import express from "express";
import path from "path";
import { GoogleGenAI } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

const app = express();
const PORT = 3000;

app.use(express.json());

// Initialize server-side Gemini client with recommended user-agent header
function getGeminiClient(): GoogleGenAI | null {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    return null;
  }
  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

// Health Check API
app.get("/api/health", (req, res) => {
  res.json({
    status: "ok",
    app: "IMAX Smart Academy",
    timestamp: new Date().toISOString(),
    geminiConfigured: !!process.env.GEMINI_API_KEY
  });
});

// Server-side AI Educational Analysis Route
app.post("/api/gemini/analyze-student", async (req, res) => {
  try {
    const { studentName, grade, examTitle, booklet1Data, booklet2Data, totalPercentage, prevExamPercentage } = req.body;
    const ai = getGeminiClient();

    if (!ai) {
      return res.status(200).json({
        success: false,
        fallback: true,
        message: "Gemini API key not configured on server. Fallback generated."
      });
    }

    const prompt = `
شما مشاور ارشد و متخصص سنجش و پذیرش مدارس تیزهوشان (سمپاد) در موسسه تیزهوشان «آی‌مکس (IMAX)» هستید.
لطفاً برای دانش‌آموز زیر، یک تحلیل آموزشی و مشاوره‌ای کاملاً حرفه‌ای به زبان فارسی و با ادبیات انگیزشی و علمی تولید کنید:

مشخصات آزمون:
- نام دانش‌آموز: ${studentName || 'دانش‌آموز'}
- پایه: ${grade === 6 ? 'پایه ششم تیزهوشان' : 'پایه نهم تیزهوشان'}
- عنوان آزمون: ${examTitle || 'آزمون شبیه‌ساز سمپاد'}
- درصد کل تراز: ${totalPercentage}%
- درصد آزمون قبلی: ${prevExamPercentage ? prevExamPercentage + '%' : 'ثبت نشده'}

اطلاعات دفترچه‌ها:
- دفترچه اول: ${JSON.stringify(booklet1Data || {})}
- دفترچه دوم: ${JSON.stringify(booklet2Data || {})}

خروجی شما باید دقیقاً یک JSON معتبر بدون هیچ مارک‌داون اضافی یا توضیح اطراف آن باشد با ساختار زیر:
{
  "summary": "یک پاراگراف چکیده ارزیابی وضعیت و سطح آمادگی دانش‌آموز برای آزمون تیزهوشان",
  "comparisonToPrevious": "مقایسه دقیق پیشرفت یا افت دانش‌آموز نسبت به آزمون‌های قبلی",
  "strengths": ["نقطه قوت اول با ذکر مبحث", "نقطه قوت دوم"],
  "weaknesses": ["نقطه ضعف اول و خطاهای پرریسک", "نقطه ضعف دوم"],
  "studySuggestions": ["پیشنهاد مطالعاتی اول شامل ساعت مطالعه و منابع تیزهوشان آی‌مکس", "پیشنهاد راهبردی دوم", "پیشنهاد سوم جهت هماهنگی با اساتید عباسی و مرحمتی"]
}
`;

    const response = await ai.models.generateContent({
      model: "gemini-3.8-flash",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
      },
    });

    const text = response.text || "{}";
    const parsed = JSON.parse(text);

    return res.json({
      success: true,
      analysis: parsed
    });
  } catch (error: any) {
    console.error("Gemini API Error:", error?.message || error);
    return res.status(200).json({
      success: false,
      fallback: true,
      error: error?.message || "Internal generation error"
    });
  }
});

async function startServer() {
  const isProduction = process.env.NODE_ENV === "production" || 
                       process.env.K_SERVICE !== undefined ||
                       (typeof __filename !== "undefined" && __filename.endsWith(".cjs"));

  if (!isProduction) {
    const { createServer: createViteServer } = await import("vite");
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`IMAX Smart Academy server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
