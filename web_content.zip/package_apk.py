import os
import sys
import shutil
import zipfile
import hashlib
import base64
import zlib
import struct
import subprocess

def main():
    print("=== India GPT Release APK Builder ===")
    workdir = "/tmp/apk_build"
    if os.path.exists(workdir):
        shutil.rmtree(workdir)
    os.makedirs(workdir, exist_ok=True)

    base_apk = "/tmp/webview-release.apk"
    if not os.path.exists(base_apk):
        print("Base APK not found! Downloading...")
        subprocess.run([
            "curl", "-s", "-L", "--connect-timeout", "15", "--max-time", "60",
            "https://github.com/bishwassagar/Android-Webview-App/raw/master/app/release/app-release.apk",
            "-o", base_apk
        ], check=True)
        print("Download complete!")

    # 1. Extract base APK
    print("Extracting base APK...")
    extract_dir = os.path.join(workdir, "extracted")
    with zipfile.ZipFile(base_apk, 'r') as z:
        z.extractall(extract_dir)

    # 2. Modify classes.dex to load local asset chat.html
    dex_path = os.path.join(extract_dir, "classes.dex")
    with open(dex_path, 'rb') as f:
        dex = bytearray(f.read())

    old_url = b"https://github.com/bishwassagar"
    new_url = b"file:///android_asset/chat.html"
    assert len(old_url) == len(new_url), "Lengths must match"

    idx = dex.find(old_url)
    if idx != -1:
        print(f"Patching classes.dex at offset {idx}...")
        dex[idx:idx+len(new_url)] = new_url

        # Recalculate SHA-1 signature (bytes 12-32) from byte 32 to end
        calc_sig = hashlib.sha1(dex[32:]).digest()
        dex[12:32] = calc_sig

        # Recalculate Adler-32 checksum (bytes 8-12) from byte 12 to end
        calc_adler = zlib.adler32(dex[12:]) & 0xffffffff
        dex[8:12] = struct.pack('<I', calc_adler)

        with open(dex_path, 'wb') as f:
            f.write(dex)
        print("classes.dex successfully patched and checksums updated.")
    else:
        print("Warning: old URL not found in classes.dex")

    # 3. Patch resources.arsc for App Name
    arsc_path = os.path.join(extract_dir, "resources.arsc")
    with open(arsc_path, 'rb') as f:
        arsc = bytearray(f.read())
    
    old_app_name = b"My Application"
    new_app_name = b"India Chat GPT"
    arsc_idx = arsc.find(old_app_name)
    if arsc_idx != -1:
        print(f"Patching resources.arsc app name at offset {arsc_idx}...")
        arsc[arsc_idx:arsc_idx+len(new_app_name)] = new_app_name
        with open(arsc_path, 'wb') as f:
            f.write(arsc)
        print("App name updated to India Chat GPT.")

    # 4. Prepare assets
    assets_dir = os.path.join(extract_dir, "assets")
    os.makedirs(assets_dir, exist_ok=True)

    # Read standalone HTML
    standalone_html_path = os.path.join(os.getcwd(), "standalone", "index.html")
    standalone_css_path = os.path.join(os.getcwd(), "standalone", "style.css")
    standalone_js_path = os.path.join(os.getcwd(), "standalone", "script.js")

    with open(standalone_html_path, 'r', encoding='utf-8') as f:
        html_content = f.read()
    with open(standalone_css_path, 'r', encoding='utf-8') as f:
        css_content = f.read()
    with open(standalone_js_path, 'r', encoding='utf-8') as f:
        js_content = f.read()

    # Self-contained single-page bundle for WebView
    bundled_chat_html = f"""<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>India GPT</title>
  <style>
{css_content}
  </style>
</head>
<body>
  <div class="app-container">
    <header class="app-header">
      <div class="brand">
        <div class="logo-badge">GPT</div>
        <div class="brand-info">
          <h1>India GPT</h1>
          <span class="status-indicator"><span class="dot"></span> Online</span>
        </div>
      </div>
      <div class="header-actions">
        <button id="cloudBtn" class="btn btn-secondary" onclick="openCloudApp()">☁️ Live Web</button>
        <button id="voiceBtn" class="btn btn-secondary">🔊 Awaaz</button>
      </div>
    </header>

    <main class="chat-viewport" id="chatViewport">
      <div class="welcome-card" id="welcomeCard">
        <div class="tricolor-bar"></div>
        <h2>Namaste! Main India GPT hoon 🇮🇳</h2>
        <p>Aapka swagat hai India Chat GPT Android App mein! Sawaal puchiye, baatein karein ya padhaai ke tips lein.</p>
        <div class="suggestion-chips">
          <button class="chip" onclick="sendQuickPrompt('Bharat ke baare mein kuch dilchasp baatein batao.')">🇮🇳 Bharat ke baare mein</button>
          <button class="chip" onclick="sendQuickPrompt('Ek naya business idea batao.')">💡 Business Idea</button>
          <button class="chip" onclick="sendQuickPrompt('Mujhe motivation do.')">🔥 Motivation</button>
        </div>
      </div>
      <div class="messages-list" id="messagesList"></div>
    </main>

    <footer class="app-footer">
      <form id="chatForm" class="input-form">
        <input 
          type="text" 
          id="userInput" 
          placeholder="India GPT se kuch bhi puchiye..." 
          autocomplete="off" 
          required
        />
        <button type="button" id="micBtn" class="icon-btn">🎤</button>
        <button type="submit" id="sendBtn" class="send-btn">Bhejo 🚀</button>
      </form>
    </footer>
  </div>

  <script>
  function openCloudApp() {{
    window.location.href = "https://ais-pre-v2a2xld5mo35ya77bxghqx-14018796331.asia-southeast1.run.app";
  }}
{js_content}
  </script>
</body>
</html>
"""

    chat_html_path = os.path.join(assets_dir, "chat.html")
    with open(chat_html_path, 'w', encoding='utf-8') as f:
        f.write(bundled_chat_html)

    # Also update offline.html
    offline_html_path = os.path.join(assets_dir, "offline.html")
    with open(offline_html_path, 'w', encoding='utf-8') as f:
        f.write(bundled_chat_html)

    # Copy files
    shutil.copy(standalone_html_path, os.path.join(assets_dir, "index.html"))
    shutil.copy(standalone_css_path, os.path.join(assets_dir, "style.css"))
    shutil.copy(standalone_js_path, os.path.join(assets_dir, "script.js"))

    # 5. Clean old signatures
    meta_inf_dir = os.path.join(extract_dir, "META-INF")
    if os.path.exists(meta_inf_dir):
        for fname in os.listdir(meta_inf_dir):
            if fname.endswith(('.SF', '.RSA', '.DSA', '.EC', 'MANIFEST.MF')):
                os.remove(os.path.join(meta_inf_dir, fname))
    else:
        os.makedirs(meta_inf_dir, exist_ok=True)

    # 6. Generate RSA key & certificate with OpenSSL
    key_path = os.path.join(workdir, "key.pem")
    cert_path = os.path.join(workdir, "cert.pem")
    print("Generating signing certificate...")
    subj_val = "//CN=IndiaGPT/O=IndiaGPT/C=IN" if (sys.platform == "win32" or "MSYSTEM" in os.environ) else "/CN=IndiaGPT/O=IndiaGPT/C=IN"
    subprocess.run([
        "openssl", "req", "-x509", "-newkey", "rsa:2048",
        "-keyout", key_path, "-out", cert_path,
        "-days", "10000", "-nodes", "-batch",
        "-subj", subj_val
    ], check=True)
    print("Signing certificate generated successfully!")

    # 7. Generate MANIFEST.MF
    print("Generating META-INF/MANIFEST.MF...")
    manifest_lines = [
        "Manifest-Version: 1.0",
        "Created-By: India-GPT-APK-Builder"
    ]
    
    file_list = []
    for root, dirs, files in os.walk(extract_dir):
        for file in sorted(files):
            full_path = os.path.join(root, file)
            rel_path = os.path.relpath(full_path, extract_dir)
            if rel_path.startswith("META-INF"):
                continue
            file_list.append((rel_path, full_path))

    manifest_entries = {}
    for rel_path, full_path in file_list:
        with open(full_path, 'rb') as f:
            content = f.read()
        digest = base64.b64encode(hashlib.sha256(content).digest()).decode('ascii')
        manifest_entries[rel_path] = digest
        manifest_lines.append("")
        manifest_lines.append(f"Name: {rel_path}")
        manifest_lines.append(f"SHA-256-Digest: {digest}")

    manifest_content = "\r\n".join(manifest_lines) + "\r\n"
    manifest_path = os.path.join(meta_inf_dir, "MANIFEST.MF")
    with open(manifest_path, 'wb') as f:
        f.write(manifest_content.encode('utf-8'))

    # 8. Generate CERT.SF
    print("Generating META-INF/CERT.SF...")
    sf_lines = [
        "Signature-Version: 1.0",
        "Created-By: India-GPT-APK-Builder",
        f"SHA-256-Digest-Manifest: {base64.b64encode(hashlib.sha256(manifest_content.encode('utf-8')).digest()).decode('ascii')}"
    ]

    for rel_path, digest in manifest_entries.items():
        entry_text = f"Name: {rel_path}\r\nSHA-256-Digest: {digest}\r\n"
        entry_digest = base64.b64encode(hashlib.sha256(entry_text.encode('utf-8')).digest()).decode('ascii')
        sf_lines.append("")
        sf_lines.append(f"Name: {rel_path}")
        sf_lines.append(f"SHA-256-Digest: {entry_digest}")

    sf_content = "\r\n".join(sf_lines) + "\r\n"
    sf_path = os.path.join(meta_inf_dir, "CERT.SF")
    with open(sf_path, 'wb') as f:
        f.write(sf_content.encode('utf-8'))

    # 9. Sign CERT.SF to create CERT.RSA
    print("Signing CERT.SF to generate CERT.RSA...")
    rsa_path = os.path.join(meta_inf_dir, "CERT.RSA")
    subprocess.run([
        "openssl", "smime", "-sign",
        "-in", sf_path,
        "-out", rsa_path,
        "-outform", "DER",
        "-inkey", key_path,
        "-signer", cert_path,
        "-nodetach"
    ], check=True)

    # 10. Package into unaligned zip
    print("Packing unaligned APK...")
    unaligned_apk = os.path.join(workdir, "unaligned.apk")
    with zipfile.ZipFile(unaligned_apk, 'w', zipfile.ZIP_DEFLATED) as z:
        for root, dirs, files in os.walk(extract_dir):
            for file in sorted(files):
                full_path = os.path.join(root, file)
                rel_path = os.path.relpath(full_path, extract_dir)
                # Store uncompressed for resources and uncompressed for alignment
                if rel_path.endswith(('.png', '.arsc')):
                    z.write(full_path, rel_path, compress_type=zipfile.ZIP_STORED)
                else:
                    z.write(full_path, rel_path, compress_type=zipfile.ZIP_DEFLATED)

    # 11. Run zipalign
    target_apk_1 = "./IndiaGPT-release.apk"
    target_apk_2 = "./app-release.apk"
    
    if os.path.exists("/usr/bin/zipalign"):
        print("Running zipalign...")
        subprocess.run(["/usr/bin/zipalign", "-f", "4", unaligned_apk, target_apk_1], check=True)
    else:
        shutil.copy(unaligned_apk, target_apk_1)

    shutil.copy(target_apk_1, target_apk_2)

    sz1 = os.path.getsize(target_apk_1)
    sz2 = os.path.getsize(target_apk_2)
    print(f"SUCCESS! Generated {target_apk_1} ({sz1} bytes) and {target_apk_2} ({sz2} bytes)")

if __name__ == "__main__":
    main()
