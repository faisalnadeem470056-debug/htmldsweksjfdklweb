const TOTAL_TARGETS = 8;
const TARGET_SIZE = 56;
const TEST_TIME_LIMIT_MS = 20000;
// Anything faster than this is treated as an accidental/reflexive double-tap,
// not a genuine reaction, and is discarded rather than recorded.
const MIN_PLAUSIBLE_MS = 120;

/**
 * Runs the reaction test inside `arenaEl` and resolves with an array of
 * reaction times in milliseconds (one per successfully hit target).
 *
 * Handles: touch + mouse input, window resize mid-test, tab visibility
 * changes (pauses rather than penalizing the player), and a hard time
 * limit so the test always terminates even if the player stops responding.
 */
export function runReactionTest({ arenaEl, hintEl, countdownEl, progressLabelEl, timerLabelEl, liveReactionEl, liveHitsEl, liveTimeEl, onCancelRequested }) {
  return new Promise((resolve, reject) => {
    let cancelled = false;
    let paused = false;
    let attempts = [];
    let currentTargetEl = null;
    let targetSpawnTime = 0;
    let remainingMs = TEST_TIME_LIMIT_MS;
    let lastTick = 0;
    let rafId = null;
    let timerIntervalId = null;

    function cleanup() {
      document.removeEventListener("visibilitychange", handleVisibility);
      window.removeEventListener("resize", handleResize);
      if (rafId) cancelAnimationFrame(rafId);
      if (timerIntervalId) clearInterval(timerIntervalId);
      arenaEl.innerHTML = "";
      hintEl.hidden = false;
    }

    function handleVisibility() {
      // Losing focus mid-target would unfairly inflate the reaction time,
      // so we pause the clock instead of counting the away-time.
      paused = document.hidden;
      if (!paused && currentTargetEl) {
        // Resume timing fresh from now to avoid counting the paused duration.
        targetSpawnTime = performance.now();
      }
    }

    function handleResize() {
      if (currentTargetEl) repositionTarget(currentTargetEl);
    }

    function randomPosition() {
      const rect = arenaEl.getBoundingClientRect();
      const maxX = Math.max(rect.width - TARGET_SIZE, 0);
      const maxY = Math.max(rect.height - TARGET_SIZE - 30, 0); // keep clear of hint text
      return {
        x: Math.random() * maxX,
        y: Math.random() * maxY,
      };
    }

    function repositionTarget(el) {
      const { x, y } = randomPosition();
      el.style.left = `${x}px`;
      el.style.top = `${y}px`;
    }

    function spawnTarget() {
      if (cancelled) return;
      hintEl.hidden = true;
      const el = document.createElement("button");
      el.type = "button";
      el.className = "target";
      el.setAttribute("aria-label", "Tap target");
      repositionTarget(el);
      arenaEl.appendChild(el);
      currentTargetEl = el;
      targetSpawnTime = performance.now();

      const handleHit = (event) => {
        event.preventDefault();
        if (paused || cancelled) return;
        const now = performance.now();
        const reactionMs = now - targetSpawnTime;

        if (reactionMs < MIN_PLAUSIBLE_MS) {
          // Ignore implausibly fast taps (likely leftover touch/click echo)
          // instead of letting them corrupt the average.
          return;
        }

        attempts.push(reactionMs);
        liveReactionEl.textContent = `${(reactionMs / 1000).toFixed(3)} s`;
        liveHitsEl.textContent = `${attempts.length} / ${TOTAL_TARGETS}`;
        progressLabelEl.textContent = `Target ${attempts.length} / ${TOTAL_TARGETS}`;

        el.remove();
        currentTargetEl = null;

        if (attempts.length >= TOTAL_TARGETS) {
          finish();
        } else {
          spawnTarget();
        }
      };

      el.addEventListener("click", handleHit, { once: true });
      el.addEventListener("touchstart", handleHit, { once: true, passive: false });
    }

    function finish(reason = "complete") {
      cleanup();
      if (cancelled) return;
      if (attempts.length < 3) {
        reject(new Error("Not enough valid attempts were recorded. Please try the test again."));
        return;
      }
      resolve(attempts);
    }

    function tickTimer() {
      if (paused || cancelled) return;
      const now = performance.now();
      const delta = now - lastTick;
      lastTick = now;
      remainingMs = Math.max(0, remainingMs - delta);
      const seconds = Math.ceil(remainingMs / 1000);
      const label = `00:${String(seconds).padStart(2, "0")}`;
      timerLabelEl.textContent = label;
      liveTimeEl.textContent = label;
      if (remainingMs <= 0) {
        finish("timeout");
      }
    }

    function runCountdown() {
      const steps = ["3", "2", "1", "GO"];
      countdownEl.hidden = false;
      let i = 0;
      countdownEl.textContent = steps[i];
      const countdownInterval = setInterval(() => {
        i += 1;
        if (i >= steps.length) {
          clearInterval(countdownInterval);
          countdownEl.hidden = true;
          startTest();
          return;
        }
        countdownEl.textContent = steps[i];
      }, 600);
    }

    function startTest() {
      lastTick = performance.now();
      timerIntervalId = setInterval(tickTimer, 250);
      progressLabelEl.textContent = `Target 0 / ${TOTAL_TARGETS}`;
      spawnTarget();
    }

    document.addEventListener("visibilitychange", handleVisibility);
    window.addEventListener("resize", handleResize);

    if (onCancelRequested) {
      onCancelRequested(() => {
        cancelled = true;
        cleanup();
        reject(new Error("cancelled"));
      });
    }

    runCountdown();
  });
}
