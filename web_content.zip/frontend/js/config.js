/**
 * Frontend runtime configuration.
 * In a real deployment these values are injected at build/deploy time
 * (e.g. via a small generated config.js or server-templated values).
 * Nothing secret lives here -- only public, non-sensitive settings.
 */
export const CONFIG = {
  API_URL: window.__ENV__?.API_URL || "http://localhost:8000",
  ADS_ENABLED: window.__ENV__?.ADS_ENABLED === true,
  ANALYTICS_ENABLED: window.__ENV__?.ANALYTICS_ENABLED === true,
};
