const SETTING_LABELS = {
  general: "General",
  red_dot: "Red Dot",
  scope_2x: "2X Scope",
  scope_4x: "4X Scope",
  sniper: "Sniper",
};

function performanceRingColor(tier) {
  if (tier === "Fast") return "var(--green)";
  if (tier === "Average") return "var(--cyan)";
  return "var(--purple)";
}

export function renderResults({ els, device, game, analysis, recommendation }) {
  els.resAvg.textContent = `${(analysis.average_reaction_time_ms / 1000).toFixed(3)} s`;
  els.resFastest.textContent = `${(analysis.fastest_reaction_time_ms / 1000).toFixed(3)} s`;
  els.resSlowest.textContent = `${(analysis.slowest_reaction_time_ms / 1000).toFixed(3)} s`;
  els.resConsistency.textContent = `${analysis.consistency_percent}%`;
  els.resDevice.textContent = device.model;
  els.resGame.textContent = game.name;
  els.resTier.textContent = analysis.performance_tier;

  const color = performanceRingColor(analysis.performance_tier);
  els.perfRing.style.background = `conic-gradient(${color} 0deg 300deg, var(--surface-border) 300deg 360deg)`;

  const settings = recommendation.settings;
  const tiles = [];
  for (const key of ["general", "red_dot", "scope_2x", "scope_4x", "sniper"]) {
    if (settings[key] === null || settings[key] === undefined) continue;
    tiles.push(`
      <div class="setting-tile">
        <span class="stat-label">${SETTING_LABELS[key]}</span>
        <span class="stat-value">${settings[key]}</span>
      </div>`);
  }
  tiles.push(`
    <div class="setting-tile">
      <span class="stat-label">DPI Range</span>
      <span class="stat-value">${settings.dpi_min}–${settings.dpi_max}</span>
    </div>`);

  els.settingsGrid.innerHTML = tiles.join("");
  els.settingsDisclaimer.textContent = recommendation.disclaimer;
}
