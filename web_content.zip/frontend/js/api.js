import { CONFIG } from "./config.js";

class ApiError extends Error {
  constructor(message, status) {
    super(message);
    this.status = status;
  }
}

async function request(path, options = {}) {
  let response;
  try {
    response = await fetch(`${CONFIG.API_URL}${path}`, {
      headers: { "Content-Type": "application/json" },
      ...options,
    });
  } catch (networkError) {
    throw new ApiError("Could not reach the server. Please check your connection.", 0);
  }

  if (!response.ok) {
    let detail = "Something went wrong. Please try again.";
    try {
      const body = await response.json();
      if (body?.detail) detail = typeof body.detail === "string" ? body.detail : detail;
    } catch {
      /* response had no JSON body */
    }
    throw new ApiError(detail, response.status);
  }

  return response.json();
}

export const api = {
  getBrands: () => request("/api/devices/brands"),
  getDevices: (brand) => request(`/api/devices?brand=${encodeURIComponent(brand)}`),
  getDevice: (id) => request(`/api/devices/${encodeURIComponent(id)}`),
  getGames: () => request("/api/games"),
  analyze: (payload) =>
    request("/api/analyze", { method: "POST", body: JSON.stringify(payload) }),
  recommend: (payload) =>
    request("/api/recommend", { method: "POST", body: JSON.stringify(payload) }),
};

export { ApiError };
