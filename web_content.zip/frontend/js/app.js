import { CONFIG } from "./config.js";
import { api, ApiError } from "./api.js";
import { initDeviceStep, initGameStep } from "./device-selector.js";
import { runReactionTest } from "./reaction-test.js";
import { getRecommendationForAttempts } from "./recommendation.js";
import { renderResults } from "./results.js";
import { shareResult } from "./share.js";

// ---------------------------------------------------------------------------
// Central, minimal state for the current session (nothing persisted, nothing
// personally identifying -- it lives only in memory for this page load).
// ---------------------------------------------------------------------------
const state = {
  device: null, // { id, brand, model }
  game: null, // { id, name, ... }
  attemptsMs: [],
  analysis: null,
  recommendation: null,
};

// Cycles used only by "Try Other Settings" to preview alternate rule-based
// profiles. These are clearly presented as alternates, not re-measurements.
const ALT_PROFILES = [
  { average_reaction_time_ms: 220, consistency_percent: 90 },
  { average_reaction_time_ms: 300, consistency_percent: 75 },
  { average_reaction_time_ms: 420, consistency_percent: 60 },
];
let altProfileIndex = 0;

const els = {
  views: {
    home: document.getElementById("view-home"),
    device: document.getElementById("view-device"),
    game: document.getElementById("view-game"),
    test: document.getElementById("view-test"),
    results: document.getElementById("view-results"),
  },
  startTestBtn: document.getElementById("start-test-btn"),
  themeToggle: document.getElementById("theme-toggle"),

  manufacturerSelect: document.getElementById("manufacturer-select"),
  modelSelect: document.getElementById("model-select"),
  deviceError: document.getElementById("device-error"),
  deviceNextBtn: document.getElementById("device-next-btn"),

  gameGrid: document.getElementById("game-grid"),
  gameError: document.getElementById("game-error"),
  gameBackBtn: document.getElementById("game-back-btn"),
  gameNextBtn: document.getElementById("game-next-btn"),

  testCancelBtn: document.getElementById("test-cancel-btn"),
  testArena: document.getElementById("test-arena"),
  testHint: document.getElementById("test-hint"),
  testCountdown: document.getElementById("test-countdown"),
  testProgressLabel: document.getElementById("test-progress-label"),
  testTimerLabel: document.getElementById("test-timer-label"),
  liveReaction: document.getElementById("live-reaction"),
  liveHits: document.getElementById("live-hits"),
  liveTime: document.getElementById("live-time"),

  resultsLoading: document.getElementById("results-loading"),
  resultsContent: document.getElementById("results-content"),
  resultsError: document.getElementById("results-error"),
  resAvg: document.getElementById("res-avg"),
  resFastest: document.getElementById("res-fastest"),
  resSlowest: document.getElementById("res-slowest"),
  resConsistency: document.getElementById("res-consistency"),
  resDevice: document.getElementById("res-device"),
  resGame: document.getElementById("res-game"),
  resTier: document.getElementById("res-tier"),
  perfRing: document.getElementById("perf-ring"),
  settingsGrid: document.getElementById("settings-grid"),
  settingsDisclaimer: document.getElementById("settings-disclaimer"),
  tryOtherBtn: document.getElementById("try-other-btn"),
  shareBtn: document.getElementById("share-btn"),
  retryBtn: document.getElementById("retry-btn"),

  toast: document.getElementById("toast"),
};

function showView(name) {
  Object.entries(els.views).forEach(([key, el]) => {
    el.hidden = key !== name;
  });
  window.scrollTo({ top: 0, behavior: "instant" in window ? "instant" : "auto" });
}

function showToast(message) {
  els.toast.textContent = message;
  els.toast.hidden = false;
  clearTimeout(showToast._t);
  showToast._t = setTimeout(() => {
    els.toast.hidden = true;
  }, 3000);
}

function trackEvent(name, payload = {}) {
  if (!CONFIG.ANALYTICS_ENABLED) return;
  // Intentionally anonymous: device/game identifiers only, never personal data.
  console.debug("[analytics]", name, payload);
}

// ---------------------------------------------------------------------------
// Theme toggle
// ---------------------------------------------------------------------------
els.themeToggle.addEventListener("click", () => {
  const isLight = document.documentElement.classList.toggle("light-theme");
  els.themeToggle.textContent = isLight ? "☀️" : "🌙";
});

// ---------------------------------------------------------------------------
// Step 1: Device
// ---------------------------------------------------------------------------
els.startTestBtn.addEventListener("click", () => {
  showView("device");
});

initDeviceStep({
  state,
  els,
  onValidChange: (valid) => {
    els.deviceNextBtn.disabled = !valid;
  },
});

els.deviceNextBtn.addEventListener("click", () => {
  if (!state.device) return;
  trackEvent("device_selected", { device_id: state.device.id });
  initGameStep({
    state,
    els,
    onValidChange: (valid) => {
      els.gameNextBtn.disabled = !valid;
    },
  });
  showView("game");
});

// ---------------------------------------------------------------------------
// Step 2: Game
// ---------------------------------------------------------------------------
els.gameBackBtn.addEventListener("click", () => showView("device"));

els.gameNextBtn.addEventListener("click", () => {
  if (!state.game) return;
  trackEvent("game_selected", { game_id: state.game.id });
  startReactionTest();
});

// ---------------------------------------------------------------------------
// Step 3: Reaction test
// ---------------------------------------------------------------------------
function startReactionTest() {
  showView("test");
  trackEvent("test_started");

  let cancelFn = null;
  els.testCancelBtn.onclick = () => {
    if (cancelFn) cancelFn();
    showView("game");
  };

  runReactionTest({
    arenaEl: els.testArena,
    hintEl: els.testHint,
    countdownEl: els.testCountdown,
    progressLabelEl: els.testProgressLabel,
    timerLabelEl: els.testTimerLabel,
    liveReactionEl: els.liveReaction,
    liveHitsEl: els.liveHits,
    liveTimeEl: els.liveTime,
    onCancelRequested: (fn) => {
      cancelFn = fn;
    },
  })
    .then((attemptsMs) => {
      state.attemptsMs = attemptsMs;
      trackEvent("test_completed", { attempts: attemptsMs.length });
      showResultsFor(state.attemptsMs);
    })
    .catch((err) => {
      if (err.message === "cancelled") return;
      showView("game");
      showToast(err.message || "The test could not be completed. Please try again.");
    });
}

// ---------------------------------------------------------------------------
// Step 4: Results
// ---------------------------------------------------------------------------
async function showResultsFor(attemptsMs) {
  showView("results");
  els.resultsLoading.hidden = false;
  els.resultsContent.hidden = true;
  els.resultsError.hidden = true;
  altProfileIndex = 0;

  try {
    const { analysis, recommendation } = await getRecommendationForAttempts({
      deviceId: state.device.id,
      gameId: state.game.id,
      attemptsMs,
    });
    state.analysis = analysis;
    state.recommendation = recommendation;

    renderResults({ els, device: state.device, game: state.game, analysis, recommendation });
    els.resultsLoading.hidden = true;
    els.resultsContent.hidden = false;
    trackEvent("result_viewed", { device_id: state.device.id, game_id: state.game.id });
  } catch (err) {
    els.resultsLoading.hidden = true;
    els.resultsError.hidden = false;
    els.resultsError.textContent =
      err instanceof ApiError ? err.message : "Could not load your results. Please try again.";
  }
}

els.retryBtn.addEventListener("click", () => {
  startReactionTest();
});

els.tryOtherBtn.addEventListener("click", async () => {
  altProfileIndex = (altProfileIndex + 1) % ALT_PROFILES.length;
  const alt = ALT_PROFILES[altProfileIndex];
  try {
    const recommendation = await api.recommend({
      device_id: state.device.id,
      game_id: state.game.id,
      average_reaction_time_ms: alt.average_reaction_time_ms,
      consistency_percent: alt.consistency_percent,
    });
    state.recommendation = recommendation;
    renderResults({ els, device: state.device, game: state.game, analysis: state.analysis, recommendation });
    showToast(`Showing alternate profile: ${recommendation.profile_label}`);
  } catch (err) {
    showToast("Could not load an alternate profile right now.");
  }
});

els.shareBtn.addEventListener("click", () => {
  trackEvent("share_clicked");
  shareResult({
    device: state.device,
    game: state.game,
    analysis: state.analysis,
    recommendation: state.recommendation,
    showToast,
  });
});

// ---------------------------------------------------------------------------
// Footer year + ad slot toggling based on config
// ---------------------------------------------------------------------------
document.getElementById("footer-year").textContent = new Date().getFullYear();

if (CONFIG.ADS_ENABLED) {
  document.querySelectorAll(".ad-slot").forEach((el) => {
    el.hidden = false;
    el.textContent = "Ad space";
  });
}
