import { api } from "./api.js";

const GAME_ICONS = {
  "free-fire": "🔥",
  "pubg-mobile": "🪖",
  bgmi: "🎖️",
  "cod-mobile": "🎮",
};

export async function initDeviceStep({ state, els, onValidChange }) {
  const manufacturerSelect = els.manufacturerSelect;
  const modelSelect = els.modelSelect;

  try {
    const brands = await api.getBrands();
    manufacturerSelect.innerHTML =
      `<option value="">Select manufacturer</option>` +
      brands.map((b) => `<option value="${b}">${b}</option>`).join("");
  } catch (err) {
    showDeviceError(els, err.message);
    return;
  }

  manufacturerSelect.addEventListener("change", async () => {
    const brand = manufacturerSelect.value;
    modelSelect.innerHTML = `<option value="">Loading models…</option>`;
    modelSelect.disabled = true;
    state.device = null;
    onValidChange(false);

    if (!brand) {
      modelSelect.innerHTML = `<option value="">Select manufacturer first</option>`;
      return;
    }

    try {
      const devices = await api.getDevices(brand);
      if (devices.length === 0) {
        modelSelect.innerHTML = `<option value="">No models available yet</option>`;
        return;
      }
      modelSelect.innerHTML =
        `<option value="">Select model</option>` +
        devices.map((d) => `<option value="${d.id}">${d.model}</option>`).join("");
      modelSelect.disabled = false;
    } catch (err) {
      showDeviceError(els, err.message);
    }
  });

  modelSelect.addEventListener("change", () => {
    const deviceId = modelSelect.value;
    if (!deviceId) {
      state.device = null;
      onValidChange(false);
      return;
    }
    state.device = {
      id: deviceId,
      brand: manufacturerSelect.value,
      model: modelSelect.options[modelSelect.selectedIndex].text,
    };
    hideDeviceError(els);
    onValidChange(true);
  });
}

function showDeviceError(els, message) {
  els.deviceError.textContent = message;
  els.deviceError.hidden = false;
}
function hideDeviceError(els) {
  els.deviceError.hidden = true;
}

export async function initGameStep({ state, els, onValidChange }) {
  let games = [];
  try {
    games = await api.getGames();
  } catch (err) {
    els.gameError.textContent = err.message;
    els.gameError.hidden = false;
    return;
  }

  els.gameGrid.innerHTML = games
    .map(
      (g) => `
      <button type="button" class="game-card" data-game-id="${g.id}" role="option" aria-selected="false">
        <span class="thumb" aria-hidden="true">${GAME_ICONS[g.id] || "🎮"}</span>
        ${g.name}
      </button>`
    )
    .join("");

  els.gameGrid.querySelectorAll(".game-card").forEach((card) => {
    card.addEventListener("click", () => {
      els.gameGrid.querySelectorAll(".game-card").forEach((c) => {
        c.classList.remove("selected");
        c.setAttribute("aria-selected", "false");
      });
      card.classList.add("selected");
      card.setAttribute("aria-selected", "true");
      const game = games.find((g) => g.id === card.dataset.gameId);
      state.game = game;
      els.gameError.hidden = true;
      onValidChange(true);
    });
  });
}
