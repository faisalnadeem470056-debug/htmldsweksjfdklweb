/**
 * Builds a shareable text summary (no personal information) and shares it
 * via the Web Share API when available, falling back to copying a link
 * to the clipboard otherwise.
 */
export async function shareResult({ device, game, analysis, recommendation, showToast }) {
  const text = [
    "Smart Headshot Engine",
    `Device: ${device.model}`,
    `Game: ${game.name}`,
    `Reaction Time: ${(analysis.average_reaction_time_ms / 1000).toFixed(3)}s (${analysis.performance_tier})`,
    `Recommended General Sensitivity: ${recommendation.settings.general}`,
  ].join("\n");

  const shareUrl = window.location.origin;

  if (navigator.share) {
    try {
      await navigator.share({ title: "My Smart Headshot Engine result", text, url: shareUrl });
      return;
    } catch (err) {
      // User cancelled the native share sheet -- not an error worth surfacing.
      if (err?.name === "AbortError") return;
    }
  }

  try {
    await navigator.clipboard.writeText(`${text}\n${shareUrl}`);
    showToast("Result copied to clipboard!");
  } catch {
    showToast("Could not copy automatically. You can screenshot your results instead.");
  }
}
