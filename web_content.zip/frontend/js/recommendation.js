import { api } from "./api.js";

/**
 * Sends raw reaction attempts to the backend for analysis, then requests
 * a settings recommendation based on the analysis output. All numbers
 * shown to the user originate from these two API responses -- nothing
 * is computed or guessed on the client.
 */
export async function getRecommendationForAttempts({ deviceId, gameId, attemptsMs }) {
  const analysis = await api.analyze({
    device_id: deviceId,
    game_id: gameId,
    attempts: attemptsMs.map((ms) => ({ reaction_time_ms: ms })),
  });

  const recommendation = await api.recommend({
    device_id: deviceId,
    game_id: gameId,
    average_reaction_time_ms: analysis.average_reaction_time_ms,
    consistency_percent: analysis.consistency_percent,
  });

  return { analysis, recommendation };
}
