/**
 * Default local-development environment.
 * In production, this file is generated from env.template.js at deploy time
 * with real values -- see README.md for the Render deployment steps.
 */
window.__ENV__ = {
  API_URL: "http://localhost:8000",
  ADS_ENABLED: false,
  ANALYTICS_ENABLED: false,
};
