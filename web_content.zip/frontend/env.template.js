/**
 * Template for the runtime environment file consumed by js/config.js.
 * During deployment, generate frontend/env.js from this template with your
 * actual values substituted (e.g. via `envsubst` or a small build script),
 * and include it before app.js in index.html:
 *
 *   <script src="/env.js"></script>
 *   <script type="module" src="/js/app.js"></script>
 *
 * Never put secrets here -- this file is public and served as-is.
 */
window.__ENV__ = {
  API_URL: "${API_URL}",
  ADS_ENABLED: ${ADS_ENABLED},
  ANALYTICS_ENABLED: ${ANALYTICS_ENABLED},
};
