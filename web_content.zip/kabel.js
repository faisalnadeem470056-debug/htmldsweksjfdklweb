const T568A = [
    {
        warna: "Putih Hijau",
        fungsi: "Transmit (+) = Kirim data"
    },
    {
        warna: "Hijau",
        fungsi: "Transmit (-) = Kirim data"
    },
    {
        warna: "Putih Orange",
        fungsi: "Receive (+) = Terima data"
    },
    {
        warna: "Biru",
        fungsi: "Data Gigabit = Data jaringan"
    },
    {
        warna: "Putih Biru",
        fungsi: "Data Gigabit = Data jaringan"
    },
    {
        warna: "Orange",
        fungsi: "Receive (-) = Terima data"
    },
    {
        warna: "Putih Coklat",
        fungsi: "Data Gigabit = Data jaringan"
    },
    {
        warna: "Coklat",
        fungsi: "Data Gigabit = Data jaringan"
    }
];

const T568B = [
    {
        warna: "Putih Orange",
        fungsi: "Transmit (+) = Kirim data"
    },
    {
        warna: "Orange",
        fungsi: "Transmit (-) = Kirim data"
    },
    {
        warna: "Putih Hijau",
        fungsi: "Receive (+) = Terima data"
    },
    {
        warna: "Biru",
        fungsi: "Data Gigabit = Data jaringan"
    },
    {
        warna: "Putih Biru",
        fungsi: "Data Gigabit = Data jaringan"
    },
    {
        warna: "Hijau",
        fungsi: "Receive (-) = Terima data"
    },
    {
        warna: "Putih Coklat",
        fungsi: "Data Gigabit = Data jaringan"
    },
    {
        warna: "Coklat",
        fungsi: "Data Gigabit = Data jaringan"
    }
];


function createTable(data) {

    let output = `
        <table style="width:100%; margin-top:15px;">
            <tr>
                <th>Pin</th>
                <th>Warna</th>
                <th>Fungsi</th>
            </tr>
    `;

    data.forEach(function(item, index) {

        output += `
            <tr>
                <td>${index + 1}</td>
                <td>${item.warna}</td>
                <td>${item.fungsi}</td>
            </tr>
        `;

    });

    output += `
        </table>
    `;

    return output;
}


function showStraight() {

    const result = document.getElementById("cableResult");

    result.innerHTML = `
        <div class="result-box">

            <h2>STRAIGHT</h2>

            <p>
                <b>Fungsi:</b><br>
                Menghubungkan perangkat yang berbeda jenis.
            </p>

            <p>
                <b>Contoh:</b><br>
                PC → Switch<br>
                PC → Router
            </p>

            <p>
                <b>Ujung 1: T568B</b>
            </p>

            ${createTable(T568B)}

            <p style="margin-top:20px;">
                <b>Ujung 2: T568B</b>
            </p>

            ${createTable(T568B)}

        </div>
    `;
}


function showCrossover() {

    const result = document.getElementById("cableResult");

    result.innerHTML = `
        <div class="result-box">

            <h2>CROSSOVER</h2>

            <p>
                <b>Fungsi:</b><br>
                Menghubungkan perangkat yang sejenis
                pada perangkat yang tidak mendukung
                Auto-MDI/MDI-X.
            </p>

            <p>
                <b>Contoh:</b><br>
                PC → PC<br>
                Switch → Switch<br>
                Router → Router
            </p>

            <p>
                <b>Ujung 1: T568A</b>
            </p>

            ${createTable(T568A)}

            <p style="margin-top:20px;">
                <b>Ujung 2: T568B</b>
            </p>

            ${createTable(T568B)}

        </div>
    `;
}