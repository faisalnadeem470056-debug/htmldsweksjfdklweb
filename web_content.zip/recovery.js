/* Aucun lien de récupération, jeton ou mot de passe n'est enregistré. */
(function () {
  'use strict';
  const project = 'https://yiozxgmolugolfiocrwx.supabase.co';
  const publicKey = 'sb_publishable_5jKQuq7QFyvkY_h54hp6LA_MfSsvW-N';
  const expectedEmail = 'gninannetro@gmail.com';
  const expectedId = 'd25a70dc-48ac-4252-8d0b-29c016d1959a';
  function parseLink(value) {
    let u;
    try { u = new URL(value.trim().replace(/&amp;/g, '&')); } catch { throw Error('Collez l’adresse complète du lien reçu par e-mail.'); }
    if (u.origin !== project || u.pathname !== '/auth/v1/verify' || u.username || u.password || u.searchParams.get('type') !== 'recovery') {
      throw Error('Ce lien ne correspond pas à la récupération du compte MIDOK. Copiez le lien « Reset password » du dernier e-mail Supabase.');
    }
    const token = u.searchParams.get('token');
    if (!token || token.length > 1024) throw Error('Lien incomplet. Copiez de nouveau son adresse depuis l’e-mail.');
    return token;
  }
  async function request(path, method, body, token) {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 20000);
    try {
      const r = await fetch(project + path, {
        method, credentials: 'omit', referrerPolicy: 'no-referrer', cache: 'no-store',
        headers: { apikey: publicKey, 'Content-Type': 'application/json', ...(token ? { Authorization: 'Bearer ' + token } : {}) },
        body: body === undefined ? undefined : JSON.stringify(body), signal: controller.signal
      });
      const data = await r.json().catch(() => ({}));
      if (!r.ok) {
        if (path === '/auth/v1/verify') throw Error('Lien expiré, déjà utilisé ou invalide. Dans Supabase, demandez un nouvel e-mail avec « Send password recovery », puis copiez son lien sans l’ouvrir.');
        if (r.status === 401 || r.status === 403) throw Error('Session expirée ou autorisation supplémentaire requise. Demandez un nouveau lien de récupération.');
        if (data.code === 'same_password' || data.error_code === 'same_password') throw Error('Choisissez un mot de passe différent de l’ancien.');
        if (r.status === 422) throw Error('Ce mot de passe est refusé. Choisissez-en un autre, plus long et unique.');
        throw Error('Supabase a refusé la demande (code ' + r.status + '). Réessayez ou transmettez uniquement ce code.');
      }
      return data;
    } catch (e) {
      if (e.name === 'AbortError') throw Error('Délai dépassé. Si vous enregistriez le mot de passe, essayez de vous connecter avec le nouveau ; sinon demandez un nouveau lien.');
      if (e instanceof TypeError) throw Error('Connexion impossible. Vérifiez Internet et ouvrez cette page dans votre navigateur ou l’application MIDOK.');
      throw e;
    } finally { clearTimeout(timer); }
  }
  function createRecovery() {
    let session = null;
    return {
      async reset(link, password, confirmation) {
        if (password.length < 12) throw Error('Choisissez au moins 12 caractères.');
        if (password !== confirmation) throw Error('Les deux mots de passe ne correspondent pas.');
        if (!session) {
          const result = await request('/auth/v1/verify', 'POST', { token_hash: parseLink(link), type: 'recovery' });
          if (!result.access_token || result.user?.id !== expectedId || result.user?.email?.toLowerCase() !== expectedEmail) {
            throw Error('Ce lien ne correspond pas au compte administrateur gninannetro@gmail.com.');
          }
          session = result.access_token;
        }
        await request('/auth/v1/user', 'PUT', { password }, session);
        const token = session;
        session = null;
        // L'échec d'une déconnexion ne doit pas masquer un changement réussi.
        request('/auth/v1/logout?scope=local', 'POST', undefined, token).catch(() => {});
      },
      clear() { session = null; }
    };
  }
  if (typeof module !== 'undefined' && module.exports) { module.exports = { parseLink, createRecovery }; return; }
  const form = document.getElementById('recovery-form');
  const status = document.getElementById('status');
  const recovery = createRecovery();
  form.addEventListener('submit', async event => {
    event.preventDefault();
    const button = form.querySelector('button[type="submit"]');
    button.disabled = true;
    status.textContent = 'Vérification du lien et enregistrement…';
    try {
      await recovery.reset(form.elements.namedItem('link').value, form.elements.namedItem('password').value, form.elements.namedItem('confirmation').value);
      form.reset(); form.hidden = true;
      status.textContent = 'Mot de passe modifié. Retournez dans MIDOK Admin et connectez-vous avec gninannetro@gmail.com et votre nouveau mot de passe.';
      status.className = 'success';
    } catch (e) { status.textContent = e.message; status.className = 'error'; }
    finally { button.disabled = false; }
  });
  window.addEventListener('pagehide', () => { recovery.clear(); form.reset(); });
})();
