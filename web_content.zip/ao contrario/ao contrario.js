function traduzirText(){
    let traduzir = document.getElementById('pt').value;
    let invertida = traduzir.split(" ")
    .map(palav => palav.split("").reverse().join(""))
    .join(" ");
    document.getElementById('cont').value = invertida;
}
const botTrad = document.getElementById('trad');
botTrad.addEventListener('click', traduzirText);
