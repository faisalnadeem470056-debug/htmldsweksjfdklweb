TradeLab Android App

This is a PWA-style app version.
For true "install as app" behavior:
1. Put this folder on an HTTPS site or serve it on localhost.
2. Open index.html in Chrome.
3. Chrome menu (⋮) -> Add to Home screen / Install app.
4. The app opens without the normal browser UI.

IMPORTANT:
- Opening index.html directly with file:// can work for the journal, but Chrome may not offer PWA installation.
- All newly entered trades are stored locally on the phone/browser.
- Use a backup/export before clearing Chrome site data.

NEW FINANCIAL YEAR:
- Tap "+ New Year".
- Enter 2027 to create a 2027–28 tab.
- That tab has its own Dashboard, Trade Input, Monthly P&L and Calendar.
- Existing 2026–27 and historical data stay unchanged.
