package com.l3bat.alhayya.converter;

import android.app.Activity;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.UUID;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private static final int PICK_FILE = 1001;
    private Uri selectedUri;
    private String selectedName = "input.bin";
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private TextView selectedFileText, statusText;
    private ProgressBar progress;
    private EditText appNameEdit, packageEdit, serverUrlEdit;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        selectedFileText = findViewById(R.id.selectedFileText);
        statusText = findViewById(R.id.statusText);
        progress = findViewById(R.id.progress);
        appNameEdit = findViewById(R.id.appNameEdit);
        packageEdit = findViewById(R.id.packageEdit);
        serverUrlEdit = findViewById(R.id.serverUrlEdit);
        ((Button)findViewById(R.id.selectFileButton)).setOnClickListener(v -> pickFile());
        ((Button)findViewById(R.id.buildButton)).setOnClickListener(v -> buildApk());
    }

    private void pickFile() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.setType("*/*"); i.addCategory(Intent.CATEGORY_OPENABLE);
        startActivityForResult(i, PICK_FILE);
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_FILE && resultCode == RESULT_OK && data != null) {
            selectedUri = data.getData();
            if (selectedUri != null) {
                try {
                    getContentResolver().takePersistableUriPermission(selectedUri, Intent.FLAG_GRANT_READ_URI_PERMISSION);
                } catch (Exception ignored) {}
                selectedName = "input.bin";
                if (data.getClipData() == null) {
                    String last = selectedUri.getLastPathSegment();
                    if (last != null && !last.isEmpty()) selectedName = last;
                }
                selectedFileText.setText("الملف: " + selectedName);
            }
        }
    }

    private void buildApk() {
        if (selectedUri == null) { statusText.setText("اختر ملفًا أولًا"); return; }
        String server = serverUrlEdit.getText().toString().trim();
        if (server.isEmpty()) { statusText.setText("أدخل عنوان خادم البناء"); return; }
        String appName = appNameEdit.getText().toString().trim();
        String packageName = packageEdit.getText().toString().trim();
        if (appName.isEmpty()) appName = "تطبيقي";
        if (!packageName.matches("[a-zA-Z_][a-zA-Z0-9_]*(\\.[a-zA-Z_][a-zA-Z0-9_]*)+")) {
            statusText.setText("اسم الحزمة غير صحيح"); return;
        }
        final String fAppName = appName, fPackage = packageName;
        progress.setVisibility(View.VISIBLE); statusText.setText("جاري الرفع والبناء...");
        executor.execute(() -> {
            try {
                byte[] apk = uploadMultipart(server + "/api/build", fAppName, fPackage, selectedName);
                saveApk(apk, safeFileName(fAppName) + ".apk");
                runOnUiThread(() -> { progress.setVisibility(View.GONE); statusText.setText("تم بناء APK وحفظه داخل مجلد Downloads"); });
            } catch (Exception e) {
                runOnUiThread(() -> { progress.setVisibility(View.GONE); statusText.setText("فشل البناء: " + e.getMessage()); });
            }
        });
    }

    private byte[] uploadMultipart(String endpoint, String appName, String packageName, String fileName) throws Exception {
        String boundary = "----L3bat" + UUID.randomUUID();
        URL url = new URL(endpoint + "?app_name=" + URLEncoder.encode(appName, "UTF-8") + "&package_name=" + URLEncoder.encode(packageName, "UTF-8"));
        HttpURLConnection c = (HttpURLConnection) url.openConnection();
        c.setRequestMethod("POST"); c.setDoOutput(true); c.setConnectTimeout(20000); c.setReadTimeout(180000);
        c.setRequestProperty("Content-Type", "multipart/form-data; boundary=" + boundary);
        try (OutputStream out = c.getOutputStream(); InputStream in = getContentResolver().openInputStream(selectedUri)) {
            String head = "--" + boundary + "\r\nContent-Disposition: form-data; name=\"file\"; filename=\"" + fileName + "\"\r\nContent-Type: application/octet-stream\r\n\r\n";
            out.write(head.getBytes(StandardCharsets.UTF_8));
            byte[] buf = new byte[8192]; int n;
            while ((n = in.read(buf)) != -1) out.write(buf, 0, n);
            out.write(("\r\n--" + boundary + "--\r\n").getBytes(StandardCharsets.UTF_8));
        }
        int code = c.getResponseCode();
        InputStream response = code >= 400 ? c.getErrorStream() : c.getInputStream();
        byte[] data = readAll(response);
        if (code != 200) throw new RuntimeException(new String(data, StandardCharsets.UTF_8));
        return data;
    }

    private byte[] readAll(InputStream in) throws Exception {
        if (in == null) return new byte[0];
        try (InputStream x = in; ByteArrayOutputStream b = new ByteArrayOutputStream()) {
            byte[] buf = new byte[8192]; int n; while ((n = x.read(buf)) != -1) b.write(buf, 0, n); return b.toByteArray();
        }
    }

    private void saveApk(byte[] bytes, String name) throws Exception {
        ContentResolver r = getContentResolver();
        ContentValues v = new ContentValues();
        v.put(MediaStore.Downloads.DISPLAY_NAME, name);
        v.put(MediaStore.Downloads.MIME_TYPE, "application/vnd.android.package-archive");
        v.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);
        Uri outUri = r.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
        if (outUri == null) throw new RuntimeException("تعذر إنشاء ملف التنزيل");
        try (OutputStream out = r.openOutputStream(outUri)) { out.write(bytes); }
    }

    private String safeFileName(String s) { return s.replaceAll("[^a-zA-Z0-9._-]+", "_"); }
}
