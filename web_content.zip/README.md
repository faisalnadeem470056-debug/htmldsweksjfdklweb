# تواصل جردان - Android APK

هذا مشروع Android بسيط يضع واجهة HTML/CSS داخل WebView.

## البناء
افتح المشروع في Android Studio وانتظر مزامنة Gradle، ثم:
Build > Build Bundle(s) / APK(s) > Build APK(s)

ملف APK الناتج سيكون عادة داخل:
app/build/outputs/apk/debug/app-debug.apk

ملاحظة: زر "متابعة" في النسخة الحالية تجريبي فقط ولا يرسل رمز تحقق أو يسجل دخولًا فعليًا.
