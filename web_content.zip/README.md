# 击杀圣母心 Android APK 工程

这是对原 HTML 游戏的 Android WebView 封装工程。

## 构建
1. 用 Android Studio 打开本目录。
2. 等待 Gradle 同步完成。
3. Build -> Build Bundle(s) / APK(s) -> Build APK(s)。
4. APK 通常在 `app/build/outputs/apk/debug/app-debug.apk`。

## 注意
原 HTML 依赖 Three.js CDN，因此 APK 首次运行游戏时需要网络访问该 CDN。
如果要做“完全离线版”，需要把 Three.js 依赖一起内置进 assets 后，把 `game.html` 中的 CDN script 改成本地路径。


## 完全离线版说明
- `app/src/main/assets/three.min.js` 已内置 Three.js 0.160.0。
- `game.html` 已改为从 APK 内部加载，不再访问 jsDelivr/CDN。
- 已移除 Android INTERNET 权限。
- 按当前游戏源码检查，没有发现其他 `http://` / `https://` 外部资源引用。
