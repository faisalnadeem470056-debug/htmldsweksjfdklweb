# ArquivoParaAPK

Projeto Android inicial para transformar um projeto web (HTML/CSS/JS) em um aplicativo Android baseado em WebView.

## Estrutura

- `app/src/main/java/.../MainActivity.java` — tela Android e WebView.
- `app/src/main/assets/` — interface web e arquivos que serão incorporados ao app.
- `app/src/main/AndroidManifest.xml` — configuração do aplicativo.
- `app/build.gradle` — configuração de compilação.
- `settings.gradle` — configuração do projeto.

## Como compilar

Abra a pasta do projeto em um ambiente Android/Gradle compatível e execute a compilação de debug.

## Importante

Esta versão é uma base real de projeto Android, mas a função "Preparar projeto" da interface ainda não executa uma compilação do APK dentro do próprio aplicativo. A ideia é primeiro ter uma base compilável e depois adicionar o mecanismo completo de importação/empacotamento.

## Próxima evolução

1. Importação real de ZIP/HTML para `assets`.
2. Validação da estrutura do site.
3. Geração automática do projeto.
4. Ícone e metadados.
5. Empacotamento e assinatura.
