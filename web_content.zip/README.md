# دفتر حسابات المولدة - Android

هذا مشروع Android Studio جاهز للبناء، ويحوّل واجهة HTML إلى تطبيق APK باستخدام WebView.

## المتطلبات
- Android Studio حديث
- اتصال إنترنت أول مرة لتنزيل Gradle/AndroidX
- JDK المدمج مع Android Studio

## بناء APK
1. افتح المجلد `دفتر_حسابات_المولدة_Android` في Android Studio.
2. انتظر انتهاء Gradle Sync.
3. اختر Build > Build APK(s).
4. ستجد APK عادةً داخل:
   `app/build/outputs/apk/debug/app-debug.apk`

## التخزين
تم استبدال `window.storage` الموجود في الشفرة الأصلية بتخزين Android SharedPreferences، لذلك بيانات الزبائن تبقى محفوظة داخل التطبيق بعد إغلاقه.

## ملاحظة
هذا المشروع لا يحتاج صلاحية الإنترنت. الخطوط أصبحت محلية/افتراضية حتى يعمل التطبيق بدون إنترنت.
