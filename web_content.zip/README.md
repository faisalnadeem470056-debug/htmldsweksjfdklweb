# لعبة الحية — Universal File → APK Builder

هذا المشروع يتكوّن من جزأين:

1. **Android App**: تطبيق الهاتف "لعبة الحية" لاختيار الملف وإرساله إلى خادم البناء وتنزيل APK الناتج.
2. **Build Server**: خادم Python/FastAPI يقوم بتحليل الملف وبناء APK حقيقي.

## الأنواع المدعومة

- **Android/Gradle ZIP**: يبني المشروع نفسه إذا كان مشروع Android قابلًا للبناء.
- **HTML / WEB**: ملف HTML أو ZIP يحتوي `index.html` يتم تغليفه داخل WebView ثم بناؤه كـ APK.
- **الملفات الأخرى**: يتم إنشاء APK حقيقي يضم الملف داخل `assets/` مع شاشة لفتح الملف أو مشاركته؛ هذا لا يحوّل محتوى الملف إلى تطبيق أصلي سحريًا، بل يضمّه داخل تطبيق.

## المتطلبات

- Android Studio حديث لبناء تطبيق الهاتف.
- Java 17+ لخادم البناء.
- Android SDK + Build Tools على خادم البناء.
- Gradle 8.7 على الخادم.

> ملاحظة: بناء APK يحتاج بيئة Android SDK/Gradle. لا يمكن لتطبيق هاتف عادي أن يترجم أي ملف إلى APK من دون أدوات بناء؛ لذلك أُرفق خادم بناء حقيقي مع المشروع.

## تشغيل خادم البناء بسرعة

```bash
cd backend
python -m venv .venv
# Linux/macOS
source .venv/bin/activate
# Windows PowerShell: .venv\\Scripts\\Activate.ps1
pip install -r requirements.txt
uvicorn app:app --host 0.0.0.0 --port 8080
```

لخادم على جهاز آخر في الشبكة المحلية، ضع عنوانه في تطبيق الهاتف مثل:

`http://192.168.1.100:8080`

على Android Emulator يمكن استخدام:

`http://10.0.2.2:8080`

## Docker

يوجد `Dockerfile` لتجهيز بيئة البناء. راجع `backend/README.md`.

## بناء تطبيق الهاتف

افتح مجلد `android-app` في Android Studio ثم Build APK.

اسم التطبيق الظاهر: **لعبة الحية**

اسم المشروع: **لعبة الحية**

الحزمة: `com.l3bat.alhayya.converter`

## سير العمل

اختيار ملف → اكتشاف النوع → رفعه لخادم البناء → توليد مشروع Android مناسب → Gradle assembleDebug → تنزيل APK.

