# APEX TALLENTEX 2027

Complete Preparation System — a dependency-free, local-first PWA for syllabus tracking, practice tests, mock tests, results, analytics, mistakes, revision, daily goals, streaks, achievements and an app-based exam-readiness indicator.

## Run locally

Use any static web server (recommended because service workers require a secure context):

```bash
python3 -m http.server 8080
```

Open `http://localhost:8080`.

Opening `index.html` directly also renders the core UI, but service-worker/PWA installation features require HTTPS or localhost.

## GitHub Pages

1. Upload the extracted project contents to a repository.
2. In **Settings → Pages**, select the deployment source/branch.
3. Open the generated HTTPS URL.
4. Reload once after the service worker has installed so core assets are cached.

## Netlify

Drag the project folder into Netlify Drop, or connect the repository. No build command is required.

## Cloudflare Pages

Create a Pages project from the repository and use the project root as the output directory. No build command is required.

## Vercel

Import the repository as a Vercel project. The project is static and needs no build command.

## Android PWA installation

Use the in-app **Install App** action when the browser exposes `beforeinstallprompt`. If it is unavailable, use the browser menu and choose **Install app** or **Add to Home screen** when offered.

This is a PWA, not an APK. A later Android package can be produced with a suitable Trusted Web Activity or other web-to-app wrapper.

## Offline behavior

After the first successful load, the service worker caches the core application assets. Syllabus, local question bank, tests, results, analytics, revision, mistakes, goals and settings are designed to work from local storage while offline.

## Local storage and privacy

The app uses browser `localStorage`. There is no account, backend, analytics tracker, password store or personal-data upload. The student's name and preparation data remain in that browser's local storage.

Clearing browser site data can erase progress. The Settings screen also provides destructive reset actions.

## Service-worker updates

The cache is versioned in `sw.js`. To ship a new core version, change the `CACHE` version, deploy, and reload. Old caches are removed during activation.

## Question-bank architecture

Questions are separated into `data.js` and contain `id`, `subject`, `topic`, `difficulty`, `question`, `options`, `correctAnswer`, and `explanation`. The current bank is a compact built-in practice bank and is explicitly not official TALLENTEX material. More questions can be added to the same structure later.

## Design direction
The APEX refresh uses original CSS-built visuals inspired by modern dark education dashboard patterns: bento-style information grouping, vivid subject accents, progress rings, compact analytics, and animated micro-interactions. Visual references reviewed during the redesign included contemporary education UI work on Behance and Dribbble; no third-party artwork is bundled in the app.
