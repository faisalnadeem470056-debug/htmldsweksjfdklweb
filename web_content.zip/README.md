# Mail — Gmail-inspired starter app

This is a safe starter prototype for an email-style app. It does NOT collect Google passwords or 2FA codes.

## Run
Open `index.html` in a browser. For a real Android app, place this web app inside a trusted Android WebView wrapper or use a web-to-app builder.

## Firebase
The included `firebase-config.js` is a placeholder. To enable real Google Sign-In, email/password authentication, Firestore, and phone verification, create your own Firebase project and replace the placeholder configuration.

Important:
- Never ask users for their Google password.
- Never store passwords in plain text.
- Never send users' OTP/2FA codes to an admin.
- Admin notifications should contain only non-secret event information.
