Forex Robot v2 Android wrapper. Import this Gradle project into an Android build service to generate an APK. TradingView visual integration and real-time MT5/RCG data integration are separate steps.
