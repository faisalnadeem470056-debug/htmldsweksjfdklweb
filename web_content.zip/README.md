# Smart Headshot Engine

An interactive tool that helps mobile gamers get a **suggested** sensitivity
and DPI starting point, based on their device, their chosen game, and a short
in-browser reaction-time test.

> Built by **Mohammed Mansour**.

**Important:** results are a rule-based, approximate starting point — not a
scientific measurement of reflexes and not a guarantee of "the best" settings
for any individual player.

---

## Architecture

```
Frontend (vanilla HTML/CSS/JS)  --->  FastAPI backend  --->  SQLite (seeded from JSON)
     served as static files          /api/devices                devices.json
                                      /api/games                  games.json
                                      /api/analyze
                                      /api/recommend
                                      /api/health
```

- **Frontend**: no framework, no build step required. Plain ES modules.
- **Backend**: FastAPI, Pydantic validation on every input, a deterministic
  rule-based recommendation engine (no randomness, no ML).
- **Database**: SQLite for v1, accessed only through a repository layer
  (`app/repositories/`) so it can be swapped for PostgreSQL later without
  touching services or API routes.
- **Recommendation engine**: see `backend/app/services/recommendation_service.py`
  for the exact, documented rules.

## Project structure

```
smart-headshot-engine/
├── backend/
│   ├── app/
│   │   ├── main.py               FastAPI app, middleware, startup seeding
│   │   ├── config.py             Environment-driven settings
│   │   ├── api/
│   │   │   ├── routes.py         All /api/* endpoints
│   │   │   └── middleware.py     Rate limiting + security headers
│   │   ├── schemas/schemas.py    Pydantic request/response models
│   │   ├── services/
│   │   │   ├── analysis_service.py        Reaction-time statistics
│   │   │   └── recommendation_service.py  Rule-based settings engine
│   │   ├── repositories/         Data access (SQLite, seeded from JSON)
│   │   ├── models/database.py    SQLite connection + schema
│   │   ├── data/devices.json     Seed dataset (extend freely)
│   │   ├── data/games.json       Seed dataset (extend freely)
│   │   └── tests/                pytest suite
│   ├── requirements.txt
│   ├── Dockerfile
│   └── .env.example
├── frontend/
│   ├── index.html
│   ├── privacy.html / terms.html
│   ├── robots.txt / sitemap.xml
│   ├── css/style.css
│   ├── js/
│   │   ├── app.js                View routing + orchestration
│   │   ├── api.js                Fetch wrapper
│   │   ├── device-selector.js    Device + game selection
│   │   ├── reaction-test.js      The reaction/target test itself
│   │   ├── recommendation.js     Calls /analyze then /recommend
│   │   ├── results.js            Renders the results screen
│   │   └── share.js              Web Share API + clipboard fallback
│   ├── env.js                    Local-dev runtime config (safe defaults)
│   └── env.template.js           Template for generating production env.js
└── render.yaml                   Render deployment blueprint
```

## Database schema

```
devices(id, brand, model, display_refresh_rate_hz, touch_sampling_rate_hz,
        screen_resolution, dpi_min, dpi_max, sensitivity_profile, notes,
        data_source_status)

games(id, name, version, sensitivity_min, sensitivity_max,
      supported_settings [json], control_profile, notes)

settings_profiles(id, game_id, tier, general, red_dot, scope_2x, scope_4x, sniper)
  -- reserved for future curated per-game profile presets

test_results(id, anonymous_session_id, device_id, game_id,
             average_reaction_time_ms, consistency_percent, created_at)
  -- reserved for Phase 2 (optional history); no personal data by design
```

## API

| Method | Path              | Purpose                                      |
|--------|-------------------|-----------------------------------------------|
| GET    | `/api/health`     | Liveness check                                 |
| GET    | `/api/devices`    | List devices (optional `?brand=` filter)       |
| GET    | `/api/devices/brands` | List distinct manufacturers                |
| GET    | `/api/devices/{id}`   | Get one device                             |
| GET    | `/api/games`      | List games                                     |
| GET    | `/api/games/{id}` | Get one game                                   |
| POST   | `/api/analyze`    | Turn raw reaction attempts into statistics     |
| POST   | `/api/recommend`  | Turn statistics into a settings recommendation |

## Recommendation algorithm (summary)

1. The reaction test measures time-to-tap for 8 targets using `performance.now()`.
2. `/api/analyze` computes average, fastest, slowest, and a consistency score
   (100% − coefficient of variation, clamped to [0, 100]).
3. `/api/recommend` picks one of three named, documented profiles —
   **Responsive**, **Balanced**, or **Controlled** — based on reaction speed
   and consistency, applies a small (≤6%) hardware-capability adjustment for
   high-refresh/high-touch-sampling devices, then scales every value against
   the *selected game's own* sensitivity range.
4. No value is ever randomized. The same inputs always produce the same
   output (see `backend/app/tests/test_recommendation_service.py`).

## Running locally

### Backend

```bash
cd backend
python -m venv .venv && source .venv/bin/activate   # optional but recommended
pip install -r requirements.txt
cp .env.example .env
uvicorn app.main:app --reload --port 8000
```

The API will be available at `http://localhost:8000` (interactive docs at
`/docs` outside production mode). SQLite auto-seeds from the JSON datasets
on first run.

### Frontend

The frontend is static — no build step needed for local development:

```bash
cd frontend
python -m http.server 5173
```

Then open `http://localhost:5173`. It talks to the API via
`frontend/env.js`, which already points at `http://localhost:8000`.

### Tests

```bash
cd backend
pytest
```

## Deploying to Render

`render.yaml` describes two services:

1. **`smart-headshot-engine-api`** — a Docker web service built from
   `backend/Dockerfile`, with a health check on `/api/health`.
2. **`smart-headshot-engine-frontend`** — a static site that regenerates
   `env.js` from `env.template.js` at build time so it points at the deployed
   API URL, with feature flags controlled by environment variables.

Steps:

1. Push this repository to GitHub/GitLab.
2. In Render, choose **New → Blueprint** and point it at the repo — it will
   read `render.yaml` and provision both services.
3. Update `ALLOWED_ORIGINS` on the API service and `API_URL` on the frontend
   service to match your actual deployed URLs.
4. Deploy.

## Configuration (environment variables)

| Variable | Where | Purpose |
|---|---|---|
| `APP_ENV` | backend | `development` / `production` |
| `ALLOWED_ORIGINS` | backend | Comma-separated list of allowed CORS origins |
| `DATABASE_URL` | backend | SQLite path today; swap for a PostgreSQL URL later |
| `ADS_ENABLED` | both | Toggles ad slot rendering (off by default) |
| `ANALYTICS_ENABLED` | both | Toggles anonymous event logging (off by default) |
| `AFFILIATE_ENABLED` | backend | Reserved for future affiliate link injection |
| `RATE_LIMIT_PER_MINUTE` | backend | Per-IP API rate limit |
| `API_URL` | frontend | Base URL the frontend calls |

No secrets are hard-coded anywhere in the codebase; see `.env.example` files.

## Roadmap (architecture-ready, not implemented in v1)

Phase 2: optional accounts, saved history, an advanced aim trainer.
Phase 3: personalized engine, player profiles, leaderboards.
Phase 4: ML-assisted recommendations once enough reliable data exists.
Phase 5: PWA/mobile app, public API, creator dashboards.

The repository layer, JSON-driven datasets, and modular JS/service structure
exist specifically so these phases don't require rewriting the application.

## Known v1 limitations

- Ad slots and affiliate links are wired but disabled by default and contain
  no real ad code or real affiliate URLs (placeholders only), per the
  no-dark-patterns requirement.
- Device specs marked `verified_spec_unverified_touch` in `devices.json`
  intentionally omit touch-sampling-rate figures that aren't publicly
  confirmed by the manufacturer, rather than inventing a number.
- The in-memory rate limiter is per-instance; a horizontally scaled
  deployment should move it to a shared store (e.g. Redis).
