# Digital Chittilu — Simple HTML/CSS/JS

A mobile-first Chittilu management app built with only:
- HTML
- CSS
- Vanilla JavaScript
- Browser localStorage

## Run
Open `index.html` in a browser.

For a smoother local development experience, use any simple static server. No Node.js, React, database, or backend is required.

## APK conversion
This structure is suitable for a WebView/PWA/wrapper approach because it uses standard web files and touch-friendly UI.

## Important V1 behavior
- Multiple Chittilus
- Separate data per Chittilu
- Configurable members, amount, and duration
- Explicit Mark Paid / Mark Pending buttons
- Confirmation before payment changes
- Full monthly collection required before recipient selection
- Manual or random eligible-member selection
- One recipient per month
- One recipient per member per Chittilu
- Schedule and history
- Confirmation before deletion
- LocalStorage persistence
- Mobile-first 360–430px layout

## Note
The first version intentionally keeps the data local to the device/browser. Before using it as a real financial record system, add a backend/database, authentication, backup/export, and stronger server-side business-rule enforcement.
