
  # HealMate Health App

  This is a code bundle for HealMate Health App. The original project is available at https://www.figma.com/design/pUxot1V7wNqDbDu43e35Kp/HealMate-Health-App.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  