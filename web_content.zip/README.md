# A.L.E.X. — JavaScript
Assistente de Lembretes e Execução.

A versão foi convertida de Python/Kivy para HTML + CSS + JavaScript.
As tarefas ficam salvas no armazenamento local do aparelho.

IMPORTANTE: a versão web/PWA usa as notificações do navegador. Para um APK Android com notificações locais confiáveis mesmo com o app fechado, a próxima etapa é empacotar este projeto com Capacitor e o plugin de notificações locais.
