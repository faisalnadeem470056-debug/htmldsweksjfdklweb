# TALLENTEX 2027 — Class 9

Premium offline syllabus progress tracker. No account, backend, ads, tests, quizzes, or internet dependency.

## Convert this ZIP to an APK
The ZIP is deliberately structured with `index.html` at the root of the web bundle. Upload the **web/** folder as a ZIP to an HTML/ZIP-to-APK builder, choose:
- App name: `TALLENTEX 2027`
- Package ID: `com.tallentex.tracker`
- Orientation: Portrait
- Internet/network permissions: none required
- Local/offline assets: enabled

The app stores name, theme, onboarding state, and topic completion in localStorage.
