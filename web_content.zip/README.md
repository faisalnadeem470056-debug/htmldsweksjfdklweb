# ArquivoParaAPK

Projeto web estático preparado para ser compactado em ZIP e enviado a um serviço online de conversão HTML → APK.

## Arquivos obrigatórios

- `index.html` — página principal.
- `style.css` — estilos responsivos.
- `app.js` — JavaScript funcional.
- `icon.png` — ícone do projeto e favicon.
- `README.md` — estas instruções.

## Estrutura correta

Todos os cinco arquivos devem ficar diretamente na raiz do ZIP:

```text
ArquivoParaAPK-Web/
├── index.html
├── style.css
├── app.js
├── icon.png
└── README.md
```

Ao abrir o ZIP, o `index.html` deve aparecer imediatamente na raiz. Não coloque esses arquivos dentro de uma pasta `site`, `app`, `src` ou qualquer outra pasta adicional.

## Como compactar

Selecione `index.html`, `style.css`, `app.js`, `icon.png` e `README.md` e compacte esses arquivos diretamente. O ZIP final pode se chamar:

`ArquivoParaAPK-Web.zip`

## Ícone

O arquivo `icon.png` já deve estar na raiz e é usado pelo `index.html` como favicon.

Conceito do ícone: caixa azul, documento HTML saindo da caixa, símbolo `</>`, indicação APK e seta verde de conversão/exportação, com aparência moderna e fundo azul escuro.

## Funcionamento offline

A página inicial não depende de CDN, servidor, PHP, Node.js, banco de dados ou backend. Os recursos da página são locais e os caminhos usados são relativos:

- `style.css`
- `app.js`
- `icon.png`

## Compatibilidade

A interface utiliza HTML, CSS e JavaScript padrão e foi feita para funcionar em telas pequenas e grandes, sem rolagem horizontal intencional.

## Teste

Abra `index.html` no navegador. Toque em **Testar aplicativo**. A interface deve mostrar:

`✅ Aplicativo funcionando corretamente.`

## Observação sobre HTML → APK

O conversor escolhido precisa aceitar um ZIP/site estático com `index.html` na raiz. O projeto em si não contém Android Studio, Gradle, Android SDK, Termux, PHP, Node.js ou backend.
