# NPL — Noapur Premier League

Static HTML/CSS/JavaScript website prepared for Netlify deployment.

## Included in this build
- Light, glassy responsive design with mobile-first 3-dot menu.
- Desktop navigation: Home, Season, Announcement, Jerseys.
- Home-only animated 3D Season 30 element.
- Bangladesh live clock at the bottom of the Home page.
- Search modal with immediate suggestions while typing; no player-name “Try…” placeholder.
- Season 30 + older season archive cards with “Memories Updating Soon” states.
- NPL Achievements page with the Daily Cricket Facebook post link.
- Player directory with Sami, Rahad and Murad; ratings, jersey numbers, photos and profiles.
- Player photo lightbox and local Follow Player system.
- Local Create your account form: NPL Jersey Name and NPL Jersey Number only.
- Comments and complaints routed to the existing WhatsApp number.
- Jerseys/Gallery page with photo-selection flow.

## Important static-site note
Account data and follows are stored in the visitor's browser using localStorage. This keeps them on the same device/browser, but it is not server authentication and cannot sync across devices without a backend.

## Netlify
Upload the contents of this folder (or the ZIP root folder) as a static site. No build command is required.

- Latest polish: more-glassy animated navigation with active state; Jerseys page is a dedicated coming-soon page (no gallery); jersey registration includes a clear pre-registration notice.
