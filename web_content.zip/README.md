# Surger Android wrapper

This project packages the supplied Surger Phase 1 HTML shell inside a native Android WebView so the app loads from local bundled assets instead of depending on a downloaded HTML file.

## What was fixed
- Complete `surger.html` reconstructed from the supplied transfer document (the original Markdown fence interrupted the source near the Forge JSON cleanup code).
- Removed the remote Google Fonts dependency so the core shell is self-contained in the APK.
- Added native Android text-to-speech bridge.
- Added native Android speech-recognition bridge with microphone permission request.
- Added Android file chooser support for upload-style HTML file inputs.
- Added Android download-link handling through the system browser/app chooser.
- Kept the source's explicit capability walls: the current device-radio controls remain stubs; this wrapper does not silently change Wi-Fi, Bluetooth, hotspot, DND, SIM state, PINs, or the Android OS.
- WebView DOM storage is enabled so Surger's local Memory state can persist between launches.

## Important behavior
Opening an APK from Downloads still goes through Android's normal package installer and security checks. A normal app cannot silently install or replace itself.

After installation, opening **Surger** loads the bundled `surger.html` automatically. No separate HTML file is required.

## Build
Open this folder in Android Studio and build the `app` module. The environment used to prepare this package does not contain the Android SDK, so an APK could not be compiled here.

## Exact diagnosis

The previous file supplied to the phone was a **ZIP project archive**, not an `.apk`. That is why it did not show up as an installable Android app. Android's package installer requires an APK (or an app bundle delivered through a supported store/install flow); a ZIP containing Java/HTML source is not an application package.

Use the actual `app-debug.apk` produced by the Android build. The project also contains a GitHub Actions workflow so the APK can be built on a cloud runner without installing the Android SDK locally.
