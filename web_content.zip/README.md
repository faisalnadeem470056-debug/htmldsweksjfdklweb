# B-Tourisek Tourism ERP/CRM — Production Starter v2

## Company identity
- **B-Touristic / BTouristic**
- **Owner & Founder:** الأستاذ محمد موسي
- **Address:** مصر - الجيزة
- **Email:** mohamed.moussa@btouristic.com
- **Phones:** 01148535084 / 01099091108 / 01010223978
- **Website:** btouristic.com

## Owner access
The requested initial/demo PIN is **012012**. It is used only to bootstrap the first owner account. Change it immediately through `POST /api/owner/change-pin` or the future production settings screen before exposing the server publicly.

## Architecture
- Node.js 20+
- PostgreSQL 16
- Native HTTP API + `pg`
- DB-backed sessions with hashed session tokens
- Scrypt password/PIN hashing
- Role-based access control (RBAC)
- Audit log
- JSONB record layer for the business modules, ready for later normalization
- Knowledge base table + PostgreSQL full-text retrieval for RAG
- AI Gateway using an OpenAI-compatible `/chat/completions` endpoint
- 27 Egyptian governorates
- Existing B-Tourisek UI retained in `public/`

## Production modules
CRM, bookings, packages, leads, communications, complaints, quotes, procurement, hotels, suppliers, employees, transactions, campaigns and tasks.

## Run with Docker
1. Copy `.env.example` to `.env` and replace secrets.
2. Run `docker compose up --build`.
3. Open `http://localhost:8787`.

The included compose file is a starter. For real deployment use a managed PostgreSQL service, HTTPS reverse proxy, secret manager, backups, monitoring and restricted network exposure.

## Run without Docker
Requires PostgreSQL and Node.js 20+.

```bash
npm install
# set DATABASE_URL, SESSION_SECRET and OWNER_INITIAL_PIN
npm start
```

## AI
Set:
- `AI_API_KEY`
- `AI_BASE_URL` (default: `https://api.openai.com/v1`)
- `AI_MODEL`

The `/api/ai/ask` endpoint retrieves relevant knowledge documents from PostgreSQL and supplies company KPIs/context to the model. Without an API key it returns a safe local-mode response rather than pretending an LLM is active.

## Important data policy
Do **not** represent demo hotel inventory, prices, availability, flight inventory or supplier data as live. Live booking requires authorized hotel/channel-manager and GDS/NDC providers. Payment and WhatsApp integrations also require provider credentials and approved business accounts.
