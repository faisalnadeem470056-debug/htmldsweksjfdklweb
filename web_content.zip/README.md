# Belote Android

Application Android basée sur le fichier `belote.html` fourni. Elle fonctionne hors ligne, avec écran de démarrage, icône et WebView.

## Compilation
Ouvrir ce dossier dans Android Studio puis lancer **Build > Build APK(s)**.

Le projet utilise Android Gradle Plugin 8.7.3, compileSdk 35, minSdk 23.
