# Duelo: Adivina el Número — Android

Este proyecto envuelve el HTML original en un WebView para crear una aplicación Android offline.

## Abrir en Android Studio
1. Abre esta carpeta como proyecto en Android Studio.
2. Espera a que Gradle sincronice.
3. Ve a **Build > Build App Bundle(s) / APK(s) > Build APK(s)**.
4. El APK de depuración quedará normalmente en:
   `app/build/outputs/apk/debug/app-debug.apk`

## Desde terminal
Con Gradle instalado:
`gradle assembleDebug`

## Nota
El juego original está en:
`app/src/main/assets/index.html`

No necesita Internet para ejecutar la lógica del juego.
