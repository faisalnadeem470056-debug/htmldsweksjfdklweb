# SportsHub

Site responsivo de central esportiva inspirado na experiência de apps como OneFootball, mas com identidade própria e vários esportes.

## O que já está funcionando
- Home personalizada
- Favoritos salvos no navegador
- Futebol, basquete, tênis, F1, CS2, VALORANT, vôlei, NFL, MMA e golfe
- Próximos eventos e cartões de partidas
- Notícias de demonstração
- Tabela de campeonato de demonstração
- Busca
- Página de favoritos
- Configurações e notificações simuladas
- Endpoint seguro para IA usando Groq (a chave fica no servidor)
- Layout responsivo para celular

## Importante
Os jogos, notícias e classificações incluídos no frontend são dados de demonstração. Para dados reais/ao vivo, conecte uma API esportiva no backend e substitua os arrays em `app.js`.

## Publicar na Vercel
1. Envie esta pasta para um repositório no GitHub.
2. Entre na Vercel e importe o repositório.
3. Não é necessário build command: é um site estático com uma Serverless Function.
4. Em Settings > Environment Variables, crie `GROQ_API_KEY` com sua chave.
5. Faça redeploy.

## Rodar localmente
É possível abrir `index.html` diretamente para testar o frontend. Para testar a função Groq, use um ambiente que execute a função `/api/groq` (como Vercel).
