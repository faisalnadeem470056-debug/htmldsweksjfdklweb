@echo off
setlocal
if not exist node_modules echo Please run: npm install
if not exist .env copy .env.example .env
node server.js
pause
