function checkIP() {

    const ip = document.getElementById("ip").value.trim();
    const result = document.getElementById("ipResult");

    if (!isValidIP(ip)) {

        result.innerHTML = `
            <div class="result-box">
                <h2>❌ IP Tidak Valid</h2>
                <p>Masukkan IPv4 yang benar.</p>
            </div>
        `;

        return;
    }

    const parts = ip.split(".").map(Number);
    const first = parts[0];

    let ipClass;

    if (first >= 1 && first <= 126) {
        ipClass = "A";
    } else if (first >= 128 && first <= 191) {
        ipClass = "B";
    } else if (first >= 192 && first <= 223) {
        ipClass = "C";
    } else if (first >= 224 && first <= 239) {
        ipClass = "D";
    } else if (first >= 240 && first <= 255) {
        ipClass = "E";
    } else {
        ipClass = "Khusus";
    }


    let type;

    if (
        parts[0] === 10 ||
        (
            parts[0] === 172 &&
            parts[1] >= 16 &&
            parts[1] <= 31
        ) ||
        (
            parts[0] === 192 &&
            parts[1] === 168
        )
    ) {

        type = "Private IP";

    } else {

        type = "Public / Special IP";

    }


    let subnet;

    if (ipClass === "A") {

        subnet = "255.0.0.0 (/8)";

    } else if (ipClass === "B") {

        subnet = "255.255.0.0 (/16)";

    } else if (ipClass === "C") {

        subnet = "255.255.255.0 (/24)";

    } else {

        subnet = "Tidak ada default mask";

    }


    result.innerHTML = `
        <div class="result-box">

            <h2>Hasil IP</h2>

            <p>
                <b>IP Address:</b> ${ip}
            </p>

            <p>
                <b>Versi:</b> IPv4
            </p>

            <p>
                <b>Class:</b> ${ipClass}
            </p>

            <p>
                <b>Tipe:</b> ${type}
            </p>

            <p>
                <b>Default Subnet Mask:</b> ${subnet}
            </p>

        </div>
    `;
}


function checkMAC() {

    const mac = document.getElementById("mac").value.trim();
    const result = document.getElementById("macResult");

    const macPattern =
        /^([0-9A-Fa-f]{2}[:-]){5}([0-9A-Fa-f]{2})$/;


    if (!macPattern.test(mac)) {

        result.innerHTML = `
            <div class="result-box">
                <h2>❌ MAC Tidak Valid</h2>
                <p>
                    Format contoh:
                    00:1A:2B:3C:4D:5E
                </p>
            </div>
        `;

        return;
    }


    result.innerHTML = `
        <div class="result-box">

            <h2>✅ MAC Valid</h2>

            <p>
                <b>MAC Address:</b> ${mac}
            </p>

            <p>
                Format MAC Address sudah benar.
            </p>

        </div>
    `;
}


function checkPort() {

    const port = Number(
        document.getElementById("port").value
    );

    const result = document.getElementById("portResult");


    const ports = {

        21: "FTP",
        22: "SSH",
        23: "Telnet",
        25: "SMTP",
        53: "DNS",
        67: "DHCP Server",
        68: "DHCP Client",
        80: "HTTP",
        110: "POP3",
        143: "IMAP",
        443: "HTTPS"

    };


    if (
        !Number.isInteger(port) ||
        port < 1 ||
        port > 65535
    ) {

        result.innerHTML = `
            <div class="result-box">
                <h2>❌ Port Tidak Valid</h2>
                <p>
                    Port harus berada antara 1 sampai 65535.
                </p>
            </div>
        `;

        return;
    }


    if (ports[port]) {

        result.innerHTML = `
            <div class="result-box">

                <h2>Port ${port}</h2>

                <p>
                    <b>Service:</b>
                    ${ports[port]}
                </p>

            </div>
        `;

    } else {

        result.innerHTML = `
            <div class="result-box">

                <h2>Port ${port}</h2>

                <p>
                    Port valid, tetapi belum ada
                    dalam daftar referensi.
                </p>

            </div>
        `;

    }
}


function isValidIP(ip) {

    const parts = ip.split(".");

    if (parts.length !== 4) {
        return false;
    }

    return parts.every(function(part) {

        const number = Number(part);

        return (
            part !== "" &&
            Number.isInteger(number) &&
            number >= 0 &&
            number <= 255
        );

    });
}