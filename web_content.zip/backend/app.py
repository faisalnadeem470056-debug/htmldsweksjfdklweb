from fastapi import FastAPI, UploadFile, File, HTTPException
from fastapi.responses import FileResponse, JSONResponse
import os, re, shutil, subprocess, tempfile, zipfile, pathlib
from converter import build_input

app = FastAPI(title="لعبة الحية Build Server", version="1.0.0")
MAX_UPLOAD = 200 * 1024 * 1024

@app.get("/api/health")
def health():
    return {"status":"ok", "service":"l3bat-alhayya-build-server"}

@app.post("/api/build")
async def build(file: UploadFile = File(...), app_name: str = "تطبيقي", package_name: str = "com.example.generatedapp"):
    if not re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*(?:\.[A-Za-z_][A-Za-z0-9_]*)+", package_name):
        raise HTTPException(400, "Invalid package name")
    app_name = (app_name or "تطبيقي").strip()[:60]
    suffix = pathlib.Path(file.filename or "input.bin").suffix.lower()
    with tempfile.TemporaryDirectory(prefix="l3bat_build_") as td:
        input_path = os.path.join(td, "input" + suffix)
        size = 0
        with open(input_path, "wb") as out:
            while True:
                chunk = await file.read(1024 * 1024)
                if not chunk: break
                size += len(chunk)
                if size > MAX_UPLOAD:
                    raise HTTPException(413, "File too large")
                out.write(chunk)
        try:
            apk = build_input(input_path, file.filename or "input.bin", app_name, package_name, td)
        except subprocess.CalledProcessError as e:
            raise HTTPException(500, (e.stdout or e.stderr or str(e))[-8000:])
        except Exception as e:
            raise HTTPException(500, str(e))
        return FileResponse(apk, media_type="application/vnd.android.package-archive", filename=re.sub(r"[^A-Za-z0-9._-]+", "_", app_name) + ".apk")
