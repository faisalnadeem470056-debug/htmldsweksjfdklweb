"""
Centralized application configuration.
All values are read from environment variables so no secrets or
environment-specific values are hard-coded in the codebase.
"""
import os
from functools import lru_cache


def _bool_env(name: str, default: str = "false") -> bool:
    return os.getenv(name, default).strip().lower() in {"1", "true", "yes", "on"}


class Settings:
    # General
    APP_ENV: str = os.getenv("APP_ENV", "development")
    APP_NAME: str = "Smart Headshot Engine"

    # CORS - comma separated list of allowed origins
    ALLOWED_ORIGINS: list[str] = [
        origin.strip()
        for origin in os.getenv("ALLOWED_ORIGINS", "http://localhost:5173,http://localhost:8000").split(",")
        if origin.strip()
    ]

    # Database
    DATABASE_URL: str = os.getenv("DATABASE_URL", "sqlite:///./data/app.db")

    # Feature flags
    ADS_ENABLED: bool = _bool_env("ADS_ENABLED", "false")
    ANALYTICS_ENABLED: bool = _bool_env("ANALYTICS_ENABLED", "false")
    AFFILIATE_ENABLED: bool = _bool_env("AFFILIATE_ENABLED", "false")

    # Rate limiting
    RATE_LIMIT_PER_MINUTE: int = int(os.getenv("RATE_LIMIT_PER_MINUTE", "60"))

    # Misc
    API_URL: str = os.getenv("API_URL", "http://localhost:8000")


@lru_cache
def get_settings() -> Settings:
    return Settings()
