from fastapi import APIRouter, HTTPException, Query

from app.repositories.device_repository import DeviceRepository
from app.repositories.game_repository import GameRepository
from app.schemas.schemas import (
    AnalyzeRequest,
    AnalyzeResult,
    Device,
    Game,
    RecommendRequest,
    RecommendResult,
)
from app.services.analysis_service import analyze_attempts
from app.services.recommendation_service import build_recommendation

router = APIRouter(prefix="/api")

device_repo = DeviceRepository()
game_repo = GameRepository()


@router.get("/health")
def health_check():
    return {"status": "ok", "service": "smart-headshot-engine-api"}


@router.get("/devices", response_model=list[Device])
def get_devices(brand: str | None = Query(default=None, description="Filter by manufacturer")):
    return device_repo.list_all(brand=brand)


@router.get("/devices/brands", response_model=list[str])
def get_device_brands():
    return device_repo.list_brands()


@router.get("/devices/{device_id}", response_model=Device)
def get_device(device_id: str):
    device = device_repo.get_by_id(device_id)
    if not device:
        raise HTTPException(status_code=404, detail="Device not found")
    return device


@router.get("/games", response_model=list[Game])
def get_games():
    return game_repo.list_all()


@router.get("/games/{game_id}", response_model=Game)
def get_game(game_id: str):
    game = game_repo.get_by_id(game_id)
    if not game:
        raise HTTPException(status_code=404, detail="Game not found")
    return game


@router.post("/analyze", response_model=AnalyzeResult)
def analyze(payload: AnalyzeRequest):
    if not device_repo.get_by_id(payload.device_id):
        raise HTTPException(status_code=404, detail="Unknown device_id")
    if not game_repo.get_by_id(payload.game_id):
        raise HTTPException(status_code=404, detail="Unknown game_id")
    return analyze_attempts(payload.attempts)


@router.post("/recommend", response_model=RecommendResult)
def recommend(payload: RecommendRequest):
    device = device_repo.get_by_id(payload.device_id)
    if not device:
        raise HTTPException(status_code=404, detail="Unknown device_id")
    game = game_repo.get_by_id(payload.game_id)
    if not game:
        raise HTTPException(status_code=404, detail="Unknown game_id")
    return build_recommendation(
        device=device,
        game=game,
        average_reaction_time_ms=payload.average_reaction_time_ms,
        consistency_percent=payload.consistency_percent,
    )
