import pytest
from fastapi.testclient import TestClient

from app.main import app


@pytest.fixture(scope="module")
def client():
    with TestClient(app) as c:
        yield c


def test_health_check(client):
    response = client.get("/api/health")
    assert response.status_code == 200
    assert response.json()["status"] == "ok"


def test_list_devices(client):
    response = client.get("/api/devices")
    assert response.status_code == 200
    assert len(response.json()) > 0


def test_get_device_not_found(client):
    response = client.get("/api/devices/does-not-exist")
    assert response.status_code == 404


def test_list_games(client):
    response = client.get("/api/games")
    assert response.status_code == 200
    assert any(g["id"] == "free-fire" for g in response.json())


def test_analyze_with_unknown_device_returns_404(client):
    response = client.post(
        "/api/analyze",
        json={
            "device_id": "unknown",
            "game_id": "free-fire",
            "attempts": [{"reaction_time_ms": 220}, {"reaction_time_ms": 240}, {"reaction_time_ms": 260}],
        },
    )
    assert response.status_code == 404


def test_analyze_rejects_too_few_attempts(client):
    response = client.post(
        "/api/analyze",
        json={
            "device_id": "apple-iphone-13",
            "game_id": "free-fire",
            "attempts": [{"reaction_time_ms": 220}],
        },
    )
    assert response.status_code == 422


def test_recommend_end_to_end(client):
    response = client.post(
        "/api/recommend",
        json={
            "device_id": "apple-iphone-13",
            "game_id": "free-fire",
            "average_reaction_time_ms": 230,
            "consistency_percent": 85,
        },
    )
    assert response.status_code == 200
    body = response.json()
    assert "settings" in body
    assert body["settings"]["general"] <= 100
