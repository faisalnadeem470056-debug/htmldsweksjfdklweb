from app.schemas.schemas import Device, DpiRange, Game, SensitivityScale
from app.services.recommendation_service import build_recommendation

_DEVICE = Device(
    id="test-device",
    brand="TestBrand",
    model="TestModel",
    display_refresh_rate_hz=120,
    touch_sampling_rate_hz=240,
    screen_resolution="1080x2400",
    recommended_dpi_range=DpiRange(min=400, max=480),
    sensitivity_profile="high_refresh",
    notes=None,
    data_source_status="verified",
)

_GAME = Game(
    id="test-game",
    name="Test Game",
    version="1.0",
    sensitivity_scale=SensitivityScale(min=0, max=100),
    supported_settings=["general", "red_dot", "2x", "4x", "sniper"],
    control_profile="arcade",
    notes=None,
)


def test_fast_and_consistent_yields_responsive_profile():
    result = build_recommendation(_DEVICE, _GAME, average_reaction_time_ms=220, consistency_percent=90)
    assert result.profile_label == "Responsive"
    assert result.settings.general > 70


def test_average_reaction_yields_balanced_profile():
    result = build_recommendation(_DEVICE, _GAME, average_reaction_time_ms=300, consistency_percent=75)
    assert result.profile_label == "Balanced"


def test_slow_reaction_yields_controlled_profile():
    result = build_recommendation(_DEVICE, _GAME, average_reaction_time_ms=420, consistency_percent=60)
    assert result.profile_label == "Controlled"
    assert result.settings.general < 70


def test_low_consistency_pulls_fast_reaction_toward_balanced():
    result = build_recommendation(_DEVICE, _GAME, average_reaction_time_ms=220, consistency_percent=30)
    assert result.profile_label == "Balanced"


def test_settings_never_exceed_game_scale():
    result = build_recommendation(_DEVICE, _GAME, average_reaction_time_ms=200, consistency_percent=100)
    for value in [result.settings.general, result.settings.red_dot, result.settings.scope_2x, result.settings.scope_4x]:
        assert 1 <= value <= _GAME.sensitivity_scale.max


def test_sniper_omitted_when_unsupported():
    game_without_sniper = _GAME.model_copy(update={"supported_settings": ["general", "red_dot"]})
    result = build_recommendation(_DEVICE, game_without_sniper, average_reaction_time_ms=220, consistency_percent=90)
    assert result.settings.sniper is None


def test_recommendation_is_deterministic():
    result_a = build_recommendation(_DEVICE, _GAME, average_reaction_time_ms=250, consistency_percent=80)
    result_b = build_recommendation(_DEVICE, _GAME, average_reaction_time_ms=250, consistency_percent=80)
    assert result_a == result_b
