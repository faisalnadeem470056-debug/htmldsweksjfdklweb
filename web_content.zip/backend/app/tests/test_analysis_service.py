from app.schemas.schemas import ReactionAttempt
from app.services.analysis_service import analyze_attempts


def _attempts(*times_ms):
    return [ReactionAttempt(reaction_time_ms=t) for t in times_ms]


def test_average_and_extremes_are_computed_correctly():
    result = analyze_attempts(_attempts(200, 220, 240, 260, 280))
    assert result.average_reaction_time_ms == 240.0
    assert result.fastest_reaction_time_ms == 200.0
    assert result.slowest_reaction_time_ms == 280.0


def test_perfectly_uniform_times_score_full_consistency():
    result = analyze_attempts(_attempts(200, 200, 200, 200))
    assert result.consistency_percent == 100.0


def test_erratic_times_score_lower_consistency():
    result = analyze_attempts(_attempts(150, 500, 180, 600))
    assert result.consistency_percent < 70.0


def test_performance_tier_thresholds():
    assert analyze_attempts(_attempts(200, 210, 220)).performance_tier == "Fast"
    assert analyze_attempts(_attempts(300, 310, 320)).performance_tier == "Average"
    assert analyze_attempts(_attempts(400, 420, 440)).performance_tier == "Controlled"


def test_reaction_attempt_rejects_implausible_values():
    import pytest
    from pydantic import ValidationError

    with pytest.raises(ValidationError):
        ReactionAttempt(reaction_time_ms=10)  # faster than humanly possible
