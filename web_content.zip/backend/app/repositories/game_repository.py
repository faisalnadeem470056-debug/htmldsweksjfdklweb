"""Game data access layer. Same pattern as DeviceRepository."""
import json
from pathlib import Path
from typing import Optional

from app.models.database import get_connection
from app.schemas.schemas import Game, SensitivityScale

_SEED_PATH = Path(__file__).resolve().parent.parent / "data" / "games.json"


class GameRepository:
    def seed_if_empty(self) -> None:
        with get_connection() as conn:
            count = conn.execute("SELECT COUNT(*) AS c FROM games").fetchone()["c"]
            if count > 0:
                return
            data = json.loads(_SEED_PATH.read_text(encoding="utf-8"))
            for g in data["games"]:
                conn.execute(
                    """
                    INSERT INTO games (
                        id, name, version, sensitivity_min, sensitivity_max,
                        supported_settings, control_profile, notes
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                    """,
                    (
                        g["id"],
                        g["name"],
                        g["version"],
                        g["sensitivity_scale"]["min"],
                        g["sensitivity_scale"]["max"],
                        json.dumps(g["supported_settings"]),
                        g["control_profile"],
                        g.get("notes"),
                    ),
                )

    def _row_to_game(self, row) -> Game:
        return Game(
            id=row["id"],
            name=row["name"],
            version=row["version"],
            sensitivity_scale=SensitivityScale(min=row["sensitivity_min"], max=row["sensitivity_max"]),
            supported_settings=json.loads(row["supported_settings"]),
            control_profile=row["control_profile"],
            notes=row["notes"],
        )

    def list_all(self) -> list[Game]:
        with get_connection() as conn:
            rows = conn.execute("SELECT * FROM games ORDER BY name").fetchall()
            return [self._row_to_game(r) for r in rows]

    def get_by_id(self, game_id: str) -> Optional[Game]:
        with get_connection() as conn:
            row = conn.execute("SELECT * FROM games WHERE id = ?", (game_id,)).fetchone()
            return self._row_to_game(row) if row else None
