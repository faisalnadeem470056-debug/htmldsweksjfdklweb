"""
Device data access layer.

Reads are served from SQLite (seeded once from the JSON dataset at startup).
Callers never touch SQL directly -- only this class does -- so the storage
engine can be swapped for PostgreSQL later without touching services or routes.
"""
import json
from pathlib import Path
from typing import Optional

from app.models.database import get_connection
from app.schemas.schemas import Device, DpiRange

_SEED_PATH = Path(__file__).resolve().parent.parent / "data" / "devices.json"


class DeviceRepository:
    def seed_if_empty(self) -> None:
        with get_connection() as conn:
            count = conn.execute("SELECT COUNT(*) AS c FROM devices").fetchone()["c"]
            if count > 0:
                return
            data = json.loads(_SEED_PATH.read_text(encoding="utf-8"))
            for d in data["devices"]:
                conn.execute(
                    """
                    INSERT INTO devices (
                        id, brand, model, display_refresh_rate_hz, touch_sampling_rate_hz,
                        screen_resolution, dpi_min, dpi_max, sensitivity_profile, notes,
                        data_source_status
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    """,
                    (
                        d["id"],
                        d["brand"],
                        d["model"],
                        d["display_refresh_rate_hz"],
                        d.get("touch_sampling_rate_hz"),
                        d["screen_resolution"],
                        d["recommended_dpi_range"]["min"],
                        d["recommended_dpi_range"]["max"],
                        d["sensitivity_profile"],
                        d.get("notes"),
                        d["data_source_status"],
                    ),
                )

    def _row_to_device(self, row) -> Device:
        return Device(
            id=row["id"],
            brand=row["brand"],
            model=row["model"],
            display_refresh_rate_hz=row["display_refresh_rate_hz"],
            touch_sampling_rate_hz=row["touch_sampling_rate_hz"],
            screen_resolution=row["screen_resolution"],
            recommended_dpi_range=DpiRange(min=row["dpi_min"], max=row["dpi_max"]),
            sensitivity_profile=row["sensitivity_profile"],
            notes=row["notes"],
            data_source_status=row["data_source_status"],
        )

    def list_all(self, brand: Optional[str] = None) -> list[Device]:
        with get_connection() as conn:
            if brand:
                rows = conn.execute(
                    "SELECT * FROM devices WHERE brand = ? ORDER BY model", (brand,)
                ).fetchall()
            else:
                rows = conn.execute("SELECT * FROM devices ORDER BY brand, model").fetchall()
            return [self._row_to_device(r) for r in rows]

    def get_by_id(self, device_id: str) -> Optional[Device]:
        with get_connection() as conn:
            row = conn.execute("SELECT * FROM devices WHERE id = ?", (device_id,)).fetchone()
            return self._row_to_device(row) if row else None

    def list_brands(self) -> list[str]:
        with get_connection() as conn:
            rows = conn.execute("SELECT DISTINCT brand FROM devices ORDER BY brand").fetchall()
            return [r["brand"] for r in rows]
