"""
Turns a raw list of reaction-time attempts into summary statistics.
No randomness anywhere in this module -- every output number is a direct
function of the input attempts.
"""
import statistics

from app.schemas.schemas import AnalyzeResult, ReactionAttempt

# Reaction time tiers, in milliseconds. These thresholds are a reasonable,
# commonly cited approximation of casual human visual reaction time bands,
# not a scientifically calibrated instrument.
_FAST_MS = 250
_AVERAGE_MS = 350


def _performance_tier(average_ms: float) -> str:
    if average_ms <= _FAST_MS:
        return "Fast"
    if average_ms <= _AVERAGE_MS:
        return "Average"
    return "Controlled"


def _consistency_percent(times: list[float]) -> float:
    """
    Consistency is expressed as 100% minus the coefficient of variation
    (stdev / mean), clamped to [0, 100]. Perfectly identical attempt times
    score 100%; highly erratic attempt times score closer to 0%.
    """
    if len(times) < 2:
        return 100.0
    mean = statistics.mean(times)
    if mean == 0:
        return 0.0
    stdev = statistics.pstdev(times)
    coefficient_of_variation = stdev / mean
    score = max(0.0, 100.0 - coefficient_of_variation * 100.0)
    return round(min(score, 100.0), 1)


def analyze_attempts(attempts: list[ReactionAttempt]) -> AnalyzeResult:
    times = [a.reaction_time_ms for a in attempts]
    average_ms = round(statistics.mean(times), 1)
    return AnalyzeResult(
        average_reaction_time_ms=average_ms,
        fastest_reaction_time_ms=round(min(times), 1),
        slowest_reaction_time_ms=round(max(times), 1),
        consistency_percent=_consistency_percent(times),
        performance_tier=_performance_tier(average_ms),
    )
