"""
Recommendation engine.

This is a deterministic, rule-based system -- not a machine-learning model
and not a scientific measurement of "the best" settings. Every number it
outputs can be traced back to: the player's reaction-time tier, their
consistency score, the device's refresh/touch profile, and the target
game's own sensitivity scale. Nothing here is randomized.

Design notes (documented so the "why" survives refactors):
- Faster + more consistent reactions -> a more responsive profile (higher
  sensitivity), since the player has demonstrated they can react quickly
  without the input feeling erratic.
- Slower or less consistent reactions -> a more controlled profile (lower
  sensitivity), which trades raw speed for steadier aim.
- A high-refresh / high-touch-sampling device gets a modest upward nudge,
  since the hardware can faithfully translate small, fast finger movements.
- Every value is expressed as a percentage of the *game's own* sensitivity
  scale, so PUBG's 0-200 scale and Free Fire's 0-100 scale both receive
  settings proportional to their own range instead of a shared magic number.
"""
from dataclasses import dataclass

from app.schemas.schemas import Device, Game, RecommendResult, SettingsProfile


@dataclass(frozen=True)
class _BaseProfile:
    """Values as a fraction (0-1) of the game's sensitivity scale."""
    label: str
    general: float
    red_dot: float
    scope_2x: float
    scope_4x: float
    sniper: float


# Reaction-time tiers reuse the same thresholds as the analysis service.
_FAST_MS = 250
_AVERAGE_MS = 350

_RESPONSIVE = _BaseProfile("Responsive", general=0.86, red_dot=0.78, scope_2x=0.70, scope_4x=0.62, sniper=0.50)
_BALANCED = _BaseProfile("Balanced", general=0.72, red_dot=0.64, scope_2x=0.56, scope_4x=0.48, sniper=0.40)
_CONTROLLED = _BaseProfile("Controlled", general=0.58, red_dot=0.50, scope_2x=0.44, scope_4x=0.36, sniper=0.30)


def _select_base_profile(average_reaction_time_ms: float, consistency_percent: float) -> _BaseProfile:
    # Consistency below 55% pulls the profile one step toward "controlled"
    # regardless of raw speed, since erratic input is harder to build on.
    penalize_for_inconsistency = consistency_percent < 55.0

    if average_reaction_time_ms <= _FAST_MS and not penalize_for_inconsistency:
        return _RESPONSIVE
    if average_reaction_time_ms <= _AVERAGE_MS or (average_reaction_time_ms <= _FAST_MS and penalize_for_inconsistency):
        return _BALANCED
    return _CONTROLLED


def _device_multiplier(device: Device) -> float:
    """Small, bounded nudge based on hardware capability. Never exceeds +/-6%."""
    multiplier = 1.0
    if device.display_refresh_rate_hz >= 120:
        multiplier += 0.03
    if device.touch_sampling_rate_hz and device.touch_sampling_rate_hz >= 240:
        multiplier += 0.03
    return min(multiplier, 1.06)


def _scale(fraction: float, scale_max: int, multiplier: float) -> int:
    value = fraction * multiplier * scale_max
    return max(1, min(scale_max, round(value)))


def build_recommendation(device: Device, game: Game, average_reaction_time_ms: float, consistency_percent: float) -> RecommendResult:
    base = _select_base_profile(average_reaction_time_ms, consistency_percent)
    multiplier = _device_multiplier(device)
    scale_max = game.sensitivity_scale.max

    sniper_value = None
    if "sniper" in game.supported_settings:
        sniper_value = _scale(base.sniper, scale_max, multiplier)

    settings = SettingsProfile(
        general=_scale(base.general, scale_max, multiplier),
        red_dot=_scale(base.red_dot, scale_max, multiplier),
        scope_2x=_scale(base.scope_2x, scale_max, multiplier),
        scope_4x=_scale(base.scope_4x, scale_max, multiplier),
        sniper=sniper_value,
        dpi_min=device.recommended_dpi_range.min,
        dpi_max=device.recommended_dpi_range.max,
    )

    return RecommendResult(profile_label=base.label, settings=settings)
