"""
Minimal SQLite connection layer.

Kept intentionally thin: the repository classes in app/repositories are the
only code that talks to this module, so swapping SQLite for PostgreSQL later
means rewriting this file and the repositories' internals only -- the rest
of the application (services, API routes) is unaffected.
"""
import sqlite3
from contextlib import contextmanager
from pathlib import Path

from app.config import get_settings

settings = get_settings()

_DB_PATH = Path(__file__).resolve().parent.parent / "data" / "app.db"


def _connect() -> sqlite3.Connection:
    _DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(_DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


@contextmanager
def get_connection():
    conn = _connect()
    try:
        yield conn
        conn.commit()
    finally:
        conn.close()


def init_db() -> None:
    """Create tables if they do not already exist."""
    with get_connection() as conn:
        conn.executescript(
            """
            CREATE TABLE IF NOT EXISTS devices (
                id TEXT PRIMARY KEY,
                brand TEXT NOT NULL,
                model TEXT NOT NULL,
                display_refresh_rate_hz INTEGER NOT NULL,
                touch_sampling_rate_hz INTEGER,
                screen_resolution TEXT NOT NULL,
                dpi_min INTEGER NOT NULL,
                dpi_max INTEGER NOT NULL,
                sensitivity_profile TEXT NOT NULL,
                notes TEXT,
                data_source_status TEXT NOT NULL
            );

            CREATE TABLE IF NOT EXISTS games (
                id TEXT PRIMARY KEY,
                name TEXT NOT NULL,
                version TEXT NOT NULL,
                sensitivity_min INTEGER NOT NULL,
                sensitivity_max INTEGER NOT NULL,
                supported_settings TEXT NOT NULL,
                control_profile TEXT NOT NULL,
                notes TEXT
            );

            -- Reserved for Phase 2+. Anonymous by design: no personal data,
            -- no account identifiers required to write a row.
            CREATE TABLE IF NOT EXISTS test_results (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                anonymous_session_id TEXT NOT NULL,
                device_id TEXT NOT NULL,
                game_id TEXT NOT NULL,
                average_reaction_time_ms REAL NOT NULL,
                consistency_percent REAL NOT NULL,
                created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (device_id) REFERENCES devices (id),
                FOREIGN KEY (game_id) REFERENCES games (id)
            );

            CREATE TABLE IF NOT EXISTS settings_profiles (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                game_id TEXT NOT NULL,
                tier TEXT NOT NULL,
                general INTEGER NOT NULL,
                red_dot INTEGER NOT NULL,
                scope_2x INTEGER NOT NULL,
                scope_4x INTEGER NOT NULL,
                sniper INTEGER,
                FOREIGN KEY (game_id) REFERENCES games (id)
            );
            """
        )
