"""
Pydantic models used for request validation and response serialization.
Nothing from the frontend is trusted without passing through these models.
"""
from __future__ import annotations

from enum import Enum
from typing import Optional

from pydantic import BaseModel, Field, field_validator


# ---------------------------------------------------------------------------
# Devices
# ---------------------------------------------------------------------------

class DpiRange(BaseModel):
    min: int
    max: int


class Device(BaseModel):
    id: str
    brand: str
    model: str
    display_refresh_rate_hz: int
    touch_sampling_rate_hz: Optional[int] = None
    screen_resolution: str
    recommended_dpi_range: DpiRange
    sensitivity_profile: str
    notes: Optional[str] = None
    data_source_status: str


# ---------------------------------------------------------------------------
# Games
# ---------------------------------------------------------------------------

class SensitivityScale(BaseModel):
    min: int
    max: int


class Game(BaseModel):
    id: str
    name: str
    version: str
    sensitivity_scale: SensitivityScale
    supported_settings: list[str]
    control_profile: str
    notes: Optional[str] = None


# ---------------------------------------------------------------------------
# Reaction test analysis
# ---------------------------------------------------------------------------

class ReactionAttempt(BaseModel):
    """A single target hit, timed on the client with performance.now()."""
    reaction_time_ms: float = Field(..., ge=0, le=5000)

    @field_validator("reaction_time_ms")
    @classmethod
    def sanity_check(cls, value: float) -> float:
        # Reject physically implausible values instead of trusting the client blindly.
        if value < 50:
            raise ValueError("reaction_time_ms below plausible human reaction threshold")
        return value


class AnalyzeRequest(BaseModel):
    device_id: str
    game_id: str
    attempts: list[ReactionAttempt] = Field(..., min_length=3, max_length=20)


class AnalyzeResult(BaseModel):
    average_reaction_time_ms: float
    fastest_reaction_time_ms: float
    slowest_reaction_time_ms: float
    consistency_percent: float
    performance_tier: str


# ---------------------------------------------------------------------------
# Recommendation engine
# ---------------------------------------------------------------------------

class RecommendRequest(BaseModel):
    device_id: str
    game_id: str
    average_reaction_time_ms: float = Field(..., ge=50, le=5000)
    consistency_percent: float = Field(..., ge=0, le=100)


class SettingsProfile(BaseModel):
    general: int
    red_dot: int
    scope_2x: int
    scope_4x: int
    sniper: Optional[int] = None
    dpi_min: int
    dpi_max: int


class RecommendResult(BaseModel):
    profile_label: str
    settings: SettingsProfile
    disclaimer: str = (
        "This is a suggested starting point, not a guaranteed or scientifically "
        "verified best setting. Your ideal settings may vary with play style and preference."
    )
