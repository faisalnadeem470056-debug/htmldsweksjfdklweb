import logging

from fastapi import FastAPI, Request
from fastapi.exceptions import RequestValidationError
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

from app.api.middleware import RateLimitMiddleware, SecurityHeadersMiddleware
from app.api.routes import router as api_router
from app.config import get_settings
from app.models.database import init_db
from app.repositories.device_repository import DeviceRepository
from app.repositories.game_repository import GameRepository

settings = get_settings()

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("smart-headshot-engine")

app = FastAPI(
    title="Smart Headshot Engine API",
    description="Device- and reaction-based settings recommendation API for mobile gaming.",
    version="1.0.0",
    # Hide interactive docs in production to reduce surface area; keep them
    # available in development for convenience.
    docs_url="/docs" if settings.APP_ENV != "production" else None,
    redoc_url=None,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.ALLOWED_ORIGINS,
    allow_credentials=False,
    allow_methods=["GET", "POST"],
    allow_headers=["Content-Type"],
)
app.add_middleware(RateLimitMiddleware)
app.add_middleware(SecurityHeadersMiddleware)

app.include_router(api_router)


@app.exception_handler(RequestValidationError)
async def validation_exception_handler(request: Request, exc: RequestValidationError):
    # Never leak internal stack traces or raw exception payloads to clients.
    logger.warning("Validation error on %s: %s", request.url.path, exc.errors())
    return JSONResponse(
        status_code=422,
        content={"detail": "Invalid request data. Please check your input and try again."},
    )


@app.exception_handler(Exception)
async def unhandled_exception_handler(request: Request, exc: Exception):
    logger.exception("Unhandled error on %s", request.url.path)
    return JSONResponse(
        status_code=500,
        content={"detail": "An unexpected error occurred. Please try again later."},
    )


@app.on_event("startup")
def on_startup() -> None:
    init_db()
    DeviceRepository().seed_if_empty()
    GameRepository().seed_if_empty()
    logger.info("Smart Headshot Engine API started in '%s' mode.", settings.APP_ENV)
