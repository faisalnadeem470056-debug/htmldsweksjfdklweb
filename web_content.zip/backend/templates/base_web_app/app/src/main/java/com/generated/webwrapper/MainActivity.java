package com.generated.webwrapper;
import android.app.Activity;import android.os.Bundle;import android.webkit.WebSettings;import android.webkit.WebView;import android.webkit.WebViewClient;
public class MainActivity extends Activity { @Override public void onCreate(Bundle b){super.onCreate(b);setContentView(com.generated.webwrapper.R.layout.activity_main);WebView w=findViewById(com.generated.webwrapper.R.id.web);w.setWebViewClient(new WebViewClient());WebSettings s=w.getSettings();s.setJavaScriptEnabled(true);s.setDomStorageEnabled(true);w.loadUrl("file:///android_asset/web/index.html");}}
