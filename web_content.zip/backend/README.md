# Build Server

## Docker

```bash
docker compose up --build
```

Health check:

```text
GET http://localhost:8080/api/health
```

Build endpoint:

```text
POST /api/build?app_name=MyApp&package_name=com.example.myapp
multipart field: file
```

The generated APK is returned directly.

### Supported input modes

- Android Gradle ZIP → compile existing project.
- HTML → wrap as WebView application.
- ZIP containing `index.html` → wrap the complete web folder as WebView application.
- Other file types → package the source file into a real APK and expose save/share actions.
