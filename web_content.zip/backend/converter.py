import os, shutil, zipfile, tempfile, subprocess, pathlib, re

HERE = pathlib.Path(__file__).resolve().parent
TEMPLATES = HERE / "templates"

def safe_extract(zf: zipfile.ZipFile, dest: str):
    base = pathlib.Path(dest).resolve()
    for info in zf.infolist():
        name = pathlib.PurePosixPath(info.filename)
        if name.is_absolute() or ".." in name.parts:
            raise ValueError("Unsafe ZIP path")
        target = (base / pathlib.Path(*name.parts)).resolve()
        if base not in target.parents and target != base:
            raise ValueError("Unsafe ZIP path")
        if info.is_dir(): target.mkdir(parents=True, exist_ok=True)
        else:
            target.parent.mkdir(parents=True, exist_ok=True)
            with zf.open(info) as src, open(target, "wb") as dst: shutil.copyfileobj(src, dst)

def find_root_with(files, root):
    for p in pathlib.Path(root).rglob("*"):
        if p.is_dir() and all((p / f).exists() for f in files): return p
    return None

def run_gradle(project: pathlib.Path):
    gradlew = project / "gradlew"
    if gradlew.exists():
        gradlew.chmod(0o755)
        cmd = [str(gradlew), "assembleDebug", "--no-daemon", "--stacktrace"]
    else:
        cmd = ["gradle", "assembleDebug", "--no-daemon", "--stacktrace"]
    proc = subprocess.run(cmd, cwd=project, capture_output=True, text=True, timeout=900)
    if proc.returncode != 0: raise subprocess.CalledProcessError(proc.returncode, cmd, output=proc.stdout, stderr=proc.stderr)
    matches = list(project.rglob("app-debug.apk"))
    if not matches: matches = list(project.rglob("*-debug.apk"))
    if not matches: raise RuntimeError("Gradle completed but no debug APK was found")
    return str(matches[0])

def package_to_components(pkg): return pkg.split('.')

def write_base_template(template: str, dest: pathlib.Path, app_name: str, package: str):
    shutil.copytree(TEMPLATES / template, dest, dirs_exist_ok=True)
    components = package_to_components(package)
    pkg_dir = dest / "app/src/main/java" / pathlib.Path(*components)
    old_pkg = dest / "app/src/main/java/com/generated/webwrapper" if template == "base_web_app" else dest / "app/src/main/java/com/generated/filewrapper"
    old_main = old_pkg / "MainActivity.java"
    pkg_dir.mkdir(parents=True, exist_ok=True)
    text = old_main.read_text(encoding="utf-8").replace("com.generated.webwrapper" if template == "base_web_app" else "com.generated.filewrapper", package)
    old_main.unlink(); (pkg_dir / "MainActivity.java").write_text(text, encoding="utf-8")
    shutil.rmtree(old_pkg.parent / "webwrapper" if template == "base_web_app" else old_pkg.parent / "filewrapper", ignore_errors=True)
    manifest = dest / "app/src/main/AndroidManifest.xml"
    manifest.write_text(manifest.read_text(encoding="utf-8").replace("com.generated.webwrapper" if template == "base_web_app" else "com.generated.filewrapper", package), encoding="utf-8")
    gradle = dest / "app/build.gradle"
    
    g = gradle.read_text(encoding="utf-8").replace("com.generated.webwrapper" if template == "base_web_app" else "com.generated.filewrapper", package)
    gradle.write_text(g, encoding="utf-8")
    strings = dest / "app/src/main/res/values/strings.xml"
    strings.write_text(strings.read_text(encoding="utf-8").replace("Generated Web App" if template == "base_web_app" else "Generated File App", app_name.replace('&','&amp;')), encoding="utf-8")

def build_input(input_path, original_name, app_name, package, work_root):
    ext = pathlib.Path(original_name).suffix.lower()
    project = pathlib.Path(work_root) / "project"
    if ext == ".zip":
        unzip_dir = pathlib.Path(work_root) / "unzipped"
        unzip_dir.mkdir()
        with zipfile.ZipFile(input_path) as z: safe_extract(z, str(unzip_dir))
        android_root = find_root_with(["build.gradle"], unzip_dir) or find_root_with(["build.gradle.kts"], unzip_dir)
        if android_root:
            return run_gradle(android_root)
        index = next(iter(unzip_dir.rglob("index.html")), None)
        if index:
            write_base_template("base_web_app", project, app_name, package)
            web = project / "app/src/main/assets/web"
            shutil.copytree(unzip_dir, web, dirs_exist_ok=True)
            return run_gradle(project)
        # Non-web ZIP: embed safely as a ZIP asset.
        write_base_template("base_file_app", project, app_name, package)
        shutil.copy2(input_path, project / "app/src/main/assets/input_file")
        (project / "app/src/main/assets/file_name.txt").write_text(original_name, encoding="utf-8")
        return run_gradle(project)
    if ext in {".html", ".htm"}:
        write_base_template("base_web_app", project, app_name, package)
        web = project / "app/src/main/assets/web"; web.mkdir(parents=True)
        shutil.copy2(input_path, web / "index.html")
        return run_gradle(project)
    write_base_template("base_file_app", project, app_name, package)
    shutil.copy2(input_path, project / "app/src/main/assets/input_file")
    (project / "app/src/main/assets/file_name.txt").write_text(original_name, encoding="utf-8")
    return run_gradle(project)
