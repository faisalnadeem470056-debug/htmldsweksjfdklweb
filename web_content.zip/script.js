let toastTimer;
function showToast(message){const toast=document.getElementById('toast');toast.textContent=message;toast.classList.add('show');clearTimeout(toastTimer);toastTimer=setTimeout(()=>toast.classList.remove('show'),2200)}
function openPanel(title,text){document.getElementById('modal-title').textContent=title;document.getElementById('modal-text').textContent=text;document.getElementById('modal').classList.add('show')}
function closePanel(event){if(!event||event.target.id==='modal')document.getElementById('modal').classList.remove('show')}
function showPage(pageId,navId){document.querySelectorAll('.page').forEach(page=>page.classList.remove('active-page'));document.getElementById(pageId).classList.add('active-page');document.querySelectorAll('.nav-item').forEach(item=>item.classList.remove('active'));document.getElementById(navId).classList.add('active');window.scrollTo({top:0,behavior:'smooth'})}

function openPremium(title, price){
  document.getElementById('premium-title').textContent = title + ' — Premium';
  document.getElementById('premium-text').textContent = 'এই কোর্সটি PRO/Premium হিসেবে লক করা আছে। কোর্সটি আনলক করতে নিচের মূল্য অনুযায়ী কিনতে হবে।';
  document.getElementById('premium-price').textContent = price;
  document.getElementById('premiumModal').classList.add('show');
}
function closePremium(event){
  if(!event || event.target.id === 'premiumModal') document.getElementById('premiumModal').classList.remove('show');
}

function openHtmlCourse(){showPage('htmlCoursePage','coursesNav');}

function openNotePdf(){ window.location.href = 'pdfs/html-chapter-1.pdf'; }

/* Internet connectivity support: preserves all existing UI and payment/premium logic. */
(function enableInternetConnectivity(){
  async function checkInternetConnection(){
    if (!navigator.onLine) return false;
    try {
      await fetch('https://www.gstatic.com/generate_204', {
        method: 'GET', mode: 'no-cors', cache: 'no-store'
      });
      return true;
    } catch (error) {
      return false;
    }
  }
  window.appInternetConnected = checkInternetConnection;
  window.addEventListener('online', function(){ document.documentElement.dataset.internet = 'online'; });
  window.addEventListener('offline', function(){ document.documentElement.dataset.internet = 'offline'; });
  document.documentElement.dataset.internet = navigator.onLine ? 'online' : 'offline';
})();
