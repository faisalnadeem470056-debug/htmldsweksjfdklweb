const steps = [
  {
    icon: "🚽",
    title: "Potty Time!",
    text: "When you feel that you need to go, let's head to the potty.",
    button: "Go to the Potty"
  },
  {
    icon: "🧻",
    title: "Wipe",
    text: "Great job! Now let's practice wiping gently and carefully.",
    button: "Wipe"
  },
  {
    icon: "🚽",
    title: "Flush",
    text: "All done! Press the button to flush the potty.",
    button: "Flush"
  },
  {
    icon: "🧼",
    title: "Wash Hands",
    text: "Clean hands are important. Let's wash with soap and water!",
    button: "Wash Hands"
  },
  {
    icon: "⭐",
    title: "Amazing Job!",
    text: "You finished every step. You earned a star!",
    button: "Earn My Star"
  }
];

let currentStep = 0;
let stars = Number(localStorage.getItem("pottyStars") || 0);

const message = document.getElementById("message");
const starCount = document.getElementById("starCount");
const title = document.getElementById("title");
const instruction = document.getElementById("instruction");
const instructionIcon = document.getElementById("instructionIcon");
const actionButton = document.getElementById("actionButton");
const character = document.getElementById("character");
const potty = document.getElementById("potty");
const stepEls = [...document.querySelectorAll(".step")];

function updateStars() {
  starCount.textContent = stars;
  localStorage.setItem("pottyStars", stars);
}

function render() {
  const step = steps[currentStep];
  instructionIcon.textContent = step.icon;
  title.textContent = step.title;
  instruction.textContent = step.text;
  actionButton.textContent = step.button;

  stepEls.forEach((el, i) => {
    el.classList.toggle("active", i === currentStep);
    el.classList.toggle("done", i < currentStep);
  });

  if (currentStep === 0) {
    character.style.left = "15%";
  } else if (currentStep === 1) {
    character.style.left = "58%";
  } else if (currentStep === 2) {
    character.style.left = "62%";
  } else if (currentStep === 3) {
    character.style.left = "78%";
  } else {
    character.style.left = "48%";
  }
}

function celebrate(text) {
  message.textContent = text;
  character.classList.remove("happy");
  void character.offsetWidth;
  character.classList.add("happy");
}

actionButton.addEventListener("click", () => {
  if (currentStep < steps.length - 1) {
    const messages = [
      "Nice! You found the potty!",
      "Great practice!",
      "Flush complete!",
      "Super clean hands!"
    ];
    celebrate(messages[currentStep]);
    currentStep++;
    render();
  } else {
    stars++;
    updateStars();
    celebrate("⭐ You earned a star! Great job!");
    currentStep = 0;
    render();
    actionButton.textContent = "Practice Again";
  }
});

document.getElementById("resetButton").addEventListener("click", () => {
  currentStep = 0;
  message.textContent = "Let's practice together!";
  render();
});

updateStars();
render();
