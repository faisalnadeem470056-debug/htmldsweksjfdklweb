// ===============================
// SOS BUTTON
// ===============================

function sendSOS() {

    const confirmSOS = confirm(
        "🚨 EMERGENCY SOS\n\nAre you sure you want to activate SOS?"
    );

    if (confirmSOS) {

        const status = document.getElementById("status");

        status.innerHTML =
            "🚨 SOS ACTIVATED!<br>Getting your location...";

        getLocation();

        

    } else {

        document.getElementById("status").innerHTML =
            "SOS cancelled.";

    }
}


// ===============================
// GET CURRENT LOCATION
// ===============================

function getLocation() {

    const status = document.getElementById("status");

    if (!navigator.geolocation) {

        status.innerHTML =
            "❌ GPS is not supported by this browser.";

        return;
    }

    status.innerHTML =
        "📍 Getting your current location...";

    navigator.geolocation.getCurrentPosition(

        function(position) {

            const latitude =
                position.coords.latitude;

            const longitude =
                position.coords.longitude;
                saveSOSHistory(latitude, longitude);

            const mapsLink =
                `https://www.google.com/maps?q=${latitude},${longitude}`;

            status.innerHTML = `
                📍 <b>Location Found</b><br><br>

                Latitude: ${latitude.toFixed(6)}<br>

                Longitude: ${longitude.toFixed(6)}<br><br>

                <a href="${mapsLink}" target="_blank">
                    🗺️ Open Google Maps
                </a>

                <br><br>

                <button onclick="sendSOSAlert(${latitude}, ${longitude})">
                    🚨 Send SOS SMS
                </button>
            `;

        },

        function(error) {

            status.innerHTML =
                "❌ Location permission denied.<br>" +
                "Please allow location access.";

            console.error(error);

        }

    );
}


// ===============================
// SEND ALERT
// ===============================

function sendAlert() {

    const phoneNumber = "9876543210";

    const message =
        "🚨 EMERGENCY! I need help. Please check my location.";

    const smsURL =
        `sms:${phoneNumber}?body=${encodeURIComponent(message)}`;

    window.location.href = smsURL;
}


// ===============================
// SEND SOS SMS
// ===============================

function sendSOSAlert(latitude, longitude) {

    if (contacts.length === 0) {

        alert("Please add an emergency contact first.");

        return;
    }

    const phoneNumber =
        contacts[0].phone;

    const mapsLink =
        `https://www.google.com/maps?q=${latitude},${longitude}`;

    const message =
        `🚨 EMERGENCY! I need help.\nMy current location:\n${mapsLink}`;

    const smsURL =
        `sms:${phoneNumber}?body=${encodeURIComponent(message)}`;

    window.location.href = smsURL;
}


// ===============================
// EMERGENCY CONTACTS
// ===============================

let contacts =
    JSON.parse(
        localStorage.getItem("emergencyContacts")
    ) || [];


// ===============================
// SHOW CONTACTS
// ===============================

function showContacts() {

    document
        .getElementById("contactsSection")
        .scrollIntoView({
            behavior: "smooth"
        });

    displayContacts();
}


// ===============================
// ADD CONTACT
// ===============================

async function addContact() {

    const name =
        document
            .getElementById("contactName")
            .value
            .trim();

    const phone =
        document
            .getElementById("contactPhone")
            .value
            .trim();

    if (name === "" || phone === "") {

        alert("Please enter name and phone number.");

        return;
    }

    if (
        !window.firebaseAuth ||
        !window.firebaseAuth.currentUser
    ) {

        alert("Please login first.");

        return;
    }

    try {

        await window.firebaseAddDoc(

            window.firebaseCollection(

                window.firebaseDB,

                "users",

                window.firebaseAuth.currentUser.uid,

                "contacts"

            ),

            {
                name: name,
                phone: phone
            }

        );

        document.getElementById("contactName").value = "";

        document.getElementById("contactPhone").value = "";

        await loadContactsFromFirebase();

        alert("✅ Contact saved successfully!");

    } catch (error) {

        console.error(
            "Firestore error:",
            error
        );

        alert(
            "❌ Could not save contact to Firebase."
        );

    }
}


// ===============================
// LOAD CONTACTS FROM FIREBASE
// ===============================

async function loadContactsFromFirebase() {

    if (
        !window.firebaseAuth ||
        !window.firebaseAuth.currentUser
    ) {
        return;
    }

    try {

        const snapshot =
            await window.firebaseGetDocs(

                window.firebaseCollection(

                    window.firebaseDB,

                    "users",

                    window.firebaseAuth.currentUser.uid,

                    "contacts"

                )

            );

        contacts = [];

        snapshot.forEach(function(doc) {

            contacts.push({

                id: doc.id,

                name: doc.data().name,

                phone: doc.data().phone

            });

        });

        localStorage.setItem(
            "emergencyContacts",
            JSON.stringify(contacts)
        );

        displayContacts();

    } catch (error) {

        console.error(
            "Load contacts error:",
            error
        );

        alert(
            "❌ Could not load contacts from Firebase."
        );
    }
}


// ===============================
// DISPLAY CONTACTS
// ===============================

function displayContacts() {

    const list =
        document.getElementById("contactList");

    if (!list) {
        return;
    }

    list.innerHTML = "";

    contacts.forEach(
        function(contact, index) {

            list.innerHTML += `

                <div class="contact-card">

                    <b>
                        👤 ${contact.name}
                    </b>

                    <p>
                        📞 ${contact.phone}
                    </p>

                    <button
                        onclick="callContact('${contact.phone}')">

                        📞 Call

                    </button>

                    <button
                        onclick="editContact(${index})">

                        ✏️ Edit

                    </button>

                    <button
                        onclick="deleteContact(${index})">

                        🗑️ Delete

                    </button>

                </div>

            `;

        }
    );
}


// ===============================
// CALL CONTACT
// ===============================

function callContact(phone) {

    window.location.href =
        `tel:${phone}`;

}


// ===============================
// DELETE CONTACT
// ===============================

async function deleteContact(index) {

    const confirmDelete = confirm(
        "Are you sure you want to delete this contact?"
    );

    if (!confirmDelete) {
        return;
    }

    const contact = contacts[index];

    if (!contact.id) {
        alert("❌ Firebase contact ID not found.");
        return;
    }

    try {

        const contactRef =
            window.firebaseDoc(
                window.firebaseDB,
                "users",
                window.firebaseAuth.currentUser.uid,
                "contacts",
                contact.id
            );

        await window.firebaseDeleteDoc(contactRef);

        contacts.splice(index, 1);

        localStorage.setItem(
            "emergencyContacts",
            JSON.stringify(contacts)
        );

        displayContacts();

        alert("✅ Contact deleted successfully!");

    } catch (error) {

        console.error(
            "Delete contact error:",
            error
        );

        alert(
            "❌ Could not delete contact from Firebase."
        );
    }
}

// ===============================
// EDIT CONTACT
// ===============================

async function editContact(index) {

    const contact = contacts[index];

    const newName = prompt(
        "Enter new name:",
        contact.name
    );

    const newPhone = prompt(
        "Enter new phone number:",
        contact.phone
    );

    if (!newName || !newPhone) {
        return;
    }

    if (!contact.id) {
        alert("❌ Firebase contact ID not found.");
        return;
    }

    try {

        const contactRef =
            window.firebaseDoc(
                window.firebaseDB,
                "users",
                window.firebaseAuth.currentUser.uid,
                "contacts",
                contact.id
            );

        await window.firebaseUpdateDoc(
            contactRef,
            {
                name: newName,
                phone: newPhone
            }
        );

        contacts[index].name = newName;
        contacts[index].phone = newPhone;

        localStorage.setItem(
            "emergencyContacts",
            JSON.stringify(contacts)
        );

        displayContacts();

        alert("✅ Contact updated successfully!");

    } catch (error) {

        console.error(
            "Edit contact error:",
            error
        );

        alert(
            "❌ Could not update contact in Firebase."
        );
    }
}


// ===============================
// EMERGENCY NUMBERS
// ===============================

function showEmergencyNumbers() {

    document
        .getElementById("emergencySection")
        .scrollIntoView({
            behavior: "smooth"
        });

}


// ===============================
// SAFETY TIPS
// ===============================

function showSafetyTips() {

    document
  
    .getElementById("safetySection")
        .scrollIntoView({
            behavior: "smooth"
        });

}


// ===============================
// SOS HISTORY
// ===============================

async function saveSOSHistory(latitude, longitude) {
    if (
        !window.firebaseAuth ||
        !window.firebaseAuth.currentUser
    ) {
        return;
    }

    try {

        const now = new Date();

        await window.firebaseAddDoc(

            window.firebaseCollection(
                window.firebaseDB,
                "users",
                window.firebaseAuth.currentUser.uid,
                "sosHistory"
            ),

            {
    date: now.toLocaleDateString(),
    time: now.toLocaleTimeString(),
    latitude: latitude,
    longitude: longitude
}
        );

        console.log(
            "✅ SOS history saved to Firebase"
        );

    } catch (error) {

        console.error(
            "SOS history error:",
            error
        );

    }
}

// ===============================
// DISPLAY SOS HISTORY
// ===============================

async function displaySOSHistory() {

    const list =
        document.getElementById("historyList");

    if (!list) {
        return;
    }

    if (
        !window.firebaseAuth ||
        !window.firebaseAuth.currentUser
    ) {
        list.innerHTML = "";
        return;
    }

    try {

        const snapshot =
            await window.firebaseGetDocs(

                window.firebaseCollection(
                    window.firebaseDB,
                    "users",
                    window.firebaseAuth.currentUser.uid,
                    "sosHistory"
                )

            );

        list.innerHTML = "";

        snapshot.forEach(function(doc) {

            const item = doc.data();

            list.innerHTML += `

                <div class="history-card">

                    🚨 <b>SOS Alert</b>

                    <p>
                        📅 ${item.date}
                    </p>

                    <p>
                        ⏰ ${item.time}
                    </p>
                    <p>
    📍 Latitude: ${item.latitude}
</p>

<p>
    📍 Longitude: ${item.longitude}
</p>

<a href="https://www.google.com/maps?q=${item.latitude},${item.longitude}"
   target="_blank">
    🗺️ Open Location
</a>

                </div>

            `;

        });
    } catch (error) {

        console.error(
            "Load SOS history error:",
            error
        );

    }
}

// ===============================
// CLEAR SOS HISTORY
// ===============================

async function clearSOSHistory() {

    if (
        !window.firebaseAuth ||
        !window.firebaseAuth.currentUser
    ) {
        alert("Please login first.");
        return;
    }

    const confirmClear = confirm(
        "Are you sure you want to clear all SOS history?"
    );

    if (!confirmClear) {
        return;
    }

    try {

        const snapshot =
            await window.firebaseGetDocs(

                window.firebaseCollection(
                    window.firebaseDB,
                    "users",
                    window.firebaseAuth.currentUser.uid,
                    "sosHistory"
                )

            );

        for (const historyDoc of snapshot.docs) {

            const historyRef =
                window.firebaseDoc(
                    window.firebaseDB,
                    "users",
                    window.firebaseAuth.currentUser.uid,
                    "sosHistory",
                    historyDoc.id
                );

            await window.firebaseDeleteDoc(historyRef);
        }

        document.getElementById("historyList").innerHTML = "";

        alert("✅ SOS history cleared successfully!");

    } catch (error) {

        console.error(
            "Clear SOS history error:",
            error
        );

        alert(
            "❌ Could not clear SOS history from Firebase."
        );
    }
}

// ===============================
// LOGIN
// ===============================

async function loginUser() {
    
    const email =
        document
            .getElementById("loginEmail")
            .value
            .trim();

    const password =
        document
            .getElementById("loginPassword")
            .value;

    const status =
        document.getElementById("loginStatus");

    if (email === "" || password === "") {

        status.innerHTML =
            "❌ Please enter email and password.";

        return;
    }

    status.innerHTML =
        "🔄 Logging in...";

    if (
        typeof window.firebaseLogin !==
        "function"
    ) {

        status.innerHTML =
            "❌ Firebase is not ready. Please wait a moment.";

        return;
    }

    window.firebaseLogin(
        email,
        password
    )

    .then(
        async function() {

            status.innerHTML =
                "✅ Login successful!";
                document.getElementById("userEmail").innerHTML =
    "📧 Email: " + email;

            document
                .getElementById("loginSection")
                .style.display = "none";

            document
                .getElementById("appSection")
                .style.removeProperty("display");

           await loadContactsFromFirebase();

await displaySOSHistory();
        }
    )

    .catch(
        function(error) {

            status.innerHTML =
                "❌ " + error.message;

            console.error(
                "Firebase Login Error:",
                error
            );

        }
    );

}


// ===============================
// LOGOUT
// ===============================

function logoutUser() {

    if (
        typeof window.firebaseLogout !==
        "function"
    ) {

        alert(
            "Firebase is not ready. Please wait a moment."
        );

        return;
    }

    window.firebaseLogout()

    .then(
        function() {

            document
                .getElementById("appSection")
                .style.display = "none";

            document
                .getElementById("loginSection")
                .style.display = "block";

            document
                .getElementById("loginStatus")
                .innerHTML =
                "✅ Logged out successfully.";

        }
    )

    .catch(
        function(error) {

            console.error(error);

            alert(
                "❌ Logout failed."
            );

        }
    );

}


// ===============================
// INITIAL PAGE
// ===============================

document.addEventListener(
    "DOMContentLoaded",
    function() {

        const appSection =
            document.getElementById("appSection");

        if (appSection) {

            appSection.style.display =
                "none";

        }

        displaySOSHistory();

        displayContacts();

    }
);
function showRegister() {

    document.getElementById("registerSection").style.display = "block";

}
function registerUser() {

    const email =
        document.getElementById("registerEmail").value.trim();

    const password =
        document.getElementById("registerPassword").value;

    const status =
        document.getElementById("registerStatus");

    if (email === "" || password === "") {

        status.innerHTML =
            "❌ Please enter email and password.";

        return;
    }

    status.innerHTML =
        "🔄 Creating account...";

    if (
        typeof window.firebaseRegister !==
        "function"
    ) {

        status.innerHTML =
            "❌ Firebase is not ready. Please wait a moment.";

        return;
    }

    window.firebaseRegister(
        email,
        password
    )

    .then(
    function() {

        status.innerHTML =
            "✅ Account created successfully!";

        document.getElementById("registerEmail").value = "";
        document.getElementById("registerPassword").value = "";

    }
)
    .catch(
        function(error) {

            status.innerHTML =
                "❌ " + error.message;

            console.error(
                "Firebase Register Error:",
                error
            );

        }
    );

}
function showSettings() {

    document
        .getElementById("settingsSection")
        .scrollIntoView({
            behavior: "smooth"
        });

}
