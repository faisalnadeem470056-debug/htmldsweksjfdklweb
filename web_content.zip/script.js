function openIPCalculator() {
    window.location.href = "ip-calculator.html";
}