(() => {
  "use strict";

  const state = {
    matches: [],
    filter: "all",
    search: "",
    league: "all",
    controller: null,
    refreshing: false,
    lastUpdated: null,
    timer: null
  };

  const els = {
    todayLabel: document.querySelector("#todayLabel"),
    matches: document.querySelector("#matches"),
    skeleton: document.querySelector("#skeleton"),
    message: document.querySelector("#message"),
    lastUpdated: document.querySelector("#lastUpdated"),
    connectionStatus: document.querySelector("#connectionStatus"),
    refreshBtn: document.querySelector("#refreshBtn"),
    searchInput: document.querySelector("#searchInput"),
    leagueFilter: document.querySelector("#leagueFilter"),
    themeToggle: document.querySelector("#themeToggle")
  };

  const IRAQ_TZ = "Asia/Baghdad";

  function getIraqDateParts(date = new Date()) {
    const parts = new Intl.DateTimeFormat("en-CA", {
      timeZone: IRAQ_TZ, year: "numeric", month: "2-digit", day: "2-digit"
    }).formatToParts(date);
    return Object.fromEntries(parts.filter(p => p.type !== "literal").map(p => [p.type, p.value]));
  }

  function getIraqDateISO() {
    const p = getIraqDateParts();
    return `${p.year}-${p.month}-${p.day}`;
  }

  function formatArabicDate(iso) {
    return new Intl.DateTimeFormat("ar-IQ", {
      timeZone: IRAQ_TZ, weekday: "long", day: "2-digit", month: "long", year: "numeric"
    }).format(new Date(`${iso}T12:00:00Z`));
  }

  function formatTime(iso) {
    if (!iso) return "—";
    return new Intl.DateTimeFormat("ar-IQ", {
      timeZone: IRAQ_TZ, hour: "2-digit", minute: "2-digit", hour12: true
    }).format(new Date(iso));
  }

  function escapeHTML(value) {
    return String(value ?? "").replace(/[&<>"']/g, c => ({
      "&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"
    }[c]));
  }

  function logoHTML(url, alt, name) {
    const safeAlt = escapeHTML(alt || name || "شعار الفريق");
    const fallback = "data:image/svg+xml;charset=UTF-8," + encodeURIComponent(
      `<svg xmlns="http://www.w3.org/2000/svg" width="80" height="80"><rect width="80" height="80" rx="16" fill="#e5e7eb"/><text x="40" y="48" text-anchor="middle" font-size="30" fill="#6b7280">⚽</text></svg>`
    );
    return `<img loading="lazy" src="${escapeHTML(url || fallback)}" alt="${safeAlt}" onerror="this.onerror=null;this.src='${fallback}'">`;
  }

  function statusClass(match) {
    if (match.statusGroup === "live") return "live";
    if (match.statusGroup === "finished") return "finished";
    return "upcoming";
  }

  function statusLabel(match) {
    return match.statusLabel || "غير متاح";
  }

  function renderCard(match) {
    const liveScore = match.statusGroup === "live" || match.statusGroup === "finished";
    const score = liveScore && Number.isInteger(match.homeGoals) && Number.isInteger(match.awayGoals)
      ? `${match.homeGoals} - ${match.awayGoals}`
      : null;

    const meta = [
      match.round ? `الجولة: ${escapeHTML(match.round)}` : "",
      match.venue ? `الملعب: ${escapeHTML(match.venue)}` : "",
      match.fixtureId ? `ID: ${escapeHTML(match.fixtureId)}` : ""
    ].filter(Boolean).map(x => `<span class="meta-chip">${x}</span>`).join("");

    return `
      <article class="match-card" data-id="${escapeHTML(match.fixtureId)}">
        <div class="match-top">
          <div class="competition">
            <strong>${escapeHTML(match.leagueName || "بطولة غير محددة")}</strong>
            <small>${escapeHTML(match.country || "—")}</small>
          </div>
          <span class="badge ${statusClass(match)}">${match.statusGroup === "live" ? "● " : ""}${escapeHTML(statusLabel(match))}</span>
        </div>
        <div class="match-main">
          <div class="team">
            ${logoHTML(match.homeLogo, `شعار ${match.homeName}`, match.homeName)}
            <span class="team-name">${escapeHTML(match.homeName || "فريق غير محدد")}</span>
          </div>
          <div class="scorebox">
            ${score ? `<div class="score">${score}</div>` : `<div class="time">${escapeHTML(formatTime(match.startTime))}</div>`}
            ${match.statusGroup === "live" && match.elapsed ? `<div class="elapsed">مباشر الآن • ${escapeHTML(match.elapsed)}′</div>` : ""}
            ${!score && match.statusGroup !== "live" ? `<div class="vs">بتوقيت العراق</div>` : ""}
          </div>
          <div class="team">
            ${logoHTML(match.awayLogo, `شعار ${match.awayName}`, match.awayName)}
            <span class="team-name">${escapeHTML(match.awayName || "فريق غير محدد")}</span>
          </div>
        </div>
        ${meta ? `<div class="match-meta">${meta}</div>` : ""}
      </article>`;
  }

  function groupForFilter(match) {
    if (state.filter === "live") return match.statusGroup === "live";
    if (state.filter === "finished") return match.statusGroup === "finished";
    if (state.filter === "upcoming") return match.statusGroup === "upcoming";
    return true;
  }

  function render() {
    const q = state.search.trim().toLocaleLowerCase("ar");
    const filtered = state.matches.filter(m => {
      const text = `${m.homeName || ""} ${m.awayName || ""}`.toLocaleLowerCase("ar");
      return groupForFilter(m) &&
        (!q || text.includes(q)) &&
        (state.league === "all" || m.leagueKey === state.league);
    }).sort((a,b) => new Date(a.startTime || 0) - new Date(b.startTime || 0));

    els.matches.innerHTML = "";
    if (!filtered.length) {
      els.message.textContent = state.matches.length
        ? "لا توجد مباريات تطابق خيارات البحث والتصفية الحالية."
        : "لا توجد مباريات مجدولة اليوم في البيانات المتاحة من API.";
      els.message.classList.remove("hidden");
      return;
    }
    els.message.classList.add("hidden");

    const live = filtered.filter(m => m.statusGroup === "live");
    const upcoming = filtered.filter(m => m.statusGroup === "upcoming");
    const finished = filtered.filter(m => m.statusGroup === "finished");

    const sections = [
      ["مباشر الآن", live],
      ["القادمة", upcoming],
      ["انتهت", finished]
    ];
    for (const [title, list] of sections) {
      if (!list.length) continue;
      const titleEl = document.createElement("div");
      titleEl.className = "section-title";
      titleEl.innerHTML = `<h2>${title}</h2><span>${list.length} مباراة</span>`;
      els.matches.appendChild(titleEl);
      const fragment = document.createDocumentFragment();
      const wrapper = document.createElement("div");
      wrapper.style.display = "contents";
      wrapper.innerHTML = list.map(renderCard).join("");
      fragment.append(...wrapper.childNodes);
      els.matches.appendChild(fragment);
    }
  }

  function populateLeagues() {
    const current = state.league;
    const leagues = [...new Map(state.matches.map(m => [m.leagueKey, m.leagueName])).entries()]
      .filter(([key, name]) => key && name)
      .sort((a,b) => a[1].localeCompare(b[1], "ar"));
    els.leagueFilter.innerHTML = `<option value="all">كل البطولات</option>` +
      leagues.map(([key,name]) => `<option value="${escapeHTML(key)}">${escapeHTML(name)}</option>`).join("");
    els.leagueFilter.value = leagues.some(([key]) => key === current) ? current : "all";
  }

  function humanError(status, message) {
    if (status === 401 || status === 403) return "مفتاح API غير صحيح أو غير مصرح به. راجع إعدادات الخادم.";
    if (status === 429) return "تم تجاوز حد طلبات API مؤقتًا. سيُعاد المحاولة لاحقًا.";
    if (status >= 500) return "خادم البيانات غير متاح حاليًا. حاول مرة أخرى لاحقًا.";
    return message || "تعذر تحميل المباريات حاليًا، حاول مرة أخرى.";
  }

  async function fetchMatches() {
    if (state.controller) state.controller.abort();
    state.controller = new AbortController();
    setLoading(true);

    const date = getIraqDateISO();
    els.todayLabel.textContent = `مباريات ${formatArabicDate(date)}`;

    try {
      const response = await fetch(`/api/matches?date=${encodeURIComponent(date)}`, {
        signal: state.controller.signal,
        headers: { "Accept": "application/json" },
        cache: "no-store"
      });
      let payload = null;
      try { payload = await response.json(); } catch { /* handled below */ }

      if (!response.ok) {
        throw new Error(humanError(response.status, payload?.message));
      }
      if (!payload || !Array.isArray(payload.matches)) {
        throw new Error("استجابة API غير صالحة.");
      }

      state.matches = payload.matches;
      state.lastUpdated = new Date();
      populateLeagues();
      render();
      els.connectionStatus.textContent = "متصل • البيانات محدثة";
      els.connectionStatus.className = "status-pill ok";
      updateLastUpdated();
      scheduleNext(payload.refreshAfterMs);
    } catch (error) {
      if (error.name === "AbortError") return;
      els.connectionStatus.textContent = "تعذر الاتصال";
      els.connectionStatus.className = "status-pill error";
      els.message.textContent = error.message || "تعذر تحميل المباريات حاليًا، حاول مرة أخرى.";
      els.message.classList.remove("hidden");
      if (!state.matches.length) els.matches.innerHTML = "";
      scheduleNext(180000);
    } finally {
      setLoading(false);
    }
  }

  function setLoading(loading) {
    state.refreshing = loading;
    els.refreshBtn.disabled = loading;
    if (loading && !state.matches.length) els.skeleton.classList.remove("hidden");
    else els.skeleton.classList.add("hidden");
    els.refreshBtn.textContent = loading ? "جارٍ التحديث…" : "تحديث الآن";
  }

  function updateLastUpdated() {
    if (!state.lastUpdated) return;
    const seconds = Math.max(0, Math.floor((Date.now() - state.lastUpdated.getTime()) / 1000));
    els.lastUpdated.textContent = seconds < 5 ? "آخر تحديث: الآن" : `آخر تحديث: منذ ${seconds} ثانية`;
  }

  function scheduleNext(ms) {
    clearTimeout(state.timer);
    const delay = Number.isFinite(ms) ? Math.max(30000, ms) : 180000;
    state.timer = setTimeout(() => {
      if (getIraqDateISO() !== currentDate) {
        currentDate = getIraqDateISO();
      }
      fetchMatches();
    }, delay);
  }

  let currentDate = getIraqDateISO();

  document.querySelectorAll(".filter-btn").forEach(btn => {
    btn.addEventListener("click", () => {
      document.querySelectorAll(".filter-btn").forEach(b => b.classList.remove("active"));
      btn.classList.add("active");
      state.filter = btn.dataset.filter;
      render();
    });
  });

  els.searchInput.addEventListener("input", e => { state.search = e.target.value; render(); });
  els.leagueFilter.addEventListener("change", e => { state.league = e.target.value; render(); });
  els.refreshBtn.addEventListener("click", fetchMatches);

  els.themeToggle.addEventListener("click", () => {
    const dark = document.documentElement.dataset.theme === "dark";
    document.documentElement.dataset.theme = dark ? "light" : "dark";
    localStorage.setItem("football-theme", dark ? "light" : "dark");
    els.themeToggle.textContent = dark ? "☾" : "☀";
  });

  const savedTheme = localStorage.getItem("football-theme");
  if (savedTheme === "dark") {
    document.documentElement.dataset.theme = "dark";
    els.themeToggle.textContent = "☀";
  }

  setInterval(updateLastUpdated, 1000);

  // Midnight-safe rollover: the API date is always recalculated from Asia/Baghdad.
  setInterval(() => {
    const nowDate = getIraqDateISO();
    if (nowDate !== currentDate) {
      currentDate = nowDate;
      fetchMatches();
    }
  }, 30000);

  fetchMatches();
})();
