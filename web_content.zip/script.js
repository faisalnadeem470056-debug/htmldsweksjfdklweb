/* =========================================================
   مساعد الكهرباء - Electricity Assistant
   RIF POWER
   VERSION 1.0
   ========================================================= */


/* =========================================================
   STORAGE
========================================================= */

const LANGUAGE_KEY = "electricityLanguage";
const THEME_KEY = "electricityTheme";
const PROGRESS_KEY = "electricityAcademyProgressV4";


/* =========================================================
   STATE
========================================================= */

let currentLanguage =
    localStorage.getItem(LANGUAGE_KEY) || "ar";

let currentTheme =
    localStorage.getItem(THEME_KEY) || "light";

let selectedLevel = null;
let selectedType = null;
let selectedLesson = null;

let lessonQuestionIndex = 0;
let lessonScore = 0;
let selectedLessonAnswer = null;

let currentUnit = 0;
let unitQuestionIndex = 0;
let unitScore = 0;
let selectedUnitAnswer = null;

let finalQuestionIndex = 0;
let finalScore = 0;
let selectedFinalAnswer = null;

let calculatorMode = "power";


/* =========================================================
   TRANSLATIONS
========================================================= */

const T = {

    ar: {

        appName: "مساعد الكهرباء",
        developer: "RIF POWER",
        version: "VERSION 1.0",

        welcomeDescription:
            "تعلم الكهرباء بطريقة منظمة وبسيطة",

        chooseLanguage:
            "اختر اللغة",

        languageSubtitle:
            "اختر اللغة التي تريد استعمالها",

        futureLanguages:
            "لغات أخرى ستتوفر مستقبلاً",

        continue:
            "متابعة",

        homeWelcome:
            "مرحباً بك 👋",

        homeDescription:
            "تعلم الكهرباء، شخّص الأعطال، واحسب القيم الكهربائية.",

        academy:
            "أكاديمية الكهرباء",

        academyDescription:
            "تعلم الكهرباء من البداية حتى المستوى المتقدم",

        calculator:
            "الحاسبة",

        calculatorDescription:
            "احسب الجهد والتيار والمقاومة والقدرة",

        faults:
            "تشخيص الأعطال",

        faultsDescription:
            "معلومات عن الأعطال الكهربائية",

        laws:
            "القوانين والرموز",

        lawsDescription:
            "أهم القوانين والرموز الكهربائية",

        information:
            "معلومات الكهرباء",

        informationDescription:
            "معلومات ومصطلحات كهربائية",

        settings:
            "الإعدادات",

        settingsDescription:
            "اللغة والمظهر ومعلومات التطبيق",

        beginner:
            "المستوى المبتدئ",

        intermediate:
            "المستوى المتوسط",

        advanced:
            "المستوى المتقدم",

        home:
            "كهرباء المنازل",

        car:
            "كهرباء السيارات",

        selectLevel:
            "اختر المستوى",

        selectLevelDescription:
            "ابدأ من المستوى المناسب لك",

        selectType:
            "اختر نوع الكهرباء",

        selectTypeDescription:
            "اختر المجال الذي تريد تعلمه",

        lessons:
            "الدروس",

        lessonsDescription2:
            "أكمل الدروس بالترتيب",

        lesson:
            "الدرس",

        locked:
            "🔒 مقفل",

        unlocked:
            "متاح",

        completed:
            "✓ مكتمل",

        unit:
            "الوحدة",

        exam:
            "الامتحان",

        startTest:
            "ابدأ الاختبار",

        next:
            "التالي",

        review:
            "عليك المراجعة وإعادة الاختبار.",

        passed:
            "مبروك! لقد نجحت.",

        average:
            "متوسط",

        good:
            "جيد",

        veryGood:
            "جيد جداً",

        excellent:
            "ممتاز",

        finalExam:
            "الامتحان النهائي",

        finalExamDescription:
            "اجتز الامتحان النهائي بنتيجة 75/100 أو أكثر لفتح المستوى التالي.",

        passedLevel:
            "لقد اجتزت المستوى بنجاح!",

        complete:
            "مبروك!",

        completeMessage:
            "أكملت هذا المسار التعليمي.",

        power:
            "القدرة",

        voltage:
            "الجهد",

        current:
            "التيار",

        resistance:
            "المقاومة",

        calculate:
            "احسب",

        result:
            "النتيجة",

        selectFault:
            "اختر نوع العطل",

        electricalInformation:
            "معلومات كهربائية",

        language:
            "اللغة",

        arabic:
            "العربية",

        english:
            "English",

        light:
            "الوضع الفاتح",

        dark:
            "الوضع الداكن"

    },


    en: {

        appName: "Electricity Assistant",
        developer: "RIF POWER",
        version: "VERSION 1.0",

        welcomeDescription:
            "Learn electricity in a simple and organized way",

        chooseLanguage:
            "Choose Language",

        languageSubtitle:
            "Choose the language you want to use",

        futureLanguages:
            "More languages will be available later",

        continue:
            "Continue",

        homeWelcome:
            "Welcome 👋",

        homeDescription:
            "Learn electricity, diagnose faults and calculate electrical values.",

        academy:
            "Electricity Academy",

        academyDescription:
            "Learn electricity from beginner to advanced",

        calculator:
            "Calculator",

        calculatorDescription:
            "Calculate voltage, current, resistance and power",

        faults:
            "Fault Diagnosis",

        faultsDescription:
            "Electrical fault information",

        laws:
            "Laws & Symbols",

        lawsDescription:
            "Important electrical laws and symbols",

        information:
            "Electrical Information",

        informationDescription:
            "Electrical information and terms",

        settings:
            "Settings",

        settingsDescription:
            "Language, theme and app information",

        beginner:
            "Beginner Level",

        intermediate:
            "Intermediate Level",

        advanced:
            "Advanced Level",

        home:
            "Home Electricity",

        car:
            "Car Electricity",

        selectLevel:
            "Choose Level",

        selectLevelDescription:
            "Choose the level you want to study",

        selectType:
            "Choose Electricity Type",

        selectTypeDescription:
            "Choose the field you want to learn",

        lessons:
            "Lessons",

        lessonsDescription2:
            "Complete lessons in order",

        lesson:
            "Lesson",

        locked:
            "🔒 Locked",

        unlocked:
            "Available",

        completed:
            "✓ Completed",

        unit:
            "Unit",

        exam:
            "Exam",

        startTest:
            "Start Test",

        next:
            "Next",

        review:
            "You need to review and retake the test.",

        passed:
            "Congratulations! You passed.",

        average:
            "Average",

        good:
            "Good",

        veryGood:
            "Very Good",

        excellent:
            "Excellent",

        finalExam:
            "Final Exam",

        finalExamDescription:
            "Score 75/100 or higher to unlock the next level.",

        passedLevel:
            "You successfully passed this level!",

        complete:
            "Congratulations!",

        completeMessage:
            "You completed this learning path.",

        power:
            "Power",

        voltage:
            "Voltage",

        current:
            "Current",

        resistance:
            "Resistance",

        calculate:
            "Calculate",

        result:
            "Result",

        selectFault:
            "Choose a fault",

        electricalInformation:
            "Electrical Information",

        language:
            "Language",

        arabic:
            "العربية",

        english:
            "English",

        light:
            "Light Mode",

        dark:
            "Dark Mode"

    }

};


/* =========================================================
   HELPERS
========================================================= */

function $(id) {
    return document.getElementById(id);
}

function text(id, value) {
    const element = $(id);

    if (element) {
        element.textContent = value;
    }
}


/* =========================================================
   SCREEN SYSTEM
   IMPORTANT FIX FOR WHITE SCREEN
========================================================= */

function showScreen(screenId) {

    document.querySelectorAll(".screen").forEach(screen => {

        screen.classList.remove("active");

        screen.classList.add("hidden");

    });


    const target = $(screenId);

    if (!target) {
        console.error("Screen not found:", screenId);
        return;
    }


    target.classList.remove("hidden");

    target.classList.add("active");

    window.scrollTo(0, 0);
}


/* =========================================================
   LANGUAGE
========================================================= */

function selectLanguage(language) {

    currentLanguage = language;

    $("check-ar")?.classList.toggle(
        "selected",
        language === "ar"
    );

    $("check-en")?.classList.toggle(
        "selected",
        language === "en"
    );

}


function applyLanguage() {

    const lang = T[currentLanguage];

    document.documentElement.lang = currentLanguage;

    document.documentElement.dir =
        currentLanguage === "ar"
            ? "rtl"
            : "ltr";


    text("welcomeAppName", lang.appName);
    text("welcomeDeveloper", lang.developer);
    text("welcomeVersion", lang.version);
    text("welcomeDescription", lang.welcomeDescription);

    text("languageTitle", lang.chooseLanguage);
    text("languageSubtitle", lang.languageSubtitle);
    text("futureLanguages", lang.futureLanguages);
    text("continueButton", lang.continue);

    text("homeAppName", lang.appName);
    text("homeDeveloper", lang.developer);
    text("homeWelcome", lang.homeWelcome);
    text("homeDescription", lang.homeDescription);

    text("lessonsTitle", lang.academy);
    text("lessonsDescription", lang.academyDescription);

    text("calculatorTitle", lang.calculator);
    text("calculatorDescription", lang.calculatorDescription);

    text("faultsTitle", lang.faults);
    text("faultsDescription", lang.faultsDescription);

    text("lawsTitle", lang.laws);
    text("lawsDescription", lang.lawsDescription);

    text("informationTitle", lang.information);
    text("informationDescription", lang.informationDescription);

    text("settingsTitle", lang.settings);
    text("settingsDescription", lang.settingsDescription);

    text(
        "homeFooter",
        `${lang.appName} • ${lang.developer} • ${lang.version}`
    );


    text("lessonsPageTitle", lang.academy);

    text("academyLevelTitle", lang.selectLevel);
    text(
        "academyLevelDescription",
        lang.selectLevelDescription
    );

    text("academyTypeTitle", lang.selectType);
    text(
        "academyTypeDescription",
        lang.selectTypeDescription
    );

    text("academyCurriculumTitle", lang.lessons);
    text(
        "academyCurriculumDescription",
        lang.lessonsDescription2
    );


    text(
        "calculatorPageTitle",
        lang.calculator
    );

    text(
        "calculatorBoxTitle",
        currentLanguage === "ar"
            ? "اختر ما تريد حسابه"
            : "Choose what to calculate"
    );

    text(
        "calculateButton",
        lang.calculate
    );


    text(
        "faultsPageTitle",
        lang.faults
    );

    text(
        "faultsBoxTitle",
        lang.selectFault
    );


    text(
        "lawsPageTitle",
        lang.laws
    );

    text(
        "informationPageTitle",
        lang.information
    );

    text(
        "informationBoxTitle",
        lang.electricalInformation
    );


    text(
        "settingsPageTitle",
        lang.settings
    );

    text(
        "languageSettingTitle",
        lang.language
    );

    text(
        "currentLanguage",
        currentLanguage === "ar"
            ? lang.arabic
            : lang.english
    );


    updateThemeText();
    updateCalculator();

    if (selectedLevel && selectedType) {
        renderAcademyLessons();
    }

    renderFaults();
    renderInformation();
    renderLaws();
}


/* =========================================================
   THEME
========================================================= */

function applyTheme() {

    document.documentElement.dataset.theme =
        currentTheme === "dark"
            ? "dark"
            : "light";

    localStorage.setItem(
        THEME_KEY,
        currentTheme
    );

    updateThemeText();
}


function toggleTheme() {

    currentTheme =
        currentTheme === "dark"
            ? "light"
            : "dark";

    applyTheme();
}


function updateThemeText() {

    const lang = T[currentLanguage];

    text(
        "themeToggle",
        currentTheme === "dark"
            ? `☀️ ${lang.light}`
            : `🌙 ${lang.dark}`
    );

    text(
        "themeModeText",
        currentTheme === "dark"
            ? lang.dark
            : lang.light
    );
}


/* =========================================================
   LANGUAGE CONTINUE
========================================================= */

function continueFromLanguage() {

    localStorage.setItem(
        LANGUAGE_KEY,
        currentLanguage
    );

    applyLanguage();

    showScreen("homeScreen");
}


/* =========================================================
   HOME
========================================================= */

function goHome() {
    showScreen("homeScreen");
}


/* =========================================================
   ACADEMY DATA
========================================================= */

const LEVELS = {

    beginner: {
        title: {
            ar: "المستوى المبتدئ",
            en: "Beginner Level"
        }
    },

    intermediate: {
        title: {
            ar: "المستوى المتوسط",
            en: "Intermediate Level"
        }
    },

    advanced: {
        title: {
            ar: "المستوى المتقدم",
            en: "Advanced Level"
        }
    }

};


const TYPES = {

    home: {
        title: {
            ar: "كهرباء المنازل",
            en: "Home Electricity"
        }
    },

    car: {
        title: {
            ar: "كهرباء السيارات",
            en: "Car Electricity"
        }
    }

};


/* =========================================================
   50 LESSON TITLES
========================================================= */

const HOME_BEGINNER = [

    "ما هي الكهرباء؟",
    "الجهد الكهربائي Voltage",
    "التيار الكهربائي Current",
    "المقاومة Resistance",
    "القدرة الكهربائية Power",
    "العلاقة بين الجهد والتيار والمقاومة",
    "قانون أوم",
    "الطاقة الكهربائية",
    "الوحدات الكهربائية",
    "رموز الكهرباء الأساسية",

    "الفاز Phase",
    "النتر Neutral",
    "الأرضي Earth",
    "القاطع الكهربائي",
    "الفيوز Fuse",
    "المفتاح Switch",
    "المقبس Socket",
    "المصباح Lamp",
    "الأسلاك الكهربائية",
    "ألوان الأسلاك",

    "الدائرة الكهربائية",
    "الدائرة المفتوحة",
    "الدائرة المغلقة",
    "التوصيل على التوالي",
    "التوصيل على التوازي",
    "الحمل الكهربائي",
    "الدارة البسيطة",
    "قراءة الرموز الكهربائية",
    "السلامة الكهربائية",
    "مخاطر الكهرباء",

    "الماس الكهربائي",
    "ارتفاع التيار",
    "انخفاض الجهد",
    "انقطاع الكهرباء",
    "القاطع الذي يفصل",
    "المصباح الذي لا يشتغل",
    "المقبس الذي لا يعمل",
    "المفتاح الذي لا يعمل",
    "أساسيات الفحص الكهربائي",
    "استعمال جهاز القياس بأمان",

    "الملتيميتر",
    "قياس الجهد",
    "قياس المقاومة",
    "قياس الاستمرارية",
    "فهم نتائج القياس",
    "الأحمال المنزلية",
    "استهلاك الكهرباء",
    "حساب القدرة",
    "مراجعة المستوى المبتدئ",
    "اختبار شامل للمستوى المبتدئ"

];


const HOME_INTERMEDIATE = [

    "مراجعة قانون أوم",
    "دوائر المنازل",
    "لوحة التوزيع",
    "القواطع الفرعية",
    "القاطع الرئيسي",
    "الحماية الكهربائية",
    "توزيع الأحمال",
    "اختيار الحمل المناسب",
    "القدرة الفعلية",
    "القدرة والطاقة",

    "هبوط الجهد",
    "أسباب سخونة الأسلاك",
    "الحمل الزائد",
    "القصر الكهربائي",
    "التسرب الكهربائي",
    "الحماية من التسرب",
    "أنظمة التأريض",
    "الربط الأرضي",
    "أنواع القواطع",
    "قراءة بيانات القاطع",

    "المحركات الكهربائية",
    "المروحة الكهربائية",
    "المضخة",
    "السخان الكهربائي",
    "الثلاجة",
    "الغسالة",
    "الإضاءة المنزلية",
    "LED",
    "المفاتيح المتعددة",
    "الدوائر المنزلية المركبة",

    "مبادئ قراءة المخططات",
    "رسم دائرة منزلية",
    "تحديد الأعطال",
    "منهجية التشخيص",
    "قراءة جهاز القياس",
    "حساب استهلاك جهاز",
    "حساب استهلاك المنزل",
    "كفاءة الأجهزة",
    "السلامة أثناء التشخيص",
    "مراجعة الوحدة",

    "الحماية من الصدمات",
    "الحماية من الحرائق",
    "تنظيم الأسلاك",
    "فحص الدائرة",
    "تحليل حالة كهربائية",
    "حل مشكلة كهربائية نظرية",
    "تطبيقات حسابية",
    "مراجعة شاملة",
    "استعداد الامتحان",
    "اختبار شامل للمستوى المتوسط"

];


const HOME_ADVANCED = [

    "تحليل الدوائر المتقدمة",
    "الشبكات الكهربائية",
    "حسابات الأحمال",
    "معامل القدرة",
    "القدرة الفعالة",
    "القدرة غير الفعالة",
    "القدرة الظاهرية",
    "الأنظمة أحادية الطور",
    "الأنظمة ثلاثية الطور",
    "التوازن بين الأطوار",

    "المحولات",
    "المحركات أحادية الطور",
    "المحركات ثلاثية الطور",
    "أنظمة التحكم",
    "الكونتاكتور",
    "الريليه",
    "الحماية الحرارية",
    "دوائر التحكم",
    "دوائر القدرة",
    "قراءة مخططات التحكم",

    "الطاقة الشمسية",
    "الألواح الشمسية",
    "العاكس Inverter",
    "البطاريات",
    "أنظمة التخزين",
    "حساب إنتاج الطاقة",
    "حساب الأحمال الشمسية",
    "أنظمة الحماية",
    "المولدات",
    "مصادر الطاقة",

    "تحليل الأعطال المتقدم",
    "قياس الدوائر",
    "تحليل هبوط الجهد",
    "تحليل الحمل الزائد",
    "تحليل القصر",
    "تحليل التسرب",
    "قراءة المخططات المتقدمة",
    "منهجية الصيانة",
    "التوثيق الكهربائي",
    "السلامة المهنية",

    "إدارة الأحمال",
    "كفاءة الطاقة",
    "جودة الطاقة",
    "أساسيات الشبكات",
    "التشخيص المنهجي",
    "تحليل الحالات",
    "مشاكل واقعية",
    "مراجعة متقدمة",
    "التحضير للامتحان النهائي",
    "اختبار شامل للمستوى المتقدم"

];


function makeTitles(base, type) {

    return base.map((title, index) => {

        if (type === "car") {

            return {
                ar: title,
                en: `Lesson ${index + 1}`
            };

        }

        return {
            ar: title,
            en: `Lesson ${index + 1}`
        };

    });

}


/* =========================================================
   CAR LESSONS
========================================================= */

const CAR_BEGINNER_TITLES = [

    "مقدمة في كهرباء السيارات",
    "بطارية السيارة",
    "الجهد في السيارة",
    "التيار الكهربائي في السيارة",
    "المقاومة",
    "القدرة الكهربائية",
    "الفيوزات",
    "الريليه",
    "الأسلاك",
    "الأرضي",

    "المارش",
    "الدينامو",
    "الإضاءة",
    "المصابيح",
    "البوق",
    "المروحة",
    "المساحات",
    "النوافذ الكهربائية",
    "القفل المركزي",
    "ولاعة السيارة",

    "مفتاح التشغيل",
    "دوائر السيارة",
    "الدائرة المفتوحة",
    "الدائرة المغلقة",
    "القصر الكهربائي",
    "ضعف البطارية",
    "فشل الشحن",
    "فحص الفيوز",
    "قراءة المخطط",
    "السلامة",

    "أعراض البطارية الضعيفة",
    "أعراض الدينامو",
    "أعراض المارش",
    "عطل المصباح",
    "عطل البوق",
    "عطل المروحة",
    "عطل المساحات",
    "عطل النافذة",
    "أساسيات الملتيميتر",
    "قياس الجهد بأمان",

    "قياس المقاومة",
    "اختبار الاستمرارية",
    "فهم القياسات",
    "تشخيص بسيط",
    "تتبع الدائرة",
    "حساب القدرة",
    "استهلاك الأجهزة",
    "مراجعة",
    "استعداد الاختبار",
    "اختبار شامل للمبتدئ"

];


const CAR_INTERMEDIATE_TITLES =
    HOME_INTERMEDIATE.map(
        (x, i) => `كهرباء السيارات: ${x}`
    );


const CAR_ADVANCED_TITLES =
    HOME_ADVANCED.map(
        (x, i) => `كهرباء السيارات المتقدمة: ${x}`
    );


const LESSON_DATABASE = {

    beginner: {

        home: makeTitles(
            HOME_BEGINNER,
            "home"
        ),

        car: makeTitles(
            CAR_BEGINNER_TITLES,
            "car"
        )

    },

    intermediate: {

        home: makeTitles(
            HOME_INTERMEDIATE,
            "home"
        ),

        car: makeTitles(
            CAR_INTERMEDIATE_TITLES,
            "car"
        )

    },

    advanced: {

        home: makeTitles(
            HOME_ADVANCED,
            "home"
        ),

        car: makeTitles(
            CAR_ADVANCED_TITLES,
            "car"
        )

    }

};


/* =========================================================
   PROGRESS
========================================================= */

function getProgress() {

    try {

        return JSON.parse(
            localStorage.getItem(PROGRESS_KEY)
        ) || {};

    } catch {

        return {};

    }

}


function saveProgress(progress) {

    localStorage.setItem(
        PROGRESS_KEY,
        JSON.stringify(progress)
    );

}


function trackKey() {

    return `${selectedLevel}_${selectedType}`;

}


function getTrackProgress() {

    const progress = getProgress();

    const key = trackKey();

    if (!progress[key]) {

        progress[key] = {
            completedLessons: [],
            passedUnits: [],
            finalPassed: false
        };

        saveProgress(progress);

    }

    return progress[key];

}


function isLessonCompleted(number) {

    const data = getTrackProgress();

    return data.completedLessons.includes(number);

}


function isUnitPassed(unit) {

    const data = getTrackProgress();

    return data.passedUnits.includes(unit);

}


function isFinalPassed() {

    return getTrackProgress().finalPassed === true;

}


/* =========================================================
   LESSON UNLOCKING
========================================================= */

function isLessonUnlocked(number) {

    if (number === 1) {
        return true;
    }


    if (!isLessonCompleted(number - 1)) {
        return false;
    }


    if (number > 5) {

        const requiredUnit =
            Math.floor((number - 1) / 5);

        if (!isUnitPassed(requiredUnit)) {
            return false;
        }

    }


    return true;

}


/* =========================================================
   ACADEMY NAVIGATION
========================================================= */

function openLessons() {

    showScreen("lessonsScreen");

    $("academyLevelScreen").classList.remove("hidden");
    $("academyTypeScreen").classList.add("hidden");
    $("academyCurriculumScreen").classList.add("hidden");

    renderAcademyLevels();

}


function backToLevels() {

    $("academyTypeScreen").classList.add("hidden");

    $("academyLevelScreen").classList.remove("hidden");

}


function backToTypes() {

    $("academyCurriculumScreen").classList.add("hidden");

    $("academyTypeScreen").classList.remove("hidden");

}


function renderAcademyLevels() {

    const container = $("academyLevels");

    if (!container) return;

    const lang = T[currentLanguage];

    container.innerHTML = "";


    Object.keys(LEVELS).forEach(level => {

        const button = document.createElement("button");

        button.className = "lesson-card";

        button.innerHTML = `
            <div class="lesson-number">
                ${level === "beginner" ? "1" :
                  level === "intermediate" ? "2" : "3"}
            </div>

            <h3>
                ${LEVELS[level].title[currentLanguage]}
            </h3>

            <p>
                ${currentLanguage === "ar"
                    ? "50 درساً منظماً"
                    : "50 structured lessons"}
            </p>
        `;

        button.onclick = () =>
            selectAcademyLevel(level);

        container.appendChild(button);

    });

}


function selectAcademyLevel(level) {

    selectedLevel = level;

    $("academyLevelScreen").classList.add("hidden");

    $("academyTypeScreen").classList.remove("hidden");

    renderAcademyTypes();

}


function renderAcademyTypes() {

    const container = $("academyTypes");

    container.innerHTML = "";


    Object.keys(TYPES).forEach(type => {

        const button = document.createElement("button");

        button.className = "lesson-card";

        button.innerHTML = `
            <div class="lesson-number">
                ${type === "home" ? "🏠" : "🚗"}
            </div>

            <h3>
                ${TYPES[type].title[currentLanguage]}
            </h3>

            <p>
                ${currentLanguage === "ar"
                    ? "50 درساً"
                    : "50 lessons"}
            </p>
        `;

        button.onclick = () =>
            selectAcademyType(type);

        container.appendChild(button);

    });

}


function selectAcademyType(type) {

    selectedType = type;

    $("academyTypeScreen").classList.add("hidden");

    $("academyCurriculumScreen").classList.remove("hidden");

    renderAcademyLessons();

}


/* =========================================================
   CURRICULUM
========================================================= */

function renderAcademyLessons() {

    if (!selectedLevel || !selectedType) return;

    const container = $("academyLessons");

    if (!container) return;

    const data =
        LESSON_DATABASE[selectedLevel][selectedType];

    const progress =
        getTrackProgress();

    container.innerHTML = "";


    const completed =
        progress.completedLessons.length;


    text(
        "academyCurrentLevel",
        LEVELS[selectedLevel].title[currentLanguage]
    );


    text(
        "academyProgressText",
        `${completed} / 50`
    );


    $("academyProgressFill").style.width =
        `${(completed / 50) * 100}%`;


    data.forEach((lesson, index) => {

        const number = index + 1;

        const unlocked =
            isLessonUnlocked(number);

        const done =
            isLessonCompleted(number);


        const card =
            document.createElement("button");

        card.className = "lesson-card";


        let status =
            done
                ? T[currentLanguage].completed
                : unlocked
                    ? T[currentLanguage].unlocked
                    : T[currentLanguage].locked;


        card.innerHTML = `

            <div class="lesson-number">
                ${number}
            </div>

            <h3>
                ${lesson[currentLanguage]}
            </h3>

            <p>
                ${status}
            </p>

        `;


        if (!unlocked) {

            card.style.opacity = "0.55";

            card.onclick = () => {

                alert(
                    currentLanguage === "ar"
                        ? "هذا الدرس مقفل. أكمل الدروس والامتحان المطلوب أولاً."
                        : "This lesson is locked. Complete the required lessons and exam first."
                );

            };

        } else {

            card.onclick = () =>
                openLesson(number);

        }


        container.appendChild(card);

    });

}


/* =========================================================
   LESSON DETAIL
========================================================= */

function openLesson(number) {

    if (!isLessonUnlocked(number)) return;

    selectedLesson = number;

    const lesson =
        LESSON_DATABASE[selectedLevel][selectedType]
        [number - 1];


    text(
        "lessonDetailNumber",
        `${T[currentLanguage].lesson} ${number}`
    );

    text(
        "lessonDetailTitle",
        lesson[currentLanguage]
    );


    $("lessonDetailContent").innerHTML =
        generateLessonContent(
            number,
            lesson[currentLanguage]
        );


    showScreen("lessonDetailScreen");

}


function generateLessonContent(number, title) {

    const lang = currentLanguage;

    if (lang === "ar") {

        return `
            <div class="info-box">

                <h3>📘 شرح الدرس</h3>

                <p>
                    في هذا الدرس سنتعرف على:
                    <strong>${title}</strong>.
                </p>

                <p>
                    الهدف هو فهم الفكرة الأساسية
                    بطريقة منظمة قبل الانتقال إلى
                    الدرس التالي.
                </p>

            </div>

            <div class="info-box">

                <h3>⚡ نقاط مهمة</h3>

                <ul>

                    <li>
                        افهم المصطلحات الأساسية.
                    </li>

                    <li>
                        اربط المعلومة بالتطبيقات الكهربائية.
                    </li>

                    <li>
                        راجع الدرس قبل الاختبار.
                    </li>

                </ul>

            </div>

            <div class="safety-notice">

                <strong>⚠️ السلامة أولاً</strong>

                <p>
                    لا تقم بتجارب على كهرباء المنزل
                    أو الأسلاك تحت الجهد. التطبيقات
                    العملية على الكهرباء الخطرة يجب
                    أن تتم مع شخص مؤهل.
                </p>

            </div>
        `;

    }


    return `
        <div class="info-box">

            <h3>📘 Lesson explanation</h3>

            <p>
                In this lesson we will learn:
                <strong>${title}</strong>.
            </p>

            <p>
                The goal is to understand the
                main concept before moving
                to the next lesson.
            </p>

        </div>

        <div class="info-box">

            <h3>⚡ Important points</h3>

            <ul>

                <li>
                    Understand the basic terms.
                </li>

                <li>
                    Connect the concept with
                    electrical applications.
                </li>

                <li>
                    Review before taking the test.
                </li>

            </ul>

        </div>

        <div class="safety-notice">

            <strong>⚠️ Safety first</strong>

            <p>
                Do not perform experiments on
                live household electricity.
                Dangerous practical work should
                be done with a qualified person.
            </p>

        </div>
    `;

}


/* =========================================================
   LESSON TEST
========================================================= */

function startLessonTest() {

    lessonQuestionIndex = 0;
    lessonScore = 0;
    selectedLessonAnswer = null;

    showScreen("lessonTestScreen");

    renderLessonQuestion();

}


function generateLessonQuestions() {

    const lesson =
        LESSON_DATABASE[selectedLevel]
        [selectedType][selectedLesson - 1];

    const title =
        lesson[currentLanguage];


    if (currentLanguage === "ar") {

        return [

            {
                q: `ما الموضوع الرئيسي في هذا الدرس؟`,
                answers: [
                    title,
                    "الطقس",
                    "الرياضيات فقط",
                    "التاريخ"
                ],
                correct: 0
            },

            {
                q: "ما الخطوة الأفضل قبل تطبيق أي معلومة كهربائية؟",
                answers: [
                    "فهم المعلومة واتباع قواعد السلامة",
                    "لمس الأسلاك",
                    "تجربة الكهرباء مباشرة",
                    "تجاهل التحذيرات"
                ],
                correct: 0
            },

            {
                q: "ماذا يجب أن تفعل إذا لم تفهم جزءاً من الدرس؟",
                answers: [
                    "تراجعه وتتعلم الأساسيات",
                    "تتجاهله",
                    "تنتقل مباشرة للنهاية",
                    "تخمن الإجابة"
                ],
                correct: 0
            },

            {
                q: "ما الهدف من أكاديمية الكهرباء؟",
                answers: [
                    "التعلم بشكل تدريجي",
                    "تجربة الكهرباء الخطرة",
                    "حفظ الكلمات فقط",
                    "تجاوز الدروس"
                ],
                correct: 0
            },

            {
                q: "متى تنتقل للدرس التالي؟",
                answers: [
                    "بعد اجتياز اختبار الدرس",
                    "قبل دراسة الدرس",
                    "عشوائياً",
                    "بدون اختبار"
                ],
                correct: 0
            }

        ];

    }


    return [

        {
            q: `What is the main topic of this lesson?`,
            answers: [
                title,
                "Weather",
                "History",
                "Sports"
            ],
            correct: 0
        },

        {
            q: "What should come before practical electrical work?",
            answers: [
                "Understanding and safety",
                "Touching wires",
                "Ignoring warnings",
                "Random testing"
            ],
            correct: 0
        },

        {
            q: "What should you do if you do not understand a lesson?",
            answers: [
                "Review it",
                "Ignore it",
                "Skip everything",
                "Guess"
            ],
            correct: 0
        },

        {
            q: "What is the goal of the academy?",
            answers: [
                "Progressive learning",
                "Dangerous experiments",
                "Memorizing only",
                "Skipping lessons"
            ],
            correct: 0
        },

        {
            q: "When should you move to the next lesson?",
            answers: [
                "After passing the lesson test",
                "Before studying",
                "Randomly",
                "Without a test"
            ],
            correct: 0
        }

    ];

}


function renderLessonQuestion() {

    const questions =
        generateLessonQuestions();

    const q =
        questions[lessonQuestionIndex];


    text(
        "lessonQuestionCounter",
        `${lessonQuestionIndex + 1} / ${questions.length}`
    );


    text(
        "lessonQuestion",
        q.q
    );


    const container =
        $("lessonAnswers");

    container.innerHTML = "";


    q.answers.forEach((answer, index) => {

        const button =
            document.createElement("button");

        button.className =
            "fault-option";

        button.textContent =
            answer;


        button.onclick = () => {

            document
                .querySelectorAll("#lessonAnswers button")
                .forEach(b =>
                    b.style.borderColor = ""
                );

            button.style.borderColor =
                "var(--primary)";

            selectedLessonAnswer = index;

        };


        container.appendChild(button);

    });


    text(
        "nextLessonQuestionButton",
        lessonQuestionIndex === questions.length - 1
            ? (currentLanguage === "ar" ? "إنهاء الاختبار" : "Finish Test")
            : T[currentLanguage].next
    );

}


function nextLessonQuestion() {

    if (selectedLessonAnswer === null) {

        alert(
            currentLanguage === "ar"
                ? "اختر إجابة أولاً."
                : "Choose an answer first."
        );

        return;
    }


    const questions =
        generateLessonQuestions();

    const q =
        questions[lessonQuestionIndex];


    if (selectedLessonAnswer === q.correct) {

        lessonScore += 20;

    }


    selectedLessonAnswer = null;


    if (
        lessonQuestionIndex <
        questions.length - 1
    ) {

        lessonQuestionIndex++;

        renderLessonQuestion();

    } else {

        finishLessonTest();

    }

}


function finishLessonTest() {

    text(
        "lessonScore",
        `${lessonScore}/100`
    );


    if (lessonScore >= 50) {

        const progress =
            getProgress();

        const key =
            trackKey();

        if (!progress[key]) {

            progress[key] = {
                completedLessons: [],
                passedUnits: [],
                finalPassed: false
            };

        }


        if (
            !progress[key].completedLessons
                .includes(selectedLesson)
        ) {

            progress[key].completedLessons.push(
                selectedLesson
            );

        }


        saveProgress(progress);


        text(
            "lessonResultIcon",
            "🎉"
        );

        text(
            "lessonResultMessage",
            getPerformanceMessage(lessonScore)
        );

    } else {

        text(
            "lessonResultIcon",
            "📖"
        );

        text(
            "lessonResultMessage",
            T[currentLanguage].review
        );

    }


    showScreen("lessonResultScreen");

}


function getPerformanceMessage(score) {

    const lang = T[currentLanguage];

    if (score === 100) return lang.excellent;

    if (score >= 90) return lang.veryGood;

    if (score >= 75) return lang.good;

    if (score >= 50) return lang.average;

    return lang.review;

}


function handleLessonResult() {

    if (lessonScore < 50) {

        openLesson(selectedLesson);

        return;

    }


    if (
        selectedLesson % 5 === 0 &&
        isUnitAvailable(
            selectedLesson / 5
        )
    ) {

        startUnitExam(
            selectedLesson / 5
        );

        return;

    }


    backToCurriculum();

}


/* =========================================================
   UNIT EXAMS
========================================================= */

function isUnitAvailable(unit) {

    return isLessonCompleted(unit * 5);

}


function startUnitExam(unit) {

    currentUnit = unit;

    unitQuestionIndex = 0;
    unitScore = 0;
    selectedUnitAnswer = null;

    showScreen("unitExamScreen");

    renderUnitQuestion();

}


function generateUnitQuestions() {

    const base =
        currentLanguage === "ar"
            ? "ما أهم هدف من دراسة هذه الوحدة؟"
            : "What is an important goal of studying this unit?";


    return [

        {
            q: base,
            answers:
                currentLanguage === "ar"
                    ? [
                        "فهم المفاهيم الأساسية",
                        "تجاهل السلامة",
                        "تجاوز الدروس",
                        "التجربة العشوائية"
                    ]
                    : [
                        "Understanding the concepts",
                        "Ignoring safety",
                        "Skipping lessons",
                        "Random testing"
                    ],
            correct: 0
        },

        {
            q:
                currentLanguage === "ar"
                    ? "ما القاعدة الأساسية في الكهرباء؟"
                    : "What is an important electrical rule?",
            answers:
                currentLanguage === "ar"
                    ? [
                        "السلامة أولاً",
                        "لمس الأسلاك",
                        "تجاهل القاطع",
                        "العمل بدون معرفة"
                    ]
                    : [
                        "Safety first",
                        "Touching wires",
                        "Ignoring breakers",
                        "Working without knowledge"
                    ],
            correct: 0
        },

        {
            q:
                currentLanguage === "ar"
                    ? "كيف تتعلم بشكل أفضل؟"
                    : "How do you learn best?",
            answers:
                currentLanguage === "ar"
                    ? [
                        "بالتدرج والمراجعة",
                        "بتجاوز الدروس",
                        "بالتخمين",
                        "بعدم الدراسة"
                    ]
                    : [
                        "Progressively with review",
                        "By skipping lessons",
                        "By guessing",
                        "Without studying"
                    ],
            correct: 0
        },

        {
            q:
                currentLanguage === "ar"
                    ? "ماذا تفعل إذا فشلت في الامتحان؟"
                    : "What should you do if you fail?",
            answers:
                currentLanguage === "ar"
                    ? [
                        "تراجع وتعيد الامتحان",
                        "تتوقف",
                        "تتجاوز الوحدة",
                        "تحذف التقدم"
                    ]
                    : [
                        "Review and retake it",
                        "Stop",
                        "Skip the unit",
                        "Delete progress"
                    ],
            correct: 0
        },

        {
            q:
                currentLanguage === "ar"
                    ? "ما النتيجة المطلوبة لاجتياز الوحدة؟"
                    : "What score is required to pass the unit?",
            answers: [
                "75/100",
                "25/100",
                "40/100",
                "10/100"
            ],
            correct: 0
        }

    ];

}


function renderUnitQuestion() {

    const questions =
        generateUnitQuestions();

    const q =
        questions[unitQuestionIndex];


    text(
        "unitExamUnit",
        `${T[currentLanguage].unit} ${currentUnit}`
    );


    text(
        "unitExamDescription",
        currentLanguage === "ar"
            ? "يجب الحصول على 75/100 أو أكثر."
            : "You need 75/100 or higher."
    );


    text(
        "unitExamQuestion",
        q.q
    );


    text(
        "nextUnitExamQuestionButton",
        unitQuestionIndex === questions.length - 1
            ? "إنهاء الامتحان"
            : T[currentLanguage].next
    );


    const container =
        $("unitExamAnswers");

    container.innerHTML = "";


    q.answers.forEach((answer, index) => {

        const button =
            document.createElement("button");

        button.className =
            "fault-option";

        button.textContent =
            answer;


        button.onclick = () => {

            document
                .querySelectorAll("#unitExamAnswers button")
                .forEach(b =>
                    b.style.borderColor = ""
                );

            button.style.borderColor =
                "var(--primary)";

            selectedUnitAnswer = index;

        };


        container.appendChild(button);

    });

}


function nextUnitExamQuestion() {

    if (selectedUnitAnswer === null) {

        alert(
            currentLanguage === "ar"
                ? "اختر إجابة أولاً."
                : "Choose an answer first."
        );

        return;

    }


    const questions =
        generateUnitQuestions();

    const q =
        questions[unitQuestionIndex];


    if (
        selectedUnitAnswer === q.correct
    ) {

        unitScore += 20;

    }


    selectedUnitAnswer = null;


    if (
        unitQuestionIndex <
        questions.length - 1
    ) {

        unitQuestionIndex++;

        renderUnitQuestion();

    } else {

        finishUnitExam();

    }

}


function finishUnitExam() {

    text(
        "unitExamScore",
        `${unitScore}/100`
    );


    if (unitScore >= 75) {

        const progress =
            getProgress();

        const key =
            trackKey();


        if (!progress[key].passedUnits.includes(
            currentUnit
        )) {

            progress[key].passedUnits.push(
                currentUnit
            );

        }


        saveProgress(progress);


        text(
            "unitExamResultIcon",
            "🎉"
        );

        text(
            "unitExamResultMessage",
            T[currentLanguage].passed
        );

    } else {

        text(
            "unitExamResultIcon",
            "📖"
        );

        text(
            "unitExamResultMessage",
            currentLanguage === "ar"
                ? "لم تحصل على 75/100. راجع الوحدة وأعد الامتحان."
                : "You scored below 75/100. Review the unit and retake the exam."
        );

    }


    showScreen("unitExamResultScreen");

}


function handleUnitResult() {

    if (unitScore < 75) {

        startUnitExam(currentUnit);

        return;

    }


    if (
        currentUnit === 10 &&
        isFinalExamAvailable()
    ) {

        startFinalExam();

        return;

    }


    backToCurriculum();

}


/* =========================================================
   FINAL EXAM
========================================================= */

function isFinalExamAvailable() {

    return (
        isLessonCompleted(50) &&
        isUnitPassed(10)
    );

}


function startFinalExam() {

    finalQuestionIndex = 0;
    finalScore = 0;
    selectedFinalAnswer = null;

    showScreen("finalExamScreen");

    renderFinalQuestion();

}


function generateFinalQuestions() {

    return Array.from(
        { length: 10 },
        (_, index) => ({

            q:
                currentLanguage === "ar"
                    ? `السؤال ${index + 1}: ما أهم قاعدة في التعلم الكهربائي؟`
                    : `Question ${index + 1}: What is an important electrical learning rule?`,

            answers:
                currentLanguage === "ar"
                    ? [
                        "السلامة والفهم الصحيح",
                        "التجربة العشوائية",
                        "تجاهل المخاطر",
                        "تجاوز الأساسيات"
                    ]
                    : [
                        "Safety and correct understanding",
                        "Random testing",
                        "Ignoring risks",
                        "Skipping basics"
                    ],

            correct: 0

        })
    );

}


function renderFinalQuestion() {

    const questions =
        generateFinalQuestions();

    const q =
        questions[finalQuestionIndex];


    text(
        "finalExamLevel",
        LEVELS[selectedLevel].title[currentLanguage]
    );


    text(
        "finalExamDescription",
        T[currentLanguage].finalExamDescription
    );


    text(
        "finalExamQuestion",
        q.q
    );


    text(
        "nextFinalExamQuestionButton",
        finalQuestionIndex === questions.length - 1
            ? "إنهاء الامتحان"
            : T[currentLanguage].next
    );


    const container =
        $("finalExamAnswers");

    container.innerHTML = "";


    q.answers.forEach((answer, index) => {

        const button =
            document.createElement("button");

        button.className =
            "fault-option";

        button.textContent =
            answer;


        button.onclick = () => {

            document
                .querySelectorAll("#finalExamAnswers button")
                .forEach(b =>
                    b.style.borderColor = ""
                );

            button.style.borderColor =
                "var(--primary)";

            selectedFinalAnswer = index;

        };


        container.appendChild(button);

    });

}


function nextFinalExamQuestion() {

    if (selectedFinalAnswer === null) {

        alert(
            currentLanguage === "ar"
                ? "اختر إجابة أولاً."
                : "Choose an answer first."
        );

        return;

    }


    const questions =
        generateFinalQuestions();

    const q =
        questions[finalQuestionIndex];


    if (
        selectedFinalAnswer === q.correct
    ) {

        finalScore += 10;

    }


    selectedFinalAnswer = null;


    if (
        finalQuestionIndex <
        questions.length - 1
    ) {

        finalQuestionIndex++;

        renderFinalQuestion();

    } else {

        finishFinalExam();

    }

}


function finishFinalExam() {

    text(
        "levelScore",
        `${finalScore}/100`
    );


    if (finalScore >= 75) {

        const progress =
            getProgress();

        const key =
            trackKey();


        progress[key].finalPassed =
            true;


        saveProgress(progress);


        text(
            "levelResultIcon",
            "🏆"
        );

        text(
            "levelResultMessage",
            T[currentLanguage].passedLevel
        );


    } else {

        text(
            "levelResultIcon",
            "📖"
        );

        text(
            "levelResultMessage",
            currentLanguage === "ar"
                ? "لم تنجح. راجع المستوى وأعد الامتحان."
                : "You did not pass. Review the level and retake the exam."
        );

    }


    showScreen("levelResultScreen");

}


function handleNextLevel() {

    if (finalScore < 75) {

        startFinalExam();

        return;

    }


    const levels =
        Object.keys(LEVELS);

    const currentIndex =
        levels.indexOf(selectedLevel);


    if (
        currentIndex <
        levels.length - 1
    ) {

        selectedLevel =
            levels[currentIndex + 1];

        selectedType = null;

        openLessons();

    } else {

        showScreen(
            "academyCompleteScreen"
        );

    }

}


/* =========================================================
   BACK TO CURRICULUM
========================================================= */

function backToCurriculum() {

    showScreen("lessonsScreen");

    $("academyLevelScreen").classList.add("hidden");

    $("academyTypeScreen").classList.add("hidden");

    $("academyCurriculumScreen").classList.remove("hidden");

    renderAcademyLessons();

}


function backToLessonDetail() {

    openLesson(selectedLesson);

}


/* =========================================================
   CALCULATOR
========================================================= */

function selectCalculatorMode(mode) {

    calculatorMode = mode;

    updateCalculator();

}


function updateCalculator() {

    const formula =
        $("calculatorFormula");

    const inputs =
        $("calculatorInputs");

    if (!formula || !inputs) return;


    if (calculatorMode === "power") {

        formula.innerHTML =
            "P = V × I";

        inputs.innerHTML = `
            <label>V — Voltage</label>
            <input
                id="inputVoltage"
                type="number"
                inputmode="decimal"
                placeholder="Voltage">

            <label>I — Current</label>
            <input
                id="inputCurrent"
                type="number"
                inputmode="decimal"
                placeholder="Current">
        `;

    }


    else if (calculatorMode === "voltage") {

        formula.innerHTML =
            "V = P ÷ I";

        inputs.innerHTML = `
            <label>P — Power</label>
            <input
                id="inputPower"
                type="number"
                inputmode="decimal"
                placeholder="Power">

            <label>I — Current</label>
            <input
                id="inputCurrent"
                type="number"
                inputmode="decimal"
                placeholder="Current">
        `;

    }


    else if (calculatorMode === "current") {

        formula.innerHTML =
            "I = P ÷ V";

        inputs.innerHTML = `
            <label>P — Power</label>
            <input
                id="inputPower"
                type="number"
                inputmode="decimal"
                placeholder="Power">

            <label>V — Voltage</label>
            <input
                id="inputVoltage"
                type="number"
                inputmode="decimal"
                placeholder="Voltage">
        `;

    }


    else {

        formula.innerHTML =
            "R = V ÷ I";

        inputs.innerHTML = `
            <label>V — Voltage</label>
            <input
                id="inputVoltage"
                type="number"
                inputmode="decimal"
                placeholder="Voltage">

            <label>I — Current</label>
            <input
                id="inputCurrent"
                type="number"
                inputmode="decimal"
                placeholder="Current">
        `;

    }


    $("calculatorResult").innerHTML = "";

}


function calculateElectricalValue() {

    let result;


    const value = id => {

        const element = $(id);

        return element
            ? Number(element.value)
            : 0;

    };


    if (calculatorMode === "power") {

        const V = value("inputVoltage");
        const I = value("inputCurrent");

        if (V <= 0 || I <= 0) {
            showCalculatorError();
            return;
        }

        result = V * I;

    }


    else if (calculatorMode === "voltage") {

        const P = value("inputPower");
        const I = value("inputCurrent");

        if (P <= 0 || I <= 0) {
            showCalculatorError();
            return;
        }

        result = P / I;

    }


    else if (calculatorMode === "current") {

        const P = value("inputPower");
        const V = value("inputVoltage");

        if (P <= 0 || V <= 0) {
            showCalculatorError();
            return;
        }

        result = P / V;

    }


    else {

        const V = value("inputVoltage");
        const I = value("inputCurrent");

        if (V <= 0 || I <= 0) {
            showCalculatorError();
            return;
        }

        result = V / I;

    }


    $("calculatorResult").innerHTML = `
        <h3>${T[currentLanguage].result}</h3>

        <div class="result-value">
            ${Number(result.toFixed(4))}
        </div>
    `;

}


function showCalculatorError() {

    $("calculatorResult").innerHTML = `
        <p>
            ${
                currentLanguage === "ar"
                    ? "أدخل قيماً صحيحة أكبر من صفر."
                    : "Enter valid values greater than zero."
            }
        </p>
    `;

}


function openCalculator() {

    showScreen("calculatorScreen");

    updateCalculator();

}


/* =========================================================
   FAULT DIAGNOSIS
========================================================= */

const FAULTS = [

    {
        ar: "المصباح لا يشتغل",
        en: "Lamp does not work",
        detailAr:
            "قد يكون السبب في المصباح أو المفتاح أو مصدر التغذية أو وجود مشكلة في الدائرة.",
        detailEn:
            "The cause may be the lamp, switch, power supply or another part of the circuit."
    },

    {
        ar: "المقبس لا يعمل",
        en: "Socket does not work",
        detailAr:
            "تحقق من وجود التغذية بشكل آمن. إذا كانت المشكلة في تمديدات المنزل، يجب الاستعانة بشخص مؤهل.",
        detailEn:
            "Check the power supply safely. For household wiring problems, ask a qualified person."
    },

    {
        ar: "القاطع يفصل",
        en: "Breaker trips",
        detailAr:
            "قد يكون السبب حملاً زائداً أو قصراً أو مشكلة في جهاز كهربائي.",
        detailEn:
            "The cause may be overload, short circuit or a faulty appliance."
    },

    {
        ar: "المفتاح لا يعمل",
        en: "Switch does not work",
        detailAr:
            "قد تكون المشكلة في المفتاح نفسه أو في الدائرة المرتبطة به.",
        detailEn:
            "The switch itself or its circuit may have a problem."
    },

    {
        ar: "البطارية ضعيفة",
        en: "Weak battery",
        detailAr:
            "في السيارة، البطارية الضعيفة قد تسبب صعوبة في تشغيل السيارة أو ضعف بعض الأنظمة.",
        detailEn:
            "A weak car battery can cause starting problems and weak electrical systems."
    },

    {
        ar: "الفيوز يحترق",
        en: "Fuse blows",
        detailAr:
            "قد يدل ذلك على تيار زائد أو قصر في الدائرة. لا تستبدل الفيوز بقيمة غير مناسبة.",
        detailEn:
            "It can indicate excessive current or a short circuit. Never replace a fuse with an unsuitable rating."
    },

    {
        ar: "المروحة لا تعمل",
        en: "Fan does not work",
        detailAr:
            "قد يكون السبب في التغذية أو المفتاح أو المحرك أو الحماية.",
        detailEn:
            "The cause may be the supply, switch, motor or protection."
    },

    {
        ar: "البوق لا يعمل",
        en: "Horn does not work",
        detailAr:
            "في السيارة، افحص المعلومات الأساسية مثل الفيوز والريليه بطريقة آمنة.",
        detailEn:
            "In a car, basic items such as the fuse and relay can be checked safely."
    }

];


function openFaults() {

    showScreen("faultsScreen");

    $("faultsListScreen").classList.remove("hidden");

    $("faultDetailScreen").classList.add("hidden");

    renderFaults();

}


function renderFaults() {

    const container =
        $("faultsList");

    if (!container) return;

    container.innerHTML = "";


    FAULTS.forEach((fault, index) => {

        const button =
            document.createElement("button");

        button.className =
            "fault-option";

        button.textContent =
            currentLanguage === "ar"
                ? fault.ar
                : fault.en;


        button.onclick = () =>
            openFaultDetail(index);


        container.appendChild(button);

    });

}


function openFaultDetail(index) {

    const fault = FAULTS[index];

    $("faultsListScreen").classList.add("hidden");

    $("faultDetailScreen").classList.remove("hidden");


    $("faultDetail").innerHTML = `

        <div class="info-box">

            <h3>
                ${
                    currentLanguage === "ar"
                        ? fault.ar
                        : fault.en
                }
            </h3>

            <p>
                ${
                    currentLanguage === "ar"
                        ? fault.detailAr
                        : fault.detailEn
                }
            </p>

        </div>

        <div class="safety-notice">

            <strong>
                ⚠️ ${
                    currentLanguage === "ar"
                        ? "السلامة"
                        : "Safety"
                }
            </strong>

            <p>
                ${
                    currentLanguage === "ar"
                        ? "لا تعمل على دوائر كهربائية خطرة أو تحت الجهد. اطلب مساعدة شخص مؤهل."
                        : "Do not work on dangerous live circuits. Ask a qualified person for help."
                }
            </p>

        </div>
    `;

}


function backToFaultsList() {

    $("faultDetailScreen").classList.add("hidden");

    $("faultsListScreen").classList.remove("hidden");

}


function openFaultsFromHome() {
    openFaults();
}


/* =========================================================
   LAWS
========================================================= */

const LAWS = [

    {
        symbol: "P = V × I",
        ar: "قانون القدرة الكهربائية",
        en: "Electrical power law",
        detailAr:
            "القدرة الكهربائية تساوي الجهد مضروباً في التيار. الوحدة هي الواط W.",
        detailEn:
            "Electrical power equals voltage multiplied by current. The unit is watt (W)."
    },

    {
        symbol: "V = I × R",
        ar: "قانون أوم",
        en: "Ohm's law",
        detailAr:
            "الجهد يساوي التيار مضروباً في المقاومة.",
        detailEn:
            "Voltage equals current multiplied by resistance."
    },

    {
        symbol: "I = V ÷ R",
        ar: "حساب التيار",
        en: "Current calculation",
        detailAr:
            "يمكن حساب التيار بقسمة الجهد على المقاومة.",
        detailEn:
            "Current can be calculated by dividing voltage by resistance."
    },

    {
        symbol: "R = V ÷ I",
        ar: "حساب المقاومة",
        en: "Resistance calculation",
        detailAr:
            "يمكن حساب المقاومة بقسمة الجهد على التيار.",
        detailEn:
            "Resistance can be calculated by dividing voltage by current."
    }

];


function openLaws() {

    showScreen("lawsScreen");

    $("lawsList").classList.remove("hidden");

    $("lawDetailScreen").classList.add("hidden");

    renderLaws();

}


function renderLaws() {

    const container =
        $("lawsList");

    container.innerHTML = "";


    const grid =
        document.createElement("div");

    grid.className =
        "symbol-grid";


    LAWS.forEach((law, index) => {

        const card =
            document.createElement("button");

        card.className =
            "symbol-card";

        card.innerHTML = `

            <span class="symbol">
                ${law.symbol}
            </span>

            <p>
                ${
                    currentLanguage === "ar"
                        ? law.ar
                        : law.en
                }
            </p>

        `;

        card.onclick = () =>
            openLawDetail(index);

        grid.appendChild(card);

    });


    container.appendChild(grid);

}


function openLawDetail(index) {

    const law = LAWS[index];

    $("lawsList").classList.add("hidden");

    $("lawDetailScreen").classList.remove("hidden");


    $("lawDetail").innerHTML = `

        <div class="info-box">

            <div class="formula">
                ${law.symbol}
            </div>

            <h3>
                ${
                    currentLanguage === "ar"
                        ? law.ar
                        : law.en
                }
            </h3>

            <p>
                ${
                    currentLanguage === "ar"
                        ? law.detailAr
                        : law.detailEn
                }
            </p>

        </div>
    `;

}


function backToLawsList() {

    $("lawDetailScreen").classList.add("hidden");

    $("lawsList").classList.remove("hidden");

}


/* =========================================================
   INFORMATION
========================================================= */

const INFORMATION = [

    {
        ar: "الجهد الكهربائي",
        en: "Voltage",
        detailAr:
            "الجهد هو فرق الطاقة الكهربائية بين نقطتين، ويقاس بالفولت V.",
        detailEn:
            "Voltage is the electrical potential difference between two points and is measured in volts."
    },

    {
        ar: "التيار الكهربائي",
        en: "Current",
        detailAr:
            "التيار هو حركة الشحنات الكهربائية، ويقاس بالأمبير A.",
        detailEn:
            "Current is the flow of electric charge and is measured in amperes."
    },

    {
        ar: "المقاومة",
        en: "Resistance",
        detailAr:
            "المقاومة تعيق مرور التيار الكهربائي، وتقاس بالأوم Ω.",
        detailEn:
            "Resistance opposes current flow and is measured in ohms."
    },

    {
        ar: "القدرة",
        en: "Power",
        detailAr:
            "القدرة هي معدل استعمال الطاقة الكهربائية، وتقاس بالواط W.",
        detailEn:
            "Power is the rate of electrical energy use and is measured in watts."
    },

    {
        ar: "الفاز",
        en: "Phase",
        detailAr:
            "الفاز هو الموصل الذي يحمل الجهد في الدوائر المنزلية.",
        detailEn:
            "Phase is the conductor that carries voltage in typical household circuits."
    },

    {
        ar: "النتر",
        en: "Neutral",
        detailAr:
            "النتر هو موصل رجوع في كثير من الدوائر الكهربائية المنزلية.",
        detailEn:
            "Neutral is a return conductor in many household electrical circuits."
    },

    {
        ar: "الأرضي",
        en: "Earth",
        detailAr:
            "التأريض جزء مهم من الحماية الكهربائية ضد بعض حالات الخطأ.",
        detailEn:
            "Earthing is an important part of electrical protection."
    },

    {
        ar: "القاطع الكهربائي",
        en: "Circuit breaker",
        detailAr:
            "القاطع جهاز حماية يفصل الدائرة عند ظروف معينة مثل التيار الزائد.",
        detailEn:
            "A circuit breaker protects a circuit by disconnecting it under certain fault conditions."
    },

    {
        ar: "الفيوز",
        en: "Fuse",
        detailAr:
            "الفيوز عنصر حماية يقطع الدائرة عندما يمر تيار أعلى من الحد المصمم له.",
        detailEn:
            "A fuse protects a circuit by opening when current exceeds its designed limit."
    },

    {
        ar: "الملتيميتر",
        en: "Multimeter",
        detailAr:
            "جهاز قياس يمكن أن يستخدم لقياس قيم كهربائية مختلفة حسب نوع الجهاز وطريقة استعماله.",
        detailEn:
            "A multimeter can measure different electrical quantities depending on the device and setup."
    }

];


function openInformation() {

    showScreen("informationScreen");

    $("informationListScreen").classList.remove("hidden");

    $("informationDetailScreen").classList.add("hidden");

    renderInformation();

}


function renderInformation() {

    const container =
        $("informationList");

    if (!container) return;

    container.innerHTML = "";


    INFORMATION.forEach((info, index) => {

        const button =
            document.createElement("button");

        button.className =
            "fault-option";

        button.textContent =
            currentLanguage === "ar"
                ? info.ar
                : info.en;


        button.onclick = () =>
            openInformationDetail(index);


        container.appendChild(button);

    });

}


function openInformationDetail(index) {

    const info =
        INFORMATION[index];


    $("informationListScreen")
        .classList.add("hidden");

    $("informationDetailScreen")
        .classList.remove("hidden");


    $("informationDetail").innerHTML = `

        <div class="info-box">

            <h3>
                ${
                    currentLanguage === "ar"
                        ? info.ar
                        : info.en
                }
            </h3>

            <p>
                ${
                    currentLanguage === "ar"
                        ? info.detailAr
                        : info.detailEn
                }
            </p>

        </div>
    `;

}


function backToInformationList() {

    $("informationDetailScreen")
        .classList.add("hidden");

    $("informationListScreen")
        .classList.remove("hidden");

}


/* =========================================================
   SETTINGS
========================================================= */

function openSettings() {

    showScreen("settingsScreen");

    text(
        "currentLanguage",
        currentLanguage === "ar"
            ? "العربية"
            : "English"
    );

}


function changeLanguageFromSettings() {

    showScreen("languageScreen");

}


function resetAcademyProgress() {

    localStorage.removeItem(
        PROGRESS_KEY
    );

    alert(
        currentLanguage === "ar"
            ? "تم مسح تقدم الأكاديمية."
            : "Academy progress cleared."
    );

}


/* =========================================================
   STARTUP
========================================================= */

document.addEventListener(
    "DOMContentLoaded",
    () => {

        applyTheme();

        applyLanguage();


        const savedLanguage =
            localStorage.getItem(
                LANGUAGE_KEY
            );


        if (savedLanguage) {

            currentLanguage =
                savedLanguage;

            applyLanguage();

            showScreen("homeScreen");

        } else {

            showScreen("welcomeScreen");


            setTimeout(() => {

                showScreen("languageScreen");

            }, 1000);

        }

    }
);


/* =========================================================
   GLOBAL FUNCTIONS
========================================================= */

window.selectLanguage =
    selectLanguage;

window.continueFromLanguage =
    continueFromLanguage;

window.toggleTheme =
    toggleTheme;

window.goHome =
    goHome;

window.openLessons =
    openLessons;

window.backToLevels =
    backToLevels;

window.backToTypes =
    backToTypes;

window.openLesson =
    openLesson;

window.startLessonTest =
    startLessonTest;

window.nextLessonQuestion =
    nextLessonQuestion;

window.handleLessonResult =
    handleLessonResult;

window.startUnitExam =
    startUnitExam;

window.nextUnitExamQuestion =
    nextUnitExamQuestion;

window.handleUnitResult =
    handleUnitResult;

window.startFinalExam =
    startFinalExam;

window.nextFinalExamQuestion =
    nextFinalExamQuestion;

window.handleNextLevel =
    handleNextLevel;

window.backToCurriculum =
    backToCurriculum;

window.backToLessonDetail =
    backToLessonDetail;

window.selectCalculatorMode =
    selectCalculatorMode;

window.calculateElectricalValue =
    calculateElectricalValue;

window.openCalculator =
    openCalculator;

window.openFaults =
    openFaults;

window.backToFaultsList =
    backToFaultsList;

window.openLaws =
    openLaws;

window.backToLawsList =
    backToLawsList;

window.openInformation =
    openInformation;

window.backToInformationList =
    backToInformationList;

window.openSettings =
    openSettings;

window.changeLanguageFromSettings =
    changeLanguageFromSettings;

window.resetAcademyProgress =
    resetAcademyProgress;


/* =========================================================
   END OF SCRIPT
========================================================= */