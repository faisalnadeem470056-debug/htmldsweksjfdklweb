let state = {
  ore: 0,

  buildings: [
    {
      id: 'pick',
      name: 'Pioche en bois',
      icon: '⛏️',
      baseCost: 15,
      cps: 0.1,
      count: 0
    },
    {
      id: 'villager',
      name: 'Villageois mineur',
      icon: '🧑',
      baseCost: 100,
      cps: 1,
      count: 0
    },
    {
      id: 'cart',
      name: 'Chariot de mine',
      icon: '🛒',
      baseCost: 1100,
      cps: 8,
      count: 0
    },
    {
      id: 'furnace',
      name: 'Four à fondre',
      icon: '🔥',
      baseCost: 12000,
      cps: 47,
      count: 0
    },
    {
      id: 'golem',
      name: 'Golem de fer',
      icon: '🤖',
      baseCost: 130000,
      cps: 260,
      count: 0
    }
  ],

  stats: {
    totalEarned: 0,
    totalClicks: 0,
    playSeconds: 0
  },

  // Heure à laquelle le joueur a quitté le jeu
  lastSaveTime: Date.now()
};

let buyAmount = 1;
let gameStarted = false;


// ==============================
// ÉLÉMENTS HTML
// ==============================

const welcomeScreen =
  document.getElementById('welcomeScreen');

const startBtn =
  document.getElementById('startBtn');

const game =
  document.querySelector('.app');

const tabbar =
  document.querySelector('.tabbar');

const oreCount =
  document.getElementById('oreCount');

const cpsDisplay =
  document.getElementById('cpsDisplay');

const shopList =
  document.getElementById('shopList');

const blockBtn =
  document.getElementById('blockBtn');

const buy1Btn =
  document.getElementById('buy1Btn');

const buy10Btn =
  document.getElementById('buy10Btn');

const statTotal =
  document.getElementById('statTotal');

const statClicks =
  document.getElementById('statClicks');

const statTime =
  document.getElementById('statTime');


// ==============================
// AU DÉMARRAGE
// ==============================

game.style.display = 'none';
tabbar.style.display = 'none';


// ==============================
// FORMAT DES NOMBRES
// ==============================

function formatNumber(n) {

  if (n < 1000) {
    return Math.floor(n).toString();
  }

  const units = [
    'K',
    'M',
    'B',
    'T',
    'Qa',
    'Qi'
  ];

  let unitIndex = -1;

  while (
    n >= 1000 &&
    unitIndex < units.length - 1
  ) {
    n /= 1000;
    unitIndex++;
  }

  return n.toFixed(2) + units[unitIndex];
}


function formatCps(n) {

  if (n < 1000) {
    return n.toFixed(1);
  }

  return formatNumber(n);
}


// ==============================
// PRIX
// ==============================

function getCost(building, count) {

  return Math.ceil(
    building.baseCost *
    Math.pow(1.15, count)
  );
}


function getCostForAmount(building, amount) {

  let total = 0;

  for (let i = 0; i < amount; i++) {

    total += getCost(
      building,
      building.count + i
    );
  }

  return total;
}


// ==============================
// CPS TOTAL
// ==============================

function getTotalCps() {

  return state.buildings.reduce(
    (sum, building) =>
      sum +
      building.cps *
      building.count,
    0
  );
}


// ==============================
// ACHETER UN BÂTIMENT
// ==============================

function buyBuilding(id) {

  const building =
    state.buildings.find(
      b => b.id === id
    );

  if (!building) return;

  const cost =
    getCostForAmount(
      building,
      buyAmount
    );

  if (state.ore >= cost) {

    state.ore -= cost;

    building.count += buyAmount;

    render();

    save();
  }
}


// ==============================
// ACHAT 1 / 10
// ==============================

function setBuyAmount(amount) {

  buyAmount = amount;

  buy1Btn.classList.toggle(
    'active',
    amount === 1
  );

  buy10Btn.classList.toggle(
    'active',
    amount === 10
  );

  renderShop();
}


// ==============================
// BOUTIQUE
// ==============================

function renderShop() {

  shopList.innerHTML = '';

  state.buildings.forEach(building => {

    const cost =
      getCostForAmount(
        building,
        buyAmount
      );

    const affordable =
      state.ore >= cost;

    const div =
      document.createElement('div');

    div.className =
      `item ${affordable ? '' : 'disabled'}`;

    div.innerHTML = `

      <div class="item-left">

        <div class="item-icon">
          ${building.icon}
        </div>

        <div class="item-info">

          <h3>
            ${building.name}
            (${building.count})
          </h3>

          <p>
            ${building.cps} minerai/s chacun
          </p>

        </div>

      </div>

      <button
        class="buyBtn"
        ${affordable ? '' : 'disabled'}
      >
        ${formatNumber(cost)} ⛏️
      </button>
    `;

    const buyButton =
      div.querySelector('.buyBtn');

    buyButton.addEventListener(
      'click',
      () => buyBuilding(building.id)
    );

    shopList.appendChild(div);
  });
}


// ==============================
// STATISTIQUES
// ==============================

function renderStats() {

  statTotal.textContent =
    formatNumber(
      state.stats.totalEarned
    );

  statClicks.textContent =
    state.stats.totalClicks;

  const seconds =
    state.stats.playSeconds;

  const hours =
    Math.floor(seconds / 3600);

  const minutes =
    Math.floor(
      (seconds % 3600) / 60
    );

  const secs =
    seconds % 60;

  statTime.textContent =
    `${hours}:` +
    `${minutes.toString().padStart(2, '0')}:` +
    `${secs.toString().padStart(2, '0')}`;
}


// ==============================
// AFFICHAGE
// ==============================

function render() {

  oreCount.textContent =
    `${formatNumber(state.ore)} minerai`;

  cpsDisplay.textContent =
    `${formatCps(getTotalCps())} minerai/seconde`;

  renderShop();

  renderStats();
}


// ==============================
// ANIMATION PIOCHES
// ==============================

function spawnSwarm(x, y) {

  const count = 10;

  for (let i = 0; i < count; i++) {

    const el =
      document.createElement('div');

    el.className =
      'swarm-icon';

    el.textContent =
      '⛏️';

    const angle =
      (Math.PI * 2 * i) /
      count +
      Math.random() * 0.5;

    const distance =
      70 +
      Math.random() * 50;

    const dx =
      Math.cos(angle) *
      distance;

    const dy =
      Math.sin(angle) *
      distance;

    el.style.left =
      x + 'px';

    el.style.top =
      y + 'px';

    el.style.setProperty(
      '--dx',
      dx + 'px'
    );

    el.style.setProperty(
      '--dy',
      dy + 'px'
    );

    el.style.setProperty(
      '--rot',
      (Math.random() * 360 - 180) +
      'deg'
    );

    document.body.appendChild(el);

    setTimeout(
      () => el.remove(),
      700
    );
  }
}


// ==============================
// TEXTE FLOTTANT
// ==============================

function spawnFloatText(
  x,
  y,
  text
) {

  const el =
    document.createElement('div');

  el.className =
    'float';

  el.textContent =
    text;

  el.style.left =
    x + 'px';

  el.style.top =
    y + 'px';

  document.body.appendChild(el);

  setTimeout(
    () => el.remove(),
    800
  );
}


// ==============================
// GAINS HORS LIGNE
// ==============================

function calculateOfflineGain() {

  if (!state.lastSaveTime) {
    state.lastSaveTime = Date.now();
    return 0;
  }

  const now = Date.now();

  const offlineMilliseconds =
    now - state.lastSaveTime;

  const offlineSeconds =
    Math.max(
      0,
      offlineMilliseconds / 1000
    );

  const cps =
    getTotalCps();

  const offlineGain =
    cps * offlineSeconds;

  return offlineGain;
}


// ==============================
// CHARGER LA SAUVEGARDE
// ==============================

function loadSave() {

  const saved =
    localStorage.getItem(
      'minerSave'
    );

  if (!saved) {
    return false;
  }

  try {

    const loaded =
      JSON.parse(saved);

    if (
      typeof loaded.ore === 'number'
    ) {
      state.ore =
        loaded.ore;
    }

    if (
      Array.isArray(
        loaded.buildings
      )
    ) {

      loaded.buildings.forEach(
        savedBuilding => {

          const building =
            state.buildings.find(
              b =>
                b.id ===
                savedBuilding.id
            );

          if (
            building &&
            typeof savedBuilding.count ===
              'number'
          ) {

            building.count =
              savedBuilding.count;
          }
        }
      );
    }

    if (loaded.stats) {

      state.stats = {
        totalEarned:
          Number(
            loaded.stats.totalEarned
          ) || 0,

        totalClicks:
          Number(
            loaded.stats.totalClicks
          ) || 0,

        playSeconds:
          Number(
            loaded.stats.playSeconds
          ) || 0
      };
    }

    state.lastSaveTime =
      Number(
        loaded.lastSaveTime
      ) || Date.now();

    return true;

  } catch (error) {

    console.error(
      'Erreur de sauvegarde :',
      error
    );

    return false;
  }
}


// ==============================
// BOUTON COMMENCER
// ==============================

startBtn.addEventListener(
  'click',
  () => {

    console.log(
      'MinerClicker : jeu démarré'
    );

    const hadSave =
      loadSave();

    // ==========================
    // GAINS HORS LIGNE
    // ==========================

    if (hadSave) {

      const offlineGain =
        calculateOfflineGain();

      if (offlineGain > 0) {

        state.ore +=
          offlineGain;

        state.stats.totalEarned +=
          offlineGain;

        console.log(
          'Minerai gagné hors ligne :',
          offlineGain
        );
      }
    }

    state.lastSaveTime =
      Date.now();

    gameStarted = true;

    welcomeScreen.style.display =
      'none';

    game.style.display =
      'block';

    tabbar.style.display =
      'flex';

    save();

    render();
  }
);


// ==============================
// BOUTON DE LA MINE
// ==============================

blockBtn.addEventListener(
  'click',
  (event) => {

    if (!gameStarted) return;

    blockBtn.blur();

    // 1 clic = 1 minerai
    state.ore += 1;

    state.stats.totalEarned += 1;

    state.stats.totalClicks += 1;

    spawnFloatText(
      event.clientX,
      event.clientY,
      '+1'
    );

    spawnSwarm(
      event.clientX,
      event.clientY
    );

    render();

    save();
  }
);


// ==============================
// RETIRER LE FOCUS AU TOUCHER
// ==============================

blockBtn.addEventListener(
  'touchend',
  () => {

    setTimeout(() => {
      blockBtn.blur();
    }, 0);

  },
  { passive: true }
);


// ==============================
// BOUTONS ACHAT
// ==============================

buy1Btn.addEventListener(
  'click',
  () => {
    setBuyAmount(1);
  }
);


buy10Btn.addEventListener(
  'click',
  () => {
    setBuyAmount(10);
  }
);


// ==============================
// NAVIGATION
// ==============================

document
  .querySelectorAll('.tab-btn')
  .forEach(button => {

    button.addEventListener(
      'click',
      () => {

        document
          .querySelectorAll('.tab-btn')
          .forEach(
            btn =>
              btn.classList.remove('active')
          );

        document
          .querySelectorAll('.view')
          .forEach(
            view =>
              view.style.display = 'none'
          );

        button.classList.add('active');

        const target =
          document.getElementById(
            button.dataset.tab
          );

        if (target) {
          target.style.display =
            'block';
        }
      }
    );
  });


// ==============================
// PRODUCTION AUTOMATIQUE
// ==============================

setInterval(
  () => {

    if (!gameStarted) return;

    const gain =
      getTotalCps() / 10;

    state.ore += gain;

    state.stats.totalEarned += gain;

    render();

  },
  100
);


// ==============================
// TEMPS DE JEU
// ==============================

setInterval(
  () => {

    if (!gameStarted) return;

    state.stats.playSeconds++;

    renderStats();

  },
  1000
);


// ==============================
// SAUVEGARDE
// ==============================

function save() {

  state.lastSaveTime =
    Date.now();

  localStorage.setItem(
    'minerSave',
    JSON.stringify(state)
  );
}


// ==============================
// SAUVEGARDE AVANT DE QUITTER
// ==============================

window.addEventListener(
  'beforeunload',
  () => {

    if (gameStarted) {
      save();
    }

  }
);


// ==============================
// SAUVEGARDE AUTOMATIQUE
// ==============================

setInterval(
  () => {

    if (gameStarted) {
      save();
    }

  },
  5000
);


// ==============================
// AFFICHAGE INITIAL
// ==============================

render();