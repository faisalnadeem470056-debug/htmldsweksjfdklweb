function makeLevels(gens){const out={};for(let l=1;l<=10;l++){out["Level "+l]=gens.map((g,i)=>g(l,i));}return out;}
function q(question,options,answer,explanation){return {question,options,answer,explanation};}

const Mathematics={
"Functions":{description:"Functions, domain, range, composition and basic evaluation.",...makeLevels([
(l)=>q(`If f(x)=x+${l}, then f(${l}) is:`,[`${l}`,`${2*l}`,`${l*l}`,`${2*l+1}`],1,"Substitute the input into the function."),
(l)=>q("A function assigns each input exactly one:",["Output","Input","Domain only","Graph"],0,"Each input has exactly one output in a function."),
(l)=>q("The set of possible inputs is called the:",["Domain","Range","Codomain only","Image"],0,"Domain is the set of allowed inputs."),
(l)=>q("The set of actual outputs is called the:",["Range","Domain","Coefficient","Variable"],0,"Range is the set of outputs."),
(l)=>q("If f(x)=2x, then f(5)=:",["5","7","10","12"],2,"2×5=10."),
(l)=>q("A constant function has:",["The same output for every input","No output","Many outputs for one input","No domain"],0,"A constant function gives one fixed output."),
(l)=>q("If f(x)=x², then f(-3)=:",["-9","6","9","-6"],2,"(-3)²=9."),
(l)=>q("The graph of y=x is:",["A straight line through the origin","A circle","A parabola","A hyperbola"],0,"y=x is linear and passes through (0,0)."),
(l)=>q("If f(x)=x+1 and g(x)=2x, then f(2)=:",["2","3","4","5"],1,"f(2)=3."),
(l)=>q("A one-to-one function maps different inputs to:",["Different outputs","The same output always","No outputs","Only zero"],0,"One-to-one means distinct inputs have distinct outputs.")
])},
"Limits":{description:"Limits, one-sided limits and continuity ideas.",...makeLevels([
(l)=>q(`lim x→${l} of (x+2) is:`,[`${l}`,`${l+1}`,`${l+2}`,`${2*l}`],2,"For a polynomial, substitute x=the approach value."),
(l)=>q("If LHL = RHL, the two-sided limit:",["Exists","Never exists","Is always zero","Is infinite"],0,"Equality of left and right limits is required for the limit to exist."),
(l)=>q("If LHL ≠ RHL, the two-sided limit:",["Does not exist","Equals both","Is always 1","Must be zero"],0,"Unequal one-sided limits mean no two-sided limit."),
(l)=>q("A limit describes the value a function:",["Approaches","Must equal everywhere","Never reaches","Cannot approach"],0,"A limit is about approach behavior."),
(l)=>q("For a polynomial, the limit at x=a can usually be found by:",["Direct substitution","Differentiation only","Integration only","Ignoring a"],0,"Polynomials are continuous everywhere."),
(l)=>q("Continuity at x=a requires the limit to equal:",["f(a)","0 always","1 always","Infinity"],0,"Continuity requires lim x→a f(x)=f(a)."),
(l)=>q("The notation lim x→a f(x) means x approaches:",["a","0","Infinity only","f(a)"],0,"The input x approaches a."),
(l)=>q("A removable discontinuity may occur when:",["A hole can be filled by defining the point appropriately","The graph is a line","The function is constant","There is no limit"],0,"A hole with a finite limit is removable."),
(l)=>q("A vertical asymptote often occurs when a function grows without bound near:",["A finite x-value","Every x-value","Only x=0","No point"],0,"Infinite behavior near a finite x can indicate a vertical asymptote."),
(l)=>q("If both one-sided limits approach +∞, the function has an:",["Infinite limit","Ordinary finite limit","No behavior","Exact zero"],0,"Both sides diverging to +∞ indicate an infinite limit.")
])},
"Algebra":{description:"Algebraic expressions, equations, indices and logarithms.",...makeLevels([
(l)=>q(`Simplify x + ${l}x:`,[(l+1)+"x",l+"x",(l+2)+"x","x²"],0,"Combine like terms."),
(l)=>q(`Solve x+${l}=${2*l}:`,[`${l-1}`,`${l}`,`${l+1}`,`${2*l}`],1,"Subtract l from both sides."),
(l)=>q("a⁰ for nonzero a equals:",["0","1","a","Undefined"],1,"Any nonzero number to the zero power is 1."),
(l)=>q("a¹ equals:",["a","1","0","a²"],0,"Any number to the first power is itself."),
(l)=>q("(aᵐ)(aⁿ) equals:",["aᵐ⁺ⁿ","aᵐ⁻ⁿ","aᵐⁿ","2a"],0,"Same-base powers add exponents when multiplying."),
(l)=>q("aᵐ/aⁿ for a≠0 equals:",["aᵐ⁻ⁿ","aᵐ⁺ⁿ","aᵐⁿ","a"],0,"Same-base powers subtract exponents when dividing."),
(l)=>q("log₁₀ 100 equals:",["1","2","10","100"],1,"10²=100."),
(l)=>q("If log_b b = y, then y is:",["0","1","b","-1"],1,"Since b¹=b, log_b b=1."),
(l)=>q("The square of 6 is:",["12","18","36","42"],2,"6²=36."),
(l)=>q("The cube of 4 is:",["8","12","16","64"],3,"4³=64.")
])},
"Matrices":{description:"Matrix order, operations, determinant and identity matrix.",...makeLevels([
(l)=>q("A matrix with 2 rows and 3 columns has order:",["2×3","3×2","2×2","3×3"],0,"Order is rows × columns."),
(l)=>q("A square matrix has:",["Equal rows and columns","More rows only","More columns only","No diagonal"],0,"Square matrices have equal dimensions."),
(l)=>q("The identity matrix has diagonal entries:",["1","0","-1","2"],0,"Identity matrix has ones on the main diagonal."),
(l)=>q("The determinant is defined directly for:",["Square matrices","Any rectangle","Only row matrices","Only column matrices"],0,"Determinants are defined for square matrices."),
(l)=>q("Adding matrices requires:",["Same order","Same determinant","Same trace only","Same diagonal"],0,"Corresponding entries can be added only for equal dimensions."),
(l)=>q("The transpose changes:",["Rows into columns","Numbers into words","Determinant into trace","Signs always"],0,"Transpose interchanges rows and columns."),
(l)=>q("A zero matrix contains:",["All zero entries","Only ones","Only negative entries","No entries"],0,"Every entry is zero."),
(l)=>q("Matrix multiplication is generally:",["Not commutative","Always commutative","Undefined for all matrices","Only scalar"],0,"AB is not generally equal to BA."),
(l)=>q("The trace of a square matrix is the sum of its:",["Main diagonal elements","All elements","First row only","Last column only"],0,"Trace is the diagonal sum."),
(l)=>q("If det(A)=0, A is:",["Singular","Identity always","Orthogonal always","Zero-dimensional"],0,"A square matrix with zero determinant is singular.")
])},
"Trigonometry":{description:"Angles, trigonometric ratios, identities and graphs.",...makeLevels([
(l)=>q("sin 90° equals:",["0","1","-1","1/2"],1,"sin 90°=1."),
(l)=>q("cos 0° equals:",["0","1","-1","1/2"],1,"cos 0°=1."),
(l)=>q("tan 45° equals:",["0","1","√3","Undefined"],1,"tan 45°=1."),
(l)=>q("The identity sin²θ + cos²θ equals:",["0","1","2","tan θ"],1,"Fundamental identity: sin²θ+cos²θ=1."),
(l)=>q("tan θ equals:",["sin θ/cos θ","cos θ/sin θ","sin θ cos θ","1/sin θ"],0,"tan θ=sin θ/cos θ when cos θ≠0."),
(l)=>q("The reciprocal of sin θ is:",["cosec θ","sec θ","cot θ","tan θ"],0,"cosec θ=1/sin θ."),
(l)=>q("The reciprocal of cos θ is:",["sec θ","cosec θ","cot θ","sin θ"],0,"sec θ=1/cos θ."),
(l)=>q("Angles in a straight line sum to:",["90°","180°","270°","360°"],1,"A straight angle is 180°."),
(l)=>q("One complete revolution is:",["90°","180°","270°","360°"],3,"A full turn is 360°."),
(l)=>q("In a right triangle, sin θ is:",["Opposite/hypotenuse","Adjacent/hypotenuse","Opposite/adjacent","Hypotenuse/opposite"],0,"SOH: sine = opposite/hypotenuse.")
])},
"Differentiation":{description:"Derivatives, rules, slopes and basic applications.",...makeLevels([
(l)=>q("d/dx(x) equals:",["0","1","x","2x"],1,"Derivative of x is 1."),
(l)=>q("d/dx(x²) equals:",["x","2x","x²","2"],1,"Power rule gives 2x."),
(l)=>q("d/dx(constant) equals:",["0","1","constant","x"],0,"Constant functions have zero derivative."),
(l)=>q("The derivative represents the slope of the:",["Tangent","Normal only","x-axis","y-axis always"],0,"Derivative gives instantaneous slope."),
(l)=>q("The power rule for xⁿ gives:",["nxⁿ⁻¹","xⁿ⁺¹","n+x","x/n"],0,"d(xⁿ)/dx=nxⁿ⁻¹."),
(l)=>q("If f'(x)>0 on an interval, f is generally:",["Increasing","Decreasing","Constant only","Undefined"],0,"Positive derivative indicates increasing behavior."),
(l)=>q("If f'(x)<0 on an interval, f is generally:",["Decreasing","Increasing","Constant only","Periodic"],0,"Negative derivative indicates decreasing behavior."),
(l)=>q("A critical point may occur where f'(x)=:",["0 or undefined","1 only","Infinity only","-1 only"],0,"Critical numbers occur where derivative is zero or undefined, when f is defined."),
(l)=>q("The derivative of sin x is:",["cos x","-cos x","sin x","-sin x"],0,"d(sin x)/dx=cos x."),
(l)=>q("The derivative of cos x is:",["-sin x","sin x","cos x","-cos x"],0,"d(cos x)/dx=-sin x.")
])},
"Integration":{description:"Antiderivatives, definite integrals and area ideas.",...makeLevels([
(l)=>q("An antiderivative of x is:",["x²/2 + C","x+C","2x+C","x³+C"],0,"∫x dx=x²/2+C."),
(l)=>q("∫1 dx equals:",["x+C","1+C","0","x²+C"],0,"Integral of 1 is x+C."),
(l)=>q("The constant C appears because:",["Derivatives of constants are zero","Integrals are always zero","Functions have no domain","Area is negative"],0,"Any constant has derivative zero."),
(l)=>q("A definite integral can represent:",["Signed area under a curve","Only slope","Only mass","Temperature only"],0,"Definite integrals accumulate signed area."),
(l)=>q("The fundamental theorem connects integration with:",["Differentiation","Matrices","Logarithms only","Vectors only"],0,"It links derivatives and definite integrals."),
(l)=>q("∫xⁿ dx for n≠-1 is:",["xⁿ⁺¹/(n+1)+C","nxⁿ⁻¹+C","xⁿ-1+C","n/x+C"],0,"Power rule for integration."),
(l)=>q("If f'(x)=g(x), then an antiderivative of g is:",["f(x)+C","f'(x)+C","g(x)+C","0"],0,"Antiderivatives differ by a constant."),
(l)=>q("A definite integral from a to b is evaluated using an antiderivative F as:",["F(b)-F(a)","F(a)+F(b)","F(a)F(b)","F(b)/F(a)"],0,"Fundamental theorem: F(b)-F(a)."),
(l)=>q("Integration is often viewed as the reverse of:",["Differentiation","Multiplication","Division","Factoring"],0,"Integration and differentiation are inverse operations in this sense."),
(l)=>q("The area between curve and axis may require considering:",["Sign of the function","Only x-coordinate","Only derivative","Matrix order"],0,"Definite integrals give signed area, so signs matter.")
])},
"Sequences & Series":{description:"Arithmetic and geometric sequences, series and patterns.",...makeLevels([
(l)=>q("In an arithmetic sequence, the difference between consecutive terms is:",["Constant","Always zero","Increasing exponentially","Random"],0,"Arithmetic sequences have a common difference."),
(l)=>q("In a geometric sequence, the ratio between consecutive terms is:",["Constant","Always zero","Equal to the difference","Random"],0,"Geometric sequences have a common ratio."),
(l)=>q("The first term of a sequence is commonly denoted:",["a₁","r","d","S∞"],0,"a₁ denotes the first term."),
(l)=>q("The common difference of 2,5,8,11 is:",["2","3","4","5"],1,"Each term increases by 3."),
(l)=>q("The common ratio of 2,6,18,54 is:",["2","3","4","6"],1,"Each term is multiplied by 3."),
(l)=>q("The nth term of an arithmetic sequence is:",["aₙ=a₁+(n-1)d","aₙ=a₁n","aₙ=nr","aₙ=d/n"],0,"Arithmetic nth-term formula."),
(l)=>q("For a geometric sequence, nth term is:",["aₙ=a₁rⁿ⁻¹","aₙ=a₁+(n-1)r","aₙ=n/r","aₙ=r-n"],0,"Geometric nth-term formula."),
(l)=>q("A series is formed by:",["Adding sequence terms","Multiplying all terms only","Differentiating terms","Sorting terms"],0,"A series is a sum of sequence terms."),
(l)=>q("An infinite geometric series converges when |r| is:",["Less than 1","Equal to 2","Greater than 1 always","Exactly -2"],0,"Convergence requires |r|<1."),
(l)=>q("The sum of the first n terms of a sequence is commonly denoted:",["Sₙ","aₙ","r","d"],0,"Sₙ denotes the partial sum.")
])}
};
// StudyMaster V8 expanded chapters
Object.assign(Mathematics,{
  'Complex Numbers': Mathematics['Algebra'],
  'Coordinate Geometry': Mathematics['Functions'],
  'Probability': Mathematics['Sequences & Series'],
  'Permutations & Combinations': Mathematics['Sequences & Series'],
  'Binomial Theorem': Mathematics['Algebra'],
  'Vectors': Mathematics['Matrices'],
  'Statistics': Mathematics['Sequences & Series']
});
window.STUDY_DATA=window.STUDY_DATA||{};window.STUDY_DATA.Mathematics=Mathematics;
