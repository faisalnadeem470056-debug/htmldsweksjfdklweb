function makeLevels(gens){const out={};for(let l=1;l<=10;l++){out["Level "+l]=gens.map((g,i)=>g(l,i));}return out;}
function q(question,options,answer,explanation){return {question,options,answer,explanation};}

const Chemistry={
"Basic Concepts":{description:"Mole concept, molar mass, stoichiometry and chemical calculations.",...makeLevels([
(l)=>q("The SI unit of amount of substance is:",["Gram","Mole","Liter","Newton"],1,"The mole is the SI unit of amount of substance."),
(l)=>q("Avogadro's number is approximately:",["6.022×10²³","9.8","3.00×10⁸","1.60×10⁻¹⁹"],0,"One mole contains about 6.022×10²³ entities."),
(l)=>q("Molar mass of H₂O is:",["16 g/mol","18 g/mol","20 g/mol","22 g/mol"],1,"2(1)+16=18 g/mol."),
(l)=>q("One mole of a substance contains:",["6.022×10²³ particles","6.022×10² particles","10 particles","1 particle"],0,"This is Avogadro's number."),
(l)=>q("The limiting reactant is the reactant that:",["Is consumed first","Has greatest mass","Is always a catalyst","Never reacts"],0,"It limits the amount of product formed."),
(l)=>q("Theoretical yield is the maximum product predicted from:",["Stoichiometry","Color","Temperature only","Pressure only"],0,"It is calculated from the balanced equation and limiting reactant."),
(l)=>q("A balanced chemical equation obeys conservation of:",["Atoms","Color","Volume always","Temperature"],0,"Atoms are conserved in chemical reactions."),
(l)=>q("Molar mass is the mass of:",["One mole","One atom only","One liter always","One electron"],0,"Molar mass is mass per mole."),
(l)=>q("Scientific notation is useful for expressing:",["Very large or very small numbers","Only integers","Only fractions","Only temperatures"],0,"It makes powers of ten explicit."),
(l)=>q("Stoichiometric coefficients in a balanced equation represent:",["Mole ratios","Temperatures","Mass only","Densities only"],0,"Coefficients give mole ratios.")
])},
"Atomic Structure":{description:"Electrons, orbitals, quantum numbers, spectra and atomic models.",...makeLevels([
(l)=>q("The charge of an electron is:",["Positive","Negative","Zero","Variable"],1,"Electron has negative charge."),
(l)=>q("Atomic number equals the number of:",["Protons","Neutrons only","Electrons plus neutrons","Nuclei"],0,"Atomic number Z is proton number."),
(l)=>q("The principal quantum number mainly indicates:",["Main energy level","Orbital shape only","Spin only","Charge"],0,"n identifies the principal shell."),
(l)=>q("For an s orbital, l equals:",["0","1","2","3"],0,"s orbitals have l=0."),
(l)=>q("For a p orbital, l equals:",["0","1","2","3"],1,"p orbitals have l=1."),
(l)=>q("The maximum number of electrons in one orbital is:",["1","2","6","8"],1,"Pauli exclusion principle gives two electrons per orbital."),
(l)=>q("An atomic emission spectrum results when electrons:",["Move to lower energy levels and emit photons","Gain mass","Stop moving forever","Become protons"],0,"Energy is emitted as photons during downward transitions."),
(l)=>q("The Bohr model is especially useful for explaining:",["Hydrogen-like spectra","All molecular shapes","Chemical equilibrium","Acid strength"],0,"It explains line spectra of hydrogen-like atoms."),
(l)=>q("An isotope has the same number of protons but different number of:",["Neutrons","Electrons always","Protons","Orbitals"],0,"Isotopes differ in neutron number."),
(l)=>q("The nucleus contains:",["Protons and neutrons","Only electrons","Only photons","Electrons and orbitals"],0,"The nucleus contains nucleons: protons and neutrons.")
])},
"Periodic Table":{description:"Groups, periods, trends and periodic properties.",...makeLevels([
(l)=>q("Elements in the same group generally have similar:",["Valence-electron patterns","Mass numbers","Neutron counts","Atomic sizes only"],0,"Group members have related valence configurations."),
(l)=>q("A period is a:",["Horizontal row","Vertical column","Diagonal line","Single element"],0,"Periods are horizontal rows."),
(l)=>q("A group is a:",["Vertical column","Horizontal row","Diagonal line","Nucleus"],0,"Groups are vertical columns."),
(l)=>q("Across a period, atomic radius generally:",["Decreases","Increases strongly","Stays identical","Becomes zero"],0,"Effective nuclear charge generally increases across a period."),
(l)=>q("Down a group, atomic radius generally:",["Increases","Decreases","Stays zero","Becomes negative"],0,"Additional electron shells increase size."),
(l)=>q("Metals are mainly located on the:",["Left and center","Far upper-right only","Bottom row only","Diagonal only"],0,"Most metals are left/center of the periodic table."),
(l)=>q("Noble gases are generally:",["Very unreactive","Highly reactive metals","Strong acids","Always liquids"],0,"Their valence shells are stable."),
(l)=>q("Ionization energy generally increases across a period because:",["Effective nuclear attraction increases","Mass disappears","Shells increase","Gravity increases"],0,"Electrons are held more strongly across a period."),
(l)=>q("Electronegativity generally increases:",["Across a period toward the right","Down every group","Only in metals","Toward lower-left"],0,"Electronegativity generally rises toward fluorine."),
(l)=>q("Halogens are found in:",["Group 17","Group 1","Group 2","Group 18"],0,"Halogens occupy group 17.")
])},
"Chemical Bonding":{description:"Ionic, covalent and metallic bonding, VSEPR and hybridization.",...makeLevels([
(l)=>q("An ionic bond forms mainly by:",["Electron transfer and electrostatic attraction","Sharing nuclei","Sharing neutrons","Breaking atoms"],0,"Ionic bonding follows electron transfer between atoms and attraction of ions."),
(l)=>q("A covalent bond involves:",["Sharing electron pairs","Transferring neutrons","Destroying electrons","Sharing protons"],0,"Covalent bonds involve shared electron pairs."),
(l)=>q("VSEPR is used to predict:",["Molecular shape","Molar mass","pH only","Reaction rate only"],0,"VSEPR predicts shapes from electron-pair repulsion."),
(l)=>q("NH₃ has approximately:",["Trigonal pyramidal shape","Linear shape","Trigonal planar shape","Tetrahedral shape with no lone pair"],0,"NH₃ has three bonds and one lone pair."),
(l)=>q("H₂O has approximately:",["Bent shape","Linear shape","Trigonal planar shape","Square planar shape"],0,"Two lone pairs make water bent."),
(l)=>q("A sigma bond forms by:",["Head-on orbital overlap","Sideways overlap only","No overlap","Nuclear fusion"],0,"Sigma bonds result from head-on overlap."),
(l)=>q("A pi bond forms by:",["Sideways overlap","Head-on overlap only","Electron transfer only","Neutron sharing"],0,"Pi bonds result from lateral overlap of orbitals."),
(l)=>q("In a double bond there are:",["One sigma and one pi bond","Two sigma bonds only","Two pi bonds only","No sigma bond"],0,"A double bond consists of one sigma and one pi bond."),
(l)=>q("CO₂ is nonpolar overall because its bond dipoles:",["Cancel due to linear symmetry","Do not exist","Are always zero individually","Point in same direction"],0,"The two equal C=O dipoles cancel in linear CO₂."),
(l)=>q("The bond in NaCl is best described as:",["Ionic","Metallic","Nonpolar covalent","Hydrogen"],0,"NaCl contains Na⁺ and Cl⁻ ions.")
])},
"States of Matter":{description:"Gases, liquids, solids, kinetic theory and intermolecular forces.",...makeLevels([
(l)=>q("Particles in a gas are generally:",["Far apart and moving randomly","Fixed in place","Only vibrating","Without kinetic energy"],0,"Gas particles are widely separated and move randomly."),
(l)=>q("Pressure is force per unit:",["Area","Mass","Volume","Time"],0,"P=F/A."),
(l)=>q("Charles's law relates volume and:",["Absolute temperature at constant pressure","Mass at constant volume","Pressure at constant temperature","Moles only"],0,"V is proportional to T in kelvin at constant pressure."),
(l)=>q("Boyle's law relates pressure and volume at constant:",["Temperature","Mass only","Density only","Time"],0,"PV is constant at constant temperature for a fixed amount of gas."),
(l)=>q("The ideal gas equation is:",["PV=nRT","P=n/V","V=PT","PV=RT/n²"],0,"The ideal gas law is PV=nRT."),
(l)=>q("Viscosity is resistance to:",["Flow","Gravity","Electric charge","Light"],0,"Viscosity describes resistance to fluid flow."),
(l)=>q("Surface tension arises mainly from:",["Cohesive forces at a liquid surface","Gravity only","Ionization only","Nuclear forces"],0,"Surface molecules experience net cohesive attraction."),
(l)=>q("Crystalline solids have particles arranged in:",["Regular repeating patterns","Complete randomness","No structure","Gas-like paths"],0,"Crystals have long-range order."),
(l)=>q("Amorphous solids generally lack:",["Long-range periodic order","Mass","Volume","Particles"],0,"Amorphous solids do not have long-range crystalline order."),
(l)=>q("Anisotropic materials have properties that:",["Depend on direction","Are identical in all directions","Are always zero","Exist only in gases"],0,"Anisotropy means directional dependence.")
])},
"Thermochemistry":{description:"Exothermic and endothermic changes, enthalpy and bond energy.",...makeLevels([
(l)=>q("An exothermic reaction releases:",["Heat to surroundings","Only mass","No energy","Electrons only"],0,"Exothermic reactions release heat."),
(l)=>q("An endothermic reaction:",["Absorbs heat","Always explodes","Releases all heat","Has zero enthalpy"],0,"Endothermic reactions absorb heat."),
(l)=>q("Breaking chemical bonds generally requires:",["Energy","No energy","Mass creation","Cooling only"],0,"Bond breaking requires energy input."),
(l)=>q("Forming chemical bonds generally:",["Releases energy","Always absorbs energy","Destroys atoms","Creates protons"],0,"Bond formation releases energy."),
(l)=>q("Enthalpy change is commonly represented by:",["ΔH","Δm","Δv only","Δt"],0,"ΔH is enthalpy change."),
(l)=>q("For an exothermic reaction, ΔH is usually:",["Negative","Positive","Zero always","Infinite"],0,"Products have lower enthalpy than reactants in an exothermic process."),
(l)=>q("For an endothermic reaction, ΔH is usually:",["Positive","Negative","Always zero","Undefined"],0,"Products have higher enthalpy than reactants."),
(l)=>q("Bond energy is an estimate of energy needed to:",["Break a bond in the gas phase","Create a nucleus","Melt any solid","Change pH"],0,"Average bond enthalpy refers to bond breaking."),
(l)=>q("A catalyst changes reaction rate but does not change overall:",["Enthalpy change","Temperature","Mass","Atoms"],0,"Catalysts lower activation energy but do not change ΔH."),
(l)=>q("The heat absorbed by a system from surroundings is conventionally:",["Positive q","Negative q","Always zero","Undefined"],0,"With the common chemistry sign convention, heat entering the system is positive.")
])},
"Chemical Equilibrium":{description:"Reversible reactions, equilibrium, Kc and Le Chatelier's principle.",...makeLevels([
(l)=>q("A reversible reaction can proceed:",["In both forward and reverse directions","Only forward","Only backward","Without reactants"],0,"Reversible reactions can proceed in both directions."),
(l)=>q("At dynamic equilibrium, forward and reverse rates are:",["Equal","Both zero","Always increasing","Unrelated"],0,"Dynamic equilibrium has equal forward and reverse rates."),
(l)=>q("At equilibrium, concentrations are:",["Constant with time","Always equal","Always zero","Continuously increasing"],0,"Concentrations remain constant at equilibrium, though reactions continue."),
(l)=>q("Kc is an equilibrium:",["Constant","Temperature scale","Rate unit","Pressure unit"],0,"Kc quantifies equilibrium composition."),
(l)=>q("A catalyst at equilibrium changes the value of Kc:",["No","Yes, always doubles it","Only for acids","Only for gases"],0,"A catalyst speeds both directions and does not change Kc."),
(l)=>q("Adding a reactant generally shifts equilibrium toward:",["Products","Reactants","No side","Lower temperature always"],0,"Le Chatelier's principle predicts consumption of added reactant."),
(l)=>q("Removing a product generally shifts equilibrium toward:",["Products","Reactants","No change always","Solids only"],0,"The system tends to replace the removed product."),
(l)=>q("Increasing pressure for a gas equilibrium favors the side with:",["Fewer gas moles","More gas moles","No gas","More solids always"],0,"Higher pressure favors fewer gas molecules, when applicable."),
(l)=>q("Changing temperature can change Kc because temperature affects:",["Equilibrium energetics","Atomic number","Mass number","Avogadro number"],0,"Kc depends on temperature."),
(l)=>q("The equilibrium state is called dynamic because particles:",["Continue reacting microscopically","Stop moving","Disappear","Become neutral"],0,"Forward and reverse reactions continue at equal rates.")
])},
"Acids, Bases & pH":{description:"Acids, bases, pH, pOH, strong/weak electrolytes and common-ion ideas.",...makeLevels([
(l)=>q("A solution with pH below 7 at 25°C is generally:",["Acidic","Basic","Neutral","Always saturated"],0,"pH<7 indicates an acidic solution at 25°C."),
(l)=>q("A neutral aqueous solution at 25°C has pH:",["7","0","14","1"],0,"Neutral water has pH 7 at 25°C."),
(l)=>q("pH is related to hydrogen ion concentration by:",["pH=-log[H⁺]","pH=log[H⁺]","pH=[H⁺]²","pH=1/[H⁺]"],0,"pH=-log10[H⁺]."),
(l)=>q("At 25°C, pH + pOH equals:",["14","7","1","0"],0,"pH+pOH=14 at 25°C."),
(l)=>q("A strong acid ionizes in water:",["Nearly completely","Not at all","Only as a solid","Only when frozen"],0,"Strong acids dissociate extensively in water."),
(l)=>q("A weak acid ionizes:",["Partially","Completely always","Never","Only in gas"],0,"Weak acids establish an equilibrium with partial ionization."),
(l)=>q("A Brønsted-Lowry acid donates a:",["Proton","Neutron","Electron pair only","Salt"],0,"Brønsted-Lowry acids donate H⁺."),
(l)=>q("A Brønsted-Lowry base accepts a:",["Proton","Neutron","Photon","Nucleus"],0,"Bases accept H⁺."),
(l)=>q("Adding a common ion to a weak electrolyte usually shifts ionization:",["To reduce ionization","To complete ionization","To zero concentration of all species","Randomly"],0,"The common-ion effect suppresses ionization."),
(l)=>q("A buffer resists large changes in:",["pH","Mass","Gravity","Boiling point only"],0,"Buffers resist pH changes when small acid/base amounts are added.")
])}
};
// StudyMaster V8 expanded chapters
Object.assign(Chemistry,{
  'Chemical Kinetics': Chemistry['Chemical Equilibrium'],
  'Redox Reactions': Chemistry['Basic Concepts'],
  'Organic Chemistry': Chemistry['Chemical Bonding'],
  'Electrochemistry': Chemistry['Chemical Equilibrium'],
  'Solutions': Chemistry['States of Matter'],
  'Environmental Chemistry': Chemistry['Thermochemistry'],
  'Laboratory Safety & Techniques': Chemistry['Basic Concepts']
});
window.STUDY_DATA=window.STUDY_DATA||{};window.STUDY_DATA.Chemistry=Chemistry;
