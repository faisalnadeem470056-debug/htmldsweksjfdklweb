function makeLevels(gens){const out={};for(let l=1;l<=10;l++){out["Level "+l]=gens.map((g,i)=>g(l,i));}return out;}
function q(question,options,answer,explanation){return {question,options,answer,explanation};}

const English={
"Subject–Verb Agreement":{description:"Agreement rules for singular and plural subjects.",...makeLevels([
(l)=>q("He ___ to school every day.",["go","goes","going","gone"],1,"A singular subject takes 'goes' in the present simple."),
(l)=>q("They ___ football every Sunday.",["plays","play","playing","played"],1,"Plural subject 'they' takes 'play'."),
(l)=>q("Each student ___ a book.",["have","has","having","are"],1,"'Each' is singular, so 'has' is correct."),
(l)=>q("The students ___ ready.",["is","are","was","has"],1,"Plural 'students' takes 'are'."),
(l)=>q("Neither Ali nor his friends ___ late.",["is","are","was","has"],1,"With neither...nor, the verb agrees with the nearer subject 'friends'."),
(l)=>q("The list of names ___ on the table.",["are","is","were","have"],1,"The head subject is singular 'list'."),
(l)=>q("Mathematics ___ my favorite subject.",["are","is","were","have"],1,"The subject 'Mathematics' is singular here."),
(l)=>q("There ___ many reasons.",["is","are","was","has"],1,"The real subject 'many reasons' is plural."),
(l)=>q("Everyone ___ responsible.",["are","is","were","have"],1,"Indefinite pronoun 'everyone' is singular."),
(l)=>q("A pair of shoes ___ under the bed.",["are","is","were","have"],1,"The head noun 'pair' is singular.")
])},
"Tenses":{description:"Present, past, future and perfect tense forms.",...makeLevels([
(l)=>q("She ___ her homework every evening.",["do","does","did","doing"],1,"Simple present with 'she' uses 'does'."),
(l)=>q("They ___ yesterday.",["leave","left","leaving","will leave"],1,"'Yesterday' indicates simple past."),
(l)=>q("I ___ my work already.",["finish","finished","have finished","am finish"],2,"Present perfect is used with 'already' for a completed action with present relevance."),
(l)=>q("He ___ tomorrow.",["came","comes yesterday","will come","coming"],2,"'Tomorrow' points to future time."),
(l)=>q("We ___ TV when he arrived.",["watch","were watching","have watched","will watch"],1,"Past continuous describes an ongoing past action interrupted by another past event."),
(l)=>q("By next year, she ___ the course.",["completed","will have completed","completes","is completing"],1,"Future perfect shows completion before a future time."),
(l)=>q("I ___ in Karachi since 2024.",["live","lived","have lived","will live"],2,"Present perfect can describe an action/state continuing from the past to now."),
(l)=>q("He ___ before I reached the station.",["left","had left","leaves","will leave"],1,"Past perfect marks the earlier of two past actions."),
(l)=>q("Listen! The baby ___.",["cries","is crying","cried","will cry"],1,"'Listen!' suggests an action happening now."),
(l)=>q("Water ___ at 100°C at standard pressure.",["boils","boiled","is boiling only","will boil only"],0,"Simple present states a general scientific fact.")
])},
"Narration":{description:"Direct and indirect speech transformations.",...makeLevels([
(l)=>q("Indirect speech of 'He said, “I am tired.”' is:",["He said that he was tired.","He said that I am tired.","He says he was tired.","He said he is tired yesterday."],0,"Backshift commonly changes present 'am' to past 'was'."),
(l)=>q("In reported speech, 'today' may change to:",["that day","tomorrow","yesterday","now"],0,"Depending on context, today commonly becomes that day."),
(l)=>q("In reported speech, 'tomorrow' may change to:",["the next day","the previous day","today","now"],0,"Tomorrow commonly becomes the next day."),
(l)=>q("A reporting verb commonly used for a statement is:",["said","asked only","ordered only","exclaimed only"],0,"'Said' can introduce reported statements."),
(l)=>q("A question in indirect speech usually changes to:",["Statement word order","The same question order","A command","A fragment"],0,"Reported questions use statement word order."),
(l)=>q("'Do you know him?' can be reported using:",["whether/if","because","although","that only"],0,"Yes/no questions commonly use if or whether."),
(l)=>q("'Where are you going?' is a:",["Wh-question","Yes/no question","Command","Statement"],0,"It begins with a wh-word and asks for information."),
(l)=>q("In reported commands, we often use:",["to + base verb","verb-ing only","past perfect only","would + noun"],0,"Commands are often reported with an infinitive."),
(l)=>q("'Please help me' may be reported as:",["He requested me to help him.","He said help.","He asked that I helped yesterday.","He was helping."],0,"A polite request can be reported with 'requested ... to'."),
(l)=>q("Pronouns in reported speech change according to:",["The speaker, listener and context","Alphabetical order","Sentence length","Punctuation only"],0,"Pronouns are adjusted to preserve the intended reference.")
])},
"Active & Passive Voice":{description:"Changing active sentences into passive voice.",...makeLevels([
(l)=>q("Passive of 'Ali writes a letter' is:",["A letter is written by Ali.","A letter was written Ali.","Ali is written by a letter.","A letter writes Ali."],0,"Present simple passive uses is/are + past participle."),
(l)=>q("Passive of 'They built a bridge' is:",["A bridge was built by them.","A bridge is build by them.","They were built a bridge.","A bridge built them."],0,"Simple past passive uses was/were + past participle."),
(l)=>q("Passive voice focuses more on the:",["Action/receiver","Agent only","Adverb only","Subject's name only"],0,"The passive foregrounds the receiver of the action."),
(l)=>q("Passive of 'She is reading a book' is:",["A book is being read by her.","A book was read by her.","A book is read by her yesterday.","She is being read."],0,"Present continuous passive uses is/are being + past participle."),
(l)=>q("Passive of 'He has finished the work' is:",["The work has been finished by him.","The work was finish by him.","The work is finishing him.","The work had finish."],0,"Present perfect passive uses has/have been + past participle."),
(l)=>q("Passive of 'Open the door' is:",["Let the door be opened.","The door opened him.","The door is opening only.","Let open door."],0,"Imperatives can be changed using 'Let ... be + past participle'."),
(l)=>q("A passive sentence normally contains a form of:",["Be + past participle","Do + noun","Have + adjective","Will + ing only"],0,"The passive is formed with a form of 'be' plus past participle."),
(l)=>q("The agent in a passive sentence is commonly introduced by:",["by","to","for only","with only"],0,"'By' can introduce the doer of the action."),
(l)=>q("Passive of 'People speak English worldwide' is:",["English is spoken worldwide.","English speaks people.","English was speaking worldwide.","People are spoken English."],0,"The object 'English' becomes the passive subject."),
(l)=>q("Not every active verb can be made passive because passive generally requires:",["A transitive verb with an object","An adjective","An adverb","A preposition only"],0,"Passive voice normally needs an object to become the passive subject.")
])},
"Anaphoric Reference":{description:"References that point back to previously mentioned words or ideas.",...makeLevels([
(l)=>q("In 'Ali lost his book. He found it later,' 'He' refers back to:",["Ali","book","later","lost"],0,"'He' refers back to Ali."),
(l)=>q("In 'Sara bought a pen and used it,' 'it' refers to:",["Sara","pen","bought","used"],1,"'It' points back to the pen."),
(l)=>q("An anaphoric reference points:",["Backward to earlier text","Forward only","Outside language always","To punctuation"],0,"Anaphora refers back to an earlier antecedent."),
(l)=>q("The earlier noun referred to by a pronoun is called its:",["Antecedent","Predicate","Modifier","Clause"],0,"The antecedent is the earlier referent."),
(l)=>q("In 'The students finished the test. They left,' 'They' refers to:",["students","test","finished","left"],0,"The pronoun refers back to students."),
(l)=>q("In 'The car was old, but it still ran,' 'it' refers to:",["car","old","ran","but"],0,"'It' refers back to the car."),
(l)=>q("Anaphora helps a text avoid unnecessary:",["Repetition","Grammar","Meaning","Punctuation"],0,"Pronouns can reduce repeated nouns."),
(l)=>q("In 'Ahmed told Bilal that he was late,' the pronoun 'he' may be:",["Ambiguous","Always Bilal","Always Ahmed","A verb"],0,"The context does not uniquely identify the antecedent."),
(l)=>q("A pronoun should normally agree with its antecedent in:",["Number and person","Punctuation only","Tense only","Length"],0,"Pronoun-antecedent agreement includes number and person."),
(l)=>q("'This' can be anaphoric when it refers to:",["A previously mentioned idea","Only a future noun","No noun or idea","A verb tense"],0,"Demonstratives can point back to earlier discourse.")
])},
"Cataphoric Reference":{description:"References that point forward to information introduced later.",...makeLevels([
(l)=>q("In 'When he arrived, Ali sat down,' 'he' refers forward to:",["Ali","arrived","down","when"],0,"The name Ali appears later and identifies 'he'."),
(l)=>q("A cataphoric reference points:",["Forward to later text","Backward only","To punctuation","To a dictionary"],0,"Cataphora anticipates a later expression."),
(l)=>q("In 'Before she spoke, Maria took a breath,' 'she' refers to:",["Maria","breath","spoke","before"],0,"Maria appears later in the sentence."),
(l)=>q("Cataphora can create:",["Suspense or emphasis","Only errors","A change of tense","A new alphabet"],0,"Forward reference can delay identification for effect."),
(l)=>q("In 'If it is approved, the plan will begin,' 'it' most likely refers to:",["The plan or an implied proposal","begin","approved","will"],0,"The later noun/idea supplies the reference."),
(l)=>q("A forward-pointing pronoun is called:",["Cataphoric","Anaphoric","Reflexive only","Relative only"],0,"Cataphoric references point forward."),
(l)=>q("In 'Although he was tired, Ahmed continued,' 'he' refers to:",["Ahmed","tired","continued","although"],0,"Ahmed appears after the pronoun."),
(l)=>q("Cataphoric reference differs from anaphoric reference mainly in:",["Direction of reference","Number of words","Punctuation","Verb tense"],0,"Cataphora points forward; anaphora points backward."),
(l)=>q("In 'Before they left, the guests thanked us,' 'they' refers to:",["the guests","us","left","before"],0,"The later noun phrase identifies the pronoun."),
(l)=>q("Cataphoric reference is common when a writer wants to:",["Introduce a referent after a pronoun","Repeat every noun","Remove context","Avoid all pronouns"],0,"The referent can be introduced later for flow or emphasis.")
])},
"Parts of Speech":{description:"Nouns, pronouns, verbs, adjectives, adverbs, prepositions and conjunctions.",...makeLevels([
(l)=>q("A noun names a:",["Person, place, thing or idea","Action only","Description only","Connection only"],0,"Nouns name entities or ideas."),
(l)=>q("A verb commonly expresses:",["Action or state","Only a person","Only a place","Only color"],0,"Verbs express actions, events or states."),
(l)=>q("An adjective modifies a:",["Noun or pronoun","Verb only","Preposition only","Conjunction only"],0,"Adjectives describe nouns/pronouns."),
(l)=>q("An adverb commonly modifies a:",["Verb, adjective or adverb","Noun only","Pronoun only","Article only"],0,"Adverbs often modify verbs, adjectives and other adverbs."),
(l)=>q("A pronoun can replace a:",["Noun or noun phrase","Verb only","Preposition","Conjunction"],0,"Pronouns stand in for noun phrases."),
(l)=>q("A preposition shows a relationship such as:",["Place or time","Only number","Only tense","Only sound"],0,"Prepositions can express spatial, temporal and other relations."),
(l)=>q("A conjunction connects:",["Words, phrases or clauses","Only nouns","Only verbs","Only letters"],0,"Conjunctions join grammatical units."),
(l)=>q("In 'The red car stopped,' 'red' is a:",["Adjective","Adverb","Verb","Pronoun"],0,"'Red' describes the noun car."),
(l)=>q("In 'She sings beautifully,' 'beautifully' is an:",["Adverb","Adjective","Noun","Preposition"],0,"It modifies the verb sings."),
(l)=>q("In 'Ali and Sara studied,' 'and' is a:",["Conjunction","Preposition","Adverb","Pronoun"],0,"'And' connects two subjects.")
])},
"Vocabulary":{description:"Common academic vocabulary, synonyms, antonyms and context clues.",...makeLevels([
(l)=>q("The closest meaning of 'rapid' is:",["Fast","Slow","Weak","Late"],0,"Rapid means fast."),
(l)=>q("The opposite of 'ancient' is:",["Modern","Old","Historic","Former"],0,"Modern is the opposite of ancient."),
(l)=>q("'Accurate' means:",["Correct","Huge","Quick","Angry"],0,"Accurate means correct or exact."),
(l)=>q("The closest meaning of 'assist' is:",["Help","Avoid","Refuse","Delay"],0,"Assist means help."),
(l)=>q("The opposite of 'expand' is:",["Contract","Increase","Extend","Grow"],0,"Contract means become smaller."),
(l)=>q("'Brief' most nearly means:",["Short","Heavy","Loud","Complex"],0,"Brief means short in duration or length."),
(l)=>q("'Obtain' means:",["Get","Lose","Hide","Break"],0,"Obtain means get or acquire."),
(l)=>q("The opposite of 'scarce' is:",["Abundant","Rare","Limited","Few"],0,"Abundant means plentiful."),
(l)=>q("'Essential' means:",["Necessary","Optional","Unrelated","Temporary"],0,"Essential means necessary or very important."),
(l)=>q("'Predict' means:",["Say what is likely to happen","Forget the past","Copy a sentence","Measure mass"],0,"Predict means forecast a likely future event.")
])}
};
// StudyMaster V8 expanded chapters
Object.assign(English,{
  'Articles': English['Subject–Verb Agreement'],
  'Prepositions': English['Parts of Speech'],
  'Conjunctions': English['Parts of Speech'],
  'Modals': English['Tenses'],
  'Conditional Sentences': English['Tenses'],
  'Punctuation': English['Parts of Speech'],
  'Sentence Correction': English['Vocabulary']
});
window.STUDY_DATA=window.STUDY_DATA||{};window.STUDY_DATA.English=English;
