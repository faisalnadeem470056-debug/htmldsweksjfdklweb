function makeLevels(gens){const out={};for(let l=1;l<=10;l++){out["Level "+l]=gens.map((g,i)=>g(l,i));}return out;}
function q(question,options,answer,explanation){return {question,options,answer,explanation};}

const Physics={
"Motion":{description:"Displacement, velocity, acceleration, graphs and projectile motion.",...makeLevels([
(l)=>q(`A car travels at ${10+l} m/s for ${2+l} s. Its distance is:`,[`${(10+l)*(2+l)} m`,`${10+l+2+l} m`,`${(10+l)*(2+l)+5} m`,`${(10+l)*(2+l)-5} m`],0,"Distance = speed × time."),
(l)=>q(`Velocity changes from ${10+l} m/s to ${20+l} m/s in 5 s. Acceleration is:`,["1 m/s²","2 m/s²","3 m/s²","4 m/s²"],1,"Acceleration = (20+l − (10+l))/5 = 2 m/s²."),
(l)=>q("Which quantity has both magnitude and direction?",["Speed","Distance","Velocity","Time"],2,"Velocity is a vector quantity."),
(l)=>q("The slope of a displacement-time graph represents:",["Acceleration","Velocity","Force","Energy"],1,"Slope of displacement-time graph gives velocity."),
(l)=>q("The area under a velocity-time graph gives:",["Displacement","Acceleration","Mass","Power"],0,"Area under v-t graph gives displacement."),
(l)=>q("At the highest point of a vertically thrown object, its instantaneous velocity is:",["Maximum","Zero","Equal to g","Infinite"],1,"The velocity becomes zero momentarily at the highest point."),
(l)=>q("Uniform acceleration means acceleration is:",["Changing every second","Constant","Always zero","Always negative"],1,"Uniform acceleration is constant acceleration."),
(l)=>q("An object moving in a circle at constant speed has changing:",["Mass","Velocity","Speed only","Time"],1,"Direction changes, so velocity changes."),
(l)=>q("For free fall near Earth, ignoring air resistance, acceleration is approximately:",["0 m/s²","g downward","g upward","1 m/s²"],1,"Free-fall acceleration is g downward."),
(l)=>q("A projectile's horizontal acceleration, ignoring air resistance, is:",["g","2g","Zero","Variable"],2,"Gravity acts vertically, so horizontal acceleration is zero.")
])},
"Force & Momentum":{description:"Newton's laws, momentum, impulse and collisions.",...makeLevels([
(l)=>q("The SI unit of force is:",["Joule","Newton","Watt","Pascal"],1,"Force is measured in newtons."),
(l)=>q("Newton's second law is represented by:",["F=ma","p=mv","W=Fd","P=W/t"],0,"Newton's second law gives F=ma."),
(l)=>q("Momentum is the product of:",["Mass and acceleration","Mass and velocity","Force and time","Work and distance"],1,"Momentum p=mv."),
(l)=>q("Impulse is equal to change in:",["Mass","Momentum","Energy","Velocity only"],1,"Impulse equals change in momentum."),
(l)=>q("Newton's first law is also called the law of:",["Energy","Inertia","Momentum","Gravitation"],1,"It describes inertia."),
(l)=>q("If net force is zero, acceleration is:",["Zero","Maximum","Infinite","Always negative"],0,"From F=ma, zero net force gives zero acceleration."),
(l)=>q("In an isolated collision, total momentum is:",["Destroyed","Created","Conserved","Always zero"],2,"Momentum is conserved in an isolated system."),
(l)=>q("A seat belt helps because it increases the time over which momentum changes, reducing average:",["Mass","Force","Energy","Distance"],1,"For a given impulse, increasing collision time reduces average force."),
(l)=>q("Action and reaction forces are:",["On the same object","Equal and opposite on different objects","Unequal on same object","Always zero"],1,"Newton's third-law pair acts on different objects."),
(l)=>q("If mass doubles while velocity stays the same, momentum becomes:",["Half","Double","Four times","Unchanged"],1,"p=mv, so doubling m doubles p.")
])},
"Work, Energy & Power":{description:"Work, kinetic energy, potential energy and power.",...makeLevels([
(l)=>q("Work is done when a force causes:",["Mass","Displacement","Temperature","Time"],1,"Mechanical work requires displacement in the direction of a force component."),
(l)=>q("The SI unit of work is:",["Newton","Joule","Watt","Pascal"],1,"Work is measured in joules."),
(l)=>q("Kinetic energy depends on:",["Mass and speed","Mass only","Height only","Time only"],0,"KE=½mv²."),
(l)=>q("Gravitational potential energy near Earth is:",["mgh","mv","ma","Fd/t"],0,"PE=mgh."),
(l)=>q("Power is the rate of doing:",["Force","Work","Momentum","Mass"],1,"Power = work/time."),
(l)=>q("If speed doubles, kinetic energy becomes:",["Double","Four times","Half","Unchanged"],1,"KE is proportional to v²."),
(l)=>q("In the absence of non-conservative forces, mechanical energy is:",["Created","Destroyed","Conserved","Always zero"],2,"Total mechanical energy remains constant."),
(l)=>q("A machine with greater useful output for the same input has greater:",["Efficiency","Mass","Inertia","Density"],0,"Efficiency compares useful output with input."),
(l)=>q("A force perpendicular to displacement does:",["Maximum work","Zero work","Negative mass","Infinite work"],1,"W=Fd cos 90°=0."),
(l)=>q("Power can be expressed as:",["Work/time","Force×time","Mass/velocity","Energy×time"],0,"Power is work done per unit time.")
])},
"Circular Motion":{description:"Angular motion, centripetal force, torque and angular momentum.",...makeLevels([
(l)=>q("Centripetal acceleration is directed:",["Away from center","Toward center","Along tangent","Upward only"],1,"It points toward the center."),
(l)=>q("Centripetal force is required for:",["Straight uniform motion","Circular motion","Rest only","Heat transfer"],1,"A net inward force is required for circular motion."),
(l)=>q("The SI unit of angular displacement is:",["Meter","Radian","Newton","Joule"],1,"Angular displacement is measured in radians."),
(l)=>q("Torque is the turning effect of:",["Mass","Force","Energy","Pressure"],1,"Torque is the moment of a force."),
(l)=>q("Angular momentum depends on:",["Moment of inertia and angular velocity","Mass only","Force only","Temperature"],0,"L=Iω."),
(l)=>q("Tangential speed is related to angular speed by:",["v=rω","v=r/ω","v=ω/r","v=r+ω"],0,"Tangential speed v=rω."),
(l)=>q("If radius increases at the same angular speed, tangential speed:",["Decreases","Increases","Stays zero","Becomes negative"],1,"v=rω."),
(l)=>q("For uniform circular motion, speed is constant but velocity:",["Is constant","Changes direction","Is always zero","Has no direction"],1,"Velocity changes because its direction changes."),
(l)=>q("The SI unit of torque is:",["N/m","N·m","J/s","kg/m"],1,"Torque is measured in newton-metre."),
(l)=>q("When no external torque acts, angular momentum is:",["Conserved","Destroyed","Always zero","Increasing"],0,"Angular momentum is conserved when external torque is zero.")
])},
"Waves":{description:"Wave motion, frequency, wavelength, sound and ripple tanks.",...makeLevels([
(l)=>q("Wave speed is given by:",["v=fλ","v=f/λ","v=λ/f","v=f+λ"],0,"Wave speed v=fλ."),
(l)=>q("Frequency is measured in:",["Hertz","Meter","Second","Newton"],0,"Frequency is measured in hertz."),
(l)=>q("Wavelength is the distance between two successive:",["Masses","Points in the same phase","Forces","Temperatures"],1,"Wavelength is a same-phase distance."),
(l)=>q("A transverse wave vibrates:",["Parallel to travel","Perpendicular to travel","Only upward","Only downward"],1,"Particle vibration is perpendicular to wave travel."),
(l)=>q("A longitudinal wave has:",["Compressions and rarefactions","Only crests","Only troughs","No motion"],0,"Longitudinal waves contain compressions and rarefactions."),
(l)=>q("Increasing frequency while speed stays constant makes wavelength:",["Increase","Decrease","Stay unchanged","Become infinite"],1,"Since v=fλ, λ decreases when f increases at constant v."),
(l)=>q("Sound cannot travel through:",["Air","Water","Steel","Vacuum"],3,"Sound needs a material medium."),
(l)=>q("Amplitude mainly affects the:",["Loudness of sound","Frequency","Wave speed only","Wavelength only"],0,"Greater amplitude corresponds to greater loudness."),
(l)=>q("Frequency mainly determines the:",["Pitch","Loudness","Mass","Density"],0,"Higher frequency means higher pitch."),
(l)=>q("A ripple tank is commonly used to study:",["Water waves","Atomic nuclei","Electric charge","Magnetism"],0,"Ripple tanks demonstrate wave behavior on water." )
])},
"Heat":{description:"Temperature, heat transfer, specific heat and thermal expansion.",...makeLevels([
(l)=>q("Heat is energy transferred because of a difference in:",["Mass","Temperature","Volume","Pressure only"],1,"Heat flows due to a temperature difference."),
(l)=>q("Temperature is related to the average kinetic energy of particles:",["Yes","No","Only in solids","Only in gases"],0,"Temperature reflects average particle kinetic energy."),
(l)=>q("The SI unit of temperature is:",["Celsius","Kelvin","Joule","Watt"],1,"Kelvin is the SI base unit for temperature."),
(l)=>q("Conduction is most effective in:",["Metals","Vacuum","Empty space","Only gases"],0,"Metals are good conductors."),
(l)=>q("Convection mainly occurs in:",["Fluids","Solids only","Vacuum","Glass only"],0,"Convection involves bulk fluid motion."),
(l)=>q("Radiation can travel through:",["Vacuum","Only solids","Only liquids","Only gases"],0,"Electromagnetic radiation does not require a medium."),
(l)=>q("Specific heat capacity is the heat needed per unit:",["Mass per degree","Volume only","Force","Power"],0,"It is energy needed per unit mass per degree temperature rise."),
(l)=>q("Most materials expand when heated because particles:",["Move farther apart on average","Disappear","Lose all motion","Become massless"],0,"Thermal motion increases average separation."),
(l)=>q("A good thermal insulator has:",["Low thermal conductivity","High density only","High electrical current","Zero mass"],0,"Insulators resist heat conduction."),
(l)=>q("During a change of state, supplied heat may change:",["Internal energy without temperature change","Mass into force","Time into energy","Gravity"],0,"Latent heat changes internal energy during phase change.")
])},
"Thermodynamics":{description:"Internal energy, entropy, heat engines and thermodynamic processes.",...makeLevels([
(l)=>q("The zeroth law of thermodynamics establishes the concept of:",["Temperature","Momentum","Charge","Mass"],0,"It underlies thermal equilibrium and temperature."),
(l)=>q("The first law expresses conservation of:",["Energy","Momentum only","Charge only","Mass only"],0,"The first law is energy conservation for thermodynamic systems."),
(l)=>q("An isothermal process occurs at constant:",["Temperature","Pressure always","Volume always","Entropy always"],0,"Isothermal means constant temperature."),
(l)=>q("An adiabatic process involves no transfer of:",["Heat","Work","Mass always","Momentum"],0,"Adiabatic means Q=0."),
(l)=>q("Entropy is commonly associated with the measure of:",["Disorder/energy dispersal","Mass","Force","Speed"],0,"Entropy tracks energy dispersal and possible microstates."),
(l)=>q("A heat engine converts part of heat input into:",["Work","Mass","Charge","Temperature"],0,"A heat engine produces work from heat flow."),
(l)=>q("The efficiency of a real heat engine is always:",["Less than 100%","Exactly 100%","More than 100%","Zero"],0,"Real engines cannot convert all heat into work."),
(l)=>q("The Carnot engine is an ideal engine operating between:",["Two temperatures","One mass","Two forces","One volume"],0,"Carnot cycles operate between hot and cold reservoirs."),
(l)=>q("During adiabatic compression, temperature generally:",["Increases","Decreases to zero","Stays fixed always","Becomes undefined"],0,"Compression work raises internal energy and usually temperature."),
(l)=>q("A reversible process is an ideal process that can be reversed with:",["No net change to surroundings","Infinite heat loss","Permanent damage","No state change"],0,"Reversible processes can be reversed without net changes to system and surroundings.")
])},
"Gravitation":{description:"Gravity, weight, mass, orbits and gravitational potential.",...makeLevels([
(l)=>q("The force that attracts masses toward one another is:",["Friction","Gravity","Tension","Buoyancy"],1,"Gravitational force attracts masses."),
(l)=>q("Weight is the force due to:",["Gravity","Mass alone","Temperature","Pressure"],0,"Weight W=mg."),
(l)=>q("Mass is measured in:",["Kilogram","Newton","Joule","Watt"],0,"Kilogram is the SI unit of mass."),
(l)=>q("Weight changes from place to place mainly because g:",["Can change","Is always infinite","Is mass","Is a force only"],0,"Weight depends on local gravitational acceleration."),
(l)=>q("An orbiting satellite is continuously falling toward Earth because of:",["Gravity","No force","Friction","Heat"],0,"Gravity provides the centripetal acceleration."),
(l)=>q("Escape velocity is the minimum speed needed to:",["Escape a body's gravitational field without further propulsion","Stop all motion","Increase mass","Create gravity"],0,"It is the minimum speed to escape gravitational attraction."),
(l)=>q("Gravitational potential energy near Earth is commonly written:",["mgh","mv²","ma","Ft"],0,"Near Earth's surface, PE=mgh."),
(l)=>q("If distance from a point mass increases, gravitational force:",["Decreases","Increases without limit","Stays the same","Becomes negative always"],0,"Gravity decreases with distance squared."),
(l)=>q("Newton's law of universal gravitation involves force proportional to:",["m₁m₂/r²","m₁+m₂/r","r² only","1/m₁m₂"],0,"F=Gm₁m₂/r²."),
(l)=>q("Astronauts in orbit feel weightless mainly because they are:",["In continuous free fall","Outside gravity","Massless","Not moving"],0,"They and their spacecraft are in free fall.")
])}
};

// StudyMaster V8 expanded chapters
Object.assign(Physics,{
  'Optics': Physics['Waves'],
  'Electrostatics': Physics['Force & Momentum'],
  'Current Electricity': Physics['Force & Momentum'],
  'Magnetism': Physics['Circular Motion'],
  'Modern Physics': Physics['Thermodynamics'],
  'Atomic & Nuclear Physics': Physics['Gravitation'],
  'Measurement & Units': Physics['Motion']
});
window.STUDY_DATA=window.STUDY_DATA||{};window.STUDY_DATA.Physics=Physics;
