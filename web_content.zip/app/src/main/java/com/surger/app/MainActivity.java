package com.surger.app;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.Settings;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.webkit.DownloadListener;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import java.util.ArrayList;
import java.util.Locale;

public class MainActivity extends Activity implements TextToSpeech.OnInitListener {
    private static final int MIC_REQ = 7001;
    private static final int FILE_REQ = 7002;
    private WebView web;
    private ValueCallback<Uri[]> fileCallback;
    private SpeechRecognizer recognizer;
    private TextToSpeech tts;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        web = new WebView(this);
        setContentView(web);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setBuiltInZoomControls(false);
        web.setWebViewClient(new WebViewClient());
        web.setWebChromeClient(new WebChromeClient() {
            @Override public void onPermissionRequest(android.webkit.PermissionRequest req) {
                runOnUiThread(() -> { String[] r=req.getResources(); if(r!=null){ java.util.ArrayList<String> allowed=new java.util.ArrayList<>(); for(String x:r) if(android.webkit.PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(x)) allowed.add(x); req.grant(allowed.toArray(new String[0])); } });
            }
            @Override public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb, FileChooserParams p) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = cb;
                Intent i = p.createIntent();
                try { startActivityForResult(i, FILE_REQ); } catch (Exception e) { fileCallback = null; return false; }
                return true;
            }
        });
        web.setDownloadListener((url, userAgent, contentDisposition, mimetype, contentLength) -> {
            Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
            try { startActivity(i); } catch (Exception ignored) { }
        });
        web.addJavascriptInterface(new AndroidBridge(), "SurgerAndroid");
        web.loadUrl("file:///android_asset/surger.html");
        tts = new TextToSpeech(this, this);
    }

    public class AndroidBridge {
        @JavascriptInterface public boolean nativeAvailable() { return true; }
        @JavascriptInterface public void speak(String text) {
            if (tts == null) return;
            runOnUiThread(() -> {
                tts.setLanguage(Locale.US);
                tts.setSpeechRate(0.9f);
                tts.setPitch(0.84f);
                tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "surger-voice");
            });
        }
        @JavascriptInterface public void startListening() {
            runOnUiThread(() -> {
                if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                    requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, MIC_REQ);
                    return;
                }
                beginRecognition();
            });
        }
        @JavascriptInterface public void stopListening() {
            if (recognizer != null) recognizer.stopListening();
        }
        @JavascriptInterface public void openFile() {
            Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            i.addCategory(Intent.CATEGORY_OPENABLE); i.setType("*/*");
            startActivityForResult(i, FILE_REQ);
        }
    }

    private void beginRecognition() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            web.evaluateJavascript("window.SurgerNativeSpeechError && window.SurgerNativeSpeechError('Speech recognition is unavailable on this phone.');", null);
            return;
        }
        if (recognizer != null) recognizer.destroy();
        recognizer = SpeechRecognizer.createSpeechRecognizer(this);
        recognizer.setRecognitionListener(new RecognitionListener() {
            public void onReadyForSpeech(Bundle b) {}
            public void onBeginningOfSpeech() {}
            public void onRmsChanged(float r) {}
            public void onBufferReceived(byte[] b) {}
            public void onEndOfSpeech() {}
            public void onPartialResults(Bundle b) {}
            public void onEvent(int t, Bundle b) {}
            public void onError(int e) { web.evaluateJavascript("window.SurgerNativeSpeechError && window.SurgerNativeSpeechError('Mic could not complete the request.');", null); }
            public void onResults(Bundle b) {
                ArrayList<String> r = b.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                if (r != null && !r.isEmpty()) {
                    String escaped = r.get(0).replace("\\", "\\\\").replace("'", "\\'");
                    web.evaluateJavascript("window.SurgerNativeSpeechResult && window.SurgerNativeSpeechResult('"+escaped+"');", null);
                }
            }
        });
        Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.US.toLanguageTag());
        i.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false);
        recognizer.startListening(i);
    }

    @Override public void onRequestPermissionsResult(int r, String[] p, int[] g) {
        super.onRequestPermissionsResult(r,p,g);
        if (r == MIC_REQ && g.length > 0 && g[0] == PackageManager.PERMISSION_GRANTED) beginRecognition();
        else web.evaluateJavascript("window.SurgerNativeSpeechError && window.SurgerNativeSpeechError('Microphone permission was not granted.');", null);
    }

    @Override protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req,res,data);
        if (req == FILE_REQ && fileCallback != null) {
            Uri[] r = (res == RESULT_OK && data != null && data.getData() != null) ? new Uri[]{data.getData()} : null;
            fileCallback.onReceiveValue(r); fileCallback = null;
        }
    }

    @Override public void onInit(int status) {}
    @Override protected void onDestroy() {
        if (recognizer != null) recognizer.destroy();
        if (tts != null) { tts.stop(); tts.shutdown(); }
        if (web != null) web.destroy();
        super.onDestroy();
    }
}
