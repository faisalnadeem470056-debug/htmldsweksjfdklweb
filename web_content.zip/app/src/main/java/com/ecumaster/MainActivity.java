package com.ecumaster;

import android.Manifest;
import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.UUID;

public class MainActivity extends Activity {
    private static final int REQ_BT = 77;
    private static final UUID SPP = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");

    private WebView web;
    private BluetoothAdapter adapter;
    private BluetoothSocket socket;
    private OutputStream out;
    private volatile boolean reading;
    private Thread readThread;
    private boolean receiverRegistered;

    private final BroadcastReceiver discoveryReceiver = new BroadcastReceiver() {
        @Override public void onReceive(Context context, Intent intent) {
            if (BluetoothDevice.ACTION_FOUND.equals(intent.getAction())) {
                if (Build.VERSION.SDK_INT >= 31 && checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN) != PackageManager.PERMISSION_GRANTED) return;
                BluetoothDevice d = intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);
                if (d != null) {
                    try { emit("پیدا شد|" + safe(d.getName()) + "|" + d.getAddress()); } catch (Exception ignored) {}
                }
            } else if (BluetoothDevice.ACTION_BOND_STATE_CHANGED.equals(intent.getAction())) {
                if (Build.VERSION.SDK_INT >= 31 && checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) return;
                BluetoothDevice d = intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);
                if (d != null) {
                    int state = intent.getIntExtra(BluetoothDevice.EXTRA_BOND_STATE, BluetoothDevice.BOND_NONE);
                    if (state == BluetoothDevice.BOND_BONDED) emit("جفت_شد|" + safe(d.getName()) + "|" + d.getAddress());
                    else if (state == BluetoothDevice.BOND_NONE) emit("جفت_ناموفق|" + safe(d.getName()) + "|" + d.getAddress());
                    else emit("درحال_جفت|" + safe(d.getName()) + "|" + d.getAddress());
                }
            } else if (BluetoothAdapter.ACTION_DISCOVERY_FINISHED.equals(intent.getAction())) {
                emit("جستجو_تمام|-");
            }
        }
    };

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        web = new WebView(this);
        setContentView(web);
        adapter = BluetoothAdapter.getDefaultAdapter();

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowFileAccessFromFileURLs(true);
        s.setAllowUniversalAccessFromFileURLs(false);
        web.setWebViewClient(new WebViewClient());
        web.setWebChromeClient(new WebChromeClient());
        web.addJavascriptInterface(new Native(), "ECUNative");
        web.loadUrl("file:///android_asset/index.html");

        IntentFilter f = new IntentFilter(BluetoothDevice.ACTION_FOUND);
        f.addAction(BluetoothDevice.ACTION_BOND_STATE_CHANGED);
        f.addAction(BluetoothAdapter.ACTION_DISCOVERY_FINISHED);
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(discoveryReceiver, f, Context.RECEIVER_NOT_EXPORTED); else registerReceiver(discoveryReceiver, f);
        receiverRegistered = true;
    }

    private boolean btPerms() {
        if (Build.VERSION.SDK_INT >= 31) {
            return checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN) == PackageManager.PERMISSION_GRANTED
                    && checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED;
        }
        if (Build.VERSION.SDK_INT >= 23) {
            return checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED;
        }
        return true;
    }

    private void askBt() {
        if (Build.VERSION.SDK_INT >= 31) {
            requestPermissions(new String[]{Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT}, REQ_BT);
        } else if (Build.VERSION.SDK_INT >= 23) {
            requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, REQ_BT);
        }
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grants) {
        super.onRequestPermissionsResult(requestCode, permissions, grants);
        if (requestCode == REQ_BT) emit("مجوز|" + (btPerms() ? "قبول شد" : "رد شد"));
    }

    private void emit(String x) {
        if (web == null) return;
        runOnUiThread(() -> web.evaluateJavascript("window.nativeEvent(" + JSONObject.quote(x) + ")", null));
    }

    private String safe(String s) { return s == null ? "دستگاه بدون نام" : s.replace("|", " "); }

    private void closeSocket() {
        reading = false;
        try { if (socket != null) socket.close(); } catch (Exception ignored) {}
        socket = null;
        out = null;
        emit("قطع");
    }

    private void startReader(final BluetoothSocket s) {
        reading = true;
        readThread = new Thread(() -> {
            byte[] buffer = new byte[4096];
            StringBuilder pending = new StringBuilder();
            try {
                InputStream in = s.getInputStream();
                while (reading) {
                    int n = in.read(buffer);
                    if (n < 0) break;
                    if (n == 0) continue;
                    String chunk = new String(buffer, 0, n, StandardCharsets.US_ASCII);
                    pending.append(chunk);
                    int cut;
                    while ((cut = findFrameEnd(pending)) >= 0) {
                        String frame = pending.substring(0, cut).trim();
                        pending.delete(0, cut + 1);
                        if (!frame.isEmpty()) emit("دریافت|" + frame);
                    }
                    if (pending.length() > 8192) {
                        emit("دریافت|" + pending.toString().trim());
                        pending.setLength(0);
                    }
                }
            } catch (Exception e) {
                if (reading) emit("خطای دریافت|" + safe(e.getMessage()));
            } finally {
                if (reading) closeSocket();
            }
        }, "ECU-BT-Reader");
        readThread.start();
    }

    private int findFrameEnd(StringBuilder s) {
        int r = s.indexOf("\r");
        int n = s.indexOf("\n");
        if (r < 0) return n;
        if (n < 0) return r;
        return Math.min(r, n);
    }

    public class Native {
        @JavascriptInterface public String status() {
            if (adapter == null) return "بلوتوث_در_دسترس_نیست";
            if (!btPerms()) return "مجوز_لازم_است";
            return adapter.isEnabled() ? "بلوتوث_روشن" : "بلوتوث_خاموش";
        }

        @JavascriptInterface public void enableBluetooth() {
            if (adapter == null) { emit("خطا|این گوشی Bluetooth ندارد"); return; }
            if (!btPerms()) { askBt(); return; }
            if (!adapter.isEnabled()) {
                try { startActivity(new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE)); }
                catch (Exception e) { startActivity(new Intent(Settings.ACTION_BLUETOOTH_SETTINGS)); }
            }
        }

        @JavascriptInterface public void openBluetoothSettings() {
            startActivity(new Intent(Settings.ACTION_BLUETOOTH_SETTINGS));
        }

        @JavascriptInterface public String paired() {
            JSONArray a = new JSONArray();
            if (adapter == null) return a.toString();
            if (!btPerms()) { askBt(); return a.toString(); }
            try {
                for (BluetoothDevice d : adapter.getBondedDevices()) {
                    JSONObject o = new JSONObject();
                    o.put("name", safe(d.getName()));
                    o.put("addr", d.getAddress());
                    a.put(o);
                }
            } catch (Exception ignored) {}
            return a.toString();
        }

        @JavascriptInterface public void discover() {
            if (adapter == null) { emit("خطا|این گوشی Bluetooth ندارد"); return; }
            if (!btPerms()) { askBt(); return; }
            try {
                if (adapter.isDiscovering()) adapter.cancelDiscovery();
                emit("جستجو_شروع|-");
                adapter.startDiscovery();
            } catch (Exception e) { emit("خطا|شروع جستجو: " + safe(e.getMessage())); }
        }

        @JavascriptInterface public void cancelDiscovery() {
            if (adapter == null || !btPerms()) return;
            try { if (adapter.isDiscovering()) adapter.cancelDiscovery(); } catch (Exception ignored) {}
        }

        @JavascriptInterface public void pair(String addr) {
            if (adapter == null) { emit("خطا|این گوشی Bluetooth ندارد"); return; }
            if (!btPerms()) { askBt(); return; }
            try {
                BluetoothDevice d = adapter.getRemoteDevice(addr);
                if (d.getBondState() == BluetoothDevice.BOND_BONDED) {
                    emit("جفت_شد|" + safe(d.getName()) + "|" + addr);
                    return;
                }
                emit("درحال_جفت|" + safe(d.getName()) + "|" + addr);
                d.createBond();
            } catch (Exception e) {
                emit("جفت_ناموفق|" + safe(e.getMessage()) + "|" + addr);
            }
        }

        @JavascriptInterface public void connect(String addr) {
            if (!btPerms()) { askBt(); return; }
            new Thread(() -> {
                closeSocket();
                try {
                    BluetoothDevice d = adapter.getRemoteDevice(addr);
                    adapter.cancelDiscovery();
                    BluetoothSocket s;
                    try { s = d.createRfcommSocketToServiceRecord(SPP); s.connect(); }
                    catch (Exception first) {
                        s = d.createInsecureRfcommSocketToServiceRecord(SPP); s.connect();
                    }
                    socket = s;
                    out = s.getOutputStream();
                    emit("متصل|" + safe(d.getName()) + "|" + addr);
                    startReader(s);
                } catch (Exception e) {
                    emit("خطای اتصال|" + safe(e.getMessage()));
                    closeSocket();
                }
            }, "ECU-BT-Connect").start();
        }

        @JavascriptInterface public void disconnect() { closeSocket(); }

        @JavascriptInterface public void identifyEcu() {
            sendReadOnly("0100");
            sendReadOnly("0902");
            sendReadOnly("03");
        }

        @JavascriptInterface public void sendReadOnly(String cmd) {
            if (out == null) { emit("خطا|VCI متصل نیست"); return; }
            new Thread(() -> {
                try {
                    String c = cmd.replace(" ", "").trim();
                    out.write((c + "\r").getBytes(StandardCharsets.US_ASCII));
                    out.flush();
                    emit("ارسال|" + c);
                } catch (IOException e) {
                    emit("خطا|" + safe(e.getMessage()));
                    closeSocket();
                }
            }, "ECU-BT-Tx").start();
        }
    }

    @Override protected void onDestroy() {
        closeSocket();
        if (receiverRegistered) {
            try { unregisterReceiver(discoveryReceiver); } catch (Exception ignored) {}
        }
        if (web != null) web.destroy();
        super.onDestroy();
    }
}
