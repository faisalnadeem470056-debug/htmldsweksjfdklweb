package com.ecoradar.app;

import android.Manifest;
import android.app.*;
import android.os.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.webkit.*;
import android.widget.Toast;

public class MainActivity extends Activity {
    WebView web;
    static final int REQ=55;
    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        Notifications.ensure(this);
        web=new WebView(this);
        web.setBackgroundColor(0xFF06141D);
        WebSettings s=web.getSettings();
        s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true); s.setGeolocationEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        web.setWebViewClient(new WebViewClient());
        web.setWebChromeClient(new WebChromeClient(){
            @Override public void onGeolocationPermissionsShowPrompt(String origin, GeolocationPermissions.Callback cb){
                if(Build.VERSION.SDK_INT>=23 && checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)!=PackageManager.PERMISSION_GRANTED){
                    requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION,Manifest.permission.ACCESS_COARSE_LOCATION},REQ);
                }
                cb.invoke(origin,true,false);
            }
        });
        web.addJavascriptInterface(new Bridge(this),"AndroidEcoRadar");
        web.loadUrl("file:///android_asset/index.html");
        setContentView(web);
        requestNotificationPermission();
        WeatherAlertReceiver.schedule(this);
    }
    void requestNotificationPermission(){
        if(Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},56);
    }
    @Override public void onBackPressed(){ if(web.canGoBack()) web.goBack(); else super.onBackPressed(); }
}
class Bridge {
    final Context c; Bridge(Context c){this.c=c;}
    @JavascriptInterface public void saveLocation(String lat,String lon){
        c.getSharedPreferences("eco",0).edit().putString("lat",lat).putString("lon",lon).apply();
        WeatherAlertReceiver.schedule(c);
    }
    @JavascriptInterface public void requestNotifications(){
        if(Build.VERSION.SDK_INT>=33 && c instanceof Activity)
            ((Activity)c).requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},56);
    }
}
class Notifications {
    static final String CH="eco_alerts";
    static void ensure(Context c){
        if(Build.VERSION.SDK_INT>=26){
            NotificationChannel n=new NotificationChannel(CH,"Alertas ECO RADAR",NotificationManager.IMPORTANCE_HIGH);
            n.setDescription("Avisos preventivos de lluvia y empeoramiento del clima");
            ((NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE)).createNotificationChannel(n);
        }
    }
    static void show(Context c,String title,String msg){
        ensure(c);
        Intent i=new Intent(c,MainActivity.class);
        PendingIntent p=PendingIntent.getActivity(c,0,i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder b=Build.VERSION.SDK_INT>=26?new Notification.Builder(c,CH):new Notification.Builder(c);
        b.setSmallIcon(com.ecoradar.app.R.drawable.ic_launcher).setContentTitle(title).setContentText(msg).setStyle(new Notification.BigTextStyle().bigText(msg)).setAutoCancel(true).setContentIntent(p);
        ((NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE)).notify((int)(System.currentTimeMillis()%100000),b.build());
    }
}
