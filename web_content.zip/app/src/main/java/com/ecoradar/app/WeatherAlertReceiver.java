package com.ecoradar.app;

import android.app.*;
import android.content.*;
import android.os.*;
import android.net.*;
import org.json.*;
import java.io.*;
import java.net.*;

public class WeatherAlertReceiver extends BroadcastReceiver {
  static final long PERIOD=20*60*1000L;
  @Override public void onReceive(Context c, Intent i){
    final Context app=c.getApplicationContext();
    new Thread(()->check(app)).start();
  }
  static void schedule(Context c){
    AlarmManager am=(AlarmManager)c.getSystemService(Context.ALARM_SERVICE);
    Intent in=new Intent(c,WeatherAlertReceiver.class);
    PendingIntent pi=PendingIntent.getBroadcast(c,700,in,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
    long first=System.currentTimeMillis()+5000;
    if(Build.VERSION.SDK_INT>=23) am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,first,pi);
    else am.set(AlarmManager.RTC_WAKEUP,first,pi);
  }
  static void check(Context c){
    try{
      String lat=c.getSharedPreferences("eco",0).getString("lat","-12.0464");
      String lon=c.getSharedPreferences("eco",0).getString("lon","-77.0428");
      String u="https://api.open-meteo.com/v1/forecast?latitude="+lat+"&longitude="+lon+"&current=temperature_2m,relative_humidity_2m,precipitation_probability,weather_code,wind_speed_10m&hourly=precipitation_probability,weather_code&forecast_days=1&timezone=auto";
      HttpURLConnection x=(HttpURLConnection)new URL(u).openConnection(); x.setConnectTimeout(10000);x.setReadTimeout(10000);
      BufferedReader r=new BufferedReader(new InputStreamReader(x.getInputStream()));StringBuilder sb=new StringBuilder();String line;while((line=r.readLine())!=null)sb.append(line);r.disconnect();
      JSONObject j=new JSONObject(sb.toString()).getJSONObject("current");
      int rain=j.optInt("precipitation_probability",0), wind=j.optInt("wind_speed_10m",0), code=j.optInt("weather_code",-1);
      int risk=0; if(rain>=75)risk+=35;else if(rain>=50)risk+=20; if(wind>=45)risk+=40;else if(wind>=30)risk+=25; if(code>=95)risk+=30;
      String msg=null,title=null;
      if(code>=95){title="🚨 Tormenta detectada";msg="ECO RADAR detecta condición compatible con tormenta. Revisa fuentes oficiales."; }
      else if(rain>=75){title="🌧️ Lluvia probable";msg="La probabilidad de precipitación es "+rain+"%. Prepárate para lluvia."; }
      else if(wind>=30){title="💨 Viento fuerte";msg="Viento estimado de "+wind+" km/h. Mantente atento a cambios."; }
      if(msg!=null && risk>=20){
        String key=title+rain+wind+code;
        String old=c.getSharedPreferences("eco",0).getString("lastAlert","");
        if(!key.equals(old)){Notifications.show(c,title,msg);c.getSharedPreferences("eco",0).edit().putString("lastAlert",key).apply();}
      }
      EcoRadarWidget.updateAll(c,j);
      monitorOfficialSources(c);
    }catch(Exception ignored){}
    scheduleNext(c);
  }

  private static void monitorOfficialSources(Context c){
    // This checks the public official pages and notifies the user to review them.
    // It deliberately does NOT claim to predict earthquakes.
    try{
      String sen=readUrl("https://www.senamhi.gob.pe/?p=aviso-meteorologico");
      String low=sen.toLowerCase(java.util.Locale.ROOT);
      boolean hasAlert=low.contains("aviso meteorol") || low.contains("lluvia intensa") ||
                       low.contains("viento fuerte") || low.contains("tormenta") ||
                       low.contains("nivel rojo") || low.contains("nivel naranja");
      if(hasAlert){
        String key="senamhi:"+Integer.toHexString(sen.hashCode());
        String old=c.getSharedPreferences("eco",0).getString("officialAlert","");
        if(!key.equals(old)){
          Notifications.show(c,"⚠️ SENAMHI: revisar avisos",
            "Hay información meteorológica oficial publicada por SENAMHI. Abre ECO RADAR y revisa el aviso antes de tomar decisiones.");
          c.getSharedPreferences("eco",0).edit().putString("officialAlert",key).apply();
        }
      }
    }catch(Exception ignored){}
  }

  private static String readUrl(String u)throws Exception{
    HttpURLConnection x=(HttpURLConnection)new URL(u).openConnection();
    x.setConnectTimeout(8000); x.setReadTimeout(10000);
    x.setRequestProperty("User-Agent","EcoRadar/3.1 Android");
    BufferedReader r=new BufferedReader(new InputStreamReader(x.getInputStream()));
    StringBuilder sb=new StringBuilder(); String line;
    while((line=r.readLine())!=null && sb.length()<250000) sb.append(line);
    r.close(); x.disconnect(); return sb.toString();
  }

  static void scheduleNext(Context c){
    AlarmManager am=(AlarmManager)c.getSystemService(Context.ALARM_SERVICE);
    Intent in=new Intent(c,WeatherAlertReceiver.class);
    PendingIntent pi=PendingIntent.getBroadcast(c,700,in,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
    long next=System.currentTimeMillis()+PERIOD;
    if(Build.VERSION.SDK_INT>=23)am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,next,pi); else am.set(AlarmManager.RTC_WAKEUP,next,pi);
  }
}
