package com.ecoradar.app;

import android.appwidget.*;
import android.content.*;
import android.widget.RemoteViews;
import org.json.JSONObject;

public class EcoRadarWidget extends AppWidgetProvider {
 @Override public void onUpdate(Context c,AppWidgetManager m,int[] ids){ WeatherAlertReceiver.schedule(c); for(int id:ids) update(c,m,id,null); }
 static void update(Context c,AppWidgetManager m,int id,JSONObject j){
   RemoteViews v=new RemoteViews(c.getPackageName(),R.layout.widget_ecoradar);
   if(j!=null){
     v.setTextViewText(R.id.wTemp,j.optInt("temperature_2m",0)+"°C");
     v.setTextViewText(R.id.wRain,"💧 Lluvia: "+j.optInt("precipitation_probability",0)+"% · 💨 "+j.optInt("wind_speed_10m",0)+" km/h");
   } else v.setTextViewText(R.id.wRain,"Actualizando clima…");
   Intent in=new Intent(c,MainActivity.class); PendingIntent p=PendingIntent.getActivity(c,0,in,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
   v.setOnClickPendingIntent(R.id.wTitle,p); v.setOnClickPendingIntent(R.id.wTemp,p); v.setOnClickPendingIntent(R.id.wRain,p);
   m.updateAppWidget(id,v);
 }
 static void updateAll(Context c,JSONObject j){AppWidgetManager m=AppWidgetManager.getInstance(c);int[] ids=m.getAppWidgetIds(new ComponentName(c,EcoRadarWidget.class));for(int id:ids)update(c,m,id,j);}
}
