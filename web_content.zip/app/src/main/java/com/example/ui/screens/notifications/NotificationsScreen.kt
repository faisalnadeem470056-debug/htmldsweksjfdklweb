package com.example.ui.screens.notifications

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ChatBubble
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.DoneAll
import androidx.compose.material.icons.filled.ElectricBolt
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.PersonAdd
import androidx.compose.material.icons.filled.SlowMotionVideo
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material.icons.outlined.DeleteSweep
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.NotificationItem
import com.example.ui.components.ResourceHelper
import com.example.ui.theme.DarkBg
import com.example.ui.theme.DarkBorder
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceElevated
import com.example.ui.theme.InstagramPink
import com.example.ui.theme.KeiosAmber
import com.example.ui.theme.KeiosCyan
import com.example.ui.theme.KeiosNeonGreen
import com.example.ui.viewmodel.KeiosgramViewModel

@Composable
fun NotificationsScreen(
    viewModel: KeiosgramViewModel,
    notifications: List<NotificationItem>,
    modifier: Modifier = Modifier
) {
    var selectedFilter by remember { mutableStateOf("ALL") }
    var showSimulatorMenu by remember { mutableStateOf(false) }

    // Pulsing animation for live sync status indicator
    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val pulseAlpha by infiniteTransition.animateFloat(
        initialValue = 0.4f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(800),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse_alpha"
    )

    val filterOptions = listOf(
        Pair("ALL", "All Activity"),
        Pair("LIKE", "Likes"),
        Pair("COMMENT", "Comments"),
        Pair("FOLLOW", "Follows"),
        Pair("MENTION", "Mentions"),
        Pair("SECURITY_ALERT", "Security")
    )

    val filteredList = remember(notifications, selectedFilter) {
        if (selectedFilter == "ALL") notifications
        else notifications.filter { it.type == selectedFilter }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(DarkBg)
            .statusBarsPadding()
    ) {
        // Top Header
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 10.dp)
        ) {
            Text(
                text = "Notifications",
                fontSize = 22.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface,
                modifier = Modifier.testTag("notifications_header_title")
            )

            Spacer(modifier = Modifier.weight(1f))

            // Trigger Real-time Simulation Action Button
            Button(
                onClick = { showSimulatorMenu = !showSimulatorMenu },
                colors = ButtonDefaults.buttonColors(containerColor = KeiosCyan.copy(alpha = 0.2f)),
                shape = RoundedCornerShape(16.dp),
                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                modifier = Modifier.testTag("open_simulation_panel_button")
            ) {
                Icon(
                    imageVector = Icons.Default.ElectricBolt,
                    contentDescription = null,
                    tint = KeiosCyan,
                    modifier = Modifier.size(14.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = "Test Live Alert",
                    color = KeiosCyan,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            IconButton(
                onClick = { viewModel.clearAllNotifications() },
                modifier = Modifier.size(36.dp)
            ) {
                Icon(
                    imageVector = Icons.Outlined.DeleteSweep,
                    contentDescription = "Clear All",
                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.size(20.dp)
                )
            }
        }

        // Live Real-Time Status Bar
        Surface(
            color = DarkSurface,
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 4.dp)
                .border(1.dp, DarkBorder, RoundedCornerShape(12.dp)),
            shape = RoundedCornerShape(12.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(10.dp)
                        .clip(CircleShape)
                        .background(KeiosNeonGreen.copy(alpha = pulseAlpha))
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "Real-time Live Sync Active",
                    fontSize = 12.sp,
                    color = KeiosNeonGreen,
                    fontWeight = FontWeight.SemiBold
                )
                Spacer(modifier = Modifier.weight(1f))
                Text(
                    text = "${notifications.size} events",
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        // Live Event Simulator Menu Dropdown
        AnimatedVisibility(visible = showSimulatorMenu) {
            Surface(
                color = DarkSurfaceElevated,
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 6.dp)
                    .border(1.dp, KeiosCyan.copy(alpha = 0.4f), RoundedCornerShape(14.dp))
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text(
                        text = "⚡ Real-time Notification Engine",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = KeiosCyan
                    )
                    Text(
                        text = "Trigger real-time events to test instant in-app alerts and database sync:",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(top = 2.dp, bottom = 8.dp)
                    )

                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        SimulatorQuickButton("❤️ Like", Modifier.weight(1f)) {
                            viewModel.triggerSimulatedNotification("LIKE")
                            showSimulatorMenu = false
                        }
                        SimulatorQuickButton("💬 Comment", Modifier.weight(1f)) {
                            viewModel.triggerSimulatedNotification("COMMENT")
                            showSimulatorMenu = false
                        }
                        SimulatorQuickButton("👤 Follow", Modifier.weight(1f)) {
                            viewModel.triggerSimulatedNotification("FOLLOW")
                            showSimulatorMenu = false
                        }
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        SimulatorQuickButton("🛡️ Security", Modifier.weight(1f)) {
                            viewModel.triggerSimulatedNotification("SECURITY_ALERT")
                            showSimulatorMenu = false
                        }
                        SimulatorQuickButton("📹 Reel Post", Modifier.weight(1f)) {
                            viewModel.triggerSimulatedNotification("REEL_POST")
                            showSimulatorMenu = false
                        }
                        SimulatorQuickButton("🏷️ Mention", Modifier.weight(1f)) {
                            viewModel.triggerSimulatedNotification("MENTION")
                            showSimulatorMenu = false
                        }
                    }
                }
            }
        }

        // Filter Categories
        LazyRow(
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            items(filterOptions) { (key, label) ->
                val isSelected = selectedFilter == key
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(20.dp))
                        .background(if (isSelected) KeiosCyan else DarkSurface)
                        .border(
                            width = 1.dp,
                            color = if (isSelected) KeiosCyan else DarkBorder,
                            shape = RoundedCornerShape(20.dp)
                        )
                        .clickable { selectedFilter = key }
                        .padding(horizontal = 14.dp, vertical = 6.dp)
                        .testTag("filter_tab_$key")
                ) {
                    Text(
                        text = label,
                        fontSize = 12.sp,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                        color = if (isSelected) Color.Black else MaterialTheme.colorScheme.onSurface
                    )
                }
            }
        }

        // Notification Items List
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .testTag("notifications_list")
        ) {
            if (filteredList.isEmpty()) {
                item {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 60.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(
                                imageVector = Icons.Default.DoneAll,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.size(48.dp)
                            )
                            Spacer(modifier = Modifier.height(10.dp))
                            Text(
                                text = "All caught up!",
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "No notifications in this filter",
                                fontSize = 13.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            } else {
                items(filteredList, key = { it.id }) { item ->
                    NotificationRow(
                        notification = item,
                        onItemClick = { viewModel.markNotificationRead(item.id) },
                        onFollowBackClick = { viewModel.toggleFollowBack(item.id, item.isFollowingBack) }
                    )
                }
            }
        }
    }
}

@Composable
private fun SimulatorQuickButton(
    label: String,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(8.dp))
            .background(DarkSurface)
            .border(1.dp, DarkBorder, RoundedCornerShape(8.dp))
            .clickable { onClick() }
            .padding(vertical = 8.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = label,
            fontSize = 11.sp,
            fontWeight = FontWeight.SemiBold,
            color = MaterialTheme.colorScheme.onSurface
        )
    }
}

@Composable
fun NotificationRow(
    notification: NotificationItem,
    onItemClick: () -> Unit,
    onFollowBackClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = modifier
            .fillMaxWidth()
            .clickable { onItemClick() }
            .background(if (!notification.isRead) DarkSurface.copy(alpha = 0.6f) else Color.Transparent)
            .padding(horizontal = 16.dp, vertical = 12.dp)
            .testTag("notification_row_${notification.id}")
    ) {
        // Avatar with Type Badge
        Box(contentAlignment = Alignment.BottomEnd) {
            Image(
                painter = painterResource(id = ResourceHelper.getDrawableRes(notification.senderAvatar)),
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .size(44.dp)
                    .clip(CircleShape)
                    .border(1.dp, DarkBorder, CircleShape)
            )

            // Badge Icon
            val (icon, badgeColor) = when (notification.type) {
                "LIKE" -> Pair(Icons.Default.Favorite, InstagramPink)
                "COMMENT" -> Pair(Icons.Default.ChatBubble, KeiosCyan)
                "FOLLOW" -> Pair(Icons.Default.PersonAdd, Color(0xFF3897F0))
                "SECURITY_ALERT" -> Pair(Icons.Default.Lock, KeiosNeonGreen)
                "REEL_POST" -> Pair(Icons.Default.SlowMotionVideo, Color(0xFF9C27B0))
                else -> Pair(Icons.Default.Favorite, InstagramPink)
            }

            Box(
                modifier = Modifier
                    .size(18.dp)
                    .clip(CircleShape)
                    .background(badgeColor)
                    .border(1.5.dp, DarkBg, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = Color.White,
                    modifier = Modifier.size(10.dp)
                )
            }
        }

        Spacer(modifier = Modifier.width(12.dp))

        // Message body
        Column(modifier = Modifier.weight(1f)) {
            val annotated = buildAnnotatedString {
                withStyle(style = SpanStyle(fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)) {
                    append(notification.senderUsername)
                }
                append(" ")
                append(notification.message)
            }

            Text(
                text = annotated,
                fontSize = 13.sp,
                color = MaterialTheme.colorScheme.onSurface
            )

            Spacer(modifier = Modifier.height(3.dp))

            Text(
                text = formatNotifTime(notification.timestamp),
                fontSize = 11.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        Spacer(modifier = Modifier.width(8.dp))

        // Action or Target Image
        if (notification.type == "FOLLOW") {
            Button(
                onClick = onFollowBackClick,
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (notification.isFollowingBack) DarkSurfaceElevated else KeiosCyan
                ),
                shape = RoundedCornerShape(8.dp),
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                modifier = Modifier.height(32.dp)
            ) {
                Text(
                    text = if (notification.isFollowingBack) "Following" else "Follow Back",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (notification.isFollowingBack) MaterialTheme.colorScheme.onSurface else Color.Black
                )
            }
        } else if (notification.targetPreviewRes != null) {
            Image(
                painter = painterResource(id = ResourceHelper.getDrawableRes(notification.targetPreviewRes)),
                contentDescription = "Target Content",
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .size(44.dp)
                    .clip(RoundedCornerShape(6.dp))
                    .border(1.dp, DarkBorder, RoundedCornerShape(6.dp))
            )
        } else if (!notification.isRead) {
            Box(
                modifier = Modifier
                    .size(8.dp)
                    .clip(CircleShape)
                    .background(KeiosCyan)
            )
        }
    }
}

private fun formatNotifTime(time: Long): String {
    val diff = System.currentTimeMillis() - time
    val mins = diff / (1000 * 60)
    val hours = mins / 60
    val days = hours / 24
    return when {
        mins < 1 -> "just now"
        mins < 60 -> "${mins}m"
        hours < 24 -> "${hours}h"
        else -> "${days}d"
    }
}
