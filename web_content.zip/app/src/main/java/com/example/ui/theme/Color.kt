package com.example.ui.theme

import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

val InstagramPink = Color(0xFFE1306C)
val InstagramPurple = Color(0xFFC13584)
val InstagramOrange = Color(0xFFFD1D1D)
val InstagramYellow = Color(0xFFFCAF45)
val InstagramBlue = Color(0xFF0095F6)
val KeiosCyan = Color(0xFF00E5FF)
val KeiosNeonGreen = Color(0xFF00E676)
val KeiosAmber = Color(0xFFFFB300)

val DarkBg = Color(0xFF0A0A0E)
val DarkSurface = Color(0xFF13131A)
val DarkSurfaceElevated = Color(0xFF1C1C24)
val DarkBorder = Color(0xFF262633)
val DarkTextPrimary = Color(0xFFF5F5F7)
val DarkTextSecondary = Color(0xFFA0A0B0)

val LightBg = Color(0xFFFFFFFF)
val LightSurface = Color(0xFFF8F9FA)
val LightSurfaceElevated = Color(0xFFFFFFFF)
val LightBorder = Color(0xFFE5E7EB)
val LightTextPrimary = Color(0xFF111827)
val LightTextSecondary = Color(0xFF6B7280)

val InstagramStoryBrush = Brush.linearGradient(
    colors = listOf(
        InstagramYellow,
        InstagramOrange,
        InstagramPink,
        InstagramPurple
    )
)

val KeiosCyberBrush = Brush.linearGradient(
    colors = listOf(
        KeiosCyan,
        Color(0xFF7C4DFF),
        InstagramPink
    )
)
