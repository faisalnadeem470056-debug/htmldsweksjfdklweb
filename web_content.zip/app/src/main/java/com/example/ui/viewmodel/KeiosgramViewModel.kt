package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.FilterType
import com.example.data.model.NotificationItem
import com.example.data.model.Post
import com.example.data.model.Reel
import com.example.data.model.ReelComment
import com.example.data.model.UserProfile
import com.example.data.repository.KeiosRepository
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

enum class AppNavigationTab {
    FEED,
    REELS,
    CREATE,
    NOTIFICATIONS,
    PROFILE
}

class KeiosgramViewModel(application: Application) : AndroidViewModel(application) {
    val repository = KeiosRepository(application)

    // Current top-level tab
    private val _currentTab = MutableStateFlow(AppNavigationTab.FEED)
    val currentTab: StateFlow<AppNavigationTab> = _currentTab.asStateFlow()

    // Sub-screens & sheets
    private val _showSecurityScreen = MutableStateFlow(false)
    val showSecurityScreen: StateFlow<Boolean> = _showSecurityScreen.asStateFlow()

    private val _showEditProfile = MutableStateFlow(false)
    val showEditProfile: StateFlow<Boolean> = _showEditProfile.asStateFlow()

    private val _showCreateReelDialog = MutableStateFlow(false)
    val showCreateReelDialog: StateFlow<Boolean> = _showCreateReelDialog.asStateFlow()

    // Real-time in-app notification banner
    private val _activeNotificationBanner = MutableStateFlow<NotificationItem?>(null)
    val activeNotificationBanner: StateFlow<NotificationItem?> = _activeNotificationBanner.asStateFlow()

    // Data streams from Room
    val posts: StateFlow<List<Post>> = repository.allPosts.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val reels: StateFlow<List<Reel>> = repository.allReels.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val notifications: StateFlow<List<NotificationItem>> = repository.allNotifications.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val unreadCount: StateFlow<Int> = repository.unreadNotificationsCount.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = 0
    )

    val userProfile: StateFlow<UserProfile?> = repository.userProfile.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = UserProfile()
    )

    // Active Reel comments sheet state
    private val _activeReelForComments = MutableStateFlow<Reel?>(null)
    val activeReelForComments: StateFlow<Reel?> = _activeReelForComments.asStateFlow()

    private val _activeReelComments = MutableStateFlow<List<ReelComment>>(emptyList())
    val activeReelComments: StateFlow<List<ReelComment>> = _activeReelComments.asStateFlow()

    // Photo editor state
    private val _editorSelectedImage = MutableStateFlow("img_workspace")
    val editorSelectedImage: StateFlow<String> = _editorSelectedImage.asStateFlow()

    private val _editorSelectedFilter = MutableStateFlow(FilterType.NORMAL)
    val editorSelectedFilter: StateFlow<FilterType> = _editorSelectedFilter.asStateFlow()

    private val _editorBrightness = MutableStateFlow(0f)
    val editorBrightness: StateFlow<Float> = _editorBrightness.asStateFlow()

    private val _editorContrast = MutableStateFlow(1f)
    val editorContrast: StateFlow<Float> = _editorContrast.asStateFlow()

    private val _editorSaturation = MutableStateFlow(1f)
    val editorSaturation: StateFlow<Float> = _editorSaturation.asStateFlow()

    private val _editorWarmth = MutableStateFlow(0f)
    val editorWarmth: StateFlow<Float> = _editorWarmth.asStateFlow()

    private val _editorCaption = MutableStateFlow("")
    val editorCaption: StateFlow<String> = _editorCaption.asStateFlow()

    private val _editorLocation = MutableStateFlow("Keios Software • Tokyo HQ")
    val editorLocation: StateFlow<String> = _editorLocation.asStateFlow()

    private val _isPosting = MutableStateFlow(false)
    val isPosting: StateFlow<Boolean> = _isPosting.asStateFlow()

    init {
        // Collect real-time notifications for the banner
        viewModelScope.launch {
            repository.realtimeNotificationEvent.collect { notif ->
                _activeNotificationBanner.value = notif
                delay(4000)
                if (_activeNotificationBanner.value?.id == notif.id) {
                    _activeNotificationBanner.value = null
                }
            }
        }

        // Periodic live notification engine (fires an event every 45s)
        viewModelScope.launch {
            while (true) {
                delay(45000)
                repository.simulateRealtimeNotification()
            }
        }
    }

    fun selectTab(tab: AppNavigationTab) {
        _currentTab.value = tab
        if (tab == AppNavigationTab.NOTIFICATIONS) {
            viewModelScope.launch {
                repository.markAllNotificationsAsRead()
            }
        }
    }

    fun dismissNotificationBanner() {
        _activeNotificationBanner.value = null
    }

    fun triggerSimulatedNotification(type: String? = null) {
        viewModelScope.launch {
            repository.simulateRealtimeNotification(type)
        }
    }

    // Post Actions
    fun togglePostLike(post: Post) {
        viewModelScope.launch {
            repository.togglePostLike(post.id, post.isLiked)
        }
    }

    fun togglePostSave(post: Post) {
        viewModelScope.launch {
            repository.togglePostSave(post.id, post.isSaved)
        }
    }

    // Reel Actions
    fun toggleReelLike(reel: Reel) {
        viewModelScope.launch {
            repository.toggleReelLike(reel.id, reel.isLiked)
        }
    }

    fun toggleReelSave(reel: Reel) {
        viewModelScope.launch {
            repository.toggleReelSave(reel.id, reel.isSaved)
        }
    }

    fun toggleFollowCreator(username: String, isFollowing: Boolean) {
        viewModelScope.launch {
            repository.toggleFollowCreator(username, isFollowing)
        }
    }

    fun openReelComments(reel: Reel) {
        _activeReelForComments.value = reel
        _activeReelComments.value = repository.getReelComments(reel.id)
    }

    fun closeReelComments() {
        _activeReelForComments.value = null
        _activeReelComments.value = emptyList()
    }

    fun postReelComment(text: String) {
        val reel = _activeReelForComments.value ?: return
        if (text.isBlank()) return
        viewModelScope.launch {
            val user = userProfile.value?.username ?: "alex_keios"
            val newComment = repository.addReelComment(reel.id, text.trim(), user)
            _activeReelComments.value = listOf(newComment) + _activeReelComments.value
        }
    }

    // Create Reel
    fun showCreateReelModal() {
        _showCreateReelDialog.value = true
    }

    fun hideCreateReelModal() {
        _showCreateReelDialog.value = false
    }

    fun uploadReel(caption: String, audioTrack: String, videoType: String) {
        viewModelScope.launch {
            val user = userProfile.value
            val newReel = Reel(
                username = user?.username ?: "alex_keios",
                userAvatarRes = user?.avatarRes ?: "img_avatar_me",
                isVerified = user?.isVerified ?: true,
                caption = caption,
                audioTitle = audioTrack,
                audioArtist = user?.fullName ?: "Alex Chen",
                previewImageRes = if (videoType == "TECH_DEMO") "img_reel_conference" else "img_workspace",
                videoType = videoType,
                primaryColorHex = if (videoType == "TECH_DEMO") 0xFF1B003A else 0xFF00223A,
                secondaryColorHex = if (videoType == "TECH_DEMO") 0xFFE1306C else 0xFF00E5FF,
                likesCount = 1,
                isLiked = true,
                commentsCount = 0,
                sharesCount = 0,
                timestamp = System.currentTimeMillis()
            )
            repository.createReel(newReel)
            _showCreateReelDialog.value = false
            _currentTab.value = AppNavigationTab.REELS
        }
    }

    // Photo Filter Studio State & Actions
    fun setEditorImage(imageRes: String) {
        _editorSelectedImage.value = imageRes
    }

    fun setEditorFilter(filter: FilterType) {
        _editorSelectedFilter.value = filter
    }

    fun setEditorBrightness(value: Float) {
        _editorBrightness.value = value
    }

    fun setEditorContrast(value: Float) {
        _editorContrast.value = value
    }

    fun setEditorSaturation(value: Float) {
        _editorSaturation.value = value
    }

    fun setEditorWarmth(value: Float) {
        _editorWarmth.value = value
    }

    fun setEditorCaption(caption: String) {
        _editorCaption.value = caption
    }

    fun setEditorLocation(location: String) {
        _editorLocation.value = location
    }

    fun publishPhotoPost() {
        val caption = _editorCaption.value.trim()
        val image = _editorSelectedImage.value
        val filter = _editorSelectedFilter.value
        val brightness = _editorBrightness.value
        val contrast = _editorContrast.value
        val saturation = _editorSaturation.value
        val warmth = _editorWarmth.value
        val location = _editorLocation.value

        viewModelScope.launch {
            _isPosting.value = true
            val user = userProfile.value
            val newPost = Post(
                username = user?.username ?: "alex_keios",
                userAvatarRes = user?.avatarRes ?: "img_avatar_me",
                isVerified = user?.isVerified ?: true,
                caption = if (caption.isNotEmpty()) caption else "Exploring new horizons with Keios Software 🚀 #keios #tech",
                imageResName = image,
                filterName = filter.name,
                brightness = brightness,
                contrast = contrast,
                saturation = saturation,
                warmth = warmth,
                likesCount = 1,
                isLiked = true,
                commentsCount = 0,
                location = location,
                timestamp = System.currentTimeMillis()
            )
            repository.createPost(newPost)
            // Reset editor
            _editorCaption.value = ""
            _editorBrightness.value = 0f
            _editorContrast.value = 1f
            _editorSaturation.value = 1f
            _editorWarmth.value = 0f
            _editorSelectedFilter.value = FilterType.NORMAL
            _isPosting.value = false
            _currentTab.value = AppNavigationTab.FEED
        }
    }

    // Notifications
    fun markNotificationRead(id: Long) {
        viewModelScope.launch {
            repository.markNotificationAsRead(id)
        }
    }

    fun toggleFollowBack(id: Long, isFollowingBack: Boolean) {
        viewModelScope.launch {
            repository.toggleFollowBack(id, isFollowingBack)
        }
    }

    fun clearAllNotifications() {
        viewModelScope.launch {
            repository.clearAllNotifications()
        }
    }

    // Profile & Security Navigation
    fun openSecuritySettings() {
        _showSecurityScreen.value = true
    }

    fun closeSecuritySettings() {
        _showSecurityScreen.value = false
    }

    fun openEditProfile() {
        _showEditProfile.value = true
    }

    fun closeEditProfile() {
        _showEditProfile.value = false
    }

    fun saveProfile(fullName: String, username: String, bio: String, department: String, website: String) {
        viewModelScope.launch {
            val current = userProfile.value ?: UserProfile()
            val updated = current.copy(
                fullName = fullName,
                username = username,
                bio = bio,
                department = department,
                website = website
            )
            repository.updateProfile(updated)
            _showEditProfile.value = false
        }
    }

    fun toggleTwoFactor(enabled: Boolean) {
        viewModelScope.launch {
            repository.toggleTwoFactor(enabled)
        }
    }

    fun togglePrivateAccount(isPrivate: Boolean) {
        viewModelScope.launch {
            repository.togglePrivateAccount(isPrivate)
        }
    }

    fun toggleBiometricLock(enabled: Boolean) {
        viewModelScope.launch {
            repository.toggleBiometricLock(enabled)
        }
    }

    fun togglePushNotifications(enabled: Boolean) {
        viewModelScope.launch {
            repository.togglePushNotifications(enabled)
        }
    }
}
