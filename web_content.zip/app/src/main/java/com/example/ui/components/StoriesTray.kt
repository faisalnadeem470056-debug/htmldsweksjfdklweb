package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.ui.theme.DarkBg
import com.example.ui.theme.InstagramPink
import com.example.ui.theme.InstagramStoryBrush
import com.example.ui.theme.KeiosCyan
import kotlinx.coroutines.delay

data class StoryItem(
    val id: String,
    val username: String,
    val avatarRes: String,
    val isUser: Boolean = false,
    val isVerified: Boolean = false,
    val storyImageRes: String = "img_workspace",
    val title: String = "Keios Dev Story"
)

@Composable
fun StoriesTray(
    onAddStoryClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val stories = remember {
        listOf(
            StoryItem(
                id = "my_story",
                username = "Your Story",
                avatarRes = "img_avatar_me",
                isUser = true
            ),
            StoryItem(
                id = "s_1",
                username = "keios_official",
                avatarRes = "ic_app_icon",
                isVerified = true,
                storyImageRes = "img_reel_conference",
                title = "Tokyo Architecture Keynote 🌐"
            ),
            StoryItem(
                id = "s_2",
                username = "elena_ux",
                avatarRes = "img_avatar_me",
                isVerified = true,
                storyImageRes = "img_workspace",
                title = "Compose animation tweaks 🎨"
            ),
            StoryItem(
                id = "s_3",
                username = "marcus_ai",
                avatarRes = "img_avatar_me",
                isVerified = true,
                storyImageRes = "img_reel_conference",
                title = "Quantized weights live testing 🧠"
            ),
            StoryItem(
                id = "s_4",
                username = "tokyo_lab",
                avatarRes = "img_workspace",
                isVerified = false,
                storyImageRes = "img_workspace",
                title = "Friday sprint demo & coffee ☕"
            )
        )
    }

    var viewingStory by remember { mutableStateOf<StoryItem?>(null) }

    LazyRow(
        contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp),
        horizontalArrangement = Arrangement.spacedBy(14.dp),
        modifier = modifier
            .fillMaxWidth()
            .testTag("stories_tray")
    ) {
        items(stories, key = { it.id }) { item ->
            StoryBubble(
                item = item,
                onClick = {
                    if (item.isUser) {
                        onAddStoryClick()
                    } else {
                        viewingStory = item
                    }
                }
            )
        }
    }

    // Story View Dialog Modal
    if (viewingStory != null) {
        StoryViewerDialog(
            story = viewingStory!!,
            onDismiss = { viewingStory = null }
        )
    }
}

@Composable
fun StoryBubble(
    item: StoryItem,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = modifier
            .width(72.dp)
            .clickable { onClick() }
            .testTag("story_bubble_${item.username}")
    ) {
        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier.size(68.dp)
        ) {
            // Ring
            if (!item.isUser) {
                Box(
                    modifier = Modifier
                        .size(68.dp)
                        .clip(CircleShape)
                        .background(InstagramStoryBrush)
                )
            }

            // Image
            Image(
                painter = painterResource(id = ResourceHelper.getDrawableRes(item.avatarRes)),
                contentDescription = item.username,
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .size(if (item.isUser) 64.dp else 62.dp)
                    .clip(CircleShape)
                    .border(
                        width = if (item.isUser) 1.dp else 2.5.dp,
                        color = DarkBg,
                        shape = CircleShape
                    )
            )

            // Add (+) Badge for User
            if (item.isUser) {
                Box(
                    modifier = Modifier
                        .align(Alignment.BottomEnd)
                        .size(22.dp)
                        .clip(CircleShape)
                        .background(KeiosCyan)
                        .border(2.dp, DarkBg, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Add,
                        contentDescription = "Add Story",
                        tint = Color.Black,
                        modifier = Modifier.size(14.dp)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(4.dp))

        Text(
            text = item.username,
            fontSize = 11.sp,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            color = MaterialTheme.colorScheme.onSurface,
            textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth()
        )
    }
}

@Composable
fun StoryViewerDialog(
    story: StoryItem,
    onDismiss: () -> Unit
) {
    var progress by remember { mutableFloatStateOf(0f) }

    LaunchedEffect(story) {
        val totalMs = 4000f
        val interval = 40L
        val step = interval / totalMs
        while (progress < 1f) {
            delay(interval)
            progress = (progress + step).coerceAtMost(1f)
        }
        onDismiss()
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black)
                .clickable { onDismiss() }
        ) {
            // Story Image
            Image(
                painter = painterResource(id = ResourceHelper.getDrawableRes(story.storyImageRes)),
                contentDescription = "Story Content",
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )

            // Top Header & Progress
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .statusBarsPadding()
                    .padding(horizontal = 16.dp, vertical = 8.dp)
            ) {
                LinearProgressIndicator(
                    progress = { progress },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(3.dp)
                        .clip(RoundedCornerShape(2.dp)),
                    color = Color.White,
                    trackColor = Color.White.copy(alpha = 0.3f)
                )

                Spacer(modifier = Modifier.height(10.dp))

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Image(
                        painter = painterResource(id = ResourceHelper.getDrawableRes(story.avatarRes)),
                        contentDescription = null,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .border(1.5.dp, KeiosCyan, CircleShape)
                    )

                    Spacer(modifier = Modifier.width(10.dp))

                    Column {
                        Text(
                            text = story.username,
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp
                        )
                        Text(
                            text = story.title,
                            color = Color.White.copy(alpha = 0.8f),
                            fontSize = 12.sp
                        )
                    }

                    Spacer(modifier = Modifier.weight(1f))

                    IconButton(onClick = onDismiss) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Close",
                            tint = Color.White
                        )
                    }
                }
            }

            // Bottom reply prompt
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 20.dp)
            ) {
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .height(44.dp)
                        .clip(RoundedCornerShape(22.dp))
                        .border(1.dp, Color.White.copy(alpha = 0.5f), RoundedCornerShape(22.dp))
                        .background(Color.Black.copy(alpha = 0.4f))
                        .padding(horizontal = 16.dp),
                    contentAlignment = Alignment.CenterStart
                ) {
                    Text(
                        text = "Send message to ${story.username}...",
                        color = Color.White.copy(alpha = 0.7f),
                        fontSize = 13.sp
                    )
                }

                Spacer(modifier = Modifier.width(12.dp))

                Icon(
                    imageVector = Icons.Default.Favorite,
                    contentDescription = "Like Story",
                    tint = InstagramPink,
                    modifier = Modifier.size(28.dp)
                )

                Spacer(modifier = Modifier.width(12.dp))

                Icon(
                    imageVector = Icons.Default.Send,
                    contentDescription = "Share Story",
                    tint = Color.White,
                    modifier = Modifier.size(26.dp)
                )
            }
        }
    }
}
