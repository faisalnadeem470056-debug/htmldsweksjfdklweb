package com.example.ui.screens.profile

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.GridOn
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.SlowMotionVideo
import androidx.compose.material.icons.outlined.BookmarkBorder
import androidx.compose.material.icons.outlined.GridOn
import androidx.compose.material.icons.outlined.Share
import androidx.compose.material.icons.outlined.SlowMotionVideo
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.FilterType
import com.example.data.model.Post
import com.example.data.model.Reel
import com.example.data.model.UserProfile
import com.example.ui.components.ResourceHelper
import com.example.ui.theme.DarkBg
import com.example.ui.theme.DarkBorder
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceElevated
import com.example.ui.theme.InstagramPink
import com.example.ui.theme.InstagramStoryBrush
import com.example.ui.theme.KeiosCyan
import com.example.ui.theme.KeiosNeonGreen
import com.example.ui.viewmodel.KeiosgramViewModel

data class ProfileHighlight(
    val title: String,
    val iconRes: String
)

@Composable
fun ProfileScreen(
    viewModel: KeiosgramViewModel,
    profile: UserProfile,
    posts: List<Post>,
    reels: List<Reel>,
    modifier: Modifier = Modifier
) {
    val showSecurityScreen by viewModel.showSecurityScreen.collectAsState()
    val showEditProfile by viewModel.showEditProfile.collectAsState()
    var selectedProfileTab by remember { mutableIntStateOf(0) } // 0 = Posts, 1 = Reels, 2 = Saved

    if (showSecurityScreen) {
        SecurityManagementScreen(
            viewModel = viewModel,
            profile = profile,
            onBack = { viewModel.closeSecuritySettings() }
        )
        return
    }

    val highlights = remember {
        listOf(
            ProfileHighlight("Keynotes", "img_reel_conference"),
            ProfileHighlight("Workstation", "img_workspace"),
            ProfileHighlight("DevOps", "ic_app_icon"),
            ProfileHighlight("Tokyo Lab", "img_workspace")
        )
    }

    val savedPosts = remember(posts) { posts.filter { it.isSaved } }
    val savedReels = remember(reels) { reels.filter { it.isSaved } }

    LazyVerticalGrid(
        columns = GridCells.Fixed(3),
        horizontalArrangement = Arrangement.spacedBy(2.dp),
        verticalArrangement = Arrangement.spacedBy(2.dp),
        modifier = modifier
            .fillMaxSize()
            .background(DarkBg)
            .statusBarsPadding()
            .testTag("profile_screen_grid")
    ) {
        // Profile Header Section (spans 3 columns)
        item(span = { GridItemSpan(3) }) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp)
            ) {
                // Top Action Bar
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    if (profile.isPrivateAccount) {
                        Icon(
                            imageVector = Icons.Default.Lock,
                            contentDescription = "Private Account",
                            tint = MaterialTheme.colorScheme.onSurface,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                    }

                    Text(
                        text = profile.username,
                        fontSize = 19.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface,
                        modifier = Modifier.testTag("profile_username_text")
                    )

                    if (profile.isVerified) {
                        Spacer(modifier = Modifier.width(4.dp))
                        Icon(
                            imageVector = Icons.Default.CheckCircle,
                            contentDescription = "Verified Keios Account",
                            tint = KeiosCyan,
                            modifier = Modifier.size(16.dp)
                        )
                    }

                    Spacer(modifier = Modifier.weight(1f))

                    // Direct Security Management Button
                    IconButton(
                        onClick = { viewModel.openSecuritySettings() },
                        modifier = Modifier.testTag("open_security_settings_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Security,
                            contentDescription = "Security Settings",
                            tint = KeiosCyan,
                            modifier = Modifier.size(24.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Avatar and Stats Row
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    // Profile Avatar with Keios gradient border
                    Box(contentAlignment = Alignment.Center) {
                        Box(
                            modifier = Modifier
                                .size(84.dp)
                                .clip(CircleShape)
                                .background(InstagramStoryBrush)
                        )
                        Image(
                            painter = painterResource(id = ResourceHelper.getDrawableRes(profile.avatarRes)),
                            contentDescription = "Profile Photo",
                            contentScale = ContentScale.Crop,
                            modifier = Modifier
                                .size(78.dp)
                                .clip(CircleShape)
                                .border(2.dp, DarkBg, CircleShape)
                        )
                    }

                    Spacer(modifier = Modifier.width(24.dp))

                    // Stats: Posts, Followers, Following
                    Row(
                        horizontalArrangement = Arrangement.SpaceAround,
                        modifier = Modifier.weight(1f)
                    ) {
                        StatItem(count = "${posts.size}", label = "Posts")
                        StatItem(count = "${profile.followersCount}", label = "Followers")
                        StatItem(count = "${profile.followingCount}", label = "Following")
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Bio & Details
                Text(
                    text = profile.fullName,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )

                if (profile.department.isNotEmpty()) {
                    Text(
                        text = profile.department,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = KeiosCyan
                    )
                }

                Spacer(modifier = Modifier.height(4.dp))

                Text(
                    text = profile.bio,
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.onSurface
                )

                if (profile.website.isNotEmpty()) {
                    Text(
                        text = profile.website,
                        fontSize = 12.sp,
                        color = Color(0xFF3897F0),
                        fontWeight = FontWeight.Medium
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Security Status Badge (Clickable to open Security)
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = DarkSurfaceElevated,
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, if (profile.isTwoFactorEnabled) KeiosNeonGreen.copy(alpha = 0.4f) else DarkBorder, RoundedCornerShape(12.dp))
                        .clickable { viewModel.openSecuritySettings() }
                        .testTag("security_status_chip")
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Shield,
                            contentDescription = null,
                            tint = if (profile.isTwoFactorEnabled) KeiosNeonGreen else Color(0xFFFFB74D),
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (profile.isTwoFactorEnabled) "🛡️ 2FA Protected • Enterprise Identity Active" else "⚠️ Set up 2FA to secure your account",
                            fontSize = 11.sp,
                            color = if (profile.isTwoFactorEnabled) KeiosNeonGreen else Color(0xFFFFB74D),
                            fontWeight = FontWeight.SemiBold
                        )
                        Spacer(modifier = Modifier.weight(1f))
                        Text(
                            text = "Manage →",
                            fontSize = 11.sp,
                            color = KeiosCyan,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Profile Action Buttons: Edit Profile, Security, Share
                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Button(
                        onClick = { viewModel.openEditProfile() },
                        colors = ButtonDefaults.buttonColors(containerColor = DarkSurfaceElevated),
                        shape = RoundedCornerShape(10.dp),
                        contentPadding = PaddingValues(vertical = 8.dp),
                        modifier = Modifier
                            .weight(1f)
                            .border(1.dp, DarkBorder, RoundedCornerShape(10.dp))
                            .testTag("edit_profile_button")
                    ) {
                        Text(
                            text = "Edit Profile",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }

                    Button(
                        onClick = { viewModel.openSecuritySettings() },
                        colors = ButtonDefaults.buttonColors(containerColor = KeiosCyan.copy(alpha = 0.15f)),
                        shape = RoundedCornerShape(10.dp),
                        contentPadding = PaddingValues(vertical = 8.dp),
                        modifier = Modifier
                            .weight(1f)
                            .border(1.dp, KeiosCyan.copy(alpha = 0.5f), RoundedCornerShape(10.dp))
                            .testTag("security_management_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Security,
                            contentDescription = null,
                            tint = KeiosCyan,
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "Security",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = KeiosCyan
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Story Highlights
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(14.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    items(highlights) { highlight ->
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            modifier = Modifier.width(62.dp)
                        ) {
                            Box(
                                contentAlignment = Alignment.Center,
                                modifier = Modifier
                                    .size(56.dp)
                                    .clip(CircleShape)
                                    .background(DarkSurfaceElevated)
                                    .border(1.dp, DarkBorder, CircleShape)
                            ) {
                                Image(
                                    painter = painterResource(id = ResourceHelper.getDrawableRes(highlight.iconRes)),
                                    contentDescription = highlight.title,
                                    contentScale = ContentScale.Crop,
                                    modifier = Modifier
                                        .size(52.dp)
                                        .clip(CircleShape)
                                )
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = highlight.title,
                                fontSize = 11.sp,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Profile Grid Tabs (Posts, Reels, Saved)
                TabRow(
                    selectedTabIndex = selectedProfileTab,
                    containerColor = DarkSurface,
                    contentColor = KeiosCyan,
                    indicator = { tabPositions ->
                        TabRowDefaults.SecondaryIndicator(
                            modifier = Modifier.tabIndicatorOffset(tabPositions[selectedProfileTab]),
                            color = KeiosCyan
                        )
                    }
                ) {
                    Tab(
                        selected = selectedProfileTab == 0,
                        onClick = { selectedProfileTab = 0 },
                        icon = {
                            Icon(
                                imageVector = if (selectedProfileTab == 0) Icons.Filled.GridOn else Icons.Outlined.GridOn,
                                contentDescription = "Posts Grid",
                                tint = if (selectedProfileTab == 0) KeiosCyan else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    )
                    Tab(
                        selected = selectedProfileTab == 1,
                        onClick = { selectedProfileTab = 1 },
                        icon = {
                            Icon(
                                imageVector = if (selectedProfileTab == 1) Icons.Filled.SlowMotionVideo else Icons.Outlined.SlowMotionVideo,
                                contentDescription = "Reels",
                                tint = if (selectedProfileTab == 1) KeiosCyan else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    )
                    Tab(
                        selected = selectedProfileTab == 2,
                        onClick = { selectedProfileTab = 2 },
                        icon = {
                            Icon(
                                imageVector = if (selectedProfileTab == 2) Icons.Filled.Bookmark else Icons.Outlined.BookmarkBorder,
                                contentDescription = "Saved",
                                tint = if (selectedProfileTab == 2) KeiosCyan else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    )
                }
            }
        }

        // Tab 0: Posts Grid
        if (selectedProfileTab == 0) {
            if (posts.isEmpty()) {
                item(span = { GridItemSpan(3) }) {
                    EmptyProfileSection("No posts yet", "Share photos to build your portfolio")
                }
            } else {
                items(posts, key = { it.id }) { post ->
                    val filter = remember(post.filterName) {
                        try { FilterType.valueOf(post.filterName) } catch (e: Exception) { FilterType.NORMAL }
                    }
                    val colorFilter = remember(filter, post.brightness, post.contrast, post.saturation, post.warmth) {
                        ColorFilter.colorMatrix(
                            filter.getColorMatrix(
                                brightness = post.brightness,
                                contrast = post.contrast,
                                saturation = post.saturation,
                                warmth = post.warmth
                            )
                        )
                    }

                    Box(
                        modifier = Modifier
                            .aspectRatio(1f)
                            .background(DarkSurfaceElevated)
                    ) {
                        Image(
                            painter = painterResource(id = ResourceHelper.getDrawableRes(post.imageResName)),
                            contentDescription = post.caption,
                            contentScale = ContentScale.Crop,
                            colorFilter = colorFilter,
                            modifier = Modifier.fillMaxSize()
                        )
                        if (filter != FilterType.NORMAL) {
                            Box(
                                modifier = Modifier
                                    .align(Alignment.TopEnd)
                                    .padding(4.dp)
                                    .size(8.dp)
                                    .clip(CircleShape)
                                    .background(KeiosCyan)
                            )
                        }
                    }
                }
            }
        } else if (selectedProfileTab == 1) {
            // Tab 1: Reels Grid
            if (reels.isEmpty()) {
                item(span = { GridItemSpan(3) }) {
                    EmptyProfileSection("No Reels yet", "Upload your first Reel to Keiosgram")
                }
            } else {
                items(reels, key = { it.id }) { reel ->
                    Box(
                        modifier = Modifier
                            .aspectRatio(0.75f)
                            .background(
                                Brush.verticalGradient(
                                    listOf(Color(reel.primaryColorHex), Color(reel.secondaryColorHex))
                                )
                            )
                    ) {
                        if (reel.previewImageRes != null) {
                            Image(
                                painter = painterResource(id = ResourceHelper.getDrawableRes(reel.previewImageRes)),
                                contentDescription = reel.caption,
                                contentScale = ContentScale.Crop,
                                modifier = Modifier.fillMaxSize()
                            )
                        }

                        // Play count in bottom left
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .align(Alignment.BottomStart)
                                .padding(6.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.PlayArrow,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(2.dp))
                            Text(
                                text = "${reel.likesCount * 14}",
                                color = Color.White,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        } else {
            // Tab 2: Saved / Bookmarked Items
            if (savedPosts.isEmpty() && savedReels.isEmpty()) {
                item(span = { GridItemSpan(3) }) {
                    EmptyProfileSection("No saved items", "Bookmark posts or reels to view them here")
                }
            } else {
                items(savedPosts, key = { "saved_${it.id}" }) { post ->
                    Box(
                        modifier = Modifier
                            .aspectRatio(1f)
                            .background(DarkSurfaceElevated)
                    ) {
                        Image(
                            painter = painterResource(id = ResourceHelper.getDrawableRes(post.imageResName)),
                            contentDescription = post.caption,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize()
                        )
                        Box(
                            modifier = Modifier
                                .align(Alignment.TopEnd)
                                .padding(4.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Bookmark,
                                contentDescription = null,
                                tint = KeiosCyan,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                }
            }
        }
    }

    // Edit Profile Bottom Sheet
    if (showEditProfile) {
        EditProfileSheet(
            profile = profile,
            onDismiss = { viewModel.closeEditProfile() },
            onSave = { fullName, username, bio, department, website ->
                viewModel.saveProfile(fullName, username, bio, department, website)
            }
        )
    }
}

@Composable
private fun StatItem(count: String, label: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(
            text = count,
            fontSize = 17.sp,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onSurface
        )
        Text(
            text = label,
            fontSize = 12.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

@Composable
private fun EmptyProfileSection(title: String, subtitle: String) {
    Box(
        contentAlignment = Alignment.Center,
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 40.dp)
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                text = title,
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = subtitle,
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}
