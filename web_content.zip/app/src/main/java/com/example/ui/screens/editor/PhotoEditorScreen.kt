package com.example.ui.screens.editor

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Crop
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.FilterType
import com.example.ui.components.ResourceHelper
import com.example.ui.theme.DarkBg
import com.example.ui.theme.DarkBorder
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceElevated
import com.example.ui.theme.InstagramPink
import com.example.ui.theme.KeiosCyan
import com.example.ui.viewmodel.AppNavigationTab
import com.example.ui.viewmodel.KeiosgramViewModel

@Composable
fun PhotoEditorScreen(
    viewModel: KeiosgramViewModel,
    modifier: Modifier = Modifier
) {
    val selectedImage by viewModel.editorSelectedImage.collectAsState()
    val selectedFilter by viewModel.editorSelectedFilter.collectAsState()
    val brightness by viewModel.editorBrightness.collectAsState()
    val contrast by viewModel.editorContrast.collectAsState()
    val saturation by viewModel.editorSaturation.collectAsState()
    val warmth by viewModel.editorWarmth.collectAsState()
    val caption by viewModel.editorCaption.collectAsState()
    val location by viewModel.editorLocation.collectAsState()
    val isPosting by viewModel.isPosting.collectAsState()

    var editorTab by remember { mutableIntStateOf(0) } // 0 = Filters, 1 = Adjust
    var activeSticker by remember { mutableStateOf<String?>(null) }
    var selectedAspectRatio by remember { mutableFloatStateOf(1f) } // 1f = 1:1, 0.8f = 4:5, 1.77f = 16:9

    val imageChoices = listOf(
        Pair("img_workspace", "Workstation"),
        Pair("img_reel_conference", "Tech Summit"),
        Pair("img_avatar_me", "Portrait")
    )

    val stickers = listOf(
        "⚡ Keios v2.4",
        "🚀 Tokyo Summit",
        "💻 120 FPS Compose",
        "✨ Clean Architecture"
    )

    // Current color matrix for main preview
    val mainColorFilter = remember(selectedFilter, brightness, contrast, saturation, warmth) {
        ColorFilter.colorMatrix(
            selectedFilter.getColorMatrix(
                brightness = brightness,
                contrast = contrast,
                saturation = saturation,
                warmth = warmth
            )
        )
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(DarkBg)
            .statusBarsPadding()
            .verticalScroll(rememberScrollState())
    ) {
        // Top Bar
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 10.dp)
        ) {
            IconButton(
                onClick = { viewModel.selectTab(AppNavigationTab.FEED) },
                modifier = Modifier.size(36.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Close,
                    contentDescription = "Cancel",
                    tint = MaterialTheme.colorScheme.onSurface
                )
            }

            Text(
                text = "Photo Filter Studio",
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface,
                modifier = Modifier.padding(start = 8.dp)
            )

            Spacer(modifier = Modifier.weight(1f))

            // Next / Share Button
            Button(
                onClick = { viewModel.publishPhotoPost() },
                enabled = !isPosting,
                colors = ButtonDefaults.buttonColors(containerColor = InstagramPink),
                shape = RoundedCornerShape(20.dp),
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 6.dp),
                modifier = Modifier.testTag("publish_post_button")
            ) {
                if (isPosting) {
                    CircularProgressIndicator(
                        color = Color.White,
                        modifier = Modifier.size(16.dp),
                        strokeWidth = 2.dp
                    )
                } else {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = "Share",
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Icon(
                            imageVector = Icons.Default.Share,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(14.dp)
                        )
                    }
                }
            }
        }

        // Live Photo Viewport
        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier
                .fillMaxWidth()
                .aspectRatio(1f)
                .background(Color.Black)
                .padding(8.dp)
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .clip(RoundedCornerShape(12.dp))
            ) {
                Image(
                    painter = painterResource(id = ResourceHelper.getDrawableRes(selectedImage)),
                    contentDescription = "Photo Preview",
                    contentScale = ContentScale.Crop,
                    colorFilter = mainColorFilter,
                    modifier = Modifier.fillMaxSize()
                )

                // Filter Watermark Tag
                Surface(
                    shape = RoundedCornerShape(14.dp),
                    color = Color.Black.copy(alpha = 0.65f),
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .padding(12.dp)
                ) {
                    Text(
                        text = "✨ ${selectedFilter.displayName}",
                        color = Color.White,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }

                // Optional Overlay Sticker
                if (activeSticker != null) {
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = KeiosCyan.copy(alpha = 0.90f),
                        shadowElevation = 6.dp,
                        modifier = Modifier
                            .align(Alignment.BottomStart)
                            .padding(14.dp)
                            .clickable { activeSticker = null }
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                        ) {
                            Text(
                                text = activeSticker!!,
                                color = Color.Black,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Icon(
                                imageVector = Icons.Default.Close,
                                contentDescription = "Remove sticker",
                                tint = Color.Black,
                                modifier = Modifier.size(12.dp)
                            )
                        }
                    }
                }
            }
        }

        // Photo Source Picker Row
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 6.dp)
        ) {
            Text(
                text = "Source:",
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                fontWeight = FontWeight.SemiBold
            )
            imageChoices.forEach { (imgKey, label) ->
                val isSelected = selectedImage == imgKey
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (isSelected) KeiosCyan.copy(alpha = 0.2f) else DarkSurface)
                        .border(
                            width = 1.dp,
                            color = if (isSelected) KeiosCyan else DarkBorder,
                            shape = RoundedCornerShape(8.dp)
                        )
                        .clickable { viewModel.setEditorImage(imgKey) }
                        .padding(horizontal = 10.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = label,
                        fontSize = 11.sp,
                        color = if (isSelected) KeiosCyan else MaterialTheme.colorScheme.onSurface,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                    )
                }
            }
        }

        // Stickers Row
        LazyRow(
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(stickers) { sticker ->
                val isSelected = activeSticker == sticker
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = if (isSelected) InstagramPink else DarkSurface,
                    modifier = Modifier
                        .border(1.dp, if (isSelected) InstagramPink else DarkBorder, RoundedCornerShape(12.dp))
                        .clickable { activeSticker = if (isSelected) null else sticker }
                ) {
                    Text(
                        text = sticker,
                        color = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurface,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Medium,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                    )
                }
            }
        }

        // Studio Tabs: Filters vs Adjust
        TabRow(
            selectedTabIndex = editorTab,
            containerColor = DarkSurface,
            contentColor = KeiosCyan,
            indicator = { tabPositions ->
                TabRowDefaults.SecondaryIndicator(
                    modifier = Modifier.tabIndicatorOffset(tabPositions[editorTab]),
                    color = KeiosCyan
                )
            },
            modifier = Modifier.padding(top = 8.dp)
        ) {
            Tab(
                selected = editorTab == 0,
                onClick = { editorTab = 0 },
                text = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.AutoAwesome,
                            contentDescription = null,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Filters", fontWeight = FontWeight.Bold)
                    }
                }
            )
            Tab(
                selected = editorTab == 1,
                onClick = { editorTab = 1 },
                text = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Tune,
                            contentDescription = null,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Adjust", fontWeight = FontWeight.Bold)
                    }
                }
            )
        }

        // Tab 0: Filters Carousel
        if (editorTab == 0) {
            Column(modifier = Modifier.fillMaxWidth().padding(vertical = 12.dp)) {
                Text(
                    text = "Tap to apply Instagram filter:",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)
                )

                LazyRow(
                    contentPadding = PaddingValues(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    modifier = Modifier.fillMaxWidth().testTag("filter_carousel")
                ) {
                    items(FilterType.entries) { filterType ->
                        val isSelected = selectedFilter == filterType
                        val previewFilter = remember(filterType) {
                            ColorFilter.colorMatrix(filterType.getColorMatrix())
                        }

                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            modifier = Modifier
                                .width(78.dp)
                                .clickable { viewModel.setEditorFilter(filterType) }
                                .testTag("filter_item_${filterType.name}")
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(72.dp)
                                    .clip(RoundedCornerShape(12.dp))
                                    .border(
                                        width = if (isSelected) 2.5.dp else 1.dp,
                                        color = if (isSelected) KeiosCyan else DarkBorder,
                                        shape = RoundedCornerShape(12.dp)
                                    )
                            ) {
                                Image(
                                    painter = painterResource(id = ResourceHelper.getDrawableRes(selectedImage)),
                                    contentDescription = filterType.displayName,
                                    contentScale = ContentScale.Crop,
                                    colorFilter = previewFilter,
                                    modifier = Modifier.fillMaxSize()
                                )
                                if (isSelected) {
                                    Box(
                                        modifier = Modifier
                                            .align(Alignment.BottomEnd)
                                            .padding(4.dp)
                                            .size(16.dp)
                                            .clip(CircleShape)
                                            .background(KeiosCyan),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Check,
                                            contentDescription = null,
                                            tint = Color.Black,
                                            modifier = Modifier.size(11.dp)
                                        )
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(6.dp))

                            Text(
                                text = filterType.displayName,
                                fontSize = 11.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                color = if (isSelected) KeiosCyan else MaterialTheme.colorScheme.onSurface,
                                textAlign = TextAlign.Center,
                                maxLines = 1
                            )
                        }
                    }
                }
            }
        } else {
            // Tab 1: Adjust Sliders
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // Brightness
                SliderAdjustment(
                    label = "Brightness",
                    value = brightness,
                    valueRange = -80f..80f,
                    displayValue = "${brightness.toInt()}",
                    onValueChange = { viewModel.setEditorBrightness(it) }
                )

                // Contrast
                SliderAdjustment(
                    label = "Contrast",
                    value = contrast,
                    valueRange = 0.5f..1.8f,
                    displayValue = String.format("%.2fx", contrast),
                    onValueChange = { viewModel.setEditorContrast(it) }
                )

                // Saturation
                SliderAdjustment(
                    label = "Saturation",
                    value = saturation,
                    valueRange = 0.0f..2.0f,
                    displayValue = String.format("%.2fx", saturation),
                    onValueChange = { viewModel.setEditorSaturation(it) }
                )

                // Warmth
                SliderAdjustment(
                    label = "Warmth",
                    value = warmth,
                    valueRange = -40f..40f,
                    displayValue = "${warmth.toInt()}",
                    onValueChange = { viewModel.setEditorWarmth(it) }
                )
            }
        }

        // Caption & Location Post Form
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Text(
                text = "Post Details",
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp,
                color = MaterialTheme.colorScheme.onSurface
            )

            Spacer(modifier = Modifier.height(8.dp))

            OutlinedTextField(
                value = caption,
                onValueChange = { viewModel.setEditorCaption(it) },
                placeholder = { Text("Write a caption... e.g. Shipping new features! #keios #tech") },
                minLines = 3,
                maxLines = 4,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("post_caption_input"),
                shape = RoundedCornerShape(12.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = KeiosCyan,
                    unfocusedBorderColor = DarkBorder,
                    focusedTextColor = MaterialTheme.colorScheme.onSurface,
                    unfocusedTextColor = MaterialTheme.colorScheme.onSurface
                )
            )

            Spacer(modifier = Modifier.height(10.dp))

            OutlinedTextField(
                value = location,
                onValueChange = { viewModel.setEditorLocation(it) },
                leadingIcon = {
                    Icon(
                        imageVector = Icons.Default.LocationOn,
                        contentDescription = "Location",
                        tint = KeiosCyan,
                        modifier = Modifier.size(18.dp)
                    )
                },
                placeholder = { Text("Add location") },
                singleLine = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("post_location_input"),
                shape = RoundedCornerShape(12.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = KeiosCyan,
                    unfocusedBorderColor = DarkBorder,
                    focusedTextColor = MaterialTheme.colorScheme.onSurface,
                    unfocusedTextColor = MaterialTheme.colorScheme.onSurface
                )
            )

            Spacer(modifier = Modifier.height(16.dp))

            Button(
                onClick = { viewModel.publishPhotoPost() },
                enabled = !isPosting,
                colors = ButtonDefaults.buttonColors(containerColor = InstagramPink),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("publish_feed_post_button")
            ) {
                Text(
                    text = "Share to Feed",
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    color = Color.White
                )
            }
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

@Composable
private fun SliderAdjustment(
    label: String,
    value: Float,
    valueRange: ClosedFloatingPointRange<Float>,
    displayValue: String,
    onValueChange: (Float) -> Unit
) {
    Column {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(
                text = label,
                fontSize = 13.sp,
                fontWeight = FontWeight.Medium,
                color = MaterialTheme.colorScheme.onSurface
            )
            Spacer(modifier = Modifier.weight(1f))
            Text(
                text = displayValue,
                fontSize = 12.sp,
                color = KeiosCyan,
                fontWeight = FontWeight.Bold
            )
        }
        Slider(
            value = value,
            onValueChange = onValueChange,
            valueRange = valueRange,
            colors = SliderDefaults.colors(
                thumbColor = KeiosCyan,
                activeTrackColor = KeiosCyan,
                inactiveTrackColor = DarkBorder
            )
        )
    }
}
