package com.example.ui.components

import androidx.annotation.DrawableRes
import com.example.R

object ResourceHelper {
    @DrawableRes
    fun getDrawableRes(name: String?): Int {
        return when (name) {
            "img_workspace" -> R.drawable.img_workspace
            "img_reel_conference" -> R.drawable.img_reel_conference
            "img_avatar_me" -> R.drawable.img_avatar_me
            "ic_app_icon" -> R.drawable.ic_app_icon
            else -> R.drawable.img_workspace
        }
    }
}
