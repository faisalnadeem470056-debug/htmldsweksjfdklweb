package com.example.data.repository

import android.content.Context
import com.example.data.local.KeiosgramDatabase
import com.example.data.model.ActiveSession
import com.example.data.model.NotificationItem
import com.example.data.model.Post
import com.example.data.model.Reel
import com.example.data.model.ReelComment
import com.example.data.model.SecurityAuditEntry
import com.example.data.model.UserProfile
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.launch
import kotlin.random.Random

class KeiosRepository(context: Context) {
    private val db = KeiosgramDatabase.getDatabase(context)
    private val postDao = db.postDao()
    private val reelDao = db.reelDao()
    private val notificationDao = db.notificationDao()
    private val userProfileDao = db.userProfileDao()

    private val scope = CoroutineScope(Dispatchers.IO)

    // Live real-time notification broadcast for in-app banner alert
    private val _realtimeNotificationEvent = MutableSharedFlow<NotificationItem>(extraBufferCapacity = 10)
    val realtimeNotificationEvent = _realtimeNotificationEvent.asSharedFlow()

    // Local in-memory comments for reels
    private val _reelComments = mutableMapOf<Long, MutableList<ReelComment>>()

    val allPosts: Flow<List<Post>> = postDao.getAllPosts()
    val savedPosts: Flow<List<Post>> = postDao.getSavedPosts()
    val allReels: Flow<List<Reel>> = reelDao.getAllReels()
    val savedReels: Flow<List<Reel>> = reelDao.getSavedReels()
    val allNotifications: Flow<List<NotificationItem>> = notificationDao.getAllNotifications()
    val unreadNotificationsCount: Flow<Int> = notificationDao.getUnreadCount()
    val userProfile: Flow<UserProfile?> = userProfileDao.getUserProfile()

    // Security sessions and audit logs
    val activeSessions = listOf(
        ActiveSession(
            id = "sess_1",
            deviceName = "Pixel 8 Pro • Keios Secure Enclave",
            clientType = "Android App v2.4 (Keiosgram)",
            location = "Tokyo, Japan",
            lastActive = "Active now",
            isCurrent = true
        ),
        ActiveSession(
            id = "sess_2",
            deviceName = "MacBook Pro 16\" (M3 Max)",
            clientType = "Keios Enterprise SSO Web",
            location = "Tokyo, Japan",
            lastActive = "2 hours ago",
            isCurrent = false
        ),
        ActiveSession(
            id = "sess_3",
            deviceName = "iPad Pro 12.9\"",
            clientType = "Keios Mobile Companion",
            location = "San Francisco, CA",
            lastActive = "Yesterday at 18:42",
            isCurrent = false
        )
    )

    val securityAuditEntries = listOf(
        SecurityAuditEntry(
            id = "aud_1",
            title = "Two-Factor Auth Verified",
            description = "TOTP token passed from Keios Authenticator App",
            timestamp = "Just now",
            severity = "SUCCESS"
        ),
        SecurityAuditEntry(
            id = "aud_2",
            title = "Biometric Unlock Enabled",
            description = "Fingerprint / Face Unlock authorized for app launch",
            timestamp = "2 hours ago",
            severity = "INFO"
        ),
        SecurityAuditEntry(
            id = "aud_3",
            title = "Password Security Check",
            description = "Password entropy score 98/100 (Strong)",
            timestamp = "12 days ago",
            severity = "INFO"
        ),
        SecurityAuditEntry(
            id = "aud_4",
            title = "Session Granted via Keios SSO",
            description = "Tokyo Office VPN gateway (133.242.18.42)",
            timestamp = "14 days ago",
            severity = "SUCCESS"
        )
    )

    init {
        scope.launch {
            seedDatabaseIfEmpty()
        }
    }

    private suspend fun seedDatabaseIfEmpty() {
        if (postDao.getCount() == 0) {
            val initialPosts = listOf(
                Post(
                    id = 1,
                    username = "alex_keios",
                    userAvatarRes = "img_avatar_me",
                    isVerified = true,
                    caption = "Shipping the next iteration of the Keios Mobile Runtime engine! 🚀 Clean code, zero-alloc state pipelines, and smooth 120 FPS Compose interactions. What's on your tech stack this week?\n\n#keios #androiddev #kotlin #jetpackcompose #engineering",
                    imageResName = "img_workspace",
                    filterName = "JUNO",
                    contrast = 1.1f,
                    saturation = 1.15f,
                    likesCount = 342,
                    isLiked = true,
                    commentsCount = 28,
                    location = "Keios Software HQ • Tokyo, JP",
                    timestamp = System.currentTimeMillis() - 1000 * 60 * 45 // 45 mins ago
                ),
                Post(
                    id = 2,
                    username = "keios_software",
                    userAvatarRes = "ic_app_icon",
                    isVerified = true,
                    caption = "Keynote highlights from the annual Keios Global Tech Summit 🌐 Our engineering teams presented breakthroughs in offline-first sync, edge AI models, and real-time social tooling.\n\n#keiossummit #techinnovation #futureofcode #engineeringlife",
                    imageResName = "img_reel_conference",
                    filterName = "CLARENDON",
                    contrast = 1.2f,
                    saturation = 1.1f,
                    likesCount = 1890,
                    isLiked = false,
                    commentsCount = 142,
                    location = "Keios International Hall • Shibuya",
                    timestamp = System.currentTimeMillis() - 1000 * 60 * 180
                ),
                Post(
                    id = 3,
                    username = "elena_ux",
                    userAvatarRes = "img_avatar_me",
                    isVerified = true,
                    caption = "Refining micro-interactions and dark mode color palettes for Keiosgram! 🎨 High contrast surfaces with subtle luminous neon edges. Designing with empathy and engineering in mind.\n\n#designsystems #uiux #materialdesign #mobileart",
                    imageResName = "img_workspace",
                    filterName = "VALENCIA",
                    warmth = 15f,
                    likesCount = 512,
                    isLiked = false,
                    commentsCount = 45,
                    location = "Keios Design Lab",
                    timestamp = System.currentTimeMillis() - 1000 * 60 * 60 * 8
                ),
                Post(
                    id = 4,
                    username = "marcus_devops",
                    userAvatarRes = "img_avatar_me",
                    isVerified = false,
                    caption = "All 420 automated unit tests & screenshot assertions passed on CI! Branch merged into main without a single conflict. Feeling victorious on a Friday afternoon! 💻✨\n\n#devops #cicd #cleancode #weekendready",
                    imageResName = "img_reel_conference",
                    filterName = "KEIOS_CYBER",
                    likesCount = 278,
                    isLiked = false,
                    commentsCount = 19,
                    location = "Server Farm 03",
                    timestamp = System.currentTimeMillis() - 1000 * 60 * 60 * 24
                )
            )
            postDao.insertAll(initialPosts)
        }

        if (reelDao.getCount() == 0) {
            val initialReels = listOf(
                Reel(
                    id = 1,
                    username = "elena_ux",
                    userAvatarRes = "img_avatar_me",
                    isVerified = true,
                    caption = "Building micro-animations in Jetpack Compose in under 60 seconds! ⚡ Watch how we handle custom spring transitions in Keiosgram. #android #compose #keios",
                    audioTitle = "Keios Beats • Ambient Pulse",
                    audioArtist = "Keios Sound Studio",
                    previewImageRes = "img_reel_conference",
                    videoType = "DESIGN_SYSTEM",
                    primaryColorHex = 0xFF12002B,
                    secondaryColorHex = 0xFF6B11B0,
                    likesCount = 1420,
                    isLiked = true,
                    commentsCount = 89,
                    sharesCount = 230,
                    isFollowing = true,
                    timestamp = System.currentTimeMillis() - 1000 * 60 * 30
                ),
                Reel(
                    id = 2,
                    username = "alex_keios",
                    userAvatarRes = "img_avatar_me",
                    isVerified = true,
                    caption = "Day in the life of a Staff Engineer @ Keios Software Tokyo ☕ From morning standup to shipping high-throughput data layers.\n#tokyo #softwareengineer #keioslife #officevlog",
                    audioTitle = "Tokyo Lofi Coffee House",
                    audioArtist = "Chillhop Tokyo",
                    previewImageRes = "img_workspace",
                    videoType = "OFFICE_VLOG",
                    primaryColorHex = 0xFF0D1B2A,
                    secondaryColorHex = 0xFF1B4965,
                    likesCount = 3850,
                    isLiked = false,
                    commentsCount = 244,
                    sharesCount = 612,
                    isFollowing = false,
                    timestamp = System.currentTimeMillis() - 1000 * 60 * 120
                ),
                Reel(
                    id = 3,
                    username = "marcus_ai",
                    userAvatarRes = "img_avatar_me",
                    isVerified = true,
                    caption = "Running on-device local quantized LLM inference at 60 FPS on Android! Keios Neural Engine running locally with zero cloud lag 🧠⚡ #ai #android #futuretech",
                    audioTitle = "Cybernetic Glitch & Synth",
                    audioArtist = "Neural Soundworks",
                    previewImageRes = null,
                    videoType = "AI_INFERENCE",
                    primaryColorHex = 0xFF001B2E,
                    secondaryColorHex = 0xFF00E5FF,
                    likesCount = 5910,
                    isLiked = false,
                    commentsCount = 412,
                    sharesCount = 980,
                    isFollowing = false,
                    timestamp = System.currentTimeMillis() - 1000 * 60 * 360
                ),
                Reel(
                    id = 4,
                    username = "keios_official",
                    userAvatarRes = "ic_app_icon",
                    isVerified = true,
                    caption = "Welcome to the Keios Software ecosystem 🚀 Building software that scales without compromise. Tag your teammates who need to see this! #keios #tech #future",
                    audioTitle = "Keios Anthem 2026",
                    audioArtist = "Keios Audio",
                    previewImageRes = "img_reel_conference",
                    videoType = "TECH_DEMO",
                    primaryColorHex = 0xFF2B0938,
                    secondaryColorHex = 0xFFE1306C,
                    likesCount = 8420,
                    isLiked = true,
                    commentsCount = 632,
                    sharesCount = 1450,
                    isFollowing = true,
                    timestamp = System.currentTimeMillis() - 1000 * 60 * 60 * 12
                )
            )
            reelDao.insertAll(initialReels)

            // Seed sample comments for reel 1
            _reelComments[1L] = mutableListOf(
                ReelComment(1, 1, "marcus_ai", "img_avatar_me", "That spring stiffness curve is so satisfying to watch! 🔥", System.currentTimeMillis() - 15000, 24),
                ReelComment(2, 1, "kenji_dev", "img_avatar_me", "Is this part of the new Keios UI Kit? Can't wait to adopt it in our team.", System.currentTimeMillis() - 10000, 15),
                ReelComment(3, 1, "sarah_cloud", "img_avatar_me", "Incredible performance. 60 FPS locked even with heavy blur!", System.currentTimeMillis() - 4000, 8)
            )
            _reelComments[2L] = mutableListOf(
                ReelComment(4, 2, "elena_ux", "img_avatar_me", "The view from the 18th floor lab is awesome! 🗼", System.currentTimeMillis() - 60000, 32),
                ReelComment(5, 2, "dev_community", "img_avatar_me", "What keyboard switches are you using in the desk shot?", System.currentTimeMillis() - 30000, 11)
            )
        }

        if (notificationDao.getCount() == 0) {
            val initialNotifications = listOf(
                NotificationItem(
                    id = 1,
                    type = "LIKE",
                    senderUsername = "elena_ux",
                    senderAvatar = "img_avatar_me",
                    message = "liked your post 'Shipping the next iteration of Keios Mobile Runtime'",
                    targetPreviewRes = "img_workspace",
                    timestamp = System.currentTimeMillis() - 1000 * 60 * 5,
                    isRead = false
                ),
                NotificationItem(
                    id = 2,
                    type = "COMMENT",
                    senderUsername = "marcus_ai",
                    senderAvatar = "img_avatar_me",
                    message = "commented: \"The zero-alloc state pipeline benchmark is incredible!\" on your post",
                    targetPreviewRes = "img_workspace",
                    timestamp = System.currentTimeMillis() - 1000 * 60 * 22,
                    isRead = false
                ),
                NotificationItem(
                    id = 3,
                    type = "REEL_POST",
                    senderUsername = "keios_official",
                    senderAvatar = "ic_app_icon",
                    message = "shared a new reel: 'Welcome to the Keios Software ecosystem 🚀'",
                    targetPreviewRes = "img_reel_conference",
                    timestamp = System.currentTimeMillis() - 1000 * 60 * 45,
                    isRead = false
                ),
                NotificationItem(
                    id = 4,
                    type = "FOLLOW",
                    senderUsername = "kenji_dev",
                    senderAvatar = "img_avatar_me",
                    message = "started following you.",
                    timestamp = System.currentTimeMillis() - 1000 * 60 * 120,
                    isRead = true,
                    isFollowingBack = false
                ),
                NotificationItem(
                    id = 5,
                    type = "SECURITY_ALERT",
                    senderUsername = "Keios Security",
                    senderAvatar = "ic_app_icon",
                    message = "Two-Factor Authentication successfully verified for session on Pixel 8 Pro.",
                    timestamp = System.currentTimeMillis() - 1000 * 60 * 180,
                    isRead = true
                ),
                NotificationItem(
                    id = 6,
                    type = "MENTION",
                    senderUsername = "elena_ux",
                    senderAvatar = "img_avatar_me",
                    message = "mentioned you in a comment: \"@alex_keios nailed the architecture on this!\"",
                    targetPreviewRes = "img_reel_conference",
                    timestamp = System.currentTimeMillis() - 1000 * 60 * 360,
                    isRead = true
                )
            )
            notificationDao.insertAll(initialNotifications)
        }

        if (userProfileDao.getUserProfile() == null) {
            userProfileDao.insertOrUpdate(UserProfile())
        }
    }

    // Post Actions
    suspend fun togglePostLike(id: Long, currentlyLiked: Boolean) {
        val newLiked = !currentlyLiked
        val delta = if (newLiked) 1 else -1
        postDao.toggleLike(id, newLiked, delta)
    }

    suspend fun togglePostSave(id: Long, currentlySaved: Boolean) {
        postDao.toggleSave(id, !currentlySaved)
    }

    suspend fun createPost(post: Post): Long {
        val id = postDao.insertPost(post)
        userProfileDao.incrementPostsCount()
        // Trigger a real-time notification
        val newNotification = NotificationItem(
            type = "LIKE",
            senderUsername = "keios_community",
            senderAvatar = "ic_app_icon",
            message = "and 3 others liked your new photo post!",
            targetPreviewRes = post.imageResName,
            timestamp = System.currentTimeMillis(),
            isRead = false
        )
        notificationDao.insertNotification(newNotification)
        _realtimeNotificationEvent.emit(newNotification)
        return id
    }

    // Reel Actions
    suspend fun toggleReelLike(id: Long, currentlyLiked: Boolean) {
        val newLiked = !currentlyLiked
        val delta = if (newLiked) 1 else -1
        reelDao.toggleLike(id, newLiked, delta)
    }

    suspend fun toggleReelSave(id: Long, currentlySaved: Boolean) {
        reelDao.toggleSave(id, !currentlySaved)
    }

    suspend fun toggleFollowCreator(username: String, currentlyFollowing: Boolean) {
        reelDao.updateFollowStatus(username, !currentlyFollowing)
    }

    suspend fun createReel(reel: Reel): Long {
        val id = reelDao.insertReel(reel)
        // Emit live notification for upload
        val newNotification = NotificationItem(
            type = "REEL_POST",
            senderUsername = "Keiosgram Studio",
            senderAvatar = "ic_app_icon",
            message = "Your Reel '${reel.caption.take(28)}...' is live and reaching the team!",
            targetPreviewRes = reel.previewImageRes,
            timestamp = System.currentTimeMillis(),
            isRead = false
        )
        notificationDao.insertNotification(newNotification)
        _realtimeNotificationEvent.emit(newNotification)
        return id
    }

    fun getReelComments(reelId: Long): List<ReelComment> {
        return _reelComments[reelId] ?: emptyList()
    }

    suspend fun addReelComment(reelId: Long, text: String, username: String): ReelComment {
        val list = _reelComments.getOrPut(reelId) { mutableListOf() }
        val newComment = ReelComment(
            id = System.currentTimeMillis(),
            reelId = reelId,
            username = username,
            userAvatarRes = "img_avatar_me",
            text = text,
            timestamp = System.currentTimeMillis(),
            likesCount = 0
        )
        list.add(0, newComment)
        reelDao.incrementCommentsCount(reelId)
        return newComment
    }

    // Notification Actions
    suspend fun markAllNotificationsAsRead() {
        notificationDao.markAllAsRead()
    }

    suspend fun markNotificationAsRead(id: Long) {
        notificationDao.markAsRead(id)
    }

    suspend fun toggleFollowBack(id: Long, currentlyFollowing: Boolean) {
        notificationDao.updateFollowBack(id, !currentlyFollowing)
    }

    suspend fun clearAllNotifications() {
        notificationDao.clearAll()
    }

    // Simulate real-time notification from team or community
    suspend fun simulateRealtimeNotification(type: String? = null): NotificationItem {
        val possibleSenders = listOf("elena_ux", "marcus_ai", "sarah_cloud", "kenji_dev", "keios_official", "tatsuya_lead")
        val sender = possibleSenders.random()
        val notifType = type ?: listOf("LIKE", "COMMENT", "FOLLOW", "MENTION", "REEL_POST").random()

        val notif = when (notifType) {
            "LIKE" -> NotificationItem(
                type = "LIKE",
                senderUsername = sender,
                senderAvatar = "img_avatar_me",
                message = "liked your Reel on Keiosgram!",
                targetPreviewRes = "img_reel_conference",
                timestamp = System.currentTimeMillis(),
                isRead = false
            )
            "COMMENT" -> NotificationItem(
                type = "COMMENT",
                senderUsername = sender,
                senderAvatar = "img_avatar_me",
                message = "commented: \"Super clean code, exactly what we needed! 🔥\"",
                targetPreviewRes = "img_workspace",
                timestamp = System.currentTimeMillis(),
                isRead = false
            )
            "FOLLOW" -> NotificationItem(
                type = "FOLLOW",
                senderUsername = sender,
                senderAvatar = "img_avatar_me",
                message = "started following you on Keiosgram.",
                timestamp = System.currentTimeMillis(),
                isRead = false,
                isFollowingBack = false
            )
            "MENTION" -> NotificationItem(
                type = "MENTION",
                senderUsername = sender,
                senderAvatar = "img_avatar_me",
                message = "mentioned you in a story: \"Check out @alex_keios latest build!\"",
                targetPreviewRes = "img_workspace",
                timestamp = System.currentTimeMillis(),
                isRead = false
            )
            "SECURITY_ALERT" -> NotificationItem(
                type = "SECURITY_ALERT",
                senderUsername = "Keios Security",
                senderAvatar = "ic_app_icon",
                message = "Security check passed: 2FA hardware token verified successfully.",
                timestamp = System.currentTimeMillis(),
                isRead = false
            )
            else -> NotificationItem(
                type = "REEL_POST",
                senderUsername = sender,
                senderAvatar = "img_avatar_me",
                message = "posted a new reel: 'Inside Keios Tokyo Office'.",
                targetPreviewRes = "img_reel_conference",
                timestamp = System.currentTimeMillis(),
                isRead = false
            )
        }

        val id = notificationDao.insertNotification(notif)
        val saved = notif.copy(id = id)
        _realtimeNotificationEvent.emit(saved)
        return saved
    }

    // Profile & Security Actions
    suspend fun updateProfile(profile: UserProfile) {
        userProfileDao.updateProfile(profile)
    }

    suspend fun toggleTwoFactor(enabled: Boolean) {
        userProfileDao.setTwoFactorEnabled(enabled)
        val notif = NotificationItem(
            type = "SECURITY_ALERT",
            senderUsername = "Keios Security",
            senderAvatar = "ic_app_icon",
            message = if (enabled) "Two-Factor Authentication (2FA) has been enabled." else "Two-Factor Authentication (2FA) was disabled.",
            timestamp = System.currentTimeMillis(),
            isRead = false
        )
        notificationDao.insertNotification(notif)
        _realtimeNotificationEvent.emit(notif)
    }

    suspend fun togglePrivateAccount(isPrivate: Boolean) {
        userProfileDao.setPrivateAccount(isPrivate)
    }

    suspend fun toggleBiometricLock(enabled: Boolean) {
        userProfileDao.setBiometricLockEnabled(enabled)
    }

    suspend fun togglePushNotifications(enabled: Boolean) {
        userProfileDao.setNotificationPushEnabled(enabled)
    }
}
