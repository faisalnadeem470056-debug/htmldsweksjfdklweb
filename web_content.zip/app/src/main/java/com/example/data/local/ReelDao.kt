package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.Reel
import kotlinx.coroutines.flow.Flow

@Dao
interface ReelDao {
    @Query("SELECT * FROM reels ORDER BY timestamp DESC")
    fun getAllReels(): Flow<List<Reel>>

    @Query("SELECT * FROM reels WHERE isSaved = 1 ORDER BY timestamp DESC")
    fun getSavedReels(): Flow<List<Reel>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertReel(reel: Reel): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(reels: List<Reel>)

    @Update
    suspend fun updateReel(reel: Reel)

    @Query("UPDATE reels SET isLiked = :isLiked, likesCount = likesCount + :delta WHERE id = :id")
    suspend fun toggleLike(id: Long, isLiked: Boolean, delta: Int)

    @Query("UPDATE reels SET isSaved = :isSaved WHERE id = :id")
    suspend fun toggleSave(id: Long, isSaved: Boolean)

    @Query("UPDATE reels SET isFollowing = :isFollowing WHERE username = :username")
    suspend fun updateFollowStatus(username: String, isFollowing: Boolean)

    @Query("UPDATE reels SET commentsCount = commentsCount + 1 WHERE id = :id")
    suspend fun incrementCommentsCount(id: Long)

    @Query("SELECT COUNT(*) FROM reels")
    suspend fun getCount(): Int
}
