package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "user_profile")
data class UserProfile(
    @PrimaryKey
    val id: Int = 1,
    val fullName: String = "Alex Chen",
    val username: String = "alex_keios",
    val bio: String = "Staff Android & Systems Architect @ Keios Software 🚀\nBuilding realtime engines & high-throughput mobile tools.\nTokyo 🇯🇵 • San Francisco 🇺🇸",
    val department: String = "Keios Engineering Labs",
    val website: String = "https://keios.software",
    val avatarRes: String = "img_avatar_me",
    val isVerified: Boolean = true,
    val postsCount: Int = 12,
    val followersCount: Int = 3840,
    val followingCount: Int = 295,
    val isPrivateAccount: Boolean = false,
    val isTwoFactorEnabled: Boolean = true,
    val twoFactorMethod: String = "Keios Authenticator App (TOTP)",
    val backupCodesLeft: Int = 8,
    val isBiometricLockEnabled: Boolean = true,
    val notificationPushEnabled: Boolean = true,
    val realTimeFeedSync: Boolean = true,
    val lastPasswordChange: String = "12 days ago",
    val currentSessionDevice: String = "Pixel 8 Pro • Keios Secure Enclave",
    val currentSessionIp: String = "133.242.18.42 (Tokyo, JP)"
)

data class ActiveSession(
    val id: String,
    val deviceName: String,
    val clientType: String,
    val location: String,
    val lastActive: String,
    val isCurrent: Boolean = false
)

data class SecurityAuditEntry(
    val id: String,
    val title: String,
    val description: String,
    val timestamp: String,
    val severity: String // "INFO", "SUCCESS", "WARN"
)
