package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "notifications")
data class NotificationItem(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val type: String, // "LIKE", "COMMENT", "FOLLOW", "MENTION", "REEL_POST", "SECURITY_ALERT"
    val senderUsername: String,
    val senderAvatar: String,
    val message: String,
    val targetPreviewRes: String? = null,
    val timestamp: Long = System.currentTimeMillis(),
    val isRead: Boolean = false,
    val isFollowingBack: Boolean = false,
    val actionUrl: String? = null
)
