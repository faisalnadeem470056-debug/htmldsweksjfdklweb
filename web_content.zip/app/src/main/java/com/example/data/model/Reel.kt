package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "reels")
data class Reel(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val username: String,
    val userAvatarRes: String,
    val isVerified: Boolean = false,
    val caption: String,
    val audioTitle: String,
    val audioArtist: String,
    val previewImageRes: String? = null,
    val videoType: String = "TECH_DEMO", // "TECH_DEMO", "OFFICE_VLOG", "AI_INFERENCE", "DESIGN_SYSTEM", "USER_UPLOAD"
    val primaryColorHex: Long = 0xFF1E0A3C,
    val secondaryColorHex: Long = 0xFF003859,
    val likesCount: Int = 0,
    val isLiked: Boolean = false,
    val commentsCount: Int = 0,
    val sharesCount: Int = 0,
    val timestamp: Long = System.currentTimeMillis(),
    val isSaved: Boolean = false,
    val isFollowing: Boolean = false
)

data class ReelComment(
    val id: Long = 0,
    val reelId: Long,
    val username: String,
    val userAvatarRes: String,
    val text: String,
    val timestamp: Long = System.currentTimeMillis(),
    val likesCount: Int = 0
)
