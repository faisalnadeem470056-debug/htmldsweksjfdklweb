package com.example.data.model

import androidx.compose.ui.graphics.ColorMatrix

enum class FilterType(val displayName: String, val description: String) {
    NORMAL("Normal", "Original untouched photo"),
    CLARENDON("Clarendon", "High contrast with cool shadow tint"),
    JUNO("Juno", "Vibrant colors with rich warm highlights"),
    LUDWIG("Ludwig", "Minimalist warm glow with balanced shadows"),
    VALENCIA("Valencia", "Warm vintage wash with pastel softness"),
    LARK("Lark", "Brightened exposure with vivid cool tones"),
    SLUMBER("Slumber", "Dreamy retro matte finish with subdued saturation"),
    MOON("Moon", "Classic high-contrast black and white"),
    SEPIA("Sepia Glow", "Nostalgic golden monochrome warmth"),
    KEIOS_CYBER("Keios Tech", "Futuristic high-tech cyan & magenta duotone");

    fun getColorMatrix(
        brightness: Float = 0f, // -100 to 100
        contrast: Float = 1f,   // 0.5 to 2.0
        saturation: Float = 1f, // 0.0 to 2.0
        warmth: Float = 0f      // -50 to 50
    ): ColorMatrix {
        val baseMatrix = when (this) {
            NORMAL -> ColorMatrix()

            CLARENDON -> ColorMatrix(
                floatArrayOf(
                    1.15f, 0f, 0f, 0f, 10f,
                    0f, 1.10f, 0f, 0f, 5f,
                    0f, 0f, 1.30f, 0f, 25f,
                    0f, 0f, 0f, 1f, 0f
                )
            )

            JUNO -> ColorMatrix(
                floatArrayOf(
                    1.25f, 0.05f, 0f, 0f, 15f,
                    0f, 1.20f, 0f, 0f, 10f,
                    0f, 0f, 0.90f, 0f, -10f,
                    0f, 0f, 0f, 1f, 0f
                )
            )

            LUDWIG -> ColorMatrix(
                floatArrayOf(
                    1.05f, 0.05f, 0f, 0f, 12f,
                    0f, 1.05f, 0.05f, 0f, 8f,
                    0f, 0f, 0.95f, 0f, -5f,
                    0f, 0f, 0f, 1f, 0f
                )
            )

            VALENCIA -> ColorMatrix(
                floatArrayOf(
                    1.10f, 0.08f, 0f, 0f, 20f,
                    0f, 1.05f, 0.05f, 0f, 12f,
                    0f, 0f, 0.85f, 0f, -15f,
                    0f, 0f, 0f, 1f, 0f
                )
            )

            LARK -> ColorMatrix(
                floatArrayOf(
                    1.10f, 0f, 0f, 0f, 15f,
                    0f, 1.15f, 0f, 0f, 18f,
                    0f, 0f, 1.25f, 0f, 30f,
                    0f, 0f, 0f, 1f, 0f
                )
            )

            SLUMBER -> ColorMatrix(
                floatArrayOf(
                    0.95f, 0.05f, 0.05f, 0f, 18f,
                    0.05f, 0.90f, 0.05f, 0f, 12f,
                    0.05f, 0.05f, 0.85f, 0f, 8f,
                    0f, 0f, 0f, 1f, 0f
                )
            )

            MOON -> ColorMatrix(
                floatArrayOf(
                    0.299f * 1.3f, 0.587f * 1.3f, 0.114f * 1.3f, 0f, -10f,
                    0.299f * 1.3f, 0.587f * 1.3f, 0.114f * 1.3f, 0f, -10f,
                    0.299f * 1.3f, 0.587f * 1.3f, 0.114f * 1.3f, 0f, -10f,
                    0f, 0f, 0f, 1f, 0f
                )
            )

            SEPIA -> ColorMatrix(
                floatArrayOf(
                    0.393f, 0.769f, 0.189f, 0f, 15f,
                    0.349f, 0.686f, 0.168f, 0f, 5f,
                    0.272f, 0.534f, 0.131f, 0f, -20f,
                    0f, 0f, 0f, 1f, 0f
                )
            )

            KEIOS_CYBER -> ColorMatrix(
                floatArrayOf(
                    0.5f, 0.2f, 0.8f, 0f, 10f,
                    0.1f, 0.9f, 0.7f, 0f, 20f,
                    0.2f, 0.4f, 1.4f, 0f, 35f,
                    0f, 0f, 0f, 1f, 0f
                )
            )
        }

        // Apply custom adjustments if modified
        if (saturation != 1f || contrast != 1f || brightness != 0f || warmth != 0f) {
            val satMatrix = ColorMatrix().apply { setToSaturation(saturation) }
            val adjMatrix = ColorMatrix(
                floatArrayOf(
                    contrast, 0f, 0f, 0f, brightness + (warmth * 0.5f),
                    0f, contrast, 0f, 0f, brightness,
                    0f, 0f, contrast, 0f, brightness - (warmth * 0.5f),
                    0f, 0f, 0f, 1f, 0f
                )
            )
            val combined = ColorMatrix()
            // base * sat * adj
            combined.timesAssign(baseMatrix)
            combined.timesAssign(satMatrix)
            combined.timesAssign(adjMatrix)
            return combined
        }

        return baseMatrix
    }
}
