package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.UserProfile
import kotlinx.coroutines.flow.Flow

@Dao
interface UserProfileDao {
    @Query("SELECT * FROM user_profile WHERE id = 1 LIMIT 1")
    fun getUserProfile(): Flow<UserProfile?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdate(profile: UserProfile)

    @Update
    suspend fun updateProfile(profile: UserProfile)

    @Query("UPDATE user_profile SET isTwoFactorEnabled = :enabled WHERE id = 1")
    suspend fun setTwoFactorEnabled(enabled: Boolean)

    @Query("UPDATE user_profile SET isPrivateAccount = :isPrivate WHERE id = 1")
    suspend fun setPrivateAccount(isPrivate: Boolean)

    @Query("UPDATE user_profile SET isBiometricLockEnabled = :enabled WHERE id = 1")
    suspend fun setBiometricLockEnabled(enabled: Boolean)

    @Query("UPDATE user_profile SET notificationPushEnabled = :enabled WHERE id = 1")
    suspend fun setNotificationPushEnabled(enabled: Boolean)

    @Query("UPDATE user_profile SET postsCount = postsCount + 1 WHERE id = 1")
    suspend fun incrementPostsCount()
}
