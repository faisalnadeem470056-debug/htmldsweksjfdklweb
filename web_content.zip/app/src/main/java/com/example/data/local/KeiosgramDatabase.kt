package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.data.model.NotificationItem
import com.example.data.model.Post
import com.example.data.model.Reel
import com.example.data.model.UserProfile

@Database(
    entities = [
        Post::class,
        Reel::class,
        NotificationItem::class,
        UserProfile::class
    ],
    version = 1,
    exportSchema = false
)
abstract class KeiosgramDatabase : RoomDatabase() {
    abstract fun postDao(): PostDao
    abstract fun reelDao(): ReelDao
    abstract fun notificationDao(): NotificationDao
    abstract fun userProfileDao(): UserProfileDao

    companion object {
        @Volatile
        private var INSTANCE: KeiosgramDatabase? = null

        fun getDatabase(context: Context): KeiosgramDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    KeiosgramDatabase::class.java,
                    "keiosgram_database"
                )
                    .fallbackToDestructiveMigration()
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
