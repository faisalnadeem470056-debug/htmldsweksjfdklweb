package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.data.model.UserProfile
import com.example.ui.components.InstagramBottomNav
import com.example.ui.components.NotificationBanner
import com.example.ui.screens.editor.PhotoEditorScreen
import com.example.ui.screens.feed.FeedScreen
import com.example.ui.screens.notifications.NotificationsScreen
import com.example.ui.screens.profile.ProfileScreen
import com.example.ui.screens.reels.ReelsScreen
import com.example.ui.theme.DarkBg
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.viewmodel.AppNavigationTab
import com.example.ui.viewmodel.KeiosgramViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme(darkTheme = true) {
                KeiosgramApp()
            }
        }
    }
}

@Composable
fun KeiosgramApp(
    viewModel: KeiosgramViewModel = viewModel()
) {
    val currentTab by viewModel.currentTab.collectAsState()
    val posts by viewModel.posts.collectAsState()
    val reels by viewModel.reels.collectAsState()
    val notifications by viewModel.notifications.collectAsState()
    val unreadCount by viewModel.unreadCount.collectAsState()
    val userProfile by viewModel.userProfile.collectAsState()
    val activeBanner by viewModel.activeNotificationBanner.collectAsState()

    val profileNonNull = userProfile ?: UserProfile()
    val snackbarHostState = remember { SnackbarHostState() }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(DarkBg)
            .testTag("app_root_container")
    ) {
        Scaffold(
            modifier = Modifier.fillMaxSize(),
            containerColor = DarkBg,
            snackbarHost = { SnackbarHost(snackbarHostState) },
            bottomBar = {
                // Show bottom nav on main views
                InstagramBottomNav(
                    selectedTab = currentTab,
                    unreadCount = unreadCount,
                    onTabSelected = { tab ->
                        viewModel.selectTab(tab)
                    }
                )
            }
        ) { innerPadding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(bottom = innerPadding.calculateBottomPadding())
            ) {
                AnimatedContent(
                    targetState = currentTab,
                    transitionSpec = { fadeIn() togetherWith fadeOut() },
                    label = "tab_transition"
                ) { targetTab ->
                    when (targetTab) {
                        AppNavigationTab.FEED -> {
                            FeedScreen(
                                viewModel = viewModel,
                                posts = posts,
                                unreadCount = unreadCount
                            )
                        }
                        AppNavigationTab.REELS -> {
                            ReelsScreen(
                                viewModel = viewModel,
                                reels = reels
                            )
                        }
                        AppNavigationTab.CREATE -> {
                            PhotoEditorScreen(
                                viewModel = viewModel
                            )
                        }
                        AppNavigationTab.NOTIFICATIONS -> {
                            NotificationsScreen(
                                viewModel = viewModel,
                                notifications = notifications
                            )
                        }
                        AppNavigationTab.PROFILE -> {
                            ProfileScreen(
                                viewModel = viewModel,
                                profile = profileNonNull,
                                posts = posts,
                                reels = reels
                            )
                        }
                    }
                }
            }
        }

        // Real-Time Notification Floating Slide-in Banner at Top
        NotificationBanner(
            notification = activeBanner,
            onDismiss = { viewModel.dismissNotificationBanner() },
            onClick = {
                viewModel.dismissNotificationBanner()
                viewModel.selectTab(AppNavigationTab.NOTIFICATIONS)
            }
        )
    }
}
