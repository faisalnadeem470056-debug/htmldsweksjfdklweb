package fr.belote.app;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.view.View;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.TextView;
import android.widget.ImageView;
import android.os.Handler;

public class MainActivity extends Activity {
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.rgb(7,61,41));
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.rgb(7,61,41));
        TextView splash = new TextView(this);
        splash.setText("🃏\nBelote"); splash.setTextSize(32); splash.setTextColor(Color.WHITE); splash.setGravity(17);
        root.addView(splash, new FrameLayout.LayoutParams(-1,-1)); setContentView(root);
        new Handler().postDelayed(() -> {
            WebView web = new WebView(this); web.setBackgroundColor(Color.rgb(11,93,59));
            WebSettings s=web.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setAllowFileAccess(true); s.setBuiltInZoomControls(false);
            web.setWebViewClient(new WebViewClient()); web.loadUrl("file:///android_asset/index.html"); setContentView(web);
        }, 650);
    }
}
