const fileInput = document.getElementById("fileInput");
const fileInfo = document.getElementById("fileInfo");
const statusBox = document.getElementById("status");
const checkBtn = document.getElementById("checkBtn");
const buildBtn = document.getElementById("buildBtn");

let selectedFile = null;

fileInput.addEventListener("change", () => {
  selectedFile = fileInput.files[0] || null;

  if (!selectedFile) {
    fileInfo.textContent = "Nenhum arquivo selecionado.";
    return;
  }

  const size = (selectedFile.size / 1024 / 1024).toFixed(2);
  fileInfo.textContent = `Arquivo: ${selectedFile.name}\nTamanho: ${size} MB`;
  statusBox.textContent = "Projeto selecionado. Faça a verificação.";
});

checkBtn.addEventListener("click", () => {
  if (!selectedFile) {
    statusBox.textContent = "⚠️ Selecione um ZIP ou HTML primeiro.";
    return;
  }

  const name = selectedFile.name.toLowerCase();

  if (!name.endsWith(".zip") && !name.endsWith(".html") && !name.endsWith(".htm")) {
    statusBox.textContent = "❌ Formato não suportado.";
    return;
  }

  const packageName = document.getElementById("packageName").value.trim();

  if (!/^[a-z][a-z0-9_]*(\.[a-z][a-z0-9_]*)+$/.test(packageName)) {
    statusBox.textContent =
      "❌ Nome do pacote inválido.\nExemplo: com.exemplo.meuapp";
    return;
  }

  statusBox.textContent =
    "✅ Verificação básica concluída.\n\n" +
    "Arquivo: OK\n" +
    "Nome do pacote: OK\n" +
    "Pronto para a etapa de compilação.";
});

buildBtn.addEventListener("click", () => {
  if (!selectedFile) {
    statusBox.textContent = "⚠️ Selecione um projeto primeiro.";
    return;
  }

  statusBox.textContent =
    "📦 Projeto preparado.\n\n" +
    "Nesta versão, a interface e a estrutura Android já estão prontas. " +
    "A compilação do APK será feita pelo ambiente Android que abrir este projeto.";
});
