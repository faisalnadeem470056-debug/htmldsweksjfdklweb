// ===============================
// FIREBASE CONFIG
// ===============================
const firebaseConfig = {
  apiKey: "AIzaSyDw8zXmNrRRjL_ZsrgtE-Y92zE1SBx5AQo",
  authDomain: "koryob-15d9b.firebaseapp.com",
  projectId: "koryob-15d9b",
  storageBucket: "koryob-15d9b.firebasestorage.app",
  messagingSenderId: "856595750579",
  appId: "1:856595750579:web:e0c4379e5f8471fb8c9ac6",
  measurementId: "G-X33F8STYDC"
};

const firebaseScripts = [
  "https://www.gstatic.com/firebasejs/12.1.0/firebase-app-compat.js",
  "https://www.gstatic.com/firebasejs/12.1.0/firebase-auth-compat.js",
  "https://www.gstatic.com/firebasejs/12.1.0/firebase-firestore-compat.js"
];

let firebaseLoaded = 0;
firebaseScripts.forEach(src => {
  const script = document.createElement("script");
  script.src = src;
  script.onload = () => {
    firebaseLoaded++;
    if (firebaseLoaded === firebaseScripts.length) startFirebase();
  };
  script.onerror = () => console.error("Firebase loading error:", src);
  document.head.appendChild(script);
});

let auth = null, db = null, currentUser = null, currentProfile = null;
let allJobs = [], currentCategory = "all", currentChatUid = null, selectedJobImage = "";

function startFirebase() {
  try {
    if (!firebase.apps.length) firebase.initializeApp(firebaseConfig);
    auth = firebase.auth();
    db = firebase.firestore();

    auth.onAuthStateChanged(async user => {
      currentUser = user;
      if (user) {
        try {
          await loadProfile();
          document.getElementById("auth").classList.add("hidden");
          document.getElementById("main").classList.remove("hidden");
          await loadJobs();
          updateInterface();
        } catch (error) {
          console.error("User loading error:", error);
        }
      } else {
        currentProfile = null;
        document.getElementById("main").classList.add("hidden");
        document.getElementById("auth").classList.remove("hidden");
      }
    });
  } catch (error) {
    console.error("Firebase error:", error);
    const message = document.getElementById("authMessage");
    if (message) message.textContent = "❌ Firebase пайваст нашуд.";
  }
}

setTimeout(() => {
  const splash = document.getElementById("splash");
  if (splash) {
    splash.style.opacity = "0";
    splash.style.transition = "opacity 180ms ease";
    setTimeout(() => splash.style.display = "none", 180);
  }
}, 650);

function togglePassword(inputId, button) {
  const input = document.getElementById(inputId);
  if (!input) return;
  input.type = input.type === "password" ? "text" : "password";
  button.textContent = input.type === "password" ? "👁️" : "🙈";
}
window.togglePassword = togglePassword;

function showLogin() {
  document.getElementById("loginForm").classList.remove("hidden");
  document.getElementById("registerForm").classList.add("hidden");
  document.getElementById("loginTab").classList.add("active");
  document.getElementById("registerTab").classList.remove("active");
  document.getElementById("authMessage").textContent = "";
}
window.showLogin = showLogin;

function showRegister() {
  document.getElementById("registerForm").classList.remove("hidden");
  document.getElementById("loginForm").classList.add("hidden");
  document.getElementById("registerTab").classList.add("active");
  document.getElementById("loginTab").classList.remove("active");
}
window.showRegister = showRegister;

function makeEmail(username) {
  return username.trim().toLowerCase() + "@koryob.app";
}
function validUsername(username) {
  return /^[a-zA-Z0-9][a-zA-Z0-9._-]{2,29}$/.test(username);
}

async function registerUser() {
  if (!auth || !db) {
    document.getElementById("authMessage").textContent = "⏳ Firebase ҳоло омода нест.";
    return;
  }
  const name = document.getElementById("regName").value.trim();
  const city = document.getElementById("regCity").value.trim();
  const role = document.getElementById("regRole").value;
  const username = document.getElementById("authUsername").value.trim().toLowerCase();
  const password = document.getElementById("authPassword").value;
  const message = document.getElementById("authMessage");

  if (!name || !city || !username || !password) return message.textContent = "⚠️ Ҳама майдонҳоро пур кунед.";
  if (!validUsername(username)) return message.textContent = "⚠️ Username бояд аз 3 то 30 аломат бошад.";
  if (password.length < 6) return message.textContent = "⚠️ Парол бояд камаш 6 аломат дошта бошад.";

  try {
    message.textContent = "⏳ Аккаунт сохта шуда истодааст...";
    const email = makeEmail(username);
    const result = await auth.createUserWithEmailAndPassword(email, password);
    const uid = result.user.uid;

    await db.collection("users").doc(uid).set({
      uid, name, username, city, role, about: "", photo: "",
      createdAt: firebase.firestore.FieldValue.serverTimestamp()
    });

    saveLocalAccount({uid, username, name, email});
    currentProfile = {uid, name, username, city, role, about: "", photo: ""};

    ["regName","regCity","authUsername","authPassword"].forEach(id => document.getElementById(id).value = "");
    message.textContent = "✅ Аккаунт сохта шуд!";
    document.getElementById("auth").classList.add("hidden");
    document.getElementById("main").classList.remove("hidden");
    updateInterface();
    await loadJobs();
  } catch (error) {
    console.error(error);
    message.textContent = firebaseError(error);
  }
}
window.registerUser = registerUser;

async function loginUser() {
  if (!auth) {
    document.getElementById("authMessage").textContent = "⏳ Firebase ҳоло омода нест.";
    return;
  }
  const username = document.getElementById("loginUsername").value.trim().toLowerCase();
  const password = document.getElementById("loginPassword").value;
  const message = document.getElementById("authMessage");
  if (!username || !password) return message.textContent = "⚠️ Username ва паролро ворид кунед.";

  try {
    message.textContent = "⏳ Даромада истодааст...";
    const email = makeEmail(username);
    const result = await auth.signInWithEmailAndPassword(email, password);
    saveLocalAccount({uid: result.user.uid, username, name: username, email});
  } catch (error) {
    console.error(error);
    message.textContent = firebaseError(error);
  }
}
window.loginUser = loginUser;

function firebaseError(error) {
  switch (error.code) {
    case "auth/email-already-in-use": return "❌ Ин Username аллакай истифода шудааст.";
    case "auth/invalid-credential": return "❌ Username ё парол нодуруст аст.";
    case "auth/wrong-password": return "❌ Парол нодуруст аст.";
    case "auth/user-not-found": return "❌ Чунин аккаунт ёфт нашуд.";
    case "auth/weak-password": return "❌ Парол хеле осон аст.";
    case "auth/operation-not-allowed": return "❌ Email/Password дар Firebase фаъол нест.";
    case "auth/network-request-failed": return "❌ Интернетро санҷед.";
    case "auth/too-many-requests": return "❌ Кӯшишҳо хеле зиёд шуданд. Каме интизор шавед.";
    default: return "❌ Хато: " + (error.message || error.code);
  }
}

async function loadProfile() {
  if (!currentUser || !db) return;
  const doc = await db.collection("users").doc(currentUser.uid).get();
  if (doc.exists) {
    currentProfile = doc.data();
    fillProfile();
  } else {
    currentProfile = {
      uid: currentUser.uid,
      name: "",
      username: currentUser.email ? currentUser.email.split("@")[0] : "",
      city: "", role: "jobseeker", about: "", photo: ""
    };
  }
}

function fillProfile() {
  if (!currentProfile) return;
  document.getElementById("profileName").value = currentProfile.name || "";
  document.getElementById("profileUsername").value = currentProfile.username || "";
  document.getElementById("profileCity").value = currentProfile.city || "";
  document.getElementById("profileRole").value = currentProfile.role || "jobseeker";
  document.getElementById("profileAbout").value = currentProfile.about || "";
  if (currentProfile.photo) document.getElementById("profilePhoto").src = currentProfile.photo;
}

async function saveProfile() {
  if (!currentUser || !db) return;
  const data = {
    name: document.getElementById("profileName").value.trim(),
    city: document.getElementById("profileCity").value.trim(),
    role: document.getElementById("profileRole").value,
    about: document.getElementById("profileAbout").value.trim()
  };
  try {
    await db.collection("users").doc(currentUser.uid).update(data);
    currentProfile = {...currentProfile, ...data};
    updateInterface();
    alert("✅ Профил сабт шуд.");
  } catch (error) {
    console.error(error);
    alert("❌ " + error.message);
  }
}
window.saveProfile = saveProfile;

function previewProfileImage(event) {
  const file = event.target.files[0];
  if (!file) return;
  if (file.size > 700000) return alert("⚠️ Сурат бояд аз 700KB хурдтар бошад.");
  const reader = new FileReader();
  reader.onload = async function() {
    const image = reader.result;
    document.getElementById("profilePhoto").src = image;
    try {
      await db.collection("users").doc(currentUser.uid).update({photo:image});
      currentProfile.photo = image;
    } catch (error) { console.error(error); }
  };
  reader.readAsDataURL(file);
}
window.previewProfileImage = previewProfileImage;

function previewJobImage(event) {
  const file = event.target.files[0];
  if (!file) return;
  if (file.size > 700000) return alert("⚠️ Сурат бояд аз 700KB хурдтар бошад.");
  const reader = new FileReader();
  reader.onload = function() {
    selectedJobImage = reader.result;
    const preview = document.getElementById("jobImagePreview");
    preview.src = selectedJobImage;
    preview.classList.remove("hidden");
  };
  reader.readAsDataURL(file);
}
window.previewJobImage = previewJobImage;

async function createJob() {
  if (!currentUser || !currentProfile) return;
  if (currentProfile.role !== "employer") return alert("⚠️ Барои нашри эълон бояд Корфармо бошед.");

  const title = document.getElementById("jobTitle").value.trim();
  const company = document.getElementById("jobCompany").value.trim();
  const city = document.getElementById("jobCity").value.trim();
  const salary = document.getElementById("jobSalary").value.trim();
  const category = document.getElementById("jobCategory").value;
  const description = document.getElementById("jobDescription").value.trim();
  const message = document.getElementById("jobMessage");

  if (!title || !city || !description) return message.textContent = "⚠️ Номи кор, шаҳр ва тавсифро пур кунед.";

  try {
    message.textContent = "⏳ Эълон сохта шуда истодааст...";
    await db.collection("jobs").add({
      title, company, city, salary, category, description,
      image: selectedJobImage || "",
      employerUid: currentUser.uid,
      employerName: currentProfile.name || currentProfile.username,
      employerUsername: currentProfile.username || "",
      createdAt: firebase.firestore.FieldValue.serverTimestamp()
    });

    message.textContent = "✅ Эълон нашр шуд!";
    ["jobTitle","jobCompany","jobCity","jobSalary","jobDescription"].forEach(id => document.getElementById(id).value = "");
    selectedJobImage = "";
    document.getElementById("jobImagePreview").classList.add("hidden");
    await loadJobs();
  } catch (error) {
    console.error(error);
    message.textContent = "❌ " + error.message;
  }
}
window.createJob = createJob;

async function loadJobs() {
  if (!db) return;
  try {
    const snapshot = await db.collection("jobs").orderBy("createdAt","desc").get();
    allJobs = [];
    snapshot.forEach(doc => allJobs.push({id:doc.id,...doc.data()}));
    renderJobs(allJobs);
    renderSavedJobs();
  } catch (error) { console.error("Jobs loading error:", error); }
}

function renderJobs(jobs) {
  const box = document.getElementById("jobsList");
  if (!box) return;
  if (!jobs.length) return box.innerHTML = "<p>Ҳоло эълони кор нест.</p>";

  box.innerHTML = jobs.map(job => {
    const image = job.image ? `<img src="${job.image}">` : "";
    return `<div class="job-card">${image}
      <h3>${escapeHTML(job.title || "Кор")}</h3>
      <p>🏢 ${escapeHTML(job.company || "Корфармо")}</p>
      <p>📍 ${escapeHTML(job.city || "")}</p>
      <p>💰 ${escapeHTML(job.salary || "Музокира мешавад")}</p>
      <div class="job-meta"><span>${escapeHTML(job.category || "Дигар")}</span></div>
      <div class="card-buttons">
        <button class="view-btn" onclick="openJob('${job.id}')">Дидан</button>
        <button class="save-btn" onclick="saveJob('${job.id}')">❤️</button>
      </div>
    </div>`;
  }).join("");
}

function filterJobs() {
  const input = document.getElementById("searchInput");
  const query = input ? input.value.toLowerCase().trim() : "";
  let result = allJobs.filter(job => {
    const text = `${job.title || ""} ${job.company || ""} ${job.city || ""} ${job.category || ""}`.toLowerCase();
    return text.includes(query);
  });
  if (currentCategory !== "all") result = result.filter(job => job.category === currentCategory);
  renderJobs(result);
}
window.filterJobs = filterJobs;

function filterCategory(category) { currentCategory = category; filterJobs(); }
window.filterCategory = filterCategory;

function openJob(id) {
  const job = allJobs.find(x => x.id === id);
  if (!job) return;
  document.getElementById("jobDetails").innerHTML = `
    ${job.image ? `<img class="image-preview" src="${job.image}">` : ""}
    <h2>${escapeHTML(job.title || "")}</h2>
    <p>🏢 ${escapeHTML(job.company || "Корфармо")}</p>
    <p>📍 ${escapeHTML(job.city || "")}</p>
    <p>💰 ${escapeHTML(job.salary || "Музокира мешавад")}</p>
    <p>📌 ${escapeHTML(job.category || "Дигар")}</p>
    <hr><p>${escapeHTML(job.description || "")}</p>
    ${job.employerUid && job.employerUid !== currentUser?.uid ? `<button class="primary-btn" onclick="openChat('${job.employerUid}')">💬 Навиштан ба корфармо</button>` : ""}
  `;
  document.getElementById("jobModal").classList.remove("hidden");
}
window.openJob = openJob;

function closeJobModal() { document.getElementById("jobModal").classList.add("hidden"); }
window.closeJobModal = closeJobModal;

function getSavedJobs() {
  if (!currentUser) return [];
  return JSON.parse(localStorage.getItem("koryob_saved_" + currentUser.uid) || "[]");
}
function saveJob(id) {
  if (!currentUser) return;
  let saved = getSavedJobs();
  saved = saved.includes(id) ? saved.filter(x => x !== id) : [...saved,id];
  localStorage.setItem("koryob_saved_" + currentUser.uid, JSON.stringify(saved));
  renderSavedJobs();
}
window.saveJob = saveJob;

function renderSavedJobs() {
  const box = document.getElementById("savedJobs");
  if (!box) return;
  const ids = getSavedJobs();
  const jobs = allJobs.filter(job => ids.includes(job.id));
  if (!jobs.length) return box.innerHTML = "<p>❤️ Ҳоло ягон кор захира нашудааст.</p>";
  box.innerHTML = jobs.map(job => `<div class="job-card">
    <h3>${escapeHTML(job.title || "")}</h3>
    <p>🏢 ${escapeHTML(job.company || "")}</p>
    <p>📍 ${escapeHTML(job.city || "")}</p>
    <button class="view-btn" onclick="openJob('${job.id}')">Дидан</button>
  </div>`).join("");
}

function chatId(uid1, uid2) { return [uid1,uid2].sort().join("_"); }

async function openChat(uid) {
  if (!currentUser) return;
  if (uid === currentUser.uid) return alert("Ин профили худи шумост.");
  currentChatUid = uid;
  let title = "Корбар";
  try {
    const doc = await db.collection("users").doc(uid).get();
    if (doc.exists) {
      const data = doc.data();
      title = data.name || data.username || "Корбар";
    }
  } catch (error) { console.error(error); }
  document.getElementById("chatTitle").textContent = "💬 " + title;
  document.getElementById("chatModal").classList.remove("hidden");
  await ensureChatDocument();
  await loadMessages();
}
window.openChat = openChat;

async function ensureChatDocument() {
  if (!currentUser || !currentChatUid) return;
  const id = chatId(currentUser.uid,currentChatUid);
  const ref = db.collection("chats").doc(id);
  const doc = await ref.get();
  if (!doc.exists) await ref.set({
    members:[currentUser.uid,currentChatUid],
    createdAt:firebase.firestore.FieldValue.serverTimestamp(),
    lastMessage:"",
    lastMessageAt:firebase.firestore.FieldValue.serverTimestamp()
  });
}

async function loadMessages() {
  if (!currentUser || !currentChatUid) return;
  const box = document.getElementById("messages");
  if (!box) return;
  const id = chatId(currentUser.uid,currentChatUid);
  try {
    const snapshot = await db.collection("chats").doc(id).collection("messages").orderBy("createdAt","asc").get();
    box.innerHTML = "";
    snapshot.forEach(doc => {
      const data = doc.data();
      const mine = data.senderUid === currentUser.uid;
      const div = document.createElement("div");
      div.className = "message" + (mine ? " mine" : "");
      div.innerHTML = escapeHTML(data.text || "") + (mine ? " ✓✓" : "");
      box.appendChild(div);
    });
    box.scrollTop = box.scrollHeight;
  } catch (error) {
    console.error("Messages error:",error);
    box.innerHTML = "<p>💬 Ҳоло паёмҳо дастрас нестанд.</p>";
  }
}

async function sendMessage() {
  if (!currentUser || !currentChatUid) return;
  const input = document.getElementById("messageInput");
  if (!input) return;
  const text = input.value.trim();
  if (!text) return;
  try {
    await ensureChatDocument();
    const id = chatId(currentUser.uid,currentChatUid);
    await db.collection("chats").doc(id).collection("messages").add({
      text,senderUid:currentUser.uid,receiverUid:currentChatUid,
      createdAt:firebase.firestore.FieldValue.serverTimestamp()
    });
    await db.collection("chats").doc(id).update({
      lastMessage:text,
      lastMessageAt:firebase.firestore.FieldValue.serverTimestamp(),
      lastSenderUid:currentUser.uid
    });
    input.value = "";
    await loadMessages();
  } catch (error) {
    console.error(error);
    alert("❌ Паём фиристода нашуд: " + error.message);
  }
}
window.sendMessage = sendMessage;

function closeChat() {
  document.getElementById("chatModal").classList.add("hidden");
  currentChatUid = null;
}
window.closeChat = closeChat;

function getLocalAccounts() {
  try { return JSON.parse(localStorage.getItem("koryob_accounts") || "[]"); }
  catch { return []; }
}
function saveLocalAccount(account) {
  let accounts = getLocalAccounts().filter(a => a.uid !== account.uid);
  accounts.unshift(account);
  if (accounts.length > 5) accounts = accounts.slice(0,5);
  localStorage.setItem("koryob_accounts",JSON.stringify(accounts));
}
function openAccounts() {
  renderAccounts();
  document.getElementById("accountsModal").classList.remove("hidden");
}
window.openAccounts = openAccounts;
function closeAccounts() { document.getElementById("accountsModal").classList.add("hidden"); }
window.closeAccounts = closeAccounts;

function renderAccounts() {
  const box = document.getElementById("accountsList");
  if (!box) return;
  const accounts = getLocalAccounts();
  if (!accounts.length) return box.innerHTML = "<p>Ҳоло аккаунти дигар нест.</p>";
  box.innerHTML = accounts.map(account => `<div class="account-item">
    <div><strong>${escapeHTML(account.name || account.username)}</strong><br><small>@${escapeHTML(account.username)}</small></div>
    <button onclick="switchAccount('${escapeHTML(account.username)}')">Даромадан</button>
  </div>`).join("");
}
window.renderAccounts = renderAccounts;

async function switchAccount(username) {
  if (!auth) return;
  const password = prompt("Пароли @" + username + "-ро ворид кунед:");
  if (!password) return;
  try {
    await auth.signInWithEmailAndPassword(makeEmail(username),password);
    closeAccounts();
  } catch (error) { console.error(error); alert(firebaseError(error)); }
}
window.switchAccount = switchAccount;

async function addNewAccount() {
  const accounts = getLocalAccounts();
  if (accounts.length >= 5) return alert("⚠️ Шумо аллакай 5 аккаунт доред.");
  closeAccounts();
  try { if (auth.currentUser) await auth.signOut(); } catch (error) { console.error(error); }
  document.getElementById("main").classList.add("hidden");
  document.getElementById("auth").classList.remove("hidden");
  showRegister();
  ["regName","regCity","authUsername","authPassword"].forEach(id => document.getElementById(id).value = "");
  document.getElementById("authMessage").textContent = "➕ Аккаунти нави худро созед.";
}
window.addNewAccount = addNewAccount;

async function logoutUser() {
  if (!auth) return;
  try {
    await auth.signOut();
    document.getElementById("authMessage").textContent = "";
    showLogin();
  } catch (error) { console.error(error); alert("❌ Баромадан нашуд."); }
}
window.logoutUser = logoutUser;

function showPage(page) {
  document.querySelectorAll(".page").forEach(p => p.classList.add("hidden"));
  const target = document.getElementById(page);
  if (!target) return;
  target.classList.remove("hidden");
  if (page === "saved") renderSavedJobs();
  if (page === "chat") loadChatList();
}
window.showPage = showPage;

function updateInterface() {
  if (!currentProfile) return;
  const welcome = document.getElementById("welcomeText");
  if (welcome) welcome.textContent = "Салом, " + (currentProfile.name || currentProfile.username || "Корбар");
  const createNav = document.getElementById("createNav");
  if (!createNav) return;
  if (currentProfile.role === "employer") createNav.classList.remove("hidden");
  else createNav.classList.add("hidden");
}

async function loadChatList() {
  if (!currentUser || !db) return;
  const box = document.getElementById("chatList");
  if (!box) return;
  box.innerHTML = "<p>⏳ Чатҳо бор шуда истодаанд...</p>";
  try {
    const snapshot = await db.collection("chats").where("members","array-contains",currentUser.uid).get();
    if (snapshot.empty) return box.innerHTML = "<p>💬 Ҳоло чат надоред.</p>";
    box.innerHTML = "";
    snapshot.forEach(doc => {
      const data = doc.data();
      const other = (data.members || []).find(uid => uid !== currentUser.uid);
      if (!other) return;
      const div = document.createElement("div");
      div.className = "account-item";
      div.innerHTML = `<div><strong>👤 ${escapeHTML(other)}</strong></div><button>Кушодан</button>`;
      div.querySelector("button").onclick = () => openChat(other);
      box.appendChild(div);
    });
  } catch (error) {
    console.error(error);
    box.innerHTML = "<p>❌ Чатҳо ҳоло дастрас нестанд.</p>";
  }
}
window.loadChatList = loadChatList;

function escapeHTML(value) {
  return String(value || "").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/'/g,"&#039;");
}
window.escapeHTML = escapeHTML;
