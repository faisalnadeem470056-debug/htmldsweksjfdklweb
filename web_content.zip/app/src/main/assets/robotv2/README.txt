Forex Robot v2 — protótipo multiativos

Inclui:
- Scanner multiativos e múltiplos timeframes
- Gráfico de candles demonstrativo
- Sinais educativos com entrada/SL/TP/RR
- Seções ICT/SMC: PO3, Judas Swing, liquidez, BOS, CHoCH, FVG/IFVG, Order Blocks, suporte/resistência e sessões
- Gestão de risco básica

IMPORTANTE: esta versão ainda usa dados demonstrativos e NÃO está conectada ao MT5/RCG Markets. Não executa ordens reais nem ordens demo automaticamente.
