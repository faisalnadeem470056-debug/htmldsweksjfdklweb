# ECU MASTER GOLD: WebView JavaScript bridge methods are invoked by reflection.
-keepclassmembers class com.ecumaster.MainActivity$Bridge { *; }
