let xp=Number(localStorage.getItem("novaXP")||0), streak=Number(localStorage.getItem("novaStreak")||1);
const lessons={
 anglais:[["Hello","Bonjour"],["House","Maison"],["Friend","Ami"],["School","École"],["Book","Livre"]],
 espagnol:[["Hola","Bonjour"],["Casa","Maison"],["Amigo","Ami"],["Escuela","École"],["Libro","Livre"]],
 allemand:[["Hallo","Bonjour"],["Haus","Maison"],["Freund","Ami"],["Schule","École"],["Buch","Livre"]]
};
const school={
 maths:["Fractions","Une fraction représente une partie d’un tout. Exemple : 1/2 signifie une partie sur deux.","Quel est 1/2 + 1/2 ?","1"],
 français:["Grammaire","Un verbe indique généralement une action ou un état.","Dans « Les enfants jouent », quel est le verbe ?","jouent"],
 histoire:["Histoire","La Révolution française commence en 1789.","En quelle année commence-t-elle ?","1789"],
 géographie:["Géographie","Un continent est une vaste étendue de terres émergées.","Combien y a-t-il de continents ?","7"],
 sciences:["Sciences","L’eau peut être solide, liquide ou gazeuse.","Comment appelle-t-on l’eau à l’état solide ?","glace"]
};
function save(){localStorage.setItem("novaXP",xp);localStorage.setItem("novaStreak",streak)}
function update(){document.querySelectorAll("#xp,#xp2").forEach(e=>e.textContent=xp);document.getElementById("streak").textContent=streak;let level=Math.floor(xp/100)+1;document.getElementById("level").textContent=level;document.getElementById("progress").style.width=(xp%100)+"%";save()}
function addXP(n){xp+=n;update();alert("Bravo ! +"+n+" XP ⭐")}
function showPage(id){document.querySelectorAll(".page").forEach(p=>p.classList.remove("active"));document.getElementById(id).classList.add("active");window.scrollTo(0,0)}
function searchFromHome(){let q=document.getElementById("homeSearch").value.trim();if(q){document.getElementById("webQuery").value=q;showPage("search");webSearch()}}
function videoSearch(){let q=document.getElementById("videoQuery").value.trim();if(!q)return;let url="https://www.youtube.com/results?search_query="+encodeURIComponent(q);document.getElementById("videoResults").innerHTML='<a href="'+url+'" target="_blank">▶️ Voir les vidéos pour « '+escapeHTML(q)+' »<br><small>Ouvrir YouTube</small></a>'}
function webSearch(){let q=document.getElementById("webQuery").value.trim();if(!q)return;let url="https://www.google.com/search?q="+encodeURIComponent(q);document.getElementById("searchResults").innerHTML='<a href="'+url+'" target="_blank">🔎 Résultats pour « '+escapeHTML(q)+' »<br><small>Ouvrir la recherche Internet</small></a>'}
function setLanguage(lang){let arr=lessons[lang];let i=0;document.getElementById("languageBox").innerHTML='<h3>'+lang.toUpperCase()+'</h3><p>Traduis le mot :</p><h2 id="word">'+arr[i][0]+'</h2><input id="langAnswer" placeholder="Ta traduction..." style="width:100%;padding:12px;border-radius:10px;border:1px solid #303649;background:#0f121a;color:white"><button onclick="checkLang(\''+lang+'\')" style="margin-top:10px;padding:12px;border:0;border-radius:10px;background:#5b5ff7;color:white">Vérifier</button><div id="langFeedback"></div>';window.currentLang={lang,i}}
function checkLang(lang){let x=window.currentLang,arr=lessons[lang],ans=document.getElementById("langAnswer").value.trim().toLowerCase();let good=ans===arr[x.i][1].toLowerCase();document.getElementById("langFeedback").innerHTML='<div class="answer">'+(good?"✅ Correct ! +10 XP":"❌ Réponse : "+arr[x.i][1])+'</div>';if(good)addXP(10);x.i=(x.i+1)%arr.length;setTimeout(()=>{document.getElementById("word").textContent=arr[x.i][0];document.getElementById("langAnswer").value=""},700)}
function lesson(subject){let d=school[subject];document.getElementById("lessonBox").innerHTML='<h3>'+d[0]+'</h3><p>'+d[1]+'</p><hr><p><b>'+d[2]+'</b></p><input id="schoolAnswer" placeholder="Ta réponse..." style="width:100%;padding:12px;border-radius:10px;border:1px solid #303649;background:#0f121a;color:white"><button onclick="checkSchool(\''+subject+'\')" style="margin-top:10px;padding:12px;border:0;border-radius:10px;background:#5b5ff7;color:white">Vérifier</button><div id="schoolFeedback"></div>'}
function checkSchool(subject){let d=school[subject],ans=document.getElementById("schoolAnswer").value.trim().toLowerCase();let good=ans===d[3].toLowerCase();document.getElementById("schoolFeedback").innerHTML='<div class="answer">'+(good?"✅ Correct ! +15 XP":"❌ Réponse : "+d[3])+'</div>';if(good)addXP(15)}
function escapeHTML(s){return s.replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[c]))}
update();setLanguage("anglais");