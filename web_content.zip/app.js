const STORAGE_KEY="digitalChittilu_v1";
let state=loadState();
let currentPage="home";
let language="bilingual";

function defaultState(){return {chittilus:[],selectedChitId:null};}
function loadState(){try{return JSON.parse(localStorage.getItem(STORAGE_KEY))||defaultState()}catch(e){return defaultState()}}
function save(){localStorage.setItem(STORAGE_KEY,JSON.stringify(state))}
function selectedChit(){return state.chittilus.find(c=>c.id===state.selectedChitId)||null}
function uid(){return Date.now().toString(36)+Math.random().toString(36).slice(2,8)}
function money(n){return "₹"+Number(n||0).toLocaleString("en-IN")}
function esc(s){return String(s??"").replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[m]))}
function activeMembers(c){return c.members.filter(m=>m.active!==false)}
function required(c){return activeMembers(c).length*c.monthlyAmount}
function monthPayments(c,month){return c.payments.filter(p=>p.month===month)}
function collected(c,month){return monthPayments(c,month).filter(p=>p.status==="paid").reduce((a,p)=>a+Number(p.amount),0)}
function pending(c,month){return Math.max(0,required(c)-collected(c,month))}
function recipientFor(c,month){return c.recipients.find(r=>r.month===month)}
function receivedIds(c){return new Set(c.recipients.map(r=>r.memberId))}
function isComplete(c){return c.recipients.length>=activeMembers(c).length && activeMembers(c).length>0}
function currentMonth(c){return Math.min(c.currentMonth,c.totalMonths)}

function initPayments(c){
  c.payments=[];
  for(let month=1;month<=c.totalMonths;month++){
    activeMembers(c).forEach(m=>c.payments.push({id:uid(),memberId:m.id,month,amount:c.monthlyAmount,status:"pending",paidAt:null}));
  }
}
function render(){
  document.querySelectorAll(".nav-item").forEach(b=>b.classList.toggle("active",b.dataset.page===currentPage));
  const main=document.getElementById("appContent");
  const c=selectedChit();
  if(!c && currentPage!=="more"){main.innerHTML=emptyNoChit();return}
  if(currentPage==="home")main.innerHTML=home(c);
  else if(currentPage==="members")main.innerHTML=members(c);
  else if(currentPage==="collection")main.innerHTML=collection(c);
  else main.innerHTML=more(c);
}
function emptyNoChit(){
 return `<div class="card empty"><div class="big">📒</div><h2>No Chittilu Yet</h2><p>Create your first Chittilu to start.</p>
 <button class="btn btn-primary btn-block" onclick="showCreate()">➕ Create Chittilu</button></div>
 <div class="card"><strong>Digital Chittilu Notebook</strong><p class="muted small">Simple • Safe • Clear</p></div>`;
}
function switcher(c){
 return `<div class="card selector"><select onchange="selectChit(this.value)">
 ${state.chittilus.map(x=>`<option value="${x.id}" ${x.id===c?.id?"selected":""}>${esc(x.name)}</option>`).join("")}
 </select><button class="btn btn-primary" onclick="showCreate()">＋ New</button></div>`;
}
function home(c){
 const m=currentMonth(c), col=collected(c,m), req=required(c), rec=recipientFor(c,m), pct=req?Math.min(100,col/req*100):0;
 return `${switcher(c)}
 <div class="card"><h1>${esc(c.name)}</h1><div class="subtitle">నా చిట్టి • My Chittilu</div>
 <div class="grid2">
  <div class="stat"><div class="icon">👥</div><div class="label">Members / సభ్యులు</div><div class="value">${activeMembers(c).length}</div></div>
  <div class="stat"><div class="icon">💰</div><div class="label">Monthly / నెల</div><div class="value">${money(c.monthlyAmount)}</div></div>
  <div class="stat"><div class="icon">📅</div><div class="label">Current Month</div><div class="value">${m} / ${c.totalMonths}</div></div>
  <div class="stat"><div class="icon">🎁</div><div class="label">Recipients</div><div class="value">${c.recipients.length} / ${activeMembers(c).length}</div></div>
 </div></div>
 <div class="card"><div class="row"><div><div class="muted small">This Month Collection / ఈ నెల వసూలు</div><div class="amount">${money(col)}</div></div>
 <span class="badge ${col>=req?"badge-complete":"badge-pending"}">${col>=req?"✓ Fully Collected":"⚠ Pending"}</span></div>
 <div class="progress"><div style="width:${pct}%"></div></div>
 <div class="row small"><strong>${money(col)} collected</strong><strong>${money(req)} required</strong></div>
 ${col<req?`<div class="notice notice-danger" style="margin-top:12px">🔒 ${money(pending(c,m))} pending — collect full amount first.</div>`:
 `<div class="notice notice-success" style="margin-top:12px">✅ Full Collection Completed</div>`}</div>
 <div class="card"><div class="row"><div><div class="muted small">🎁 Current Recipient</div>
 <strong style="font-size:19px">${rec?esc(memberName(c,rec.memberId)):"Recipient Not Selected"}</strong></div>
 ${rec?`<span class="badge badge-received">🎁 Received</span>`:""}</div>
 ${rec?`<div class="muted small" style="margin-top:7px">${money(rec.amount)} • Month ${m}</div>`:
 isComplete(c)?`<div class="notice notice-success" style="margin-top:13px">🎉 Chittilu Completed — ${activeMembers(c).length} / ${activeMembers(c).length} Members Received</div>`:
 col>=req?`<button class="btn btn-primary btn-block" style="margin-top:13px" onclick="showRecipient()">🎁 Select This Month's Recipient</button>`:
 `<button class="btn btn-light btn-block" style="margin-top:13px" disabled>🔒 Collect Full Amount First</button>`}</div>
 <button class="btn btn-primary btn-block" onclick="showCreate()">➕ Create New Chittilu</button>`;
}
function memberName(c,id){return c.members.find(m=>m.id===id)?.name||"Unknown"}
function members(c){
 return `${switcher(c)}<div class="row"><div><h1>Members</h1><div class="subtitle">సభ్యులు</div></div>
 <button class="btn btn-primary" onclick="showMember()">➕ Add</button></div>
 ${activeMembers(c).length?activeMembers(c).map(m=>{
 const rec=c.recipients.find(r=>r.memberId===m.id);
 return `<div class="card member"><div class="avatar">👤</div><div class="member-info"><div class="member-name">${esc(m.name)}</div>
 <div class="member-phone">${m.phone?`📞 ${esc(m.phone)}`:"No phone"}</div>
 <div>${rec?`<span class="badge badge-received">🎁 Received — Month ${rec.month}</span>`:`<span class="badge badge-pending">⏳ Not Received</span>`}</div></div>
 <div class="member-right"><div class="price">${money(c.monthlyAmount)}</div><div class="actions">
 <button class="btn btn-light" onclick="showMember('${m.id}')">✏️</button>
 <button class="btn btn-danger" onclick="deleteMember('${m.id}')">🗑</button></div></div></div>`}).join(""):
 `<div class="card empty"><div class="big">👥</div><p>No members yet.</p><button class="btn btn-primary" onclick="showMember()">➕ Add Member</button></div>`}`;
}
function paymentFor(c,memberId,month){return c.payments.find(p=>p.memberId===memberId&&p.month===month)}
function collection(c){
 const m=currentMonth(c), col=collected(c,m), req=required(c), paid=monthPayments(c,m).filter(p=>p.status==="paid").length, total=activeMembers(c).length;
 return `${switcher(c)}<h1>Collection</h1><div class="subtitle">📅 Month ${m} / ${c.totalMonths} • Monthly Collection</div>
 <div class="card"><div class="muted small">Collected / మొత్తం వసూలు</div><div class="amount">${money(col)} <span class="muted" style="font-size:17px">/ ${money(req)}</span></div>
 <div class="progress"><div style="width:${req?Math.min(100,col/req*100):0}%"></div></div>
 <div class="row"><span class="badge badge-paid">✅ ${paid} Paid</span><span class="badge badge-pending">❌ ${total-paid} Pending</span></div></div>
 ${activeMembers(c).map(mem=>{
 const p=paymentFor(c,mem.id,m);const rec=c.recipients.find(r=>r.memberId===mem.id);
 return `<div class="card member"><div class="avatar">👤</div><div class="member-info"><div class="member-name">${esc(mem.name)}</div><div class="member-phone">${mem.phone?esc(mem.phone):""}</div>
 ${rec?`<span class="badge badge-received">🎁 Received — Month ${rec.month}</span>`:""}</div><div class="member-right"><div class="price">${money(p?.amount||c.monthlyAmount)}</div>
 ${p?.status==="paid"?`<span class="badge badge-paid">🟢 PAID</span><button class="btn btn-light btn-block" style="margin-top:7px" onclick="confirmPayment('${p.id}','pending')">↩ Mark Pending</button>`:
 `<span class="badge badge-pending">🔴 PENDING</span><button class="btn btn-success btn-block" style="margin-top:7px" onclick="confirmPayment('${p.id}','paid')">✅ Mark Paid</button>`}</div></div>`}).join("")}`;
}
function more(c){
 return `${c?switcher(c):""}<h1>More</h1><div class="subtitle">More options / మరిన్ని</div>
 <div class="card"><button class="btn btn-primary btn-block" onclick="showCreate()">➕ Create New Chittilu</button></div>
 ${c?`<div class="card"><button class="btn btn-light btn-block" onclick="showSchedule()">📋 Schedule / షెడ్యూల్</button>
 <button class="btn btn-light btn-block" style="margin-top:9px" onclick="showHistory()">🕘 History / చరిత్ర</button>
 <button class="btn btn-light btn-block" style="margin-top:9px" onclick="showSettings()">⚙️ Chittilu Settings</button></div>`:""}
 <div class="card"><strong>💾 Local Storage</strong><p class="muted small">Your data is saved on this device/browser. No server is required for V1.</p></div>`;
}
function modal(content){document.getElementById("modal").innerHTML=content;document.getElementById("modalBackdrop").classList.remove("hidden")}
function closeModal(){document.getElementById("modalBackdrop").classList.add("hidden")}
function showCreate(){
 modal(`<h2>➕ Create Chittilu</h2><p>Create a separate Chittilu with its own members and records.</p>
 <div class="form-group"><label class="form-label">Chittilu Name</label><input id="fName" placeholder="Friends Chit"></div>
 <div class="form-group"><label class="form-label">Number of Members</label><input id="fMembers" type="number" min="1" placeholder="10"></div>
 <div class="form-group"><label class="form-label">Monthly Contribution (₹)</label><input id="fAmount" type="number" min="1" placeholder="1000"></div>
 <div class="form-group"><label class="form-label">Duration / Number of Months</label><select id="fMonths">
 ${[3,5,6,8,10,12,15,20,24,36].map(n=>`<option>${n}</option>`).join("")}<option value="custom">Custom</option></select></div>
 <div id="customMonths" class="form-group hidden"><label class="form-label">Custom Months</label><input id="fCustom" type="number" min="1" max="120"></div>
 <div id="calc" class="notice notice-success">Monthly Collection: ₹0</div>
 <div class="actions" style="margin-top:14px"><button class="btn btn-light" onclick="closeModal()">Cancel</button><button class="btn btn-primary" onclick="createChit()">Create</button></div>`);
 ["fMembers","fAmount"].forEach(id=>document.getElementById(id).addEventListener("input",updateCalc));
 document.getElementById("fMonths").addEventListener("change",e=>{document.getElementById("customMonths").classList.toggle("hidden",e.target.value!=="custom")});
}
function updateCalc(){const n=+document.getElementById("fMembers").value||0,a=+document.getElementById("fAmount").value||0;document.getElementById("calc").textContent="Monthly Collection: "+money(n*a)}
function createChit(){
 const name=document.getElementById("fName").value.trim(),n=+document.getElementById("fMembers").value,a=+document.getElementById("fAmount").value;
 let months=document.getElementById("fMonths").value;if(months==="custom")months=+document.getElementById("fCustom").value;else months=+months;
 if(!name||n<1||a<1||months<1){alert("Please enter valid Chittilu details.");return}
 if(months>120){alert("Maximum 120 months.");return}
 if(months<1){return}
 const c={id:uid(),name,memberCount:n,monthlyAmount:a,totalMonths:months,currentMonth:1,status:"active",createdAt:new Date().toISOString(),members:[],payments:[],recipients:[]};
 state.chittilus.push(c);state.selectedChitId=c.id;save();closeModal();currentPage="members";render();
 alert("Chittilu created. Add members to begin.");
}
function showMember(id){
 const c=selectedChit(),m=id?c.members.find(x=>x.id===id):null;
 modal(`<h2>${m?"✏️ Edit Member":"➕ Add Member"}</h2>
 <div class="form-group"><label class="form-label">Name / పేరు</label><input id="mName" value="${esc(m?.name||"")}" placeholder="Ravi"></div>
 <div class="form-group"><label class="form-label">Phone / ఫోన్</label><input id="mPhone" value="${esc(m?.phone||"")}" inputmode="tel" placeholder="9876543210"></div>
 <div class="actions"><button class="btn btn-light" onclick="closeModal()">Cancel</button><button class="btn btn-primary" onclick="saveMember('${id||""}')">Save</button></div>`);
}
function saveMember(id){
 const c=selectedChit(),name=document.getElementById("mName").value.trim(),phone=document.getElementById("mPhone").value.trim();
 if(!name){alert("Name is required.");return}
 if(id){const m=c.members.find(x=>x.id===id);m.name=name;m.phone=phone}
 else{
  if(activeMembers(c).length>=c.memberCount){alert(`This Chittilu is configured for ${c.memberCount} members.`);return}
  const m={id:uid(),name,phone,photo:null,active:true,createdAt:new Date().toISOString()};c.members.push(m);
  for(let month=1;month<=c.totalMonths;month++)c.payments.push({id:uid(),memberId:m.id,month,amount:c.monthlyAmount,status:"pending",paidAt:null});
 }
 save();closeModal();render();
}
function deleteMember(id){
 const c=selectedChit(),m=c.members.find(x=>x.id===id);
 if(c.recipients.some(r=>r.memberId===id)){alert("A received member cannot be deleted.");return}
 if(!confirm(`Delete ${m.name}?`))return;
 m.active=false;c.payments=c.payments.filter(p=>p.memberId!==id);save();render();
}
function confirmPayment(pid,newStatus){
 const c=selectedChit(),p=c.payments.find(x=>x.id===pid),m=c.members.find(x=>x.id===p.memberId);
 const text=newStatus==="paid"?`Mark ${m.name} as Paid for ${money(p.amount)}?`:`Are you sure you want to mark ${m.name} as Pending?`;
 modal(`<h2>${newStatus==="paid"?"✅ Mark Paid":"↩ Mark Pending"}</h2><p>${esc(text)}</p>
 <div class="actions"><button class="btn btn-light" onclick="closeModal()">Cancel</button><button class="btn ${newStatus==="paid"?"btn-success":"btn-primary"}" onclick="applyPayment('${pid}','${newStatus}')">Confirm</button></div>`);
}
function applyPayment(pid,status){const c=selectedChit(),p=c.payments.find(x=>x.id===pid);p.status=status;p.paidAt=status==="paid"?new Date().toISOString():null;save();closeModal();render()}
function showRecipient(){
 const c=selectedChit(),m=currentMonth(c);
 if(isComplete(c)){alert("This Chittilu is already completed.");return}
 if(collected(c,m)<required(c)){alert("Full collection is required before selecting a recipient.");return}
 if(recipientFor(c,m)){alert("This month already has a recipient.");return}
 const eligible=activeMembers(c).filter(x=>!receivedIds(c).has(x.id));
 if(!eligible.length){alert("No eligible members remaining.");return}
 modal(`<h2>🎁 Who Gets This Month's Chit?</h2><p>ఈ నెల ఎవరికి? • Month ${m} • ${money(required(c))}</p>
 <div class="card" style="background:#f8faff"><button class="btn btn-primary btn-block" onclick="randomRecipient()">🎲 Pick Random Member</button></div>
 <div class="section-title">Choose Manually</div>
 ${eligible.map(x=>`<button class="card btn-light btn-block" style="text-align:left;margin-bottom:8px" onclick="selectRecipient('${x.id}')">👤 <strong>${esc(x.name)}</strong><br><span class="muted small">⏳ Not Received</span></button>`).join("")}
 <button class="btn btn-light btn-block" onclick="closeModal()">Cancel</button>`);
}
function randomRecipient(){
 const c=selectedChit(),eligible=activeMembers(c).filter(x=>!receivedIds(c).has(x.id));
 const pick=eligible[Math.floor(Math.random()*eligible.length)];selectRecipient(pick.id);
}
function selectRecipient(id){
 const c=selectedChit(),m=currentMonth(c),member=c.members.find(x=>x.id===id);
 if(collected(c,m)<required(c)||recipientFor(c,m)||receivedIds(c).has(id)){alert("Recipient selection is not allowed for this member/month.");return}
 modal(`<h2>🎁 Confirm Recipient</h2><p>Give <strong>${money(required(c))}</strong> to <strong>${esc(member.name)}</strong>?</p>
 <div class="card"><div class="row"><strong>Month ${m}</strong><strong>${money(required(c))}</strong></div></div>
 <div class="actions"><button class="btn btn-light" onclick="showRecipient()">Cancel</button><button class="btn btn-primary" onclick="saveRecipient('${id}')">✅ Confirm</button></div>`);
}
function saveRecipient(id){
 const c=selectedChit(),m=currentMonth(c);
 if(collected(c,m)<required(c)||recipientFor(c,m)||receivedIds(c).has(id)){alert("Recipient could not be saved.");return}
 c.recipients.push({id:uid(),chitId:c.id,month:m,memberId:id,amount:required(c),selectedMethod:"manual",selectedAt:new Date().toISOString()});
 if(c.recipients.length>=activeMembers(c).length)c.status="completed";
 else if(m<c.totalMonths)c.currentMonth=m+1;
 save();closeModal();render();
 alert(`Recipient saved: ${memberName(c,id)} — ${money(required(c))}`);
}
function showSchedule(){
 const c=selectedChit();
 modal(`<h2>📋 Chit Progress</h2><p>Actual recorded recipients only.</p>
 ${Array.from({length:c.totalMonths},(_,i)=>i+1).map(m=>{const r=recipientFor(c,m),cur=m===currentMonth(c)&&!r;
 return `<div class="schedule-item"><div class="month-circle">${m}</div><div><strong>${r?"🎁 "+esc(memberName(c,r.memberId)):"🎁 Not Selected"}</strong><span class="muted small">${r?money(r.amount)+" • Completed":cur?"🟢 Current":"⏳ Upcoming"}</span></div></div>`}).join("")}
 <button class="btn btn-light btn-block" onclick="closeModal()">Close</button>`);
}
function showHistory(){
 const c=selectedChit();
 modal(`<h2>🕘 Monthly History</h2><p>Previous and current month records.</p>
 ${Array.from({length:c.totalMonths},(_,i)=>i+1).map(m=>{const ps=monthPayments(c,m),paid=ps.filter(p=>p.status==="paid").length,r=recipientFor(c,m);
 return `<div class="card"><div class="row"><strong>Month ${m}</strong><span class="badge ${paid===activeMembers(c).length?"badge-complete":"badge-pending"}">${paid}/${activeMembers(c).length} Paid</span></div>
 <div class="small muted" style="margin-top:8px">Collection: ${money(collected(c,m))} / ${money(required(c))}</div>
 <div class="small" style="margin-top:5px">🎁 Recipient: <strong>${r?esc(memberName(c,r.memberId)):"Not Selected"}</strong></div></div>`}).join("")}
 <button class="btn btn-light btn-block" onclick="closeModal()">Close</button>`);
}
function showSettings(){
 const c=selectedChit();
 modal(`<h2>⚙️ Chittilu Details</h2><div class="card"><div class="small muted">Name</div><strong>${esc(c.name)}</strong><hr class="divider">
 <div class="small muted">Members</div><strong>${activeMembers(c).length} / ${c.memberCount}</strong><hr class="divider">
 <div class="small muted">Monthly Contribution</div><strong>${money(c.monthlyAmount)}</strong><hr class="divider">
 <div class="small muted">Duration</div><strong>${c.totalMonths} Months</strong></div>
 <button class="btn btn-danger btn-block" onclick="deleteChit()">🗑 Delete Chittilu</button>
 <button class="btn btn-light btn-block" style="margin-top:8px" onclick="closeModal()">Close</button>`);
}
function deleteChit(){
 const c=selectedChit();if(!confirm(`Delete Chittilu "${c.name}" and all its records?`))return;
 state.chittilus=state.chittilus.filter(x=>x.id!==c.id);state.selectedChitId=state.chittilus[0]?.id||null;save();closeModal();currentPage="home";render();
}
function selectChit(id){state.selectedChitId=id;save();currentPage="home";render()}
document.querySelectorAll(".nav-item").forEach(b=>b.addEventListener("click",()=>{currentPage=b.dataset.page;render()}));
document.getElementById("modalBackdrop").addEventListener("click",e=>{if(e.target.id==="modalBackdrop")closeModal()});
document.getElementById("languageBtn").addEventListener("click",()=>{language=language==="bilingual"?"english":"bilingual";document.getElementById("languageBtn").textContent=language==="bilingual"?"EN":"TE"});
render();
