
// Simple single-file app logic
document.addEventListener('DOMContentLoaded', function(){
  const splash = document.getElementById('splash');
  const home = document.getElementById('home');
  const memes = document.getElementById('memes');
  const about = document.getElementById('about');
  const feedback = document.getElementById('feedback');

  function show(el){
    [splash,home,memes,about,feedback].forEach(e => e.classList.add('hidden'));
    el.classList.remove('hidden');
  }

  document.getElementById('enterBtn').addEventListener('click', ()=> show(home));
  document.getElementById('openMemes').addEventListener('click', ()=> show(memes));
  document.getElementById('openAbout').addEventListener('click', ()=> show(about));
  document.getElementById('openFeedback').addEventListener('click', ()=> show(feedback));

  document.querySelectorAll('.back').forEach(b=>b.addEventListener('click', ()=> show(home)));

  // Meme logic (placeholder images list)
  const memesList = [
    {img:'icon.png', caption:'"لما تحاول تشرح لأخوك وهو مو فاهم 😂"'},
    {img:'icon.png', caption:'"صاحبي لما يشوف الرسمة الأولى 😅"'},
    {img:'icon.png', caption:'"اول مرة ارسم واطلع تحفة 😎"'}
  ];
  let idx = 0;
  document.getElementById('nextMeme').addEventListener('click', ()=>{
    idx = (idx+1) % memesList.length;
    document.getElementById('memeImg').src = memesList[idx].img;
    document.getElementById('memeCaption').textContent = memesList[idx].caption;
  });

  // Sound placeholder
  document.getElementById('playSound').addEventListener('click', ()=>{
    alert('تشغيل صوت (نموذج): صوت ضحك');
  });

  // Feedback send
  document.getElementById('sendFeedback').addEventListener('click', ()=>{
    const txt = document.getElementById('feedbackText').value.trim();
    if(!txt){ alert('اكتب رأيك أولًا'); return;}
    alert('شكرًا! تم إرسال رأيك (نموذج)');
    document.getElementById('feedbackText').value = '';
  });

  // Theme toggle
  const themeBtn = document.getElementById('themeToggle');
  themeBtn.addEventListener('click', ()=>{
    document.body.classList.toggle('dark');
    themeBtn.textContent = document.body.classList.contains('dark') ? 'وضع النهار' : 'وضع الليل';
  });

  // Show splash for short time then home
  setTimeout(()=> show(splash), 100);
});
