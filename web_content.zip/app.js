const root=document.getElementById('app'), panel=document.getElementById('panel'), shade=document.getElementById('shade');
const handle=document.getElementById('handle'), close=document.getElementById('close'), clock=document.getElementById('clock');
const win=document.getElementById('window'), winTitle=document.getElementById('windowTitle'), winBody=document.getElementById('windowBody');
const winClose=document.getElementById('windowClose');

function openPanel(){root.classList.add('open')}
function closePanel(){root.classList.remove('open')}
handle.addEventListener('click',openPanel); close.addEventListener('click',closePanel); shade.addEventListener('click',closePanel);

let sx=0;
handle.addEventListener('touchstart',e=>sx=e.touches[0].clientX,{passive:true});
handle.addEventListener('touchend',e=>{if(sx-e.changedTouches[0].clientX>25)openPanel()},{passive:true});
panel.addEventListener('touchstart',e=>sx=e.touches[0].clientX,{passive:true});
panel.addEventListener('touchend',e=>{if(e.changedTouches[0].clientX-sx>45)closePanel()},{passive:true});

function tick(){clock.textContent=new Date().toLocaleTimeString('ru-RU',{hour:'2-digit',minute:'2-digit'})}
tick();setInterval(tick,1000);

document.querySelectorAll('.tile').forEach(t=>t.addEventListener('click',()=>{
 t.classList.toggle('active');
 const s=t.querySelector('small');
 if(s && (t.dataset.name==='Wi‑Fi'||t.dataset.name==='Bluetooth')) s.textContent=s.textContent==='Вкл.'?'Выкл.':'Вкл.';
}));

function showApp(name){
 winTitle.textContent=name; win.classList.add('show');
 if(name==='Калькулятор'){winBody.innerHTML=`<div class="calc"><input id="display" readonly><div class="keys">${['7','8','9','÷','4','5','6','×','1','2','3','−','0','.','=','+'].map(x=>`<button>${x}</button>`).join('')}</div></div>`;
   let d=document.getElementById('display'), expr=''; winBody.querySelectorAll('.keys button').forEach(b=>b.onclick=()=>{let x=b.textContent;if(x==='='){try{d.value=Function('return '+expr.replaceAll('×','*').replaceAll('÷','/').replaceAll('−','-'))()}catch{d.value='Ошибка'}expr=''}else{expr+=x;d.value=expr}})}
 else if(name==='Заметки'){winBody.innerHTML='<div class="note"><textarea placeholder="Напиши заметку..."></textarea></div>'}
 else if(name==='Камера'){winBody.innerHTML='<h2>📷 Камера</h2><p>Окно камеры готово для подключения к системной камере в следующей версии.</p>'}
 else if(name==='Музыка'){winBody.innerHTML='<h2>🎵 Музыка</h2><p>Мини-плеер SmartPanel.</p><button style="padding:12px;border-radius:12px;background:#2b3547">▶ Воспроизвести</button>'}
 else if(name==='Браузер'){winBody.innerHTML='<h2>🌐 Браузер</h2><p>Открой браузер телефона для полноценного веб-сёрфинга.</p>'}
 else if(name==='Файлы'){winBody.innerHTML='<h2>📁 Файлы</h2><p>Файловый менеджер SmartPanel.</p>'}
 else {winBody.innerHTML='<h2>⚙ Настройки</h2><p>Мини-окно настроек SmartPanel.</p>'}
}
document.querySelectorAll('.app').forEach(b=>b.addEventListener('click',()=>showApp(b.dataset.app)));
document.querySelectorAll('[data-action]').forEach(b=>b.addEventListener('click',()=>showApp(b.dataset.action)));
winClose.addEventListener('click',()=>win.classList.remove('show'));