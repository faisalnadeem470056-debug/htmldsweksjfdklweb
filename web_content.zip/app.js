const members=["Agung Ardi","Agung IT","Nesi","Darojat","Deni","Fanny","Clara","Wulan","Ery","Toro"];
const months=["Semua Bulan","Januari","Februari","Maret","April","Mei","Juni","Juli","Agustus","September","Oktober","November","Desember"];
let data=JSON.parse(localStorage.getItem("kasAccounting2026")||"[]");

function rupiah(n){return new Intl.NumberFormat("id-ID",{style:"currency",currency:"IDR",maximumFractionDigits:0}).format(n||0)}
function save(){localStorage.setItem("kasAccounting2026",JSON.stringify(data))}
function login(){if(document.getElementById("pin").value==="1234"){document.getElementById("login").classList.add("hidden");document.getElementById("app").classList.remove("hidden");init()}else alert("PIN salah. PIN awal 1234.")}
function init(){
 let mf=document.getElementById("monthFilter");mf.innerHTML=months.map((m,i)=>`<option value="${i}">${m}</option>`).join("");
 let ns=document.getElementById("name");ns.innerHTML=members.map(x=>`<option>${x}</option>`).join("");
 document.getElementById("date").value=new Date().toISOString().slice(0,10);
 render();
}
function filtered(){let m=+document.getElementById("monthFilter").value;let q=(document.getElementById("search")?.value||"").toLowerCase();return data.filter(x=>(!m||new Date(x.date).getMonth()+1===m)&&(!q||(x.name+" "+x.desc).toLowerCase().includes(q)))}
function render(){
 let arr=filtered(), inc=arr.filter(x=>x.type==="in").reduce((a,x)=>a+x.amount,0), out=arr.filter(x=>x.type==="out").reduce((a,x)=>a+x.amount,0);
 document.getElementById("income").textContent=rupiah(inc);document.getElementById("expense").textContent=rupiah(out);document.getElementById("saldo").textContent=rupiah(inc-out);document.getElementById("count").textContent=arr.length;
 let max=Math.max(inc,out,1);document.getElementById("barIn").style.width=(inc/max*100)+"%";document.getElementById("barOut").style.width=(out/max*100)+"%";
 document.getElementById("list").innerHTML=arr.slice().sort((a,b)=>b.date.localeCompare(a.date)).map(txHTML).join("")||empty("Belum ada transaksi");
 document.getElementById("recent").innerHTML=arr.slice().sort((a,b)=>b.date.localeCompare(a.date)).slice(0,5).map(txHTML).join("")||empty("Belum ada transaksi");
 let ml=document.getElementById("memberList");ml.innerHTML=members.map(n=>{let i=arr.filter(x=>x.name===n&&x.type==="in").reduce((a,x)=>a+x.amount,0),o=arr.filter(x=>x.name===n&&x.type==="out").reduce((a,x)=>a+x.amount,0);return `<div class="member"><div><b>${n}</b><small>Saldo anggota</small></div><strong class="${i-o>=0?"in":"out"}">${rupiah(i-o)}</strong></div>`}).join("");
 let monthly=[];for(let m=1;m<=12;m++){let a=data.filter(x=>new Date(x.date).getMonth()+1===m),i=a.filter(x=>x.type==="in").reduce((s,x)=>s+x.amount,0),o=a.filter(x=>x.type==="out").reduce((s,x)=>s+x.amount,0);monthly.push(`<div class="report-row"><div><b>${months[m]}</b><small>${a.length} transaksi</small></div><strong>${rupiah(i-o)}</strong></div>`)}document.getElementById("report").innerHTML=monthly.join("");
}
function txHTML(x){return `<div class="tx"><div class="meta"><b>${x.desc||"-"}</b><small>${x.name} · ${x.date}</small></div><div><strong class="${x.type==="in"?"in":"out"}">${x.type==="in"?"+":"-"}${rupiah(x.amount)}</strong><div class="tx-actions"><button onclick="editTx('${x.id}')">Edit</button><button onclick="delTx('${x.id}')">Hapus</button></div></div></div>`}
function empty(s){return `<div class="panel"><small>${s}</small></div>`}
function openForm(id=null){document.getElementById("modal").classList.remove("hidden");document.getElementById("formTitle").textContent=id?"Edit Transaksi":"Tambah Transaksi";document.getElementById("editId").value=id||"";let x=data.find(a=>a.id===id);document.getElementById("date").value=x?.date||new Date().toISOString().slice(0,10);document.getElementById("name").value=x?.name||members[0];document.getElementById("desc").value=x?.desc||"";document.getElementById("type").value=x?.type||"in";document.getElementById("amount").value=x?.amount||""}
function closeForm(){document.getElementById("modal").classList.add("hidden")}
function saveTx(){let id=document.getElementById("editId").value||crypto.randomUUID();let x={id,date:document.getElementById("date").value,name:document.getElementById("name").value,desc:document.getElementById("desc").value,type:document.getElementById("type").value,amount:+document.getElementById("amount").value};if(!x.date||!x.amount)return alert("Tanggal dan nominal wajib diisi");let idx=data.findIndex(a=>a.id===id);if(idx>=0)data[idx]=x;else data.push(x);save();closeForm();render()}
function editTx(id){openForm(id)}
function delTx(id){if(confirm("Hapus transaksi ini?")){data=data.filter(x=>x.id!==id);save();render()}}
function page(id){document.querySelectorAll(".page").forEach(x=>x.classList.remove("active"));document.getElementById(id).classList.add("active");document.querySelectorAll("nav button").forEach(x=>x.classList.remove("active"))}
function toggleDark(){document.body.classList.toggle("dark");localStorage.setItem("dark",document.body.classList.contains("dark"))}
if(localStorage.getItem("dark")==="true")document.body.classList.add("dark");
function backup(){let blob=new Blob([JSON.stringify(data,null,2)],{type:"application/json"}),a=document.createElement("a");a.href=URL.createObjectURL(blob);a.download="backup-kas-accounting-2026.json";a.click()}
function restoreClick(){document.getElementById("restore").click()}
function restore(e){let f=e.target.files[0];if(!f)return;let r=new FileReader();r.onload=()=>{try{let x=JSON.parse(r.result);if(!Array.isArray(x))throw 0;data=x;save();render();alert("Restore berhasil")}catch{alert("File backup tidak valid")}};r.readAsText(f)}
