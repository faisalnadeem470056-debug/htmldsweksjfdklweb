const defaultPosts=[
 {title:"د ژوند ښکلی اړخ",cat:"ادبي ټوټې",text:"ژوند هغه وخت لا ښکلی کېږي چې د نورو لپاره د خوښۍ سبب شو.",views:120},
 {title:"یوه لنډه ټوکه",cat:"ټوکې",text:"خندا د ورځې تر ټولو ارزانه خوږه ده؛ نو هره ورځ لږه خندا مه هېروئ!",views:80},
 {title:"د امید خبره",cat:"بیتونه",text:"که شپه هر څومره اوږده وي، سهار خامخا راځي.",views:250},
 {title:"ښه اخلاق",cat:"حدیث",text:"له خلکو سره په نرمه ژبه او ښه اخلاقو چلند وکړئ.",views:500}
];
let posts=JSON.parse(localStorage.getItem("dz_posts")||"null")||defaultPosts;
let currentCat="ټول";
function hideSplash(){const s=document.getElementById("splash");if(s)s.classList.add("hidden")}
setTimeout(hideSplash,1800);window.addEventListener("load",()=>setTimeout(hideSplash,500));document.addEventListener("DOMContentLoaded",()=>{setTimeout(hideSplash,1800);renderPosts();loadAccount();});
function showPage(id){document.querySelectorAll(".page").forEach(p=>p.classList.remove("active"));document.getElementById(id).classList.add("active");const names={home:"اصلي مینو",posts:"مطالب",about:"زموږ په اړه",account:"زما حساب",admin:"د اډمین اداره"};document.getElementById("pageTitle").textContent=names[id]||"";window.scrollTo(0,0)}
function goHome(){showPage("home")}
function filterPosts(cat){currentCat=cat;renderPosts()}
function renderPosts(){const box=document.getElementById("postsList");const list=posts.filter(p=>currentCat==="ټول"||p.cat===currentCat);box.innerHTML=list.map((p,i)=>`<article class="post"><h3>${esc(p.title)}</h3><p>${esc(p.text)}</p><div class="meta"><span>🏷️ ${esc(p.cat)}</span><span>👁️ ${Number(p.views)||0}</span><span>❤️ 0</span><span>💬 0</span></div></article>`).join("")||"<div class='notice'>تر اوسه مطلب نشته.</div>";document.getElementById("offline").style.display=navigator.onLine?"none":"block"}
function esc(s){return String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}
function togglePass(){const x=document.getElementById("password");x.type=x.type==="password"?"text":"password"}
function saveAccount(){const d={name:document.getElementById("name").value,email:document.getElementById("email").value};localStorage.setItem("dz_account",JSON.stringify(d));document.getElementById("accountMsg").textContent="✅ معلومات خوندي شوې."}
function loadAccount(){const d=JSON.parse(localStorage.getItem("dz_account")||"null");if(d){document.getElementById("name").value=d.name||"";document.getElementById("email").value=d.email||""}}
function addAdminPost(){const title=document.getElementById("adminTitle").value.trim(),text=document.getElementById("adminText").value.trim(),cat=document.getElementById("adminCat").value,views=Math.max(0,Number(document.getElementById("adminViews").value)||0);if(!title||!text){alert("مهرباني وکړئ سرلیک او مطلب ولیکئ.");return}posts.unshift({title,text,cat,views});localStorage.setItem("dz_posts",JSON.stringify(posts));document.getElementById("adminTitle").value="";document.getElementById("adminText").value="";renderPosts();alert("مطلب اضافه شو.")}
function exitApp(){try{window.close()}catch(e){}alert("د اپ د وتلو لپاره د موبایل Back تڼۍ وکاروئ.")}
window.addEventListener("online",renderPosts);window.addEventListener("offline",renderPosts);
