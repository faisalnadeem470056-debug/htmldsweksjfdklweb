const crops=[
{name:"Liin",icon:"🍋",type:"Geed miro",summary:"Geed miro oo u baahan qorrax, biyo nidaamsan iyo nafaqo joogto ah.",stages:[
["🌱","Marxaladda yar","Bilaha hore ilaali xididka, ciidda qoyaan dhexdhexaad ahna ku hay. Ka fogee cawska tartanka la gala.","Biyo yar oo joogto ah; Ha ku fatahin","Ku dar compost bisil agagaarka xididka","Ka ilaali cayayaanka iyo xoolaha"],
["🌿","Markuu xoogaysto","Samee qaab-dhisid laamo caafimaad leh. Jar laamaha dhaawacan, ciidda ku dabool mulch.","Waraabi marka ciiddu qalasho","NPK si dhexdhexaad ah xilliga koritaanka","La soco aphids iyo cayayaanka caleenta"],
["🍋","Markuu qaangaaro","Maamul ubaxa iyo miraha, jar laamaha isdhaafaya, kana ilaali biyo-fadhiisiga.","Biyo qoto dheer laakiin aan joogto u fatahin","Compost + potassium marka miro samaysmaan","Goosashada ku samee marka midab iyo bislaansho sax ah la gaaro"]]},
{name:"Moos",icon:"🍌",type:"Geed miro",summary:"Moosku si fiican ayuu u koraa marka uu helo biyo iyo potassium ku filan.",stages:[
["🌱","Geed yar","Ka ilaali dabayl iyo xoolo, ciidda qoyaan joogto ah ku hay.","Waraab joogto ah","Compost/organic matter","Ka saar caleemaha si daran u dhaawacmay"],
["🌿","Koritaan xooggan","Ka saar caleemaha qallalan iyo laamaha/nuugayaasha xad-dhaafka ah.","Biyo badan xilliga kulaylka","NPK iyo potassium si qorshaysan","La soco fangaska iyo cayayaanka"],
["🍌","Qaangaar & miro","Taageer jirridda marka rucubku culus yahay, kadibna gooso marka miruhu gaarayaan bislaansho ku habboon.","Ha u oggolaan ciiddu inay si xad-dhaaf ah u qalasho","Potassium ayaa muhiim u ah tayada miraha","Nadiifi agagaarka geedka"]]},
{name:"Basal",icon:"🧅",type:"Dalag",summary:"Basasha waxay jeceshahay ciid si fiican u daadisa iyo waraab aan xad-dhaaf ahayn.",stages:[
["🌱","Bilowga","Abuurka ama geedo yaryar si tartiib ah u waraabi; cawska ka saar.","Qoyaan joogto ah","Compost bisil","Ha buuxin biyaha"],
["🌿","Koritaanka nalka","Waraabka iyo nafaqada si joogto ah u maamul; cawska ha badnaan.","Yaree waraabka haddii roob jiro","NPK qiyaas ku habboon ciidda","La soco thrips"],
["🧅","Qaangaar & goosasho","Marka caleemuhu dhacaan oo nalka adkaado, yaree waraabka oo diyaari goosashada.","Yaree biyaha ka hor goosashada","Ha ku badin nitrogen dhammaadka","Qallaji basasha meel hawo leh"]]},
{name:"Timir",icon:"🌴",type:"Geed miro",summary:"Timirtu waxay u adkaysataa kulaylka, balse waxay u baahan tahay biyo iyo nafaqo nidaamsan si wax-soo-saar fiican loo helo.",stages:[
["🌱","Geed yar","Xididka ka ilaali dhaawac, samee basin waraab ah, kana ilaali xoolaha.","Waraab qoto dheer","Compost + organic matter","Nadiifi haramaha"],
["🌿","Koritaan","Maamul caleemaha hoose ee qalalan, ciidda ku dabool mulch.","Waraab nidaamsan","NPK iyo micronutrients haddii loo baahdo","La soco cayayaanka timirta"],
["🌴","Qaangaar","Maamul ubaxa, miraha iyo nadaafadda geedka; isticmaal farsamooyinka beerista deegaanka ku habboon.","Biyo ku filan xilliga miraha","Potassium iyo compost ayaa caawin kara","Goosashada ku samee marxaladda ku habboon"]]},
{name:"Yaanyo",icon:"🍅",type:"Dalag",summary:"Yaanyadu waxay u baahan tahay qorrax, taageero jirridda iyo waraab joogto ah.",stages:[
["🌱","Seedling","Geedka yar qorrax tartiib ah u bar oo xididka ha dhaawicin.","Waraab fudud","Compost yar","Ka ilaali fangaska"],
["🌿","Koritaan","Ku xir taageero, jar caleemaha aadka u hooseeya, hana qoyn caleemaha marka loo baahdo.","Waraab joogto ah","NPK dheellitiran","La soco whitefly iyo aphids"],
["🍅","Ubax & miro","Ilaali biyaha iyo potassium; gooso miraha marka ay gaaraan bislaansho ku habboon.","Ha isbedbedelin qoyaanka","Potassium xilliga miro samayska","Ka saar miraha/caleemaha buka"]]},
{name:"Galley",icon:"🌽",type:"Dalag",summary:"Galleydu waxay u baahan tahay nafaqo gaar ahaan nitrogen xilliga koritaanka.",stages:[
["🌱","Bilowga","Ciidda nadiifi oo geedaha yaryar ka ilaali cawska.","Waraab marka loo baahdo","Compost ama nafaqo bilow ah","Ka ilaali cayayaanka bilowga"],
["🌿","Koritaan","Nidaami kala fogaanshaha iyo cawska; la soco jirridda.","Waraab muhiim ah xilliyada qalalan","Nitrogen ku filan","La soco stem borers"],
["🌽","Buuxinta hadhuudhka","Ha joojin biyaha xilliga muhiimka ah haddii dhulku qalalan yahay; diyaari goosashada.","Waraab xilliga hadhuudhka","Ha ku badin nitrogen dhammaadka","Gooso marka hadhuudhku bislaado"]]},
{name:"Sisin",icon:"🌾",type:"Dalag",summary:"Sisin waa dalag u adkaysta xaaladaha qalalan marka ciidda si wanaagsan loo maareeyo.",stages:[
["🌱","Bilowga","Geedaha yaryar ka ilaali cawska iyo biyo-fadhiisiga.","Waraab fudud marka loo baahdo","Compost haddii ciiddu liidato","Ha ku fatahin biyo"],
["🌿","Koritaan","Yaree tartanka cawska, la soco ubaxa iyo cayayaanka.","Waraab marka qalayl daran jiro","Nafaqo dheellitiran","Kormeer caleemaha"],
["🌾","Qaangaar","Marka qaybta sare iyo sanduuqyada abuurku bislaanayaan, diyaari goosasho waqtigeeda.","Ka fogow waraab xad-dhaaf ah","Ha ku badin nitrogen","Goosashada ka ilaali daadashada abuurka"]]},
{name:"Qajaar",icon:"🥒",type:"Dalag",summary:"Qajaarku si degdeg ah ayuu u koraa, wuxuuna u baahan yahay qoyaan joogto ah.",stages:[
["🌱","Bilowga","Qorrax iyo ciid jilicsan sii.","Waraab yar oo joogto ah","Compost","Ka ilaali slugs iyo cayayaanka"],
["🌿","Koritaan","U samee meel uu fuulo haddii noocaasi u baahan yahay.","Waraab joogto ah","NPK dheellitiran","La soco mildew"],
["🥒","Miro","Gooso si joogto ah si wax-soo-saarku u sii socdo.","Ha qalajin ciidda","Potassium dhexdhexaad ah","Ka saar miraha dhaawacan"]]},
{name:"Qaraha",icon:"🍉",type:"Dalag",summary:"Qaraha wuxuu jecel yahay qorrax badan iyo ciid si fiican u daadisa.",stages:[
["🌱","Bilowga","Geedo yaryar si taxaddar leh u waraabi.","Qoyaan dhexdhexaad ah","Compost","Ka ilaali cawska"],
["🌿","Kala bax","Meel ku filan sii si laamaha u fidaan.","Waraab qoto dheer marka loo baahdo","NPK dheellitiran","La soco aphids"],
["🍉","Miro","Xilliga miro buuxinta biyo iyo potassium si nidaamsan u maamul.","Yaree waraabka marka bislaansho dhowdahay","Potassium","Ka hubi midabka iyo calaamadaha bislaanshaha"]]},
{name:"Baradho",icon:"🥔",type:"Dalag",summary:"Baradhadu waxay u baahan tahay ciid dabacsan, hawo leh iyo waraab joogto ah.",stages:[
["🌱","Bilowga","Abuurka caafimaad qaba ku beer ciid diyaarsan.","Qoyaan dhexdhexaad ah","Compost","Ka ilaali qudhunka"],
["🌿","Koritaan","Ciidda ku dabo xagga jirridda si tubers-ku u samaysmaan si fiican.","Waraab nidaamsan","NPK ku habboon","La soco beetles/fangaska"],
["🥔","Qaangaar","Marka caleemuhu huruudaan oo tuberku bislaado, diyaari goosashada.","Yaree waraabka dhammaadka","Ha ku badin nitrogen","Qallaji oo ku kaydi meel qabow/hawo leh"]]},
{name:"Basbaas",icon:"🌶️",type:"Dalag",summary:"Basbaasku wuxuu u baahan yahay qorrax, nafaqo iyo maarayn biyo oo deggan.",stages:[
["🌱","Geed yar","Ka ilaali kulaylka xad-dhaafka ah iyo biyo-fadhiisiga.","Waraab fudud","Compost","Ka ilaali aphids"],
["🌿","Koritaan","Samee geed caafimaad leh oo laamo fiican leh.","Waraab joogto ah","NPK dheellitiran","La soco thrips"],
["🌶️","Miro","Gooso miraha si joogto ah marka ay gaaraan midabka/baaxadda la rabo.","Ha qallajin ciidda","Potassium xilliga miraha","Ka saar miraha buka"]]},
{name:"Cambe",icon:"🥭",type:"Geed miro",summary:"Cambaha wuxuu u baahan yahay meel qorrax leh, ciid daadisa iyo jaritaan sax ah.",stages:[
["🌱","Geed yar","Samee jirid hoggaamineed oo caafimaad leh, kana ilaali xoolaha.","Waraab joogto ah","Compost bisil","Mulch ku wareeji, ha ku dhejin jirridda"],
["🌿","Koritaan","Jar laamaha isdhaafaya oo qaabee taajka.","Waraab xilliga qalalan","NPK ku salaysan ciidda","La soco cayayaanka"],
["🥭","Qaangaar","Maamul ubaxa iyo miraha; nadaafadda taajku waxay caawisaa hawo-galka.","Biyo muhiim ah xilliga miraha","Potassium + organic matter","Gooso miraha si taxaddar leh"]]},
{name:"Avokado",icon:"🥑",type:"Geed miro",summary:"Avokadadu waxay si gaar ah uga baqdaa biyo-fadhiisiga xididka.",stages:[
["🌱","Geed yar","Ciid daadisa iyo mulch khafiif ah sii.","Waraab marka dusha ciiddu qalasho","Compost","Ha ku aasin jirridda"],
["🌿","Koritaan","Taajka qaabee, xididkana ka ilaali dhaawac.","Waraab qoto dheer oo kala fog","Nafaqo dheellitiran","La soco root rot"],
["🥑","Qaangaar","Ilaali ubaxa iyo miraha, hana oggolaan biyo-fadhiisiga.","Maamul qoyaan joogto ah","Potassium iyo micronutrients haddii loo baahdo","Goosashada ku samee calaamadaha bislaanshaha"]]},
{name:"Papaya",icon:"🧡",type:"Geed miro",summary:"Papaya waa geed si dhakhso ah u kora oo jecel kulayl iyo ciid daadisa.",stages:[
["🌱","Geed yar","Ka ilaali dabayl iyo biyo-fadhiisiga.","Waraab dhexdhexaad ah","Compost","Nadiifi hareeraha"],
["🌿","Koritaan","Ka ilaali jirridda jab iyo caleemo dhaawacmay.","Waraab joogto ah xilliga qalalan","NPK dheellitiran","La soco cayayaanka"],
["🧡","Miro","Marka miruhu bilaabaan midab beddel, qorshee goosashada iyo suuq-geynta.","Biyo joogto ah","Potassium","Ka saar miraha dhaawacmay"]]},
{name:"Karootada",icon:"🥕",type:"Dalag",summary:"Karootadu waxay u baahan tahay ciid jilicsan oo aan dhagax badan lahayn.",stages:[
["🌱","Bilowga","Abuurka si siman u qoy oo cawska si tartiib ah uga saar.","Waraab khafiif ah","Compost bisil","Ha ku badin nitrogen"],
["🌿","Koritaan","Khafiifi geedaha si xididdadu u helaan meel.","Qoyaan joogto ah","Nafaqo dheellitiran","Ka ilaali cayayaanka ciidda"],
["🥕","Qaangaar","Marka xididku gaaro cabbirka la rabo, diyaari goosashada.","Ha qallajin ciidda","Ha ku badin nitrogen","Ka saar ciidda oo si fiican u kaydi"]]}
];

const fertilizers=[
["🧪","NPK 15-15-15","Bacriminta isku-dheellitiran ee N, P iyo K. Qiyaasta ku salee ciidda iyo dalagga."],
["🌿","Compost","Walxo dabiici ah oo bisil; waxay hagaajisaa qaab-dhismeedka ciidda iyo haynta qoyaanka."],
["🐄","Digada xoolaha","Isticmaal digada si fiican u bislaatay; digada cusub waxay dhaawici kartaa xididdada."],
["💧","Urea 46% N","Nitrogen badan; ha lagu isticmaalin indho la'aan. Qiyaasta iyo waqtigu waa muhiim."],
["🌱","DAP 18-46-0","Waxay bixisaa nitrogen iyo phosphorus; ciidda iyo dalagga ku salee isticmaalka."],
["🥔","Potassium","Waxay muhiim u noqon kartaa tayada iyo buuxinta miraha/tubers-ka, gaar ahaan marxaladaha dambe."]];

function esc(s){return s.replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[m]))}
function setActive(p){document.querySelectorAll('.bottom-nav button').forEach(b=>b.classList.toggle('active',b.dataset.page===p))}
function showPage(page){
  setActive(page);
  const main=document.getElementById('main');
  if(page==='home') main.innerHTML=home();
  else if(page==='crops') main.innerHTML=cropsPage();
  else if(page==='fertilizer') main.innerHTML=fertilizerPage();
  else if(page==='calendar') main.innerHTML=calendarPage();
  else if(page==='settings') main.innerHTML=settingsPage();
  window.scrollTo({top:0,behavior:'smooth'});
}
function home(){
 return `<section class="hero"><h1>Beeraha Waa Nolol 🌱</h1><p>Baro sida geed kasta loo xanaaneeyo laga bilaabo geed yar ilaa uu qaangaaro oo miro bixiyo.</p></section>
 <div class="search">🔎 <input oninput="filterHome(this.value)" placeholder="Raadi geed, dalag ama bacrimin..."></div>
 <div class="stats"><div class="stat"><b>${crops.length}</b><span>Geedo & dalagyo</span></div><div class="stat"><b>${fertilizers.length}</b><span>Bacrimin</span></div><div class="stat"><b>3</b><span>Marxalado</span></div></div>
 <section class="section"><div class="sectionhead"><h2>Geedaha & Dalagyada</h2><button class="back" onclick="showPage('crops')">Dhammaan →</button></div><div id="homeGrid" class="grid">${cropCards(crops.slice(0,6))}</div></section>
 <section class="section"><div class="sectionhead"><h2>Baro maanta</h2></div><div class="list">
 <div class="row" onclick="showPage('fertilizer')"><div class="round">🧪</div><div><strong>Bacriminta si sax ah u baro</strong><small>NPK, Urea, DAP, compost iyo digada.</small></div></div>
 <div class="row" onclick="showPage('calendar')"><div class="round">📅</div><div><strong>Jadwalka daryeelka</strong><small>Qorshee waraab, nafaqo iyo hawlaha beeraha.</small></div></div>
 </div></section>
 <a class="cta" href="https://wa.me/252684411459?text=Salaan%20Beeraley%20Pro%2C%20waxaan%20rabaa%20caawimaad%20beeraha." target="_blank">💬 WhatsApp nagala soo xiriir — 0684411459</a>
 <div class="footer">Beeraley Pro • Talooyin guud oo beeraha ah. Qiyaasta bacriminta/pesticide-ka ku salee ciidda, dalagga iyo talada khabiirka deegaanka.</div>`;
}
function cropCards(arr){return arr.map(c=>`<article class="card crop-card" onclick="cropDetail('${encodeURIComponent(c.name)}')"><div class="crop-icon">${c.icon}</div><h3>${esc(c.name)}</h3><p>${esc(c.summary)}</p><span class="pill">${esc(c.type)}</span></article>`).join('')}
function cropsPage(){
 return `<div class="section"><div class="sectionhead"><h2>🌿 Geedaha & Dalagyada</h2><span class="muted">${crops.length} nooc</span></div></div>
 <div class="search">🔎 <input id="cropSearch" oninput="filterCrops(this.value)" placeholder="Raadi: Liin, Moos, Basal..."></div>
 <div id="cropGrid" class="grid section">${cropCards(crops)}</div>`;
}
function filterCrops(q){const x=q.toLowerCase().trim();document.getElementById('cropGrid').innerHTML=cropCards(crops.filter(c=>(c.name+c.summary+c.type).toLowerCase().includes(x)))||'<div class="empty wide">Wax natiijo ah lama helin.</div>'}
function filterHome(q){const x=q.toLowerCase().trim();document.getElementById('homeGrid').innerHTML=cropCards(crops.filter(c=>(c.name+c.summary+c.type).toLowerCase().includes(x)).slice(0,10))||'<div class="empty wide">Wax natiijo ah lama helin.</div>'}
function cropDetail(encoded){
 const c=crops.find(x=>x.name===decodeURIComponent(encoded)); if(!c)return;
 const visual = {
  "Liin":"linear-gradient(135deg,#dff8e8,#fff4a8)",
  "Moos":"linear-gradient(135deg,#fff5bd,#e4f7cf)",
  "Basal":"linear-gradient(135deg,#f7e5ed,#f7f0ff)",
  "Timir":"linear-gradient(135deg,#e6f5df,#d8f0ff)",
  "Yaanyo":"linear-gradient(135deg,#ffe0d8,#fff4cf)",
  "Galley":"linear-gradient(135deg,#fff0b5,#e7f6c8)",
  "Sisin":"linear-gradient(135deg,#eee8d4,#e9f5df)",
  "Qajaar":"linear-gradient(135deg,#d8f6df,#e2f7b9)",
  "Qaraha":"linear-gradient(135deg,#ffe0e0,#dff4d9)",
  "Baradho":"linear-gradient(135deg,#eadbc4,#fff0cf)",
  "Basbaas":"linear-gradient(135deg,#ffd6cc,#ffe8a8)",
  "Cambe":"linear-gradient(135deg,#ffe6ad,#dff4c7)",
  "Avokado":"linear-gradient(135deg,#d8f1cf,#f1f7d8)",
  "Papaya":"linear-gradient(135deg,#ffdcb9,#fff1bd)",
  "Karootada":"linear-gradient(135deg,#ffe0b9,#e6f6d7)"
 }[c.name] || "linear-gradient(135deg,#dff5e9,#eef8f3)";
 document.getElementById('main').innerHTML=`<button class="back" onclick="showPage('crops')">← Ku noqo geedaha</button>
 <div class="detail-hero" style="background:${visual}">
   <div class="plant-visual"><span>${c.icon}</span><i>🌱</i><i>💧</i><i>☀️</i></div>
   <div class="detail-icon">${c.icon}</div><h1>${esc(c.name)}</h1><div class="muted">${esc(c.type)}</div>
   <p>${esc(c.summary)}</p>
   <div class="quick-badges"><span>☀️ Qorrax</span><span>💧 Waraab</span><span>🧪 Nafaqo</span></div>
 </div>
 ${c.stages.map((s,i)=>`<section class="stage"><div class="stage-head"><div class="stage-num">${i+1}</div><h3>${s[0]} ${esc(s[1])}</h3></div><div class="stage-body"><p>${esc(s[2])}</p>${s.slice(3).map(v=>`<div class="check"><b>✓</b><span>${esc(v)}</span></div>`).join('')}</div></section>`).join('')}
 <div class="notice">⚠️ Talooyinkani waa hagitaan guud. Bacriminta kiimikada ama daawooyinka cayayaanka ha ku qiyaasin magaca oo keliya; raac calaamadda alaabta, xaaladda ciidda iyo talada khabiir beeraha.</div>
 <a class="cta" href="https://wa.me/252684411459?text=Salaan%2C%20waxaan%20rabaa%20talo%20ku%20saabsan%20${encodeURIComponent(c.name)}." target="_blank">💬 Talo ku saabsan ${esc(c.name)} — WhatsApp</a>`;
 setActive('crops'); window.scrollTo(0,0);
}
function fertilizerPage(){
 return `<div class="section"><div class="sectionhead"><h2>🧪 Bacriminta</h2></div><p class="muted">Baro waxa ay bacrimintu qabato iyo sida si masuuliyad leh loo isticmaalo.</p></div>
 <div class="list section">${fertilizers.map(f=>`<div class="row"><div class="round">${f[0]}</div><div><strong>${f[1]}</strong><small>${f[2]}</small></div></div>`).join('')}</div>
 <div class="notice">💡 Talo: Haddii ay suurtagal tahay, samee baaritaanka ciidda. Nafaqada saxda ahi waxay ku xiran tahay ciidda, nooca dalagga iyo marxaladda koritaanka.</div>
 <a class="cta" href="https://wa.me/252684411459?text=Salaan%2C%20waxaan%20rabaa%20talo%20bacrimin." target="_blank">💬 Weydii talo bacrimin</a>`;
}
function calendarPage(){
 return `<div class="section"><div class="sectionhead"><h2>📅 Jadwalka beeraha</h2></div></div>
 <div class="tabs"><button class="active">Bilowga</button><button>Koritaanka</button><button>Qaangaar</button></div>
 <div class="list section">
 <div class="row"><div class="round">💧</div><div><strong>Waraab</strong><small>Hubi qoyaanka ciidda, roobka iyo nooca dalagga ka hor waraabinta.</small></div></div>
 <div class="row"><div class="round">🌱</div><div><strong>Caws & nadiifin</strong><small>Cawska si joogto ah uga saar agagaarka geedaha si uusan ula tartamin nafaqada.</small></div></div>
 <div class="row"><div class="round">🧪</div><div><strong>Nafaqo</strong><small>Ku xisaabtan marxaladda geedka; ha ku darin bacrimin badan hal mar.</small></div></div>
 <div class="row"><div class="round">🔍</div><div><strong>Kormeer</strong><small>Usbuuc kasta fiiri caleemo, jirid, xidid iyo miraha si calaamadaha cudur/cayayaan loo qabto goor hore.</small></div></div>
 </div>`;
}
function settingsPage(){
 return `<section class="section"><div class="sectionhead"><h2>☰ Menu & Dejinta</h2></div>
 <div class="list">
 <div class="row" onclick="showPage('crops')"><div class="round">🌿</div><div><strong>Geedaha & Dalagyada</strong><small>Faahfaahinta geed kasta iyo 3-da marxaladood.</small></div></div>
 <div class="row" onclick="showPage('fertilizer')"><div class="round">🧪</div><div><strong>Bacriminta</strong><small>Baro NPK, Urea, DAP, compost iyo digada.</small></div></div>
 <div class="row"><div class="round">🌤️</div><div><strong>Cimilada</strong><small>Qaybtan waxaa lagu xiriirin karaa API cimilo online ah marka magaalada la doorto.</small></div></div>
 <div class="row"><div class="round">💰</div><div><strong>Suuqa</strong><small>Meel loogu talagalay qiimaha dalagyada marka xog online ah lagu xiro.</small></div></div>
 </div>
 <a class="cta" href="https://wa.me/252684411459?text=Salaan%20Beeraley%20Pro%2C%20waxaan%20rabaa%20caawimaad." target="_blank">💬 Nala soo xiriir WhatsApp<br><small>0684411459</small></a>
 <div class="footer">Nooca app-ka: Beeraley Pro Modern • 2026</div></section>`;
}
showPage('home');
