let posts=[],currentCat="ټول",myProfile=null,myRole=null,editingId=null,owner=false;
const LS="dz_profile_v3",CACHE="dz_posts_cache_v3";
function ssGet(k,d=null){try{const v=localStorage.getItem(k);return v===null?d:v}catch(e){return d}}
function ssSet(k,v){try{localStorage.setItem(k,v)}catch(e){}}
function hideSplash(){const s=document.getElementById("splash");if(s)s.classList.add("hidden")}
setTimeout(hideSplash,1600);
function showError(msg){const b=document.getElementById("postsList");if(b)b.innerHTML=`<div class="notice">${esc(msg)}</div>`}
window.addEventListener("error",e=>{if(document.getElementById("posts")?.classList.contains("active"))showError("د مطالبو د پاڼې ستونزه: "+(e.message||"ناڅرګنده ستونزه"))});

document.addEventListener("DOMContentLoaded",async()=>{
  try{
    const first=(location.hash||"#home").slice(1);
    history.replaceState({page:document.getElementById(first)?first:"home"},"", "#"+(document.getElementById(first)?first:"home"));
  }catch(e){}
  historyReady=true;
  showPage((location.hash||"#home").slice(1),false);
  loadLocalProfile();updateStatus();
  try{const raw=JSON.parse(ssGet(CACHE,"[]"));renderPosts(Array.isArray(raw)?raw:[])}catch(e){renderPosts([])}
  document.getElementById("profileGallery")?.addEventListener("change",previewPhoto);
  document.getElementById("profileCamera")?.addEventListener("change",previewPhoto);
  document.getElementById("adminGallery")?.addEventListener("change",()=>{});
  document.getElementById("adminCamera")?.addEventListener("change",()=>{});
  document.getElementById("adminTextFile")?.addEventListener("change",readPostTextFile);
  document.addEventListener("contextmenu",e=>{if(!e.target.closest("input,textarea,select,[contenteditable=\"true\"]"))e.preventDefault();});
  try{await initSupabase();if(supabaseReady){await loadProfile();await refreshPosts();await detectAdmin()}}catch(e){console.warn(e)}
  updateStatus();
});
window.addEventListener("online",async()=>{updateStatus();if(supabaseReady){await refreshPosts();await detectAdmin()}});window.addEventListener("offline",updateStatus);
let currentPage="home";
let historyReady=false;
function showPage(id,push=true){
  const allowed={home:1,posts:1,about:1,profile:1,admin:1};
  if(!allowed[id]) id="home";
  try{
    const pages=document.querySelectorAll(".page");
    pages.forEach(p=>{p.classList.remove("active");p.style.removeProperty("display");});
    const el=document.getElementById(id);
    if(!el) return false;
    el.classList.add("active");
    currentPage=id;
    const names={home:"اصلي مینو",posts:"مطالب",about:"زموږ په اړه",profile:"زما حساب",admin:"اډمین"};
    const t=document.getElementById("pageTitle");
    if(t)t.textContent=names[id]||"";
    if(push && historyReady){try{history.pushState({page:id},"", "#"+id)}catch(e){}}
    try{window.scrollTo(0,0)}catch(e){}
    if(id==="posts") updateStatus();
    return true;
  }catch(e){
    console.error("showPage",e);
    return false;
  }
}
function goHome(){showPage("home",true)}
function appBack(){
  if(currentPage!=="home"){
    showPage("home",false);
    try{history.replaceState({page:"home"},"","#home")}catch(e){}
    return;
  }
  if(confirm("له اپلیکیشن څخه ووځئ؟")){
    try{window.close()}catch(e){}
  }
}
window.addEventListener("popstate",()=>{
  const id=(location.hash||"#home").slice(1);
  showPage(document.getElementById(id)?id:"home",false);
});
function updateStatus(){const x=document.getElementById("onlineStatus");if(x)x.textContent=navigator.onLine?"":"📡 تاسو له انټرنېټ سره وصل نه یاست"}
function showToast(msg,goHomeAfter=0){let t=document.getElementById("dzToast");if(!t){t=document.createElement("div");t.id="dzToast";document.body.appendChild(t)}t.className="toast";t.textContent=msg;if(goHomeAfter){setTimeout(()=>{t.remove();goHome()},goHomeAfter)}}
function openPosts(){
  try{
    loadLocalProfile();
    showPage("posts");
    updateStatus();
    const b=document.getElementById("postsList");
    if(!navigator.onLine){
      if(b)b.innerHTML="<div class='notice'>📡 تاسو له انټرنېټ سره وصل نه یاست</div>";
      renderPosts(Array.isArray(posts)?posts:[]);
      return;
    }
    if(!myProfile?.name||!myProfile?.photo){
      showPage("profile");
      const m=document.getElementById("profileMsg");
      if(m)m.textContent="لومړی خپل نوم او انځور ثبت کړئ، بیا مطالبو ته داخل شئ.";
      return;
    }
    // First render the local cache so the WebView never waits on Supabase.
    const cached=Array.isArray(posts)?posts:[];
    renderPosts(cached);
    if(b && !cached.length)b.innerHTML="<div class='notice'>⏳ آنلاین مطالب لوډ کېږي...</div>";
    // Load the network data only after the page has painted.
    setTimeout(()=>{try{refreshPosts()}catch(e){showError("د آنلاین مطالبو په لوډ کې ستونزه راغله.")}},150);
  }catch(e){
    showPage("posts");
    showError("د مطالبو پاڼه ونه پرانیستل شوه.");
  }
}
function loadLocalProfile(){try{myProfile=JSON.parse(ssGet(LS,"null"))}catch(e){myProfile=null}if(myProfile){const n=document.getElementById("profileName"),p=document.getElementById("photoPreview");if(n)n.value=myProfile.name||"";if(p)p.innerHTML=myProfile.photo?`<img src="${myProfile.photo}">`:""}}
function previewPhoto(){const f=this.files?.[0];if(!f)return;compressImage(f,900,350*1024).then(data=>{myProfile=myProfile||{};myProfile.photo=data;const p=document.getElementById("photoPreview");if(p)p.innerHTML=`<img src="${data}">`}).catch(()=>{const m=document.getElementById("profileMsg");if(m)m.textContent="انځور لوستل کېدای نه شي."})}
async function saveProfile(){const name=(document.getElementById("profileName")?.value||"").trim();if(!name){document.getElementById("profileMsg").textContent="نوم ولیکئ.";return}if(!myProfile?.photo){document.getElementById("profileMsg").textContent="انځور هم وټاکئ.";return}myProfile=myProfile||{};myProfile.name=name;ssSet(LS,JSON.stringify(myProfile));let saved=true;if(supabaseReady&&me){try{const {error}=await supabaseClient.from("profiles").upsert({id:me.id,name,photo:myProfile.photo||"",updated_at:new Date().toISOString()});if(error)throw error}catch(e){saved=false;console.warn(e)}}if(saved){showToast("✅ ستاسې نوم او انځور په بریالیتوب سره خوندي شول.",1200)}else{document.getElementById("profileMsg").textContent="⚠️ په موبایل کې خوندي شول، خو آنلاین حساب ته ونه لېږل شول."}}
async function loadProfile(){if(!supabaseReady||!me)return;try{const {data,error}=await supabaseClient.from("profiles").select("name,photo").eq("id",me.id).maybeSingle();if(error)throw error;if(data){myProfile={...(myProfile||{}),...data};ssSet(LS,JSON.stringify(myProfile));loadLocalProfile()}}catch(e){console.warn(e)}}
async function refreshPosts(){
  if(!supabaseReady||!navigator.onLine){renderPosts(posts);return}
  try{
    const result=await Promise.race([
      supabaseClient.from("posts").select("id,title,category,content,image,views,likes,created_at").order("created_at",{ascending:false}).limit(100),
      new Promise((_,reject)=>setTimeout(()=>reject(new Error("TIMEOUT")),10000))
    ]);
    const {data,error}=result;
    if(error)throw error;
    const rows=Array.isArray(data)?data:[];
    const ids=rows.map(p=>p.id);
    let counts={};
    if(ids.length){
      try{
        const {data:cs,error:ce}=await Promise.race([
          supabaseClient.from("comments").select("post_id").in("post_id",ids),
          new Promise((_,reject)=>setTimeout(()=>reject(new Error("TIMEOUT")),5000))
        ]);
        if(!ce)(cs||[]).forEach(c=>counts[c.post_id]=(counts[c.post_id]||0)+1);
      }catch(e){}
    }
    posts=rows.map(p=>({...p,cat:p.category,text:p.content,commentCount:counts[p.id]||0}));
    ssSet(CACHE,JSON.stringify(posts));
    renderPosts(posts);
  }catch(e){
    renderPosts(posts);
    const x=document.getElementById("onlineStatus");
    if(x)x.textContent=(e?.message==="TIMEOUT")?"📡 آنلاین خدمت ځنډېدلی؛ مهرباني بیا هڅه وکړئ.":sErr(e);
  }
}
function filterPosts(c){currentCat=c;renderPosts(posts)}
function renderPosts(all){try{const box=document.getElementById("postsList");if(!box)return;const arr=Array.isArray(all)?all:[];const list=arr.filter(p=>p&& (currentCat==="ټول"||p.category===currentCat||p.cat===currentCat));if(!list.length){box.innerHTML="<div class='notice'>تر اوسه مطلب نشته.</div>";return}box.innerHTML=list.map(p=>postHtml(p)).join("")}catch(e){showError("د مطالبو په ښودلو کې ستونزه راغله.")}}
function postHtml(p){const img=p.image?`<img class="post-img" src="${esc(p.image)}">`:"";return `<article class="post"><h3>${esc(p.title||"")}</h3>${img}<p>${esc(p.content??p.text??"").replace(/\n/g,"<br>")}</p><div class="meta"><span>🏷️ ${esc(p.category??p.cat??"")}</span><span>👁️ ${Number(p.views)||0}</span><span>❤️ ${Number(p.likes)||0}</span><span>💬 ${Number(p.commentCount)||0}</span></div><div class="actions"><button onclick="likePost(${Number(p.id)})">❤️ لایک</button><button onclick="addView(${Number(p.id)})">👁️ لیدل</button><button onclick="toggleComments(${Number(p.id)})">💬 کمینټ</button></div><div id="comments-${Number(p.id)}" class="comments" style="display:none"><div id="commentList-${Number(p.id)}"></div><textarea id="commentText-${Number(p.id)}" rows="2" placeholder="خپل نظر ولیکئ..."></textarea><button class="primary" onclick="sendComment(${Number(p.id)})">نظر لېږل</button></div></article>`}
async function addView(id){if(!supabaseReady||!me||!navigator.onLine)return;try{const {error}=await supabaseClient.rpc("increment_post_view",{p_post_id:id});if(error)throw error;const p=posts.find(x=>Number(x.id)===Number(id));if(p)p.views=(Number(p.views)||0)+1;renderPosts(posts)}catch(e){}}
async function likePost(id){if(!supabaseReady||!me||!navigator.onLine)return;try{const {data,error}=await supabaseClient.rpc("toggle_post_like",{p_post_id:id});if(error)throw error;const p=posts.find(x=>Number(x.id)===Number(id));if(p)p.likes=Math.max(0,Number(p.likes||0)+(data?.liked?1:-1));renderPosts(posts)}catch(e){alert(sErr(e))}}
async function toggleComments(id){const el=document.getElementById("comments-"+id);if(!el)return;el.style.display=el.style.display==="none"?"block":"none";if(el.style.display==="block")loadComments(id)}
async function loadComments(id){const box=document.getElementById("commentList-"+id);if(!box)return;if(!supabaseReady||!navigator.onLine){box.innerHTML="<div class='notice'>د کمینټ لپاره انټرنېټ اړین دی.</div>";return}try{const {data,error}=await supabaseClient.from("comments").select("user_name,text,created_at").eq("post_id",id).order("created_at",{ascending:true});if(error)throw error;box.innerHTML=(data||[]).map(c=>`<div class="comment"><b>${esc(c.user_name||"کاروونکی")}</b><p>${esc(c.text||"")}</p></div>`).join("")||"<p class='muted'>تر اوسه کمینټ نشته.</p>"}catch(e){box.textContent=sErr(e)}}
async function sendComment(id){const el=document.getElementById("commentText-"+id),t=el?.value.trim();if(!t||!supabaseReady||!me||!navigator.onLine)return;try{const {error}=await supabaseClient.from("comments").insert({post_id:id,user_id:me.id,user_name:myProfile?.name||"کاروونکی",text:t});if(error)throw error;el.value="";const p=posts.find(x=>Number(x.id)===Number(id));if(p)p.commentCount=(p.commentCount||0)+1;renderPosts(posts);document.getElementById("comments-"+id).style.display="block";loadComments(id)}catch(e){alert(sErr(e))}}
async function openAdmin(){showPage("admin");document.getElementById("adminGate").style.display="block";document.getElementById("adminPanel").style.display="none";if(supabaseReady)await detectAdmin()}
async function detectAdmin(){if(!me)return;try{const {data,error}=await supabaseClient.from("admins").select("role,enabled").eq("id",me.id).maybeSingle();if(error)throw error;if(data?.enabled){myRole=data.role||"editor";owner=myRole==="owner";document.getElementById("adminGate").style.display="none";document.getElementById("adminPanel").style.display="block";document.getElementById("ownerTab").style.display=owner?"block":"none";document.getElementById("adminStatsFields").style.display=owner?"block":"none";loadAdminPosts();if(owner)loadInvites()}else{myRole=null;owner=false;document.getElementById("adminGate").style.display="block";document.getElementById("adminPanel").style.display="none"}}catch(e){console.warn(e)}}
async function claimFirstOwner(){const code=(document.getElementById("ownerCode")?.value||"").trim();if(!/^\d{6}$/.test(code)){document.getElementById("adminMsg").textContent="د لومړي اډمین ۶ رقمي کوډ سم ولیکئ.";return}if(!supabaseReady||!me){document.getElementById("adminMsg").textContent="انټرنېټ ته وصل شئ.";return}try{const {data,error}=await supabaseClient.rpc("claim_first_owner",{p_code:code});if(error)throw error;if(data?.success){showToast("✅ لومړی اصلي اډمین په بریالیتوب سره جوړ شو.",1200);await detectAdmin()}else document.getElementById("adminMsg").textContent=data?.message||"کوډ ناسم دی یا لومړی اډمین مخکې جوړ شوی."}catch(e){document.getElementById("adminMsg").textContent=sErr(e)}}
async function loginVirtualAdmin(){const password=(document.getElementById("virtualAdminPassword")?.value||"");if(!password){document.getElementById("adminMsg").textContent="د مجازي اډمین پاسورډ ولیکئ.";return}if(!supabaseReady||!me){document.getElementById("adminMsg").textContent="انټرنېټ ته وصل شئ.";return}try{const {data,error}=await supabaseClient.rpc("login_virtual_admin",{p_password:password});if(error)throw error;if(data?.success){document.getElementById("virtualAdminPassword").value="";showToast("✅ مجازي اډمین په بریالیتوب سره فعال شو.",1200);await detectAdmin()}else document.getElementById("adminMsg").textContent=data?.message||"پاسورډ ناسم دی."}catch(e){document.getElementById("adminMsg").textContent=sErr(e)}}
async function redeemAdminCode(){document.getElementById("adminMsg").textContent="د اډمین لپاره اوس د مجازي اډمین پاسورډ وکاروئ."}
function showAdminTab(x){["new","manage","admins"].forEach(k=>{const el=document.getElementById("admin"+(k==="new"?"New":k==="manage"?"Manage":"Admins"));if(el)el.style.display=k===x?"block":"none"})}
async function savePost(){if(!myRole||!supabaseReady||!me)return;const title=document.getElementById("adminTitle").value.trim(),text=document.getElementById("adminText").value.trim(),cat=document.getElementById("adminCat").value;if(!title||!text){document.getElementById("postMsg").textContent="سرلیک او مطلب ولیکئ.";return}const imageFile=document.getElementById("adminGallery")?.files?.[0]||document.getElementById("adminCamera")?.files?.[0];const save=async(image)=>{const views=owner?Math.max(0,Number(document.getElementById("adminViews").value)||0):0,likes=owner?Math.max(0,Number(document.getElementById("adminLikes").value)||0):0;const row={title,category:cat,content:text,image:image||"",views,likes,created_by:me.id};try{let result;if(editingId)result=await supabaseClient.from("posts").update({...row,updated_at:new Date().toISOString()}).eq("id",editingId);else result=await supabaseClient.from("posts").insert(row);if(result.error)throw result.error;editingId=null;clearPostForm();await refreshPosts();loadAdminPosts();showToast("✅ مطلب په بریالیتوب سره خپور شو.",1200)}catch(e){document.getElementById("postMsg").textContent=sErr(e)}};if(imageFile)compressImage(imageFile,1200,450*1024).then(save).catch(()=>save(""));else save("")}
function readPostTextFile(){const f=this.files?.[0];if(!f)return;const r=new FileReader();r.onload=()=>{const t=document.getElementById("adminText");if(t)t.value=String(r.result||"");document.getElementById("postMsg").textContent="✅ د فایل متن راوړل شو. اوس پوسټ خپرول کېکاږئ."};r.onerror=()=>{document.getElementById("postMsg").textContent="فایل لوستل کېدای نه شي."};r.readAsText(f,"UTF-8")}
function clearPostForm(){["adminTitle","adminText"].forEach(id=>{const e=document.getElementById(id);if(e)e.value=""});["adminGallery","adminCamera"].forEach(id=>{const e=document.getElementById(id);if(e)e.value=""});const v=document.getElementById("adminViews"),l=document.getElementById("adminLikes");if(v)v.value=0;if(l)l.value=0}
async function loadAdminPosts(){if(!supabaseReady||!myRole)return;try{const {data,error}=await supabaseClient.from("posts").select("id,title,category,views,likes,created_at").order("created_at",{ascending:false}).limit(100);if(error)throw error;document.getElementById("adminList").innerHTML=(data||[]).map(p=>`<div class="admin-item"><b>${esc(p.title||"")}</b><small>${esc(p.category||"")} · 👁️ ${p.views||0} · ❤️ ${p.likes||0}</small><div>${owner?`<button onclick="editPost(${p.id})">✏️ ایډیټ</button><button onclick="deletePost(${p.id})">🗑️ ډیلټ</button><button onclick="setStats(${p.id},${Number(p.views)||0},${Number(p.likes)||0})">📊 شمېرې</button>`:"<small>یوازې د پوسټ جوړولو اجازه</small>"}</div></div>`).join("")||"<p>پوسټ نشته.</p>"}catch(e){document.getElementById("adminList").textContent=sErr(e)}}
async function editPost(id){if(!owner)return;const {data,error}=await supabaseClient.from("posts").select("*").eq("id",id).single();if(error||!data)return;editingId=id;document.getElementById("adminTitle").value=data.title||"";document.getElementById("adminCat").value=data.category||"ټوکې";document.getElementById("adminText").value=data.content||"";document.getElementById("adminViews").value=data.views||0;document.getElementById("adminLikes").value=data.likes||0;showAdminTab("new")}
async function deletePost(id){if(!owner)return;if(!confirm("دا پوسټ ډیلټ شي؟"))return;try{const {error}=await supabaseClient.from("posts").delete().eq("id",id);if(error)throw error;await refreshPosts();loadAdminPosts()}catch(e){alert(sErr(e))}}
async function setStats(id,v,l){if(!owner)return;const nv=prompt("د لیدنو نوی شمېر:",v);if(nv===null)return;const nl=prompt("د لایکونو نوی شمېر:",l);if(nl===null)return;try{const {error}=await supabaseClient.from("posts").update({views:Math.max(0,Number(nv)||0),likes:Math.max(0,Number(nl)||0),updated_at:new Date().toISOString()}).eq("id",id);if(error)throw error;await refreshPosts();loadAdminPosts()}catch(e){alert(sErr(e))}}
async function createInvite(){if(!owner)return;const code=document.getElementById("newInviteCode").value.trim();if(!/^\d{6}$/.test(code)){alert("۶ رقمي کوډ ولیکئ.");return}try{const {error}=await supabaseClient.from("admin_codes").insert({code,created_by:me.id,enabled:true});if(error)throw error;document.getElementById("newInviteCode").value="";loadInvites()}catch(e){alert(sErr(e))}}
async function loadInvites(){if(!owner)return;try{const {data,error}=await supabaseClient.from("admin_codes").select("code,enabled,created_at").order("created_at",{ascending:false});if(error)throw error;document.getElementById("inviteList").innerHTML=(data||[]).map(d=>`<div class="admin-item"><b>کوډ: ${esc(d.code)}</b><small>${d.enabled?"فعال":"کارول شوی"}</small></div>`).join("")||"<p>تر اوسه کوډ نشته.</p>"}catch(e){}}
function compressImage(file,maxSide,maxBytes){return new Promise((resolve,reject)=>{const r=new FileReader();r.onload=()=>{const im=new Image();im.onload=()=>{let w=im.width,h=im.height,scale=Math.min(1,maxSide/Math.max(w,h));w=Math.round(w*scale);h=Math.round(h*scale);const c=document.createElement("canvas");c.width=w;c.height=h;const ctx=c.getContext("2d");ctx.drawImage(im,0,0,w,h);let q=.82,data=c.toDataURL("image/jpeg",q);while(data.length>maxBytes*1.37&&q>.35){q-=.07;data=c.toDataURL("image/jpeg",q)}resolve(data)};im.onerror=reject;im.src=r.result};r.onerror=reject;r.readAsDataURL(file)})}
function esc(s){return String(s??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;","\"":"&quot;","'":"&#39;"}[c]))}
function exitApp(){alert("د اپ د بندولو لپاره د موبایل Back تڼۍ وکاروئ.")}
