(function () {
  "use strict";

  function showFriendlyError(message) {
    var result = document.getElementById("testResult");
    if (!result) return;
    result.hidden = false;
    result.textContent = "⚠️ " + message;
  }

  function initializeApp() {
    var button = document.getElementById("testButton");
    var result = document.getElementById("testResult");

    if (!button || !result) {
      console.error("ArquivoParaAPK: elementos principais não foram encontrados.");
      return;
    }

    button.addEventListener("click", function () {
      try {
        result.hidden = false;
        result.textContent = "✅ Aplicativo funcionando corretamente.";
        button.setAttribute("aria-label", "Aplicativo testado com sucesso");
      } catch (error) {
        console.error("ArquivoParaAPK:", error);
        showFriendlyError("Não foi possível concluir o teste.");
      }
    });
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", initializeApp);
  } else {
    initializeApp();
  }
})();
