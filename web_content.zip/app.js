import { firebaseConfig } from "./firebase-config.js";
import { initializeApp } from "https://www.gstatic.com/firebasejs/12.0.0/firebase-app.js";
import {
  getAuth, onAuthStateChanged, signInWithEmailAndPassword, createUserWithEmailAndPassword,
  GoogleAuthProvider, signInWithPopup, signOut, RecaptchaVerifier, signInWithPhoneNumber
} from "https://www.gstatic.com/firebasejs/12.0.0/firebase-auth.js";
import {
  getFirestore, collection, addDoc, query, where, orderBy, getDocs, serverTimestamp
} from "https://www.gstatic.com/firebasejs/12.0.0/firebase-firestore.js";

const configured = !firebaseConfig.apiKey.startsWith("YOUR_");
const auth = configured ? getAuth(initializeApp(firebaseConfig)) : null;
const db = configured ? getFirestore(auth.app) : null;

const $ = id => document.getElementById(id);
let registerMode = false, currentUser = null, confirmation = null, recaptcha = null;

function status(msg){ $("status").textContent = msg; }
function securityStatus(msg){ $("securityStatus").textContent = msg; }

$("toggle").onclick=()=>{registerMode=!registerMode;$("authTitle").textContent=registerMode?"Create your Mail account":"Welcome to Mail";$("emailBtn").textContent=registerMode?"Create account":"Sign in";$("toggle").textContent=registerMode?"Already have an account? Sign in":"Create an account";};

$("emailBtn").onclick=async()=>{
  if(!configured){status("Firebase is not configured yet. Add your Firebase settings first.");return;}
  try{
    const e=$("email").value.trim(), p=$("password").value;
    currentUser=registerMode? (await createUserWithEmailAndPassword(auth,e,p)).user : (await signInWithEmailAndPassword(auth,e,p)).user;
    if(registerMode) await addDoc(collection(db,"securityEvents"),{type:"account_created",uid:currentUser.uid,email:currentUser.email,createdAt:serverTimestamp()});
  }catch(err){status(err.message)}
};

$("googleBtn").onclick=async()=>{
  if(!configured){status("Firebase is not configured yet.");return;}
  try{const r=await signInWithPopup(auth,new GoogleAuthProvider());currentUser=r.user;await addDoc(collection(db,"securityEvents"),{type:"google_signin",uid:currentUser.uid,email:currentUser.email,createdAt:serverTimestamp()});}
  catch(err){status(err.message)}
};
$("logout").onclick=()=>auth&&signOut(auth);

onAuthStateChanged(auth,user=>{
  currentUser=user;
  if(user){$("auth").classList.add("hidden");$("app").classList.remove("hidden");$("logout").classList.remove("hidden");loadFolder("Inbox");}
  else {$("auth").classList.remove("hidden");$("app").classList.add("hidden");$("logout").classList.add("hidden");}
});

async function loadFolder(folder){
  $("folderTitle").textContent=folder;
  const box=$("messages"); box.innerHTML="";
  if(!configured){box.innerHTML='<div class="message">Configure Firebase to load real messages.</div>';return;}
  try{
    const q=query(collection(db,"messages"),where("folder","==",folder),where("uid","==",currentUser.uid),orderBy("createdAt","desc"));
    const snap=await getDocs(q);
    if(snap.empty){box.innerHTML='<div class="message">No messages yet.</div>';return;}
    snap.forEach(d=>{const m=d.data();box.innerHTML+=`<div class="message"><b>${escapeHtml(m.subject||"(no subject)")}</b><div>${escapeHtml(m.to||"")}</div><p>${escapeHtml(m.body||"")}</p></div>`});
  }catch(e){box.innerHTML='<div class="message">Messages need a Firestore index/rules setup.</div>'}
}
function escapeHtml(s){return String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[c]));}
document.querySelectorAll("[data-folder]").forEach(b=>b.onclick=()=>loadFolder(b.dataset.folder));
$("refresh").onclick=()=>loadFolder($("folderTitle").textContent);

$("compose").onclick=()=>{$("composeModal").classList.remove("hidden")};
$("closeCompose").onclick=()=>{$("composeModal").classList.add("hidden")};
$("send").onclick=async()=>{
  if(!currentUser){return}
  const msg={uid:currentUser.uid,to:$("to").value.trim(),subject:$("subject").value.trim(),body:$("body").value,folder:"Sent",createdAt:serverTimestamp()};
  try{await addDoc(collection(db,"messages"),msg);$("composeModal").classList.add("hidden");["to","subject","body"].forEach(x=>$(x).value="");loadFolder("Sent")}
  catch(e){alert(e.message)}
};

$("security").onclick=()=>{$("securityModal").classList.remove("hidden")};
$("closeSecurity").onclick=()=>{$("securityModal").classList.add("hidden")};
$("sendOtp").onclick=async()=>{
  if(!configured){securityStatus("Firebase is not configured.");return}
  try{
    if(!recaptcha) recaptcha=new RecaptchaVerifier(auth,"recaptcha",{size:"normal"});
    confirmation=await signInWithPhoneNumber(auth,$("phone").value.trim(),recaptcha);
    $("otp").classList.remove("hidden");$("verifyOtp").classList.remove("hidden");securityStatus("Code sent to your phone.");
  }catch(e){securityStatus(e.message)}
};
$("verifyOtp").onclick=async()=>{
  try{
    await confirmation.confirm($("otp").value.trim());
    await addDoc(collection(db,"securityEvents"),{type:"2fa_phone_verified",uid:currentUser.uid,email:currentUser.email,createdAt:serverTimestamp()});
    securityStatus("Phone verification completed. For production, use Firebase multi-factor authentication to enforce 2FA on every sign-in.");
  }catch(e){securityStatus(e.message)}
};
