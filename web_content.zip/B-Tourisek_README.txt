B-Tourisek Management System — Extended Demo

Owner: الأستاذ محمد موسي
Company: B-Touristic / BTouristic
Location: مصر - الجيزة
Email: mohamed.moussa@btouristic.com
Phones: 01148535084 / 01099091108 / 01010223978
Website: btouristic.com

Demo owner PIN: 012012

This is a self-contained browser prototype. It now includes 24 functional UI modules covering:
Dashboard, AI Command Center, CRM, Bookings, Packages, Hotels & 27 Governorates, Suppliers,
Procurement & Contracts, Fleet, Inventory & Activities, HR & RBAC, Marketing, Leads,
Communications, Satisfaction & Complaints, Quotations, Documents/Vouchers, Calendar & Tasks,
Finance, Accounting/Banks/Cash, Reports, Customer Portal/CMS, Knowledge Base/RAG, Settings/Security.

Important:
- Demo figures and demo hotel/supplier records are placeholders.
- Live hotel availability/prices, GDS/NDC, payments, WhatsApp, maps and production AI require secure backend integrations.
- The demo PIN is intentionally client-side and is NOT suitable for production authentication.
- Production should use server-side authentication, Argon2id/bcrypt, 2FA, RBAC, audit logs, encrypted secrets, backups and HTTPS.
