MEHMETİSTAN — DİJİTAL ÜLKE SİSTEMİ
==================================

Bu bir Play Store uygulaması DEĞİLDİR.
Bu bir APK DEĞİLDİR.
Play Store'de aramayın — orada yoktur ve arama hatası verir.

Bu paket, Mehmetistan Cumhuriyeti'nin resmi dijital devlet portalıdır.
HTML / CSS / JavaScript ile çalışır. İnternet gerektirmez.


NASIL AÇILIR (telefon / tablet)
--------------------------------
1. ZIP dosyasını çıkarın (uzun bas → çıkart).
2. Açılan "Mehmetistan" klasörüne girin.
3. "index.html" dosyasına dokunun.
4. Chrome veya Samsung Internet ile açın.
   (Dosya yöneticisi "Play Store'de aransın mı?" derse HAYIR deyin.
    Bunun yerine: index.html → menü → "Birlikte aç" → Chrome.)


ANA EKRANA EKLEME
-----------------
Chrome ile index.html açıkken:

  • Android Chrome: sağ üst ⋮  →  "Ana ekrana ekle" / "Uygulama yükle"
  • iPad / iPhone Safari: paylaş → "Ana Ekrana Ekle"

Bundan sonra Mehmetistan, diğer uygulamalar gibi ana ekranda durur.
Play Store gerekmez.


BİLGİSAYARDA
------------
index.html dosyasına çift tıklayın. Tarayıcıda açılır.


İÇİNDEKİLER
-----------
Ülke haritası, devlet, şehirler, kanunlar, MTT para, MSK,
uzay programı, tarih, diğer ülkeler, haberler, ekonomi,
Mehmetistan oyunu, projeler, ayarlar.

Tema: koyu / açık
Dil: Türkçe / English


DOSYALAR
--------
index.html
style.css
script.js
manifest.webmanifest
assets/flag/
assets/maps/
assets/icons/

Harita ve ülke verileri yerel dosyalardadır; sunucu gerekmez.


MEHMETİSTAN CUMHURİYETİ
Bir Hilal, Bir Vatan
