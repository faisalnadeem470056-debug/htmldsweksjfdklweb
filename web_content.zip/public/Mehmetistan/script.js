/* Mehmetistan Dijital Ülke Sistemi — local, offline, no store */
(function () {
  "use strict";

  const $ = (s, r = document) => r.querySelector(s);
  const $$ = (s, r = document) => [...r.querySelectorAll(s)];

  const state = {
    lang: localStorage.getItem("mh-lang") || "tr",
    theme: localStorage.getItem("mh-theme") || "dark",
    anim: localStorage.getItem("mh-anim") !== "off",
    notif: localStorage.getItem("mh-notif") !== "off",
    view: "home",
    q: "",
    mapTab: "atlas",
    lawCat: "all",
    selected: null,
    quiz: null,
    high: Number(localStorage.getItem("mh-high") || 0),
    citizen: localStorage.getItem("mh-citizen") || "",
  };

  const tx = (o) => (o && typeof o === "object" ? o[state.lang] || o.tr : o);
  const nfmt = (n) => Number(n).toLocaleString(state.lang === "tr" ? "tr-TR" : "en-US");

  const I = {
    app: { tr: "Mehmetistan", en: "Mehmetistan" },
    sub: { tr: "Dijital Ülke Sistemi", en: "Digital Country System" },
    portal: { tr: "Resmi devlet portalı", en: "Official state portal" },
    motto: { tr: "Bir Hilal, Bir Vatan", en: "One Crescent, One Homeland" },
    back: { tr: "Geri", en: "Back" },
    search: { tr: "Modül, şehir, kanun…", en: "Module, city, law…" },
    pop: { tr: "Nüfus", en: "Population" },
    cap: { tr: "Başkent", en: "Capital" },
    area: { tr: "Yüzölçüm", en: "Area" },
    ally: { tr: "Müttefik", en: "Ally" },
    neutral: { tr: "Tarafsız", en: "Neutral" },
    enemy: { tr: "Düşman", en: "Hostile" },
    unknown: { tr: "Bilinmiyor", en: "Unknown" },
    play: { tr: "İl sınavını başlat", en: "Start province quiz" },
    zipnote: {
      tr: "Bu bir APK değildir. Play Store’de aramayın. Chrome menüsünden Ana ekrana ekle.",
      en: "This is not an APK. Do not search Play Store. Use Chrome: Add to Home Screen.",
    },
  };

  const MODULES = [
    { id: "map", title: { tr: "Ülke Haritası", en: "Country Map" }, blurb: { tr: "İller, başkent, atlas", en: "Provinces, capital, atlas" }, ico: "map", tone: "b" },
    { id: "government", title: { tr: "Devlet", en: "State" }, blurb: { tr: "Başkan, hükümet, kurumlar", en: "President, cabinet, agencies" }, ico: "gov", tone: "g" },
    { id: "cities", title: { tr: "Şehirler", en: "Cities" }, blurb: { tr: "İl merkezleri ve yerleşimler", en: "Capitals and towns" }, ico: "city", tone: "b" },
    { id: "laws", title: { tr: "Kanunlar", en: "Laws" }, blurb: { tr: "Anayasa ve mevzuat", en: "Constitution and statutes" }, ico: "law", tone: "g" },
    { id: "mtt", title: { tr: "MTT Para", en: "MTT Currency" }, blurb: { tr: "Dijital ekonomi", en: "Digital economy" }, ico: "coin", tone: "g" },
    { id: "msk", title: { tr: "MSK", en: "MSK" }, blurb: { tr: "Silahlı kuvvetler", en: "Armed forces" }, ico: "shield", tone: "b" },
    { id: "space", title: { tr: "Uzay Programı", en: "Space Program" }, blurb: { tr: "MUA görevleri", en: "MSA missions" }, ico: "rocket", tone: "b" },
    { id: "history", title: { tr: "Tarih", en: "History" }, blurb: { tr: "Kronoloji", en: "Timeline" }, ico: "book", tone: "g" },
    { id: "world", title: { tr: "Diğer Ülkeler", en: "Other Countries" }, blurb: { tr: "Atlas diplomasisi", en: "Atlas diplomacy" }, ico: "globe", tone: "b" },
    { id: "news", title: { tr: "Haberler", en: "News" }, blurb: { tr: "Resmi bülten", en: "Official bulletin" }, ico: "news", tone: "g" },
    { id: "economy", title: { tr: "Ekonomi", en: "Economy" }, blurb: { tr: "Bütçe ve ticaret", en: "Budget and trade" }, ico: "chart", tone: "g" },
    { id: "game", title: { tr: "Mehmetistan Oyunu", en: "Mehmetistan Game" }, blurb: { tr: "Vatan ve il sınavı", en: "Homeland and quiz" }, ico: "game", tone: "b" },
    { id: "projects", title: { tr: "Projeler", en: "Projects" }, blurb: { tr: "Harita, oyun, kod", en: "Map, game, code" }, ico: "folder", tone: "b" },
    { id: "settings", title: { tr: "Ayarlar", en: "Settings" }, blurb: { tr: "Tema, dil, kurulum", en: "Theme, language, install" }, ico: "gear", tone: "g" },
  ];

  const provinces = [
    { id: "mehmetkent", name: "Mehmetkent", region: { tr: "İç Başkent", en: "Capital Interior" }, pop: 2410000, area: 1840, capital: true, x: 43.4, y: 49.6, d: { tr: "Cumhuriyetin kalbi. Millet Meclisi, Devlet Başkanlığı ve MTT Merkez Bankası burada toplanır.", en: "Heart of the republic. Assembly, Presidency and MTT Central Bank sit here." } },
    { id: "arven", name: "Arven", region: { tr: "Kuzeybatı", en: "Northwest" }, pop: 612000, area: 11400, x: 33.6, y: 32.8, d: { tr: "Üniversite kenti. Arven Akademisi ilk yükseköğretim kurumudur.", en: "University province. Arven Academy is the first higher-education house." } },
    { id: "liora", name: "Liora", region: { tr: "Kuzey", en: "North" }, pop: 538000, area: 13200, x: 41.8, y: 26.6, d: { tr: "Kuzey kıyısının fener ili. Balıkçılık ve gözlemevleri.", en: "Lighthouse province of the north coast." } },
    { id: "velis", name: "Velis", region: { tr: "Kuzeydoğu", en: "Northeast" }, pop: 490000, area: 10800, x: 53.4, y: 32.4, d: { tr: "Talakistan sınırına bakan ticaret kapısı.", en: "Trade gate facing Talakistan." } },
    { id: "taris", name: "Taris", region: { tr: "Kuzey İç", en: "North Interior" }, pop: 705000, area: 9600, x: 40.2, y: 37.8, d: { tr: "Buğday ambarı ve değirmen kuleleri.", en: "Grain store and mill towers." } },
    { id: "melun", name: "Melun", region: { tr: "Kuzey İç", en: "North Interior" }, pop: 890000, area: 8900, x: 46.4, y: 38.0, d: { tr: "Ticaret ve lojistik. Melun Garı en işlek duraktır.", en: "Commerce and logistics. Busiest rail hub." } },
    { id: "kavin", name: "Kavin", region: { tr: "Doğu", en: "East" }, pop: 455000, area: 10100, x: 53.2, y: 40.2, d: { tr: "Bağcılık ve doğu rüzgârı.", en: "Vineyards and eastern wind." } },
    { id: "pavel", name: "Pavel", region: { tr: "Batı", en: "West" }, pop: 670000, area: 12050, x: 31.8, y: 47.6, d: { tr: "Tersaneler ve rüzgâr türbinleri.", en: "Shipyards and wind turbines." } },
    { id: "moren", name: "Moren", region: { tr: "İç Batı", en: "West Interior" }, pop: 580000, area: 7400, x: 37.4, y: 46.2, d: { tr: "Orman, kâğıt ve devlet arşivi.", en: "Forest, paper and the state archive." } },
    { id: "varis", name: "Varis", region: { tr: "Doğu İç", en: "East Interior" }, pop: 760000, area: 8200, x: 50.2, y: 45.8, d: { tr: "Sanayi kuşağı. Motor ve uydu parçası.", en: "Industrial belt. Engines and satellite parts." } },
    { id: "koren", name: "Koren", region: { tr: "Doğu", en: "East" }, pop: 510000, area: 9700, x: 54.2, y: 50.0, d: { tr: "Doğu kıyı ticareti ve tuzlaleler.", en: "Eastern coastal trade and salt pans." } },
    { id: "daren", name: "Daren", region: { tr: "Batı", en: "West" }, pop: 430000, area: 10500, x: 32.6, y: 53.4, d: { tr: "Maden ve Daren mermeri.", en: "Mines and Daren marble." } },
    { id: "loren", name: "Loren", region: { tr: "İç Batı", en: "West Interior" }, pop: 495000, area: 6800, x: 37.8, y: 52.4, d: { tr: "Tekstil. Loren keteni resmi üniformalardadır.", en: "Textiles. Loren linen in state uniforms." } },
    { id: "zoren", name: "Zoren", region: { tr: "İç Güney", en: "South Interior" }, pop: 640000, area: 7900, x: 43.8, y: 55.4, d: { tr: "MSK eğitim üssü, başkentin güney kapısı.", en: "MSK training base, southern gate of the capital." } },
    { id: "naven", name: "Naven", region: { tr: "Doğu İç", en: "East Interior" }, pop: 520000, area: 8050, x: 50.0, y: 54.2, d: { tr: "Enerji koridoru. Naven barajı.", en: "Energy corridor. Naven Dam." } },
    { id: "seris", name: "Seris", region: { tr: "Doğu", en: "East" }, pop: 405000, area: 9150, x: 55.4, y: 54.6, d: { tr: "Küçük, uyanık kıyı limanı.", en: "Small, sharp coastal harbour." } },
    { id: "karel", name: "Karel", region: { tr: "Güneybatı", en: "Southwest" }, pop: 388000, area: 11200, x: 33.8, y: 60.4, d: { tr: "Maysaistan’a bakan sınır kalkanı.", en: "Border shield facing Maysaistan." } },
    { id: "vanel", name: "Vanel", region: { tr: "Güney İç", en: "South Interior" }, pop: 360000, area: 6400, x: 37.6, y: 58.6, d: { tr: "Bahçe tarımı. Vanel lalesi.", en: "Garden farming. Vanel tulip." } },
    { id: "toren", name: "Toren", region: { tr: "Güney", en: "South" }, pop: 575000, area: 8600, x: 41.6, y: 61.8, d: { tr: "Güney demiryolu kavşağı.", en: "Southern railway junction." } },
    { id: "maris", name: "Maris", region: { tr: "Güneydoğu", en: "Southeast" }, pop: 445000, area: 9300, x: 54.0, y: 62.2, d: { tr: "İskele, tuzla ve gemi söküm.", en: "Quay, salt works, ship-breaking." } },
    { id: "yoren", name: "Yoren", region: { tr: "Güney", en: "South" }, pop: 410000, area: 10900, x: 37.6, y: 68.4, d: { tr: "Masalistan’a bakan dağlık il.", en: "Mountain province facing Masalistan." } },
    { id: "velan", name: "Velan", region: { tr: "Güney", en: "South" }, pop: 470000, area: 9800, x: 43.6, y: 68.6, d: { tr: "Güney ovaları. Velan pirinci.", en: "Southern plains. Velan rice." } },
    { id: "saven", name: "Saven", region: { tr: "Güneydoğu", en: "Southeast" }, pop: 395000, area: 8700, x: 50.2, y: 68.2, d: { tr: "Kuş cenneti ve milli rezerv.", en: "Bird sanctuary and national reserve." } },
    { id: "nelis", name: "Nelis", region: { tr: "Güneydoğu", en: "Southeast" }, pop: 352000, area: 11600, x: 54.4, y: 70.4, d: { tr: "Güneydoğu ucu. Nelis feneri.", en: "Southeastern tip. Nelis light." } },
  ];

  const cities = [
    ...provinces.map((p) => ({ id: p.id, name: p.name, province: p.name, pop: p.pop, capital: !!p.capital, national: !!p.capital, d: p.d })),
    { id: "hilalport", name: "Hilalport", province: "Pavel", pop: 186000, capital: false, national: false, d: { tr: "Batı açıklarındaki konteyner limanı.", en: "Container port on the western approaches." } },
    { id: "akademi", name: "Akademikent", province: "Arven", pop: 94000, capital: false, national: false, d: { tr: "Kampüs kenti, uzay mühendisliği.", en: "Campus city, space engineering." } },
    { id: "goktepe", name: "Göktepe", province: "Zoren", pop: 67000, capital: false, national: false, d: { tr: "MUA fırlatma izleme istasyonu.", en: "MSA launch-tracking station." } },
  ];

  const countries = [
    { id: "mehmetistan", name: "Mehmetistan", cap: "Mehmetkent", rel: "ally", box: [26, 24, 32, 54], h: { tr: "2018 cumhuriyeti. Atlas’ın merkez adası.", en: "2018 republic. Central island of the atlas." } },
    { id: "ortamistan", name: "Ortamistan", cap: "Ortamkent", rel: "ally", box: [14, 2, 30, 20], h: { tr: "Kuzey denizcilik cumhuriyeti. 2023 dostluk antlaşması.", en: "Northern maritime republic. 2023 friendship treaty." } },
    { id: "kralistan", name: "Kralistan", cap: "Kralkent", rel: "enemy", box: [47, 2, 26, 20], h: { tr: "Kuzeydoğu krallığı. Hilal Doktrini’ne karşı.", en: "Northeastern kingdom. Opposes the Crescent Doctrine." } },
    { id: "almiraistan", name: "Almiraistan", cap: "Almirakent", rel: "ally", box: [1, 22, 24, 30], h: { tr: "Batı liman birliği. MTT’nin ilk dış muhatabı.", en: "Western harbour league. MTT’s first foreign counterpart." } },
    { id: "maysaistan", name: "Maysaistan", cap: "Maysakent", rel: "ally", box: [1, 51, 24, 26], h: { tr: "Güneybatı tarım cumhuriyeti. Tahıl protokolü.", en: "Southwestern farm republic. Grain protocol." } },
    { id: "masalistan", name: "Masalistan", cap: "Masalkent", rel: "neutral", box: [14, 70, 26, 26], h: { tr: "Güney krallık kalıntısı. Mesafe korunur.", en: "Southern remnant of a kingdom. Distance is kept." } },
    { id: "talakistan", name: "Talakistan", cap: "Talakkent", rel: "ally", box: [56, 22, 20, 20], h: { tr: "Doğu-kuzey tarım kuşağı. Gümrük birliği.", en: "East-north farm belt. Customs union." } },
    { id: "hiyaristan", name: "Hiyaristan", cap: "Hiyarkent", rel: "neutral", box: [75, 21, 23, 21], h: { tr: "Uzak doğu. Orman hukuku sıkı.", en: "Far east. Strict forest law." } },
    { id: "barlasistan", name: "Barlasistan", cap: "Barlaskent", rel: "ally", box: [56, 42, 20, 20], h: { tr: "Tarihî akraba halk. Ortak dağ okulu.", en: "Historic kindred people. Shared mountain school." } },
    { id: "toprakistan", name: "Toprakistan", cap: "Toprakkent", rel: "neutral", box: [75, 42, 23, 20], h: { tr: "Doğu tarım devleti. Bloklara girmez.", en: "Eastern agrarian state. Joins no blocs." } },
    { id: "tarikistan", name: "Tarikistan", cap: "Tarikkent", rel: "ally", box: [54, 61, 22, 25], h: { tr: "Güneydoğu deniz cumhuriyeti. Liman protokolü.", en: "Southeastern maritime republic. Port protocol." } },
    { id: "seyyidistan", name: "Seyyidistan", cap: "Seyyidkent", rel: "unknown", box: [74, 61, 24, 27], h: { tr: "İç işleyişi kapalı. İlişki resmi olarak bilinmiyor.", en: "Inner workings closed. Relation officially unknown." } },
  ];

  const laws = [
    { cat: "constitution", code: "AY-001", y: 2018, t: { tr: "Mehmetistan Anayasası", en: "Constitution of Mehmetistan" }, s: { tr: "Egemenlik, kuvvetler ayrılığı, hilal bayrağı, Mehmetkent başkentliği.", en: "Sovereignty, separation of powers, crescent flag, Mehmetkent as capital." } },
    { cat: "constitution", code: "AY-014", y: 2022, t: { tr: "Dijital Devlet Maddesi", en: "Digital State Amendment" }, s: { tr: "Resmi işlemler çevrimdışı öncelikli portalda yürür.", en: "Official business runs through an offline-first portal." } },
    { cat: "citizenship", code: "VT-003", y: 2019, t: { tr: "Vatandaşlık Kanunu", en: "Citizenship Act" }, s: { tr: "Doğum, soy, hizmet. Dijital kimlik zorunlu.", en: "Birth, descent, service. Digital identity required." } },
    { cat: "education", code: "EG-007", y: 2020, t: { tr: "Millî Eğitim Kanunu", en: "National Education Act" }, s: { tr: "On iki yıl zorunlu eğitim. Harita dersi omurgadır.", en: "Twelve years compulsory. Map-reading is core." } },
    { cat: "security", code: "GV-002", y: 2019, t: { tr: "MSK Kuruluş Kanunu", en: "MSK Establishment Act" }, s: { tr: "Kara, hava, deniz, özel kuvvet. Sivil denetim.", en: "Army, air, navy, special forces. Civilian oversight." } },
    { cat: "economy", code: "EK-001", y: 2020, t: { tr: "MTT Para Kanunu", en: "MTT Currency Act" }, s: { tr: "Tek yasal ödeme aracı MTT. Emisyon Merkez Bankası’nda.", en: "MTT is sole legal tender. Issue at the Central Bank." } },
    { cat: "transport", code: "UL-009", y: 2021, t: { tr: "Ulusal Demiryolu Kanunu", en: "National Railway Act" }, s: { tr: "Melun–Mehmetkent–Toren omurgası kamu malıdır.", en: "Melun–Mehmetkent–Toren spine is public property." } },
    { cat: "technology", code: "DJ-004", y: 2022, t: { tr: "Açık Veri ve Yazılım Kanunu", en: "Open Data and Software Act" }, s: { tr: "Devlet yazılımı yerel ve çevrimdışı çalışır.", en: "State software runs locally and offline." } },
    { cat: "environment", code: "CV-006", y: 2021, t: { tr: "Saven Rezervi Kanunu", en: "Saven Reserve Act" }, s: { tr: "Kıyı bataklıkları milli parktır.", en: "Coastal marshes are a national park." } },
    { cat: "other", code: "KL-003", y: 2018, t: { tr: "Bayrak ve Mühür Kanunu", en: "Flag and Seal Act" }, s: { tr: "Yeşil-siyah-mavi kuşak, mavi hilal.", en: "Green-black-blue bands, blue crescent." } },
    { cat: "other", code: "UZ-001", y: 2022, t: { tr: "Uzay Faaliyetleri Kanunu", en: "Space Activities Act" }, s: { tr: "Fırlatma MUA tekelinde. Yörünge millî varlık.", en: "Launches under the MSA. Orbit is a national asset." } },
    { cat: "economy", code: "EK-016", y: 2024, t: { tr: "Kamu Bütçe Disiplini", en: "Public Budget Discipline" }, s: { tr: "Açık tavanı. Uzay ve demiryolu ayrı kalem.", en: "Deficit ceiling. Space and rail are separate lines." } },
  ];
  const CATS = [
    ["all", { tr: "Tümü", en: "All" }],
    ["constitution", { tr: "Anayasa", en: "Constitution" }],
    ["citizenship", { tr: "Vatandaşlık", en: "Citizenship" }],
    ["education", { tr: "Eğitim", en: "Education" }],
    ["security", { tr: "Güvenlik", en: "Security" }],
    ["economy", { tr: "Ekonomi", en: "Economy" }],
    ["transport", { tr: "Ulaşım", en: "Transport" }],
    ["technology", { tr: "Teknoloji", en: "Technology" }],
    ["environment", { tr: "Çevre", en: "Environment" }],
    ["other", { tr: "Diğer", en: "Other" }],
  ];

  const news = [
    { date: "2026-09-08", cat: { tr: "Uzay", en: "Space" }, t: { tr: "MUA Atlas-W görevini duyurdu", en: "MSA announced Atlas-W" }, b: { tr: "Göktepe’den Hilal-R2 ile kıyı fırtına uydusu. Pencere 2026 son çeyrek.", en: "Coastal-storm satellite on Hilal-R2 from Goktepe. Window: late 2026." } },
    { date: "2026-08-21", cat: { tr: "Ekonomi", en: "Economy" }, t: { tr: "MTT cüzdan v3 testleri bitti", en: "MTT wallet v3 tests done" }, b: { tr: "Çevrimdışı karekod on ilde hatasız. Yaygınlaştırma üçüncü çeyrek.", en: "Offline QR clean in ten provinces. Rollout in Q3." } },
    { date: "2026-07-14", cat: { tr: "Devlet", en: "State" }, t: { tr: "Dijital ülke portalı mühürlendi", en: "Digital country portal sealed" }, b: { tr: "Harita, kanun ve kimlik aynı çatı altında vatandaşa açıldı.", en: "Map, law and identity opened to citizens under one roof." } },
    { date: "2026-06-02", cat: { tr: "MSK", en: "MSK" }, t: { tr: "Mavi Hat-26 tatbikatı Nelis’te bitti", en: "Blue Line-26 ended at Nelis" }, b: { tr: "Deniz-hava manevrası. Kralistan gözlem gemisi 12 mil dışında tutuldu.", en: "Sea-air manoeuvre. Kralistan observer held outside 12 miles." } },
    { date: "2026-04-19", cat: { tr: "Ulaşım", en: "Transport" }, t: { tr: "Hilalport ikinci iskele temeli", en: "Hilalport second quay foundation" }, b: { tr: "Kapasite 2,4 milyon TEU. Almiraistan hattı günlük sefere geçiyor.", en: "Capacity 2.4 million TEU. Almiraistan line goes daily." } },
    { date: "2026-03-14", cat: { tr: "Tarih", en: "History" }, t: { tr: "Bağımsızlık Günü: 8. yıl", en: "Independence Day: year 8" }, b: { tr: "Hilal Meydanı’nda resmi geçit. ‘Bir hilal, bir vatan.’", en: "State parade on Crescent Square. ‘One crescent, one homeland.’" } },
    { date: "2026-01-28", cat: { tr: "Çevre", en: "Environment" }, t: { tr: "Saven rezervinde kuş rekoru", en: "Record birds at Saven Reserve" }, b: { tr: "Kış sayımında 86 tür. Koruma hedefi aşıldı.", en: "Winter count: 86 species. Protection target beaten." } },
    { date: "2025-12-09", cat: { tr: "Diplomasi", en: "Diplomacy" }, t: { tr: "Talakistan demiryolu niyet protokolü", en: "Talakistan rail intent protocol" }, b: { tr: "Velis kapısından Talakkent’e ray etüdü başlıyor.", en: "Study begins for rail from Velis gate to Talakkent." } },
  ];

  const history = [
    { y: "2014", t: { tr: "Fikir", en: "The idea" }, b: { tr: "Hilalli vatan taslağı. İlk bayrak eskizi yeşil-siyah-maviydi.", en: "A homeland under a crescent. First flag study already green-black-blue." } },
    { y: "2016", t: { tr: "Anayasa taslağı", en: "Draft constitution" }, b: { tr: "Dil, başkent, para, ordu. Hilal mühür kabul edildi.", en: "Language, capital, currency, army. Crescent adopted as seal." } },
    { y: "14 Mart 2018", t: { tr: "Bağımsızlık Günü", en: "Independence Day" }, b: { tr: "Cumhuriyet ilan edildi. Mehmetkent başkent.", en: "Republic proclaimed. Mehmetkent capital." } },
    { y: "2019", t: { tr: "MSK ve iller", en: "MSK and provinces" }, b: { tr: "Yirmi dört il sınırı. Silahlı kuvvetler tek komuta.", en: "Twenty-four borders. Armed forces under one command." } },
    { y: "2020", t: { tr: "MTT tedavüle çıktı", en: "MTT in circulation" }, b: { tr: "Merkez Bankası ilk seriyi bastı.", en: "Central Bank printed the first series." } },
    { y: "2022", t: { tr: "İlk uydu", en: "First satellite" }, b: { tr: "MUA-1 Hilal Göz yörüngede. Dijital Devlet maddesi.", en: "MSA-1 Crescent Eye in orbit. Digital State amendment." } },
    { y: "2023", t: { tr: "Atlas diplomasisi", en: "Atlas diplomacy" }, b: { tr: "Almiraistan, Ortamistan, Barlasistan dostluk antlaşmaları.", en: "Friendship treaties with Almiraistan, Ortamistan, Barlasistan." } },
    { y: "2025", t: { tr: "Dijital ülke sistemi", en: "Digital country system" }, b: { tr: "Kayıtlar tek portalda birleşti.", en: "Records joined in one portal." } },
    { y: "2026", t: { tr: "Resmi dijital portal", en: "Official digital portal" }, b: { tr: "Bu uygulama mühürlendi.", en: "This application was sealed." } },
  ];

  const cabinet = [
    ["Başbakan / PM", "Harun Melun"],
    ["İçişleri / Interior", "Leyla Karel"],
    ["Dışişleri / Foreign Affairs", "Emir Velis"],
    ["Savunma / Defence", "Korg. Saren Zoren"],
    ["Hazine / Treasury", "Deniz Varis"],
    ["Eğitim / Education", "Prof. Ayla Arven"],
    ["Sağlık / Health", "Dr. Mert Naven"],
    ["Ulaştırma / Transport", "Selim Melun"],
    ["Enerji / Energy", "Nihan Koren"],
    ["Dijital Devlet / Digital State", "Cem Hilal"],
    ["Çevre / Environment", "Defne Saven"],
    ["Adalet / Justice", "Yargıç Baran Toren"],
    ["Kültür / Culture", "İpek Liora"],
    ["Tarım / Agriculture", "Yusuf Taris"],
    ["Uzay / Space", "Dr. Lara Göktepe"],
  ];

  const spend = [
    [{ tr: "Eğitim", en: "Education" }, 18],
    [{ tr: "Ulaştırma", en: "Transport" }, 16],
    [{ tr: "Sosyal", en: "Social" }, 15],
    [{ tr: "Sağlık", en: "Health" }, 14],
    [{ tr: "MSK", en: "MSK" }, 12],
    [{ tr: "Uzay", en: "Space" }, 9],
    [{ tr: "Enerji", en: "Energy" }, 8],
    [{ tr: "Diğer", en: "Other" }, 8],
  ];

  const projects = [
    { cat: { tr: "Harita", en: "Map" }, t: { tr: "Resmi siyasi harita", en: "Official political map" }, s: { tr: "Yürürlükte", en: "Live" }, d: { tr: "2026 baskısı. İller düzenlenebilir veri.", en: "2026 edition. Provinces as editable data." } },
    { cat: { tr: "Minecraft", en: "Minecraft" }, t: { tr: "Mehmetkent ölçeği", en: "Mehmetkent scale" }, s: { tr: "Yapımda", en: "In progress" }, d: { tr: "Başkentin blok modeli. Hilal Meydanı birinci etap.", en: "Block model of the capital. Crescent Square is phase one." } },
    { cat: { tr: "Oyun", en: "Game" }, t: { tr: "Mehmetistan: Vatan", en: "Mehmetistan: Homeland" }, s: { tr: "Aktif", en: "Active" }, d: { tr: "Ulus kurma. İl sınavı bu portalın içinde.", en: "Nation-building. Province quiz lives in this portal." } },
    { cat: { tr: "Hikâye", en: "Story" }, t: { tr: "Hilal Kronikleri", en: "Crescent Chronicles" }, s: { tr: "Dizi", en: "Serial" }, d: { tr: "2014–2026 anlatısı, resmi kronolojiyle uyumlu.", en: "2014–2026 narrative, aligned with the official timeline." } },
    { cat: { tr: "Yapay zekâ", en: "AI" }, t: { tr: "Dijital kâtip", en: "Digital clerk" }, s: { tr: "Deneysel", en: "Experimental" }, d: { tr: "Kanun ve haritayı yerelde arar.", en: "Searches law and map data locally." } },
    { cat: { tr: "Kodlama", en: "Code" }, t: { tr: "Açık ülke kodu", en: "Open country code" }, s: { tr: "Sürekli", en: "Ongoing" }, d: { tr: "Yeni kayıt eklemek bir nesne daha yazmaktır.", en: "Adding a record is writing one more object." } },
  ];

  const ic = {
    map: '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M9 4l-5 2v14l5-2 6 2 5-2V4l-5 2-6-2z"/></svg>',
    gov: '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M4 10h16M6 10v8M18 10v8M4 18h16M12 4l8 6H4z"/></svg>',
    city: '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M4 20V9l6-3v14M10 20V8l10-4v16M4 20h16"/></svg>',
    law: '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M7 4h10v2H7zM8 6v14M16 6v14M6 20h12M12 6v14"/></svg>',
    coin: '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="1.8"><circle cx="12" cy="12" r="8"/><path d="M12 7v10"/></svg>',
    shield: '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M12 3l8 3v6c0 5-3.5 8-8 9-4.5-1-8-4-8-9V6z"/></svg>',
    rocket: '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M12 3c3 3 5 8 5 12l-5 5-5-5c0-4 2-9 5-12zM12 11a1.5 1.5 0 100 3 1.5 1.5 0 000-3z"/></svg>',
    book: '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M5 5h8a3 3 0 013 3v12H8a3 3 0 00-3 3V5zM16 8h3v12h-6"/></svg>',
    globe: '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="1.8"><circle cx="12" cy="12" r="8"/><path d="M4 12h16M12 4c2.5 2.5 3.5 5.5 3.5 8s-1 5.5-3.5 8c-2.5-2.5-3.5-5.5-3.5-8s1-5.5 3.5-8z"/></svg>',
    news: '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M4 5h12v14H4zM16 8h4v11a2 2 0 01-2 2H6"/></svg>',
    chart: '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M4 19h16M7 16v-5M12 16V7M17 16v-8"/></svg>',
    game: '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="1.8"><rect x="3" y="8" width="18" height="10" rx="3"/><path d="M8 13h4M10 11v4M16.5 12v.01M18.5 14v.01"/></svg>',
    folder: '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M3 7h6l2 2h10v10H3z"/></svg>',
    gear: '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="1.8"><circle cx="12" cy="12" r="3"/><path d="M12 3v2M12 19v2M3 12h2M19 12h2M5.6 5.6l1.4 1.4M17 17l1.4 1.4M5.6 18.4L7 17M17 7l1.4-1.4"/></svg>',
  };

  function applyChrome() {
    document.documentElement.dataset.theme = state.theme;
    document.documentElement.dataset.anim = state.anim ? "on" : "off";
    document.documentElement.lang = state.lang;
    $("#brandTitle").textContent = "MEHMETİSTAN";
    $("#brandSub").textContent = tx(I.sub);
    $("#backBtn").hidden = state.view === "home" || state.view === "menu";
    $$(".tab").forEach((b) => b.classList.toggle("on", b.dataset.go === (["map", "news", "mtt"].includes(state.view) ? state.view : state.view === "home" ? "home" : "menu")));
  }

  function go(id) {
    state.view = id;
    state.q = "";
    if (id !== "game") state.quiz = null;
    location.hash = id === "home" ? "" : id;
    render();
    $("#main").scrollTop = 0;
  }

  function head(title, sub) {
    return `<div class="section-head"><p class="kicker">${tx(I.portal)}</p><h2>${title}</h2>${sub ? `<p class="hint">${sub}</p>` : ""}</div>`;
  }

  function relChip(rel) {
    return `<span class="chip ${rel}">${tx(I[rel] || I.unknown)}</span>`;
  }

  function homeView() {
    const cards = MODULES.map(
      (m) => `<button type="button" class="card" data-go="${m.id}">
        <span class="ico ${m.tone}">${ic[m.ico]}</span>
        <h3>${tx(m.title)}</h3>
        <p>${tx(m.blurb)}</p>
      </button>`
    ).join("");
    return `<div class="page">
      <section class="hero">
        <p class="kicker">${state.lang === "tr" ? "Mehmetistan Cumhuriyeti" : "Republic of Mehmetistan"}</p>
        <h1>MEHMETİSTAN</h1>
        <p class="motto">${tx(I.sub)} · ${tx(I.motto)}</p>
        <div class="stats">
          <div class="stat"><b>18,4 Mn</b><span>${tx(I.pop)}</span></div>
          <div class="stat"><b>24</b><span>${state.lang === "tr" ? "İl" : "Provinces"}</span></div>
          <div class="stat"><b>MTT</b><span>1,00</span></div>
          <div class="stat"><b>2018</b><span>${state.lang === "tr" ? "Kuruluş" : "Founded"}</span></div>
        </div>
      </section>
      <label class="hint" for="q">${state.lang === "tr" ? "Ara" : "Search"}</label>
      <input class="search" id="q" placeholder="${tx(I.search)}" value="${esc(state.q)}" />
      <div class="grid" id="modGrid">${cards}</div>
    </div>`;
  }

  function mapView() {
    const tabs = ["atlas", "pins", "list"].map((t) => {
      const lab = { atlas: { tr: "Dünya atlası", en: "World atlas" }, pins: { tr: "İller", en: "Provinces" }, list: { tr: "Liste", en: "List" } }[t];
      return `<button type="button" data-maptab="${t}" class="${state.mapTab === t ? "on" : ""}">${tx(lab)}</button>`;
    }).join("");
    if (state.mapTab === "list") {
      return `<div class="page">${head(state.lang === "tr" ? "Ülke Haritası" : "Country Map", state.lang === "tr" ? "24 il · başkent Mehmetkent" : "24 provinces · capital Mehmetkent")}
        <div class="tabs">${tabs}</div>
        <div class="list">${provinces.map(pRow).join("")}</div>
      </div>`;
    }
    const hot = countries.map((c) => {
      const [x, y, w, h] = c.box;
      return `<button type="button" class="hotspot" data-country="${c.id}" style="left:${x}%;top:${y}%;width:${w}%;height:${h}%" aria-label="${c.name}"></button>`;
    }).join("");
    const pins =
      state.mapTab === "pins"
        ? provinces
            .map((p) =>
              p.capital
                ? `<button type="button" class="pin capital" style="left:${p.x}%;top:${p.y}%" data-prov="${p.id}" aria-label="${p.name}"><svg viewBox="0 0 24 24" fill="currentColor"><path d="M12 2l2.4 7.2H22l-6 4.4 2.3 7.2L12 16.8 5.7 20.8 8 13.6 2 9.2h7.6z"/></svg></button>`
                : `<button type="button" class="pin" style="left:${p.x}%;top:${p.y}%" data-prov="${p.id}" aria-label="${p.name}"></button>`
            )
            .join("")
        : "";
    return `<div class="page">${head(state.lang === "tr" ? "Ülke Haritası" : "Country Map", state.lang === "tr" ? "Sürükleyin, iki parmakla yakınlaştırın. Bölgeye dokunun." : "Drag, pinch to zoom. Tap a region.")}
      <div class="tabs">${tabs}</div>
      <div class="map-wrap" id="mapWrap">
        <div class="map-stage" id="mapStage">
          <div class="map-inner" id="mapInner">
            <img src="assets/maps/world-map.png" alt="Mehmetistan siyasi atlası" width="1500" height="1000" />
            ${hot}${pins}
          </div>
        </div>
        <div class="map-tools">
          <button type="button" id="zIn" aria-label="+">+</button>
          <button type="button" id="zOut" aria-label="−">−</button>
          <button type="button" id="zRst" aria-label="reset">↻</button>
        </div>
      </div>
    </div>`;
  }

  function pRow(p) {
    return `<button type="button" class="row" data-prov="${p.id}">
      <b>${p.capital ? "★ " : ""}${p.name}</b>
      <span>${tx(p.region)} · ${nfmt(p.pop)} · ${nfmt(p.area)} km²</span>
    </button>`;
  }

  function govView() {
    return `<div class="page">${head(state.lang === "tr" ? "Devlet" : "State")}
      <div class="hero">
        <p class="kicker">${state.lang === "tr" ? "Devlet Başkanı" : "Head of State"}</p>
        <h2>Mehmet Alparslan</h2>
        <p class="prose">${state.lang === "tr" ? "2022’den beri. Dijital ülke reformunun mimarı. Hilal Doktrini ile dış politikayı belirler." : "Since 2022. Architect of the digital-country reform. Sets foreign policy through the Crescent Doctrine."}</p>
      </div>
      <div class="kv">
        <div><span>${tx(I.cap)}</span><b>Mehmetkent</b></div>
        <div><span>${state.lang === "tr" ? "Meclis" : "Assembly"}</span><b>180</b></div>
        <div><span>${state.lang === "tr" ? "Yardımcı" : "Vice"}</span><b>Selin Arven</b></div>
        <div><span>${state.lang === "tr" ? "Sistem" : "System"}</span><b>${state.lang === "tr" ? "Cumhurbaşkanlığı" : "Presidential"}</b></div>
      </div>
      <h3>${state.lang === "tr" ? "Hükümet" : "Cabinet"}</h3>
      <div class="list">${cabinet.map(([o, n]) => `<div class="row"><b>${n}</b><span>${o}</span></div>`).join("")}</div>
      <h3>${state.lang === "tr" ? "Kurumlar" : "Agencies"}</h3>
      <div class="list">
        <div class="row"><b>MTT Merkez Bankası</b><span>${state.lang === "tr" ? "Para politikası ve dijital cüzdan" : "Monetary policy and digital wallet"}</span></div>
        <div class="row"><b>Mehmetistan Uzay Ajansı (MUA)</b><span>${state.lang === "tr" ? "Uydu ve fırlatma" : "Satellites and launches"}</span></div>
        <div class="row"><b>Dijital Kimlik Kurumu</b><span>${state.lang === "tr" ? "Vatandaşlık kartı" : "Citizenship card"}</span></div>
        <div class="row"><b>Ulusal Harita Müdürlüğü</b><span>${state.lang === "tr" ? "Siyasi harita ve il sınırları" : "Political map and borders"}</span></div>
      </div>
      ${idCard()}
    </div>`;
  }

  function idCard() {
    const name = state.citizen || (state.lang === "tr" ? "Vatandaş" : "Citizen");
    const no = "MH-" + String(Math.abs(hash(name)) % 90000000 + 10000000);
    return `<h3>${state.lang === "tr" ? "Dijital vatandaşlık kartı" : "Digital citizenship card"}</h3>
      <div class="idcard">
        <img class="flag" src="assets/flag/flag.png" alt="" />
        <small>Mehmetistan Cumhuriyeti</small>
        <b>${esc(name)}</b>
        <div class="id-grid">
          <div>${state.lang === "tr" ? "Kimlik" : "ID"}<br><span class="tabular">${no}</span></div>
          <div>${tx(I.cap)}<br>Mehmetkent</div>
        </div>
      </div>
      <input class="input" id="citizenName" placeholder="${state.lang === "tr" ? "Ad soyad" : "Full name"}" value="${esc(state.citizen)}" />
      <button type="button" class="btn-ghost" id="issueCard">${state.lang === "tr" ? "Kartı düzenle" : "Issue card"}</button>`;
  }

  function citiesView() {
    const q = state.q.trim().toLowerCase();
    const list = cities.filter((c) => !q || c.name.toLowerCase().includes(q) || c.province.toLowerCase().includes(q));
    return `<div class="page">${head(state.lang === "tr" ? "Şehirler" : "Cities")}
      <input class="search" id="q" placeholder="${state.lang === "tr" ? "Şehir veya il" : "City or province"}" value="${esc(state.q)}" />
      <div class="list">${list.map((c) => `<div class="row"><b>${c.national ? "★ " : ""}${c.name}</b><span>${c.province} · ${nfmt(c.pop)} · ${c.national ? tx(I.cap) : c.capital ? (state.lang === "tr" ? "İl merkezi" : "Provincial capital") : ""}</span><p>${tx(c.d)}</p></div>`).join("") || empty()}</div>
    </div>`;
  }

  function lawsView() {
    const tabs = CATS.map(([id, lab]) => `<button type="button" data-law="${id}" class="${state.lawCat === id ? "on" : ""}">${tx(lab)}</button>`).join("");
    const list = laws.filter((l) => state.lawCat === "all" || l.cat === state.lawCat);
    return `<div class="page">${head(state.lang === "tr" ? "Kanunlar" : "Laws")}
      <div class="tabs">${tabs}</div>
      <div class="list">${list.map((l) => `<div class="row"><div class="meta"><span>${l.code}</span><span>${l.y}</span></div><b>${tx(l.t)}</b><p>${tx(l.s)}</p></div>`).join("")}</div>
    </div>`;
  }

  function mttView() {
    return `<div class="page">${head("MTT", state.lang === "tr" ? "Mehmetistan Tokenu · kurgusal para birimi" : "Mehmetistan Token · fictional currency")}
      <div class="hero">
        <p class="kicker">${state.lang === "tr" ? "Resmi parite" : "Official parity"}</p>
        <h2 class="tabular">1,00 MTT</h2>
        <p class="hint">${state.lang === "tr" ? "100 kırat = 1 MTT · Merkez Bankası emisyonu" : "100 kirat = 1 MTT · Central Bank issue"}</p>
      </div>
      <div class="kv">
        <div><span>${state.lang === "tr" ? "GSYİH" : "GDP"}</span><b>142,6 Mr</b></div>
        <div><span>${state.lang === "tr" ? "Enflasyon" : "Inflation"}</span><b>%2,1</b></div>
        <div><span>${state.lang === "tr" ? "Rezerv" : "Reserves"}</span><b>31,2 Mr</b></div>
        <div><span>${state.lang === "tr" ? "Borç" : "Debt"}</span><b>%28</b></div>
      </div>
      <p class="hint">${state.lang === "tr" ? "Gerçek piyasa verisi çekilmez. Kurgu Mehmetistan ekonomisi." : "No live market data. Fictional Mehmetistan economy."}</p>
    </div>`;
  }

  function economyView() {
    const bars = spend.map(([l, p]) => `<div class="bar-row"><span>${tx(l)}</span><div class="bar"><i style="width:${p}%"></i></div><span class="tabular">${p}%</span></div>`).join("");
    return `<div class="page">${head(state.lang === "tr" ? "Ekonomi" : "Economy", "2026")}
      <h3>${state.lang === "tr" ? "Bütçe giderleri" : "Budget expenditure"}</h3>
      <div class="list" style="background:var(--surface);padding:14px;border-radius:14px;box-shadow:var(--shadow)">${bars}</div>
      <h3>${state.lang === "tr" ? "Üretim" : "Output"}</h3>
      <div class="kv">
        <div><span>${state.lang === "tr" ? "Hizmet" : "Services"}</span><b>%44</b></div>
        <div><span>${state.lang === "tr" ? "Sanayi" : "Industry"}</span><b>%31</b></div>
        <div><span>${state.lang === "tr" ? "Tarım" : "Agriculture"}</span><b>%14</b></div>
        <div><span>${state.lang === "tr" ? "Uzay / yazılım" : "Space / software"}</span><b>%5</b></div>
      </div>
      <h3>${state.lang === "tr" ? "Ticaret ortakları" : "Trade partners"}</h3>
      <div class="list">
        <div class="row"><b>Almiraistan</b><span>${state.lang === "tr" ? "İhracat %18" : "Export 18%"}</span></div>
        <div class="row"><b>Ortamistan</b><span>${state.lang === "tr" ? "İhracat %14" : "Export 14%"}</span></div>
        <div class="row"><b>Toprakistan</b><span>${state.lang === "tr" ? "İthalat %16" : "Import 16%"}</span></div>
      </div>
    </div>`;
  }

  function mskView() {
    const br = [
      [{ tr: "Kara Kuvvetleri", en: "Army" }, "62.000", { tr: "Zoren kışlası. Hilal zırhlısı.", en: "Zoren Barracks. Hilal armour." }],
      [{ tr: "Hava Kuvvetleri", en: "Air Force" }, "14.200", { tr: "Melun ve Göktepe. Kartal-C.", en: "Melun and Goktepe. Kartal-C." }],
      [{ tr: "Deniz Kuvvetleri", en: "Navy" }, "11.800", { tr: "Hilalport ve Seris. Denizçi korveti.", en: "Hilalport and Seris. Denizci corvette." }],
      [{ tr: "Özel Kuvvetler", en: "Special forces" }, "2.400", { tr: "Yoren dağ okulu, Mehmetkent siber alay.", en: "Yoren mountain school, Mehmetkent cyber regiment." }],
    ];
    return `<div class="page">${head("MSK", state.lang === "tr" ? "Mehmetistan Silahlı Kuvvetleri" : "Mehmetistan Armed Forces")}
      <div class="list">${br.map(([n, s, d]) => `<div class="row"><b>${tx(n)}</b><span>${s}</span><p>${tx(d)}</p></div>`).join("")}</div>
      <h3>${state.lang === "tr" ? "Rütbeler" : "Ranks"}</h3>
      <p class="hint">Er · Onbaşı · Çavuş · Teğmen · Yüzbaşı · Binbaşı · Albay · Tümgeneral · Orgeneral</p>
      <h3>${state.lang === "tr" ? "Ekipman" : "Equipment"}</h3>
      <div class="list">
        <div class="row"><b>Hilal-2 zırhlısı</b><span>Varis · 120 mm</span></div>
        <div class="row"><b>Kartal-C</b><span>${state.lang === "tr" ? "Çok rollü savaş uçağı" : "Multirole fighter"}</span></div>
        <div class="row"><b>Denizçi-sınıfı korvet</b><span>Hilalport</span></div>
        <div class="row"><b>Bozkurt füze bataryası</b><span>${state.lang === "tr" ? "Kıyı ve sınır" : "Coast and border"}</span></div>
      </div>
    </div>`;
  }

  function spaceView() {
    const m = [
      ["MUA-1 Hilal Göz", "2022", { tr: "Görevde", en: "Operational" }, { tr: "Yer gözlem. Haritaya sürekli görüntü.", en: "Earth observation. Live map feed." }],
      ["MUA-2 Haberleşme", "2024", { tr: "Görevde", en: "Operational" }, { tr: "Güvenli haberleşme yedek kanalı.", en: "Secure comms backup channel." }],
      ["Atlas-W", "2026", { tr: "Uçuşta", en: "In flight" }, { tr: "Kıyı fırtınası ve tarım tahmini.", en: "Coastal storms and farm forecast." }],
      ["Ay Keşif A", "2028", { tr: "Üretimde", en: "In build" }, { tr: "Yörünge tarayıcısı.", en: "Orbital scanner." }],
    ];
    return `<div class="page">${head(state.lang === "tr" ? "Uzay Programı" : "Space Program", "MUA")}
      <div class="list">${m.map(([n, y, s, d]) => `<div class="row"><div class="meta"><span>${y}</span><span class="chip">${tx(s)}</span></div><b>${n}</b><p>${tx(d)}</p></div>`).join("")}</div>
      <h3>${state.lang === "tr" ? "Roketler" : "Rockets"}</h3>
      <div class="list">
        <div class="row"><b>Hilal-R1</b><span>1,2 t LEO</span></div>
        <div class="row"><b>Hilal-R2</b><span>4,8 t LEO · ${state.lang === "tr" ? "iş atı" : "workhorse"}</span></div>
        <div class="row"><b>Bozkır-Ağır</b><span>14 t LEO · 2031</span></div>
      </div>
    </div>`;
  }

  function historyView() {
    return `<div class="page">${head(state.lang === "tr" ? "Tarih" : "History")}
      <div class="timeline">${history.map((h) => `<article class="tl"><time>${h.y}</time><b>${tx(h.t)}</b><p class="hint">${tx(h.b)}</p></article>`).join("")}</div>
    </div>`;
  }

  function worldView() {
    return `<div class="page">${head(state.lang === "tr" ? "Diğer Ülkeler" : "Other Countries")}
      <div class="list">${countries.map((c) => `<button type="button" class="row" data-country="${c.id}"><div class="meta">${relChip(c.rel)}</div><b>${c.name}</b><span>${tx(I.cap)}: ${c.cap}</span><p>${tx(c.h)}</p></button>`).join("")}</div>
    </div>`;
  }

  function newsView() {
    return `<div class="page">${head(state.lang === "tr" ? "Haberler" : "News")}
      <div class="list">${news.map((n) => `<article class="row"><div class="meta"><span>${n.date}</span><span>${tx(n.cat)}</span></div><b>${tx(n.t)}</b><p>${tx(n.b)}</p></article>`).join("")}</div>
    </div>`;
  }

  function gameView() {
    if (state.quiz) return quizView();
    return `<div class="page">${head(state.lang === "tr" ? "Mehmetistan Oyunu" : "Mehmetistan Game")}
      <div class="hero">
        <p class="kicker">Mehmetistan: Vatan</p>
        <h2>${state.lang === "tr" ? "Ulus, harita, hilal" : "Nation, map, crescent"}</h2>
        <p class="prose">${state.lang === "tr" ? "Atlas diplomasisi ve il yönetimi üzerine bir vatan projesi. Bu portalda il sınavı oynanır; harita bilgisi ölçülür." : "A homeland project of atlas diplomacy and provincial rule. The province quiz in this portal tests map knowledge."}</p>
      </div>
      <div class="kv">
        <div><span>${state.lang === "tr" ? "En yüksek" : "Best"}</span><b class="tabular">${state.high}/8</b></div>
        <div><span>${state.lang === "tr" ? "İl" : "Provinces"}</span><b>24</b></div>
      </div>
      <button type="button" class="btn-primary" id="startQuiz">${tx(I.play)}</button>
      <h3>${state.lang === "tr" ? "Özellikler" : "Features"}</h3>
      <div class="list">
        <div class="row"><b>${state.lang === "tr" ? "Siyasi harita" : "Political map"}</b><span>${state.lang === "tr" ? "24 il, başkent yıldızı" : "24 provinces, capital star"}</span></div>
        <div class="row"><b>${state.lang === "tr" ? "Hikâye" : "Story"}</b><span>Hilal Kronikleri · 2014–2026</span></div>
        <div class="row"><b>${state.lang === "tr" ? "Güncelleme" : "Update"}</b><span>2026.3 · ${state.lang === "tr" ? "dijital portal" : "digital portal"}</span></div>
      </div>
    </div>`;
  }

  function quizView() {
    const q = state.quiz;
    if (q.done) {
      if (q.score > state.high) {
        state.high = q.score;
        localStorage.setItem("mh-high", String(q.score));
      }
      return `<div class="page">${head(state.lang === "tr" ? "Sınav tamamlandı" : "Quiz complete")}
        <p class="quiz-score tabular">${q.score}/8</p>
        <p class="hint">${state.lang === "tr" ? "En yüksek" : "Best"}: ${state.high}/8</p>
        <button type="button" class="btn-primary" id="startQuiz">${state.lang === "tr" ? "Yeniden" : "Play again"}</button>
      </div>`;
    }
    const cur = q.order[q.i];
    const p = provinces.find((x) => x.id === cur);
    const feedback = q.msg ? `<p class="hint">${q.msg}</p>` : "";
    const pins = provinces
      .map((pr) => `<button type="button" class="pin${pr.capital ? " capital" : ""}" style="left:${pr.x}%;top:${pr.y}%" data-quiz="${pr.id}" aria-label="${pr.name}"></button>`)
      .join("");
    return `<div class="page">${head(state.lang === "tr" ? "Bu ili bulun" : "Find this province", `${q.i + 1}/8 · ${p.name}`)}
      ${feedback}
      <div class="map-wrap" id="mapWrap" style="height:52dvh">
        <div class="map-stage" id="mapStage">
          <div class="map-inner" id="mapInner" style="transform:translate(-18%,-18%) scale(2.1)">
            <img src="assets/maps/world-map.png" alt="" width="1500" height="1000" />
            ${pins}
          </div>
        </div>
      </div>
    </div>`;
  }

  function projectsView() {
    return `<div class="page">${head(state.lang === "tr" ? "Projeler" : "Projects")}
      <div class="list">${projects.map((p) => `<div class="row"><div class="meta"><span>${tx(p.cat)}</span><span>${tx(p.s)}</span></div><b>${tx(p.t)}</b><p>${tx(p.d)}</p></div>`).join("")}</div>
    </div>`;
  }

  function settingsView() {
    return `<div class="page">${head(state.lang === "tr" ? "Ayarlar" : "Settings")}
      <div class="warn-box"><strong>${state.lang === "tr" ? "Play Store yok" : "No Play Store"}</strong>${tx(I.zipnote)}</div>
      <div class="setting"><div><b>${state.lang === "tr" ? "Koyu tema" : "Dark theme"}</b></div>
        <button type="button" class="switch ${state.theme === "dark" ? "on" : ""}" id="swTheme" aria-pressed="${state.theme === "dark"}"><i></i></button></div>
      <div class="setting"><div><b>${state.lang === "tr" ? "Dil" : "Language"}</b><div class="hint">${state.lang === "tr" ? "Türkçe" : "English"}</div></div>
        <button type="button" class="btn-ghost" id="swLang" style="width:auto;min-width:96px">${state.lang === "tr" ? "EN" : "TR"}</button></div>
      <div class="setting"><div><b>${state.lang === "tr" ? "Animasyonlar" : "Animations"}</b></div>
        <button type="button" class="switch ${state.anim ? "on" : ""}" id="swAnim"><i></i></button></div>
      <div class="setting"><div><b>${state.lang === "tr" ? "Bildirimler" : "Notifications"}</b></div>
        <button type="button" class="switch ${state.notif ? "on" : ""}" id="swNotif"><i></i></button></div>
      <h3>${state.lang === "tr" ? "Ana ekrana ekle" : "Add to Home Screen"}</h3>
      <p class="prose">${state.lang === "tr"
        ? "Chrome’da sağ üst ⋮ menüsünü açın → Ana ekrana ekle / Uygulama yükle. Samsung Internet: menü → Ana ekrana ekle. iPhone/iPad: paylaş → Ana Ekrana Ekle. Play Store’ye gitmeyin."
        : "In Chrome open ⋮ → Add to Home Screen / Install app. Do not go to Play Store."}</p>
      <h3>${state.lang === "tr" ? "Uygulama hakkında" : "About"}</h3>
      <p class="prose">Mehmetistan Dijital Ülke Sistemi · 2026.1<br>${tx(I.motto)}<br>${state.lang === "tr" ? "Çevrimdışı çalışır. Sunucu gerekmez." : "Works offline. No server required."}</p>
    </div>`;
  }

  function menuView() {
    return `<div class="page">${head(state.lang === "tr" ? "Tüm modüller" : "All modules")}
      <div class="grid">${MODULES.map((m) => `<button type="button" class="card" data-go="${m.id}"><span class="ico ${m.tone}">${ic[m.ico]}</span><h3>${tx(m.title)}</h3><p>${tx(m.blurb)}</p></button>`).join("")}</div>
    </div>`;
  }

  function empty() {
    return `<p class="hint">${state.lang === "tr" ? "Kayıt yok" : "No records"}</p>`;
  }

  const views = {
    home: homeView,
    map: mapView,
    government: govView,
    cities: citiesView,
    laws: lawsView,
    mtt: mttView,
    msk: mskView,
    space: spaceView,
    history: historyView,
    world: worldView,
    news: newsView,
    economy: economyView,
    game: gameView,
    projects: projectsView,
    settings: settingsView,
    menu: menuView,
  };

  function render() {
    applyChrome();
    const fn = views[state.view] || homeView;
    $("#main").innerHTML = fn();
    bind();
    if (state.view === "map") setupMap();
  }

  function bind() {
    $$("[data-go]").forEach((b) => b.addEventListener("click", () => go(b.dataset.go)));
    const q = $("#q");
    if (q) q.addEventListener("input", () => {
      state.q = q.value;
      if (state.view === "home") filterHome();
      else render();
    });
    $$("[data-maptab]").forEach((b) => b.addEventListener("click", () => { state.mapTab = b.dataset.maptab; render(); }));
    $$("[data-law]").forEach((b) => b.addEventListener("click", () => { state.lawCat = b.dataset.law; render(); }));
    $$("[data-prov]").forEach((b) => b.addEventListener("click", () => openProv(b.dataset.prov)));
    $$("[data-country]").forEach((b) => b.addEventListener("click", () => openCountry(b.dataset.country)));
    const iq = $("#startQuiz");
    if (iq) iq.addEventListener("click", startQuiz);
    $$("[data-quiz]").forEach((b) => b.addEventListener("click", () => answerQuiz(b.dataset.quiz)));
    const swT = $("#swTheme");
    if (swT) swT.addEventListener("click", () => { state.theme = state.theme === "dark" ? "light" : "dark"; localStorage.setItem("mh-theme", state.theme); render(); });
    const swL = $("#swLang");
    if (swL) swL.addEventListener("click", () => { state.lang = state.lang === "tr" ? "en" : "tr"; localStorage.setItem("mh-lang", state.lang); render(); });
    const swA = $("#swAnim");
    if (swA) swA.addEventListener("click", () => { state.anim = !state.anim; localStorage.setItem("mh-anim", state.anim ? "on" : "off"); render(); });
    const swN = $("#swNotif");
    if (swN) swN.addEventListener("click", () => { state.notif = !state.notif; localStorage.setItem("mh-notif", state.notif ? "on" : "off"); render(); });
    const issue = $("#issueCard");
    if (issue) issue.addEventListener("click", () => {
      state.citizen = ($("#citizenName") || {}).value || "";
      localStorage.setItem("mh-citizen", state.citizen);
      render();
    });
  }

  function filterHome() {
    const q = state.q.trim().toLowerCase();
    $$("#modGrid .card").forEach((c) => {
      const id = c.dataset.go;
      const m = MODULES.find((x) => x.id === id);
      const hay = (tx(m.title) + " " + tx(m.blurb)).toLowerCase();
      c.style.display = !q || hay.includes(q) ? "" : "none";
    });
  }

  function openProv(id) {
    const p = provinces.find((x) => x.id === id);
    if (!p) return;
    sheet(`<h3>${p.capital ? "★ " : ""}${p.name}</h3>
      <div class="meta">${relChip("ally")}<span>${tx(p.region)}</span></div>
      <p class="prose" style="margin:10px 0">${tx(p.d)}</p>
      <div class="kv">
        <div><span>${tx(I.pop)}</span><b>${nfmt(p.pop)}</b></div>
        <div><span>${tx(I.area)}</span><b>${nfmt(p.area)} km²</b></div>
      </div>
      <button type="button" class="btn-ghost" data-close="sheet" style="margin-top:12px">${state.lang === "tr" ? "Kapat" : "Close"}</button>`);
  }

  function openCountry(id) {
    const c = countries.find((x) => x.id === id);
    if (!c) return;
    if (id === "mehmetistan") {
      state.mapTab = "pins";
      go("map");
      return;
    }
    sheet(`<h3>${c.name}</h3>
      ${relChip(c.rel)}
      <p class="hint">${tx(I.cap)}: ${c.cap}</p>
      <p class="prose" style="margin-top:8px">${tx(c.h)}</p>
      <button type="button" class="btn-ghost" data-close="sheet" style="margin-top:12px">${state.lang === "tr" ? "Kapat" : "Close"}</button>`);
  }

  function sheet(html) {
    $("#sheetBody").innerHTML = html;
    $("#sheet").hidden = false;
    $$("[data-close]").forEach((b) => b.addEventListener("click", closeSheet));
  }
  function closeSheet() { $("#sheet").hidden = true; }

  function startQuiz() {
    const ids = provinces.map((p) => p.id).sort(() => Math.random() - 0.5).slice(0, 8);
    state.quiz = { order: ids, i: 0, score: 0, done: false, msg: "" };
    render();
  }
  function answerQuiz(id) {
    const q = state.quiz;
    if (!q || q.done) return;
    const ok = id === q.order[q.i];
    q.msg = ok ? (state.lang === "tr" ? "Doğru" : "Correct") : (state.lang === "tr" ? "Yanlış — " : "Wrong — ") + provinces.find((p) => p.id === q.order[q.i]).name;
    if (ok) q.score += 1;
    q.i += 1;
    if (q.i >= q.order.length) q.done = true;
    render();
  }

  /* pan / zoom */
  const mapCtl = { s: 1, x: 0, y: 0, dragging: false, lx: 0, ly: 0, dist: 0 };
  function setupMap() {
    const stage = $("#mapStage");
    const inner = $("#mapInner");
    if (!stage || !inner) return;
    const apply = () => {
      mapCtl.s = Math.min(4.5, Math.max(1, mapCtl.s));
      inner.style.transform = `translate(${mapCtl.x}px, ${mapCtl.y}px) scale(${mapCtl.s})`;
    };
    apply();
    const zIn = $("#zIn"), zOut = $("#zOut"), zRst = $("#zRst");
    if (zIn) zIn.onclick = () => { mapCtl.s += 0.35; apply(); };
    if (zOut) zOut.onclick = () => { mapCtl.s -= 0.35; apply(); };
    if (zRst) zRst.onclick = () => { mapCtl.s = 1; mapCtl.x = 0; mapCtl.y = 0; apply(); };
    stage.addEventListener("pointerdown", (e) => {
      if (e.target.closest("button")) return;
      mapCtl.dragging = true;
      mapCtl.lx = e.clientX; mapCtl.ly = e.clientY;
      stage.setPointerCapture(e.pointerId);
    });
    stage.addEventListener("pointermove", (e) => {
      if (!mapCtl.dragging) return;
      mapCtl.x += e.clientX - mapCtl.lx;
      mapCtl.y += e.clientY - mapCtl.ly;
      mapCtl.lx = e.clientX; mapCtl.ly = e.clientY;
      apply();
    });
    stage.addEventListener("pointerup", () => { mapCtl.dragging = false; });
    stage.addEventListener("wheel", (e) => {
      e.preventDefault();
      mapCtl.s += e.deltaY > 0 ? -0.15 : 0.15;
      apply();
    }, { passive: false });
    let lastTap = 0;
    stage.addEventListener("click", (e) => {
      const now = Date.now();
      if (now - lastTap < 280) { mapCtl.s = mapCtl.s > 1.5 ? 1 : 2.2; apply(); }
      lastTap = now;
    });
  }

  function tick() {
    const d = new Date();
    const parts = new Intl.DateTimeFormat("tr-TR", { hour: "2-digit", minute: "2-digit", hour12: false, timeZone: "Europe/Istanbul" }).format(d);
    const el = $("#clock");
    if (el) el.textContent = parts;
  }

  function hash(s) {
    let h = 0;
    for (let i = 0; i < s.length; i++) h = (h * 31 + s.charCodeAt(i)) | 0;
    return h;
  }
  function esc(s) {
    return String(s || "").replace(/[&<>"']/g, (c) => ({ "&": "&", "<": "<", ">": ">", '"': """, "'": "&#39;" }[c]));
  }

  function boot() {
    applyChrome();
    tick();
    setInterval(tick, 15000);
    $("#enterBtn").addEventListener("click", enter);
    $("#brandBtn").addEventListener("click", () => go("home"));
    $("#backBtn").addEventListener("click", () => go("home"));
    $("#themeBtn").addEventListener("click", () => {
      state.theme = state.theme === "dark" ? "light" : "dark";
      localStorage.setItem("mh-theme", state.theme);
      applyChrome();
    });
    $$(".tab").forEach((b) => b.addEventListener("click", () => go(b.dataset.go)));
    $(".sheet .sheet-backdrop").addEventListener("click", closeSheet);
    const h = (location.hash || "").replace("#", "");
    if (h && (views[h] || h === "menu")) state.view = h;
    if (sessionStorage.getItem("mh-in")) enter();
    window.addEventListener("hashchange", () => {
      const id = (location.hash || "").replace("#", "") || "home";
      if (views[id] || id === "home") { state.view = id; render(); }
    });
  }

  function enter() {
    sessionStorage.setItem("mh-in", "1");
    $("#splash").hidden = true;
    $("#app").hidden = false;
    render();
    if (state.notif && !sessionStorage.getItem("mh-n")) {
      sessionStorage.setItem("mh-n", "1");
    }
  }

  document.addEventListener("DOMContentLoaded", boot);
})();
