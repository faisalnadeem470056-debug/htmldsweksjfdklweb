// Supabase connection for د ژوند رنګونه
const SUPABASE_URL = "https://skhdmkydekzsbhtljerw.supabase.co";
const SUPABASE_PUBLISHABLE_KEY = "sb_publishable_Rc-c6jEYEWfPFba9swt6BA_5ZND4zRQ";
const supabaseClient = window.supabase.createClient(SUPABASE_URL, SUPABASE_PUBLISHABLE_KEY);
let supabaseReady = false;
let me = null;

async function initSupabase(){
  try{
    const { data: sessionData } = await supabaseClient.auth.getSession();
    if(!sessionData?.session){
      const { error } = await supabaseClient.auth.signInAnonymously();
      if(error) throw error;
    }
    const { data: userData, error: userError } = await supabaseClient.auth.getUser();
    if(userError) throw userError;
    me = userData.user;
    supabaseReady = true;
    return true;
  }catch(e){
    supabaseReady = false;
    console.warn("Supabase:", e);
    return false;
  }
}

function sErr(e){
  const code=e?.code||"";
  const map={
    "23505":"دا کوډ یا معلومات مخکې موجود دي.",
    "23503":"اړوند معلومات پیدا نه شول.",
    "42501":"اجازه نشته.",
    "PGRST116":"معلومات پیدا نه شول.",
    "PGRST301":"د نښلولو ستونزه ده.",
    "AuthRetryableFetchError":"انټرنېټ مو وڅېړئ."
  };
  return map[code] || e?.message || "آنلاین خدمت کې ستونزه راغله.";
}
