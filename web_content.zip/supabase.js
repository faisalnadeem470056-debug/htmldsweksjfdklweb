// د ژوند رنګونه — Supabase REST connection (no external Supabase JS library needed)
const SUPABASE_URL = "https://skhdmkydekzsbhtljerw.supabase.co";
const SUPABASE_PUBLISHABLE_KEY = "sb_publishable_Rc-c6jEYEWfPFba9swt6BA_5ZND4zRQ";
const AUTH_URL = SUPABASE_URL + "/auth/v1";
const REST_URL = SUPABASE_URL + "/rest/v1";
const SESSION_KEY = "dz_supabase_session_v1";
let supabaseReady = false;
let me = null;

function authHeaders(token){
  const h={"apikey":SUPABASE_PUBLISHABLE_KEY,"Content-Type":"application/json"};
  if(token) h.Authorization="Bearer "+token;
  return h;
}

async function authRequest(path, body){
  const r=await fetch(AUTH_URL+path,{method:"POST",headers:authHeaders(),body:JSON.stringify(body||{})});
  const text=await r.text(); let data={}; try{data=text?JSON.parse(text):{}}catch(e){data={message:text}};
  if(!r.ok){const e=new Error(data?.msg||data?.message||data?.error_description||"د حساب جوړولو ستونزه ده.");e.code=data?.code||data?.error_code||"";throw e}
  return data;
}

async function signInAnon(){
  const old=JSON.parse(localStorage.getItem(SESSION_KEY)||"null");
  if(old?.access_token){
    const r=await fetch(AUTH_URL+"/user",{headers:authHeaders(old.access_token)});
    if(r.ok){const u=await r.json();return {session:old,user:u}}
    if(old.refresh_token){
      try{
        const refreshed=await authRequest("/token?grant_type=refresh_token",{refresh_token:old.refresh_token});
        localStorage.setItem(SESSION_KEY,JSON.stringify(refreshed));
        const u=await (await fetch(AUTH_URL+"/user",{headers:authHeaders(refreshed.access_token)})).json();
        return {session:refreshed,user:u};
      }catch(e){localStorage.removeItem(SESSION_KEY)}
    }
  }
  const session=await authRequest("/signup",{});
  if(!session?.access_token) throw new Error("د انانیمس حساب جوړول فعال نه دي.");
  localStorage.setItem(SESSION_KEY,JSON.stringify(session));
  const user=session.user || (await (await fetch(AUTH_URL+"/user",{headers:authHeaders(session.access_token)})).json());
  return {session,user};
}

async function initSupabase(){
  try{
    const x=await signInAnon();
    me=x.user||null;
    supabaseReady=!!me;
    return supabaseReady;
  }catch(e){supabaseReady=false;me=null;console.warn("Supabase:",e);return false}
}

const supabaseClient={
  auth:{
    async getSession(){return {data:{session:JSON.parse(localStorage.getItem(SESSION_KEY)||"null")}}},
    async signInAnonymously(){try{const x=await signInAnon();me=x.user;supabaseReady=true;return {data:x,error:null}}catch(error){return {data:null,error}}},
    async getUser(){
      const s=JSON.parse(localStorage.getItem(SESSION_KEY)||"null");
      if(!s?.access_token)return {data:{user:null},error:new Error("No session")};
      const r=await fetch(AUTH_URL+"/user",{headers:authHeaders(s.access_token)});const data=await r.json();
      return r.ok?{data:{user:data},error:null}:{data:{user:null},error:new Error(data?.message||"User error")};
    }
  },
  from(table){return new RestQuery(table)},
  rpc(name,args){return rpcCall(name,args)}
};

class RestQuery{
  constructor(table){this.table=table;this.action="select";this.columns="*";this.filters=[];this.orderBy=null;this.orderAsc=true;this.limitN=null;this.mode="many";this.payload=null;this.upsertMode=false}
  select(columns="*"){this.action="select";this.columns=columns;return this}
  eq(col,val){this.filters.push([col,"eq",val]);return this}
  in(col,vals){this.filters.push([col,"in",vals]);return this}
  order(col,opt={}){this.orderBy=col;this.orderAsc=opt.ascending!==false;return this}
  limit(n){this.limitN=n;return this}
  maybeSingle(){this.mode="maybeSingle";return this}
  single(){this.mode="single";return this}
  insert(payload){this.action="insert";this.payload=payload;return this}
  upsert(payload){this.action="upsert";this.payload=payload;this.upsertMode=true;return this}
  update(payload){this.action="update";this.payload=payload;return this}
  delete(){this.action="delete";return this}
  then(resolve,reject){return this.execute().then(resolve,reject)}
  catch(reject){return this.execute().catch(reject)}
  async execute(retried=false){
    const s=JSON.parse(localStorage.getItem(SESSION_KEY)||"null");
    const token=s?.access_token;
    if(!token)return {data:null,error:new Error("انټرنېټ/حساب شتون نه لري.")};
    let url=REST_URL+"/"+encodeURIComponent(this.table);
    const headers=authHeaders(token);
    let init={method:"GET",headers};
    if(this.action==="select"){
      const qs=new URLSearchParams();qs.set("select",this.columns);
      for(const [c,op,v] of this.filters){qs.set(c,op+"."+(Array.isArray(v)?"("+v.join(",")+")":String(v)))}
      if(this.orderBy)qs.set("order",this.orderBy+"."+(this.orderAsc?"asc":"desc"));
      if(this.limitN!=null)qs.set("limit",String(this.limitN));
      url+="?"+qs.toString();
    }else{
      const qs=new URLSearchParams();
      for(const [c,op,v] of this.filters)qs.set(c,op+"."+String(v));
      if(this.action==="insert"||this.action==="upsert"){init.method="POST";headers.Prefer=this.action==="upsert"?"resolution=merge-duplicates,return=minimal":"return=representation";if(this.action==="upsert")headers["Content-Profile"]="public";if(this.action==="upsert")qs.set("on_conflict","id");}
      else if(this.action==="update"){init.method="PATCH";headers.Prefer="return=minimal"}
      else if(this.action==="delete"){init.method="DELETE"}
      if(qs.toString())url+="?"+qs.toString();
      if(this.action!=="delete")init.body=JSON.stringify(this.payload);
    }
    let r;
    try{r=await fetch(url,init)}catch(e){return {data:null,error:e}}
    if(r.status===401 && !retried && s?.refresh_token){
      try{const fresh=await authRequest("/token?grant_type=refresh_token",{refresh_token:s.refresh_token});localStorage.setItem(SESSION_KEY,JSON.stringify(fresh));return this.execute(true)}catch(e){}
    }
    const text=await r.text();let data=null;try{data=text?JSON.parse(text):null}catch(e){data=text}
    if(!r.ok){const e=new Error(data?.message||data?.hint||data?.details||text||"Supabase خطا");e.code=data?.code||data?.status||r.status;return {data:null,error:e}}
    if(this.action==="select"){
      if(this.mode==="single")return {data:Array.isArray(data)?data[0]||null:data,error:Array.isArray(data)&&!data.length?Object.assign(new Error("معلومات پیدا نه شول."),{code:"PGRST116"}):null};
      if(this.mode==="maybeSingle")return {data:Array.isArray(data)?data[0]||null:data,error:null};
    }
    return {data,error:null}
  }
}

async function rpcCall(name,args={}){
  const s=JSON.parse(localStorage.getItem(SESSION_KEY)||"null");
  if(!s?.access_token)return {data:null,error:new Error("انټرنېټ/حساب شتون نه لري.")};
  try{
    const r=await fetch(REST_URL+"/rpc/"+encodeURIComponent(name),{method:"POST",headers:authHeaders(s.access_token),body:JSON.stringify(args||{})});
    const text=await r.text();let data=null;try{data=text?JSON.parse(text):null}catch(e){data=text}
    if(!r.ok){const e=new Error(data?.message||data?.hint||data?.details||text||"RPC خطا");e.code=data?.code||r.status;return {data:null,error:e}}
    return {data,error:null};
  }catch(error){return {data:null,error}}
}

function sErr(e){
  const code=e?.code||"";const map={"23505":"دا کوډ یا معلومات مخکې موجود دي.","23503":"اړوند معلومات پیدا نه شول.","42501":"اجازه نشته.","PGRST116":"معلومات پیدا نه شول.","PGRST301":"د نښلولو ستونزه ده.","AuthRetryableFetchError":"انټرنېټ مو وڅېړئ.","404":"آنلاین خدمت کې اړین فنکشن پیدا نه شو. د SQL setup فایل یو ځل اجرا کړئ."};
  return map[code]||e?.message||"آنلاین خدمت کې ستونزه راغله.";
}
