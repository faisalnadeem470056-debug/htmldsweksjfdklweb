import { useState, useEffect, useRef, useCallback } from 'react';
import {
  Player,
  PlayerColor,
  GameMode,
} from './types/game';
import { StartScreen } from './components/StartScreen';
import { ControlsHeader } from './components/ControlsHeader';
import { Board } from './components/Board';
import { Dice } from './components/Dice';
import { PlayerCard } from './components/PlayerCard';
import { HowToPlayModal } from './components/HowToPlayModal';
import { StatsModal } from './components/StatsModal';
import { PauseModal } from './components/PauseModal';
import { WinnerModal } from './components/WinnerModal';
import {
  getLegalMoves,
  calculateMoveResult,
  checkPlayerWon,
  getNextPlayerColor,
} from './utils/ludoRules';
import { chooseAiMove } from './utils/ai';
import { sounds } from './utils/audio';
import { recordStatsDelta, addMatchRecord } from './utils/storage';

const INITIAL_PLAYERS: Player[] = [
  {
    color: 'red',
    name: 'Player 1',
    type: 'human',
    active: true,
    hasWon: false,
    tokens: [
      { id: 0, color: 'red', step: -1 },
      { id: 1, color: 'red', step: -1 },
      { id: 2, color: 'red', step: -1 },
      { id: 3, color: 'red', step: -1 },
    ],
  },
  {
    color: 'green',
    name: 'Bot Green',
    type: 'bot',
    active: true,
    hasWon: false,
    tokens: [
      { id: 0, color: 'green', step: -1 },
      { id: 1, color: 'green', step: -1 },
      { id: 2, color: 'green', step: -1 },
      { id: 3, color: 'green', step: -1 },
    ],
  },
  {
    color: 'yellow',
    name: 'Player 2',
    type: 'human',
    active: true,
    hasWon: false,
    tokens: [
      { id: 0, color: 'yellow', step: -1 },
      { id: 1, color: 'yellow', step: -1 },
      { id: 2, color: 'yellow', step: -1 },
      { id: 3, color: 'yellow', step: -1 },
    ],
  },
  {
    color: 'blue',
    name: 'Bot Blue',
    type: 'bot',
    active: true,
    hasWon: false,
    tokens: [
      { id: 0, color: 'blue', step: -1 },
      { id: 1, color: 'blue', step: -1 },
      { id: 2, color: 'blue', step: -1 },
      { id: 3, color: 'blue', step: -1 },
    ],
  },
];

export function App() {
  // Navigation / Views
  const [screen, setScreen] = useState<'start' | 'game'>('start');
  const [gameMode, setGameMode] = useState<GameMode>('4-player');

  // Modals
  const [howToPlayOpen, setHowToPlayOpen] = useState(false);
  const [statsOpen, setStatsOpen] = useState(false);
  const [pauseOpen, setPauseOpen] = useState(false);
  const [winnerModalOpen, setWinnerModalOpen] = useState(false);

  // Sound state
  const [soundEnabled, setSoundEnabled] = useState(sounds.isEnabled());

  // Gameplay State
  const [players, setPlayers] = useState<Player[]>(INITIAL_PLAYERS);
  const [activeColor, setActiveColor] = useState<PlayerColor>('red');
  const [diceValue, setDiceValue] = useState<number>(1);
  const [isRolling, setIsRolling] = useState(false);
  const [phase, setPhase] = useState<
    'awaiting_roll' | 'rolling' | 'awaiting_move' | 'moving' | 'game_over'
  >('awaiting_roll');
  const [legalTokenIds, setLegalTokenIds] = useState<number[]>([]);
  const [consecutiveSixes, setConsecutiveSixes] = useState<number>(0);
  const [turnMessage, setTurnMessage] = useState<string>('Roll the dice to start!');
  const [winner, setWinner] = useState<Player | null>(null);

  // Juicy effects state
  const [isShaking, setIsShaking] = useState(false);
  const [animatingToken, setAnimatingToken] = useState<{
    color: PlayerColor;
    tokenId: number;
  } | null>(null);
  const [bannerToast, setBannerToast] = useState<{ text: string; color: string } | null>(null);

  // Match statistics tracker
  const matchTurnsRef = useRef<number>(0);
  const matchCapturesRef = useRef<number>(0);

  // Active player object
  const activePlayer = players.find((p) => p.color === activeColor) || players[0];
  const isHumanTurn = activePlayer.type === 'human';

  // Toggle Sound handler
  const handleToggleSound = () => {
    const updated = sounds.toggle();
    setSoundEnabled(updated);
  };

  // Toast banner helper
  const showToast = (text: string, color: string = 'text-amber-300') => {
    setBannerToast({ text, color });
    setTimeout(() => {
      setBannerToast(null);
    }, 2200);
  };

  // Start new match from config
  const handleStartGame = (
    mode: GameMode,
    configs: { color: PlayerColor; name: string; type: 'human' | 'bot' }[]
  ) => {
    setGameMode(mode);
    matchTurnsRef.current = 0;
    matchCapturesRef.current = 0;

    const newPlayers: Player[] = ['red', 'green', 'yellow', 'blue'].map((color) => {
      const config = configs.find((c) => c.color === color);
      const isActive = !!config;
      return {
        color: color as PlayerColor,
        name: config ? config.name : `Player ${color}`,
        type: config ? config.type : 'bot',
        active: isActive,
        hasWon: false,
        tokens: [
          { id: 0, color: color as PlayerColor, step: -1 },
          { id: 1, color: color as PlayerColor, step: -1 },
          { id: 2, color: color as PlayerColor, step: -1 },
          { id: 3, color: color as PlayerColor, step: -1 },
        ],
      };
    });

    setPlayers(newPlayers);
    const firstColor = configs[0].color;
    setActiveColor(firstColor);
    setDiceValue(1);
    setPhase('awaiting_roll');
    setLegalTokenIds([]);
    setConsecutiveSixes(0);
    setWinner(null);
    setWinnerModalOpen(false);
    setTurnMessage(`${configs[0].name}'s turn. Roll the dice!`);
    setScreen('game');

    recordStatsDelta({ gamesPlayed: 1 });
  };

  // Restart current match
  const handleRestartMatch = () => {
    setPlayers((prev) =>
      prev.map((p) => ({
        ...p,
        hasWon: false,
        tokens: p.tokens.map((t) => ({ ...t, step: -1 })),
      }))
    );
    matchTurnsRef.current = 0;
    matchCapturesRef.current = 0;
    const firstActive = players.find((p) => p.active)?.color || 'red';
    setActiveColor(firstActive);
    setDiceValue(1);
    setPhase('awaiting_roll');
    setLegalTokenIds([]);
    setConsecutiveSixes(0);
    setWinner(null);
    setWinnerModalOpen(false);
    setPauseOpen(false);
    setTurnMessage('Game restarted. Roll the dice!');
  };

  // Switch to next player's turn
  const advanceTurn = useCallback((currentPlayers: Player[], nextColor: PlayerColor) => {
    setConsecutiveSixes(0);
    setActiveColor(nextColor);
    setLegalTokenIds([]);
    setPhase('awaiting_roll');
    const nextPlayer = currentPlayers.find((p) => p.color === nextColor);
    setTurnMessage(`${nextPlayer?.name || nextColor}'s turn. Roll the dice!`);
  }, []);

  // Execute token move step by step
  const handleExecuteMove = useCallback(async (tokenId: number) => {
    if (phase !== 'awaiting_move') return;

    setPhase('moving');
    setLegalTokenIds([]);

    const rolledSix = diceValue === 6;

    const moveResult = calculateMoveResult(activeColor, tokenId, diceValue, players, rolledSix);
    setAnimatingToken({ color: activeColor, tokenId });

    // Step-by-step hopping animation
    const from = moveResult.fromStep;
    const to = moveResult.toStep;

    if (from === -1) {
      // Exiting yard directly to start square 0
      sounds.playTokenStep();
      setPlayers((prev) =>
        prev.map((p) => {
          if (p.color !== activeColor) return p;
          return {
            ...p,
            tokens: p.tokens.map((t) => (t.id === tokenId ? { ...t, step: 0 } : t)),
          };
        })
      );
      await new Promise((r) => setTimeout(r, 260));
    } else {
      // Advance step by step
      for (let s = from + 1; s <= to; s++) {
        sounds.playTokenStep();
        setPlayers((prev) =>
          prev.map((p) => {
            if (p.color !== activeColor) return p;
            return {
              ...p,
              tokens: p.tokens.map((t) => (t.id === tokenId ? { ...t, step: s } : t)),
            };
          })
        );
        await new Promise((r) => setTimeout(r, 90));
      }
    }

    setAnimatingToken(null);

    // Apply capture if any
    let captured = false;
    let updatedPlayers = players;

    if (moveResult.capturedToken) {
      captured = true;
      matchCapturesRef.current += 1;
      sounds.playCapture();
      setIsShaking(true);
      setTimeout(() => setIsShaking(false), 450);

      const capturedColor = moveResult.capturedToken.color;
      const capturedId = moveResult.capturedToken.tokenId;
      const opp = players.find((p) => p.color === capturedColor);

      showToast(`💥 ${activePlayer.name} captured ${opp?.name || capturedColor}'s token!`, 'text-red-400');

      recordStatsDelta({ tokensCaptured: 1 });

      setPlayers((prev) => {
        const next = prev.map((p) => {
          if (p.color === activeColor) {
            return {
              ...p,
              tokens: p.tokens.map((t) => (t.id === tokenId ? { ...t, step: to } : t)),
            };
          }
          if (p.color === capturedColor) {
            return {
              ...p,
              tokens: p.tokens.map((t) => (t.id === capturedId ? { ...t, step: -1 } : t)),
            };
          }
          return p;
        });
        updatedPlayers = next;
        return next;
      });
    } else {
      setPlayers((prev) => {
        const next = prev.map((p) => {
          if (p.color !== activeColor) return p;
          return {
            ...p,
            tokens: p.tokens.map((t) => (t.id === tokenId ? { ...t, step: to } : t)),
          };
        });
        updatedPlayers = next;
        return next;
      });
    }

    // Check if token reached Goal (step 56)
    if (moveResult.reachedGoal) {
      sounds.playTokenHome();
      showToast(`★ ${activePlayer.name}'s token reached Home!`, 'text-emerald-400');
      recordStatsDelta({ tokensHome: 1 });
    }

    // Check if player WON the match
    const currentPlayerState = updatedPlayers.find((p) => p.color === activeColor)!;
    if (checkPlayerWon(currentPlayerState)) {
      setPlayers((prev) =>
        prev.map((p) => (p.color === activeColor ? { ...p, hasWon: true } : p))
      );
      setWinner(activePlayer);
      setPhase('game_over');
      setWinnerModalOpen(true);

      const deltaWins: Record<string, number> = {
        gamesWon: activePlayer.type === 'human' ? 1 : 0,
        [`${activeColor}Wins`]: 1,
      };
      recordStatsDelta(deltaWins);

      addMatchRecord({
        id: Date.now().toString(),
        date: new Date().toLocaleDateString(),
        winnerColor: activeColor,
        winnerName: activePlayer.name,
        mode: gameMode,
        turns: matchTurnsRef.current,
        captures: matchCapturesRef.current,
      });

      return;
    }

    // Bonus turn check:
    // Bonus turn granted if rolled 6, captured an opponent, or reached home goal!
    if (moveResult.grantsBonusTurn) {
      const reason = rolledSix ? 'Rolled a 6' : captured ? 'Captured opponent' : 'Reached Home';
      showToast(`⭐ Bonus Turn! (${reason})`, 'text-amber-300');
      setTurnMessage(`Bonus roll! ${activePlayer.name} rolls again.`);
      setPhase('awaiting_roll');
    } else {
      // Normal turn transition
      const nextColor = getNextPlayerColor(activeColor, updatedPlayers);
      advanceTurn(updatedPlayers, nextColor);
    }
  }, [
    phase,
    players,
    activeColor,
    diceValue,
    activePlayer,
    gameMode,
    advanceTurn,
  ]);

  // Roll Dice handler
  const handleRollDice = useCallback(() => {
    if (phase !== 'awaiting_roll' || isRolling) return;

    matchTurnsRef.current += 1;
    setIsRolling(true);
    setPhase('rolling');
    sounds.playDiceRoll();

    // Animate dice value changes rapidly
    let rolls = 0;
    const interval = setInterval(() => {
      const tempRoll = Math.floor(Math.random() * 6) + 1;
      setDiceValue(tempRoll);
      rolls++;

      if (rolls >= 7) {
        clearInterval(interval);
        const finalRoll = Math.floor(Math.random() * 6) + 1;
        setDiceValue(finalRoll);
        setIsRolling(false);

        // Track consecutive sixes
        let nextSixCount = finalRoll === 6 ? consecutiveSixes + 1 : 0;
        setConsecutiveSixes(nextSixCount);

        if (finalRoll === 6) {
          sounds.playSixRolled();
          recordStatsDelta({ sixesRolled: 1 });
        }

        // Three sixes in a row forfeit rule
        if (nextSixCount >= 3) {
          showToast('⚠️ 3 consecutive sixes! Turn forfeited.', 'text-rose-400');
          setTurnMessage('Three 6s! Turn forfeited.');
          setTimeout(() => {
            const nextColor = getNextPlayerColor(activeColor, players);
            advanceTurn(players, nextColor);
          }, 1200);
          return;
        }

        // Calculate legal moves
        const legals = getLegalMoves(activePlayer, finalRoll);
        setLegalTokenIds(legals);

        if (legals.length === 0) {
          setTurnMessage(`Rolled ${finalRoll}. No legal moves!`);
          setTimeout(() => {
            const nextColor = getNextPlayerColor(activeColor, players);
            advanceTurn(players, nextColor);
          }, 1100);
        } else {
          setPhase('awaiting_move');
          if (activePlayer.type === 'human') {
            setTurnMessage(`Rolled ${finalRoll}! Select a highlighted token.`);
          } else {
            setTurnMessage(`${activePlayer.name} rolled ${finalRoll}... thinking...`);
          }
        }
      }
    }, 60);
  }, [phase, isRolling, consecutiveSixes, activeColor, players, activePlayer, advanceTurn]);

  // Bot Turn Automation Effect
  useEffect(() => {
    if (screen !== 'game' || pauseOpen || winnerModalOpen) return;

    if (activePlayer.type === 'bot') {
      if (phase === 'awaiting_roll' && !isRolling) {
        // Bot initiates roll after brief natural delay
        const timer = setTimeout(() => {
          handleRollDice();
        }, 700);
        return () => clearTimeout(timer);
      }

      if (phase === 'awaiting_move' && legalTokenIds.length > 0) {
        // Bot chooses move and executes after thoughtful delay
        const timer = setTimeout(() => {
          const chosenTokenId = chooseAiMove(
            activeColor,
            legalTokenIds,
            diceValue,
            players,
            diceValue === 6
          );
          handleExecuteMove(chosenTokenId);
        }, 850);
        return () => clearTimeout(timer);
      }
    }
  }, [
    screen,
    pauseOpen,
    winnerModalOpen,
    activePlayer.type,
    phase,
    isRolling,
    legalTokenIds,
    activeColor,
    diceValue,
    players,
    handleRollDice,
    handleExecuteMove,
  ]);

  // Keyboard shortcut listener (Space to roll, P to pause, M for mute)
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.target instanceof HTMLInputElement || e.target instanceof HTMLTextAreaElement) {
        return;
      }

      if (e.code === 'Space' || e.code === 'Enter') {
        if (screen === 'game' && phase === 'awaiting_roll' && isHumanTurn && !isRolling) {
          e.preventDefault();
          handleRollDice();
        }
      } else if (e.code === 'KeyP') {
        if (screen === 'game' && !winnerModalOpen) {
          setPauseOpen((prev) => !prev);
        }
      } else if (e.code === 'KeyM') {
        handleToggleSound();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [screen, phase, isHumanTurn, isRolling, winnerModalOpen, handleRollDice]);

  // If on Start Screen
  if (screen === 'start') {
    return (
      <>
        <StartScreen
          soundEnabled={soundEnabled}
          onToggleSound={handleToggleSound}
          onOpenHowToPlay={() => setHowToPlayOpen(true)}
          onOpenStats={() => setStatsOpen(true)}
          onStartGame={handleStartGame}
        />
        <HowToPlayModal isOpen={howToPlayOpen} onClose={() => setHowToPlayOpen(false)} />
        <StatsModal isOpen={statsOpen} onClose={() => setStatsOpen(false)} />
      </>
    );
  }

  // Active players list
  const activePlayersList = players.filter((p) => p.active);

  return (
    <div className="relative min-h-screen w-full bg-[#080d1a] text-slate-100 flex flex-col justify-between p-2 sm:p-4 overflow-x-hidden">
      {/* Background Ambient Glows */}
      <div className="fixed top-0 left-1/4 w-96 h-96 bg-red-600/10 rounded-full blur-[140px] pointer-events-none" />
      <div className="fixed bottom-0 right-1/4 w-96 h-96 bg-blue-600/10 rounded-full blur-[140px] pointer-events-none" />

      {/* Toast Notification Banner */}
      {bannerToast && (
        <div className="fixed top-4 left-1/2 -translate-x-1/2 z-50 animate-bounce">
          <div className="px-4 py-2 rounded-full bg-slate-900/95 border border-amber-500/50 shadow-2xl backdrop-blur-md flex items-center gap-2 text-xs sm:text-sm font-bold text-slate-100">
            <span className={bannerToast.color}>{bannerToast.text}</span>
          </div>
        </div>
      )}

      {/* Top Header & Quick Actions */}
      <ControlsHeader
        activePlayer={activePlayer}
        turnMessage={turnMessage}
        soundEnabled={soundEnabled}
        onToggleSound={handleToggleSound}
        onPause={() => setPauseOpen(true)}
        onRestart={handleRestartMatch}
        onOpenHowToPlay={() => setHowToPlayOpen(true)}
        onOpenStats={() => setStatsOpen(true)}
      />

      {/* Main Playing Area */}
      <main className="w-full max-w-4xl mx-auto flex-1 flex flex-col items-center justify-center gap-3 my-1">
        {/* Board with Screen Shake animation on captures */}
        <div className={`w-full flex items-center justify-center ${isShaking ? 'animate-shake' : ''}`}>
          <Board
            players={players}
            activeColor={activeColor}
            legalTokenIds={legalTokenIds}
            isHumanTurn={isHumanTurn && phase === 'awaiting_move'}
            onTokenClick={handleExecuteMove}
            animatingToken={animatingToken}
          />
        </div>

        {/* Action Tray: Dice & Turn status */}
        <div className="w-full max-w-md mx-auto flex items-center justify-center gap-6 bg-slate-900/70 border border-slate-800 backdrop-blur-md rounded-2xl p-3 shadow-xl">
          <Dice
            value={diceValue}
            isRolling={isRolling}
            canRoll={phase === 'awaiting_roll' && isHumanTurn && !isRolling}
            activeColor={activeColor}
            onRoll={handleRollDice}
            disabledReason={
              !isHumanTurn
                ? `${activePlayer.name}'s turn`
                : phase === 'awaiting_move'
                ? 'Select a token on board'
                : undefined
            }
          />
        </div>

        {/* 2 or 4 Player Status Cards */}
        <div
          className={`w-full max-w-2xl mx-auto grid gap-2 ${
            activePlayersList.length === 2 ? 'grid-cols-2' : 'grid-cols-2 sm:grid-cols-4'
          }`}
        >
          {activePlayersList.map((player) => (
            <PlayerCard
              key={player.color}
              player={player}
              isActive={player.color === activeColor}
              consecutiveSixes={player.color === activeColor ? consecutiveSixes : 0}
            />
          ))}
        </div>
      </main>

      {/* Footer Info / Helper */}
      <footer className="w-full max-w-4xl mx-auto text-center py-1">
        <p className="text-[11px] text-slate-500 font-medium">
          ARS LUDO • Classic Board Game • Roll a 6 to enter Base • Exact roll required to reach Home Goal
        </p>
      </footer>

      {/* Modals */}
      <HowToPlayModal isOpen={howToPlayOpen} onClose={() => setHowToPlayOpen(false)} />
      <StatsModal isOpen={statsOpen} onClose={() => setStatsOpen(false)} />
      <PauseModal
        isOpen={pauseOpen}
        soundEnabled={soundEnabled}
        onResume={() => setPauseOpen(false)}
        onRestart={() => {
          setPauseOpen(false);
          handleRestartMatch();
        }}
        onHome={() => {
          setPauseOpen(false);
          setScreen('start');
        }}
        onToggleSound={handleToggleSound}
        onOpenHowToPlay={() => {
          setPauseOpen(false);
          setHowToPlayOpen(true);
        }}
      />
      {winner && (
        <WinnerModal
          winner={winner}
          isOpen={winnerModalOpen}
          onPlayAgain={handleRestartMatch}
          onHome={() => {
            setWinnerModalOpen(false);
            setScreen('start');
          }}
        />
      )}
    </div>
  );
}
export default App;
