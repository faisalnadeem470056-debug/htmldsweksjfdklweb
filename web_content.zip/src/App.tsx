import React, { useState, useEffect, useCallback } from 'react';
import { GameState, Weapon, WeaponType, PlayerStats, GameSettings, Zombie, ItemPickup } from './types/game';
import { 
  DEFAULT_PLAYER_STATS, 
  DEFAULT_SETTINGS, 
  INITIAL_WEAPONS, 
  getLevelDetails, 
  getMapThemeForLevel,
  isBossLevel 
} from './game/constants';
import { sounds } from './game/sound';
import { MainMenu } from './components/screens/MainMenu';
import { LevelsScreen } from './components/screens/LevelsScreen';
import { WeaponsScreen } from './components/screens/WeaponsScreen';
import { UpgradesScreen } from './components/screens/UpgradesScreen';
import { ShopScreen } from './components/screens/ShopScreen';
import { SettingsScreen } from './components/screens/SettingsScreen';
import { GameCanvas } from './components/GameCanvas';
import { GameHUD } from './components/GameHUD';
import { TouchControls } from './components/TouchControls';
import { PauseModal } from './components/modals/PauseModal';
import { VictoryDefeatModal } from './components/modals/VictoryDefeatModal';

const STATS_KEY = 'jubair_hunter_stats_v1';
const WEAPONS_KEY = 'jubair_hunter_weapons_v1';
const SETTINGS_KEY = 'jubair_hunter_settings_v1';
const MEDKITS_KEY = 'jubair_hunter_medkits_v1';

export default function App() {
  // 1. Persistent State
  const [playerStats, setPlayerStats] = useState<PlayerStats>(() => {
    try {
      const saved = localStorage.getItem(STATS_KEY);
      if (saved) return JSON.parse(saved);
    } catch {}
    return DEFAULT_PLAYER_STATS;
  });

  const [weapons, setWeapons] = useState<Record<WeaponType, Weapon>>(() => {
    try {
      const saved = localStorage.getItem(WEAPONS_KEY);
      if (saved) return JSON.parse(saved);
    } catch {}
    return INITIAL_WEAPONS;
  });

  const [settings, setSettings] = useState<GameSettings>(() => {
    try {
      const saved = localStorage.getItem(SETTINGS_KEY);
      if (saved) return JSON.parse(saved);
    } catch {}
    return DEFAULT_SETTINGS;
  });

  const [medkitCount, setMedkitCount] = useState<number>(() => {
    try {
      const saved = localStorage.getItem(MEDKITS_KEY);
      if (saved) return parseInt(saved, 10);
    } catch {}
    return 3;
  });

  // Save to LocalStorage
  useEffect(() => {
    localStorage.setItem(STATS_KEY, JSON.stringify(playerStats));
  }, [playerStats]);

  useEffect(() => {
    localStorage.setItem(WEAPONS_KEY, JSON.stringify(weapons));
  }, [weapons]);

  useEffect(() => {
    localStorage.setItem(SETTINGS_KEY, JSON.stringify(settings));
    sounds.setSettings(settings.soundEnabled, settings.musicEnabled, settings.soundVolume, settings.musicVolume);
  }, [settings]);

  useEffect(() => {
    localStorage.setItem(MEDKITS_KEY, medkitCount.toString());
  }, [medkitCount]);

  // 2. Active Session State
  const [gameState, setGameState] = useState<GameState>('MENU');
  const [currentLevel, setCurrentLevel] = useState<number>(playerStats.highestLevelUnlocked || 1);
  const [isMobileDevice, setIsMobileDevice] = useState<boolean>(false);

  // Touch control inputs
  const [touchMoveVector, setTouchMoveVector] = useState({ x: 0, y: 0 });
  const [touchAimAngle, setTouchAimAngle] = useState<number | null>(null);
  const [isTouchShooting, setIsTouchShooting] = useState(false);
  const [touchReloadTrigger, setTouchReloadTrigger] = useState(0);
  const [touchJumpTrigger, setTouchJumpTrigger] = useState(0);

  // In-Game Live HUD stats from Canvas
  const [hudData, setHudData] = useState<{
    hp: number;
    maxHp: number;
    shield: number;
    maxShield: number;
    zombiesRemaining: number;
    totalZombies: number;
    bossZombie: Zombie | null;
    coinsEarned: number;
    score: number;
    comboCount: number;
    isReloading: boolean;
    playerPos: { x: number; y: number };
    zombies: Zombie[];
    pickups: ItemPickup[];
    worldSize: { width: number; height: number };
    jumpCooldown: number;
    canJump: boolean;
  }>({
    hp: 100,
    maxHp: 100,
    shield: 50,
    maxShield: 50,
    zombiesRemaining: 15,
    totalZombies: 15,
    bossZombie: null,
    coinsEarned: 0,
    score: 0,
    comboCount: 0,
    isReloading: false,
    playerPos: { x: 1100, y: 900 },
    zombies: [],
    pickups: [],
    worldSize: { width: 2200, height: 1800 },
    jumpCooldown: 0,
    canJump: true
  });

  // End game report stats
  const [endGameReport, setEndGameReport] = useState<{
    stars: number;
    coins: number;
    xp: number;
    score: number;
    kills: number;
  }>({ stars: 3, coins: 0, xp: 0, score: 0, kills: 0 });

  // Detect mobile touchscreen
  useEffect(() => {
    const checkTouch = () => {
      const hasTouch = 'ontouchstart' in window || navigator.maxTouchPoints > 0;
      setIsMobileDevice(hasTouch);
    };
    checkTouch();
    window.addEventListener('resize', checkTouch);
    return () => window.removeEventListener('resize', checkTouch);
  }, []);

  // Music management during states
  useEffect(() => {
    if (gameState === 'PLAYING') {
      sounds.startMusic();
    } else {
      sounds.stopMusic();
    }
  }, [gameState]);

  // Launch a level
  const handleStartLevel = (levelNum: number) => {
    setCurrentLevel(levelNum);
    setGameState('PLAYING');
  };

  // Weapon equip
  const handleEquipWeapon = (weaponId: WeaponType) => {
    setPlayerStats(prev => ({ ...prev, equippedWeapon: weaponId }));
  };

  // Weapon upgrade with coins
  const handleUpgradeWeapon = (weaponId: WeaponType) => {
    const w = weapons[weaponId];
    const cost = Math.floor(w.cost * 0.45 + (w.upgradeLevel * 250));
    if (playerStats.coins >= cost && w.upgradeLevel < w.maxUpgradeLevel) {
      setPlayerStats(prev => ({ ...prev, coins: prev.coins - cost }));
      setWeapons(prev => ({
        ...prev,
        [weaponId]: {
          ...w,
          upgradeLevel: w.upgradeLevel + 1,
          damage: Math.round(w.damage * 1.25),
          fireRate: Number((w.fireRate * 1.1).toFixed(1)),
          magSize: Math.round(w.magSize * 1.2),
          currentAmmo: Math.round(w.magSize * 1.2),
          reserveAmmo: Math.round(w.reserveAmmo * 1.25)
        }
      }));
      sounds.playPowerup();
    }
  };

  // Weapon unlock with coins
  const handleUnlockWeapon = (weaponId: WeaponType) => {
    const w = weapons[weaponId];
    if (playerStats.coins >= w.cost && !w.unlocked) {
      setPlayerStats(prev => ({
        ...prev,
        coins: prev.coins - w.cost,
        inventory: [...prev.inventory, weaponId]
      }));
      setWeapons(prev => ({
        ...prev,
        [weaponId]: { ...w, unlocked: true }
      }));
      sounds.playVictory();
    }
  };

  // Upgrade Hunter Perk
  const handleUpgradePerk = (perkKey: keyof PlayerStats['perks']) => {
    const currentTier = playerStats.perks[perkKey];
    const cost = 200 + currentTier * 250;
    if (playerStats.coins >= cost && currentTier < 5) {
      setPlayerStats(prev => ({
        ...prev,
        coins: prev.coins - cost,
        perks: {
          ...prev.perks,
          [perkKey]: currentTier + 1
        }
      }));
      sounds.playPowerup();
    }
  };

  // Emergency Medkit use in combat
  const handleUseMedkit = () => {
    if (medkitCount > 0 && hudData.hp < hudData.maxHp) {
      setMedkitCount(prev => prev - 1);
      setHudData(prev => ({
        ...prev,
        hp: Math.min(prev.maxHp, prev.hp + 50)
      }));
      sounds.playPowerup();
    }
  };

  // Shop actions
  const handleAddMedkits = (amount: number, cost: number) => {
    if (playerStats.coins >= cost) {
      setPlayerStats(prev => ({ ...prev, coins: prev.coins - cost }));
      setMedkitCount(prev => prev + amount);
      sounds.playCoin();
    }
  };

  const handleAddCoins = (amount: number) => {
    setPlayerStats(prev => ({ ...prev, coins: prev.coins + amount }));
    sounds.playCoin();
  };

  // Victory callback from canvas
  const handleLevelComplete = (stats: { stars: number; coins: number; xp: number; score: number; kills: number }) => {
    setEndGameReport(stats);
    setPlayerStats(prev => {
      const nextLevel = Math.min(100, Math.max(prev.highestLevelUnlocked, currentLevel + 1));
      const existingStars = prev.stars[currentLevel] || 0;
      const newStars = Math.max(existingStars, stats.stars);
      const newXp = prev.xp + stats.xp;
      const newPlayerLevel = 1 + Math.floor(newXp / 400);

      return {
        ...prev,
        coins: prev.coins + stats.coins,
        xp: newXp,
        level: newPlayerLevel,
        highestLevelUnlocked: nextLevel,
        stars: {
          ...prev.stars,
          [currentLevel]: newStars
        }
      };
    });
    setGameState('VICTORY');
  };

  // Game over callback
  const handleGameOver = (stats: { score: number; kills: number }) => {
    setEndGameReport({
      stars: 0,
      coins: 0,
      xp: Math.floor(stats.kills * 10),
      score: stats.score,
      kills: stats.kills
    });
    setGameState('GAMEOVER');
  };

  // Reset Progress
  const handleResetProgress = () => {
    setPlayerStats(DEFAULT_PLAYER_STATS);
    setWeapons(INITIAL_WEAPONS);
    setMedkitCount(3);
    setCurrentLevel(1);
    setGameState('MENU');
  };

  const activeWeapon = weapons[playerStats.equippedWeapon] || weapons.pistol;
  const unlockedWeaponsList: Weapon[] = (Object.values(weapons) as Weapon[]).filter(w => w.unlocked);
  const currentMapTheme = getMapThemeForLevel(currentLevel);
  const levelDetails = getLevelDetails(currentLevel);

  return (
    <div className="relative w-screen h-screen overflow-hidden bg-slate-950 select-none">
      {/* 1. MAIN MENU */}
      {gameState === 'MENU' && (
        <MainMenu
          playerStats={playerStats}
          onNavigate={(screen) => {
            if (screen === 'PLAY') {
              handleStartLevel(playerStats.highestLevelUnlocked);
            } else {
              setGameState(screen as GameState);
            }
          }}
        />
      )}

      {/* 2. LEVELS SCREEN (100 Levels) */}
      {gameState === 'LEVELS' && (
        <LevelsScreen
          playerStats={playerStats}
          onSelectLevel={(lvl) => handleStartLevel(lvl)}
          onBack={() => setGameState('MENU')}
        />
      )}

      {/* 3. WEAPONS SCREEN (Armory) */}
      {gameState === 'WEAPONS' && (
        <WeaponsScreen
          weapons={weapons}
          playerStats={playerStats}
          onUpgradeWeapon={handleUpgradeWeapon}
          onUnlockWeapon={handleUnlockWeapon}
          onEquipWeapon={handleEquipWeapon}
          onBack={() => setGameState('MENU')}
        />
      )}

      {/* 4. UPGRADES SCREEN (Hunter Perks) */}
      {gameState === 'UPGRADES' && (
        <UpgradesScreen
          playerStats={playerStats}
          onUpgradePerk={handleUpgradePerk}
          onBack={() => setGameState('MENU')}
        />
      )}

      {/* 5. SHOP SCREEN */}
      {gameState === 'SHOP' && (
        <ShopScreen
          playerStats={playerStats}
          medkitCount={medkitCount}
          onAddMedkits={handleAddMedkits}
          onAddCoins={handleAddCoins}
          onBack={() => setGameState('MENU')}
        />
      )}

      {/* 6. SETTINGS SCREEN */}
      {gameState === 'SETTINGS' && (
        <SettingsScreen
          settings={settings}
          onUpdateSettings={(newSet) => setSettings(prev => ({ ...prev, ...newSet }))}
          onResetProgress={handleResetProgress}
          onBack={() => setGameState('MENU')}
        />
      )}

      {/* 7. ACTIVE GAMEPLAY (CANVAS + HUD + CONTROLS) */}
      {(gameState === 'PLAYING' || gameState === 'PAUSED' || gameState === 'VICTORY' || gameState === 'GAMEOVER') && (
        <div className="relative w-full h-full">
          {/* 2D Action Shooting Canvas Engine */}
          <GameCanvas
            level={currentLevel}
            playerStats={playerStats}
            settings={settings}
            activeWeapon={activeWeapon}
            unlockedWeapons={unlockedWeaponsList}
            medkitCount={medkitCount}
            onUseMedkit={handleUseMedkit}
            onSelectWeapon={handleEquipWeapon}
            onLevelComplete={handleLevelComplete}
            onGameOver={handleGameOver}
            onPause={() => setGameState('PAUSED')}
            isPaused={gameState !== 'PLAYING'}
            touchMoveVector={touchMoveVector}
            touchAimAngle={touchAimAngle}
            isTouchShooting={isTouchShooting}
            touchReloadTrigger={touchReloadTrigger}
            touchJumpTrigger={touchJumpTrigger}
            onUpdateHUD={setHudData}
          />

          {/* In-Game HUD overlay */}
          <GameHUD
            level={currentLevel}
            mapName={currentMapTheme.name}
            zombiesRemaining={hudData.zombiesRemaining}
            totalZombies={hudData.totalZombies}
            bossZombie={hudData.bossZombie}
            hp={hudData.hp}
            maxHp={hudData.maxHp}
            shield={hudData.shield}
            maxShield={hudData.maxShield}
            activeWeapon={activeWeapon}
            unlockedWeapons={unlockedWeaponsList}
            onSelectWeapon={handleEquipWeapon}
            coinsEarned={hudData.coinsEarned}
            score={hudData.score}
            comboCount={hudData.comboCount}
            isReloading={hudData.isReloading}
            onPause={() => setGameState('PAUSED')}
            playerPos={hudData.playerPos}
            zombies={hudData.zombies}
            pickups={hudData.pickups}
            worldSize={hudData.worldSize}
            jumpCooldown={hudData.jumpCooldown}
            canJump={hudData.canJump}
          />

          {/* Virtual Touch Controls (Always available on Mobile or when enabled in Settings) */}
          {(isMobileDevice || settings.touchControls) && gameState === 'PLAYING' && (
            <TouchControls
              onMove={(dx, dy) => setTouchMoveVector({ x: dx, y: dy })}
              onAim={(angle) => setTouchAimAngle(angle)}
              onShootStart={() => setIsTouchShooting(true)}
              onShootEnd={() => setIsTouchShooting(false)}
              onReload={() => setTouchReloadTrigger(prev => prev + 1)}
              onJump={() => setTouchJumpTrigger(prev => prev + 1)}
              onSwitchWeapon={() => {
                const currentIndex = unlockedWeaponsList.findIndex(w => w.id === activeWeapon.id);
                const nextIndex = (currentIndex + 1) % unlockedWeaponsList.length;
                handleEquipWeapon(unlockedWeaponsList[nextIndex].id);
              }}
              onUseItem={handleUseMedkit}
              activeWeapon={activeWeapon}
              medkitCount={medkitCount}
              isReloading={hudData.isReloading}
              canJump={hudData.canJump}
              jumpCooldown={hudData.jumpCooldown}
            />
          )}

          {/* PAUSE MODAL */}
          {gameState === 'PAUSED' && (
            <PauseModal
              onResume={() => setGameState('PLAYING')}
              onRestart={() => handleStartLevel(currentLevel)}
              onSettings={() => setGameState('SETTINGS')}
              onQuit={() => setGameState('MENU')}
            />
          )}

          {/* VICTORY & DEFEAT REPORT MODAL */}
          {(gameState === 'VICTORY' || gameState === 'GAMEOVER') && (
            <VictoryDefeatModal
              status={gameState}
              level={currentLevel}
              isBoss={levelDetails.isBoss}
              bossName={levelDetails.bossName}
              starsEarned={endGameReport.stars}
              coinsEarned={endGameReport.coins}
              xpEarned={endGameReport.xp}
              score={endGameReport.score}
              zombiesKilled={endGameReport.kills}
              onNextLevel={() => handleStartLevel(Math.min(100, currentLevel + 1))}
              onRetry={() => handleStartLevel(currentLevel)}
              onGoToArmory={() => setGameState('WEAPONS')}
              onGoToMenu={() => setGameState('MENU')}
            />
          )}
        </div>
      )}
    </div>
  );
}
