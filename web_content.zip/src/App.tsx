import React, { useState, useEffect } from 'react';
import { UserRole, Student, Teacher } from './types';
import { DataStore } from './services/store';
import { Header } from './components/Header';
import { ParentStudentPanel } from './components/ParentStudentPanel';
import { TeacherPanel } from './components/TeacherPanel';
import { AdminDashboard } from './components/AdminDashboard';
import { toPersianDigits } from './utils/jalali';
import { Wifi, Battery, Signal } from 'lucide-react';

export default function App() {
  // Application State
  const [currentRole, setCurrentRole] = useState<UserRole>('parent');
  const [currentUserId, setCurrentUserId] = useState<string>('parent-ali');
  const [isMobileFrame, setIsMobileFrame] = useState<boolean>(false);

  // Reactive store state
  const [students, setStudents] = useState(DataStore.getStudents());
  const [teachers, setTeachers] = useState(DataStore.getTeachers());
  const [classes, setClasses] = useState(DataStore.getClasses());
  const [sessions, setSessions] = useState(DataStore.getSessions());
  const [payments, setPayments] = useState(DataStore.getPayments());
  const [exams, setExams] = useState(DataStore.getExams());
  const [results, setResults] = useState(DataStore.getResults());

  // Subscribe to store updates
  useEffect(() => {
    const unsubscribe = DataStore.subscribe(() => {
      setStudents(DataStore.getStudents());
      setTeachers(DataStore.getTeachers());
      setClasses(DataStore.getClasses());
      setSessions(DataStore.getSessions());
      setPayments(DataStore.getPayments());
      setExams(DataStore.getExams());
      setResults(DataStore.getResults());
    });
    return unsubscribe;
  }, []);

  // Handle Role Change
  const handleRoleChange = (role: UserRole, userId: string) => {
    setCurrentRole(role);
    setCurrentUserId(userId);
  };

  // Reset Data to initial demo state
  const handleResetData = () => {
    if (confirm('آیا مایل به بازنشانی اطلاعات نمونه آموزشگاه آی‌مکس هستید؟')) {
      DataStore.resetToInitial();
    }
  };

  // Determine current active objects based on role and userId
  const activeTeacher: Teacher = teachers.find(t => t.teacherId === currentUserId) || teachers[0];
  
  // Active student for parent/student role
  const activeStudent: Student = (currentRole === 'parent' || currentRole === 'student')
    ? (students.find(s => s.studentId === currentUserId || s.parentPhone.includes(currentUserId)) || students[0])
    : students[0];

  return (
    <div className="min-h-screen bg-slate-50 text-slate-800 flex flex-col font-sans selection:bg-indigo-500 selection:text-white">
      
      {/* Top Header & Role Switcher Bar */}
      <Header
        currentRole={currentRole}
        currentUserId={currentUserId}
        onRoleChange={handleRoleChange}
        isMobileFrame={isMobileFrame}
        onToggleFrame={() => setIsMobileFrame(!isMobileFrame)}
        onResetData={handleResetData}
      />

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-4 sm:p-6 flex flex-col items-center">
        
        {/* Mobile Viewport Simulation Shell when isMobileFrame is active */}
        {isMobileFrame ? (
          <div className="w-full max-w-md my-4 bg-white rounded-[40px] p-3.5 shadow-xl border-4 border-slate-300 ring-1 ring-slate-200">
            {/* Mobile Bezel Top Notch */}
            <div className="w-full pt-1 pb-2 px-6 flex items-center justify-between text-xs text-slate-600 font-mono">
              <span>{toPersianDigits('10:45')}</span>
              <div className="w-20 h-4 bg-slate-200 rounded-full flex items-center justify-center">
                <div className="w-2.5 h-2.5 rounded-full bg-slate-400"></div>
              </div>
              <div className="flex items-center gap-1.5 text-[11px]">
                <Signal className="w-3 h-3" />
                <Wifi className="w-3 h-3" />
                <Battery className="w-3.5 h-3.5" />
              </div>
            </div>

            {/* Mobile Screen Inside */}
            <div className="bg-slate-50 rounded-[32px] overflow-hidden p-3 min-h-[640px] max-h-[82vh] overflow-y-auto border border-slate-200">
              {currentRole === 'admin' ? (
                <AdminDashboard
                  students={students}
                  teachers={teachers}
                  classes={classes}
                  sessions={sessions}
                  payments={payments}
                  exams={exams}
                  results={results}
                  onConfirmPayment={(studentId, amount, confirmedBy, PersianDate) =>
                    DataStore.confirmPayment(studentId, amount, confirmedBy, PersianDate)
                  }
                  onAddStudent={(std) => DataStore.addStudent(std)}
                  onAddClass={(newClass) => DataStore.addClass(newClass)}
                />
              ) : currentRole === 'teacher' ? (
                <TeacherPanel
                  teacher={activeTeacher}
                  classes={classes}
                  students={students}
                  sessions={sessions}
                  exams={exams}
                  onAddSession={(ses) => DataStore.addSession(ses)}
                  onSaveExamResult={(res) => DataStore.saveExamResult(res)}
                  onAddClass={(newClass) => DataStore.addClass(newClass)}
                />
              ) : (
                <ParentStudentPanel
                  currentStudent={activeStudent}
                  sessions={sessions}
                  payments={payments}
                  results={results}
                  onSelectStudent={(sId) => setCurrentUserId(sId)}
                  availableStudents={students}
                />
              )}
            </div>

            {/* Mobile Home Indicator */}
            <div className="w-32 h-1 bg-slate-300 rounded-full mx-auto mt-3"></div>
          </div>
        ) : (
          /* Wide Screen Responsive Layout */
          <div className="w-full">
            {currentRole === 'admin' ? (
              <AdminDashboard
                students={students}
                teachers={teachers}
                classes={classes}
                sessions={sessions}
                payments={payments}
                exams={exams}
                results={results}
                onConfirmPayment={(studentId, amount, confirmedBy, PersianDate) =>
                  DataStore.confirmPayment(studentId, amount, confirmedBy, PersianDate)
                }
                onAddStudent={(std) => DataStore.addStudent(std)}
                onAddClass={(newClass) => DataStore.addClass(newClass)}
              />
            ) : currentRole === 'teacher' ? (
              <TeacherPanel
                teacher={activeTeacher}
                classes={classes}
                students={students}
                sessions={sessions}
                exams={exams}
                onAddSession={(ses) => DataStore.addSession(ses)}
                onSaveExamResult={(res) => DataStore.saveExamResult(res)}
                onAddClass={(newClass) => DataStore.addClass(newClass)}
              />
            ) : (
              <ParentStudentPanel
                currentStudent={activeStudent}
                sessions={sessions}
                payments={payments}
                results={results}
                onSelectStudent={(sId) => setCurrentUserId(sId)}
                availableStudents={students}
              />
            )}
          </div>
        )}

      </main>

      {/* Footer */}
      <footer className="border-t border-slate-200 bg-white py-4 text-center text-xs text-slate-500 mt-auto">
        <div className="max-w-7xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-2">
          <div>
            سامانه تیزهوشان آی‌مکس (IMAX Smart Academy) • طراحی شده با استاندارد آزمون‌های ورودی سمپاد
          </div>
          <div className="text-slate-400 font-mono text-[11px]">
            نسخه ۲.۴.۰ • پشتیبانی از تقویم جلالی و هوش مصنوعی تحلیلی
          </div>
        </div>
      </footer>

    </div>
  );
}
