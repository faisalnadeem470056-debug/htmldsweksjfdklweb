// Voice & Text Action Engine for opening real apps and websites (WhatsApp, Google, YouTube, etc.)

export interface VoiceActionExecution {
  matched: boolean;
  actionName: string;
  url: string;
  spokenReply: string;
  displayMessage: string;
}

export function parseAndExecuteVoiceCommand(rawText: string): VoiceActionExecution | null {
  if (!rawText) return null;
  const text = rawText.trim().toLowerCase();

  // Helper to open window safely
  const launchUrl = (targetUrl: string) => {
    try {
      const win = window.open(targetUrl, '_blank', 'noopener,noreferrer');
      if (!win) {
        // In case popup blocked, fallback location or signal
        console.warn("Popup blocked by browser. Fallback action card will let user click.");
      }
    } catch (e) {
      console.warn("window.open blocked or restricted in iframe:", e);
    }
  };

  // 1. WhatsApp
  if (
    text.includes('whatsapp') ||
    text.includes('whats app') ||
    text.includes('whatsap') ||
    text.includes('watsapp')
  ) {
    if (
      text.includes('open') || 
      text.includes('kholo') || 
      text.includes('chalu') || 
      text.includes('start') || 
      text.includes('dekhao') || 
      text.includes('khol do') ||
      text.length < 20
    ) {
      const url = 'https://web.whatsapp.com';
      launchUrl(url);
      return {
        matched: true,
        actionName: 'WhatsApp',
        url,
        spokenReply: 'Ji haan! WhatsApp open kar raha hoon.',
        displayMessage: '✅ WhatsApp open ho gaya hai! Agar browser ne popup block kiya hai, toh niche diye gaye link par click karein:'
      };
    }
  }

  // 2. YouTube & Music / Videos
  if (
    text.includes('youtube') || 
    text.includes('you tube') || 
    text.includes('yt') || 
    text.startsWith('play ') || 
    text.includes('gana sunao') || 
    text.includes('song play karo')
  ) {
    if (
      text.includes('open') || 
      text.includes('kholo') || 
      text.includes('chalu') || 
      text.includes('play') || 
      text.includes('search') ||
      text.includes('video') ||
      text.length < 20
    ) {
      // Extract search query if any (e.g. "youtube open karke arijit singh ke gane chalao")
      let query = '';
      const clean = text
        .replace(/youtube|you tube|yt|open|kholo|chalu karo|play|karo|chalao|pe|par|search|ke|gane|song/gi, ' ')
        .trim();
      
      if (clean.length > 2) {
        query = clean;
      }

      const url = query 
        ? `https://www.youtube.com/results?search_query=${encodeURIComponent(query)}`
        : 'https://www.youtube.com';
      
      launchUrl(url);
      return {
        matched: true,
        actionName: 'YouTube',
        url,
        spokenReply: query 
          ? `Ji! YouTube par ${query} open kar diya hai.` 
          : 'Ji haan! YouTube open kar raha hoon.',
        displayMessage: query
          ? `✅ YouTube par "${query}" open kiya gaya hai:`
          : '✅ YouTube open ho gaya hai!'
      };
    }
  }

  // 3. Google Search & Google Open
  if (
    text.includes('google') ||
    text.startsWith('search ') ||
    text.includes('search karo')
  ) {
    if (
      text.includes('open') || 
      text.includes('kholo') || 
      text.includes('search') || 
      text.includes('par dhundo') ||
      text.length < 25
    ) {
      // Extract query
      let query = '';
      const clean = text
        .replace(/google|open|kholo|khol do|search karo|search|par|dhundo|batao/gi, ' ')
        .trim();

      if (clean.length > 1) {
        query = clean;
      }

      const url = query 
        ? `https://www.google.com/search?q=${encodeURIComponent(query)}`
        : 'https://www.google.com';

      launchUrl(url);
      return {
        matched: true,
        actionName: 'Google',
        url,
        spokenReply: query 
          ? `Ji! Google par "${query}" search kar diya hai.` 
          : 'Ji haan! Google open kar raha hoon.',
        displayMessage: query 
          ? `✅ Google search "${query}" open kiya gaya hai:` 
          : '✅ Google search engine open ho gaya hai!'
      };
    }
  }

  // 4. Gmail / Email
  if (
    text.includes('gmail') || 
    text.includes('email') || 
    text.includes('mail')
  ) {
    if (text.includes('open') || text.includes('kholo') || text.includes('check') || text.length < 15) {
      const url = 'https://mail.google.com';
      launchUrl(url);
      return {
        matched: true,
        actionName: 'Gmail',
        url,
        spokenReply: 'Ji! Aapka Gmail inbox open kar raha hoon.',
        displayMessage: '✅ Gmail open ho gaya hai!'
      };
    }
  }

  // 5. Google Maps / Navigation
  if (
    text.includes('maps') || 
    text.includes('map') || 
    text.includes('rasta') || 
    text.includes('location')
  ) {
    if (text.includes('open') || text.includes('kholo') || text.includes('dikhayein') || text.length < 20) {
      const clean = text.replace(/google|maps|map|open|kholo|rasta|location|dikhayein|ka/gi, ' ').trim();
      const url = clean.length > 2 
        ? `https://www.google.com/maps/search/${encodeURIComponent(clean)}`
        : 'https://maps.google.com';
      launchUrl(url);
      return {
        matched: true,
        actionName: 'Google Maps',
        url,
        spokenReply: clean.length > 2 
          ? `Ji! Google Maps par ${clean} ka rasta open kar raha hoon.`
          : 'Ji! Google Maps open kar raha hoon.',
        displayMessage: '✅ Google Maps open ho gaya hai!'
      };
    }
  }

  // 6. Instagram
  if (text.includes('instagram') || text.includes('insta')) {
    if (text.includes('open') || text.includes('kholo') || text.length < 15) {
      const url = 'https://www.instagram.com';
      launchUrl(url);
      return {
        matched: true,
        actionName: 'Instagram',
        url,
        spokenReply: 'Ji! Instagram open kar raha hoon.',
        displayMessage: '✅ Instagram open ho gaya hai!'
      };
    }
  }

  // 7. Facebook
  if (text.includes('facebook') || text.includes('fb')) {
    if (text.includes('open') || text.includes('kholo') || text.length < 15) {
      const url = 'https://www.facebook.com';
      launchUrl(url);
      return {
        matched: true,
        actionName: 'Facebook',
        url,
        spokenReply: 'Ji! Facebook open kar raha hoon.',
        displayMessage: '✅ Facebook open ho gaya hai!'
      };
    }
  }

  // 8. Twitter / X
  if (text.includes('twitter') || text === 'x' || text.includes('x open') || text.includes('open x')) {
    if (text.includes('open') || text.includes('kholo') || text.length < 15) {
      const url = 'https://x.com';
      launchUrl(url);
      return {
        matched: true,
        actionName: 'X (Twitter)',
        url,
        spokenReply: 'Ji! X (Twitter) open kar raha hoon.',
        displayMessage: '✅ X (Twitter) open ho gaya hai!'
      };
    }
  }

  // 9. Calculator
  if (text.includes('calculator') || text.includes('calc')) {
    if (text.includes('open') || text.includes('kholo') || text.length < 15) {
      const url = 'https://www.google.com/search?q=calculator';
      launchUrl(url);
      return {
        matched: true,
        actionName: 'Calculator',
        url,
        spokenReply: 'Ji! Calculator open kar diya hai.',
        displayMessage: '✅ Calculator open ho gaya hai!'
      };
    }
  }

  return null;
}
