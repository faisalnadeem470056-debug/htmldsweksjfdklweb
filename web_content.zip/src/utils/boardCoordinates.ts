import { PlayerColor } from '../types/game';

export interface GridCoord {
  row: number;
  col: number;
}

// 52 Cells on the circular track (0-indexed)
// Red start is index 0
export const MAIN_PATH: GridCoord[] = [
  // Red side moving clockwise (Left arm upper edge)
  { row: 6, col: 1 },  // 0: Red Start
  { row: 6, col: 2 },  // 1
  { row: 6, col: 3 },  // 2
  { row: 6, col: 4 },  // 3
  { row: 6, col: 5 },  // 4

  // Top arm left column going UP
  { row: 5, col: 6 },  // 5
  { row: 4, col: 6 },  // 6
  { row: 3, col: 6 },  // 7
  { row: 2, col: 6 },  // 8: Safe Star 1
  { row: 1, col: 6 },  // 9
  { row: 0, col: 6 },  // 10

  // Top Arm top row crossing right
  { row: 0, col: 7 },  // 11
  { row: 0, col: 8 },  // 12

  // Top arm right column going DOWN
  { row: 1, col: 8 },  // 13: Green Start
  { row: 2, col: 8 },  // 14
  { row: 3, col: 8 },  // 15
  { row: 4, col: 8 },  // 16
  { row: 5, col: 8 },  // 17

  // Right arm top row going RIGHT
  { row: 6, col: 9 },  // 18
  { row: 6, col: 10 }, // 19
  { row: 6, col: 11 }, // 20
  { row: 6, col: 12 }, // 21: Safe Star 2
  { row: 6, col: 13 }, // 22
  { row: 6, col: 14 }, // 23

  // Right arm right edge going DOWN
  { row: 7, col: 14 }, // 24
  { row: 8, col: 14 }, // 25

  // Right arm bottom row going LEFT
  { row: 8, col: 13 }, // 26: Yellow Start
  { row: 8, col: 12 }, // 27
  { row: 8, col: 11 }, // 28
  { row: 8, col: 10 }, // 29
  { row: 8, col: 9 },  // 30

  // Bottom arm right column going DOWN
  { row: 9, col: 8 },  // 31
  { row: 10, col: 8 }, // 32
  { row: 11, col: 8 }, // 33
  { row: 12, col: 8 }, // 34: Safe Star 3
  { row: 13, col: 8 }, // 35
  { row: 14, col: 8 }, // 36

  // Bottom arm bottom edge crossing LEFT
  { row: 14, col: 7 }, // 37
  { row: 14, col: 6 }, // 38

  // Bottom arm left column going UP
  { row: 13, col: 6 }, // 39: Blue Start
  { row: 12, col: 6 }, // 40
  { row: 11, col: 6 }, // 41
  { row: 10, col: 6 }, // 42
  { row: 9, col: 6 },  // 43

  // Left arm bottom row going LEFT
  { row: 8, col: 5 },  // 44
  { row: 8, col: 4 },  // 45
  { row: 8, col: 3 },  // 46
  { row: 8, col: 2 },  // 47: Safe Star 4
  { row: 8, col: 1 },  // 48
  { row: 8, col: 0 },  // 49

  // Left arm left edge
  { row: 7, col: 0 },  // 50
  { row: 6, col: 0 },  // 51
];

// Starting offset index on MAIN_PATH for each player
export const START_OFFSETS: Record<PlayerColor, number> = {
  red: 0,
  green: 13,
  yellow: 26,
  blue: 39,
};

// Safe squares on the 52-cell track: 4 start squares + 4 star squares
export const SAFE_TRACK_INDICES = new Set<number>([0, 8, 13, 21, 26, 34, 39, 47]);

// 5 colored cells on the home run for each player (step 51..55)
export const HOME_PATHS: Record<PlayerColor, GridCoord[]> = {
  red: [
    { row: 7, col: 1 },
    { row: 7, col: 2 },
    { row: 7, col: 3 },
    { row: 7, col: 4 },
    { row: 7, col: 5 },
  ],
  green: [
    { row: 1, col: 7 },
    { row: 2, col: 7 },
    { row: 3, col: 7 },
    { row: 4, col: 7 },
    { row: 5, col: 7 },
  ],
  yellow: [
    { row: 7, col: 13 },
    { row: 7, col: 12 },
    { row: 7, col: 11 },
    { row: 7, col: 10 },
    { row: 7, col: 9 },
  ],
  blue: [
    { row: 13, col: 7 },
    { row: 12, col: 7 },
    { row: 11, col: 7 },
    { row: 10, col: 7 },
    { row: 9, col: 7 },
  ],
};

// Center Goal positions (step 56)
export const GOAL_POSITIONS: Record<PlayerColor, GridCoord> = {
  red: { row: 7, col: 6.2 },
  green: { row: 6.2, col: 7 },
  yellow: { row: 7, col: 7.8 },
  blue: { row: 7.8, col: 7 },
};

// 4 Yard positions per color
export const YARD_POSITIONS: Record<PlayerColor, GridCoord[]> = {
  red: [
    { row: 1.7, col: 1.7 },
    { row: 1.7, col: 3.3 },
    { row: 3.3, col: 1.7 },
    { row: 3.3, col: 3.3 },
  ],
  green: [
    { row: 1.7, col: 10.7 },
    { row: 1.7, col: 12.3 },
    { row: 3.3, col: 10.7 },
    { row: 3.3, col: 12.3 },
  ],
  yellow: [
    { row: 10.7, col: 10.7 },
    { row: 10.7, col: 12.3 },
    { row: 12.3, col: 10.7 },
    { row: 12.3, col: 12.3 },
  ],
  blue: [
    { row: 10.7, col: 1.7 },
    { row: 10.7, col: 3.3 },
    { row: 12.3, col: 1.7 },
    { row: 12.3, col: 3.3 },
  ],
};

/**
 * Returns the track index (0..51) on MAIN_PATH for a player at step (0..50).
 */
export function getTrackIndex(color: PlayerColor, step: number): number {
  if (step < 0 || step > 50) return -1;
  const offset = START_OFFSETS[color];
  return (offset + step) % 52;
}

/**
 * Returns true if the token is currently on a safe square.
 */
export function isSafeSquare(color: PlayerColor, step: number): boolean {
  if (step === -1) return true; // in yard
  if (step >= 51) return true; // in home row or goal
  const trackIdx = getTrackIndex(color, step);
  return SAFE_TRACK_INDICES.has(trackIdx);
}

/**
 * Returns grid coordinates for a token at a given step.
 */
export function getTokenCoordinate(color: PlayerColor, tokenId: number, step: number): GridCoord {
  if (step === -1) {
    return YARD_POSITIONS[color][tokenId] || { row: 0, col: 0 };
  }
  if (step >= 0 && step <= 50) {
    const trackIdx = getTrackIndex(color, step);
    return MAIN_PATH[trackIdx];
  }
  if (step >= 51 && step <= 55) {
    const homeIdx = step - 51;
    return HOME_PATHS[color][homeIdx];
  }
  // step === 56 (Goal)
  return GOAL_POSITIONS[color];
}

/**
 * Returns an identifier key for a location to detect collisions/captures.
 */
export function getLocationKey(color: PlayerColor, tokenId: number, step: number): string {
  if (step === -1) {
    return `yard-${color}-${tokenId}`;
  }
  if (step >= 0 && step <= 50) {
    const trackIdx = getTrackIndex(color, step);
    return `track-${trackIdx}`;
  }
  if (step >= 51 && step <= 55) {
    return `home-${color}-${step}`;
  }
  return `goal-${color}`;
}
