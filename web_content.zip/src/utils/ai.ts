import { PlayerColor, Player } from '../types/game';
import { calculateMoveResult } from './ludoRules';
import { getTrackIndex, SAFE_TRACK_INDICES } from './boardCoordinates';

/**
 * Chooses the smartest token move for an AI player among legal options.
 */
export function chooseAiMove(
  color: PlayerColor,
  legalTokenIds: number[],
  diceRoll: number,
  allPlayers: Player[],
  rolledSix: boolean
): number {
  if (legalTokenIds.length === 1) {
    return legalTokenIds[0];
  }

  let bestScore = -Infinity;
  let bestTokenId = legalTokenIds[0];

  const player = allPlayers.find((p) => p.color === color)!;

  for (const tokenId of legalTokenIds) {
    const moveResult = calculateMoveResult(color, tokenId, diceRoll, allPlayers, rolledSix);
    let score = 0;

    // 1. Capture opponent piece (Highest priority!)
    if (moveResult.capturedToken) {
      score += 1200;
    }

    // 2. Reach final Goal (step 56)
    if (moveResult.reachedGoal) {
      score += 900;
    }

    // 3. Enter safe home column (51..55)
    if (moveResult.toStep >= 51 && moveResult.fromStep < 51) {
      score += 500;
    }

    // 4. Land on a safe star or start cell
    if (moveResult.toStep >= 0 && moveResult.toStep <= 50) {
      const targetTrackIdx = getTrackIndex(color, moveResult.toStep);
      if (SAFE_TRACK_INDICES.has(targetTrackIdx)) {
        score += 350;
      }
    }

    // 5. Release a piece from yard if rolled 6
    if (moveResult.fromStep === -1) {
      // Extra points if player has few active tokens on board
      const activeCount = player.tokens.filter((t) => t.step >= 0 && t.step < 56).length;
      score += 400 - activeCount * 40;
    }

    // 6. Escape danger: was current position vulnerable?
    if (moveResult.fromStep >= 0 && moveResult.fromStep <= 50) {
      const currentTrackIdx = getTrackIndex(color, moveResult.fromStep);
      if (!SAFE_TRACK_INDICES.has(currentTrackIdx)) {
        const isInDanger = allPlayers.some((opp) => {
          if (!opp.active || opp.color === color) return false;
          return opp.tokens.some((oppToken) => {
            if (oppToken.step < 0 || oppToken.step > 50) return false;
            const oppIdx = getTrackIndex(opp.color, oppToken.step);
            const dist = (currentTrackIdx - oppIdx + 52) % 52;
            return dist >= 1 && dist <= 6;
          });
        });
        if (isInDanger) {
          score += 300;
        }
      }
    }

    // 7. General progress towards goal
    score += moveResult.toStep * 5;

    // Small random tie-breaker to prevent robotic predictability
    score += Math.random() * 5;

    if (score > bestScore) {
      bestScore = score;
      bestTokenId = tokenId;
    }
  }

  return bestTokenId;
}
