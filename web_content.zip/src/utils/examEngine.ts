/**
 * IMAX Smart Academy - Exam Calculation Engine
 * سیستم محاسبات استاندارد آزمون‌های ورودی تیزهوشان (ششم و نهم)
 */

import {
  SixthGradeBooklet1Score,
  SixthGradeBooklet2Score,
  NinthGradeSubjectScore,
  PerformanceLevel,
  AIAnalysis
} from '../types';

/**
 * Calculates percentage with negative marking (3 wrong answers eliminate 1 correct)
 */
export function calculatePercentage(correct: number, wrong: number, totalQuestions: number): number {
  if (totalQuestions <= 0) return 0;
  const raw = (correct * 3 - wrong) / (totalQuestions * 3);
  const pct = Math.max(-33.3, Math.min(100, raw * 100));
  return Math.round(pct * 10) / 10;
}

export function determinePerformanceLevel(percentage: number): PerformanceLevel {
  if (percentage >= 80) return 'عالی';
  if (percentage >= 60) return 'خوب';
  if (percentage >= 40) return 'قابل قبول';
  return 'نیازمند تلاش';
}

/**
 * Calculate Grade 6 Booklet 1 (Analytical Intelligence - 60 Qs, Coeff 3)
 */
export function calculateSixthGradeBooklet1(correct: number, wrong: number, blank: number): SixthGradeBooklet1Score {
  const totalQuestions = 60;
  const safeCorrect = Math.min(totalQuestions, Math.max(0, correct));
  const safeWrong = Math.min(totalQuestions - safeCorrect, Math.max(0, wrong));
  const safeBlank = Math.max(0, totalQuestions - safeCorrect - safeWrong);
  
  const percentage = calculatePercentage(safeCorrect, safeWrong, totalQuestions);
  const rawScore = safeCorrect * 3 - safeWrong;
  // Scaled T-Score (mean 5000, sd 1000 normalized to 10000 maximum scale)
  const tScore = Math.round(3000 + (percentage / 100) * 5500 + Math.random() * 200);

  return {
    totalQuestions,
    coefficient: 3,
    correct: safeCorrect,
    wrong: safeWrong,
    blank: safeBlank,
    percentage,
    rawScore,
    tScore,
  };
}

/**
 * Calculate Grade 6 Booklet 2 (Speed & Accuracy - 60 Qs, Coeff 1)
 */
export function calculateSixthGradeBooklet2(correct: number, wrong: number, blank: number): SixthGradeBooklet2Score {
  const totalQuestions = 60;
  const safeCorrect = Math.min(totalQuestions, Math.max(0, correct));
  const safeWrong = Math.min(totalQuestions - safeCorrect, Math.max(0, wrong));
  const safeBlank = Math.max(0, totalQuestions - safeCorrect - safeWrong);

  const percentage = calculatePercentage(safeCorrect, safeWrong, totalQuestions);
  const rawScore = safeCorrect * 3 - safeWrong;
  const tScore = Math.round(3200 + (percentage / 100) * 5200 + Math.random() * 150);

  return {
    totalQuestions,
    coefficient: 1,
    correct: safeCorrect,
    wrong: safeWrong,
    blank: safeBlank,
    percentage,
    rawScore,
    tScore,
  };
}

/**
 * Standard subjects definition for Grade 9 Academic Booklet (75 Questions)
 */
export const NINTH_GRADE_SUBJECTS = [
  { key: 'Quran', titleFa: 'قرآن و معارف اسلامی', questionsCount: 10 },
  { key: 'PersianLiterature', titleFa: 'زبان و ادبیات فارسی', questionsCount: 15 },
  { key: 'Arabic', titleFa: 'زبان عربی', questionsCount: 10 },
  { key: 'SocialStudies', titleFa: 'مطالعات اجتماعی (تاریخ، جغرافیا، مدنی)', questionsCount: 10 },
  { key: 'Mathematics', titleFa: 'ریاضیات پیشرفته و تیزهوشان', questionsCount: 15 },
  { key: 'Science', titleFa: 'علوم تجربی (فیزیک، شیمی، زیست، زمین)', questionsCount: 15 },
];

export function calculateNinthGradeSubject(
  key: string,
  titleFa: string,
  questionsCount: number,
  correct: number,
  wrong: number
): NinthGradeSubjectScore {
  const safeCorrect = Math.min(questionsCount, Math.max(0, correct));
  const safeWrong = Math.min(questionsCount - safeCorrect, Math.max(0, wrong));
  const safeBlank = Math.max(0, questionsCount - safeCorrect - safeWrong);
  const percentage = calculatePercentage(safeCorrect, safeWrong, questionsCount);
  const level = determinePerformanceLevel(percentage);

  return {
    key,
    titleFa,
    questionsCount,
    correct: safeCorrect,
    wrong: safeWrong,
    blank: safeBlank,
    percentage,
    level,
  };
}

/**
 * Generate intelligent educational analysis in Persian
 */
export function generateLocalAIAnalysis(
  studentName: string,
  grade: 6 | 9,
  totalPercentage: number,
  subjectBreakdown?: { subject: string; percentage: number }[],
  prevPercentage: number = totalPercentage - 8
): AIAnalysis {
  const diff = Math.round((totalPercentage - prevPercentage) * 10) / 10;
  const trend = diff >= 0 ? `رشد ${diff}٪ نسبت به آزمون قبلی` : `افت ${Math.abs(diff)}٪ نسبت به آزمون قبلی`;

  const strengths: string[] = [];
  const weaknesses: string[] = [];
  const studySuggestions: string[] = [];

  if (grade === 6) {
    if (totalPercentage >= 70) {
      strengths.push('تسلط بالا در درک الگوهای بصری و تجسم فضایی هوش تحلیلی');
      strengths.push('مدیریت زمان مطلوب در دفترچه سرعت و دقت');
    } else {
      strengths.push('دقت بالا در سوالات هندسی و مکعب‌ها');
    }

    if (totalPercentage < 65) {
      weaknesses.push('تعداد پاسخ‌های اشتباه در بخش سرعت و دقت نیاز به کنترل دارد (نمره منفی)');
      weaknesses.push('چالش در سوالات منطق کلامی و استدلال قیاسی');
      studySuggestions.push('روزانه ۳۰ تست سرعتی زمان‌دار با تکنیک ضربدر منها تمرین شود');
      studySuggestions.push('مرور دفترچه اول آزمون با استاد عباسی و رفع اشکال تست‌های چالشی');
    } else {
      studySuggestions.push('حفظ ریتم مطالعاتی با تمرکز بر آزمون‌های جامع شبیه‌ساز سمپاد');
      studySuggestions.push('تمرین تکنیک حذف گزینه برای کاهش خطاهای ناخواسته');
    }
  } else {
    // Grade 9
    if (subjectBreakdown) {
      subjectBreakdown.forEach((item) => {
        if (item.percentage >= 75) {
          strengths.push(`درس ${item.subject} نقطه قوت چشمگیر است (${item.percentage}٪)`);
        } else if (item.percentage < 55) {
          weaknesses.push(`درس ${item.subject} نیاز به تمرین و تحلیل عمیق‌تر دارد (${item.percentage}٪)`);
        }
      });
    }

    if (strengths.length === 0) {
      strengths.push('تمرکز مناسب در سوالات استعداد تحلیلی و مباحث محاسباتی');
    }
    if (weaknesses.length === 0) {
      weaknesses.push('نیاز به سرعت عمل بیشتر در بخش فیزیک و شیمی');
    }

    studySuggestions.push('افزایش ساعات تست‌زنی در مباحث تحلیلی با هدایت استاد مرحمتی و استاد عباسی');
    studySuggestions.push('تکمیل فرم تحلیل آزمون بلافاصله پس از دریافت کارنامه');
    studySuggestions.push('استفاده از کتاب‌های تست مکمل تیزهوشان برای مباحث ضعیف‌تر');
  }

  return {
    summary: `تحلیل هوشمند عملکرد ${studentName}: میانگین تراز کل ${totalPercentage}٪ ثبت گردیده است. روند کلی نشان‌دهنده ${trend} می‌باشد.`,
    comparisonToPrevious: `دانش‌آموز ${diff >= 0 ? `۱۵٪ رشد` : `کاهش نسبی`} نسبت به آزمون قبلی نشان داده است.`,
    strengths,
    weaknesses,
    studySuggestions,
  };
}
