import html2canvas from 'html2canvas';
import jsPDF from 'jspdf';

export interface PdfExportOptions {
  fileName?: string;
  onProgress?: (step: string) => void;
}

/**
 * Client-side PDF generation utility for the analytical report card
 * Captures the official Persian report card DOM with exact styling, typography, tables, and stamps
 * and converts it into a high-resolution, vector-positioned A4 PDF document.
 */
export async function exportReportCardToPdf(
  element: HTMLElement,
  options: PdfExportOptions = {}
): Promise<void> {
  const { fileName = 'Karname-IMAX-ReportCard.pdf', onProgress } = options;

  if (!element) {
    throw new Error('المان کارنامه جهت تبدیل به PDF یافت نشد.');
  }

  onProgress?.('در حال آماده‌سازی کارنامه...');

  // Temporary style adjustment for optimal capturing
  const originalWidth = element.style.width;
  const originalMaxWidth = element.style.maxWidth;

  try {
    onProgress?.('در حال رندر و پردازش گرافیکی با کیفیت بالا...');

    // High DPI canvas capture (scale: 2 ensures sharp text and fine borders)
    const canvas = await html2canvas(element, {
      scale: 2,
      useCORS: true,
      allowTaint: true,
      logging: false,
      backgroundColor: '#ffffff',
      windowWidth: element.scrollWidth,
      windowHeight: element.scrollHeight,
      onclone: (clonedDoc) => {
        // Ensure any hidden action bars or print-hidden elements are properly hidden
        const printHiddenElements = clonedDoc.querySelectorAll('.print\\:hidden, [data-pdf-ignore="true"]');
        printHiddenElements.forEach((el) => {
          (el as HTMLElement).style.display = 'none';
        });
      }
    });

    onProgress?.('در حال تولید فایل سند رسمی PDF...');

    // A4 Dimensions in mm
    const pdf = new jsPDF({
      orientation: 'portrait',
      unit: 'mm',
      format: 'a4',
      compress: true
    });

    const pageWidth = pdf.internal.pageSize.getWidth();
    const pageHeight = pdf.internal.pageSize.getHeight();

    // Margins (in mm)
    const margin = 8;
    const contentWidth = pageWidth - margin * 2;
    const contentHeight = (canvas.height * contentWidth) / canvas.width;

    const imgData = canvas.toDataURL('image/jpeg', 0.98);

    // If it fits into a single A4 page comfortably (or with slight scaling)
    if (contentHeight <= pageHeight - margin * 2) {
      pdf.addImage(imgData, 'JPEG', margin, margin, contentWidth, contentHeight);
    } else {
      // Multi-page handling
      let heightLeft = contentHeight;
      let position = margin;
      let pageNumber = 1;

      // First page
      pdf.addImage(imgData, 'JPEG', margin, position, contentWidth, contentHeight);
      heightLeft -= (pageHeight - margin * 2);

      // Remaining pages
      while (heightLeft > 0) {
        pdf.addPage();
        pageNumber++;
        position = margin - (pageNumber - 1) * (pageHeight - margin * 2);
        pdf.addImage(imgData, 'JPEG', margin, position, contentWidth, contentHeight);
        heightLeft -= (pageHeight - margin * 2);
      }
    }

    onProgress?.('در حال دانلود فایل...');
    pdf.save(fileName);
  } finally {
    // Restore original styles
    element.style.width = originalWidth;
    element.style.maxWidth = originalMaxWidth;
  }
}
