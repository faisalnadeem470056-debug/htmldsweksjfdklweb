import { GameStats, PlayerColor } from '../types/game';

const STATS_KEY = 'ars_ludo_stats';
const HISTORY_KEY = 'ars_ludo_history';

export interface MatchRecord {
  id: string;
  date: string;
  winnerColor: PlayerColor;
  winnerName: string;
  mode: string;
  turns: number;
  captures: number;
}

const defaultStats: GameStats = {
  gamesPlayed: 0,
  gamesWon: 0,
  redWins: 0,
  greenWins: 0,
  yellowWins: 0,
  blueWins: 0,
  tokensCaptured: 0,
  tokensLost: 0,
  tokensHome: 0,
  sixesRolled: 0,
  highestStreak: 0,
};

export function getStats(): GameStats {
  try {
    const data = localStorage.getItem(STATS_KEY);
    if (data) {
      return { ...defaultStats, ...JSON.parse(data) };
    }
  } catch {
    // fallback
  }
  return { ...defaultStats };
}

export function saveStats(stats: GameStats): void {
  try {
    localStorage.setItem(STATS_KEY, JSON.stringify(stats));
  } catch {
    // ignore
  }
}

export function recordStatsDelta(delta: Partial<GameStats>): GameStats {
  const current = getStats();
  const updated: GameStats = {
    gamesPlayed: current.gamesPlayed + (delta.gamesPlayed || 0),
    gamesWon: current.gamesWon + (delta.gamesWon || 0),
    redWins: current.redWins + (delta.redWins || 0),
    greenWins: current.greenWins + (delta.greenWins || 0),
    yellowWins: current.yellowWins + (delta.yellowWins || 0),
    blueWins: current.blueWins + (delta.blueWins || 0),
    tokensCaptured: current.tokensCaptured + (delta.tokensCaptured || 0),
    tokensLost: current.tokensLost + (delta.tokensLost || 0),
    tokensHome: current.tokensHome + (delta.tokensHome || 0),
    sixesRolled: current.sixesRolled + (delta.sixesRolled || 0),
    highestStreak: Math.max(current.highestStreak, delta.highestStreak || 0),
  };
  saveStats(updated);
  return updated;
}

export function getMatchHistory(): MatchRecord[] {
  try {
    const data = localStorage.getItem(HISTORY_KEY);
    if (data) {
      return JSON.parse(data);
    }
  } catch {
    // ignore
  }
  return [];
}

export function addMatchRecord(record: MatchRecord): void {
  try {
    const history = getMatchHistory();
    history.unshift(record);
    // keep max 20 matches
    localStorage.setItem(HISTORY_KEY, JSON.stringify(history.slice(0, 20)));
  } catch {
    // ignore
  }
}

export function resetAllStats(): void {
  localStorage.removeItem(STATS_KEY);
  localStorage.removeItem(HISTORY_KEY);
}
