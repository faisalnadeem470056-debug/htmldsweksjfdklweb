import { PlayerColor, Token, Player } from '../types/game';
import { getTrackIndex, SAFE_TRACK_INDICES } from './boardCoordinates';

export interface MoveResult {
  tokenId: number;
  fromStep: number;
  toStep: number;
  capturedToken?: {
    color: PlayerColor;
    tokenId: number;
  };
  reachedGoal: boolean;
  grantsBonusTurn: boolean;
}

/**
 * Returns true if a specific token can legally move given the dice roll.
 */
export function canTokenMove(token: Token, diceRoll: number): boolean {
  if (token.step === 56) {
    // Already in home goal
    return false;
  }

  if (token.step === -1) {
    // Token in yard can only exit on a 6
    return diceRoll === 6;
  }

  // Token on track or home column: must not overshoot 56
  return token.step + diceRoll <= 56;
}

/**
 * Returns all token IDs for a player that can legally move with the current dice roll.
 */
export function getLegalMoves(player: Player, diceRoll: number): number[] {
  const legalTokenIds: number[] = [];

  for (const token of player.tokens) {
    if (canTokenMove(token, diceRoll)) {
      legalTokenIds.push(token.id);
    }
  }

  return legalTokenIds;
}

/**
 * Evaluates the outcome of moving a token by the dice roll.
 */
export function calculateMoveResult(
  activeColor: PlayerColor,
  tokenId: number,
  diceRoll: number,
  allPlayers: Player[],
  rolledSix: boolean
): MoveResult {
  const player = allPlayers.find((p) => p.color === activeColor);
  if (!player) throw new Error(`Player ${activeColor} not found`);

  const token = player.tokens.find((t) => t.id === tokenId);
  if (!token) throw new Error(`Token ${tokenId} not found`);

  const fromStep = token.step;
  let toStep: number;

  if (fromStep === -1) {
    toStep = 0; // Exits to start square
  } else {
    toStep = fromStep + diceRoll;
  }

  let capturedToken: { color: PlayerColor; tokenId: number } | undefined;
  let grantsBonusTurn = rolledSix;

  // Check if target is on the main track (0..50) and can capture an opponent
  if (toStep >= 0 && toStep <= 50) {
    const targetTrackIdx = getTrackIndex(activeColor, toStep);
    const isSafe = SAFE_TRACK_INDICES.has(targetTrackIdx);

    if (!isSafe) {
      // Find any opponent token currently at targetTrackIdx
      for (const opponent of allPlayers) {
        if (!opponent.active || opponent.color === activeColor) continue;

        for (const opToken of opponent.tokens) {
          if (opToken.step >= 0 && opToken.step <= 50) {
            const opTrackIdx = getTrackIndex(opponent.color, opToken.step);
            if (opTrackIdx === targetTrackIdx) {
              capturedToken = {
                color: opponent.color,
                tokenId: opToken.id,
              };
              grantsBonusTurn = true; // Capturing grants a bonus turn!
              break;
            }
          }
        }
        if (capturedToken) break;
      }
    }
  }

  const reachedGoal = toStep === 56;
  if (reachedGoal) {
    grantsBonusTurn = true; // Reaching goal grants a bonus turn!
  }

  return {
    tokenId,
    fromStep,
    toStep,
    capturedToken,
    reachedGoal,
    grantsBonusTurn,
  };
}

/**
 * Checks if a player has won (all 4 tokens at step 56).
 */
export function checkPlayerWon(player: Player): boolean {
  return player.tokens.every((t) => t.step === 56);
}

/**
 * Returns the next player's turn in clockwise order:
 * red -> green -> yellow -> blue
 */
export function getNextPlayerColor(currentColor: PlayerColor, players: Player[]): PlayerColor {
  const order: PlayerColor[] = ['red', 'green', 'yellow', 'blue'];
  let idx = order.indexOf(currentColor);

  for (let i = 1; i <= 4; i++) {
    const nextColor = order[(idx + i) % 4];
    const player = players.find((p) => p.color === nextColor);
    // Move to next player if active and hasn't won yet
    if (player && player.active && !player.hasWon) {
      return nextColor;
    }
  }

  return currentColor;
}
