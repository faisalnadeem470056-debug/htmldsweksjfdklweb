import React, { StrictMode, useState, useEffect, Component, ReactNode } from 'react';
import { createRoot } from 'react-dom/client';
import App from './App.tsx';
import './index.css';
import { GoogleOAuthProvider } from '@react-oauth/google';

const DEFAULT_CLIENT_ID = "121551296-un1c6j25aqahp0aat04bkn6ql70s1922.apps.googleusercontent.com";

interface ErrorBoundaryProps {
  children: ReactNode;
}

interface ErrorBoundaryState {
  hasError: boolean;
  error?: Error;
}

class ErrorBoundary extends Component<ErrorBoundaryProps, ErrorBoundaryState> {
  constructor(props: ErrorBoundaryProps) {
    super(props);
    this.state = { hasError: false };
  }

  static getDerivedStateFromError(error: Error): ErrorBoundaryState {
    return { hasError: true, error };
  }

  componentDidCatch(error: Error, errorInfo: any) {
    console.error("App Crash caught by ErrorBoundary:", error, errorInfo);
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="flex flex-col items-center justify-center min-h-screen bg-slate-950 text-white p-6 text-center">
          <div className="w-16 h-16 bg-orange-600/20 text-orange-500 rounded-2xl flex items-center justify-center text-2xl font-bold mb-4 border border-orange-500/30">
            GPT
          </div>
          <h1 className="text-2xl font-bold mb-2">India Chat GPT Ko Reload Karein</h1>
          <p className="text-slate-400 max-w-md mb-6 text-sm">
            App open hone me thodi dikkat aayi. Neeche diye gaye button par click karke turant open karein.
          </p>
          <div className="flex gap-3">
            <button
              onClick={() => {
                localStorage.removeItem('india_ai_user_name');
                window.location.reload();
              }}
              className="px-5 py-2.5 bg-gradient-to-r from-orange-500 to-amber-500 hover:from-orange-600 hover:to-amber-600 text-white font-bold rounded-xl text-sm transition-all shadow-md"
            >
              Reset & Open App
            </button>
            <button
              onClick={() => window.location.reload()}
              className="px-5 py-2.5 bg-slate-800 hover:bg-slate-700 text-white font-semibold rounded-xl text-sm transition-all border border-slate-700"
            >
              Refresh Page
            </button>
          </div>
        </div>
      );
    }
    return this.props.children;
  }
}

// Global unhandled error resilience to prevent blank white screens
if (typeof window !== 'undefined') {
  window.addEventListener('error', (event) => {
    console.warn('Recovered from global window error:', event.message);
  });
  window.addEventListener('unhandledrejection', (event) => {
    console.warn('Recovered from unhandled promise rejection:', event.reason);
  });
}

function SafeGoogleWrapper({ clientId, children }: { clientId: string; children: ReactNode }) {
  const activeClientId = clientId?.trim() || DEFAULT_CLIENT_ID;

  return (
    <GoogleOAuthProvider 
      clientId={activeClientId}
      onScriptLoadError={() => {
        console.warn("Google OAuth external script blocked or slow. App continues seamlessly.");
      }}
    >
      {children}
    </GoogleOAuthProvider>
  );
}

function RootApp() {
  const [clientId, setClientId] = useState<string>(DEFAULT_CLIENT_ID);

  useEffect(() => {
    fetch('/api/config')
      .then(res => res.json())
      .then(data => {
        if (data?.googleClientId) {
          setClientId(data.googleClientId);
        }
      })
      .catch((err) => {
        console.warn("Could not fetch Google Client ID, using default fallback:", err);
      });
  }, []);

  return (
    <ErrorBoundary>
      <SafeGoogleWrapper clientId={clientId || DEFAULT_CLIENT_ID}>
        <App />
      </SafeGoogleWrapper>
    </ErrorBoundary>
  );
}

const rootElement = document.getElementById('root');
if (rootElement) {
  createRoot(rootElement).render(
    <StrictMode>
      <RootApp />
    </StrictMode>
  );
}

