/**
 * IMAX Smart Academy - Central Data Store & Firebase Sync
 * این ماژول داده‌های پایه، وضعیت نشست‌ها، پرداخت‌ها، کلاس‌ها و آزمون‌ها را نگهداری و ذخیره می‌کند.
 */

import {
  User,
  Teacher,
  ClassItem,
  Student,
  SessionItem,
  PaymentItem,
  ExamResult,
  ExamDefinition,
  AIAnalysis
} from '../types';
import { calculatePercentage, determinePerformanceLevel } from '../utils/examEngine';

const STORAGE_KEY = 'imax_academy_data_v3';

export interface AppDataState {
  users: User[];
  teachers: Teacher[];
  classes: ClassItem[];
  students: Student[];
  sessions: SessionItem[];
  payments: PaymentItem[];
  exams: ExamDefinition[];
  results: ExamResult[];
}

export const INITIAL_DATA: AppDataState = {
  users: [
    {
      id: 'usr-admin-1',
      name: 'مهندس حسینی (مدیریت کل آموزشگاه آی‌مکس)',
      phone: '09121112233',
      role: 'admin',
      avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80'
    },
    {
      id: 'teacher-abbasi',
      name: 'عباسی',
      fullName: 'استاد یامین عباسی',
      phone: '09123456789',
      role: 'teacher',
      avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80'
    },
    {
      id: 'teacher-marhamati',
      name: 'مرحمتی',
      fullName: 'استاد علیرضا مرحمتی',
      phone: '09129876543',
      role: 'teacher',
      avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150&auto=format&fit=crop&q=80'
    },
    {
      id: 'parent-ali',
      name: 'ولی دانش‌آموز علی احمدی',
      phone: '09123334455',
      role: 'parent',
      avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&auto=format&fit=crop&q=80'
    },
    {
      id: 'student-ali',
      name: 'علی احمدی',
      phone: '09123334455',
      role: 'student',
      avatar: 'https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?w=150&auto=format&fit=crop&q=80'
    }
  ],
  teachers: [
    {
      teacherId: 'teacher-abbasi',
      name: 'عباسی',
      fullName: 'استاد یامین عباسی',
      assignedClasses: [
        'cls-third-abbasi',
        'cls-fourth-abbasi',
        'cls-fifth-a',
        'cls-sixth-a',
        'cls-ninth-a'
      ],
      phone: '09123456789',
      subject: 'هوش محاسباتی و خلاقیت',
      photo: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80'
    },
    {
      teacherId: 'teacher-marhamati',
      name: 'مرحمتی',
      fullName: 'استاد علیرضا مرحمتی',
      assignedClasses: [
        'cls-third-marhamati',
        'cls-fourth-marhamati',
        'cls-fifth-b',
        'cls-sixth-b',
        'cls-ninth-b'
      ],
      phone: '09129876543',
      subject: 'هوش کلامی و منطقی',
      photo: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150&auto=format&fit=crop&q=80'
    }
  ],
  classes: [
    // Grade 3 (Independent classes per teacher)
    {
      classId: 'cls-third-abbasi',
      className: 'کلاس هوش و محاسبات خلاق سوم (استاد عباسی)',
      grade: 3,
      teacherId: 'teacher-abbasi',
      isJointTeaching: false,
      schedule: 'شنبه‌ها و سه‌شنبه‌ها ۱۵:۳۰ الی ۱۷:۰۰',
      students: ['std-bardia-3']
    },
    {
      classId: 'cls-third-marhamati',
      className: 'کلاس درک مطلب و هوش زبانی سوم (استاد مرحمتی)',
      grade: 3,
      teacherId: 'teacher-marhamati',
      isJointTeaching: false,
      schedule: 'یکشنبه‌ها و چهارشنبه‌ها ۱۵:۳۰ الی ۱۷:۰۰',
      students: ['std-bardia-3']
    },
    // Grade 4 (Independent classes per teacher)
    {
      classId: 'cls-fourth-abbasi',
      className: 'کلاس ریاضی پیشرفته و تفکر الگوریتمی چهارم (استاد عباسی)',
      grade: 4,
      teacherId: 'teacher-abbasi',
      isJointTeaching: false,
      schedule: 'دوشنبه‌ها و پنج‌شنبه‌ها ۱۶:۰۰ الی ۱۷:۳۰',
      students: ['std-nima-4']
    },
    {
      classId: 'cls-fourth-marhamati',
      className: 'کلاس هوش کلامی و دقت چهارم (استاد مرحمتی)',
      grade: 4,
      teacherId: 'teacher-marhamati',
      isJointTeaching: false,
      schedule: 'یکشنبه‌ها و سه‌شنبه‌ها ۱۶:۰۰ الی ۱۷:۳۰',
      students: ['std-nima-4']
    },
    // Grade 5 (Joint Teaching: Abbasi & Marhamati)
    {
      classId: 'cls-fifth-a',
      className: 'کلاس پنجم تیزهوشان (هوش محاسباتی و خلاقیت استاد عباسی)',
      grade: 5,
      teacherId: 'teacher-abbasi',
      isJointTeaching: true,
      schedule: 'دوشنبه‌ها ۱۷:۰۰ الی ۱۸:۳۰',
      students: ['std-artin-5']
    },
    {
      classId: 'cls-fifth-b',
      className: 'کلاس پنجم تیزهوشان (هوش کلامی و منطقی استاد مرحمتی)',
      grade: 5,
      teacherId: 'teacher-marhamati',
      isJointTeaching: true,
      schedule: 'چهارشنبه‌ها ۱۷:۰۰ الی ۱۸:۳۰',
      students: ['std-artin-5']
    },
    // Grade 6 (Joint Teaching: Abbasi & Marhamati)
    {
      classId: 'cls-sixth-a',
      className: 'کلاس ششم تیزهوشان - گروه الف (هوش محاسباتی و خلاقیت استاد عباسی)',
      grade: 6,
      teacherId: 'teacher-abbasi',
      isJointTeaching: true,
      schedule: 'سه‌شنبه‌ها و پنج‌شنبه‌ها ۱۷:۰۰ الی ۱۹:۰۰',
      students: ['std-ali-1', 'std-sara-2', 'std-reza-3']
    },
    {
      classId: 'cls-sixth-b',
      className: 'کلاس ششم تیزهوشان - گروه ب (هوش کلامی و منطقی استاد مرحمتی)',
      grade: 6,
      teacherId: 'teacher-marhamati',
      isJointTeaching: true,
      schedule: 'یکشنبه‌ها و سه‌شنبه‌ها ۱۸:۰۰ الی ۱۹:۴۵',
      students: ['std-ali-1', 'std-sara-2', 'std-reza-3']
    },
    // Grade 9 (Joint Teaching: Abbasi & Marhamati)
    {
      classId: 'cls-ninth-a',
      className: 'کلاس نهم تیزهوشان (ریاضیات و هوش تحلیلی استاد عباسی)',
      grade: 9,
      teacherId: 'teacher-abbasi',
      isJointTeaching: true,
      schedule: 'جمعه‌ها ۹:۰۰ الی ۱۱:۰۰',
      students: ['std-yalda-9', 'std-pouya-9', 'std-artin-9']
    },
    {
      classId: 'cls-ninth-b',
      className: 'کلاس نهم تیزهوشان (استعداد کلامی و علوم استاد مرحمتی)',
      grade: 9,
      teacherId: 'teacher-marhamati',
      isJointTeaching: true,
      schedule: 'جمعه‌ها ۱۱:۱۵ الی ۱۳:۱۵',
      students: ['std-yalda-9', 'std-pouya-9', 'std-artin-9']
    }
  ],
  students: [
    // Grade 3 Student
    {
      studentId: 'std-bardia-3',
      fullName: 'بردیا صادقی',
      photo: 'https://images.unsplash.com/photo-1543610892-0b1f7e6d8ac1?w=200&auto=format&fit=crop&q=80',
      grade: 3,
      parentPhone: '09121114477',
      classId: 'cls-third-abbasi',
      nationalCode: '0031122334',
      activeCycleSessions: 2,
      currentCycleNumber: 1
    },
    // Grade 4 Student
    {
      studentId: 'std-nima-4',
      fullName: 'نیما کریمی',
      photo: 'https://images.unsplash.com/photo-1544717305-2782549b5136?w=200&auto=format&fit=crop&q=80',
      grade: 4,
      parentPhone: '09122225588',
      classId: 'cls-fourth-abbasi',
      nationalCode: '0029988776',
      activeCycleSessions: 4,
      currentCycleNumber: 1
    },
    // Grade 5 Student (Joint Teaching)
    {
      studentId: 'std-artin-5',
      fullName: 'آرتین رهنما',
      photo: 'https://images.unsplash.com/photo-1508214751196-bcfd4ca60f91?w=200&auto=format&fit=crop&q=80',
      grade: 5,
      parentPhone: '09123336699',
      classId: 'cls-fifth-a',
      nationalCode: '0027766554',
      activeCycleSessions: 6, // Orange status
      currentCycleNumber: 1
    },
    // Grade 6 Students (Joint Teaching)
    {
      studentId: 'std-ali-1',
      fullName: 'علی احمدی',
      photo: 'https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?w=200&auto=format&fit=crop&q=80',
      grade: 6,
      parentPhone: '09123334455',
      classId: 'cls-sixth-a',
      nationalCode: '0021345678',
      activeCycleSessions: 3, // < 5 (Yellow status)
      currentCycleNumber: 2
    },
    {
      studentId: 'std-sara-2',
      fullName: 'سارا راد',
      photo: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=200&auto=format&fit=crop&q=80',
      grade: 6,
      parentPhone: '09124445566',
      classId: 'cls-sixth-a',
      nationalCode: '0029876543',
      activeCycleSessions: 5, // 5 sessions (Orange status: "زمان پرداخت دوره جدید نزدیک است")
      currentCycleNumber: 1
    },
    {
      studentId: 'std-reza-3',
      fullName: 'محمدرضا یوسفی',
      photo: 'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=200&auto=format&fit=crop&q=80',
      grade: 6,
      parentPhone: '09125556677',
      classId: 'cls-sixth-a',
      nationalCode: '0018899776',
      activeCycleSessions: 8, // 8 sessions (Red status: "لطفاً شهریه دوره جدید پرداخت شود")
      currentCycleNumber: 1
    },
    // Grade 9 Students (Joint Teaching)
    {
      studentId: 'std-yalda-9',
      fullName: 'یلدا کمالی',
      photo: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=200&auto=format&fit=crop&q=80',
      grade: 9,
      parentPhone: '09127778899',
      classId: 'cls-ninth-a',
      nationalCode: '0034455667',
      activeCycleSessions: 2,
      currentCycleNumber: 3
    },
    {
      studentId: 'std-pouya-9',
      fullName: 'پویا باقری',
      photo: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=200&auto=format&fit=crop&q=80',
      grade: 9,
      parentPhone: '09128889900',
      classId: 'cls-ninth-a',
      nationalCode: '0032211998',
      activeCycleSessions: 9, // Red status
      currentCycleNumber: 2
    },
    {
      studentId: 'std-artin-9',
      fullName: 'آرتین صادقی',
      photo: 'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?w=200&auto=format&fit=crop&q=80',
      grade: 9,
      parentPhone: '09129990011',
      classId: 'cls-ninth-a',
      nationalCode: '0036677881',
      activeCycleSessions: 5, // Orange status
      currentCycleNumber: 1
    }
  ],
  sessions: [
    // Grade 3 Sessions
    {
      sessionId: 'ses-third-1',
      classId: 'cls-third-abbasi',
      className: 'کلاس هوش و محاسبات خلاق سوم (استاد عباسی)',
      teacherId: 'teacher-abbasi',
      teacherName: 'عباسی',
      PersianDate: '1405/07/08',
      time: '15:30',
      sessionNumber: 1,
      topic: 'مفاهیم اولیه الگوهای عددی و تفکر هندسی پایه سوم'
    },
    {
      sessionId: 'ses-third-2',
      classId: 'cls-third-marhamati',
      className: 'کلاس درک مطلب و هوش زبانی سوم (استاد مرحمتی)',
      teacherId: 'teacher-marhamati',
      teacherName: 'مرحمتی',
      PersianDate: '1405/07/09',
      time: '15:30',
      sessionNumber: 1,
      topic: 'تقویت درک متن و گسترش دایره واژگان'
    },
    // Grade 4 Sessions
    {
      sessionId: 'ses-fourth-1',
      classId: 'cls-fourth-abbasi',
      className: 'کلاس ریاضی پیشرفته و تفکر الگوریتمی چهارم (استاد عباسی)',
      teacherId: 'teacher-abbasi',
      teacherName: 'عباسی',
      PersianDate: '1405/07/11',
      time: '16:00',
      sessionNumber: 1,
      topic: 'استراتژی‌های رسم شکل و حل مسئله چهارم'
    },
    // Grade 5 Sessions (Joint Teaching)
    {
      sessionId: 'ses-fifth-1',
      classId: 'cls-fifth-a',
      className: 'کلاس پنجم تیزهوشان (هوش محاسباتی و خلاقیت استاد عباسی)',
      teacherId: 'teacher-abbasi',
      teacherName: 'عباسی',
      PersianDate: '1405/07/10',
      time: '17:00',
      sessionNumber: 1,
      topic: 'مبانی هوش محاسباتی و مکعب‌های سه‌بعدی'
    },
    {
      sessionId: 'ses-fifth-2',
      classId: 'cls-fifth-b',
      className: 'کلاس پنجم تیزهوشان (هوش کلامی و منطقی استاد مرحمتی)',
      teacherId: 'teacher-marhamati',
      teacherName: 'مرحمتی',
      PersianDate: '1405/07/12',
      time: '17:00',
      sessionNumber: 1,
      topic: 'استدلال منطقی و تناسب‌های واژگانی پایه پنجم'
    },
    // Grade 6 Sessions (Joint Teaching)
    {
      sessionId: 'ses-abbasi-1',
      classId: 'cls-sixth-a',
      className: 'کلاس ششم تیزهوشان - گروه الف (تحلیلی عباسی)',
      teacherId: 'teacher-abbasi',
      teacherName: 'عباسی',
      PersianDate: '1405/07/10',
      time: '17:00',
      sessionNumber: 1,
      topic: 'مفاهیم ماتریس‌های تصویری و الگوهای تکرارشونده'
    },
    {
      sessionId: 'ses-abbasi-2',
      classId: 'cls-sixth-a',
      className: 'کلاس ششم تیزهوشان - گروه الف (تحلیلی عباسی)',
      teacherId: 'teacher-abbasi',
      teacherName: 'عباسی',
      PersianDate: '1405/07/17',
      time: '17:00',
      sessionNumber: 2,
      topic: 'دوران فضایی و بازکردن گسترده مکعب‌ها'
    },
    {
      sessionId: 'ses-marhamati-1',
      classId: 'cls-sixth-b',
      className: 'کلاس ششم تیزهوشان - گروه ب (سرعت و دقت مرحمتی)',
      teacherId: 'teacher-marhamati',
      teacherName: 'مرحمتی',
      PersianDate: '1405/07/12',
      time: '18:00',
      sessionNumber: 1,
      topic: 'تکنیک‌های خوانش چشمی و تشخیص تفاوت‌های میلی‌متری'
    },
    {
      sessionId: 'ses-marhamati-2',
      classId: 'cls-sixth-b',
      className: 'کلاس ششم تیزهوشان - گروه ب (سرعت و دقت مرحمتی)',
      teacherId: 'teacher-marhamati',
      teacherName: 'مرحمتی',
      PersianDate: '1405/07/19',
      time: '18:00',
      sessionNumber: 2,
      topic: 'تست‌های زمان‌دار ۵ ثانیه‌ای و رمزگذاری علائم'
    },
    // Grade 9 Sessions (Joint Teaching)
    {
      sessionId: 'ses-ninth-1',
      classId: 'cls-ninth-a',
      className: 'کلاس نهم تیزهوشان (استعداد تحصیلی و تحلیلی)',
      teacherId: 'teacher-abbasi',
      teacherName: 'عباسی',
      PersianDate: '1405/07/14',
      time: '09:00',
      sessionNumber: 1,
      topic: 'استدلال‌های ترکیبی و اصول شمارش در تیزهوشان نهم'
    },
    {
      sessionId: 'ses-ninth-2',
      classId: 'cls-ninth-b',
      className: 'کلاس نهم تیزهوشان (استعداد کلامی و علوم)',
      teacherId: 'teacher-marhamati',
      teacherName: 'مرحمتی',
      PersianDate: '1405/07/14',
      time: '11:15',
      sessionNumber: 1,
      topic: 'تحلیل پیشرفته متون ادبی و مفاهیم علوم تجربی سمپاد نهم'
    }
  ],
  payments: [
    {
      paymentId: 'pay-101',
      studentId: 'std-ali-1',
      studentName: 'علی احمدی',
      amount: 2800000,
      paymentStatus: 'confirmed',
      cycleNumber: 1,
      paymentDate: '2026-08-20T10:30:00.000Z',
      PersianDate: '1405/05/30',
      confirmedBy: 'مهندس حسینی'
    },
    {
      paymentId: 'pay-102',
      studentId: 'std-sara-2',
      studentName: 'سارا راد',
      amount: 2800000,
      paymentStatus: 'confirmed',
      cycleNumber: 1,
      paymentDate: '2026-08-15T11:00:00.000Z',
      PersianDate: '1405/05/25',
      confirmedBy: 'مهندس حسینی'
    },
    {
      paymentId: 'pay-103',
      studentId: 'std-yalda-9',
      studentName: 'یلدا کمالی',
      amount: 3200000,
      paymentStatus: 'confirmed',
      cycleNumber: 2,
      paymentDate: '2026-09-01T14:00:00.000Z',
      PersianDate: '1405/06/11',
      confirmedBy: 'مهندس حسینی'
    }
  ],
  exams: [
    {
      examId: 'exam-sampad-6-03',
      title: 'آزمون جامع تیزهوشان ششم - مرحله سوم (شبیه‌ساز سمپاد)',
      grade: 6,
      examDate: '2026-09-10',
      PersianDate: '1405/06/20',
      totalQuestions: 120
    },
    {
      examId: 'exam-sampad-6-02',
      title: 'آزمون جامع تیزهوشان ششم - مرحله دوم',
      grade: 6,
      examDate: '2026-08-25',
      PersianDate: '1405/06/04',
      totalQuestions: 120
    },
    {
      examId: 'exam-sampad-6-01',
      title: 'آزمون جامع تیزهوشان ششم - مرحله اول',
      grade: 6,
      examDate: '2026-08-10',
      PersianDate: '1405/05/20',
      totalQuestions: 120
    },
    {
      examId: 'exam-sampad-9-03',
      title: 'آزمون جامع تیزهوشان نهم - مرحله سوم (تحصیلی و تحلیلی)',
      grade: 9,
      examDate: '2026-09-12',
      PersianDate: '1405/06/22',
      totalQuestions: 125
    },
    {
      examId: 'exam-sampad-9-02',
      title: 'آزمون جامع تیزهوشان نهم - مرحله دوم',
      grade: 9,
      examDate: '2026-08-28',
      PersianDate: '1405/06/07',
      totalQuestions: 125
    }
  ],
  results: [
    // Ali Ahmadi (Grade 6 - Exam 3)
    {
      resultId: 'res-ali-6-03',
      studentId: 'std-ali-1',
      examId: 'exam-sampad-6-03',
      grade: 6,
      examTitle: 'آزمون جامع تیزهوشان ششم - مرحله سوم',
      examDate: '2026-09-10',
      PersianDate: '1405/06/20',
      sixthGrade: {
        booklet1: {
          totalQuestions: 60,
          coefficient: 3,
          correct: 49,
          wrong: 6,
          blank: 5,
          percentage: 78.3,
          rawScore: 141,
          tScore: 7120
        },
        booklet2: {
          totalQuestions: 60,
          coefficient: 1,
          correct: 44,
          wrong: 8,
          blank: 8,
          percentage: 68.9,
          rawScore: 124,
          tScore: 6640
        }
      },
      totalPercentage: 76.0,
      totalScore: 265,
      tScore: 7000,
      rank: 2,
      totalParticipants: 48,
      percentile: 96.2,
      analysis: {
        summary: 'علی احمدی عملکردی بسیار درخشان در این مرحله ثبت کرده است. کسب تراز ۷۰۰۰ نشان‌دهنده شانس قبولی بالای ۹۰٪ در مدارس استعداد درخشان شهید اژه‌ای / علامه حلی است.',
        comparisonToPrevious: 'دانش‌آموز نسبت به آزمون قبلی ۱۵٪ رشد نشان داده است (تراز از ۶۳۰۰ به ۷۰۰۰ ارتقا یافت).',
        strengths: [
          'هوش تحلیلی و هندسه فضایی (استاد عباسی) با درصد عالی ۷۸.۳٪',
          'استفاده بهینه از زمان در دفترچه دوم سرعت و دقت'
        ],
        weaknesses: [
          '۶ پاسخ غلط در دفترچه اول به علت شتاب‌زدگی در خواندن صورت سوال',
          'افت ریتم در ۲۰ سوال پایانی سرعت و دقت'
        ],
        studySuggestions: [
          'حل روزانه ۲۵ تست تصویری از کتاب ۱۰۰۰ تست هوش تیزهوشان آی‌مکس',
          'کاهش حدس‌های پرریسک برای جلوگیری از کسر نمره منفی',
          'شرکت در جلسات تحلیل هفتگی با استاد عباسی و استاد مرحمتی'
        ]
      }
    },
    // Ali Ahmadi (Grade 6 - Exam 2 for progress chart)
    {
      resultId: 'res-ali-6-02',
      studentId: 'std-ali-1',
      examId: 'exam-sampad-6-02',
      grade: 6,
      examTitle: 'آزمون جامع تیزهوشان ششم - مرحله دوم',
      examDate: '2026-08-25',
      PersianDate: '1405/06/04',
      sixthGrade: {
        booklet1: {
          totalQuestions: 60,
          coefficient: 3,
          correct: 40,
          wrong: 10,
          blank: 10,
          percentage: 61.1,
          rawScore: 110,
          tScore: 6200
        },
        booklet2: {
          totalQuestions: 60,
          coefficient: 1,
          correct: 38,
          wrong: 12,
          blank: 10,
          percentage: 56.7,
          rawScore: 102,
          tScore: 6100
        }
      },
      totalPercentage: 60.0,
      totalScore: 212,
      tScore: 6175,
      rank: 5,
      totalParticipants: 48,
      percentile: 89.5,
      analysis: {
        summary: 'وضعیت در حال پیشرفت، نیازمند بهبود در آزمون‌های سرعت و دقت.',
        comparisonToPrevious: 'رشد ۶٪ نسبت به مرحله اول.',
        strengths: ['استدلال تحلیلی'],
        weaknesses: ['خطای نمره منفی بالا'],
        studySuggestions: ['تکنیک ضربدر منها']
      }
    },
    // Ali Ahmadi (Grade 6 - Exam 1 for progress chart)
    {
      resultId: 'res-ali-6-01',
      studentId: 'std-ali-1',
      examId: 'exam-sampad-6-01',
      grade: 6,
      examTitle: 'آزمون جامع تیزهوشان ششم - مرحله اول',
      examDate: '2026-08-10',
      PersianDate: '1405/05/20',
      sixthGrade: {
        booklet1: {
          totalQuestions: 60,
          coefficient: 3,
          correct: 36,
          wrong: 12,
          blank: 12,
          percentage: 53.3,
          rawScore: 96,
          tScore: 5750
        },
        booklet2: {
          totalQuestions: 60,
          coefficient: 1,
          correct: 35,
          wrong: 14,
          blank: 11,
          percentage: 50.6,
          rawScore: 91,
          tScore: 5680
        }
      },
      totalPercentage: 52.6,
      totalScore: 187,
      tScore: 5732,
      rank: 9,
      totalParticipants: 48,
      percentile: 81.2,
      analysis: {
        summary: 'نقطه شروع دوره با پتانسیل جهش بالا.',
        comparisonToPrevious: 'آزمون تعیین سطح اولیه.',
        strengths: ['علاقه و هوش ریاضی'],
        weaknesses: ['عدم آشنایی با تست‌های چرخشی'],
        studySuggestions: ['شروع با تست‌های طبقه‌بندی شده']
      }
    },
    // Sara Rad (Grade 6 - Rank 1)
    {
      resultId: 'res-sara-6-03',
      studentId: 'std-sara-2',
      examId: 'exam-sampad-6-03',
      grade: 6,
      examTitle: 'آزمون جامع تیزهوشان ششم - مرحله سوم',
      examDate: '2026-09-10',
      PersianDate: '1405/06/20',
      sixthGrade: {
        booklet1: {
          totalQuestions: 60,
          coefficient: 3,
          correct: 54,
          wrong: 3,
          blank: 3,
          percentage: 88.3,
          rawScore: 159,
          tScore: 7650
        },
        booklet2: {
          totalQuestions: 60,
          coefficient: 1,
          correct: 48,
          wrong: 6,
          blank: 6,
          percentage: 76.7,
          rawScore: 138,
          tScore: 7100
        }
      },
      totalPercentage: 85.4,
      totalScore: 297,
      tScore: 7512,
      rank: 1,
      totalParticipants: 48,
      percentile: 98.9,
      analysis: {
        summary: 'سارا راد رتبه یک آموزشگاه را کسب کرد. تسلط کم‌نظیر در بخش‌های تحلیلی و زمان‌سنجی.',
        comparisonToPrevious: 'تثبیت رتبه اول با رشد ۴٪.',
        strengths: ['هوش تجسمی عالی', 'کمترین تعداد پاسخ اشتباه'],
        weaknesses: ['چند خطای جزیی در سوالات کدگذاری'],
        studySuggestions: ['حفظ تمرکز و شبیه‌سازی شرایط استرس آزمون']
      }
    },
    // Mohammadreza Yousefi (Grade 6 - Rank 3)
    {
      resultId: 'res-reza-6-03',
      studentId: 'std-reza-3',
      examId: 'exam-sampad-6-03',
      grade: 6,
      examTitle: 'آزمون جامع تیزهوشان ششم - مرحله سوم',
      examDate: '2026-09-10',
      PersianDate: '1405/06/20',
      sixthGrade: {
        booklet1: {
          totalQuestions: 60,
          coefficient: 3,
          correct: 45,
          wrong: 9,
          blank: 6,
          percentage: 70.0,
          rawScore: 126,
          tScore: 6700
        },
        booklet2: {
          totalQuestions: 60,
          coefficient: 1,
          correct: 43,
          wrong: 10,
          blank: 7,
          percentage: 66.1,
          rawScore: 119,
          tScore: 6500
        }
      },
      totalPercentage: 69.0,
      totalScore: 245,
      tScore: 6650,
      rank: 3,
      totalParticipants: 48,
      percentile: 94.0,
      analysis: {
        summary: 'محمدرضا جزو سه دانش‌آموز برتر آموزشگاه با عملکرد تحلیلی قابل ستایش.',
        comparisonToPrevious: 'رشد ۸٪ نسبت به مرحله قبل.',
        strengths: ['هوش کلامی و ادراک فضایی'],
        weaknesses: ['تعداد غلط در سرعت و دقت'],
        studySuggestions: ['کاهش ریسک در تست‌های مشکوک']
      }
    },
    // Artin Sadeghi (Grade 9 - Exam 3)
    {
      resultId: 'res-artin-9-03',
      studentId: 'std-artin-9',
      examId: 'exam-sampad-9-03',
      grade: 9,
      examTitle: 'آزمون جامع تیزهوشان نهم - مرحله سوم',
      examDate: '2026-09-12',
      PersianDate: '1405/06/22',
      ninthGrade: {
        booklet1: {
          totalQuestions: 75,
          subjects: {
            Quran: { key: 'Quran', titleFa: 'قرآن و معارف', questionsCount: 10, correct: 9, wrong: 1, blank: 0, percentage: 86.7, level: 'عالی' },
            PersianLiterature: { key: 'PersianLiterature', titleFa: 'ادبیات فارسی', questionsCount: 15, correct: 12, wrong: 2, blank: 1, percentage: 75.6, level: 'خوب' },
            Arabic: { key: 'Arabic', titleFa: 'عربی', questionsCount: 10, correct: 8, wrong: 1, blank: 1, percentage: 76.7, level: 'خوب' },
            SocialStudies: { key: 'SocialStudies', titleFa: 'مطالعات اجتماعی', questionsCount: 10, correct: 9, wrong: 0, blank: 1, percentage: 90.0, level: 'عالی' },
            Mathematics: { key: 'Mathematics', titleFa: 'ریاضیات پیشرفته', questionsCount: 15, correct: 13, wrong: 1, blank: 1, percentage: 84.4, level: 'عالی' },
            Science: { key: 'Science', titleFa: 'علوم تجربی', questionsCount: 15, correct: 10, wrong: 3, blank: 2, percentage: 60.0, level: 'خوب' }
          },
          totalPercentage: 78.9,
          score: 177
        },
        booklet2: {
          totalQuestions: 50,
          correct: 41,
          wrong: 5,
          blank: 4,
          percentage: 78.7,
          score: 118
        }
      },
      totalPercentage: 78.8,
      totalScore: 295,
      tScore: 7240,
      rank: 1,
      totalParticipants: 36,
      percentile: 97.2,
      analysis: {
        summary: 'آرتین صادقی رتبه ۱ پایه نهم تیزهوشان را از آن خود کرده است. عملکرد ممتاز در ریاضیات تیزهوشان و استعداد تحلیلی.',
        comparisonToPrevious: 'دانش‌آموز نسبت به آزمون قبلی ۱۱٪ پیشرفت داشته است.',
        strengths: ['ریاضیات پیشرفته سمپاد یک نقطه قوت چشمگیر است (۸۴.۴٪)', 'مطالعات اجتماعی با ۹۰٪ درصد تسلط عالی'],
        weaknesses: ['علوم تجربی (به ویژه فیزیک نور و شیمی) نیازمند تمرین بیشتر است (۶۰.۰٪)'],
        studySuggestions: [
          'حل تست‌های علوم پیشرفته کتاب خیلی‌سبز و نشر الگو همراه با استاد مرحمتی',
          'استمرار تست‌های تلفیقی استعداد تحلیلی دفترچه دوم',
          'شرکت در کلاس‌های رفع اشکال ویژه نهم'
        ]
      }
    }
  ]
};

export class DataStoreClass {
  private state: AppDataState;
  private listeners: Set<() => void> = new Set();

  constructor() {
    this.state = this.loadInitial();
  }

  public subscribe(listener: () => void): () => void {
    this.listeners.add(listener);
    return () => this.listeners.delete(listener);
  }

  private notify(): void {
    this.listeners.forEach(l => {
      try { l(); } catch (e) { console.error(e); }
    });
  }

  private loadInitial(): AppDataState {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (parsed && parsed.students && parsed.sessions) {
          return parsed;
        }
      }
    } catch (e) {
      console.warn('LocalStorage load error, using default state:', e);
    }
    return INITIAL_DATA;
  }

  private save(): void {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(this.state));
      this.notify();
    } catch (e) {
      console.error('Failed to save to localStorage:', e);
    }
  }

  public getState(): AppDataState {
    return this.state;
  }

  public getStudents(): Student[] {
    return this.state.students;
  }

  public getTeachers(): Teacher[] {
    return this.state.teachers;
  }

  public getClasses(): ClassItem[] {
    return this.state.classes;
  }

  public getSessions(): SessionItem[] {
    return this.state.sessions;
  }

  public getPayments(): PaymentItem[] {
    return this.state.payments;
  }

  public getExams(): ExamDefinition[] {
    return this.state.exams;
  }

  public getResults(): ExamResult[] {
    return this.state.results;
  }

  public resetToDefault(): void {
    this.state = JSON.parse(JSON.stringify(INITIAL_DATA));
    this.save();
  }

  public resetToInitial(): void {
    this.resetToDefault();
  }

  // Session Management
  public addSession(newSession: Omit<SessionItem, 'sessionId'>): SessionItem {
    const sessionId = `ses-${Date.now()}`;
    const session: SessionItem = {
      ...newSession,
      sessionId
    };

    this.state.sessions.unshift(session);

    // Auto increment student active sessions for the class
    const targetClass = this.state.classes.find(c => c.classId === newSession.classId);
    if (targetClass) {
      this.state.students = this.state.students.map(std => {
        if (targetClass.students.includes(std.studentId)) {
          return {
            ...std,
            activeCycleSessions: std.activeCycleSessions + 1
          };
        }
        return std;
      });
    }

    this.save();
    return session;
  }

  // Payment Confirmation by Admin ("تایید واریز")
  public confirmPayment(studentId: string, amount: number, confirmedBy: string, PersianDate: string): PaymentItem {
    const student = this.state.students.find(s => s.studentId === studentId);
    if (!student) throw new Error('دانش‌آموز پیدا نشد');

    const paymentId = `pay-${Date.now()}`;
    const newPayment: PaymentItem = {
      paymentId,
      studentId,
      studentName: student.fullName,
      amount,
      paymentStatus: 'confirmed',
      cycleNumber: student.currentCycleNumber,
      paymentDate: new Date().toISOString(),
      PersianDate,
      confirmedBy
    };

    this.state.payments.unshift(newPayment);

    // Reset student active session counter to zero and create new payment cycle
    this.state.students = this.state.students.map(std => {
      if (std.studentId === studentId) {
        return {
          ...std,
          activeCycleSessions: 0,
          currentCycleNumber: std.currentCycleNumber + 1
        };
      }
      return std;
    });

    this.save();
    return newPayment;
  }

  // Exam Result Management
  public addExamResult(result: ExamResult): void {
    const existingIndex = this.state.results.findIndex(
      r => r.studentId === result.studentId && r.examId === result.examId
    );
    if (existingIndex >= 0) {
      this.state.results[existingIndex] = result;
    } else {
      this.state.results.unshift(result);
    }
    this.save();
  }

  public saveExamResult(result: ExamResult): void {
    this.addExamResult(result);
  }

  // Add new student
  public addStudent(newStudent: Omit<Student, 'studentId' | 'activeCycleSessions' | 'currentCycleNumber'>): Student {
    const studentId = `std-${Date.now()}`;
    const student: Student = {
      ...newStudent,
      studentId,
      activeCycleSessions: 0,
      currentCycleNumber: 1
    };

    this.state.students.push(student);

    // Add to class
    const cls = this.state.classes.find(c => c.classId === student.classId);
    if (cls && !cls.students.includes(studentId)) {
      cls.students.push(studentId);
    }

    this.save();
    return student;
  }

  // Add new class for a teacher
  public addClass(newClass: Omit<ClassItem, 'classId'>): ClassItem {
    const classId = `cls-${Date.now()}`;
    const isJointTeaching = newClass.isJointTeaching !== undefined
      ? newClass.isJointTeaching
      : (newClass.grade === 5 || newClass.grade === 6 || newClass.grade === 9);

    const item: ClassItem = {
      ...newClass,
      classId,
      isJointTeaching,
      students: newClass.students || []
    };
    this.state.classes.push(item);

    // Also assign class to the teacher if not already in assignedClasses
    this.state.teachers = this.state.teachers.map(t => {
      if (t.teacherId === item.teacherId && !t.assignedClasses.includes(classId)) {
        return {
          ...t,
          assignedClasses: [...t.assignedClasses, classId]
        };
      }
      return t;
    });

    this.save();
    return item;
  }
}

export const DataStore = new DataStoreClass();
export const store = DataStore;

