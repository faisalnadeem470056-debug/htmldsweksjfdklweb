/// <reference types="vite/client" />
/**
 * Firebase Client Configuration and Firestore Initialization
 * آکادمی هوشمند آی‌مکس
 */

import { initializeApp, getApps, FirebaseApp } from 'firebase/app';
import { getFirestore, Firestore, collection } from 'firebase/firestore';

const env = (import.meta as any).env || {};

// Client-side Firebase configuration
// In standard deployment, these can be populated with project credentials
export const firebaseConfig = {
  apiKey: env.VITE_FIREBASE_API_KEY || "AIzaSyD-demo-imax-academy-key",
  authDomain: env.VITE_FIREBASE_AUTH_DOMAIN || "imax-academy.firebaseapp.com",
  projectId: env.VITE_FIREBASE_PROJECT_ID || "imax-academy",
  storageBucket: env.VITE_FIREBASE_STORAGE_BUCKET || "imax-academy.appspot.com",
  messagingSenderId: env.VITE_FIREBASE_MESSAGING_SENDER_ID || "1029384756",
  appId: env.VITE_FIREBASE_APP_ID || "1:1029384756:web:abcd1234efgh5678"
};

let app: FirebaseApp | null = null;
let db: Firestore | null = null;

export function getFirebaseApp(): FirebaseApp {
  if (!app) {
    const existing = getApps();
    if (existing.length > 0) {
      app = existing[0];
    } else {
      app = initializeApp(firebaseConfig);
    }
  }
  return app;
}

export function getDb(): Firestore {
  if (!db) {
    db = getFirestore(getFirebaseApp());
  }
  return db;
}

// Firestore collections mapping according to blueprint
export const COLLECTIONS = {
  USERS: 'users',
  TEACHERS: 'teachers',
  CLASSES: 'classes',
  STUDENTS: 'students',
  SESSIONS: 'sessions',
  PAYMENTS: 'payments',
  EXAMS: 'exams',
  RESULTS: 'results'
};
