# 🌟 HealMate Social Community - د ټولنیز شبکې لارښود

## 📱 لکه Facebook او Instagram!

HealMate اوس یو بشپړ Social Health Community دی چېرته **هر څوک** پوستونه کولی شي او یو بل سره interact کولی شي!

---

## 🎯 څنګه کار کوي؟ - How It Works

### 1️⃣ **Community Feed (لکه Facebook News Feed)**
**Location:** Mobile Nav → "Community" icon (ټولنه)

#### څه کولی شئ:
- ✅ **د ټولو کاروونکو پوستونه وګورئ** - See everyone's posts
- ✅ **نوی پوست جوړ کړئ** - Create your own post
- ✅ **Like, Comment, Share** - د پوستونو سره تعامل
- ✅ **Follow/Unfollow Users** - د نورو کاروونکو تعقیب
- ✅ **Save Posts** - پوستونه خوندي کړئ
- ✅ **Search Posts** - پوستونه ولټوئ

#### فیلټرونه:
- **All Posts** - د ټولو کاروونکو پوستونه
- **Following** - یوازې د هغو کسانو پوستونه چې تعقیب یې کوئ

---

### 2️⃣ **My Posts (لکه Facebook Profile)**
**Location:** Mobile Nav → "My Posts" icon (زما پوستونه)

#### څه کولی شئ:
- ✅ **د خپلو پوستونو لیست** - See only YOUR posts
- ✅ **Edit پوستونه** - خپل پوستونه سمول
- ✅ **Delete پوستونه** - خپل پوستونه ړنګول
- ✅ **Drafts** - د Draft پوستونه وګورئ
- ✅ **Analytics** - ستاسو د پوستونو Stats (Views, Likes, Comments, Shares)

---

## 👥 د کاروونکو ډولونه - User Types

په Community کې ډیر ډول کاروونکي شته:

1. **ډاکټران** (Doctors) - Dr. Ahmad Naseri, Dr. Mariam Hashimi
2. **روغتیا مینه والان** (Health Enthusiasts) - Fatima Ahmadi
3. **فټنس روزونکي** (Fitness Coaches) - Hassan Karimi
4. **تغذیه پوهان** (Nutritionists) - Sara Mohammadi
5. **یوګا ښوونکي** (Yoga Instructors) - Rashid Nazari
6. **او نور...** (And more!)

---

## 🎨 د پوست Structure - Post Format

هر پوست لري:

```
[User Avatar + Name]
↓
[Post Content] (English + Pashto/Dari)
↓
[Post Image] (Optional)
↓
[Likes, Comments, Shares Stats]
↓
[Like, Comment, Share, Save Buttons]
↓
[Comments Section]
```

---

## 💬 Comment سیسټم

### څنګه Comment وکړئ:
1. د پوست لاندې "Comment" button فشار ورکړئ
2. خپل comment ولیکئ
3. Enter فشار ورکړئ یا Send button کلیک کړئ
4. ستاسو comment به سمدستي ښکاره شي!

### د Comment فیچرونه:
- ✅ د ټولو کاروونکو comments وګورئ
- ✅ Real-time comments
- ✅ د User avatar او نوم ښکاره کیږي
- ✅ د Comment وخت ښکاره کیږي

---

## 👤 Follow/Friend سیسټم

### څنګه Follow وکړئ:
1. د پوست په header کې "Follow" button فشار ورکړئ
2. یا د Sidebar څخه "Suggested Users" وګورئ
3. د User پر "Follow" button کلیک وکړئ
4. ستاسو Following لیست به update شي!

### د Follow فایدې:
- ✅ د "Following" tab کې یوازې د followed users پوستونه وګورئ
- ✅ د followed users ټول پوستونه په feed کې priority لري
- ✅ د Following status په post header کې ښکاره کیږي

---

## ❤️ Like سیسټم

### څنګه Like وکړئ:
1. د پوست لاندې "Like" button فشار ورکړئ
2. د Like شمېر به increase شي
3. د Like button رنګ به سور شي
4. بیا کلیک کولو سره Unlike کیږي

---

## 🔖 Save/Bookmark

### څنګه Save وکړئ:
1. د پوست لاندې Bookmark icon فشار ورکړئ
2. پوست به ستاسو Saved لیست کې اضافه شي
3. د Sidebar کې "Saved Posts" شمېر به update شي

---

## 📊 Stats Dashboard (My Posts)

ستاسو د ټولو پوستونو Analytics:

### 4 اصلي Metrics:
1. **👁️ Total Views** - ټول Views
2. **❤️ Total Likes** - ټول Likes
3. **💬 Total Comments** - ټول Comments
4. **📊 Published Posts** - خپاره شوي پوستونه

---

## 📝 د پوست جوړول - Creating a Post

### د Community Feed څخه:
1. "Create Post" button فشار ورکړئ
2. خپل content ولیکئ
3. (Optional) عکس یا ویډیو اضافه کړئ
4. "Post" button فشار ورکړئ
5. ستاسو پوست به سمدستي په feed کې ښکاره شي!

### د My Posts څخه:
1. "Create New Post" button فشار ورکړئ
2. خپل content ولیکئ
3. یا "Publish" یا "Save Draft" وکړئ
4. Published پوستونه سمدستي په Community Feed کې ښکاره کیږي!

---

## 🔍 Search

د پوستونو لټون:
1. د Search bar کې keyword ولیکئ
2. په ټولو پوستونو کې لټون کوي
3. د User نومونو، content، او tags پر بنسټ

---

## 🎯 User Flow - د کاروونکي سفر

### سناریو 1: د نویو پوستونو لیدل
```
Home → Mobile Nav "Community" 
     → د ټولو پوستونه وګورئ
     → Like/Comment/Share
     → Follow interesting users
```

### سناریو 2: نوی پوست جوړول
```
Community Feed → "Create Post" button
              → Write content
              → Post
              → Appears in feed immediately!
```

### سناریو 3: د خپلو پوستونو مدیریت
```
Mobile Nav "My Posts" → View your posts
                     → Edit/Delete posts
                     → View Analytics
                     → Publish drafts
```

### سناریو 4: د ځانګړو Users تعقیب
```
Community Feed → See interesting post
              → Click "Follow" on post
              → OR go to Sidebar "Suggested Users"
              → Follow multiple users
              → Switch to "Following" tab
```

---

## 🌐 Multilingual - څه ژبیز ملاتړ

هر پوست لري:
- 🇬🇧 **English** - Primary content
- 🇦🇫 **Pashto (پښتو)** - د پښتو ترجمه
- 🇦🇫 **Dari (دري)** - د دري ترجمه

د UI ټول labels په درې ژبو دي!

---

## 🎨 د UI فیچرونه

### Modern Design:
- ✅ Glassmorphism effects
- ✅ Gradient colors
- ✅ Smooth animations
- ✅ Responsive design
- ✅ Mobile-first approach

### د Post Card:
- ✅ User Avatar + Info
- ✅ Follow button (که followed نه وي)
- ✅ Content د دواړو ژبو
- ✅ High-quality images
- ✅ Stats (Likes, Comments, Shares)
- ✅ Action buttons
- ✅ Comments section

---

## 🚀 Tips & Tricks

### 1. د ښو پوستونو لپاره:
- ✍️ Clear او helpful content ولیکئ
- 📸 د لوړ کیفیت عکسونه استعمال کړئ
- #️⃣ Hashtags استعمال کړئ
- 🌍 د دواړو ژبو content ولیکئ

### 2. د Engagement لپاره:
- 💬 د نورو پوستونو Comments کړئ
- ❤️ Helpful پوستونه Like کړئ
- 🔄 Important معلومات Share کړئ
- 👥 د Expert users Follow کړئ

### 3. د Privacy لپاره:
- 🔒 حساس معلومات شریک مه کړئ
- ⚕️ د طبي مشورې لپاره ډاکټر سره مراجعه وکړئ
- 🚫 غیر مناسب content پوست مه کړئ

---

## 📱 Mobile Navigation

د Mobile Nav کې:

```
[Home] [Community] [➕ Services] [My Posts] [Settings]
  🏠      👥                        📝         ⚙️
```

- **Home** - د اصلي صفحې ته
- **Community** - د ټولو پوستونو feed
- **Services** - د روغتیایي خدمتونه
- **My Posts** - د خپلو پوستونو لیست
- **Settings** - ترتیبات

---

## 🆚 Community Feed vs My Posts

| Feature | Community Feed | My Posts |
|---------|---------------|----------|
| **څه وینم؟** | د ټولو پوستونه | یوازې زما پوستونه |
| **Like/Comment** | ✅ په ټولو پوستونو | ✅ په زما پوستونو |
| **Create Post** | ✅ نوی پوست | ✅ نوی پوست |
| **Edit/Delete** | ❌ نه | ✅ هو |
| **Analytics** | ❌ نه | ✅ بشپړ Stats |
| **Follow Users** | ✅ هو | ❌ نه |
| **Filters** | All/Following | Published/Drafts |

---

## 🎯 د مختلفو کاروونکو لپاره

### د عام کاروونکو لپاره:
1. د نورو تجربې ولولئ
2. د روغتیا مشورې ترلاسه کړئ
3. خپلې پوښتنې وپوښتئ
4. د Expert users Follow کړئ

### د Experts لپاره (ډاکټران، Coaches):
1. د روغتیا مشورې شریک کړئ
2. د عامو پوښتنو ځوابونه ورکړئ
3. Educational content پوست کړئ
4. د Community سره engage شئ

### د Fitness Enthusiasts لپاره:
1. خپل workout routines شریک کړئ
2. د Progress عکسونه پوست کړئ
3. د نورو سره motivate کړئ
4. Tips او tricks شریک کړئ

---

## 🔔 Notifications (راتلونکی فیچر)

راتلونکې کې:
- 🔔 د نوي comment اطلاع
- ❤️ د نوي like اطلاع
- 👤 د نوي follower اطلاع
- 💬 د mention اطلاع (@username)

---

## 🎉 د مثالونو Posts

### مثال 1 - د روغتیا مشوره:
```
د سهار پیاده روی د زړه روغتیا ته خورا ګټور دی. 
هره ورځ 30 دقیقې پیاده روی کولو سره تاسو کولی شئ:
✅ د زړه روغتیا ښه کړئ
✅ وزن کم کړئ
✅ انرژي زیات کړئ
#HealthTips #Walking
```

### مثال 2 - د تجربې شریکول:
```
نن د یوګا لومړنی ټولګي مې ولید! 
د پیل کول ستونزمن و، خو احساس خورا ښه کوم. 
هڅه وکړئ! 🧘‍♀️
#Yoga #Wellness
```

### مثال 3 - پوښتنه:
```
آیا څوک د ښه nutritionist سفارش کولی شي؟
د کابل په ساحه کې؟
مننه!
#NeedHelp #Kabul
```

---

## 📞 مرسته - Support

که ستونزه لرئ:
- 📧 Email: ibrahimkhaksar.it@gmail.com
- 📱 Phone: +93783040441 / +93779494512

---

## 🌟 الحمدلله!

HealMate Community اوس یو بشپړ Social Health Network دی! 

د ټولو افغانانو لپاره - Connecting Afghanistan's Health Community! 🇦🇫💚

**Version:** 2.0.0
**Last Updated:** November 2025

---

## 🎯 یاد ولرئ!

- 👥 هر څوک پوست کولی شي
- 💬 هر څوک comment کولی شي
- ❤️ هر څوک like کولی شي
- 🔄 هر څوک share کولی شي
- 👤 هر څوک follow کولی شي

**دا ستاسو Community ده! 🎉**
