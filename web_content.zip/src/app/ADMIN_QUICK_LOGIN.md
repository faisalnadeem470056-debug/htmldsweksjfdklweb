# 🔐 Admin Panel - Quick Login Reference

## 🚀 د ګړندي لاسرسي لپاره (Quick Access)

### 📍 د Admin Panel ته څنګه ورسیږو؟

```
Settings → Admin Panel
تنظیمات → د ایډمین پینل
تنظیمات → پنل مدیریت
```

---

## 🔑 د Login معلومات (Login Credentials)

### ✅ Owner Email (یوازې دا ایمیل کار کوي):
```
ibrahimkhaksar.it@gmail.com
```

### ✅ Password (د لومړي ځل لپاره):

که تاسو لومړی ځل دي Admin Panel کاروئ:

1. **"نوی حساب جوړ کړئ"** کلیک کړئ
2. **Owner Email** ولیکئ: `ibrahimkhaksar.it@gmail.com`
3. **یو قوي پاسورډ جوړ کړئ** - دا ستاسو Admin Password به وي!
4. **Sign Up** کلیک کړئ
5. **بیا Login وکړئ** د همغه ایمیل او پاسورډ سره

---

## ⚡ د روزانه Login (Daily Login)

که تاسو مخکې Sign Up کړی:

```
Email: ibrahimkhaksar.it@gmail.com
Password: [ستاسو پاسورډ چې په Sign Up کې جوړ کړی]
```

---

## 🔄 د پاسورډ Reset (Password Reset)

که پاسورډ هیر شوی:

1. **"پاسورډ مو هیر شوی؟"** کلیک کړئ
2. **ایمیل**: `ibrahimkhaksar.it@gmail.com` ولیکئ
3. **"Send Link"** کلیک کړئ
4. **خپل Email چیک کړئ** - Reset Link به درته راشي
5. **نوی پاسورډ** تنظیم کړئ
6. **Login** وکړئ

---

## 🛡️ د امنیت مهم یادښت

**⚠️ یوازې Owner Email کار کوي!**

✅ کار کوي: `ibrahimkhaksar.it@gmail.com`  
❌ کار نه کوي: هر بل ایمیل

---

## 📞 د مرستې معلومات

- 📧 Email: ibrahimkhaksar.it@gmail.com
- 📱 Phone 1: +93783040441
- 📱 Phone 2: +93779494512

---

## ✨ د بریالیتوب Tips

1. ✅ یقیني کړئ چې **Internet** وصل دی
2. ✅ **Owner Email** سم ولیکئ
3. ✅ د **قوي پاسورډ** استعمال وکړئ
4. ✅ خپل **پاسورډ محفوظ** وساتئ
5. ✅ د logout مه هیروئ کله چې کار بشپړ شي!

---

**د نورو تفصیلاتو لپاره `ADMIN_PASSWORD_SETUP.md` وګورئ**
