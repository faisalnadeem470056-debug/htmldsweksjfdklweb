import { useState, useEffect } from 'react';

export interface PremiumSubscription {
  userId: string;
  plan: 'monthly' | 'yearly' | 'free';
  status: 'active' | 'cancelled' | 'expired' | 'pending';
  startDate: string;
  endDate: string;
  autoRenew: boolean;
  platform: 'android' | 'ios' | 'web';
  transactionId?: string;
  price: number;
  currency: string;
}

export interface PremiumFeatures {
  // Posts
  maxPostsPerDay: number;
  canPostImages: boolean;
  canPostVideos: boolean;
  
  // Social
  canSendDirectMessages: boolean;
  canVideoCall: boolean;
  unlimitedFollows: boolean;
  
  // Content
  canBookmark: boolean;
  canDownload: boolean;
  canExport: boolean;
  
  // Experience
  adFree: boolean;
  hasVerifiedBadge: boolean;
  hasPrioritySupport: boolean;
  hasAdvancedSearch: boolean;
  hasOfflineMode: boolean;
  hasCustomThemes: boolean;
  hasAnalytics: boolean;
  hasPriorityListing: boolean;
}

export function usePremium(userId: string | undefined) {
  const [isPremium, setIsPremium] = useState(false);
  const [subscription, setSubscription] = useState<PremiumSubscription | null>(null);
  const [features, setFeatures] = useState<PremiumFeatures>(getFreeFeatures());

  useEffect(() => {
    if (!userId) {
      setIsPremium(false);
      setSubscription(null);
      setFeatures(getFreeFeatures());
      return;
    }

    const checkPremium = () => {
      const saved = localStorage.getItem(`healmate_premium_${userId}`);
      if (saved) {
        const sub: PremiumSubscription = JSON.parse(saved);
        const now = new Date();
        const endDate = new Date(sub.endDate);

        if (now < endDate && sub.status === 'active') {
          setIsPremium(true);
          setSubscription(sub);
          setFeatures(getPremiumFeatures());
        } else {
          setIsPremium(false);
          setSubscription(sub);
          setFeatures(getFreeFeatures());
          
          // Update status if expired
          if (now > endDate && sub.status === 'active') {
            sub.status = 'expired';
            localStorage.setItem(`healmate_premium_${userId}`, JSON.stringify(sub));
          }
        }
      } else {
        setIsPremium(false);
        setSubscription(null);
        setFeatures(getFreeFeatures());
      }
    };

    checkPremium();

    // Check every minute for expiry
    const interval = setInterval(checkPremium, 60000);

    return () => clearInterval(interval);
  }, [userId]);

  const checkFeature = (feature: keyof PremiumFeatures): boolean => {
    return features[feature] as boolean;
  };

  const getLimit = (feature: keyof PremiumFeatures): number => {
    return features[feature] as number;
  };

  return { 
    isPremium, 
    subscription, 
    features,
    checkFeature,
    getLimit
  };
}

function getFreeFeatures(): PremiumFeatures {
  return {
    maxPostsPerDay: 3,
    canPostImages: true,
    canPostVideos: false,
    canSendDirectMessages: false,
    canVideoCall: false,
    unlimitedFollows: false,
    canBookmark: false,
    canDownload: false,
    canExport: false,
    adFree: false,
    hasVerifiedBadge: false,
    hasPrioritySupport: false,
    hasAdvancedSearch: false,
    hasOfflineMode: false,
    hasCustomThemes: false,
    hasAnalytics: false,
    hasPriorityListing: false
  };
}

function getPremiumFeatures(): PremiumFeatures {
  return {
    maxPostsPerDay: 100,
    canPostImages: true,
    canPostVideos: true,
    canSendDirectMessages: true,
    canVideoCall: true,
    unlimitedFollows: true,
    canBookmark: true,
    canDownload: true,
    canExport: true,
    adFree: true,
    hasVerifiedBadge: true,
    hasPrioritySupport: true,
    hasAdvancedSearch: true,
    hasOfflineMode: true,
    hasCustomThemes: true,
    hasAnalytics: true,
    hasPriorityListing: true
  };
}

// Helper function to check post limit
export function canCreatePost(userId: string): { allowed: boolean; remaining: number; message: string } {
  const saved = localStorage.getItem(`healmate_premium_${userId}`);
  let maxPosts = 3;
  
  if (saved) {
    const sub: PremiumSubscription = JSON.parse(saved);
    const now = new Date();
    const endDate = new Date(sub.endDate);
    
    if (now < endDate && sub.status === 'active') {
      maxPosts = 100;
    }
  }
  
  // Get today's posts
  const postsKey = `healmate_posts_count_${userId}_${new Date().toDateString()}`;
  const todayPosts = parseInt(localStorage.getItem(postsKey) || '0');
  
  if (todayPosts >= maxPosts) {
    return {
      allowed: false,
      remaining: 0,
      message: maxPosts === 3 
        ? 'Daily limit reached. Upgrade to Premium for unlimited posts!' 
        : 'Daily limit reached. Try again tomorrow!'
    };
  }
  
  return {
    allowed: true,
    remaining: maxPosts - todayPosts,
    message: `${maxPosts - todayPosts} posts remaining today`
  };
}

// Increment post count
export function incrementPostCount(userId: string) {
  const postsKey = `healmate_posts_count_${userId}_${new Date().toDateString()}`;
  const currentCount = parseInt(localStorage.getItem(postsKey) || '0');
  localStorage.setItem(postsKey, (currentCount + 1).toString());
}

// Google Play Billing Integration (Placeholder)
export async function purchaseAndroid(productId: 'monthly' | 'yearly'): Promise<boolean> {
  try {
    // In production, integrate with Google Play Billing
    // const purchase = await GooglePlayBilling.purchase(productId);
    // return purchase.success;
    
    console.log('Android purchase initiated:', productId);
    return true;
  } catch (error) {
    console.error('Android purchase failed:', error);
    return false;
  }
}

// Apple In-App Purchase Integration (Placeholder)
export async function purchaseIOS(productId: 'monthly' | 'yearly'): Promise<boolean> {
  try {
    // In production, integrate with StoreKit
    // const purchase = await StoreKit.purchase(productId);
    // return purchase.success;
    
    console.log('iOS purchase initiated:', productId);
    return true;
  } catch (error) {
    console.error('iOS purchase failed:', error);
    return false;
  }
}

// Restore purchases (for both platforms)
export async function restorePurchases(userId: string): Promise<PremiumSubscription | null> {
  try {
    const platform = getPlatform();
    
    if (platform === 'android') {
      // Restore from Google Play
      // const purchases = await GooglePlayBilling.queryPurchases();
      // return processPurchaseData(purchases, userId);
    } else if (platform === 'ios') {
      // Restore from App Store
      // const purchases = await StoreKit.restorePurchases();
      // return processPurchaseData(purchases, userId);
    }
    
    // For web, check localStorage
    const saved = localStorage.getItem(`healmate_premium_${userId}`);
    if (saved) {
      return JSON.parse(saved);
    }
    
    return null;
  } catch (error) {
    console.error('Restore failed:', error);
    return null;
  }
}

function getPlatform(): 'android' | 'ios' | 'web' {
  const userAgent = navigator.userAgent.toLowerCase();
  if (userAgent.includes('android')) return 'android';
  if (userAgent.includes('iphone') || userAgent.includes('ipad')) return 'ios';
  return 'web';
}
