# 🚀 د APK ګړندۍ جوړولو لارښود
# Quick APK Build Guide - HealMate

## ✅ ستاسو App اوس د APK لپاره چمتو دی!

---

## 📱 لاره 1: PWABuilder (5 دقیقې - ترټولو اسانه!) ⭐

### قدم 1: Deploy Your App
```bash
# که تاسو Vercel کاروئ:
npm install -g vercel
vercel login
vercel --prod

# که تاسو Netlify کاروئ:
npm install -g netlify-cli
netlify login
netlify deploy --prod
```

**یا** که تاسو د Figma Make Preview URL لرئ، نو مستقیماً هغه وکاروئ!

---

### قدم 2: PWABuilder ته ورشئ
1. 🌐 https://www.pwabuilder.com/ ته ورشئ
2. 📝 د خپل deployed app URL داخل کړئ
3. ▶️ "Start" کلیک وکړئ
4. ⏳ 10-15 ثانیې انتظار وکړئ

---

### قدم 3: د Android Package غوره کړئ
کله چې scan بشپړ شي:
1. **"Package for stores"** کلیک وکړئ
2. **"Android"** غوره کړئ
3. د دې تنظیمات سم کړئ:

```json
Package ID: com.healmate.afghanistan
App Name: HealMate
App Version: 1.0.0
Version Code: 1
Min SDK: 21 (Android 5.0)
Target SDK: 34 (Android 14)
```

---

### قدم 4: Signing Key Setup
د Play Store لپاره تاسو باید یو **signing key** لرئ:

**Option A: د PWABuilder کې نوی key جوړول**
- PWABuilder به تاسو لپاره key جوړ کړي
- دا key download او خوندي ساتئ (دا مهمه ده!)

**Option B: د خپل key کارول (سپارښتنه)**
```bash
# د Java JDK install کړئ
# بیا keytool وکاروئ:

keytool -genkey -v -keystore healmate-release-key.keystore \
  -alias healmate \
  -keyalg RSA \
  -keysize 2048 \
  -validity 10000

# معلومات داخل کړئ:
# Password: یو قوي password (یاد یې کړئ!)
# Name: Ibrahim Khaksar
# Organization: HealMate
# City: Kabul
# State: Kabul
# Country: AF
```

---

### قدم 5: Generate کړئ!
1. ✅ "Generate" کلیک وکړئ
2. ⏳ 30-60 ثانیې انتظار وکړئ
3. 📥 **AAB** یا **APK** file download کړئ

**مهم:**
- **AAB (Android App Bundle)**: د Play Store لپاره (سپارښتنه)
- **APK**: د testing یا direct installation لپاره

---

## 📱 لاره 2: Bubblewrap (Terminal څخه)

### Installation:
```bash
npm install -g @bubblewrap/cli
```

### د APK جوړول:
```bash
# 1. Initialize
bubblewrap init --manifest https://your-app-url.com/manifest.json

# 2. معلومات داخل کړئ:
# - App name: HealMate
# - Package name: com.healmate.afghanistan
# - App URL: ستاسو deployed URL

# 3. د Development APK جوړول
bubblewrap build

# 4. د Production AAB جوړول (Play Store لپاره)
bubblewrap build --release
```

---

## 📱 لاره 3: Capacitor (د Advanced Features لپاره)

### Setup:
```bash
# 1. Install Capacitor
npm install @capacitor/core @capacitor/cli @capacitor/android

# 2. Initialize
npx cap init

# معلومات داخل کړئ:
# App name: HealMate
# App ID: com.healmate.afghanistan
# Web dir: dist

# 3. Build your app
npm run build

# 4. Add Android platform
npx cap add android

# 5. Sync
npx cap sync android

# 6. Open in Android Studio
npx cap open android
```

### د Android Studio کې:
1. **Build** → **Build Bundle(s) / APK(s)**
2. د Play Store لپاره: **Build Bundle (AAB)**
3. د Testing لپاره: **Build APK**
4. File به په `android/app/build/outputs/` کې وي

---

## 🔐 د Signing Key مدیریت

### مهم یادښتونه:
- ✅ خپل keystore file خوندي ساتئ (Backup)
- ✅ Password یاد کړئ
- ❌ keystore file له لاسه نکړئ (update نشئ کولی!)
- ✅ په یو secure ځای کې save کړئ (Google Drive, USB, etc.)

---

## 📤 د Play Store ته Upload

### قدم 1: Google Play Console
1. https://play.google.com/console ته ورشئ
2. "Create app" کلیک وکړئ
3. App details ډک کړئ:

```
App name: HealMate - Afghanistan Health App
Default language: Pashto (پښتو)
App or game: App
Free or paid: Free
```

---

### قدم 2: App Content
1. **Privacy Policy**: 
   - ستاسو Privacy Policy URL (یو webpage جوړ کړئ)
   - یا `/PRIVACY_POLICY.md` web کې host کړئ

2. **App Category**:
   - Category: Medical
   - Tags: health, medical, doctors, hospitals

3. **Content Rating**:
   - د questionnaire ډک کړئ
   - Health/Medical content: Yes
   - No violence, adult content, etc.

4. **Target Audience**:
   - Age: 13 and over
   - Appeals to children: No

---

### قدم 3: Store Listing
د دې معلومات اړین دي:

#### App Description (Pashto):
```
د HealMate ته ښه راغلاست!

د افغانستان ترټولو بشپړ او پیشرفته روغتیا اپلیکیشن. موږ تاسو ته د روغتیا ټول خدمات په درې ژبو (پښتو، دری، او انګلیسي) کې وړاندې کوو.

🏥 خدمات:
• د ماهرو دوکتورانو ډایرکټري
• د روغتونونو او کلینیکونو معلومات
• د درملو بشپړ لارښود
• د اسعافي مرستې لارښوونې
• د روغتیا مشورې او معلومات
• د خوراک او تغذیې لارښود
• د روغتیا ټولنیز فیډ

📱 ځانګړتیاوې:
✅ درې ژبې: پښتو، دری، انګلیسي
✅ آفلاین کار کوي
✅ ګړندی او اسانه کارول
✅ د افغانستان لپاره ځانګړی ډیزاین

د روغتیا نوې تجربه، د HealMate سره!
```

#### App Description (English):
```
Welcome to HealMate!

Afghanistan's most comprehensive and advanced health application. We provide you with all health services in three languages (Pashto, Dari, and English).

🏥 Services:
• Expert doctors directory
• Hospitals and clinics information
• Complete medicine guide
• First aid instructions
• Health tips and advice
• Nutrition and diet guide
• Health community feed

📱 Features:
✅ Three languages: Pashto, Dari, English
✅ Works offline
✅ Fast and easy to use
✅ Designed specifically for Afghanistan

A new health experience with HealMate!
```

#### Short Description (140 characters):
```
د افغانستان بشپړ روغتیا اپ: دوکتوران، روغتونونه، درمل لارښود | Afghanistan's complete health app
```

---

### قدم 4: Graphics (اړین!)

تاسو باید دا screenshots او graphics جوړ کړئ:

#### 📱 Phone Screenshots (4-8 اړین):
- Size: **1080x1920px** یا **720x1280px**
- Format: PNG یا JPG
- Screenshots:
  1. Home screen د categories سره
  2. Doctors Directory
  3. Hospitals Directory
  4. Medicine Guide
  5. Community Feed
  6. Language Selection
  7. Health Tips
  8. First Aid Guide

#### 🖼️ Feature Graphic (اړین):
- Size: **1024x500px**
- Design idea:
  ```
  [HealMate Logo] + [Screenshot] + [Text]
  "د افغانستان بشپړ روغتیا اپلیکیشن"
  "Afghanistan's Complete Health App"
  ```

#### 📱 App Icon (512x512px):
- تاسو لا دمخه `/public/icon-512.png` لرئ
- دا upload کړئ

---

### قدم 5: Upload APK/AAB
1. **Production** → **Releases** → **Create new release**
2. ستاسو **AAB** file upload کړئ
3. Release notes لیکئ:

```
Version 1.0.0

د HealMate لومړنۍ نسخه:
• د دوکتورانو او روغتونونو ډایرکټري
• د درملو لارښود
• د اسعافي مرستې معلومات
• د روغتیا مشورې
• درې ژبې: پښتو، دری، انګلیسي

First version of HealMate:
• Doctors and hospitals directory
• Medicine guide
• First aid information
• Health tips
• Three languages: Pashto, Dari, English
```

4. **Review** → **Start rollout to Production**

---

## ⏱️ Review وخت

- Google Play Review: **2-7 ورځې**
- که مسله وي، email به ترلاسه کړئ
- سم کړئ او بیرته submit کړئ

---

## ✅ د Success Checklist

قبل د Submit څخه:

- [ ] App په مختلفو devices test شوی (phone, tablet)
- [ ] درې ژبې ټولې کار کوي
- [ ] ټول features test شوي
- [ ] Icons سم دي
- [ ] manifest.json valid دی
- [ ] Privacy Policy ready دی
- [ ] Screenshots تیار دي
- [ ] Feature graphic جوړ دی
- [ ] د APK/AAB signing سم دی

---

## 🎉 بریا!

ستاسو HealMate app به اوس د افغانستان میلیونونو خلکو ته د لاسرسي وړ وي! 🇦🇫

---

## 📞 د مرستې لپاره

که تاسو کوم مسله لرئ:
- 📧 Email: ibrahimkhaksar.it@gmail.com
- 📱 Phone: +93 783 040 441 / +93 779 494 512

---

## 🚀 ګړندۍ لاره (5 دقیقې):

```
1. App deploy کړئ (Vercel/Netlify)
2. pwabuilder.com ته ورشئ
3. URL داخل کړئ
4. Android → Generate
5. AAB download کړئ
6. Play Console ته upload کړئ
7. بریا! ✅
```

**ستاسو HealMate اوس د Play Store لپاره چمتو دی! 🎊**
