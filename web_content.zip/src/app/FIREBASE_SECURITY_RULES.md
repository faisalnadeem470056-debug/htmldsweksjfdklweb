# 🔐 Firebase Security Rules - د Firebase امنیتي قواعد

## ✅ د Firebase Console کې Security Rules Setup

ستاسو Firebase project اوس وصل دی! اوس باید Security Rules setup کړئ ترڅو ستاسو ډیټا خوندي شي.

---

## 🔥 Firestore Database Rules

### Step 1: Firebase Console ته لاړ شئ

1. https://console.firebase.google.com ته لاړ شئ
2. خپل project **healmate-96c0b** کلیک کړئ
3. د چپ خوا څخه **Firestore Database** کلیک کړئ
4. **Rules** tab کلیک کړئ

### Step 2: لاندې Rules کاپي او Paste کړئ

```javascript
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    
    // =========================================
    // د Users Collection لپاره
    // =========================================
    match /users/{userId} {
      // یوازې login شوی user خپل معلومات لوستلی شي
      allow read: if request.auth != null && request.auth.uid == userId;
      
      // یوازې login شوی user خپل معلومات create او update کولی شي
      allow create: if request.auth != null && request.auth.uid == userId;
      allow update: if request.auth != null && request.auth.uid == userId;
      
      // یوازې login شوی user خپل حساب delete کولی شي
      allow delete: if request.auth != null && request.auth.uid == userId;
    }
    
    // =========================================
    // د Posts Collection لپاره
    // =========================================
    match /posts/{postId} {
      // ټول login شوي users وکړی شي posts لوستل
      allow read: if request.auth != null;
      
      // یوازې login شوی user post جوړولی شي
      allow create: if request.auth != null 
                    && request.resource.data.userId == request.auth.uid;
      
      // یوازې د post مالک update کولی شي
      allow update: if request.auth != null 
                    && resource.data.userId == request.auth.uid;
      
      // یوازې د post مالک delete کولی شي
      allow delete: if request.auth != null 
                    && resource.data.userId == request.auth.uid;
    }
    
    // =========================================
    // د Admin Collection لپاره (Owner Only)
    // =========================================
    match /admin/{document=**} {
      // یوازې owner (ibrahimkhaksar.it@gmail.com) لاسرسی لري
      allow read, write: if request.auth != null 
                         && request.auth.token.email == 'ibrahimkhaksar.it@gmail.com';
    }
    
    // =========================================
    // د Premium Content لپاره
    // =========================================
    match /premium/{document=**} {
      // یوازې premium users وکړی شي لوستل
      allow read: if request.auth != null 
                  && get(/databases/$(database)/documents/users/$(request.auth.uid)).data.isPremium == true;
      
      // یوازې owner وکړی شي لیکل
      allow write: if request.auth != null 
                   && request.auth.token.email == 'ibrahimkhaksar.it@gmail.com';
    }
    
    // =========================================
    // د Health Records لپاره
    // =========================================
    match /healthRecords/{userId}/{record=**} {
      // یوازې user خپل health records لوستلی او لیکلی شي
      allow read, write: if request.auth != null && request.auth.uid == userId;
    }
    
    // =========================================
    // د Appointments لپاره
    // =========================================
    match /appointments/{appointmentId} {
      // د appointment patient او doctor دواړه وکړی شي لوستل
      allow read: if request.auth != null 
                  && (resource.data.patientId == request.auth.uid 
                      || resource.data.doctorId == request.auth.uid);
      
      // یوازې patient appointment جوړولی شي
      allow create: if request.auth != null 
                    && request.resource.data.patientId == request.auth.uid;
      
      // patient او doctor دواړه update کولی شي
      allow update: if request.auth != null 
                    && (resource.data.patientId == request.auth.uid 
                        || resource.data.doctorId == request.auth.uid);
      
      // یوازې patient cancel کولی شي
      allow delete: if request.auth != null 
                    && resource.data.patientId == request.auth.uid;
    }
    
    // =========================================
    // د Medicines لپاره
    // =========================================
    match /medicines/{medicineId} {
      // ټول وکړی شي medicines لوستل
      allow read: if true;
      
      // یوازې owner وکړی شي اضافه/ترمیم کول
      allow write: if request.auth != null 
                   && request.auth.token.email == 'ibrahimkhaksar.it@gmail.com';
    }
    
    // =========================================
    // د Doctors لپاره
    // =========================================
    match /doctors/{doctorId} {
      // ټول وکړی شي doctors لوستل
      allow read: if true;
      
      // یوازې owner او doctor خپل profile update کولی شي
      allow write: if request.auth != null 
                   && (request.auth.token.email == 'ibrahimkhaksar.it@gmail.com'
                       || request.auth.uid == doctorId);
    }
    
    // =========================================
    // د Hospitals لپاره
    // =========================================
    match /hospitals/{hospitalId} {
      // ټول وکړی شي hospitals لوستل
      allow read: if true;
      
      // یوازې owner وکړی شي اضافه/ترمیم کول
      allow write: if request.auth != null 
                   && request.auth.token.email == 'ibrahimkhaksar.it@gmail.com';
    }
  }
}
```

### Step 3: Publish کړئ

1. **Publish** بټن کلیک کړئ
2. "Are you sure?" → **Publish** کلیک کړئ
3. چیک کړئ چې Rules active شوي دي

---

## 📦 Storage Rules

### Step 1: Firebase Console کې Storage ته لاړ شئ

1. د چپ خوا څخه **Storage** کلیک کړئ
2. **Rules** tab کلیک کړئ

### Step 2: لاندې Rules کاپي او Paste کړئ

```javascript
rules_version = '2';
service firebase.storage {
  match /b/{bucket}/o {
    
    // =========================================
    // د Users Avatars لپاره
    // =========================================
    match /users/{userId}/avatar/{fileName} {
      // یوازې login شوی user خپل avatar لوستلی او upload کولی شي
      allow read: if request.auth != null;
      allow write: if request.auth != null && request.auth.uid == userId;
    }
    
    // =========================================
    // د Posts Media لپاره
    // =========================================
    match /posts/{postId}/{fileName} {
      // ټول login شوي users وکړی شي لوستل
      allow read: if request.auth != null;
      
      // یوازې login شوی user upload کولی شي
      allow write: if request.auth != null;
    }
    
    // =========================================
    // د Health Records Files لپاره
    // =========================================
    match /healthRecords/{userId}/{fileName} {
      // یوازې user خپل health records لوستلی او upload کولی شي
      allow read, write: if request.auth != null && request.auth.uid == userId;
    }
    
    // =========================================
    // د Premium Content لپاره
    // =========================================
    match /premium/{fileName} {
      // یوازې premium users وکړی شي لوستل
      allow read: if request.auth != null 
                  && firestore.get(/databases/(default)/documents/users/$(request.auth.uid)).data.isPremium == true;
      
      // یوازې owner upload کولی شي
      allow write: if request.auth != null 
                   && request.auth.token.email == 'ibrahimkhaksar.it@gmail.com';
    }
    
    // =========================================
    // د Medicines Images لپاره
    // =========================================
    match /medicines/{fileName} {
      // ټول وکړی شي لوستل
      allow read: if true;
      
      // یوازې owner upload کولی شي
      allow write: if request.auth != null 
                   && request.auth.token.email == 'ibrahimkhaksar.it@gmail.com';
    }
    
    // =========================================
    // د Doctors Images لپاره
    // =========================================
    match /doctors/{doctorId}/{fileName} {
      // ټول وکړی شي لوستل
      allow read: if true;
      
      // یوازې owner او doctor خپل profile image upload کولی شي
      allow write: if request.auth != null 
                   && (request.auth.token.email == 'ibrahimkhaksar.it@gmail.com'
                       || request.auth.uid == doctorId);
    }
  }
}
```

### Step 3: Publish کړئ

1. **Publish** بټن کلیک کړئ
2. "Are you sure?" → **Publish** کلیک کړئ

---

## 🔐 د Authentication Setup

### Step 1: Authentication فعالول

1. Firebase Console کې **Authentication** کلیک کړئ
2. که لومړی ځل دی، **Get started** کلیک کړئ
3. **Sign-in method** tab کلیک کړئ

### Step 2: Email/Password فعالول

1. **Email/Password** کلیک کړئ
2. **Enable** toggle ON کړئ
3. **Save** کلیک کړئ

### Step 3: د Owner Account جوړول

که تاسو غواړئ، نو کولی شئ په Firebase Console کې خپل owner account لاسي ډول جوړ کړئ:

1. **Authentication** → **Users** tab
2. **Add user** کلیک کړئ
3. Email: `ibrahimkhaksar.it@gmail.com`
4. Password: (خپل password ولیکئ)
5. **Add user** کلیک کړئ

---

## ✅ د Rules تست کول

### د Console کې تست:

1. **Firestore Database** → **Rules** tab
2. د Rules پاسې **Rules playground** کلیک کړئ
3. لاندې simulate کړئ:
   - Location: `/users/test123`
   - Authentication: Authenticated as `test123`
   - Operation: `get`
4. Result باید **Allowed** وښایي

---

## 📊 د Rules منطق

### د Firestore Rules:

```javascript
// د Authentication چیک
request.auth != null              // آیا user login دی؟
request.auth.uid                  // د user ID
request.auth.token.email          // د user email

// د ډیټا چیک
resource.data                     // د موجوده document data
request.resource.data             // د نوي/update شوي document data

// د Firestore بل document لوستل
get(/databases/$(database)/documents/users/$(userId))
```

### د Storage Rules:

```javascript
// د Authentication چیک
request.auth != null              // آیا user login دی؟
request.auth.uid                  // د user ID
request.auth.token.email          // د user email

// د file معلومات
request.resource.size             // د file size (bytes)
request.resource.contentType      // د file type (image/jpeg, etc)

// د Firestore لوستل
firestore.get(/databases/(default)/documents/users/$(userId))
```

---

## ⚠️ مهم یادونې

### د Production لپاره:

1. **هیڅکله د Test Mode Rules استعمال مه کوئ په Production کې!**
   ```javascript
   // ❌ دا خطرناک دی - هر څوک لوستلی او لیکلی شي!
   allow read, write: if true;
   ```

2. **د File Size محدودول:**
   ```javascript
   // ✅ د 5MB څخه کوچنۍ files
   allow write: if request.resource.size < 5 * 1024 * 1024;
   ```

3. **د File Type محدودول:**
   ```javascript
   // ✅ یوازې images
   allow write: if request.resource.contentType.matches('image/.*');
   ```

4. **د ډیټا Validation:**
   ```javascript
   // ✅ ټول ضروري fields شتون ولري
   allow create: if request.resource.data.keys().hasAll(['name', 'email', 'phone']);
   ```

---

## 🎯 د Common Patterns

### Pattern 1: د Owner او خپل User دواړو لاسرسی

```javascript
// Owner او د خپل ډیټا لاسرسی
allow write: if request.auth != null 
             && (request.auth.token.email == 'ibrahimkhaksar.it@gmail.com'
                 || request.auth.uid == userId);
```

### Pattern 2: د Premium Users لپاره

```javascript
// یوازې premium users
allow read: if request.auth != null 
            && get(/databases/$(database)/documents/users/$(request.auth.uid)).data.isPremium == true;
```

### Pattern 3: د Specific Roles لپاره

```javascript
// یوازې doctors او admins
allow write: if request.auth != null 
             && get(/databases/$(database)/documents/users/$(request.auth.uid)).data.role in ['doctor', 'admin'];
```

---

## 🧪 د Testing Commands

د Browser Console کې تست کړئ:

```javascript
// د Firestore تست
import { getFirestore, collection, getDocs } from 'firebase/firestore';
const db = getFirestore();
const users = await getDocs(collection(db, 'users'));
console.log('Users:', users.docs.map(doc => doc.data()));

// د Storage تست
import { getStorage, ref, uploadBytes } from 'firebase/storage';
const storage = getStorage();
const storageRef = ref(storage, 'test/file.txt');
await uploadBytes(storageRef, new Blob(['test']));
console.log('File uploaded!');
```

---

## 📞 د مرستې لپاره

که Security Rules کې ستونزه شي:

1. **Console کې Errors چیک کړئ** (F12)
2. **Firebase Console → Firestore → Rules → Logs** وګورئ
3. د `request.auth` او `resource.data` values چیک کړئ
4. د Rules playground استعمال کړئ د testing لپاره

---

## 🎊 خلاصه

- ✅ **Firestore Rules** - د ټولو collections لپاره secure rules
- ✅ **Storage Rules** - د files لپاره secure rules
- ✅ **Authentication** - Email/Password فعال
- ✅ **Owner Protection** - یوازې ibrahimkhaksar.it@gmail.com ته admin access
- ✅ **User Privacy** - هر user یوازې خپل ډیټا لیدلی شي

---

**🔐 اوس ستاسو Firebase بشپړ خوندي دی!**
