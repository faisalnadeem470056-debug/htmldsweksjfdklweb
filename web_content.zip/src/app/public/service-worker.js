// HealMate Service Worker - PWA Support
const CACHE_NAME = 'healmate-v1.0.0';
const RUNTIME_CACHE = 'healmate-runtime-v1';

// د cache کولو فایلونه
const PRECACHE_ASSETS = [
  '/',
  '/index.html',
  '/manifest.json',
  '/icons/icon-192x192.png',
  '/icons/icon-512x512.png'
];

// Install Event - د فایلونو precaching
self.addEventListener('install', (event) => {
  console.log('[Service Worker] Installing...');
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then((cache) => {
        console.log('[Service Worker] Precaching assets');
        return cache.addAll(PRECACHE_ASSETS);
      })
      .then(() => self.skipWaiting())
  );
});

// Activate Event - د زړو caches پاکول
self.addEventListener('activate', (event) => {
  console.log('[Service Worker] Activating...');
  event.waitUntil(
    caches.keys().then((cacheNames) => {
      return Promise.all(
        cacheNames
          .filter((cacheName) => {
            return cacheName !== CACHE_NAME && cacheName !== RUNTIME_CACHE;
          })
          .map((cacheName) => {
            console.log('[Service Worker] Deleting old cache:', cacheName);
            return caches.delete(cacheName);
          })
      );
    }).then(() => self.clients.claim())
  );
});

// Fetch Event - Network-First Strategy د API لپاره، Cache-First د Images لپاره
self.addEventListener('fetch', (event) => {
  const { request } = event;
  const url = new URL(request.url);

  // د API requests لپاره Network-First
  if (url.pathname.startsWith('/api/') || url.pathname.includes('supabase')) {
    event.respondWith(
      fetch(request)
        .then((response) => {
          // که response سم وي، په cache کې save کړئ
          if (response && response.status === 200) {
            const responseClone = response.clone();
            caches.open(RUNTIME_CACHE).then((cache) => {
              cache.put(request, responseClone);
            });
          }
          return response;
        })
        .catch(() => {
          // که network fail شي، له cache څخه واخلئ
          return caches.match(request);
        })
    );
    return;
  }

  // د نورو resources لپاره Cache-First
  event.respondWith(
    caches.match(request)
      .then((cachedResponse) => {
        if (cachedResponse) {
          return cachedResponse;
        }

        return fetch(request).then((response) => {
          // که valid response وي، په cache کې save کړئ
          if (!response || response.status !== 200 || response.type === 'error') {
            return response;
          }

          const responseClone = response.clone();
          caches.open(RUNTIME_CACHE).then((cache) => {
            cache.put(request, responseClone);
          });

          return response;
        });
      })
      .catch(() => {
        // که offline وي او cache کې هم نه وي، offline page وښایئ
        return caches.match('/offline.html');
      })
  );
});

// Background Sync - د offline data sync لپاره
self.addEventListener('sync', (event) => {
  console.log('[Service Worker] Background Sync:', event.tag);
  if (event.tag === 'sync-data') {
    event.waitUntil(syncData());
  }
});

// Push Notifications Support
self.addEventListener('push', (event) => {
  console.log('[Service Worker] Push Notification received');
  
  const options = {
    body: event.data ? event.data.text() : 'نوې خبرتیا',
    icon: '/icons/icon-192x192.png',
    badge: '/icons/badge-72x72.png',
    vibrate: [200, 100, 200],
    tag: 'healmate-notification',
    requireInteraction: false,
    actions: [
      {
        action: 'open',
        title: 'خلاص کړئ',
        icon: '/icons/open.png'
      },
      {
        action: 'close',
        title: 'بند',
        icon: '/icons/close.png'
      }
    ]
  };

  event.waitUntil(
    self.registration.showNotification('HealMate', options)
  );
});

// Notification Click Handler
self.addEventListener('notificationclick', (event) => {
  console.log('[Service Worker] Notification clicked:', event.action);
  
  event.notification.close();

  if (event.action === 'open') {
    event.waitUntil(
      clients.openWindow('/')
    );
  }
});

// Helper function - د data sync لپاره
async function syncData() {
  try {
    console.log('[Service Worker] Syncing offline data...');
    // دلته offline data sync logic اضافه کړئ
    return Promise.resolve();
  } catch (error) {
    console.error('[Service Worker] Sync failed:', error);
    return Promise.reject(error);
  }
}

// د Update خبرتیا
self.addEventListener('message', (event) => {
  if (event.data && event.data.type === 'SKIP_WAITING') {
    self.skipWaiting();
  }
});

console.log('[Service Worker] Loaded successfully! 🚀');
