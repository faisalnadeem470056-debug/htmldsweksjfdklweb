import { useState } from 'react';
import { Settings, Check } from 'lucide-react';
import { Button } from './components/ui/button';
import { Input } from './components/ui/input';
import { Label } from './components/ui/label';

export default function TestAdmin() {
  const [activeTab, setActiveTab] = useState('settings');
  const [appName, setAppName] = useState('HealMate');
  const [appVersion, setAppVersion] = useState('1.0.0');
  const [email, setEmail] = useState('ibrahimkhaksar.it@gmail.com');
  const [phone, setPhone] = useState('+93 700 000 000');

  const handleSave = () => {
    alert('✅ په بریالیتوب سره خوندي شو!\n\nApp Name: ' + appName + '\nVersion: ' + appVersion + '\nEmail: ' + email + '\nPhone: ' + phone);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-gray-50 to-zinc-50 p-6">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="bg-gradient-to-r from-red-500 to-pink-600 rounded-2xl p-6 text-white mb-6">
          <div className="flex items-center gap-3">
            <Settings className="w-8 h-8" />
            <div>
              <h1 className="text-2xl font-bold">Settings Test Page</h1>
              <p className="text-white/90">د تنظیماتو ټیسټ پاڼه</p>
            </div>
          </div>
        </div>

        {/* Settings Form */}
        <div className="bg-white rounded-2xl p-6 border border-gray-200 shadow-lg">
          <h2 className="text-xl font-medium mb-6 flex items-center gap-2">
            <Settings className="w-5 h-5 text-gray-600" />
            د اپلیکیشن تنظیمات
          </h2>
          
          <div className="space-y-4">
            {/* App Name */}
            <div>
              <Label htmlFor="appName">د اپلیکیشن نوم</Label>
              <Input 
                id="appName"
                value={appName}
                onChange={(e) => setAppName(e.target.value)}
                placeholder="HealMate"
              />
            </div>
            
            {/* App Version */}
            <div>
              <Label htmlFor="appVersion">نسخه</Label>
              <Input 
                id="appVersion"
                value={appVersion}
                onChange={(e) => setAppVersion(e.target.value)}
                placeholder="1.0.0"
              />
            </div>
            
            {/* Contact Email */}
            <div>
              <Label htmlFor="email">د اړیکې برېښنالیک</Label>
              <Input 
                id="email"
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="email@example.com"
              />
            </div>
            
            {/* Contact Phone */}
            <div>
              <Label htmlFor="phone">د اړیکې نمبر</Label>
              <Input 
                id="phone"
                type="tel"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                placeholder="+93 700 000 000"
              />
            </div>

            {/* Social Links */}
            <div className="pt-4 border-t">
              <h3 className="font-medium mb-3">ټولنیز لینکونه</h3>
              <div className="space-y-3">
                <div>
                  <Label htmlFor="facebook">فیسبوک</Label>
                  <Input 
                    id="facebook"
                    placeholder="https://facebook.com/healmate"
                  />
                </div>
                <div>
                  <Label htmlFor="instagram">انسټاګرام</Label>
                  <Input 
                    id="instagram"
                    placeholder="https://instagram.com/healmate"
                  />
                </div>
                <div>
                  <Label htmlFor="twitter">ټویټر</Label>
                  <Input 
                    id="twitter"
                    placeholder="https://twitter.com/healmate"
                  />
                </div>
              </div>
            </div>

            {/* Save Button */}
            <div className="pt-4">
              <Button 
                onClick={handleSave}
                className="w-full bg-gradient-to-r from-red-500 to-pink-600 hover:from-red-600 hover:to-pink-700"
              >
                <Check className="w-4 h-4 mr-2" />
                خوندي کول (Save)
              </Button>
            </div>
          </div>
        </div>

        {/* Test Info */}
        <div className="mt-6 bg-blue-50 rounded-2xl p-6 border border-blue-200">
          <h3 className="font-semibold text-blue-900 mb-3">📝 ټیسټ معلومات:</h3>
          <div className="space-y-2 text-sm text-blue-800">
            <p>✅ Settings ټب بشپړ کار کوي</p>
            <p>✅ ټول input fields کار کوي</p>
            <p>✅ Save button کلیک کیدای شي</p>
            <p>✅ د معلوماتو بدلول کار کوي</p>
          </div>
        </div>

        {/* Debug Info */}
        <div className="mt-4 bg-gray-100 rounded-xl p-4 text-xs font-mono">
          <div className="grid grid-cols-2 gap-2">
            <div>App Name: <span className="text-blue-600">{appName}</span></div>
            <div>Version: <span className="text-blue-600">{appVersion}</span></div>
            <div>Email: <span className="text-blue-600">{email}</span></div>
            <div>Phone: <span className="text-blue-600">{phone}</span></div>
          </div>
        </div>
      </div>
    </div>
  );
}
