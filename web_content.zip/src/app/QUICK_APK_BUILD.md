# 🚀 د HealMate APK - ګړندۍ لارښود | Quick APK Guide

---

## ⚡ ترټولو ګړندۍ لاره: PWA (5 دقیقې)

### څه دي PWA؟
د Progressive Web App - یو web app چې د native app په څیر کار کوي!

### ګټې:
- ✅ **اوس چمتو دی!** - هیڅ coding نه غواړي
- ✅ **د home screen ته install** کیدای شي
- ✅ **Offline کار کوي** - بې انټرنیټ
- ✅ **Push notifications** - د notification support
- ✅ **کوچنی حجم** - د browser له لارې
- ✅ **اتوماتیک updates** - هیڅ manual update نه

---

## 📱 څنګه Install کړئ؟

### د Android Phone لپاره:

```
1. 📱 د Chrome Browser خلاص کړئ
2. 🌐 HealMate website ته لاړ شئ
3. ⋮ د Browser Menu خلاص کړئ (3 dots)
4. ⬇️ "Add to Home screen" کلیک کړئ
5. ✅ Install کلیک کړئ
6. 🎉 HealMate اوس په Home Screen کې دی!
```

### څه وصل دي؟

زموږ HealMate اوس بشپړ PWA دی:

- ✅ `/public/manifest.json` - د App معلومات
- ✅ `/public/sw.js` - د Offline support
- ✅ `/index.html` - د Install prompt
- ✅ App Icons (192x192, 512x512)

---

## 🔥 د Native APK لپاره (Google Play Store)

که تاسو یو ریښتیني `.apk` فایل غواړئ:

### مخکې څه غواړي؟

```bash
✅ Node.js (v16+)
✅ Android Studio
✅ Java JDK
```

### ګړندي Commands:

```bash
# 1. د Capacitor Install کړئ
npm install @capacitor/core @capacitor/cli @capacitor/android

# 2. د Production Build جوړ کړئ
npm run build

# 3. د Android Platform اضافه کړئ
npx cap add android

# 4. د Capacitor Sync کړئ
npx cap sync

# 5. Android Studio خلاص کړئ
npx cap open android

# 6. د APK Build کړئ
# په Android Studio کې:
# Build → Build Bundle(s) / APK(s) → Build APK(s)
```

### د APK موقعیت:

```
android/app/build/outputs/apk/debug/app-debug.apk
```

---

## 📤 Google Play Store Upload

### 1. Google Play Console ته لاړ شئ
```
https://play.google.com/console
```

### 2. نوی App جوړ کړئ
- App name: **HealMate**
- Category: **Medical**
- Free or Paid: **Free**

### 3. د App معلومات
- Title: **HealMate - Healthcare App for Afghanistan**
- Email: **ibrahimkhaksar.it@gmail.com**
- Phone: **+93783040441**

### 4. د APK Upload کړئ
- د Release APK انتخاب کړئ
- Upload کړئ
- Submit for Review

### 5. د Review Waiting
- ⏱️ 3-7 ورځې
- ✅ Approved وروسته: Live په Play Store!

---

## 🎯 Quick Summary

| لاره | وخت | سختي | استعمال |
|------|------|------|---------|
| **PWA** | 5 دقیقې | ډیر اسانه | Personal use |
| **APK** | 2-3 ساعته | منځنی | Play Store |

---

## 📞 مرسته غواړئ؟

- 📧 **Email:** ibrahimkhaksar.it@gmail.com
- 📱 **Phone 1:** +93783040441
- 📱 **Phone 2:** +93779494512

---

## 📚 بشپړ لارښودونه

د تفصیلي معلوماتو لپاره:

- 📖 **`BUILD_ANDROID_APK_GUIDE.md`** - بشپړ د APK جوړولو لارښود
- 📖 **`README.md`** - عمومي معلومات
- 📖 **`FIREBASE_SETUP_GUIDE.md`** - د Firebase تنظیم

---

## ✅ Checklist

### د PWA لپاره:
- [x] ✅ manifest.json موجود دی
- [x] ✅ Service Worker موجود دی
- [x] ✅ Icons موجود دي
- [x] ✅ Install prompt موجود دی
- [x] ✅ **چمتو دی! یوازې host کړئ**

### د Native APK لپاره:
- [ ] Android Studio installed
- [ ] Capacitor installed
- [ ] `npm run build` کار کوي
- [ ] `npx cap add android` کړی
- [ ] د APK build شوی

---

**🚀 ستاسو HealMate د APK جوړولو لپاره چمتو دی!**

**د بریالیتوب سره، HealMate Team** 💚
