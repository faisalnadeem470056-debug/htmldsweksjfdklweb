# ✅ Play Store Submission Checklist
## د HealMate Android App لپاره

د **ډاکټر ابراهیم خاکسار** لخوا جوړ شوی

---

## 📱 App Information

- **App Name**: HealMate - Afghanistan Health App
- **Package Name**: `com.drkhaksar.healmate`
- **Developer**: Dr. Ibrahim Khaksar
- **Email**: ibrahimkhaksar.it@gmail.com
- **Phone**: +93 779 494 512
- **Category**: Medical / Health & Fitness
- **Price**: Free (د AdMob اعلانات سره)

---

## 🔥 Firebase Setup Checklist

### ✅ Firebase Console
- [ ] Firebase project جوړ شو: `healmate-afghanistan`
- [ ] Android app register شو
- [ ] `google-services.json` ډاونلوډ او په `/android/app/` کې کاپي شو
- [ ] SHA-1 fingerprint اضافه شو (Debug او Release دواړه)
- [ ] SHA-256 fingerprint اضافه شو

### ✅ Firebase Services
- [ ] **Authentication** فعال شو:
  - [ ] Email/Password
  - [ ] Google Sign-In
  - [ ] Phone Authentication
- [ ] **Firestore Database** جوړ شو
- [ ] **Cloud Storage** setup شو
- [ ] **Cloud Messaging (FCM)** فعال شو
- [ ] **Analytics** فعال شو
- [ ] **Crashlytics** setup شو
- [ ] **Performance Monitoring** فعال شو

### ✅ Firebase Config Files
- [ ] `/firebase-config.ts` د Firebase معلوماتو سره تازه شو
- [ ] د Firebase rules setup شول
- [ ] د Security rules test شول

---

## 💰 AdMob Setup Checklist

### ✅ AdMob Console
- [ ] AdMob account جوړ شو
- [ ] App register شو په AdMob کې
- [ ] د Firebase سره link شو

### ✅ Ad Units Created
- [ ] **Banner Ad** unit جوړ شو
  - Ad Unit ID: `_______________________`
- [ ] **Interstitial Ad** unit جوړ شو
  - Ad Unit ID: `_______________________`
- [ ] **Rewarded Ad** unit جوړ شو
  - Ad Unit ID: `_______________________`

### ✅ AdMob Integration
- [ ] AdMob App ID په `AndroidManifest.xml` کې اضافه شو
- [ ] د Ad Unit IDs په `/firebase-config.ts` کې اضافه شول
- [ ] Test ads کار کوي
- [ ] د Production لپاره test mode غیرفعال شو

---

## 🌐 TWA Setup Checklist

### ✅ Domain Setup
- [ ] Domain register شو: `_______________________`
- [ ] SSL certificate install شو (HTTPS)
- [ ] PWA deploy شو په domain کې
- [ ] PWA manifest.json صحیح دی
- [ ] Service Worker کار کوي

### ✅ Digital Asset Links
- [ ] SHA-256 fingerprint ترلاسه شو
- [ ] `assetlinks.json` فایل جوړ شو
- [ ] `assetlinks.json` په `.well-known/` folder کې upload شو
- [ ] Asset links verify شول (د Google tool سره)
- [ ] د AndroidManifest.xml کې asset_statements اضافه شو

### ✅ TWA Configuration
- [ ] د `build.gradle` کې domain اضافه شو
- [ ] د `AndroidManifest.xml` کې defaultUrl setup شو
- [ ] د Splash screen صحیح ښکاري

---

## 🔨 Build Checklist

### ✅ Release Keystore
- [ ] Release keystore جوړ شو: `healmate-release.keystore`
- [ ] Keystore معلومات خوندي ذخیره شول
- [ ] د `gradle.properties` فایل جوړ شو
- [ ] Keystore password قوي دی
- [ ] د `.gitignore` کې keystore او gradle.properties اضافه شول

### ✅ Build Configuration
- [ ] د `versionCode` صحیح دی: `1`
- [ ] د `versionName` صحیح دی: `1.0.0`
- [ ] د `applicationId` صحیح دی: `com.drkhaksar.healmate`
- [ ] د ProGuard rules setup شول
- [ ] د signing config صحیح دی

### ✅ Build Files
- [ ] Debug APK بریالیتوب سره جوړ شو
- [ ] Release APK بریالیتوب سره جوړ شو
- [ ] Release AAB بریالیتوب سره جوړ شو
- [ ] د APK/AAB size معقول دی (< 50MB)

---

## 🎨 Graphics & Assets Checklist

### ✅ App Icon
- [ ] App icon 512x512 px (PNG, 32-bit)
- [ ] App icon transparent background نلري
- [ ] App icon واضح او professional دی
- [ ] Round icon هم شته

### ✅ Feature Graphic
- [ ] Feature graphic 1024x500 px جوړ شو
- [ ] د HealMate logo او tagline پکې شته
- [ ] په پښتو، دری، او انګلیسي text شته

### ✅ Screenshots
د Phone (کمز کم 2):
- [ ] Screenshot 1: Home screen
- [ ] Screenshot 2: Doctors directory
- [ ] Screenshot 3: Medicine guide
- [ ] Screenshot 4: Emergency SOS
- [ ] Screenshot 5: Community/Posts
- [ ] Screenshot 6: Profile page

د 7-inch Tablet (اختیاري):
- [ ] Tablet screenshot 1
- [ ] Tablet screenshot 2

د 10-inch Tablet (اختیاري):
- [ ] Tablet screenshot 1
- [ ] Tablet screenshot 2

### ✅ Video (اختیاري)
- [ ] د YouTube promotional video link

---

## 📝 Store Listing Checklist

### ✅ Basic Information
- [ ] **App name**: HealMate - Afghanistan Health App
- [ ] **Short description** (80 chars max):
```
د افغانستان بشپړ روغتیایي اپلیکیشن - ډاکټران، روغتونونه، درمل، او نور
```
- [ ] **Full description** (4000 chars max) - د پښتو، دری، او انګلیسي سره
- [ ] **Category**: Medical
- [ ] **Tags**: health, medicine, doctors, afghanistan, pashto, dari

### ✅ Contact Details
- [ ] **Email**: ibrahimkhaksar.it@gmail.com
- [ ] **Phone**: +93 779 494 512
- [ ] **Website**: https://YOUR_DOMAIN.com
- [ ] **Privacy Policy URL**: https://YOUR_DOMAIN.com/privacy

### ✅ Languages
- [ ] د پښتو (Pashto) translation بشپړ دی
- [ ] د دری (Dari) translation بشپړ دی  
- [ ] د انګلیسي (English) translation بشپړ دی

---

## 🔒 App Content Checklist

### ✅ Privacy & Security
- [ ] Privacy Policy جوړ شو او online upload شو
- [ ] Terms of Service جوړ شول او online upload شول
- [ ] د Data safety form بشپړ شو:
  - [ ] د Data collection معلومات واضح دي
  - [ ] د Data sharing معلومات واضح دي
  - [ ] د Data security معلومات واضح دي

### ✅ Content Rating
- [ ] د Content rating questionnaire بشپړ شو
- [ ] د PEGI rating ترلاسه شو
- [ ] د ESRB rating ترلاسه شو

### ✅ Target Audience
- [ ] **Age rating**: 18+ (د medical content لپاره)
- [ ] **Target country**: Afghanistan, Pakistan, India
- [ ] **Primary language**: Pashto

### ✅ Ads Declaration
- [ ] ✅ "App contains ads" select شو
- [ ] د AdMob ads صحیح setup شول
- [ ] د Ads placement مناسب دی (نه ډېر intrusive)

---

## 🧪 Testing Checklist

### ✅ Internal Testing
- [ ] د Internal testing track setup شو
- [ ] Testers اضافه شول
- [ ] APK/AAB په internal testing کې upload شو
- [ ] د 7 ورځو لپاره test شو
- [ ] ټول bugs fix شول

### ✅ Closed Testing
- [ ] د Closed testing track setup شو
- [ ] د 20-50 testers اضافه شول
- [ ] د 14 ورځو لپاره test شو
- [ ] Feedback راغونډ شو
- [ ] د feedback base پر improvements شول

### ✅ Functionality Testing
- [ ] ټول pages او features کار کوي
- [ ] د Login/Signup سیسټم کار کوي
- [ ] د Firebase integration کار کوي
- [ ] د AdMob ads ښکاري
- [ ] د PWA offline mode کار کوي
- [ ] د Push notifications کار کوي
- [ ] د Share functionality کار کوي
- [ ] د Deep links کار کوي

### ✅ Device Testing
د مختلفو devices پر test شو:
- [ ] د Android 7.0 (API 24) پر
- [ ] د Android 8.0 (API 26) پر
- [ ] د Android 9.0 (API 28) پر
- [ ] د Android 10 (API 29) پر
- [ ] د Android 11 (API 30) پر
- [ ] د Android 12+ (API 31+) پر
- [ ] د مختلفو screen sizes پر

### ✅ Performance Testing
- [ ] App چټک launch کیږي (< 3 seconds)
- [ ] د Smooth scrolling
- [ ] د Memory usage reasonable دی
- [ ] د Battery consumption مناسب دی
- [ ] د Data usage acceptable دی

---

## 📋 Pre-Launch Report Checklist

د Play Console کې Pre-launch report:
- [ ] د Crashes نشته
- [ ] د ANR (App Not Responding) نشته
- [ ] د Security vulnerabilities نشته
- [ ] د Accessibility issues resolve شول
- [ ] د Pre-launch tests بشپړ pass شول

---

## 🚀 Production Release Checklist

### ✅ Final Review
- [ ] د App بشپړ کار کوي
- [ ] ټول content صحیح دی
- [ ] د Graphics بشپړ او professional دي
- [ ] د Store listing بې نقصه دی
- [ ] د Legal documents (Privacy, Terms) موجود دي

### ✅ Release Configuration
- [ ] د Release name: "Initial Release v1.0.0"
- [ ] د Release notes په درې ژبو:
  - [ ] پښتو
  - [ ] دری
  - [ ] انګلیسي
- [ ] د Countries selection: Afghanistan, Pakistan, India
- [ ] د Rollout percentage: 100%

### ✅ Release Notes (په درې ژبو)

**پښتو:**
```
🎉 د HealMate لومړۍ نسخه!

د افغانستان لپاره بشپړ روغتیایي اپلیکیشن په پښتو، دری، او انګلیسي ژبو کې.

✨ لویې فیچرونه:
• د ډاکټرانو او روغتونونو مکمل ډایرکټري
• د درملو بشپړ معلومات او لارښوونه
• د لومړنۍ مرستې لارښوونې
• د بیړني حالت SOS سیسټم
• AI روغتیایي چیټ بوټ
• د روغتیا ټپونه او نصیحتونه
• او نور ډېر...

د ډاکټر ابراهیم خاکسار لخوا ❤️
```

**دری:**
```
🎉 نسخه اول HealMate!

برنامه کامل صحی برای افغانستان به زبان‌های پشتو، دری و انگلیسی.

✨ ویژگی‌های عمده:
• فهرست کامل داکتران و شفاخانه‌ها
• اطلاعات کامل دارو و راهنمایی
• راهنمای کمک‌های اولیه
• سیستم SOS اضطراری
• چت بات صحی AI
• نکات و توصیه‌های صحی
• و خیلی بیشتر...

توسط داکتر ابراهیم خاکسار ❤️
```

**English:**
```
🎉 First Release of HealMate!

Complete health application for Afghanistan in Pashto, Dari, and English.

✨ Major Features:
• Complete directory of doctors and hospitals
• Comprehensive medicine information and guidance
• First aid guidelines
• Emergency SOS system
• AI health chatbot
• Health tips and advice
• And much more...

By Dr. Ibrahim Khaksar ❤️
```

### ✅ Post-Release
- [ ] د Release submission بریالیتوب سره وشو
- [ ] د Google review process پیل شو
- [ ] د Review status regularly چیک کړئ
- [ ] د User feedback monitor کړئ
- [ ] د Crash reports چیک کړئ
- [ ] د Performance metrics monitor کړئ

---

## 🎯 Success Criteria

### د Launch وروسته:
- ✅ App په Play Store کې live شو
- ✅ د Downloads > 1000 په لومړۍ مياشت کې
- ✅ د Rating > 4.0 stars
- ✅ د Crash rate < 1%
- ✅ د ANR rate < 0.5%

---

## 📞 د مرستې معلومات

که چیرې د Play Store submission کې مسله وي:

### د Google Play Support:
- https://support.google.com/googleplay/android-developer

### د HealMate Developer:
- 📧 Email: ibrahimkhaksar.it@gmail.com
- 📱 WhatsApp: +93 779 494 512
- 💳 Hesab Pay: +93 779 494 512

---

## 🔄 د Rejection Scenarios

که چیرې app reject شي، ممکنه دلایل:

### Common Rejection Reasons:
1. ❌ د Privacy Policy نشتوالی
2. ❌ د Content rating نه بشپړول
3. ❌ د Screenshots کمښت
4. ❌ د Sensitive permissions بغیر توضیح
5. ❌ د Copyright infringement
6. ❌ د Malware یا Security issues
7. ❌ د Store listing incomplete
8. ❌ د Ads ډېر intrusive

### د Rejection وروسته:
1. د rejection email غور سره ولولئ
2. د problems fix کړئ
3. د changes document کړئ
4. بیا submit کړئ د detailed explanation سره

---

## ✅ Final Checklist Summary

د Production release دمخه:
- [ ] ✅ Firebase بشپړ setup دی
- [ ] ✅ AdMob بشپړ configure دی
- [ ] ✅ TWA صحیح کار کوي
- [ ] ✅ Digital Asset Links verify شول
- [ ] ✅ Release AAB جوړ شو
- [ ] ✅ Graphics او screenshots بشپړ دي
- [ ] ✅ Store listing بشپړ دی
- [ ] ✅ Privacy Policy او Terms موجود دي
- [ ] ✅ Content rating بشپړ دی
- [ ] ✅ Testing بشپړ شو
- [ ] ✅ د Pre-launch report سبز دی

**تیار یاست د Submit لپاره؟ بریالیتوب مبارک! 🎉**

---

د **ډاکټر ابراهیم خاکسار** لخوا جوړ شوی
HealMate - د افغانستان بشپړ روغتیایي اپلیکیشن
تاریخ: November 28, 2025
