# ⚡ 5 دقیقې - Deploy اوس!
# 5 Minutes - Deploy NOW!

---

## 🚨 ترټولو ګړندۍ لاره - بغیر GitHub

---

## 1️⃣ Vercel CLI Install (30 ثانیې)

Terminal/CMD open کړئ:

```bash
npm install -g vercel
```

**که npm نشته:**
- Windows: https://nodejs.org/en/download (Download او install کړئ)
- Mac: `brew install node`

---

## 2️⃣ Login (30 ثانیې)

```bash
vercel login
```

- Browser به open شي
- "Continue with Email" یا "Continue with GitHub"
- ✅ Authorize کړئ

---

## 3️⃣ د Project Folder ته ورشئ (10 ثانیې)

```bash
# د Figma Make څخه ستاسو project download کړئ
# Terminal کې د folder ته ورشئ:

cd /path/to/healmate-app

# مثال:
# Windows: cd C:\Users\YourName\Downloads\healmate-app
# Mac: cd ~/Downloads/healmate-app
```

---

## 4️⃣ Deploy! (3 دقیقې)

```bash
vercel
```

### سوالات او ځوابونه:

```
Set up and deploy? → Y
Which scope? → [Enter کلیک وکړئ]
Link to existing project? → N
Project name? → healmate-app
Code directory? → ./
Modify settings? → N
```

### بیا Production:

```bash
vercel --prod
```

---

## 5️⃣ URL Copy کړئ! (5 ثانیې)

Terminal کې به ستاسو URL ښکاره شي:

```
✅ Production: https://healmate-app.vercel.app
```

**دا URL copy کړئ!** ✅

---

## 6️⃣ PWABuilder ته ورشئ (2 دقیقې)

```
1. https://www.pwabuilder.com
2. URL داخل کړئ: https://healmate-app.vercel.app
3. "Start" کلیک وکړئ
4. Android → Generate
5. ✅ APK Download!
```

---

## ✅ بشپړ شو!

**ټول وخت: 5-6 دقیقې**

---

## 🔄 د Updates Deploy کول:

کله چې code بدل کړئ:

```bash
vercel --prod
```

دا یې! ✅

---

## 🆘 که مسله لرئ:

### "Command not found: vercel"
```bash
npm install -g vercel
```

### "No package.json"
```bash
# یقیني کړئ په سم folder کې یاست:
ls
# باید package.json وګورئ
```

### "Build failed"
```bash
npm install
vercel --prod
```

---

## 📞 مرسته:

- 📧 ibrahimkhaksar.it@gmail.com
- 📱 +93 783 040 441

---

## 🎯 Quick Reference:

```bash
# Install
npm install -g vercel

# Login
vercel login

# د folder ته ورشئ
cd /path/to/healmate-app

# Deploy
vercel --prod

# ✅ URL ترلاسه کړئ
```

---

**بریا! اوس PWABuilder ته ورشئ! 🚀**
