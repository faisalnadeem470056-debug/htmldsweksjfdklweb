# 🚀 HealMate - Quick Start Guide
د ډاکټر ابراهیم خاکسار لخوا جوړ شوی

---

## 📱 د HealMate څه دی؟

**HealMate** د افغانستان لپاره یو بشپړ، وړیا، او حرفه‌ای روغتیایي اپلیکیشن دی چې په **پښتو**، **دری**، او **انګلیسي** ژبو کې شته دی.

---

## ⚡ Quick Setup (5 دقیقو کې)

### 1️⃣ د Repository Clone کول

```bash
git clone https://github.com/YOUR_USERNAME/healmate.git
cd healmate
```

### 2️⃣ د Dependencies Install کول

```bash
npm install
```

### 3️⃣ د Development Server پیل کول

```bash
npm run dev
```

بس! اپلیکیشن په `http://localhost:5173` کې چلیږي 🎉

---

## 🔥 د Firebase Setup (15 دقیقې)

### Step 1: د Firebase Project جوړول

1. https://console.firebase.google.com ته لاړشئ
2. **"Add project"** کلیک کړئ
3. Project name: `healmate-afghanistan`
4. Continue کلیک کړئ

### Step 2: د Web App اضافه کول

1. **Project Overview** کې web icon (</>) کلیک کړئ
2. App nickname: `HealMate Web`
3. **Register app** کلیک کړئ
4. د Config معلومات کاپي کړئ

### Step 3: د Config فایل تازه کول

په `/firebase-config.ts` کې خپل معلومات اضافه کړئ:

```typescript
export const firebaseConfig = {
  apiKey: "YOUR_API_KEY",
  authDomain: "healmate-afghanistan.firebaseapp.com",
  projectId: "healmate-afghanistan",
  storageBucket: "healmate-afghanistan.appspot.com",
  messagingSenderId: "YOUR_SENDER_ID",
  appId: "YOUR_APP_ID",
  measurementId: "YOUR_MEASUREMENT_ID"
};
```

### Step 4: د Firebase Services فعالول

#### Authentication:
```
Firebase Console > Authentication > Sign-in method
✅ Enable: Email/Password
✅ Enable: Google
✅ Enable: Phone
```

#### Firestore:
```
Firebase Console > Firestore Database > Create database
Location: asia-south1 (India)
Start in: Production mode
```

#### Storage:
```
Firebase Console > Storage > Get started
```

---

## 💰 د AdMob Setup (10 دقیقې)

### Step 1: د AdMob Account جوړول

1. https://admob.google.com ته لاړشئ
2. **Get Started** کلیک کړئ
3. د Google account سره sign in کړئ

### Step 2: د App Registration

1. **Apps > Add App** کلیک کړئ
2. Platform: **Android**
3. App name: **HealMate**

### Step 3: د Ad Units جوړول

```
Ad Units > Add Ad Unit:
1. Banner Ad → "HealMate_Banner_Home"
2. Interstitial Ad → "HealMate_Interstitial"
3. Rewarded Ad → "HealMate_Rewarded"
```

### Step 4: د AdMob Config تازه کول

په `/firebase-config.ts` کې:

```typescript
export const adMobConfig = {
  androidAppId: "YOUR_ADMOB_APP_ID",
  bannerAdId: "YOUR_BANNER_AD_ID",
  interstitialAdId: "YOUR_INTERSTITIAL_AD_ID",
  rewardedAdId: "YOUR_REWARDED_AD_ID",
  testMode: false
};
```

---

## 📱 د Android App جوړول (30 دقیقې)

### د Windows لپاره:

```bash
# د Setup script چلول
setup-android.bat
```

### د Mac/Linux لپاره:

```bash
# د Setup script چلول
chmod +x setup-android.sh
./setup-android.sh
```

### Manual Build:

```bash
# 1. د PWA build جوړول
npm run build

# 2. د Android folder ته لاړشئ
cd android

# 3. د Debug APK جوړول
./gradlew assembleDebug

# 4. د Release AAB جوړول (Play Store لپاره)
./gradlew bundleRelease
```

---

## 🌐 د TWA Setup

### 1️⃣ د Domain Configuration

په `/android/app/build.gradle` کې:

```gradle
manifestPlaceholders = [
    hostName: "YOUR_DOMAIN.com",
    defaultUrl: "https://YOUR_DOMAIN.com"
]
```

### 2️⃣ د Digital Asset Links

د `assetlinks.json` جوړول په `.well-known/` folder کې:

```json
[{
  "relation": ["delegate_permission/common.handle_all_urls"],
  "target": {
    "namespace": "android_app",
    "package_name": "com.drkhaksar.healmate",
    "sha256_cert_fingerprints": ["YOUR_SHA256_HERE"]
  }
}]
```

د SHA256 ترلاسه کول:

```bash
keytool -list -v -keystore ~/.android/debug.keystore -alias androiddebugkey -storepass android -keypass android | grep SHA256
```

---

## 🏪 د Play Store Submission

### د AAB Upload کول:

1. https://play.google.com/console ته لاړشئ
2. **Create app** کلیک کړئ
3. App details بشپړ کړئ
4. د **Internal testing** track ته AAB upload کړئ
5. د Testing وروسته **Production** ته promote کړئ

---

## 📂 د پروژې جوړښت

```
healmate/
├── android/                    # د Android TWA App
│   ├── app/
│   │   ├── build.gradle       # د App configuration
│   │   ├── google-services.json  # د Firebase config
│   │   └── src/
│   └── build.gradle           # د Root gradle
├── components/                # د React Components
│   ├── ContactUs.tsx
│   ├── AboutUs.tsx
│   ├── Services.tsx
│   └── ...
├── public/
│   ├── manifest.json          # د PWA Manifest
│   └── service-worker.js      # د Service Worker
├── firebase-config.ts         # د Firebase Config
├── App.tsx                    # د Main App Component
├── ANDROID_SETUP_GUIDE.md     # د بشپړ Setup لارښوود
├── PLAY_STORE_CHECKLIST.md    # د Play Store Checklist
└── package.json
```

---

## 🔧 د مفید Commands

### Development:
```bash
npm run dev          # د Development server پیل کول
npm run build        # د Production build جوړول
npm run preview      # د Build preview کول
```

### Android:
```bash
cd android

# Debug build
./gradlew assembleDebug

# Release build  
./gradlew assembleRelease

# د AAB جوړول
./gradlew bundleRelease

# Clean build
./gradlew clean
```

### Firebase:
```bash
# د Firebase CLI نصبول
npm install -g firebase-tools

# Login
firebase login

# Deploy
firebase deploy
```

---

## 🎨 د فیچرونو لیست

### ✅ Core Features:
- 🏥 د ډاکټرانو او روغتونونو Directory
- 💊 د درملو بشپړ معلومات
- 🚑 د لومړنۍ مرستې لارښوونې
- 🆘 د Emergency SOS سیسټم
- 🤖 AI روغتیایي چیټ بوټ
- 📊 BMI Calculator او Symptoms Checker
- ⏰ د درملو یادونې (Reminders)
- 📅 د وخت ټاکلو سیسټم
- 📈 د روغتیا Tracker
- 📚 د روغتیایي کتابونو Library
- 👥 د Community Posts
- 📱 د WhatsApp مرسته

### ✅ Technical Features:
- 🌐 Progressive Web App (PWA)
- 📱 د Android TWA App
- 🔐 Firebase Authentication
- 💾 Firestore Database
- 📁 Cloud Storage
- 🔔 Push Notifications
- 💰 AdMob Integration
- 🌍 د 3 ژبو ملاتړ (پښتو، دری، انګلیسي)
- 📴 Offline Support
- 🎨 Modern UI/UX (2025 Design)

---

## 📞 د مرستې معلومات

### د Developer:
- 👨‍⚕️ **Name**: Dr. Ibrahim Khaksar
- 📧 **Email**: ibrahimkhaksar.it@gmail.com
- 📱 **WhatsApp**: +93 779 494 512
- 💳 **Hesab Pay**: +93 779 494 512

### د Documentation:
- 📄 **ANDROID_SETUP_GUIDE.md** - بشپړ Android setup
- 📄 **PLAY_STORE_CHECKLIST.md** - د Play Store checklist
- 📄 **QUICK_START.md** - دا فایل

---

## 🐛 د عامو مسلو حل

### مسله: `google-services.json not found`
**حل**: د Firebase Console څخه دا فایل ډاونلوډ او په `/android/app/` کې کاپي کړئ

### مسله: `Build failed with ProGuard`
**حل**: په `proguard-rules.pro` کې د Firebase rules اضافه کړئ

### مسله: `Digital Asset Links verification failed`
**حل**: 
1. د SHA256 fingerprint چیک کړئ
2. د `assetlinks.json` په `.well-known/` folder کې موجودیت تصدیق کړئ
3. د Google Digital Asset Links Tool کاروئ

### مسله: `AdMob ads not showing`
**حل**:
1. د AdMob App ID په AndroidManifest.xml کې چیک کړئ
2. Test mode فعال کړئ
3. د Test device IDs اضافه کړئ

---

## 🚀 د Production Deploy

### 1. د PWA Deploy (Vercel/Netlify):
```bash
# Build
npm run build

# د Vercel deploy
vercel --prod

# یا د Netlify deploy
netlify deploy --prod
```

### 2. د Android App (Play Store):
```bash
# د Release AAB جوړول
cd android
./gradlew bundleRelease

# Upload to Play Console
# File: android/app/build/outputs/bundle/release/app-release.aab
```

---

## ⭐ د Next Steps

1. ✅ د Firebase setup بشپړ کړئ
2. ✅ د AdMob setup بشپړ کړئ
3. ✅ د Domain configuration بشپړ کړئ
4. ✅ د Digital Asset Links setup کړئ
5. ✅ د Internal testing پیل کړئ
6. ✅ د Closed testing ترسره کړئ
7. ✅ د Production deploy کړئ
8. 🎉 د Users feedback راغونډ کړئ!

---

## 📈 د Performance Tips

1. د Images optimize کړئ (WebP format)
2. د Code splitting استعمال کړئ
3. د Service Worker proper configure کړئ
4. د Lazy loading استعمال کړئ
5. د AdMob ads مناسب placement
6. د Analytics monitor کړئ

---

## 🎯 د Success Metrics

- ⬇️ Downloads: > 10,000 په لومړۍ میاشت
- ⭐ Rating: > 4.5 stars
- 📊 Retention: > 40% په 7 ورځو کې
- 💥 Crash Rate: < 1%
- 🚀 Load Time: < 3 seconds

---

## 🙏 مننه

د HealMate استعمال کولو لپاره مننه! که مسله وي یا سوال ولرئ، مونږ سره اړیکه ونیسئ.

**د ډاکټر ابراهیم خاکسار لخوا ستاسو د خدمت لپاره ❤️**

---

بریالیتوب مبارک! 🎉
