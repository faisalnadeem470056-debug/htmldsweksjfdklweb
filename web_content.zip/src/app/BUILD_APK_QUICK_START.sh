#!/bin/bash

# HealMate - Quick APK Build Script
# د HealMate APK جوړولو ګړندۍ سکریپټ

echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "   HealMate APK Builder"
echo "   د بریالیتوب لپاره ټول قدمونه"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Step 1: Check Prerequisites
echo -e "${BLUE}Step 1: Checking prerequisites...${NC}"
echo ""

if ! command -v node &> /dev/null; then
    echo -e "${RED}❌ Node.js نه دی install شوی${NC}"
    echo "   Install from: https://nodejs.org/"
    exit 1
fi
echo -e "${GREEN}✅ Node.js: $(node --version)${NC}"

if ! command -v npm &> /dev/null; then
    echo -e "${RED}❌ npm نه دی install شوی${NC}"
    exit 1
fi
echo -e "${GREEN}✅ npm: $(npm --version)${NC}"

if ! command -v java &> /dev/null; then
    echo -e "${YELLOW}⚠️  Java نه دی install شوی${NC}"
    echo "   Install JDK 11+ from: https://adoptium.net/"
fi

echo ""
echo -e "${BLUE}Step 2: Installing dependencies...${NC}"
echo ""

# Install npm packages
npm install

# Install Capacitor
npm install @capacitor/core @capacitor/cli @capacitor/android

echo -e "${GREEN}✅ Dependencies installed${NC}"
echo ""

# Step 3: Build React App
echo -e "${BLUE}Step 3: Building React app...${NC}"
echo ""

npm run build

if [ ! -d "dist" ]; then
    echo -e "${RED}❌ Build failed! dist folder نه جوړ شو${NC}"
    exit 1
fi

echo -e "${GREEN}✅ React app built successfully${NC}"
echo ""

# Step 4: Initialize Capacitor (if not already)
echo -e "${BLUE}Step 4: Setting up Capacitor...${NC}"
echo ""

if [ ! -f "capacitor.config.json" ]; then
    npx cap init "HealMate" "com.healmate.afghanistan" --web-dir="dist"
    echo -e "${GREEN}✅ Capacitor initialized${NC}"
else
    echo -e "${GREEN}✅ Capacitor already initialized${NC}"
fi

echo ""

# Step 5: Add Android Platform
echo -e "${BLUE}Step 5: Adding Android platform...${NC}"
echo ""

if [ ! -d "android" ]; then
    npx cap add android
    echo -e "${GREEN}✅ Android platform added${NC}"
else
    echo -e "${GREEN}✅ Android platform already exists${NC}"
fi

echo ""

# Step 6: Sync files
echo -e "${BLUE}Step 6: Syncing files to Android...${NC}"
echo ""

npx cap sync android

echo -e "${GREEN}✅ Files synced${NC}"
echo ""

# Step 7: Generate Keystore (if not exists)
echo -e "${BLUE}Step 7: Checking keystore...${NC}"
echo ""

if [ ! -f "android/app/healmate-keystore.jks" ]; then
    echo -e "${YELLOW}⚠️  Keystore نه شته${NC}"
    echo ""
    echo "Generating keystore..."
    echo "Please enter the following information:"
    echo ""
    
    keytool -genkey -v -keystore android/app/healmate-keystore.jks \
        -keyalg RSA -keysize 2048 -validity 10000 \
        -alias healmate
    
    echo ""
    echo -e "${GREEN}✅ Keystore created${NC}"
    echo -e "${RED}⚠️  IMPORTANT: Backup this file!${NC}"
    echo "   Location: android/app/healmate-keystore.jks"
    echo ""
else
    echo -e "${GREEN}✅ Keystore already exists${NC}"
fi

echo ""

# Step 8: Instructions for Android Studio
echo -e "${BLUE}Step 8: Next steps...${NC}"
echo ""
echo -e "${YELLOW}Now you need to:${NC}"
echo ""
echo "1️⃣  Open Android Studio"
echo "   npx cap open android"
echo ""
echo "2️⃣  Configure build.gradle:"
echo "   - Add keystore path"
echo "   - Add keystore password"
echo "   - Add key alias"
echo "   - Add key password"
echo ""
echo "3️⃣  Build APK:"
echo "   cd android"
echo "   ./gradlew assembleRelease"
echo ""
echo "4️⃣  Find APK at:"
echo "   android/app/build/outputs/apk/release/app-release.apk"
echo ""
echo "5️⃣  Or build AAB for Play Store:"
echo "   ./gradlew bundleRelease"
echo "   android/app/build/outputs/bundle/release/app-release.aab"
echo ""

# Open Android Studio
read -p "Open Android Studio now? (y/n): " -n 1 -r
echo ""
if [[ $REPLY =~ ^[Yy]$ ]]; then
    npx cap open android
fi

echo ""
echo -e "${GREEN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo -e "${GREEN}  Setup Complete! بریالیتوب!${NC}"
echo -e "${GREEN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo ""
echo "📖 د بشپړې راهنمایی لپاره وګورئ:"
echo "   PLAYSTORE_BUILD_GUIDE.md"
echo ""
