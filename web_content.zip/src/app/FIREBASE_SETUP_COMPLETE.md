# 🔥 Firebase Integration Complete - بشپړ Firebase Integration

## ✅ څه شوي دي؟

Firebase integration په بشپړ ډول بیرته اضافه شوی دی! اوس **HealMate** د Firebase او LocalStorage دواړو سره کار کوي.

---

## 📁 نوي فایلونه

### 1. `/config/firebase-config.ts`
- د Firebase configuration
- د Firebase initialization  
- د Firebase او LocalStorage تر منځ automatic detection

### 2. `/utils/FirebaseManager.ts`
- Dual mode support (Firebase + LocalStorage)
- د Authentication (Sign Up, Sign In, Sign Out)
- د User Management
- د Posts Management  
- د File Upload
- د Sync Functions (LocalStorage ↔ Firebase)

### 3. `/components/FirebaseSettings.tsx`
- د Firebase حالت ښودل
- د Sync options (Upload/Download)
- Trilingual support (پښتو، دری، English)

---

## 🔄 بدل شوي فایلونه

### 1. `/contexts/AuthContext.tsx`
- اوس د `FirebaseManager` سره کار کوي
- د Firebase او LocalStorage دواړو ملاتړ
- نوي functions: `isFirebaseMode()`, `syncToFirebase()`, `syncFromFirebase()`

### 2. `/components/Settings.tsx`
- نوی Firebase Settings section اضافه شو
- Firebase Settings modal
- Cloud Sync button

---

## 🚀 څنګه کار کوي؟

### Option 1: LocalStorage Mode (Default)
که تاسو Firebase configure نه کړئ، نو اپلیکیشن به په LocalStorage mode کې کار وکړي:

```
✅ د LocalStorage سره کار کوي
✅ Offline کار کوي
✅ هیڅ Firebase setup ته اړتیا نشته
✅ ټول features د لومړي په شان کار کوي
```

### Option 2: Firebase Mode (Cloud Sync)
که تاسو Firebase configure کړئ، نو اپلیکیشن به په Firebase mode کې کار وکړي:

```
✅ د Cloud کې ډیټا ذخیره کیږي
✅ د Multiple devices تر منځ sync
✅ Real-time updates
✅ Secure authentication
```

---

## 🔧 د Firebase Setup لارښوونې

### Step 1: د Firebase Project جوړول

1. **Firebase Console** ته لاړ شئ: https://console.firebase.google.com
2. **Create a project** کلیک کړئ
3. د خپل پروژې نوم ولیکئ (د بېلګې په توګه: `HealMate`)
4. Google Analytics (Optional) - تاسو کولی شئ دا غیرفعال کړئ
5. **Create project** کلیک کړئ

### Step 2: د Web App اضافه کول

1. د Firebase Console کې، د خپلې پروژې Dashboard ته لاړ شئ
2. **Web icon** (`</>`) کلیک کړئ
3. د خپل app نوم ولیکئ (د بېلګې په توګه: `HealMate Web`)
4. **Register app** کلیک کړئ
5. تاسو به د Firebase configuration معلومات وګورئ:

```javascript
const firebaseConfig = {
  apiKey: "AIzaSyC...",
  authDomain: "healmate-xxxx.firebaseapp.com",
  projectId: "healmate-xxxx",
  storageBucket: "healmate-xxxx.appspot.com",
  messagingSenderId: "123456789",
  appId: "1:123456789:web:xxxxx",
  measurementId: "G-XXXXXX"
};
```

### Step 3: د Firebase Services فعالول

#### 1. **Authentication** فعالول:

1. د Firebase Console کې، **Authentication** ته لاړ شئ
2. **Get started** کلیک کړئ
3. **Sign-in method** tab ته لاړ شئ
4. **Email/Password** فعال کړئ

#### 2. **Firestore Database** فعالول:

1. د Firebase Console کې، **Firestore Database** ته لاړ شئ
2. **Create database** کلیک کړئ
3. **Start in test mode** غوره کړئ (د development لپاره)
4. Location غوره کړئ (د بېلګې په توګه: `asia-south1` د افغانستان لپاره نږدې دی)
5. **Enable** کلیک کړئ

#### 3. **Storage** فعالول:

1. د Firebase Console کې، **Storage** ته لاړ شئ
2. **Get started** کلیک کړئ
3. **Start in test mode** غوره کړئ
4. **Next** او **Done** کلیک کړئ

### Step 4: د HealMate کې Firebase Config اضافه کول

1. **`/config/firebase-config.ts`** فایل خلاص کړئ
2. د Firebase Console څخه configuration معلومات کاپي کړئ
3. په فایل کې يې paste کړئ:

```typescript
const firebaseConfig = {
  apiKey: "AIzaSyC...",                           // ← تاسو د خپل Firebase معلومات دلته واچوئ
  authDomain: "healmate-xxxx.firebaseapp.com",
  projectId: "healmate-xxxx",
  storageBucket: "healmate-xxxx.appspot.com",
  messagingSenderId: "123456789",
  appId: "1:123456789:web:xxxxx",
  measurementId: "G-XXXXXX"
};
```

4. فایل خوندي کړئ او اپلیکیشن بیرته refresh کړئ

---

## 📱 د Settings کې Firebase

کله چې Firebase configure شي، نو د Settings صفحې کې به یو نوی section وګورئ:

### **Cloud Sync** Section:

1. **Settings** ته لاړ شئ
2. **Cloud Sync** section به د Performance وروسته وي
3. **Settings** بټن کلیک کړئ
4. تاسو به لاندې وګورئ:
   - ✅ Firebase Status (Configured/Not Configured)
   - ✅ Connection Status (Connected/Disconnected)
   - ✅ Current Mode (Firebase/LocalStorage)
   - ✅ Sync Options

### د Sync Options:

#### **1. Sync to Firebase** (Upload)
د LocalStorage څخه د ټولو ډیټا Firebase ته پورته کړئ:
- Users
- Posts
- Settings
- او نور...

#### **2. Sync from Firebase** (Download)
د Firebase څخه د ټولو ډیټا LocalStorage ته ډاونلوډ کړئ.

---

## 🔐 د Security Rules

### Firestore Security Rules:

د Firebase Console کې، **Firestore Database** → **Rules** ته لاړ شئ او لاندې rules واچوئ:

```javascript
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    // د Users لپاره
    match /users/{userId} {
      // یوازې login شوی user خپل معلومات لوستلی شي
      allow read: if request.auth != null && request.auth.uid == userId;
      // یوازې login شوی user خپل معلومات update کولی شي
      allow write: if request.auth != null && request.auth.uid == userId;
    }
    
    // د Posts لپاره
    match /posts/{postId} {
      // ټول وکړی شي لوستل
      allow read: if request.auth != null;
      // یوازې login شوی user post جوړولی شي
      allow create: if request.auth != null;
      // یوازې د post مالک update یا delete کولی شي
      allow update, delete: if request.auth != null && 
                              request.auth.uid == resource.data.userId;
    }
  }
}
```

### Storage Security Rules:

د Firebase Console کې، **Storage** → **Rules** ته لاړ شئ او لاندې rules واچوئ:

```javascript
rules_version = '2';
service firebase.storage {
  match /b/{bucket}/o {
    match /users/{userId}/{allPaths=**} {
      // یوازې login شوی user خپل فایلونه upload کولی شي
      allow read, write: if request.auth != null && request.auth.uid == userId;
    }
    
    match /posts/{postId}/{allPaths=**} {
      // ټول وکړی شي لوستل، یوازې login شوی user upload کولی شي
      allow read: if request.auth != null;
      allow write: if request.auth != null;
    }
  }
}
```

---

## 💾 د ډیټا جوړښت (Data Structure)

### Firestore Collections:

#### 1. **`users`** Collection:
```json
{
  "id": "user_1234567890_abc123",
  "email": "user@example.com",
  "name": "Ahmad Khan",
  "phone": "+93700000000",
  "avatar": "https://...",
  "role": "user",
  "isPremium": false,
  "createdAt": "2025-01-01T00:00:00.000Z",
  "lastLogin": "2025-01-01T00:00:00.000Z"
}
```

#### 2. **`posts`** Collection:
```json
{
  "id": "post_1234567890_abc123",
  "userId": "user_1234567890_abc123",
  "userName": "Ahmad Khan",
  "userAvatar": "https://...",
  "content": "د روغتیا په اړه یو مفید معلومات...",
  "images": ["https://...", "https://..."],
  "videos": [],
  "likes": 10,
  "comments": 5,
  "shares": 2,
  "createdAt": "2025-01-01T00:00:00.000Z"
}
```

---

## 🎯 د Dual Mode فایدې

### د LocalStorage Mode فایدې:
- ✅ **تیز** - هیڅ network requests نه شته
- ✅ **Offline** - بغیر انټرنیټ کار کوي
- ✅ **ساده** - کوم setup ته اړتیا نشته
- ✅ **وړیا** - هیڅ backend هزینه نشته

### د Firebase Mode فایدې:
- ✅ **Cloud Backup** - ډیټا safe دی
- ✅ **Multi-Device** - په هر جاګه access
- ✅ **Real-time** - لحظه لحظه updates
- ✅ **Secure** - Professional authentication

---

## 🔄 د Mode بدلول

### د LocalStorage څخه Firebase ته:

1. Firebase configure کړئ (د پورتنیو steps مطابق)
2. اپلیکیشن refresh کړئ
3. **Settings** → **Cloud Sync** → **Settings** ته لاړ شئ
4. **Sync to Firebase** کلیک کړئ
5. ټول ډیټا به Firebase ته upload شي!

### د Firebase څخه LocalStorage ته:

1. **Settings** → **Cloud Sync** → **Settings** ته لاړ شئ
2. **Sync from Firebase** کلیک کړئ
3. ټول ډیټا به LocalStorage ته download شي!

---

## 🧪 د Testing

### د Firebase تست کول:

1. **Sign Up** یو نوی user جوړ کړئ
2. **Firebase Console** → **Authentication** ته لاړ شئ
3. تاسو به خپل user وګورئ!
4. **Firestore Database** ته لاړ شئ
5. تاسو به د `users` collection وګورئ

### د Sync تست کول:

1. د LocalStorage mode کې یو post جوړ کړئ
2. **Settings** → **Cloud Sync** → **Sync to Firebase** کلیک کړئ
3. **Firebase Console** → **Firestore** ته لاړ شئ
4. تاسو به د `posts` collection وګورئ!

---

## ⚠️ مهم یادونې

### د Production لپاره:

1. **Security Rules** بشپړ کړئ (د پورتنیو rules استعمال کړئ)
2. **Firebase Pricing** چیک کړئ - Spark (Free) plan محدود دی
3. **Passwords** هیڅکله په plain text ذخیره نه کړئ (اوس یوازې د development لپاره دي)
4. **Environment Variables** استعمال کړئ د Firebase config لپاره

### د Performance لپاره:

1. **Indexes** جوړ کړئ د Firestore queries لپاره
2. **Caching** استعمال کړئ د تکرار requests مخنیوی لپاره
3. **Pagination** استعمال کړئ د لویو lists لپاره
4. **Batch Writes** استعمال کړئ د ډیرو writes لپاره

---

## 📊 د Firebase Pricing

### **Spark Plan (Free)**:
- ✅ 1GB Storage
- ✅ 10GB/month Transfer  
- ✅ 50,000 Reads/day
- ✅ 20,000 Writes/day
- ✅ 20,000 Deletes/day

د ډیرو کوچنیو apps لپاره کافي دی!

### **Blaze Plan (Pay-as-you-go)**:
- د لویو apps لپاره
- پیسې يوازې د استعمال مطابق
- لا ډیر space او bandwidth

---

## 🎊 خلاصه

- ✅ **Firebase** بیرته اضافه شو
- ✅ **Dual Mode** - Firebase او LocalStorage دواړو ملاتړ
- ✅ **Firebase Settings** component په Settings کې
- ✅ **Sync Functions** د upload/download لپاره
- ✅ **Trilingual Support** - پښتو، دری، English
- ✅ **Secure** - Professional authentication
- ✅ **Flexible** - تاسو انتخاب کوی چې کوم mode غواړئ

---

## 📞 د مرستې لپاره:

که کومه پوښتنه یا ستونزه ولرئ:
- 📧 Email: ibrahimkhaksar.it@gmail.com
- 💬 Hesab Pay: +93779494512

---

## 🌟 د راتلونکو Features

په راتلونکي کې به لاندې features اضافه شي:

1. **Auto Sync** - Automatic sync every 5 minutes
2. **Conflict Resolution** - د تضاد حل کول
3. **Offline Queue** - د offline changes queue
4. **Real-time Listeners** - لحظه لحظه updates
5. **Advanced Security** - د Passwords encryption

---

**🎊 مبارک شه! اوس ستاسو HealMate اپلیکیشن د Firebase سره په بشپړ ډول کار کوي!**

### څنګه پیل کړئ:

1. **Option A - LocalStorage Mode (Easy)**:
   - هیڅ نه کوئ، اپلیکیشن به په default ډول د LocalStorage سره کار وکړي!

2. **Option B - Firebase Mode (Cloud Sync)**:
   - د پورتنیو steps مطابق Firebase configure کړئ
   - د `/config/firebase-config.ts` کې خپل معلومات واچوئ
   - Refresh او enjoy!

---

**د HealMate Team څخه مننه! 💚🇦🇫**
