# 🏥 HealMate - د افغانستان روغتیایي اپلیکیشن

<div align="center">

![HealMate Logo](https://img.shields.io/badge/HealMate-Afghanistan_Health_App-6366F1?style=for-the-badge&logo=data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMjQiIGhlaWdodD0iMjQiIHZpZXdCb3g9IjAgMCAyNCAyNCIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KPHBhdGggZD0iTTEyIDIxLjM1TDEwLjU1IDE5Ljg1QzUuNCAxNC40NSAyIDEwLjcyIDIgNi41QzIgMy41OCA0LjAxIDEgNi45OSAxQzkuMTMgMSAxMS4xIDIuMDkgMTIgMy43MUMxMi45IDIuMDkgMTQuODcgMSAxNy4wMSAxQzE5Ljk5IDEgMjIgMy41OCAyMiA2LjVDMjIgMTAuNzIgMTguNiAxNC40NSAxMy40NSAxOS44NUwxMiAyMS4zNVoiIGZpbGw9IiNGRkZGRkYiLz4KPC9zdmc+)

[![License](https://img.shields.io/badge/License-MIT-green.svg?style=flat-square)](LICENSE)
[![PRs Welcome](https://img.shields.io/badge/PRs-welcome-brightgreen.svg?style=flat-square)](CONTRIBUTING.md)
[![Firebase](https://img.shields.io/badge/Firebase-FFCA28?style=flat-square&logo=firebase&logoColor=black)](https://firebase.google.com/)
[![React](https://img.shields.io/badge/React-18.3-61DAFB?style=flat-square&logo=react)](https://reactjs.org/)
[![Tailwind CSS](https://img.shields.io/badge/Tailwind-4.0-38BDF8?style=flat-square&logo=tailwind-css)](https://tailwindcss.com/)

**د افغانستان لپاره بشپړ، وړیا، او حرفه‌ای روغتیایي اپلیکیشن**

[دمو وګورئ](https://healmate-afghanistan.vercel.app) • [Documentation](ANDROID_SETUP_GUIDE.md) • [د مرستې لپاره](mailto:ibrahimkhaksar.it@gmail.com)

</div>

---

## 📱 د HealMate په اړه

**HealMate** د افغانستان خلکو لپاره یو بشپړ، وړیا، او پروفیشنل روغتیایي اپلیکیشن دی چې په **پښتو**، **دری**، او **انګلیسي** ژبو کې شته دی. دا یو **Progressive Web App (PWA)** دی چې د **Trusted Web Activity (TWA)** په واسطه د Play Store لپاره هم جوړ شوی.

### 🌟 د لویې فیچرونه

#### 🏥 د روغتیایي خدماتو لاسرسی
- **د ډاکټرانو Directory**: د تخصصونو او ځای په اساس د ډاکټرانو لټون
- **د روغتونونو معلومات**: د نږدې روغتونونو او کلینیکونو بشپړ معلومات
- **د Emergency SOS**: د بیړني حالت لپاره چټک اړیکه

#### 💊 د درملو معلومات
- **د درملو Database**: د درملو بشپړ معلومات، استعمال، او خطرناک اغیزې
- **د درملو یادونې**: د درملو د وخت په وخت اخیستو لپاره Reminders
- **د Prescription Scanner**: د prescription عکس اخیستل او معلومات ترلاسه کول

#### 🚑 د لومړنۍ مرستې لارښوونې
- د عامو حالتونو لپاره د لومړنۍ مرستې لارښوونې
- د بیړني حالت لپاره step-by-step instructions
- د Offline لاسرسي لپاره downloads

#### 🤖 AI روغتیایي Assistant
- د 24/7 AI chatbot د روغتیایي سوالونو لپاره
- د علایمو checker
- د روغتیا ټپونه او نصیحتونه

#### 📊 د روغتیا Tracking
- BMI Calculator
- د Blood Pressure tracker
- د وزن او height monitor
- د Exercise tracker

#### 📚 روغتیایي تعلیم
- د روغتیایي کتابونو library
- د ناروغیو Encyclopedia
- د خوراکي توکو لارښوود
- د روغتیا ویډیوګانې

#### 👥 د Community
- د کاروونکو posts او تجربې
- د ډاکټرانو سره Q&A
- د روغتیا challenges

---

## 🚀 د Quick Start

### د Development Setup

```bash
# 1. د Repository clone کول
git clone https://github.com/YOUR_USERNAME/healmate.git
cd healmate

# 2. د Dependencies install کول
npm install

# 3. د Development server پیل کول
npm run dev
```

د بشپړ setup لپاره [QUICK_START.md](QUICK_START.md) وګورئ.

### د Android App جوړول

```bash
# د Windows لپاره
setup-android.bat

# د Mac/Linux لپاره
chmod +x setup-android.sh
./setup-android.sh
```

د بشپړ Android setup لپاره [ANDROID_SETUP_GUIDE.md](ANDROID_SETUP_GUIDE.md) وګورئ.

---

## 🛠️ Technology Stack

### Frontend
- **React 18.3** - د UI framework
- **TypeScript** - د Type safety لپاره
- **Tailwind CSS 4.0** - د Styling لپاره
- **Motion (Framer Motion)** - د Animations لپاره
- **Lucide React** - د Icons لپاره

### Backend & Services
- **Firebase Authentication** - د User authentication لپاره
- **Firestore Database** - د Data storage لپاره
- **Cloud Storage** - د Files لپاره
- **Cloud Messaging (FCM)** - د Push notifications لپاره
- **Firebase Analytics** - د Analytics لپاره

### Monetization
- **Google AdMob** - د Ads لپاره

### PWA & Mobile
- **Service Worker** - د Offline support لپاره
- **Web App Manifest** - د PWA features لپاره
- **Trusted Web Activity (TWA)** - د Android app لپاره

---

## 📂 د پروژې جوړښت

```
healmate/
├── android/                      # د Android TWA App
│   ├── app/
│   │   ├── build.gradle         # د App configuration
│   │   ├── google-services.json # د Firebase config (Git کې نشته)
│   │   ├── src/
│   │   │   ├── main/
│   │   │   │   ├── java/com/drkhaksar/healmate/
│   │   │   │   │   ├── HealMateApplication.kt
│   │   │   │   │   └── services/
│   │   │   │   │       └── HealMateFirebaseMessagingService.kt
│   │   │   │   ├── res/
│   │   │   │   │   ├── values/
│   │   │   │   │   │   ├── strings.xml
│   │   │   │   │   │   └── colors.xml
│   │   │   │   │   └── drawable/
│   │   │   │   └── AndroidManifest.xml
│   │   └── proguard-rules.pro
│   ├── build.gradle             # د Root gradle
│   └── gradle.properties        # د Gradle properties (Git کې نشته)
│
├── components/                   # د React Components
│   ├── AuthPage.tsx             # د Login/Signup
│   ├── EnhancedDoctorsDirectory.tsx
│   ├── HospitalDirectory.tsx
│   ├── MedicineGuide.tsx
│   ├── FirstAid.tsx
│   ├── EmergencySOS.tsx
│   ├── AIHealthChat.tsx
│   ├── BMICalculator.tsx
│   ├── SymptomsChecker.tsx
│   ├── HealthTracker.tsx
│   ├── MedicineReminder.tsx
│   ├── ContactUs.tsx
│   ├── AboutUs.tsx
│   ├── Settings.tsx
│   ├── AdminPanel.tsx
│   ├── WhatsAppFloatingButton.tsx
│   └── ...
│
├── public/
│   ├── manifest.json            # د PWA Manifest
│   ├── service-worker.js        # د Service Worker
│   ├── icon-192.png
│   ├── icon-512.png
│   └── ...
│
├── utils/
│   ├── SecurityManager.ts       # د Security utilities
│   └── DataManager.ts           # د Data management
│
├── styles/
│   └── globals.css              # د Global styles
│
├── firebase-config.ts           # د Firebase Configuration
├── translations.ts              # د 3 ژبو Translations
├── App.tsx                      # د Main App Component
├── main.tsx                     # د Entry point
│
├── ANDROID_SETUP_GUIDE.md       # د بشپړ Android setup
├── PLAY_STORE_CHECKLIST.md      # د Play Store checklist
├── QUICK_START.md               # د Quick start guide
├── setup-android.sh             # د Mac/Linux setup script
├── setup-android.bat            # د Windows setup script
│
├── package.json
├── tsconfig.json
├── vite.config.ts
├── tailwind.config.js
└── .gitignore
```

---

## 🔥 د Firebase Setup

### 1. د Firebase Project جوړول

```bash
# د Firebase Console ته لاړشئ
https://console.firebase.google.com

# Project جوړ کړئ: "healmate-afghanistan"
```

### 2. د Services فعالول

- ✅ Authentication (Email, Google, Phone)
- ✅ Firestore Database
- ✅ Cloud Storage
- ✅ Cloud Messaging (FCM)
- ✅ Analytics
- ✅ Crashlytics

### 3. د Config فایل تازه کول

په `firebase-config.ts` کې خپل Firebase معلومات اضافه کړئ.

د بشپړ setup لپاره [ANDROID_SETUP_GUIDE.md](ANDROID_SETUP_GUIDE.md#1-firebase-setup) وګورئ.

---

## 💰 د AdMob Setup

### 1. د AdMob Account جوړول

```bash
https://admob.google.com
```

### 2. د Ad Units جوړول

- Banner Ad
- Interstitial Ad
- Rewarded Ad

### 3. د AdMob Config تازه کول

په `firebase-config.ts` کې د AdMob IDs اضافه کړئ.

د بشپړ setup لپاره [ANDROID_SETUP_GUIDE.md](ANDROID_SETUP_GUIDE.md#2-admob-setup) وګورئ.

---

## 📱 د Play Store Submission

### د Checklist:

- [ ] د Firebase setup بشپړ شو
- [ ] د AdMob setup بشپړ شو
- [ ] د TWA configure شو
- [ ] د Digital Asset Links verify شول
- [ ] د Release AAB جوړ شو
- [ ] د Graphics او Screenshots بشپړ دي
- [ ] د Store listing بشپړ دی
- [ ] د Privacy Policy او Terms موجود دي
- [ ] د Testing بشپړ شو

د بشپړ checklist لپاره [PLAY_STORE_CHECKLIST.md](PLAY_STORE_CHECKLIST.md) وګورئ.

---

## 🌍 د ژبو ملاتړ

HealMate په درې ژبو کې شته دی:

- 🇦🇫 **پښتو** (Pashto) - د افغانستان رسمي ژبه
- 🇦🇫 **دری** (Dari) - د افغانستان رسمي ژبه
- 🇬🇧 **انګلیسي** (English) - نړیوالې ژبه

کاروونکي کولی شي په اپلیکیشن کې د ژبې تغیر کړي او بشپړ interface په هغه ژبه کې ښکاري.

---

## 🎨 د Screenshots

<div align="center">

### د Home Screen
![Home Screen](screenshots/home-ps.png)

### د Doctors Directory
![Doctors](screenshots/doctors-ps.png)

### د Medicine Guide
![Medicine](screenshots/medicine-ps.png)

### د Emergency SOS
![Emergency](screenshots/emergency-ps.png)

</div>

---

## 👨‍⚕️ د Developer

**Dr. Ibrahim Khaksar**
- 📧 Email: ibrahimkhaksar.it@gmail.com
- 📱 WhatsApp: +93 779 494 512
- 💳 Hesab Pay: +93 779 494 512

---

## 🤝 Contributing

موږ د Contributions هرکلی کوو! که تاسو غواړئ د HealMate کې مرسته وکړئ:

1. د Repository fork کړئ
2. خپل feature branch جوړ کړئ (`git checkout -b feature/AmazingFeature`)
3. خپل changes commit کړئ (`git commit -m 'Add some AmazingFeature'`)
4. د branch push کړئ (`git push origin feature/AmazingFeature`)
5. یو Pull Request جوړ کړئ

---

## 📄 License

دا پروژه د MIT License لاندې ده. د نورو معلوماتو لپاره [LICENSE](LICENSE) فایل وګورئ.

---

## 🙏 د مننې

- د افغانستان خلکو ته چې د HealMate inspiration دي
- د Firebase او Google ټیمونو ته د عالي tools لپاره
- د React او Tailwind CSS communities ته
- ټولو ډاکټرانو او روغتیا کارکوونکو ته چې د معلوماتو مرسته کوي

---

## 📞 د مرستې او Support

که تاسو ته د HealMate په استعمال کې مسله وي یا سوال ولرئ:

### د ټیکنیکل Support:
- 📧 Email: ibrahimkhaksar.it@gmail.com
- 📱 WhatsApp: +93 779 494 512
- 💬 په اپلیکیشن کې د WhatsApp floating button استعمال کړئ

### د Documentation:
- [QUICK_START.md](QUICK_START.md) - د Quick start guide
- [ANDROID_SETUP_GUIDE.md](ANDROID_SETUP_GUIDE.md) - د Android setup
- [PLAY_STORE_CHECKLIST.md](PLAY_STORE_CHECKLIST.md) - د Play Store checklist

---

## 🎯 د Roadmap

### د راتلونکي Features:

#### Version 1.1 (راتلونکه):
- [ ] د Telemedicine integration
- [ ] د Video consultation د ډاکټرانو سره
- [ ] د Lab results integration
- [ ] د Pharmacy delivery service

#### Version 1.2:
- [ ] د iOS app (TWA یا Native)
- [ ] د Wearable devices integration
- [ ] د Advanced AI diagnostics
- [ ] د Health insurance integration

#### Version 2.0:
- [ ] د Hospital management system integration
- [ ] د Electronic Health Records (EHR)
- [ ] د Multi-clinic support
- [ ] د Advanced analytics او reporting

---

## 📊 د Status

- ✅ PWA بشپړ کار کوي
- ✅ د Firebase integration بشپړ دی
- ✅ د AdMob setup بشپړ دی
- ✅ د 3 ژبو support بشپړ دی
- 🚧 د Android TWA App په تیاری کې
- 🚧 د Play Store submission په انتظار کې

---

## ⭐ د Stars

که تاسو ته HealMate خوښ شو، مهرباني وکړئ یو ⭐ ورکړئ!

[![GitHub stars](https://img.shields.io/github/stars/YOUR_USERNAME/healmate?style=social)](https://github.com/YOUR_USERNAME/healmate/stargazers)

---

<div align="center">

**د ډاکټر ابراهیم خاکسار لخوا د افغانستان خلکو لپاره ❤️**

د روغتیا خدماتو لاسرسي د ټولو لپاره!

[Website](https://healmate-afghanistan.vercel.app) • [Email](mailto:ibrahimkhaksar.it@gmail.com) • [WhatsApp](https://wa.me/93779494512)

---

© 2025 HealMate. All rights reserved.

</div>
