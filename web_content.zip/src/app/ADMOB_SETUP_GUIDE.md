# 🎯 AdMob Integration - Complete Setup Guide
# د AdMob بشپړ راهنما

---

## ✅ **Status: READY FOR TESTING**

```
AdMob Components:       ✅ CREATED
Test IDs:               ✅ CONFIGURED
Configuration File:     ✅ READY
Documentation:          ✅ COMPLETE

Next Step: د اصلي IDs اضافه کول وروسته له Test څخه
```

---

## 📁 **Created Files:**

```
/config/admob.config.ts              ⚙️ Main configuration (EDIT HERE!)
/components/ads/AdMobBanner.tsx      📊 Banner ads
/components/ads/AdMobInterstitial.tsx 📺 Full-screen ads
/components/ads/AdMobRewarded.tsx     🎁 Reward ads
/components/ads/AdMobNative.tsx       📋 Native ads
```

---

## 🔧 **STEP 1: Test کول (اوس)**

### **1.1: Components Import کړئ**

په خپل Page کې (لکه App.tsx یا DoctorsDirectory.tsx):

```typescript
import { AdMobBanner } from './components/ads/AdMobBanner';
import { AdMobInterstitial, useInterstitialAd } from './components/ads/AdMobInterstitial';
import { AdMobRewarded, useRewardedAd } from './components/ads/AdMobRewarded';
import { AdMobNative } from './components/ads/AdMobNative';
```

### **1.2: Banner Ad استعمال**

```typescript
function MyPage() {
  return (
    <div>
      {/* ستاسو page content */}
      
      {/* Banner Ad په bottom کې */}
      <AdMobBanner position="bottom" size="standard" />
    </div>
  );
}
```

**Options:**
- `position`: 'top' یا 'bottom'
- `size`: 'standard' (50px), 'medium' (90px), 'large' (250px)

### **1.3: Interstitial Ad استعمال**

```typescript
function MyPage() {
  const { showAd, checkAndShowAd, closeAd } = useInterstitialAd();

  const handleAction = () => {
    // د user action وروسته
    checkAndShowAd(); // به په automatic ډول ad ښکاره کړي
  };

  return (
    <div>
      <button onClick={handleAction}>Some Action</button>
      
      <AdMobInterstitial 
        isOpen={showAd} 
        onClose={closeAd}
      />
    </div>
  );
}
```

### **1.4: Rewarded Ad استعمال**

```typescript
function MyPage() {
  const { showAd, reward, requestRewardedAd, closeAd, handleRewardEarned } = useRewardedAd();

  const handleWatchAd = () => {
    requestRewardedAd(); // Ad request کړئ
  };

  return (
    <div>
      <button onClick={handleWatchAd}>
        Watch Ad & Earn 10 Points
      </button>
      
      <AdMobRewarded
        isOpen={showAd}
        onClose={closeAd}
        onRewardEarned={handleRewardEarned}
        rewardAmount={10}
        rewardName="Points"
      />
      
      {reward > 0 && <p>You earned {reward} points!</p>}
    </div>
  );
}
```

### **1.5: Native Ad استعمال**

```typescript
function MyPage() {
  return (
    <div>
      {/* د posts یا content ترمنځ */}
      <AdMobNative layout="medium" />
      
      {/* Layouts: 'small', 'medium', 'large' */}
    </div>
  );
}
```

---

## 🧪 **STEP 2: Test IDs چک کړئ**

### **Current Test IDs (په /config/admob.config.ts کې):**

```typescript
// د دې IDs په اوسني حالت کې GOOGLE TEST IDs دي
// دا یوازې د testing لپاره دي

App ID:         ca-app-pub-3940256099942544~3347511713
Banner:         ca-app-pub-3940256099942544/6300978111
Interstitial:   ca-app-pub-3940256099942544/1033173712
Rewarded:       ca-app-pub-3940256099942544/5224354917
Native:         ca-app-pub-3940256099942544/2247696110
```

### **چې دا Test Mode کې دي:**

```typescript
// په /config/admob.config.ts کې line 14:
export const isDevelopment = true;  // ✅ دا true دي
```

---

## 🎨 **STEP 3: Ad Placements (چیرته ښکاره شي)**

### **په /config/admob.config.ts کې:**

```typescript
export const AdPlacements = {
  home: {
    banner: true,       // ⚠️ EDIT: Banner په home page
    interstitial: false,
    native: true,       // ⚠️ EDIT: Native په home page
  },
  doctors: {
    banner: true,
    interstitial: true,  // ⚠️ EDIT: Full screen ad د doctors لیدو وروسته
    native: true,
  },
  hospitals: {
    banner: true,
    interstitial: true,
    native: true,
  },
  medicine: {
    banner: true,
    interstitial: true,
    native: true,
  },
  community: {
    banner: true,
    interstitial: false, // د posts feed کې interstitial مه ښکاروئ
    native: true,        // خو native ads په feed کې ښکاره شي
  },
  profile: {
    banner: true,
    interstitial: false,
    native: false,
  },
};
```

---

## 📊 **STEP 4: Ad Settings (څومره ځله ښکاره شي)**

### **په /config/admob.config.ts کې:**

```typescript
export const AdSettings = {
  banner: {
    enabled: true,           // ⚠️ EDIT: Banner ads enable/disable
    refreshInterval: 60000,  // ⚠️ EDIT: هر 60 ثانیو refresh (milliseconds)
    position: 'bottom',      // 'top' یا 'bottom'
  },

  interstitial: {
    enabled: true,
    showAfterActions: 5,     // ⚠️ EDIT: د 5 actions وروسته ښکاره شي
    cooldownTime: 120000,    // ⚠️ EDIT: 2 دقیقې وقفه د دوه ads ترمنځ
  },

  rewarded: {
    enabled: true,
    rewardAmount: 10,        // ⚠️ EDIT: د reward مقدار
  },

  native: {
    enabled: true,
    showInFeed: true,
    feedInterval: 5,         // ⚠️ EDIT: د هر 5 posts وروسته یو ad
  },
};
```

---

## 🚀 **STEP 5: د اصلي AdMob IDs اضافه کول**

### **5.1: Google AdMob Account جوړ کړئ**

1. https://admob.google.com ته لاړ شئ
2. Google account سره Sign in کړئ
3. "Get Started" click کړئ

### **5.2: App اضافه کړئ**

1. "Apps" → "Add App" click کړئ
2. Platform: Android (یا iOS)
3. App Name: **HealMate**
4. Package Name: `com.healmate.afghanistan` (همغه چې په build config کې استعمال کړئ)
5. Submit

### **5.3: Ad Units جوړ کړئ**

#### **Banner Ad Unit:**
1. د App صفحې ته لاړ شئ
2. "Ad units" → "Add Ad Unit"
3. "Banner" غوره کړئ
4. Ad unit name: `HealMate Banner`
5. Create

#### **Interstitial Ad Unit:**
1. "Add Ad Unit" → "Interstitial"
2. Ad unit name: `HealMate Interstitial`
3. Create

#### **Rewarded Ad Unit:**
1. "Add Ad Unit" → "Rewarded"
2. Ad unit name: `HealMate Rewarded`
3. Create

#### **Native Advanced Ad Unit:**
1. "Add Ad Unit" → "Native Advanced"
2. Ad unit name: `HealMate Native`
3. Create

### **5.4: IDs Copy کړئ**

د هر Ad Unit ID copy کړئ. دوی به دې بڼه کې وي:
```
ca-app-pub-1234567890123456/1234567890
```

### **5.5: IDs په Code کې واچوئ**

**په `/config/admob.config.ts` کې edit کړئ:**

```typescript
// ═══════════════════════════════════════════════════════════════
// ⚠️⚠️⚠️ EDIT HERE - د اصلي IDs واچوئ ⚠️⚠️⚠️
// ═══════════════════════════════════════════════════════════════

// Line 14: Development mode false کړئ د production لپاره
export const isDevelopment = false;  // ⬅️ دلته false کړئ

// Line 25: App ID
const PRODUCTION_APP_ID = 'ca-app-pub-XXXXXXXXXXXXXXXX~XXXXXXXXXX';
                          // ⬆️ ستاسو App ID دلته واچوئ

// Line 35: Banner Ad ID
const PRODUCTION_BANNER_AD_ID = 'ca-app-pub-XXXXXXXXXXXXXXXX/XXXXXXXXXX';
                                // ⬆️ ستاسو Banner ID دلته واچوئ

// Line 45: Interstitial Ad ID
const PRODUCTION_INTERSTITIAL_AD_ID = 'ca-app-pub-XXXXXXXXXXXXXXXX/XXXXXXXXXX';
                                      // ⬆️ ستاسو Interstitial ID دلته واچوئ

// Line 55: Rewarded Ad ID
const PRODUCTION_REWARDED_AD_ID = 'ca-app-pub-XXXXXXXXXXXXXXXX/XXXXXXXXXX';
                                  // ⬆️ ستاسو Rewarded ID دلته واچوئ

// Line 75: Native Ad ID
const PRODUCTION_NATIVE_AD_ID = 'ca-app-pub-XXXXXXXXXXXXXXXX/XXXXXXXXXX';
                                // ⬆️ ستاسو Native ID دلته واچوئ
```

---

## 🔐 **STEP 6: AndroidManifest.xml کې App ID اضافه کړئ**

### **د Android لپاره (PWA → APK conversion):**

که تاسو د PWA څخه APK جوړوئ (Bubblewrap یا TWA استعمالوئ):

**په `android/app/src/main/AndroidManifest.xml` کې:**

```xml
<manifest>
    <application>
        <!-- ⚠️ EDIT: د خپل AdMob App ID دلته واچوئ -->
        <meta-data
            android:name="com.google.android.gms.ads.APPLICATION_ID"
            android:value="ca-app-pub-XXXXXXXXXXXXXXXX~XXXXXXXXXX"/>
    </application>
</manifest>
```

### **د Play Store Build لپاره:**

که تاسو د `/PLAYSTORE_BUILD_GUIDE.md` guide استعمالوئ:

په `app-config.json` کې:
```json
{
  "admob": {
    "appId": "ca-app-pub-XXXXXXXXXXXXXXXX~XXXXXXXXXX"
  }
}
```

---

## 📊 **STEP 7: Ad Analytics & Tracking**

### **د Impressions او Clicks tracking:**

په localStorage کې save کیږي:

```typescript
// د viewing analytics لپاره:
const bannerImpressions = localStorage.getItem('admob_banner_impressions');
const bannerClicks = localStorage.getItem('admob_banner_clicks');
const interstitialImpressions = localStorage.getItem('admob_interstitial_impressions');
const rewardedImpressions = localStorage.getItem('admob_rewarded_impressions');
const rewardsEarned = localStorage.getItem('admob_rewards_earned');
```

### **په Console کې check کړئ:**

```javascript
// Browser Console (F12) کې:
console.log('Banner Impressions:', localStorage.getItem('admob_banner_impressions'));
console.log('Banner Clicks:', localStorage.getItem('admob_banner_clicks'));
console.log('Interstitial Shows:', localStorage.getItem('admob_interstitial_impressions'));
console.log('Rewarded Shows:', localStorage.getItem('admob_rewarded_impressions'));
console.log('Total Rewards Earned:', localStorage.getItem('admob_rewards_earned'));
```

---

## ⚙️ **STEP 8: Customization Options**

### **8.1: د Ads فعال/غیرفعال کول**

په `/config/admob.config.ts` کې:

```typescript
export const AdSettings = {
  banner: {
    enabled: true,  // ⚠️ false کړئ د banner ads غیرفعال کولو لپاره
  },
  interstitial: {
    enabled: true,  // ⚠️ false کړئ د interstitial ads غیرفعال کولو لپاره
  },
  rewarded: {
    enabled: true,  // ⚠️ false کړئ د rewarded ads غیرفعال کولو لپاره
  },
  native: {
    enabled: true,  // ⚠️ false کړئ د native ads غیرفعال کولو لپاره
  },
};
```

### **8.2: د Ad Frequency تنظیم**

```typescript
export const AdSettings = {
  banner: {
    refreshInterval: 60000,  // ⚠️ Milliseconds (60000 = 1 دقیقه)
  },
  interstitial: {
    showAfterActions: 5,     // ⚠️ د څو actions وروسته (زیات کړئ که کم ads غواړئ)
    cooldownTime: 120000,    // ⚠️ د دوه ads ترمنځ وقفه (milliseconds)
  },
  native: {
    feedInterval: 5,         // ⚠️ د څو posts وروسته یو native ad
  },
};
```

### **8.3: د Reward Amount تنظیم**

```typescript
export const AdSettings = {
  rewarded: {
    rewardAmount: 10,  // ⚠️ بدل کړئ (لکه 5, 10, 20 points/coins)
  },
};
```

---

## 🎨 **STEP 9: په مختلفو Pages کې استعمال**

### **Example 1: Home Page**

```typescript
// په /App.tsx کې:
import { AdMobBanner } from './components/ads/AdMobBanner';
import { AdMobNative } from './components/ads/AdMobNative';

{currentPage === 'home' && (
  <div>
    {/* Hero Content */}
    <HeroCarousel />
    
    {/* Native Ad */}
    <AdMobNative layout="medium" className="my-6" />
    
    {/* Categories */}
    <CategoriesSection />
    
    {/* Banner Ad */}
    <AdMobBanner position="bottom" size="standard" />
  </div>
)}
```

### **Example 2: Doctors Directory**

```typescript
// په /components/DoctorsDirectory.tsx کې:
import { AdMobBanner } from './ads/AdMobBanner';
import { AdMobInterstitial, useInterstitialAd } from './ads/AdMobInterstitial';
import { AdMobNative } from './ads/AdMobNative';

function DoctorsDirectory() {
  const { showAd, checkAndShowAd, closeAd } = useInterstitialAd();

  const handleDoctorClick = (doctor) => {
    // د doctor profile لیدو مخکې ad ښکاره کړئ
    const adShown = checkAndShowAd();
    if (!adShown) {
      // که ad ونه ښودل شي، direct profile ته لاړ شئ
      viewDoctorProfile(doctor);
    }
  };

  return (
    <div>
      {/* Doctors List */}
      {doctors.map((doctor, index) => (
        <div key={doctor.id}>
          <DoctorCard 
            doctor={doctor} 
            onClick={() => handleDoctorClick(doctor)}
          />
          
          {/* د هر 5 doctors وروسته Native Ad */}
          {(index + 1) % 5 === 0 && (
            <AdMobNative layout="small" className="my-4" />
          )}
        </div>
      ))}
      
      {/* Banner Ad */}
      <AdMobBanner position="bottom" />
      
      {/* Interstitial Ad */}
      <AdMobInterstitial isOpen={showAd} onClose={closeAd} />
    </div>
  );
}
```

### **Example 3: Community (Social Feed)**

```typescript
// په /components/SimpleSocialFeed.tsx کې:
import { AdMobBanner } from './ads/AdMobBanner';
import { AdMobNative } from './ads/AdMobNative';

function SimpleSocialFeed() {
  return (
    <div>
      {posts.map((post, index) => (
        <div key={post.id}>
          <PostCard post={post} />
          
          {/* د هر 5 posts وروسته Native Ad */}
          {(index + 1) % 5 === 0 && (
            <AdMobNative layout="medium" className="my-6" />
          )}
        </div>
      ))}
      
      {/* Banner Ad */}
      <AdMobBanner position="bottom" />
    </div>
  );
}
```

### **Example 4: Rewarded Ad د Premium Feature لپاره**

```typescript
// په /components/ProfilePage.tsx کې:
import { AdMobRewarded, useRewardedAd } from './ads/AdMobRewarded';

function ProfilePage() {
  const [coins, setCoins] = useState(0);
  const { showAd, requestRewardedAd, closeAd, handleRewardEarned } = useRewardedAd();

  const handleWatchAdForCoins = () => {
    requestRewardedAd();
  };

  const onRewardReceived = (amount) => {
    setCoins(prev => prev + amount);
    alert(`You earned ${amount} coins!`);
  };

  return (
    <div>
      <h2>Your Coins: {coins}</h2>
      
      <button onClick={handleWatchAdForCoins}>
        Watch Ad & Earn 10 Coins 🎁
      </button>
      
      <AdMobRewarded
        isOpen={showAd}
        onClose={closeAd}
        onRewardEarned={onRewardReceived}
        rewardAmount={10}
        rewardName="Coins"
      />
    </div>
  );
}
```

---

## 🧪 **STEP 10: Testing Checklist**

### **د Testing وړاندې:**

```
☐ ټول ad components import شوي دي
☐ Test IDs په config file کې دي
☐ isDevelopment = true دی
☐ AdSettings configured دي
☐ AdPlacements configured دي
```

### **د Testing په وخت:**

```
☐ Banner ads په bottom/top کې ښکاري
☐ د 5 actions وروسته interstitial ad ښکاري
☐ Rewarded ad ښکاري او reward ورکوي
☐ Native ads په feed کې integrate دي
☐ "TEST AD" badge ښکاري
☐ Console logs ښکاري د impressions/clicks
```

### **د Production وړاندې:**

```
☐ Google AdMob account جوړ شو
☐ App په AdMob کې register شو
☐ ټول Ad Units جوړ شول
☐ اصلي IDs په config file کې اضافه شول
☐ isDevelopment = false شو
☐ AndroidManifest.xml updated شو
☐ App rebuilt او tested شو
☐ Ads په production mode کې ښکاري
```

---

## 🎯 **STEP 11: د Revenue لوړولو Tips**

### **11.1: مختلف Ad Formats استعمال کړئ**

```
✅ Banner: د page په bottom/top (د visibility لپاره)
✅ Interstitial: د مهم actions وروسته (لکه د section بدلون)
✅ Native: په content feed کې (د better UX لپاره)
✅ Rewarded: د premium features unlock کولو لپاره
```

### **11.2: د Ad Placement Optimization**

```
High Traffic Pages:
├─ Home: Banner + Native
├─ Doctors: Banner + Interstitial + Native
├─ Hospitals: Banner + Interstitial + Native
├─ Medicine: Banner + Interstitial + Native
└─ Community: Banner + Native (Interstitial مه ښکاروئ د UX لپاره)
```

### **11.3: د User Experience Balance**

```
⚖️ زیات ads = زیات revenue خو خراب UX
⚖️ کم ads = ښه UX خو کم revenue

Best Practice:
├─ Banner: هر 60 ثانیو refresh
├─ Interstitial: د 5 actions وروسته، 2 دقیقې cooldown
├─ Native: د 5 posts وروسته
└─ Rewarded: Optional، د user په خوښه
```

---

## 📊 **STEP 12: د Revenue Tracking**

### **په Google AdMob Console:**

1. https://apps.admob.google.com ته لاړ شئ
2. "Reports" tab click کړئ
3. Date range غوره کړئ
4. Metrics:
   - **Impressions**: د ads څومره ځله ښودل شوي
   - **Clicks**: څومره ځله click شوي
   - **CTR** (Click-Through Rate): د clicks percentage
   - **eCPM**: د 1000 impressions عاید
   - **Revenue**: ټول عاید

### **په App کې Local Tracking:**

```typescript
// د statistics page جوړ کړئ:
function AdStatistics() {
  const stats = {
    bannerImpressions: localStorage.getItem('admob_banner_impressions') || 0,
    bannerClicks: localStorage.getItem('admob_banner_clicks') || 0,
    interstitialShows: localStorage.getItem('admob_interstitial_impressions') || 0,
    rewardedShows: localStorage.getItem('admob_rewarded_impressions') || 0,
    rewardsEarned: localStorage.getItem('admob_rewards_earned') || 0,
  };

  return (
    <div>
      <h2>Ad Statistics (Local)</h2>
      <p>Banner Impressions: {stats.bannerImpressions}</p>
      <p>Banner Clicks: {stats.bannerClicks}</p>
      <p>Interstitial Shows: {stats.interstitialShows}</p>
      <p>Rewarded Shows: {stats.rewardedShows}</p>
      <p>Rewards Earned: {stats.rewardsEarned}</p>
    </div>
  );
}
```

---

## ⚠️ **STEP 13: مهم نکتې او خبرداری**

### **❌ دا مه کوئ:**

```
❌ د Production کې Test IDs استعمال مه کوئ
   → ستاسو account suspend کیږي

❌ زیات ads مه ښکاروئ
   → Users به irritate شي او app delete کړي

❌ د هر click باندې ads مه ښکاروئ
   → Google policy violation

❌ Fake clicks مه جوړوئ
   → Account ban کیږي

❌ د Content څخه زیات ads مه اضافه کوئ
   → Users به منفي reviews ورکړي
```

### **✅ دا وکړئ:**

```
✅ د Real Users testing وروسته optimize کړئ

✅ د AdMob Policies لوستل او تعقیب
   → https://support.google.com/admob/answer/6128543

✅ GDPR/COPPA compliance د EU users لپاره
   → د consent form استعمال کړئ

✅ د Ad Performance منظم monitor کړئ

✅ د Users feedback واورئ د ads په اړه

✅ A/B testing وکړئ د different placements لپاره
```

---

## 🚀 **STEP 14: Quick Start Commands**

### **د Testing لپاره (اوس):**

```bash
# 1. File open کړئ:
/config/admob.config.ts

# 2. Verify:
isDevelopment = true  ✅

# 3. App ته لاړ شئ او ads ولټوئ:
- Banner: په page bottom
- Interstitial: د 5 clicks وروسته
- Rewarded: "Watch Ad" button click
- Native: په feed کې

# 4. Console check کړئ (F12):
[AdMob] Banner Ad Impression ✅
[AdMob] Interstitial Ad Shown ✅
[AdMob] Rewarded Ad Shown ✅
```

### **د Production لپاره (وروسته):**

```bash
# 1. File open کړئ:
/config/admob.config.ts

# 2. Edit:
Line 14: isDevelopment = false
Line 25: PRODUCTION_APP_ID = 'ستاسو ID'
Line 35: PRODUCTION_BANNER_AD_ID = 'ستاسو ID'
Line 45: PRODUCTION_INTERSTITIAL_AD_ID = 'ستاسو ID'
Line 55: PRODUCTION_REWARDED_AD_ID = 'ستاسو ID'
Line 75: PRODUCTION_NATIVE_AD_ID = 'ستاسو ID'

# 3. Save

# 4. App rebuild:
npm run build

# 5. Test:
- No "TEST AD" badge ✅
- Real ads ښکاري (د AdMob network څخه)

# 6. Deploy to Play Store
```

---

## 📚 **Useful Resources:**

```
📖 AdMob Documentation:
   https://developers.google.com/admob

🧪 Test Ad IDs:
   https://developers.google.com/admob/android/test-ads

💰 AdMob Console:
   https://apps.admob.google.com

📊 Best Practices:
   https://support.google.com/admob/answer/6128543

🔐 AdMob Policies:
   https://support.google.com/admob/answer/6128543

💡 Optimization Tips:
   https://support.google.com/admob/answer/9234653
```

---

## ✅ **Final Checklist:**

```
Testing Phase (اوس):
☐ Components created
☐ Test IDs configured
☐ Ads showing in app
☐ Console logs working
☐ All ad types tested
☐ User experience good

Production Phase (وروسته):
☐ Google AdMob account
☐ App registered
☐ Ad Units created
☐ Real IDs obtained
☐ Config file updated
☐ isDevelopment = false
☐ AndroidManifest updated
☐ App rebuilt
☐ Real ads showing
☐ Revenue tracking setup
☐ Play Store deployed

SUCCESS! 🎉💰
```

---

**🎊 AdMob Integration بشپړ دی! اوس یې Test کړئ د Test IDs سره، او وروسته د اصلي IDs اضافه کړئ! 🚀**

**Quick Edit Locations:**
- 📁 `/config/admob.config.ts` - Lines: 14, 25, 35, 45, 55, 75
- ⚙️ `isDevelopment` flag - Line 14
- 🆔 All Production IDs - Lines 25-75

**Status: 🟢 READY FOR TESTING!**
