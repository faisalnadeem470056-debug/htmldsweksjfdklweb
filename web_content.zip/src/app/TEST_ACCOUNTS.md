# 🧪 Test Accounts - د ازموینې حسابونه

---

## 👨‍💼 **Admin Account:**

```
Email:    ibrahimkhaksar.it@gmail.com
Password: [د خپل password استعمال کړئ]

Access:
✅ Admin Panel
✅ User Management
✅ Doctor Management
✅ Post Management
✅ Medicine Management
✅ Premium Management
✅ Statistics
✅ All Features
```

---

## 👤 **Test User Accounts:**

### **User 1 (Auto-created):**
```
Email:    test@healmate.com
Password: test123
Name:     Test User
Status:   ✅ Verified

Access:
✅ Community Posts
✅ Profile
✅ Create Posts
✅ Comment & React
✅ All Public Features
❌ Admin Panel
```

### **User 2:**
```
Email:    doctor@healmate.com
Password: doctor123
Name:     Dr. Ahmad
Status:   ✅ Verified

Access:
✅ Community Posts
✅ Profile
✅ Premium Features (if subscribed)
❌ Admin Panel
```

### **User 3:**
```
Email:    patient@healmate.com
Password: patient123
Name:     Mohammad Ali
Status:   ✅ Verified

Access:
✅ Community Posts
✅ Profile
✅ Basic Features
❌ Admin Panel
```

---

## 🚀 **Quick Test:**

### **1. Test Community/Posts:**
```bash
1. Login: test@healmate.com / test123
2. Navigate to: Community (د ټولنې)
3. Create new post
4. Add image (optional)
5. Submit
6. See post in feed
7. Like, comment, share
8. Success! ✅
```

### **2. Test Admin Panel:**
```bash
1. Login: ibrahimkhaksar.it@gmail.com
2. Look for Admin button in:
   - Desktop Header (Shield icon)
   - Mobile Menu (Red border)
   - Settings Page (Admin Section)
3. Click Admin Panel
4. See dashboard
5. Success! ✅
```

### **3. Test Medicine Database:**
```bash
1. Home Page
2. Click: Medicine Guide (درمل لارښود)
3. Search: پاراسیتامول
4. Click on medicine
5. See details
6. Success! ✅
```

---

## 🔍 **Debugging:**

### **Problem: Admin Panel نه ښکاري**

```javascript
// Check localStorage:
console.log(localStorage.getItem('healmate_userEmail'));

// Should be:
// "ibrahimkhaksar.it@gmail.com"

// If not, login again or set manually:
localStorage.setItem('healmate_userEmail', 'ibrahimkhaksar.it@gmail.com');
localStorage.setItem('healmate_userName', 'Ibrahim Khaksar');
localStorage.setItem('healmate_isAuthenticated', 'true');

// Then refresh page
```

### **Problem: Posts نه ښکاري**

```javascript
// Check if logged in:
console.log(localStorage.getItem('healmate_isAuthenticated'));

// Should be: "true"

// If not, login first:
// 1. Click Login button
// 2. Use: test@healmate.com / test123
// 3. Go to Community
// 4. Posts should show
```

### **Problem: Posts خالي دي**

```javascript
// Check posts in localStorage:
console.log(JSON.parse(localStorage.getItem('healmate_posts') || '[]'));

// If empty, create test post:
const testPost = {
  id: 'post-' + Date.now(),
  userId: localStorage.getItem('healmate_userEmail'),
  userName: localStorage.getItem('healmate_userName'),
  userImage: 'https://images.unsplash.com/photo-1633332755192-727a05c4013d?w=400',
  content: 'د ازموینې لومړنۍ پوسټ - Test Post',
  images: [],
  reactions: [],
  comments: [],
  timestamp: new Date().toISOString()
};

const posts = JSON.parse(localStorage.getItem('healmate_posts') || '[]');
posts.unshift(testPost);
localStorage.setItem('healmate_posts', JSON.stringify(posts));

// Refresh page
```

---

## 📱 **Test Scenarios:**

### **Scenario 1: New User Registration**
```
1. Click "Login" button
2. Click "Sign Up" tab
3. Enter:
   - Name: Ahmad Khan
   - Email: ahmad@test.com
   - Phone: +93 700 123 456
   - Password: test123
4. Click "Sign Up"
5. Verify with code: 123456
6. Login automatic
7. Success! ✅
```

### **Scenario 2: Create Post**
```
1. Login: test@healmate.com
2. Go to Community
3. Click "Create Post" or text area
4. Write: سلام! دا زما لومړنۍ پوسټ دی
5. (Optional) Add image
6. Click "Post"
7. See post in feed immediately
8. Success! ✅
```

### **Scenario 3: Admin Actions**
```
1. Login: ibrahimkhaksar.it@gmail.com
2. Go to Admin Panel
3. Click "Users" tab
4. See all users
5. Click "Posts" tab
6. See all posts
7. Delete a post (test)
8. Post removed from system
9. Success! ✅
```

### **Scenario 4: Medicine Search**
```
1. Home → Medicine Guide
2. Search: "پاراسیتامول"
3. See results
4. Click on medicine
5. See full details:
   - Name (3 languages)
   - Usage
   - Dosage
   - Side Effects
   - Warnings
6. Success! ✅
```

---

## 🔐 **Security Test:**

### **Test 1: Non-admin cannot access Admin Panel**
```bash
1. Login: test@healmate.com
2. Try to access Admin:
   - Desktop: No Admin button ✅
   - Mobile: No Admin button ✅
   - Settings: No Admin section ✅
   - Direct URL: Blocked ✅
3. Success! Security working ✅
```

### **Test 2: Guest cannot post**
```bash
1. Don't login (guest)
2. Go to Community
3. Should see login prompt ✅
4. Cannot create post ✅
5. Success! Security working ✅
```

---

## 📊 **Test Data:**

### **Pre-loaded Data:**
```
Doctors:      250+ (in database)
Medicines:    1500+ (in database)
Hospitals:    150+ (in database)
Users:        Auto-created on registration
Posts:        Created by users
Comments:     Created by users
Reactions:    Created by users
```

### **Creating Bulk Test Data:**

```javascript
// Run in browser console:

// Create 10 test posts:
function createTestPosts() {
  const posts = JSON.parse(localStorage.getItem('healmate_posts') || '[]');
  const testUsers = ['Ahmad', 'Fatima', 'Ali', 'Zainab', 'Omar'];
  
  for (let i = 0; i < 10; i++) {
    const userName = testUsers[Math.floor(Math.random() * testUsers.length)];
    const post = {
      id: 'test-post-' + Date.now() + '-' + i,
      userId: 'test-user-' + i,
      userName: userName,
      userImage: `https://images.unsplash.com/photo-${1600000000000 + i}?w=400`,
      content: `د ازموینې پوسټ نمبر ${i + 1} - Test post number ${i + 1}`,
      images: [],
      reactions: [],
      comments: [],
      timestamp: new Date(Date.now() - i * 3600000).toISOString()
    };
    posts.unshift(post);
  }
  
  localStorage.setItem('healmate_posts', JSON.stringify(posts));
  console.log('✅ 10 test posts created!');
  location.reload();
}

createTestPosts();
```

---

## ✅ **Complete Test Checklist:**

```
Authentication:                 □
├── Register new user           □
├── Login existing user         □
├── Logout                      □
├── Remember login              □
└── Session persistence         □

Community/Posts:                □
├── View posts (logged in)      □
├── Create post                 □
├── Add image to post           □
├── Like post                   □
├── Comment on post             □
├── Share post                  □
├── Delete own post             □
└── View post in feed           □

Admin Panel:                    □
├── Access as admin             □
├── View dashboard              □
├── User management             □
├── Post management             □
├── Doctor management           □
├── Medicine management         □
├── Premium management          □
└── Statistics view             □

Medicine Database:              □
├── Search medicines            □
├── Filter by category          □
├── View details                □
├── Multi-language display      □
└── Admin CRUD                  □

General Features:               □
├── Language switching          □
├── Navigation                  □
├── Responsive design           □
├── Mobile menu                 □
├── Settings page               □
├── Profile page                □
└── All links working           □

Security:                       □
├── Admin panel protected       □
├── Posts require login         □
├── Profile require login       □
├── Guest limitations           □
└── Data validation             □
```

---

## 🆘 **Need Help?**

### **Common Issues:**

#### **1. "Admin button نه ښکاري"**
```
Solution:
1. Check email: ibrahimkhaksar.it@gmail.com
2. Logout and login again
3. Clear cache: localStorage.clear()
4. Login again
5. Check 3 locations:
   - Desktop header
   - Mobile menu
   - Settings page
```

#### **2. "Posts نه ښکاري"**
```
Solution:
1. Login first (required)
2. Go to Community
3. If empty, create test post
4. Refresh page
5. Should see posts
```

#### **3. "Cannot create post"**
```
Solution:
1. Check if logged in
2. Check internet connection
3. Check browser console for errors
4. Try logout/login
5. Clear cache and retry
```

---

**🎉 ټول Test Accounts چمتو دي! استعمال یې کړئ او ټول features ازمویئ! 🚀✨**

**Quick Start:**
1. Login: `test@healmate.com` / `test123`
2. Go to Community → Create Post
3. Admin: Login با `ibrahimkhaksar.it@gmail.com`
4. Success! ✅
