# 🚀 د HealMate Deployment لارښود
# HealMate Deployment Guide

## ستاسو App اوس د Deploy کولو لپاره چمتو دی!

---

## 🌐 لاره 1: Vercel (ترټولو اسانه - 5 دقیقې) ⭐

### قدم 1: Vercel Account جوړ کړئ
1. https://vercel.com ته ورشئ
2. "Sign Up" کلیک وکړئ
3. GitHub سره connect کړئ (سپارښتنه)
   - یا Email/Google سره

### قدم 2: GitHub Repository جوړ کړئ
```bash
# په خپل project folder کې:
git init
git add .
git commit -m "HealMate App - Ready for deployment"

# GitHub repository جوړ کړئ او push کړئ:
# 1. GitHub.com ته ورشئ
# 2. "New repository" کلیک وکړئ
# 3. نوم: healmate-app
# 4. Public یا Private (دواړه کار کوي)
# 5. Create repository

# بیا:
git remote add origin https://github.com/YOUR_USERNAME/healmate-app.git
git branch -M main
git push -u origin main
```

### قدم 3: Vercel ته Deploy کړئ
1. Vercel Dashboard ته ورشئ
2. "Add New" → "Project" کلیک وکړئ
3. د خپل GitHub repository import کړئ
4. تنظیمات سم کړئ:

```
Framework Preset: Vite
Build Command: npm run build
Output Directory: dist
Install Command: npm install
```

5. **Environment Variables** (که اړین وي):
```
VITE_ADMOB_ANDROID_ID=ca-app-pub-XXXXXXXXXXXXXXXX~XXXXXXXXXX
VITE_ADMOB_IOS_ID=ca-app-pub-XXXXXXXXXXXXXXXX~XXXXXXXXXX
```

6. "Deploy" کلیک وکړئ ✅

### قدم 4: ستاسو URL!
- ⏳ 2-3 دقیقې انتظار وکړئ
- ✅ Deploy بشپړ شو!
- 🌐 ستاسو URL به داسې وي: `https://healmate-app.vercel.app`

---

## 🌐 لاره 2: Netlify (بله اسانه لاره)

### قدم 1: Netlify Account
1. https://netlify.com ته ورشئ
2. "Sign up" کلیک وکړئ
3. GitHub سره connect کړئ

### قدم 2: GitHub Push (د پورتنۍ لارې په شان)
```bash
git init
git add .
git commit -m "HealMate App deployment"
git push origin main
```

### قدم 3: Netlify ته Deploy کړئ
1. Netlify Dashboard
2. "Add new site" → "Import an existing project"
3. GitHub repository select کړئ
4. تنظیمات:

```
Build command: npm run build
Publish directory: dist
```

5. "Deploy site" کلیک وکړئ

### قدم 4: ستاسو URL!
- URL به داسې وي: `https://healmate-app.netlify.app`
- Custom domain هم set کولی شئ

---

## 🌐 لاره 3: GitHub Pages (وړیا!)

### قدم 1: د Build تنظیمات
د `vite.config.ts` فایل سم کړئ:

```typescript
export default defineConfig({
  base: '/healmate-app/', // د خپل repo نوم
  // ... نور تنظیمات
})
```

### قدم 2: د GitHub Actions Setup
یو نوی فایل جوړ کړئ: `.github/workflows/deploy.yml`

```yaml
name: Deploy to GitHub Pages

on:
  push:
    branches: [ main ]

jobs:
  build-and-deploy:
    runs-on: ubuntu-latest
    
    steps:
    - uses: actions/checkout@v3
    
    - name: Setup Node.js
      uses: actions/setup-node@v3
      with:
        node-version: '18'
    
    - name: Install dependencies
      run: npm install
    
    - name: Build
      run: npm run build
    
    - name: Deploy to GitHub Pages
      uses: peaceiris/actions-gh-pages@v3
      with:
        github_token: ${{ secrets.GITHUB_TOKEN }}
        publish_dir: ./dist
```

### قدم 3: GitHub Settings
1. GitHub repository ته ورشئ
2. Settings → Pages
3. Source: "gh-pages" branch
4. Save

### قدم 4: Push!
```bash
git add .
git commit -m "Add GitHub Pages deployment"
git push origin main
```

- URL: `https://YOUR_USERNAME.github.io/healmate-app/`

---

## 🌐 لاره 4: د Figma Make څخه مستقیماً

که تاسو د Figma Make Preview URL وکاروئ:

### د Testing لپاره:
که تاسو یوازې test کول غواړئ:

1. **د Local APK جوړول**:
```bash
# Bubblewrap کاروئ:
npm install -g @bubblewrap/cli

# د local server start کړئ:
npm run dev

# په بل terminal کې:
npx bubblewrap init --manifest http://localhost:5173/manifest.json
npx bubblewrap build
```

2. **APK د خپل موبایل ته transfer کړئ**:
- APK به په `./app-release-signed.apk` کې وي
- د USB سره موبایل ته transfer کړئ
- Install او test کړئ

---

## ⚡ د Vercel Quick Deploy (بغیر GitHub)

### د Vercel CLI کارول:
```bash
# 1. Vercel CLI install کړئ
npm install -g vercel

# 2. Login
vercel login

# 3. د project folder ته ورشئ او:
vercel

# 4. سوالاتو ځواب ورکړئ:
# - Set up and deploy? Yes
# - Scope: ستاسو account
# - Link to existing project? No
# - Project name: healmate-app
# - Directory: ./ (Enter)
# - Override settings? No

# 5. Deploy!
vercel --prod
```

- ✅ Done! ستاسو URL به ښکاره شي

---

## 🔧 د Deployment وروسته Checklist

کله چې deploy بشپړ شو:

### 1. Test ستاسو App:
- [ ] URL په browser کې open کړئ
- [ ] ټولې صفحې کار کوي
- [ ] درې ژبې work کوي
- [ ] Images load کیږي
- [ ] Icons سم دي

### 2. PWA Test:
- [ ] Browser DevTools → Application → Manifest
- [ ] یقیني کړئ چې manifest valid دی
- [ ] Service Worker registered دی

### 3. Lighthouse Test:
- [ ] Browser DevTools → Lighthouse
- [ ] "Progressive Web App" test run کړئ
- [ ] Score: 80+ (ښه), 90+ (عالی!)

---

## 🚀 اوس PWABuilder کاروئ!

کله چې ستاسو app deploy شو:

```
1. https://www.pwabuilder.com ته ورشئ
2. ستاسو deployed URL داخل کړئ:
   مثال: https://healmate-app.vercel.app
3. "Start" کلیک وکړئ
4. ⏳ 10-15 ثانیې انتظار وکړئ
5. ✅ "Package for stores" → "Android"
6. 📦 AAB/APK download کړئ
7. 🎉 Play Store ته upload کړئ!
```

---

## 🌐 د Custom Domain Setup (اختیاري)

### Vercel کې:
1. Domain اخیستئ (Namecheap, GoDaddy, etc.)
2. Vercel Dashboard → Project → Settings → Domains
3. ستاسو domain اضافه کړئ: `healmate.af`
4. DNS تنظیمات سم کړئ (Vercel به لارښوونې درکړي)
5. ✅ Done! `https://healmate.af`

### Netlify کې:
1. Netlify Dashboard → Domain settings
2. "Add custom domain"
3. ستاسو domain داخل کړئ
4. DNS تنظیمات سم کړئ
5. SSL اوتومات enable کیږي

---

## 📊 د Deployment Performance

### Vercel:
- ✅ ګړندی deployment (1-3 دقیقې)
- ✅ Automatic HTTPS
- ✅ Global CDN
- ✅ Automatic builds د GitHub push سره
- ✅ وړیا لپاره: 100GB bandwidth

### Netlify:
- ✅ ګړندی deployment (2-4 دقیقې)
- ✅ Automatic HTTPS
- ✅ Global CDN
- ✅ Forms support
- ✅ وړیا لپاره: 100GB bandwidth

### GitHub Pages:
- ✅ بشپړ وړیا
- ✅ Unlimited bandwidth (د GitHub لخوا)
- ⚠️ د deploy وخت: 5-10 دقیقې
- ⚠️ یوازې static content

---

## 🎯 سپارښتنه شوې لاره:

### د HealMate لپاره:
🏆 **Vercel** - ترټولو اسانه او ګړندۍ!

```bash
# Terminal کې:
npm install -g vercel
vercel login
vercel --prod

# ✅ Done! URL ترلاسه کړئ او PWABuilder ته ورشئ!
```

---

## 💡 Pro Tips:

1. **Environment Variables**:
   - د Vercel/Netlify dashboard کې set کړئ
   - بیا redeploy کړئ

2. **Custom Build Commands**:
   ```bash
   # package.json کې:
   "scripts": {
     "build": "vite build",
     "preview": "vite preview"
   }
   ```

3. **د SEO لپاره**:
   - د `index.html` meta tags سم کړئ
   - Open Graph tags اضافه کړئ
   - Sitemap جوړ کړئ

---

## 📞 د مرستې لپاره:

که deployment کې مسله لرئ:
- 📧 Email: ibrahimkhaksar.it@gmail.com
- 📱 Phone: +93 783 040 441

---

## ✅ Success Flow:

```
1. Vercel/Netlify ته account جوړ کړئ (2 دقیقې)
2. GitHub ته code push کړئ (3 دقیقې)
3. Vercel/Netlify سره connect کړئ (2 دقیقې)
4. Deploy! (اوتومات - 3 دقیقې)
5. URL ترلاسه کړئ ✅
6. PWABuilder ته ورشئ (2 دقیقې)
7. APK Generate کړئ (2 دقیقې)
8. Play Store ته upload کړئ 🎉

ټول وخت: 15-20 دقیقې!
```

---

## 🎊 بریا!

ستاسو HealMate app به په نړۍ کې Live وي! 🌍🇦🇫

**ګړندۍ لاره:**
```bash
vercel login
vercel --prod
```

**او بیا PWABuilder ته ورشئ!** 🚀
