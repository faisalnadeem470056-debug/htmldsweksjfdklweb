# Privacy Policy - د محرمیت تګلاره

## English Version

**Last updated: January 2025**

### Information We Collect
HealMate ("we", "our", or "us") respects your privacy. This app collects minimal information:
- Anonymous usage analytics to improve app performance
- User preferences (language selection, settings)
- Community posts that you voluntarily share

### Information We Don't Collect
- We DO NOT collect personal health information
- We DO NOT collect personally identifiable information (PII)
- We DO NOT sell or share your data with third parties
- We DO NOT track your location

### How We Use Information
- To improve app functionality and user experience
- To provide health information and resources
- To enable community features

### Data Storage
- All data is stored locally on your device
- Community posts are stored anonymously
- No sensitive health data is transmitted

### Third-Party Services
- We may use analytics services (Google Analytics) with anonymized data
- AdMob for advertisements (see Google's privacy policy)

### Your Rights
- You can delete all app data from Settings
- You can disable analytics and ads in Settings
- You can contact us to request data deletion

### Children's Privacy
This app is not intended for children under 13. We do not knowingly collect data from children.

### Contact Us
For privacy concerns:
- Email: ibrahimkhaksar.it@gmail.com
- Phone: +93 783 040 441

---

## نسخه پښتو

**وروستۍ تازه: جنوري 2025**

### د معلوماتو راټولول
HealMate ("موږ") ستاسو د محرمیت درناوی کوو. دا اپلیکیشن لږ معلومات راټولوي:
- د اپلیکیشن د کارکولو بې نومه تحلیلونه
- د کاروونکي ترجیحات (د ژبې انتخاب، تنظیمات)
- د ټولنې پوستونه چې تاسو په خپله خوښه شریکوئ

### معلومات چې موږ نه راټولوو
- موږ د شخصي روغتیا معلومات نه راټولوو
- موږ د شخصي پېژندنې معلومات نه راټولوو
- موږ ستاسو معلومات نورو سره نه شریکوو
- موږ ستاسو موقعیت تعقیب نکوو

### د معلوماتو کارول
- د اپلیکیشن د کارکولو او تجربې د ښه کولو لپاره
- د روغتیا معلومات او سرچینې چمتو کولو لپاره
- د ټولنې فیچرونو فعالولو لپاره

### د ډاټا ذخیره کول
- ټول معلومات ستاسو په device کې ذخیره کیږي
- د ټولنې پوستونه بې نومه ذخیره کیږي
- هیڅ حساس روغتیا معلومات نه لیږدول کیږي

### د ثالث خدمات
- موږ کیدای شي analytics خدمات وکاروو (Google Analytics) د بې نومه ډاټا سره
- AdMob د اعلاناتو لپاره (د Google محرمیت تګلاره وګورئ)

### ستاسو حقوق
- تاسو کولی شئ د تنظیماتو څخه ټول app ډاټا پاک کړئ
- تاسو کولی شئ analytics او اعلانات غیرفعال کړئ
- تاسو کولی شئ موږ سره د ډاټا د حذف کولو لپاره اړیکه ونیسئ

### د ماشومانو محرمیت
دا اپلیکیشن د 13 کالو څخه کم ماشومانو لپاره نه دی. موږ په خبره د ماشومانو څخه معلومات نه راټولوو.

### اړیکه
د محرمیت د اندیښنو لپاره:
- بریښنالیک: ibrahimkhaksar.it@gmail.com
- تلیفون: +93 783 040 441

---

## نسخه دری

**آخرین به‌روزرسانی: جنوری 2025**

### اطلاعات جمع‌آوری شده
HealMate ("ما") به حریم خصوصی شما احترام می‌گذارد. این برنامه اطلاعات کمی جمع‌آوری می‌کند:
- تحلیل‌های ناشناس استفاده برای بهبود عملکرد برنامه
- ترجیحات کاربر (انتخاب زبان، تنظیمات)
- پست‌های اجتماعی که شما داوطلبانه به اشتراک می‌گذارید

### اطلاعاتی که جمع‌آوری نمی‌کنیم
- ما اطلاعات سلامت شخصی جمع‌آوری نمی‌کنیم
- ما اطلاعات قابل شناسایی شخصی جمع‌آوری نمی‌کنیم
- ما داده‌های شما را با اشخاص ثالث به اشتراک نمی‌گذاریم
- ما موقعیت شما را ردیابی نمی‌کنیم

### نحوه استفاده از اطلاعات
- برای بهبود عملکرد و تجربه کاربر
- برای ارائه اطلاعات و منابع سلامت
- برای فعال کردن ویژگی‌های اجتماعی

### ذخیره‌سازی داده
- تمام داده‌ها روی دستگاه شما ذخیره می‌شوند
- پست‌های اجتماعی به صورت ناشناس ذخیره می‌شوند
- هیچ داده سلامت حساسی منتقل نمی‌شود

### خدمات شخص ثالث
- ممکن است از خدمات تحلیلی استفاده کنیم (Google Analytics) با داده‌های ناشناس
- AdMob برای تبلیغات (سیاست حریم خصوصی Google را ببینید)

### حقوق شما
- می‌توانید تمام داده‌های برنامه را از تنظیمات حذف کنید
- می‌توانید تحلیل‌ها و تبلیغات را غیرفعال کنید
- می‌توانید برای درخواست حذف داده با ما تماس بگیرید

### حریم خصوصی کودکان
این برنامه برای کودکان زیر 13 سال نیست. ما عمداً از کودکان داده جمع‌آوری نمی‌کنیم.

### تماس با ما
برای نگرانی‌های حریم خصوصی:
- ایمیل: ibrahimkhaksar.it@gmail.com
- تلفون: +93 783 040 441
