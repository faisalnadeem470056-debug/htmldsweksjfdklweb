@echo off
chcp 65001 >nul
cls

REM HealMate Android Setup Script for Windows
REM د ډاکټر ابراهیم خاکسار لخوا جوړ شوی

echo.
echo ========================================
echo 🏥 HealMate Android Setup (Windows)
echo ========================================
echo.

REM Step 1: د Prerequisites چیک کول
echo Step 1: د Prerequisites چیک کول...
echo ------------------------------------
echo.

REM Java چیک کول
where java >nul 2>nul
if %ERRORLEVEL% EQU 0 (
    echo ✅ Java نصب دی
    java -version
) else (
    echo ❌ Java نصب نه دی
    echo مهرباني وکړئ JDK 17 نصب کړئ
    echo Link: https://adoptium.net/
    pause
    exit /b 1
)

echo.

REM Node.js چیک کول
where node >nul 2>nul
if %ERRORLEVEL% EQU 0 (
    echo ✅ Node.js نصب دی
    node --version
) else (
    echo ❌ Node.js نصب نه دی
    echo مهرباني وکړئ Node.js نصب کړئ
    echo Link: https://nodejs.org/
    pause
    exit /b 1
)

echo.

REM Gradle wrapper چیک کول
if exist "android\gradlew.bat" (
    echo ✅ Gradle wrapper موجود دی
) else (
    echo ⚠️ Gradle wrapper نه موجود دی
)

echo.
echo.

REM Step 2: د Firebase setup
echo Step 2: د Firebase Configuration
echo ---------------------------------
echo.

if exist "android\app\google-services.json" (
    echo ✅ google-services.json موجود دی
) else (
    echo ❌ google-services.json نه موجود دی!
    echo.
    echo مهرباني وکړئ دا فایل د Firebase Console څخه ډاونلوډ کړئ
    echo او په android\app\ کې کاپي کړئ
    echo.
    echo Link: https://console.firebase.google.com
    echo.
)

echo.

REM Step 3: د Firebase config چیک کول
echo Step 3: د Firebase Config فایل
echo -------------------------------
echo.

if exist "firebase-config.ts" (
    findstr /C:"YOUR_FIREBASE_API_KEY" firebase-config.ts >nul
    if %ERRORLEVEL% EQU 0 (
        echo ⚠️ firebase-config.ts ته د Firebase معلوماتو اړتیا ده
        echo مهرباني وکړئ YOUR_FIREBASE_API_KEY او نور معلومات تازه کړئ
    ) else (
        echo ✅ firebase-config.ts configure شوی
    )
) else (
    echo ❌ firebase-config.ts نه موجود دی
)

echo.
echo.

REM Step 4: د Android build configuration
echo Step 4: د Android Build Configuration
echo -------------------------------------
echo.

REM د domain چیک کول
findstr /C:"YOUR_DOMAIN.com" "android\app\build.gradle" >nul
if %ERRORLEVEL% EQU 0 (
    echo ⚠️ د domain معلومات تازه کولو ته اړتیا ده
    echo په build.gradle کې YOUR_DOMAIN.com د خپل domain سره بدل کړئ
) else (
    echo ✅ Domain configure شوی
)

echo.

REM د AdMob App ID چیک کول
findstr /C:"ca-app-pub-XXXXXXXXXXXXXXXX" "android\app\src\main\AndroidManifest.xml" >nul
if %ERRORLEVEL% EQU 0 (
    echo ⚠️ د AdMob App ID تازه کولو ته اړتیا ده
    echo په AndroidManifest.xml کې د AdMob App ID اضافه کړئ
) else (
    echo ✅ AdMob App ID configure شوی
)

echo.
echo.

REM Step 5: د Keystore چیک کول
echo Step 5: د Release Keystore
echo --------------------------
echo.

if exist "android\healmate-release.keystore" (
    echo ✅ Release keystore موجود دی
) else (
    echo ⚠️ Release keystore نه موجود دی
    echo.
    echo د release build لپاره keystore جوړ کړئ:
    echo.
    echo keytool -genkey -v -keystore android\healmate-release.keystore ^
    echo     -alias healmate -keyalg RSA -keysize 2048 -validity 10000
    echo.
)

if exist "android\gradle.properties" (
    echo ✅ gradle.properties موجود دی
) else (
    echo ⚠️ gradle.properties نه موجود دی
    echo د keystore معلوماتو لپاره gradle.properties جوړ کړئ
)

echo.
echo.

REM Step 6: د PWA build
echo Step 6: د PWA Build
echo -------------------
echo.

echo د PWA build کول...
call npm run build

if %ERRORLEVEL% EQU 0 (
    echo.
    echo ✅ PWA build بریالیتوب سره جوړ شو
) else (
    echo.
    echo ❌ PWA build ناکام شو
    pause
    exit /b 1
)

echo.
echo.

REM Step 7: د Android build options
echo Step 7: د Android Build Options
echo --------------------------------
echo.
echo د Android build لپاره لاندې commands کارولی شئ:
echo.
echo 1️⃣  د Debug APK لپاره:
echo    cd android ^&^& gradlew.bat assembleDebug
echo.
echo 2️⃣  د Release APK لپاره:
echo    cd android ^&^& gradlew.bat assembleRelease
echo.
echo 3️⃣  د Release AAB لپاره (Play Store):
echo    cd android ^&^& gradlew.bat bundleRelease
echo.
echo 4️⃣  د Clean build لپاره:
echo    cd android ^&^& gradlew.bat clean
echo.
echo.

set /p BUILD_DEBUG="ایا تاسو اوس Debug APK جوړ کول غواړئ؟ (y/n): "

if /i "%BUILD_DEBUG%"=="y" (
    echo.
    echo د Debug APK جوړول...
    cd android
    call gradlew.bat assembleDebug
    
    if %ERRORLEVEL% EQU 0 (
        echo.
        echo ========================================
        echo ✅ Debug APK بریالیتوب سره جوړ شو! 🎉
        echo ========================================
        echo.
        echo د APK ځای: android\app\build\outputs\apk\debug\app-debug.apk
        echo.
        
        set /p INSTALL_APK="ایا تاسو APK په device کې install کول غواړئ؟ (y/n): "
        
        if /i "!INSTALL_APK!"=="y" (
            where adb >nul 2>nul
            if !ERRORLEVEL! EQU 0 (
                echo.
                echo د APK install کول...
                adb install -r app\build\outputs\apk\debug\app-debug.apk
                
                if !ERRORLEVEL! EQU 0 (
                    echo.
                    echo ✅ APK بریالیتوب سره install شو! 🎉
                ) else (
                    echo.
                    echo ❌ APK install ناکام شو
                )
            ) else (
                echo.
                echo ❌ ADB نه موجود دی
                echo Android SDK Platform Tools نصب کړئ
            )
        )
    ) else (
        echo.
        echo ❌ Debug APK build ناکام شو
    )
    
    cd ..
)

echo.
echo.
echo ========================================
echo Setup Complete! 🎉
echo ========================================
echo.
echo د نورو معلوماتو لپاره دا فایلونه وګورئ:
echo   📄 ANDROID_SETUP_GUIDE.md - بشپړ setup لارښوود
echo   📄 PLAY_STORE_CHECKLIST.md - د Play Store checklist
echo.
echo د مرستې لپاره:
echo   📧 Email: ibrahimkhaksar.it@gmail.com
echo   📱 WhatsApp: +93 779 494 512
echo.
echo ✅ بریالیتوب مبارک! ❤️
echo.
pause
