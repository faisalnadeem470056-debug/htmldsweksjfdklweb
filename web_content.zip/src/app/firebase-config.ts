// Firebase Configuration for HealMate
// د Firebase Console څخه دا معلومات ترلاسه کړئ: https://console.firebase.google.com

export const firebaseConfig = {
  apiKey: "YOUR_FIREBASE_API_KEY",
  authDomain: "healmate-afghanistan.firebaseapp.com",
  projectId: "healmate-afghanistan",
  storageBucket: "healmate-afghanistan.appspot.com",
  messagingSenderId: "YOUR_MESSAGING_SENDER_ID",
  appId: "YOUR_APP_ID",
  measurementId: "YOUR_MEASUREMENT_ID"
};

// AdMob Configuration
export const adMobConfig = {
  // Android AdMob App ID
  androidAppId: "ca-app-pub-XXXXXXXXXXXXXXXX~XXXXXXXXXX",
  
  // AdMob Ad Unit IDs
  bannerAdId: "ca-app-pub-XXXXXXXXXXXXXXXX/XXXXXXXXXX",
  interstitialAdId: "ca-app-pub-XXXXXXXXXXXXXXXX/XXXXXXXXXX",
  rewardedAdId: "ca-app-pub-XXXXXXXXXXXXXXXX/XXXXXXXXXX",
  
  // Test Mode (د test کولو لپاره true کړئ)
  testMode: true,
  
  // Test Device IDs
  testDeviceIds: ["YOUR_TEST_DEVICE_ID"]
};

// Firebase Services Setup
export const firebaseServices = {
  // Authentication
  enableAuth: true,
  authProviders: ['email', 'google', 'phone'],
  
  // Firestore Database
  enableFirestore: true,
  
  // Cloud Storage
  enableStorage: true,
  
  // Cloud Messaging (FCM)
  enableMessaging: true,
  
  // Analytics
  enableAnalytics: true,
  
  // Performance Monitoring
  enablePerformance: true,
  
  // Remote Config
  enableRemoteConfig: true
};

// د Firebase initialize کولو helper function
export function getFirebaseConfig() {
  // Check if running in production
  const isProduction = window.location.hostname !== 'localhost';
  
  return {
    ...firebaseConfig,
    // د production او development لپاره جلا settings
    analyticsEnabled: isProduction,
    performanceMonitoringEnabled: isProduction
  };
}

// AdMob helper function
export function getAdMobAdId(type: 'banner' | 'interstitial' | 'rewarded'): string {
  // که test mode فعال وي، نو د Google test ad IDs استعمال کړئ
  if (adMobConfig.testMode) {
    const testIds = {
      banner: 'ca-app-pub-3940256099942544/6300978111',
      interstitial: 'ca-app-pub-3940256099942544/1033173712',
      rewarded: 'ca-app-pub-3940256099942544/5224354917'
    };
    return testIds[type];
  }
  
  // Real ad IDs
  switch(type) {
    case 'banner':
      return adMobConfig.bannerAdId;
    case 'interstitial':
      return adMobConfig.interstitialAdId;
    case 'rewarded':
      return adMobConfig.rewardedAdId;
    default:
      return adMobConfig.bannerAdId;
  }
}
