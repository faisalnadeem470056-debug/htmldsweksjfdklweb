// ═══════════════════════════════════════════════════════════════
// 👑 PREMIUM SUBSCRIPTION CONFIGURATION
// ═══════════════════════════════════════════════════════════════
//
// د Premium Plans، Pricing، او Features تنظیمات
//
// ═══════════════════════════════════════════════════════════════

// 💰 PRICING (د قیمتونه)
export const PremiumPricing = {
  monthly: {
    afn: 200,      // افغانۍ
    usd: 2.5,      // ډالر
    eur: 2.3,      // یورو
  },
  yearly: {
    afn: 2000,     // افغانۍ (400 افغانۍ سپما)
    usd: 25,       // ډالر
    eur: 23,       // یورو
  },
  lifetime: {
    afn: 5000,     // افغانۍ
    usd: 60,       // ډالر
    eur: 55,       // یورو
  },
};

// 📊 PLAN DETAILS
export const Plans = {
  free: {
    id: 'free',
    name: 'Free Plan',
    price: 0,
    duration: 'unlimited',
    features: [
      'basic_health_tips',
      'view_doctors_list',
      'basic_medicine_info',
      'hospitals_list',
      'first_aid_guide',
      'basic_health_guide',
    ],
  },
  monthly: {
    id: 'premium_monthly',
    name: 'Monthly Premium',
    price: PremiumPricing.monthly,
    duration: 30, // days
    features: 'all',
    googlePlayId: 'healmate_premium_monthly', // ⚠️ EDIT: د Google Play Billing SKU
    appleProductId: 'healmate_premium_monthly', // ⚠️ EDIT: د Apple Product ID
  },
  yearly: {
    id: 'premium_yearly',
    name: 'Yearly Premium',
    price: PremiumPricing.yearly,
    duration: 365, // days
    savings: '17%',
    features: 'all',
    googlePlayId: 'healmate_premium_yearly', // ⚠️ EDIT: د Google Play Billing SKU
    appleProductId: 'healmate_premium_yearly', // ⚠️ EDIT: د Apple Product ID
  },
  lifetime: {
    id: 'premium_lifetime',
    name: 'Lifetime Premium',
    price: PremiumPricing.lifetime,
    duration: 'unlimited',
    savings: '58%',
    features: 'all',
    googlePlayId: 'healmate_premium_lifetime', // ⚠️ EDIT: د Google Play Billing SKU
    appleProductId: 'healmate_premium_lifetime', // ⚠️ EDIT: د Apple Product ID
  },
};

// ✨ PREMIUM FEATURES
export const PremiumFeatures = {
  // Basic Features (Free)
  basic_health_tips: {
    id: 'basic_health_tips',
    name: 'Basic Health Tips',
    premium: false,
  },
  view_doctors_list: {
    id: 'view_doctors_list',
    name: 'View Doctors List',
    premium: false,
  },
  
  // Premium Features
  complete_doctor_profiles: {
    id: 'complete_doctor_profiles',
    name: 'Complete Doctor Profiles',
    icon: '🩺',
    premium: true,
  },
  complete_medicine_database: {
    id: 'complete_medicine_database',
    name: 'Complete Medicine Database (1500+)',
    icon: '💊',
    premium: true,
  },
  ai_health_chat: {
    id: 'ai_health_chat',
    name: 'AI Health Chat (Unlimited)',
    icon: '🤖',
    premium: true,
  },
  complete_health_library: {
    id: 'complete_health_library',
    name: 'Complete Health Library',
    icon: '📚',
    premium: true,
  },
  ad_free_experience: {
    id: 'ad_free_experience',
    name: 'Ad-Free Experience',
    icon: '⚡',
    premium: true,
  },
  personalized_health_plan: {
    id: 'personalized_health_plan',
    name: 'Personalized Health Plan',
    icon: '🎯',
    premium: true,
  },
  health_progress_tracking: {
    id: 'health_progress_tracking',
    name: 'Health Progress Tracking',
    icon: '📊',
    premium: true,
  },
  reminder_services: {
    id: 'reminder_services',
    name: 'Reminder Services',
    icon: '🔔',
    premium: true,
  },
  online_doctor_appointment: {
    id: 'online_doctor_appointment',
    name: 'Online Doctor Appointment',
    icon: '🏥',
    premium: true,
  },
  direct_chat_with_doctors: {
    id: 'direct_chat_with_doctors',
    name: 'Direct Chat with Doctors',
    icon: '💬',
    premium: true,
  },
  priority_support: {
    id: 'priority_support',
    name: 'Priority Support',
    icon: '📱',
    premium: true,
  },
  special_discounts: {
    id: 'special_discounts',
    name: 'Access to Special Discounts',
    icon: '🎁',
    premium: true,
  },
};

// ⚙️ AUTO RENEWAL SETTINGS
export const AutoRenewal = {
  enabled: true,
  
  // د renewal reminder settings
  reminderDays: [7, 3, 1], // د expiry څخه څومره ورځې مخکې reminder
  
  // د grace period (د payment fail په صورت کې)
  gracePeriodDays: 3,
  
  // د retry logic د payment fail په صورت کې
  retryAttempts: 3,
  retryIntervalHours: 24,
};

// 🔔 EXPIRY NOTIFICATIONS
export const ExpiryNotifications = {
  enabled: true,
  
  // د notification ښودلو وخت
  showAt: {
    days7: true,  // 7 ورځې مخکې
    days3: true,  // 3 ورځې مخکې
    day1: true,   // 1 ورځ مخکې
    expired: true, // د expiry په ورځ
  },
  
  // د notification message
  messages: {
    ps: {
      days7: 'ستاسو پریمیم subscription د 7 ورځو وروسته پای ته رسیږي',
      days3: 'ستاسو پریمیم subscription د 3 ورځو وروسته پای ته رسیږي',
      day1: 'ستاسو پریمیم subscription سبا پای ته رسیږي',
      expired: 'ستاسو پریمیم subscription پای ته ورسیدی. بیا نوي کړئ!',
    },
    fa: {
      days7: 'اشتراک پریمیم شما بعد از 7 روز منقضی می‌شود',
      days3: 'اشتراک پریمیم شما بعد از 3 روز منقضی می‌شود',
      day1: 'اشتراک پریمیم شما فردا منقضی می‌شود',
      expired: 'اشتراک پریمیم شما منقضی شد. تمدید کنید!',
    },
    en: {
      days7: 'Your Premium subscription expires in 7 days',
      days3: 'Your Premium subscription expires in 3 days',
      day1: 'Your Premium subscription expires tomorrow',
      expired: 'Your Premium subscription has expired. Renew now!',
    },
  },
};

// 🎨 UI SETTINGS
export const PremiumUI = {
  // د Premium badge colors
  badgeColors: {
    monthly: 'from-purple-600 to-pink-600',
    yearly: 'from-orange-500 to-red-600',
    lifetime: 'from-yellow-400 to-orange-600',
  },
  
  // د floating button settings
  floatingButton: {
    enabled: true,
    position: 'bottom-right', // 'bottom-right', 'bottom-left', 'top-right', 'top-left'
    showOnPages: 'all', // 'all' یا د specific pages array
    hideOnPages: ['premium'], // د پټولو pages
  },
  
  // د Premium banner settings
  banner: {
    enabled: true,
    showToFreeUsers: true,
    showToPremiumUsers: false,
    dismissible: true,
  },
};

// 📱 PLATFORM SETTINGS
export const PlatformSettings = {
  // Google Play Billing
  googlePlay: {
    enabled: true,
    publicKey: 'YOUR_GOOGLE_PLAY_LICENSE_KEY', // ⚠️ EDIT: د Google Play Console څخه
    
    // SKU IDs (د Google Play Console کې جوړ کړئ)
    skus: {
      monthly: 'healmate_premium_monthly',
      yearly: 'healmate_premium_yearly',
      lifetime: 'healmate_premium_lifetime',
    },
  },
  
  // Apple In-App Purchase
  apple: {
    enabled: true,
    sharedSecret: 'YOUR_APPLE_SHARED_SECRET', // ⚠️ EDIT: د App Store Connect څخه
    
    // Product IDs (د App Store Connect کې جوړ کړئ)
    productIds: {
      monthly: 'healmate_premium_monthly',
      yearly: 'healmate_premium_yearly',
      lifetime: 'healmate_premium_lifetime',
    },
  },
  
  // Web/PWA (د testing لپاره)
  web: {
    enabled: true,
    testMode: true, // د production کې false کړئ
  },
};

// 💳 PAYMENT METHODS
export const PaymentMethods = {
  googlePay: true,
  applePay: true,
  creditCard: true,
  debitCard: true,
  mobileBanking: true, // د افغانستان mobile banking
};

// 🔐 SECURITY
export const SecuritySettings = {
  // د subscription verification
  verifyPurchase: true,
  
  // د server-side validation (که server وي)
  serverValidation: false, // ⚠️ EDIT: که backend وي true کړئ
  serverUrl: '', // ⚠️ EDIT: د backend URL
  
  // د local encryption
  encryptLocalData: true,
};

// ═══════════════════════════════════════════════════════════════
// 🚀 QUICK SETUP CHECKLIST
// ═══════════════════════════════════════════════════════════════
/*

✅ ANDROID (Google Play Billing):

1. Google Play Console ته لاړ شئ
2. ستاسو App select کړئ
3. Monetize → Products → In-app products
4. دا Products جوړ کړئ:
   - healmate_premium_monthly (Auto-renewing subscription)
   - healmate_premium_yearly (Auto-renewing subscription)
   - healmate_premium_lifetime (Managed product)
5. د هر product لپاره:
   - Product ID واچوئ
   - Price set کړئ
   - Description اضافه کړئ
6. License Key copy کړئ:
   - Monetize → Monetization setup → Licensing
7. په config کې update کړئ:
   - PlatformSettings.googlePlay.publicKey
   - PlatformSettings.googlePlay.skus

✅ iOS (Apple In-App Purchase):

1. App Store Connect ته لاړ شئ
2. ستاسو App select کړئ
3. Features → In-App Purchases
4. دا Products جوړ کړئ:
   - healmate_premium_monthly (Auto-Renewable Subscription)
   - healmate_premium_yearly (Auto-Renewable Subscription)  
   - healmate_premium_lifetime (Non-Consumable)
5. د هر product لپاره:
   - Product ID واچوئ
   - Price set کړئ (په ټولو countries کې)
   - Localization اضافه کړئ
6. Subscription Groups جوړ کړئ (د monthly او yearly لپاره)
7. Shared Secret جوړ کړئ:
   - App Store Connect → Users and Access → Shared Secret
8. په config کې update کړئ:
   - PlatformSettings.apple.sharedSecret
   - PlatformSettings.apple.productIds

✅ WEB/PWA (Testing):

1. PlatformSettings.web.testMode = true
2. Test کړئ په browser کې
3. د production لپاره backend integration ته اړتیا ده

DONE! 🎉

*/

// ═══════════════════════════════════════════════════════════════
// 📝 NOTES
// ═══════════════════════════════════════════════════════════════
/*

⚠️ مهم نکتې:

1. Google Play Billing:
   - د Auto-renewable subscriptions استعمال کړئ
   - Grace period 3 ورځې دی
   - د testing لپاره Test accounts جوړ کړئ

2. Apple In-App Purchase:
   - د Subscription Groups استعمال کړئ
   - Introductory offers enable کړئ (لکه 7 days free trial)
   - د testing لپاره Sandbox accounts جوړ کړئ

3. Auto Renewal:
   - په automatic ډول renew کیږي
   - د payment fail په صورت کې grace period
   - د reminder notifications ښودل کیږي

4. Security:
   - د receipt verification ضروری دی
   - Server-side validation وړاندیز کیږي
   - Local data encrypted ساتل کیږي

5. Testing:
   - Google Play: Internal testing track
   - Apple: TestFlight
   - Web: Local testing

*/

export default {
  PremiumPricing,
  Plans,
  PremiumFeatures,
  AutoRenewal,
  ExpiryNotifications,
  PremiumUI,
  PlatformSettings,
  PaymentMethods,
  SecuritySettings,
};
