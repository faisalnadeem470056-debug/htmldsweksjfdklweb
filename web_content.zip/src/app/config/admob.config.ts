// ═══════════════════════════════════════════════════════════════
// 🎯 ADMOB CONFIGURATION FILE
// ═══════════════════════════════════════════════════════════════
// 
// ⚠️ IMPORTANT - د اصلي IDs اضافه کولو لپاره:
// 1. Google AdMob Console ته لاړ شئ (https://apps.admob.google.com)
// 2. ستاسو App جوړ کړئ او Ad Units جوړ کړئ
// 3. لاندې TEST IDs د خپلو اصلي IDs سره بدل کړئ
// 4. isDevelopment = false کړئ د production لپاره
//
// ═══════════════════════════════════════════════════════════════

// 🔧 DEVELOPMENT MODE
// د test کولو لپاره: true
// د production لپاره: false
export const isDevelopment = true;  // ⚠️ EDIT HERE: د production لپاره false کړئ

// ═══════════════════════════════════════════════════════════════
// 📱 APP ID (د Google AdMob څخه)
// ═══════════════════════════════════════════════════════════════

// Test App ID (د test کولو لپاره)
const TEST_APP_ID = 'ca-app-pub-3940256099942544~3347511713';

// ⚠️ EDIT HERE: ستاسو اصلي App ID دلته واچوئ
const PRODUCTION_APP_ID = 'ca-app-pub-XXXXXXXXXXXXXXXX~XXXXXXXXXX';

export const ADMOB_APP_ID = isDevelopment ? TEST_APP_ID : PRODUCTION_APP_ID;

// ═══════════════════════════════════════════════════════════════
// 📊 BANNER AD IDs
// ═══════════════════════════════════════════════════════════════

// Test Banner Ad ID
const TEST_BANNER_AD_ID = 'ca-app-pub-3940256099942544/6300978111';

// ⚠️ EDIT HERE: ستاسو اصلي Banner Ad ID دلته واچوئ
const PRODUCTION_BANNER_AD_ID = 'ca-app-pub-XXXXXXXXXXXXXXXX/XXXXXXXXXX';

export const BANNER_AD_ID = isDevelopment ? TEST_BANNER_AD_ID : PRODUCTION_BANNER_AD_ID;

// ═══════════════════════════════════════════════════════════════
// 📺 INTERSTITIAL AD IDs (Full Screen Ads)
// ═══════════════════════════════════════════════════════════════

// Test Interstitial Ad ID
const TEST_INTERSTITIAL_AD_ID = 'ca-app-pub-3940256099942544/1033173712';

// ⚠️ EDIT HERE: ستاسو اصلي Interstitial Ad ID دلته واچوئ
const PRODUCTION_INTERSTITIAL_AD_ID = 'ca-app-pub-XXXXXXXXXXXXXXXX/XXXXXXXXXX';

export const INTERSTITIAL_AD_ID = isDevelopment ? TEST_INTERSTITIAL_AD_ID : PRODUCTION_INTERSTITIAL_AD_ID;

// ═══════════════════════════════════════════════════════════════
// 🎁 REWARDED AD IDs (د انعام سره Ads)
// ═══════════════════════════════════════════════════════════════

// Test Rewarded Ad ID
const TEST_REWARDED_AD_ID = 'ca-app-pub-3940256099942544/5224354917';

// ⚠️ EDIT HERE: ستاسو اصلي Rewarded Ad ID دلته واچوئ
const PRODUCTION_REWARDED_AD_ID = 'ca-app-pub-XXXXXXXXXXXXXXXX/XXXXXXXXXX';

export const REWARDED_AD_ID = isDevelopment ? TEST_REWARDED_AD_ID : PRODUCTION_REWARDED_AD_ID;

// ═══════════════════════════════════════════════════════════════
// 🎬 REWARDED INTERSTITIAL AD IDs
// ═══════════════════════════════════════════════════════════════

// Test Rewarded Interstitial Ad ID
const TEST_REWARDED_INTERSTITIAL_AD_ID = 'ca-app-pub-3940256099942544/5354046379';

// ⚠️ EDIT HERE: ستاسو اصلي Rewarded Interstitial Ad ID دلته واچوئ
const PRODUCTION_REWARDED_INTERSTITIAL_AD_ID = 'ca-app-pub-XXXXXXXXXXXXXXXX/XXXXXXXXXX';

export const REWARDED_INTERSTITIAL_AD_ID = isDevelopment ? TEST_REWARDED_INTERSTITIAL_AD_ID : PRODUCTION_REWARDED_INTERSTITIAL_AD_ID;

// ═══════════════════════════════════════════════════════════════
// 📋 NATIVE AD IDs (د content کې integrate شوي Ads)
// ═══════════════════════════════════════════════════════════════

// Test Native Ad ID
const TEST_NATIVE_AD_ID = 'ca-app-pub-3940256099942544/2247696110';

// ⚠️ EDIT HERE: ستاسو اصلي Native Ad ID دلته واچوئ
const PRODUCTION_NATIVE_AD_ID = 'ca-app-pub-XXXXXXXXXXXXXXXX/XXXXXXXXXX';

export const NATIVE_AD_ID = isDevelopment ? TEST_NATIVE_AD_ID : PRODUCTION_NATIVE_AD_ID;

// ═══════════════════════════════════════════════════════════════
// ⚙️ AD SETTINGS
// ═══════════════════════════════════════════════════════════════

export const AdSettings = {
  // د Banner Ad settings
  banner: {
    enabled: true,
    refreshInterval: 60000, // 60 seconds (60000ms)
    position: 'bottom' as 'top' | 'bottom',
  },

  // د Interstitial Ad settings
  interstitial: {
    enabled: true,
    showAfterActions: 5, // د 5 actions وروسته ښکاره شي
    cooldownTime: 120000, // 2 minutes (120000ms) - د دوه ads ترمنځ وقفه
  },

  // د Rewarded Ad settings
  rewarded: {
    enabled: true,
    rewardAmount: 10, // د reward مقدار (لکه coins, points)
  },

  // د Native Ad settings
  native: {
    enabled: true,
    showInFeed: true, // په feed کې ښکاره شي که نه
    feedInterval: 5, // د هر 5 posts وروسته یو native ad
  },
};

// ═══════════════════════════════════════════════════════════════
// 🎨 AD PLACEMENT LOCATIONS
// ═══════════════════════════════════════════════════════════════

export const AdPlacements = {
  home: {
    banner: true,
    interstitial: false,
    native: true,
  },
  doctors: {
    banner: true,
    interstitial: true,
    native: true,
  },
  hospitals: {
    banner: true,
    interstitial: true,
    native: true,
  },
  medicine: {
    banner: true,
    interstitial: true,
    native: true,
  },
  community: {
    banner: true,
    interstitial: false,
    native: true,
  },
  profile: {
    banner: true,
    interstitial: false,
    native: false,
  },
};

// ═══════════════════════════════════════════════════════════════
// 📊 TRACKING & ANALYTICS
// ═══════════════════════════════════════════════════════════════

export const AdTracking = {
  logImpressions: true,
  logClicks: true,
  logRevenue: true,
  logErrors: true,
};

// ═══════════════════════════════════════════════════════════════
// 🚀 QUICK SETUP CHECKLIST
// ═══════════════════════════════════════════════════════════════
/*

✅ STEP 1: Google AdMob Account جوړ کړئ
  └─ https://admob.google.com

✅ STEP 2: نوی App اضافه کړئ
  └─ App Name: HealMate
  └─ Platform: Android (یا iOS که Android هم وي)

✅ STEP 3: Ad Units جوړ کړئ:
  ├─ Banner Ad Unit
  ├─ Interstitial Ad Unit
  ├─ Rewarded Ad Unit
  ├─ Rewarded Interstitial Ad Unit
  └─ Native Advanced Ad Unit

✅ STEP 4: IDs Copy کړئ او لورې واچوئ:
  ├─ App ID → PRODUCTION_APP_ID
  ├─ Banner ID → PRODUCTION_BANNER_AD_ID
  ├─ Interstitial ID → PRODUCTION_INTERSTITIAL_AD_ID
  ├─ Rewarded ID → PRODUCTION_REWARDED_AD_ID
  ├─ Rewarded Interstitial ID → PRODUCTION_REWARDED_INTERSTITIAL_AD_ID
  └─ Native ID → PRODUCTION_NATIVE_AD_ID

✅ STEP 5: isDevelopment = false کړئ

✅ STEP 6: App rebuild او test کړئ

DONE! 🎉

*/

// ═══════════════════════════════════════════════════════════════
// 📝 NOTES
// ═══════════════════════════════════════════════════════════════
/*

⚠️ مهم نکتې:

1. TEST IDs یوازې د test لپاره دي
   - ستاسو AdMob account suspend کیږي که production کې test IDs استعمال کړئ

2. د Production IDs د AdMob Console څخه ترلاسه کړئ
   - هر Ad Unit لپاره یو unique ID شته

3. isDevelopment flag:
   - true = Test IDs استعمالوي (د development لپاره)
   - false = Production IDs استعمالوي (د Play Store لپاره)

4. Ad Refresh Intervals:
   - Banner: هر 60 ثانیو کې refresh کیږي
   - Interstitial: د 5 actions وروسته ښکاره کیږي
   - د دوه Interstitial ads ترمنځ 2 دقیقې وقفه

5. Privacy:
   - GDPR/COPPA compliance ته پام وکړئ
   - د user consent ترلاسه کړئ که په EU کې استعمالیږي

6. Revenue:
   - د eCPM لوړولو لپاره مختلف ad formats استعمال کړئ
   - د rewarded ads استعمال د engagement لوړولو لپاره

*/

// ═══════════════════════════════════════════════════════════════
// 🔗 USEFUL LINKS
// ═══════════════════════════════════════════════════════════════
/*

📚 Documentation:
  - AdMob: https://admob.google.com/home/
  - Test IDs: https://developers.google.com/admob/android/test-ads

🛠️ Tools:
  - AdMob Console: https://apps.admob.google.com
  - Firebase Console: https://console.firebase.google.com

💰 Optimization:
  - Mediation: https://support.google.com/admob/answer/3063564
  - Best Practices: https://support.google.com/admob/answer/6128543

*/
