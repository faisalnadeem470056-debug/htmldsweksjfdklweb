/**
 * د Admin Panel Configuration
 * د HealMate اپلیکیشن د Owner او Admin تنظیمات
 * 
 * ⚠️ یادونه: یوازې OWNER_EMAIL د Admin Panel ته لاسرسی لري!
 * په production کې دا email د اصلي owner سره بدل کړئ.
 */

// د Owner Email - یوازې دا email د Admin Panel ته بشپړ لاسرسی لري
export const OWNER_EMAIL = "ibrahimkhaksar.it@gmail.com";

// د Owner معلومات
export const OWNER_INFO = {
  email: OWNER_EMAIL,
  name: "Ibrahim Khaksar",
  role: "owner" as const,
  permissions: [
    "full_access",
    "manage_admins",
    "manage_users",
    "manage_doctors",
    "manage_medicines",
    "manage_admob",
    "view_analytics",
    "manage_content",
    "manage_settings"
  ]
};

// د Admin Roles او Permissions
export const ADMIN_ROLES = {
  OWNER: "owner",
  SUPER_ADMIN: "super_admin",
  ADMIN: "admin",
  MODERATOR: "moderator"
} as const;

// د Admin Permissions
export const ADMIN_PERMISSIONS = {
  FULL_ACCESS: "full_access",
  MANAGE_ADMINS: "manage_admins",
  MANAGE_USERS: "manage_users",
  MANAGE_DOCTORS: "manage_doctors",
  MANAGE_MEDICINES: "manage_medicines",
  MANAGE_ADMOB: "manage_admob",
  VIEW_ANALYTICS: "view_analytics",
  MANAGE_CONTENT: "manage_content",
  MANAGE_SETTINGS: "manage_settings"
} as const;

/**
 * د Email validation function
 * چیک کوي چې آیا یو email د owner email دی که نه
 */
export function isOwnerEmail(email: string | null | undefined): boolean {
  if (!email) return false;
  return email.toLowerCase().trim() === OWNER_EMAIL.toLowerCase();
}

/**
 * د Admin role چیک کول
 */
export function hasAdminAccess(email: string | null | undefined): boolean {
  return isOwnerEmail(email);
}

export type AdminRole = typeof ADMIN_ROLES[keyof typeof ADMIN_ROLES];
export type AdminPermission = typeof ADMIN_PERMISSIONS[keyof typeof ADMIN_PERMISSIONS];
