// Firebase Configuration for HealMate
// د HealMate لپاره د Firebase ترتیبات

import { initializeApp } from 'firebase/app';
import { getAuth } from 'firebase/auth';
import { getFirestore } from 'firebase/firestore';
import { getStorage } from 'firebase/storage';
import { getAnalytics } from 'firebase/analytics';

// Firebase Configuration Object
// د Firebase ترتیباتي شیء
const firebaseConfig = {
  apiKey: "AIzaSyB2OMz3gaEmXpYwnmPbBZRpFd2hBLDABNw",
  authDomain: "healmate-96c0b.firebaseapp.com",
  projectId: "healmate-96c0b",
  storageBucket: "healmate-96c0b.firebasestorage.app",
  messagingSenderId: "294359966020",
  appId: "1:294359966020:android:fc55a4dd293465cb3fb711",
  // measurementId is required for Analytics — add your web app's measurementId here
  measurementId: ""
};

// د Firebase نښې چې ایا configured دی که نه
// Check if Firebase is properly configured
export const isFirebaseConfigured = (): boolean => {
  return firebaseConfig.apiKey !== "" &&
         firebaseConfig.projectId !== "" &&
         firebaseConfig.apiKey.length > 0 &&
         firebaseConfig.projectId.length > 0;
};

// Initialize Firebase
// د Firebase پیل کول
let app;
let auth;
let db;
let storage;
let analytics;

try {
  if (isFirebaseConfigured()) {
    app = initializeApp(firebaseConfig);
    auth = getAuth(app);
    db = getFirestore(app);
    storage = getStorage(app);
    
    // Analytics requires a web measurementId — skip if not provided or fetch fails
    if (typeof window !== 'undefined' && firebaseConfig.measurementId) {
      try {
        analytics = getAnalytics(app);
      } catch (error) {
        console.warn('⚠️ Firebase Analytics initialization skipped');
      }
    }
    
    console.log('✅ Firebase successfully initialized | Firebase په بریالیتوب سره پیل شو');
  } else {
    console.warn('⚠️ Firebase not configured. Using LocalStorage mode. | Firebase configured نه دی. د LocalStorage حالت کارول کیږي.');
  }
} catch (error) {
  console.error('❌ Firebase initialization failed | د Firebase پیل کول ناکام شو:', error);
}

// Export Firebase services
// د Firebase خدمتونه export کول
export { app, auth, db, storage, analytics };

// Helper functions
// مرسته کوونکي فعالیتونه

/**
 * د Firebase حالت ګورئ
 * Check Firebase connection status
 */
export const checkFirebaseStatus = async (): Promise<{
  configured: boolean;
  connected: boolean;
  error?: string;
}> => {
  if (!isFirebaseConfigured()) {
    return {
      configured: false,
      connected: false,
      error: 'Firebase configuration not found'
    };
  }

  try {
    // Try to access Firestore to check connection
    if (db) {
      return {
        configured: true,
        connected: true
      };
    }
    return {
      configured: true,
      connected: false,
      error: 'Firebase initialized but not connected'
    };
  } catch (error: any) {
    return {
      configured: true,
      connected: false,
      error: error.message
    };
  }
};

/**
 * د Firebase او LocalStorage دواړو ملاتړ
 * Support both Firebase and LocalStorage
 */
export const getStorageMode = (): 'firebase' | 'localstorage' => {
  return isFirebaseConfigured() ? 'firebase' : 'localstorage';
};
