/**
 * HealMate - AdMob Configuration
 * د Google AdMob اعلاناتو تنظیمات
 * 
 * په ټیسټ حالت کې: د Google test IDs استعمال کړئ
 * په Production حالت کې: خپل اصلي AdMob IDs واچوئ
 */

export interface AdMobConfig {
  // د Android لپاره
  androidAppId: string;
  androidBannerId: string;
  androidInterstitialId: string;
  androidRewardedId: string;
  
  // د iOS لپاره
  iosAppId: string;
  iosBannerId: string;
  iosInterstitialId: string;
  iosRewardedId: string;
  
  // عمومي تنظیمات
  testMode: boolean;
  showAds: boolean;
  maxAdsPerDay: number; // په 24 ساعتونو کې د ads حد اکثر شمیر
}

/**
 * د Google Test IDs
 * دا د ټیسټ لپاره دي - په production کې مه کاروئ!
 */
export const GOOGLE_TEST_IDS = {
  android: {
    appId: "ca-app-pub-3940256099942544~3347511713",
    banner: "ca-app-pub-3940256099942544/6300978111",
    interstitial: "ca-app-pub-3940256099942544/1033173712",
    rewarded: "ca-app-pub-3940256099942544/5224354917",
  },
  ios: {
    appId: "ca-app-pub-3940256099942544~1458002511",
    banner: "ca-app-pub-3940256099942544/2934735716",
    interstitial: "ca-app-pub-3940256099942544/4411468910",
    rewarded: "ca-app-pub-3940256099942544/1712485313",
  }
};

/**
 * د Default Configuration
 * په ټیسټ حالت کې د Google test IDs سره
 */
export const DEFAULT_ADMOB_CONFIG: AdMobConfig = {
  // Android IDs
  androidAppId: GOOGLE_TEST_IDS.android.appId,
  androidBannerId: GOOGLE_TEST_IDS.android.banner,
  androidInterstitialId: GOOGLE_TEST_IDS.android.interstitial,
  androidRewardedId: GOOGLE_TEST_IDS.android.rewarded,
  
  // iOS IDs
  iosAppId: GOOGLE_TEST_IDS.ios.appId,
  iosBannerId: GOOGLE_TEST_IDS.ios.banner,
  iosInterstitialId: GOOGLE_TEST_IDS.ios.interstitial,
  iosRewardedId: GOOGLE_TEST_IDS.ios.rewarded,
  
  // Settings
  testMode: true,
  showAds: true,
  maxAdsPerDay: 3, // په 24 ساعتونو کې 3 ads (default)
};

/**
 * د AdMob Configuration وګورئ او Save کړئ
 */
class AdMobConfigManager {
  private storageKey = 'healmate_admob_config';
  
  /**
   * د Configuration ترلاسه کړئ
   */
  getConfig(): AdMobConfig {
    try {
      const stored = localStorage.getItem(this.storageKey);
      if (stored) {
        return JSON.parse(stored);
      }
    } catch (error) {
      console.error('Error loading AdMob config:', error);
    }
    return DEFAULT_ADMOB_CONFIG;
  }
  
  /**
   * د Configuration Save کړئ
   */
  saveConfig(config: AdMobConfig): void {
    try {
      localStorage.setItem(this.storageKey, JSON.stringify(config));
    } catch (error) {
      console.error('Error saving AdMob config:', error);
    }
  }
  
  /**
   * د Configuration Reset کړئ
   */
  resetConfig(): void {
    try {
      localStorage.removeItem(this.storageKey);
    } catch (error) {
      console.error('Error resetting AdMob config:', error);
    }
  }
  
  /**
   * د ټیسټ IDs بیرته واچوئ
   */
  loadTestIds(): void {
    this.saveConfig(DEFAULT_ADMOB_CONFIG);
  }
  
  /**
   * تصدیق کړئ چې IDs valid دي
   */
  validateConfig(config: AdMobConfig): { valid: boolean; errors: string[] } {
    const errors: string[] = [];
    
    // Check if IDs start with ca-app-pub-
    const idPattern = /^ca-app-pub-\d+[~/]\d+$/;
    
    if (!idPattern.test(config.androidAppId)) {
      errors.push('Android App ID نا معتبر دی');
    }
    if (!idPattern.test(config.androidBannerId)) {
      errors.push('Android Banner ID نا معتبر دی');
    }
    if (!idPattern.test(config.iosAppId)) {
      errors.push('iOS App ID نا معتبر دی');
    }
    if (!idPattern.test(config.iosBannerId)) {
      errors.push('iOS Banner ID نا معتبر دی');
    }
    
    return {
      valid: errors.length === 0,
      errors
    };
  }
}

export const admobConfigManager = new AdMobConfigManager();

/**
 * د اوسنۍ configuration ترلاسه کړئ
 */
export function getAdMobConfig(): AdMobConfig {
  return admobConfigManager.getConfig();
}

/**
 * د Platform مطابق د Ad Unit ID ترلاسه کړئ
 */
export function getAdUnitId(platform: 'android' | 'ios', adType: 'banner' | 'interstitial' | 'rewarded'): string {
  const config = getAdMobConfig();
  
  if (platform === 'android') {
    switch (adType) {
      case 'banner':
        return config.androidBannerId;
      case 'interstitial':
        return config.androidInterstitialId;
      case 'rewarded':
        return config.androidRewardedId;
    }
  } else {
    switch (adType) {
      case 'banner':
        return config.iosBannerId;
      case 'interstitial':
        return config.iosInterstitialId;
      case 'rewarded':
        return config.iosRewardedId;
    }
  }
}
