# 🌐 HealMate Multilingual Implementation Guide
## د HealMate د ژبو بشپړ لارښود

---

## 📋 Overview | لنډیز

د HealMate اپلیکیشن باید په **درې ژبو** بشپړ کار وکړي:
- **English** (انګلیسي)
- **Dari** (دري)
- **Pashto** (پښتو)

---

## ✅ د اوسمهال حالت | Current Status

### د Multilingual Components لیست:

```tsx
✅ FULLY MULTILINGUAL (بشپړ multilingual):
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

1.  ✅ DoctorsList.tsx
2.  ✅ MobileNav.tsx
3.  ✅ Settings.tsx
4.  ✅ LanguageSwitcher.tsx
5.  ✅ LanguageDemo.tsx
6.  ✅ HealthAnalytics.tsx
7.  ✅ DoctorReviews.tsx
8.  ✅ AppointmentManagement.tsx
9.  ✅ NotificationsCenter.tsx
10. ✅ UserProfile.tsx
11. ✅ AdminPanel.tsx
12. ✅ LoginForm.tsx
13. ✅ SignUpForm.tsx
14. ✅ ForgotPasswordForm.tsx
15. ✅ AddDoctorDialog.tsx
16. ✅ AboutUs.tsx (نوی updated)
17. ✅ ContactUs.tsx (نوی updated)
18. ✅ HomeScreen.tsx (partial)
19. ✅ AuthDebugHelper.tsx (English only - د development لپاره)

⚠️ NEEDS MULTILINGUAL SUPPORT (اړتیا لري):
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

20. ⚠️ AIHealthAssistant.tsx
21. ⚠️ AdMobStatusIndicator.tsx
22. ⚠️ AdMobTestPage.tsx
23. ⚠️ Categories.tsx
24. ⚠️ CategoriesSidebar.tsx
25. ⚠️ CommunityFeed.tsx (partial)
26. ⚠️ DoctorChat.tsx
27. ⚠️ DoctorDetailModal.tsx
28. ⚠️ EPharmacy.tsx
29. ⚠️ EmergencySection.tsx
30. ⚠️ FamilyProfiles.tsx
31. ⚠️ HealthDashboard.tsx
32. ⚠️ HealthInsurance.tsx
33. ⚠️ HealthTipModal.tsx
34. ⚠️ HealthTips.tsx
35. ⚠️ Hero.tsx
36. ⚠️ LabTestBooking.tsx
37. ⚠️ MedicineDetailModal.tsx
38. ⚠️ MedicineReminder.tsx
39. ⚠️ MedicinesList.tsx
40. ⚠️ MobileHeader.tsx
41. ⚠️ MyPosts.tsx (partial)
42. ⚠️ PrivacyPolicy.tsx
43. ⚠️ ProfileSidebar.tsx
44. ⚠️ ReportPostDialog.tsx
45. ⚠️ Services.tsx
46. ⚠️ SymptomsTracker.tsx
47. ⚠️ TermsConditions.tsx
48. ⚠️ VideoConsultation.tsx
49. ⚠️ BlogSection.tsx
```

---

## 🛠️ د Multilingual Implementation لارښود

### Step 1: Import useLanguage Hook

```tsx
import { useLanguage } from "../contexts/LanguageContext";
```

### Step 2: د Component دننه استعمال

```tsx
export function YourComponent() {
  const { language } = useLanguage();
  
  // باقي code...
}
```

### Step 3: د Translations Object جوړول

```tsx
const translations = {
  en: {
    title: "Your Title",
    subtitle: "Your Subtitle",
    button: "Click Me",
    // نور English text...
  },
  dari: {
    title: "عنوان شما",
    subtitle: "زیرعنوان شما",
    button: "کلیک کنید",
    // نور Dari text...
  },
  pashto: {
    title: "ستاسو سرلیک",
    subtitle: "ستاسو فرعي سرلیک",
    button: "کلیک وکړئ",
    // نور Pashto text...
  }
};
```

### Step 4: د Translation استعمال

```tsx
const t = translations[language as keyof typeof translations] || translations.en;

return (
  <div>
    <h1>{t.title}</h1>
    <p>{t.subtitle}</p>
    <button>{t.button}</button>
  </div>
);
```

---

## 📖 بشپړ مثال | Complete Example

### د AboutUs.tsx د مثال په توګه:

```tsx
import { useLanguage } from "../contexts/LanguageContext";

export function AboutUs() {
  const { language } = useLanguage();

  const translations = {
    en: {
      title: "About Us",
      subtitle: "Learn more about HealMate",
      welcomeTitle: "Welcome to HealMate",
      introText: "HealMate is Afghanistan's leading digital healthcare platform...",
      missionTitle: "Our Mission",
      missionText: "To revolutionize healthcare delivery in Afghanistan...",
      visionTitle: "Our Vision",
      visionText: "A healthier Afghanistan where every individual...",
      valuesTitle: "Our Values",
      values: [
        { title: "Care First", description: "We prioritize patient care..." },
        { title: "Trust & Privacy", description: "Your health information..." },
      ],
      stats: [
        { number: "500+", label: "Active Users" },
        { number: "50+", label: "Doctors" },
      ]
    },
    dari: {
      title: "درباره ما",
      subtitle: "بیشتر در مورد HealMate بدانید",
      welcomeTitle: "به HealMate خوش آمدید",
      introText: "HealMate پلتفرم پیشرو مراقبت های صحی...",
      missionTitle: "مأموریت ما",
      missionText: "انقلاب در ارائه خدمات صحی...",
      visionTitle: "چشم انداز ما",
      visionText: "یک افغانستان سالم تر...",
      valuesTitle: "ارزش های ما",
      values: [
        { title: "مراقبت اول", description: "ما مراقبت و رفاه..." },
        { title: "اعتماد و حریم خصوصی", description: "معلومات صحی شما..." },
      ],
      stats: [
        { number: "۵۰۰+", label: "کاربران فعال" },
        { number: "۵۰+", label: "داکتران" },
      ]
    },
    pashto: {
      title: "زموږ په اړه",
      subtitle: "د HealMate په اړه نور معلومات",
      welcomeTitle: "HealMate ته ښه راغلاست",
      introText: "HealMate د افغانستان مخکښ ډیجیټل روغتیا...",
      missionTitle: "زموږ ماموریت",
      missionText: "د ټیکنالوژۍ له لارې د لاسرسي وړ...",
      visionTitle: "زموږ لید",
      visionText: "یو روغ افغانستان چیرې چې...",
      valuesTitle: "زموږ ارزښتونه",
      values: [
        { title: "لومړی پاملرنه", description: "موږ د ناروغ پاملرنه..." },
        { title: "باور او محرمیت", description: "ستاسو د روغتیا معلومات..." },
      ],
      stats: [
        { number: "۵۰۰+", label: "فعال کاروونکي" },
        { number: "۵۰+", label: "ډاکټران" },
      ]
    }
  };

  const t = translations[language as keyof typeof translations] || translations.en;

  return (
    <section>
      <h2>{t.title}</h2>
      <p>{t.subtitle}</p>
      
      <h3>{t.welcomeTitle}</h3>
      <p>{t.introText}</p>
      
      {/* Mission */}
      <div>
        <h4>{t.missionTitle}</h4>
        <p>{t.missionText}</p>
      </div>
      
      {/* Vision */}
      <div>
        <h4>{t.visionTitle}</h4>
        <p>{t.visionText}</p>
      </div>
      
      {/* Values */}
      <h3>{t.valuesTitle}</h3>
      {t.values.map((value, index) => (
        <div key={index}>
          <h5>{value.title}</h5>
          <p>{value.description}</p>
        </div>
      ))}
      
      {/* Stats */}
      {t.stats.map((stat, index) => (
        <div key={index}>
          <p>{stat.number}</p>
          <p>{stat.label}</p>
        </div>
      ))}
    </section>
  );
}
```

---

## 🎯 د مهم نکاتو لیست

### 1. د شمیرو لیکل:

```tsx
English: 500+, 1000+, 24/7
Dari:    ۵۰۰+, ۱۰۰۰+, ۲۴/۷
Pashto:  ۵۰۰+, ۱۰۰۰+, ۲۴/۷
```

### 2. د Arrays استعمال:

```tsx
// کله چې arrays لرئ (لکه lists, options, items):
values: [
  { title: "...", description: "..." },
  { title: "...", description: "..." },
]

// په component کې:
{t.values.map((value, index) => (
  <div key={index}>
    <h5>{value.title}</h5>
    <p>{value.description}</p>
  </div>
))}
```

### 3. د Form Fields:

```tsx
{
  nameLabel: "Name",
  namePlaceholder: "Enter your name",
  emailLabel: "Email",
  emailPlaceholder: "your@email.com",
  submitButton: "Submit"
}
```

### 4. د Error Messages:

```tsx
{
  requiredError: "This field is required",
  invalidEmail: "Invalid email address",
  passwordMismatch: "Passwords do not match",
  successMessage: "Operation completed successfully"
}
```

### 5. د Toast/Notifications:

```tsx
toast.success(t.successMessage);
toast.error(t.errorMessage);
toast.info(t.infoMessage);
```

---

## 📱 د Components Priority د Multilingual کولو لپاره

### HIGH PRIORITY (لوړ اولویت):

```
1. HomeScreen.tsx - د Home پاڼه (اوس partial دی)
2. MedicinesList.tsx - د درملو لیست
3. Categories.tsx - د کټګوریو
4. EmergencySection.tsx - بیړنی برخه
5. HealthTips.tsx - د روغتیا لارښوونې
```

### MEDIUM PRIORITY (منځنی اولویت):

```
6. DoctorChat.tsx - د ډاکټر چټ
7. VideoConsultation.tsx - ویډیو مشوره
8. LabTestBooking.tsx - د لابراتوار ټیسټ
9. FamilyProfiles.tsx - د کورنۍ پروفایلونه
10. MedicineReminder.tsx - د درملو یادونه
```

### LOW PRIORITY (ټیټ اولویت):

```
11. PrivacyPolicy.tsx
12. TermsConditions.tsx
13. BlogSection.tsx
14. AdMobTestPage.tsx (د testing لپاره)
```

---

## 🔄 د ژبې بدلون Testing

### د ژبې بدلون test کول:

1. LanguageSwitcher component استعمال کړئ
2. هره ژبه select کړئ
3. وګورئ چې ټول text بدلیږي که نه
4. د forms، buttons، labels، errors چیک کړئ

### د Testing Checklist:

```
✅ Titles او headings
✅ Paragraphs او descriptions
✅ Button labels
✅ Form labels او placeholders
✅ Error messages
✅ Success messages
✅ Navigation items
✅ Tooltips
✅ Modal titles او content
✅ Table headers او data
```

---

## 💡 د Translation Tips

### English → Dari:

```
Common phrases:
- "Welcome" → "خوش آمدید"
- "Please" → "لطفاً"
- "Thank you" → "تشکر"
- "Submit" → "ارسال"
- "Cancel" → "لغو"
- "Save" → "ذخیره"
- "Delete" → "حذف"
- "Edit" → "ویرایش"
```

### English → Pashto:

```
Common phrases:
- "Welcome" → "ښه راغلاست"
- "Please" → "مهرباني وکړئ"
- "Thank you" → "مننه"
- "Submit" → "واستوئ"
- "Cancel" → "لغوه کړئ"
- "Save" → "ذخیره کړئ"
- "Delete" → "ړنګ کړئ"
- "Edit" → "سمون"
```

---

## 🚀 د مثال د یو Component بشپړول

### مثال: HealthTips.tsx

```tsx
import { useLanguage } from "../contexts/LanguageContext";
import { Card } from "./ui/card";
import { Heart, Activity, Brain } from "lucide-react";

export function HealthTips() {
  const { language } = useLanguage();

  const translations = {
    en: {
      title: "Health Tips",
      subtitle: "Stay healthy with daily tips",
      tips: [
        {
          icon: Heart,
          title: "Heart Health",
          description: "Regular exercise keeps your heart strong",
          readMore: "Read More"
        },
        {
          icon: Activity,
          title: "Stay Active",
          description: "30 minutes of daily activity is essential",
          readMore: "Read More"
        },
        {
          icon: Brain,
          title: "Mental Wellness",
          description: "Practice mindfulness and meditation",
          readMore: "Read More"
        }
      ]
    },
    dari: {
      title: "نکات صحی",
      subtitle: "با نکات روزانه سالم بمانید",
      tips: [
        {
          icon: Heart,
          title: "سلامت قلب",
          description: "ورزش منظم قلب شما را قوی نگه می‌دارد",
          readMore: "بیشتر بخوانید"
        },
        {
          icon: Activity,
          title: "فعال بمانید",
          description: "۳۰ دقیقه فعالیت روزانه ضروری است",
          readMore: "بیشتر بخوانید"
        },
        {
          icon: Brain,
          title: "سلامت روانی",
          description: "ذهن آگاهی و مراقبه را تمرین کنید",
          readMore: "بیشتر بخوانید"
        }
      ]
    },
    pashto: {
      title: "د روغتیا لارښوونې",
      subtitle: "د ورځني لارښوونو سره روغ پاتې شئ",
      tips: [
        {
          icon: Heart,
          title: "د زړه روغتیا",
          description: "منظم ورزش ستاسو زړه قوي ساتي",
          readMore: "نور ولولئ"
        },
        {
          icon: Activity,
          title: "فعال اوسئ",
          description: "د ورځې ۳۰ دقیقې فعالیت اړین دی",
          readMore: "نور ولولئ"
        },
        {
          icon: Brain,
          title: "رواني روغتیا",
          description: "د ذهن آګاهي او مراقبه تمرین وکړئ",
          readMore: "نور ولولئ"
        }
      ]
    }
  };

  const t = translations[language as keyof typeof translations] || translations.en;

  return (
    <section className="py-8">
      <h2>{t.title}</h2>
      <p>{t.subtitle}</p>
      
      <div className="grid md:grid-cols-3 gap-4">
        {t.tips.map((tip, index) => (
          <Card key={index}>
            <tip.icon className="w-8 h-8" />
            <h3>{tip.title}</h3>
            <p>{tip.description}</p>
            <button>{tip.readMore}</button>
          </Card>
        ))}
      </div>
    </section>
  );
}
```

---

## ✅ د Implementation Steps Summary

```
Step 1: Import useLanguage hook
Step 2: د component دننه { language } destructure کړئ
Step 3: د translations object جوړ کړئ په درې ژبو
Step 4: const t = translations[language] || translations.en
Step 5: د ټول hardcoded text ځای ته {t.key} استعمال کړئ
Step 6: Test په هرې ژبه کې
Step 7: د numbers او dates formatting چیک کړئ
```

---

## 📞 د مرستې لپاره

که تاسو د multilingual implementation کې مشکل لرئ:

1. د AboutUs.tsx او ContactUs.tsx وګورئ (بشپړ multilingual)
2. د LoginForm.tsx، SignUpForm.tsx وګورئ (د forms لپاره)
3. د DoctorsList.tsx وګورئ (د dynamic data لپاره)
4. د AppointmentManagement.tsx وګورئ (د complex components لپاره)

---

## 🎯 د هدف:

```
د 2025 په پای کې:
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

✅ 100% د components multilingual
✅ د ټولو UI elements په درې ژبو
✅ د errors، warnings، success messages multilingual
✅ د forms، buttons، labels په درې ژبو
✅ د navigation او menus multilingual
✅ د tooltips او help text په درې ژبو
```

---

**مننه! د HealMate اپلیکیشن باید په درې ژبو بشپړ professional وي!** 🎉
