# 🔐 HealMate Admin Configuration Guide
## د Admin تنظیماتو بشپړ لارښود

---

## 📋 Overview / عمومي کتنه

د HealMate اپلیکیشن یو بشپړ Admin Panel لري چې یوازې د **Owner** لاسرسی لري. دا سیسټم د Firebase Authentication او Firestore سره وصل دی.

---

## 🎯 د Admin Access کنټرول

### Owner Email Configuration

د Owner email په `/config/admin-config.ts` کې تنظیم شوی دی:

```typescript
export const OWNER_EMAIL = "ibrahimkhaksar.it@gmail.com";
```

### د Email بدلول (که ضرورت وي)

که تاسو د Owner email بدلول غواړئ:

1. `/config/admin-config.ts` فایل خلاص کړئ
2. `OWNER_EMAIL` constant update کړئ:
   ```typescript
   export const OWNER_EMAIL = "your-new-email@example.com";
   ```
3. فایل خوندي کړئ
4. اپلیکیشن refresh کړئ

⚠️ **یادونه:** نوی email باید په Firebase Authentication کې register شي!

---

## 🔧 د Configuration Structure

### Main Config File: `/config/admin-config.ts`

```typescript
// د Owner Email
export const OWNER_EMAIL = "ibrahimkhaksar.it@gmail.com";

// د Owner معلومات
export const OWNER_INFO = {
  email: OWNER_EMAIL,
  name: "Ibrahim Khaksar",
  role: "owner",
  permissions: [
    "full_access",
    "manage_admins",
    "manage_users",
    // ... نور permissions
  ]
};

// Helper Functions
export function isOwnerEmail(email: string): boolean;
export function hasAdminAccess(email: string): boolean;
```

---

## 📁 د Admin System فایلونه

### 1. Configuration Files
```
/config/
├── admin-config.ts       # د Admin تنظیمات او constants
├── firebase-config.ts    # د Firebase تنظیمات
└── admob-config.ts       # د AdMob تنظیمات
```

### 2. Component Files
```
/components/
├── AdminPanel.tsx        # د Admin Panel main component
├── AdminAuth.tsx         # د Authentication screen
└── Settings.tsx          # د Admin Panel لاسرسي بټن
```

---

## 🚀 د Admin Panel Features

### 1️⃣ Dashboard Tab
- د Users شمیره
- د Doctors شمیره
- د Medicines شمیره
- د Revenue احصائیې

### 2️⃣ Admins Tab
- د Admin کاروونکو لیست
- نوی Admin اضافه کول
- د Admin حالت بدلول (Active/Blocked)
- د Admin پاسورډ بیا تنظیم کول
- د Admin حذف کول

### 3️⃣ Users Tab
- د ټولو کاروونکو لیست
- د کاروونکو مدیریت
- د کاروونکو حالت بدلول

### 4️⃣ Doctors Tab
- د ډاکټرانو لیست
- د ډاکټرانو مدیریت
- د Status تغیر (Active/Pending/Blocked)

### 5️⃣ Medicines Tab
- د درملو لیست
- د Stock مدیریت
- د بیې تنظیم کول

### 6️⃣ AdMob Tab
- د AdMob IDs مدیریت
- د Android IDs (App, Banner, Interstitial, Rewarded)
- د iOS IDs (App, Banner, Interstitial, Rewarded)
- د Test Mode enable/disable
- د ورځني view limit تنظیم کول

### 7️⃣ Settings Tab
- د Admin پاسورډ بدلول
- د Admin ایمیل بدلول
- د Admin معلومات لیدل

---

## 🔐 د Security Features

### Authentication Flow

```
1. کاروونکی Settings ته ځي
2. یوازې Owner ته Admin Panel بټن ښکاره کیږي
3. Admin Panel کې Login/SignUp صفحه ښکاره کیږي
4. Firebase Authentication د email تایید کوي
5. Firestore د admin role تایید کوي
6. یوازې Owner ته Admin Panel لاسرسی ورکول کیږي
```

### Email Validation

```typescript
// په ټولو ځایونو کې د Owner email validation
if (!isOwnerEmail(email)) {
  toast.error("❌ تاسو د Admin Panel لاسرسی نه لرئ!");
  return;
}
```

### Firestore Security

په Firestore کې د `admins` collection د security rules:

```javascript
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /admins/{adminId} {
      // یوازې authenticated کاروونکي لوستلی شي
      allow read: if request.auth != null;
      
      // یوازې owner لیکلی شي
      allow write: if request.auth != null && 
                      request.auth.token.email == 'ibrahimkhaksar.it@gmail.com';
    }
  }
}
```

---

## 📱 د Settings کې Admin Panel Access

د Settings component کې د Owner لپاره ځانګړی کارډ:

```tsx
{isOwner && (
  <Card>
    <CardHeader>
      <CardTitle>Admin Panel</CardTitle>
    </CardHeader>
    <CardContent>
      <Button onClick={() => setActivePage("admin")}>
        Open Admin Panel
      </Button>
    </CardContent>
  </Card>
)}
```

---

## 🛠️ د Development Testing

### Local Testing

1. د Owner email سره Sign Up وکړئ:
   ```
   Email: ibrahimkhaksar.it@gmail.com
   Password: [خپل مضبوط پاسورډ]
   ```

2. Login وکړئ او Admin Panel ته لاړ شئ

3. د ټولو tabs ټیسټ کړئ

### Production Deployment

1. ✅ د Firebase تنظیمات تایید کړئ
2. ✅ د Firestore security rules تنظیم کړئ
3. ✅ د Owner email په production database کې create کړئ
4. ✅ د Admin Panel ټیسټ کړئ

---

## 🔄 د Multiple Admins System (راتلونکی)

که تاسو په راتلونکي کې د څو admins اضافه کول غواړئ:

### قدم 1: د Admin Roles توسیع

```typescript
export const ADMIN_ROLES = {
  OWNER: "owner",           // بشپړ لاسرسی
  SUPER_ADMIN: "super_admin", // بشپړ لاسرسی (د owner پرته)
  ADMIN: "admin",            // محدود لاسرسی
  MODERATOR: "moderator"     // یوازې د content moderation
};
```

### قدم 2: د Permissions System

```typescript
export const ADMIN_PERMISSIONS = {
  FULL_ACCESS: "full_access",
  MANAGE_ADMINS: "manage_admins",
  MANAGE_USERS: "manage_users",
  // ... نور permissions
};
```

### قدم 3: د AdminPanel کې Permissions Check

```typescript
const canManageAdmins = hasPermission(currentAdmin, "manage_admins");

{canManageAdmins && (
  <TabsTrigger value="admins">Admins</TabsTrigger>
)}
```

---

## 📊 د Admin Activity Logging (راتلونکی)

د راتلونکي Security لپاره:

```typescript
// د Admin کړنو ثبت کول
interface AdminLog {
  adminId: string;
  action: string;
  target: string;
  timestamp: string;
  details: any;
}

// مثال
logAdminAction({
  adminId: currentAdmin.id,
  action: "DELETE_USER",
  target: userId,
  timestamp: new Date().toISOString(),
  details: { reason: "spam" }
});
```

---

## 🚨 Troubleshooting

### مسله 1: Admin Panel ته لاسرسی نشته

**حل:**
```
1. چیک کړئ چې تاسو په Owner email سره Login شوي یاست
2. Settings صفحه refresh کړئ
3. د browser cache صاف کړئ
4. که هم کار نه کوي، console errors وګورئ
```

### مسله 2: Firebase Authentication Error

**حل:**
```
1. د Firebase config چیک کړئ په /config/firebase-config.ts کې
2. د Firebase Console کې Authentication enable تایید کړئ
3. د Email/Password method enable تایید کړئ
```

### مسله 3: "User not found" Error

**حل:**
```
1. لومړی "Sign Up" وکړئ
2. بیا Login وکړئ
3. که په ایمیل کې typo وي، بیا Sign Up وکړئ
```

---

## 📞 د مرستې معلومات

### Technical Support
```
📧 Email: ibrahimkhaksar.it@gmail.com
📱 Phone: +93783040441
📱 Phone: +93779494512
```

### Documentation Files
```
📄 HOW_TO_USE_ADMIN_PANEL.md  # د Admin Panel استعمال
📄 ADMIN_CONFIG_GUIDE.md      # د Configuration لارښود (دا فایل)
📄 FIREBASE_SETUP_GUIDE.md    # د Firebase لارښود
```

---

## ✅ Best Practices

### امنیت (Security)
- ✅ مضبوط پاسورډ استعمال کړئ (12+ characters)
- ✅ پاسورډ په مختلفو ځایونو کې یو نه وي
- ✅ د Admin credentials شریک مه کوئ
- ✅ په public computers کې Login مه کوئ
- ✅ کله چې کار بشپړ شي Logout وکړئ

### مدیریت (Management)
- ✅ د منظمه توګه Admin Logs چیک کړئ
- ✅ د منظمه توګه پاسورډ بدل کړئ
- ✅ د غیر فعال admins حذف کړئ
- ✅ د permissions احتیاط سره ورکړئ

### نګهداری (Maintenance)
- ✅ د منظمه توګه backup واخلئ
- ✅ د Firestore rules update کړئ
- ✅ د Admin Panel features ټیسټ کړئ
- ✅ د Users feedback په غوږ ونیسئ

---

**د HealMate Admin Configuration بشپړ لارښود! 🎉**

Made with ❤️ for Afghanistan 🇦🇫
