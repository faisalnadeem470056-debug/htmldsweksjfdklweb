# 🎯 HealMate Admin Panel - د استعمال لارښود
## چټک لارښود / Quick Start Guide

---

## 🚀 د Admin Panel ته د رسیدو لارې

### 🔐 **IMPORTANT: Owner-Only Access**
یوازې د **Owner Email** Admin Panel ته لاسرسی لري:
```
Email: ibrahimkhaksar.it@gmail.com
```

⚠️ **امنیتي یادونه:** دا email په `/config/admin-config.ts` کې تنظیم شوی دی

### طریقه 1: د Settings څخه (سفارش شوی)
```
1️⃣ د Owner Email سره Login وکړئ (ibrahimkhaksar.it@gmail.com)
2️⃣ Settings صفحې ته ورشئ
3️⃣ "Admin Panel" کارډ ته scroll کړئ (یوازې owner ته ښکاري)
4️⃣ "Open Admin Panel" بټن کلیک کړئ
5️⃣ د لومړي ځل لپاره: "Create account" غوره کړئ
6️⃣ که مخکې حساب لرئ: "Login" وکړئ
```

### طریقه 2: په App.tsx کې
```typescript
// په کوډ کې د activePage state "admin" ته set کړئ
setActivePage("admin");
```

---

## 🔐 د Admin Account جوړول

### د لومړي ځل لپاره (First Time Setup):

1. **Sign Up کلیک وکړئ**
   - Email: `ibrahimkhaksar.it@gmail.com` (باید بالکل همدا وي)
   - Password: خپل مضبوط پاسورډ غوره کړئ (لږ تر لږه 6 حروف)
   - Confirm Password: همدا پاسورډ بیا ولیکئ

2. **د Sign Up وروسته**
   - تاسو ته به success message وښایی
   - بیرته د Login صفحې ته redirect کیږئ
   - اوس Login وکړئ

### که پاسورډ هیر شوی (Forgot Password):

1. **د Login صفحې کې "Forgot password?" کلیک وکړئ**
2. خپل ایمیل ولیکئ: `ibrahimkhaksar.it@gmail.com`
3. "Send Link" کلیک وکړئ
4. خپل ایمیل چیک کړئ - د پاسورډ reset لینک به درسیږي
5. د لینک په مټ نوی پاسورډ تنظیم کړئ

⚠️ **امنیتي یادونه:**
- یوازې owner email د Admin Panel ته لاسرسی لري
- نور هیڅوک Admin Panel نه شي لیدلای
- خپل پاسورډ خوندي وساتئ او هیڅ چا سره یې شریک مه کوئ

---

## 📱 د Admin Panel Features

### ✅ **Tab 1: Guide (لارښود)**
- چټک Setup لارښودونه
- د ID Format معلومات
- Test vs Production توپیر
- د Ad Types توضیحات
- د امنیت Tips

### ✅ **Tab 2: Android**
- Android App ID
- Android Banner Ad ID
- Android Interstitial Ad ID
- Android Rewarded Ad ID
- د هر ID لپاره Copy button

### ✅ **Tab 3: iOS**
- iOS App ID
- iOS Banner Ad ID
- iOS Interstitial Ad ID
- iOS Rewarded Ad ID
- د هر ID لپاره Copy button

### ✅ **Tab 4: Settings (تنظیمات)**
- Show IDs Toggle (IDs ښکاره/پټ)
- Test Mode Toggle (ټیسټ/Production)
- Show Ads Toggle (اعلانات فعال/غیر فعال)
- Load Test IDs button
- د Google Test IDs معلومات

---

## 🎨 د ټیسټ لپاره لارښودونه

### 1️⃣ د Test Mode فعالول
```
✓ Settings Tab ته ورشئ
✓ Test Mode = ON
✓ "Load Test IDs" button کلیک کړئ
✓ Save Changes کلیک کړئ
```

اوس ستاسو اپلیکیشن د Google Test IDs کاروي!

### 2️⃣ د Test IDs منوال ښکارندویی
```
Android Test IDs:
  App:         ca-app-pub-3940256099942544~3347511713
  Banner:      ca-app-pub-3940256099942544/6300978111
  Interstitial: ca-app-pub-3940256099942544/1033173712
  Rewarded:    ca-app-pub-3940256099942544/5224354917

iOS Test IDs:
  App:         ca-app-pub-3940256099942544~1458002511
  Banner:      ca-app-pub-3940256099942544/2934735716
  Interstitial: ca-app-pub-3940256099942544/4411468910
  Rewarded:    ca-app-pub-3940256099942544/1712485313
```

---

## 💰 د Production Setup لارښودونه

### د Google AdMob Console کې:

#### قدم 1: Account جوړول
```
1. https://admob.google.com ته ورشئ
2. د Google Account سره Sign In کړئ
3. Terms and Conditions قبول کړئ
4. د معلوماتو Form ډک کړئ
```

#### قدم 2: App اضافه کول
```
1. Apps > Add App کلیک کړئ
2. Android App اضافه کړئ:
   - App name: HealMate
   - Package name: com.healmate.afghanistan
   - Platform: Android
3. iOS App اضافه کړئ:
   - App name: HealMate
   - Bundle ID: com.healmate.afghanistan
   - Platform: iOS
```

#### قدم 3: Ad Units جوړول
```
د Android لپاره:
  1. Banner Ad Unit جوړ کړئ
  2. Interstitial Ad Unit جوړ کړئ
  3. Rewarded Ad Unit جوړ کړئ

د iOS لپاره:
  1. Banner Ad Unit جوړ کړئ
  2. Interstitial Ad Unit جوړ کړئ
  3. Rewarded Ad Unit جوړ کړئ
```

#### قدم 4: IDs کاپي کول
```
د هر Ad Unit څخه ID کاپي کړئ:
  ca-app-pub-1234567890123456/1234567890
```

### د HealMate Admin Panel کې:

#### قدم 5: IDs پیسټ کول
```
1. Admin Panel ته ورشئ
2. Android Tab کې Android IDs پیسټ کړئ
3. iOS Tab کې iOS IDs پیسټ کړئ
4. Settings Tab کې:
   - Test Mode = OFF
   - Show Ads = ON
5. Save Changes کلیک کړئ
```

---

## 🔍 د AdMob Status Indicator

په Development Mode کې، یو کوچنی indicator د screen په ښي لاندې کونج کې ښکاره کیږي:

```
┌─────────────────┐
│ AdMob Status    │
├─────────────────┤
│ Mode: Test      │
│ Ads:  ON        │
├─────────────────┤
│ ⚠️ Test Mode    │
└─────────────────┘
```

دا Status Indicator ستاسو سره وايي:
- ✅ د AdMob Mode (Test یا Prod)
- ✅ د اعلاناتو حالت (ON یا OFF)
- ⚠️ که Test Mode فعال وي

---

## 📊 د Configuration Storage

د HealMate AdMob configuration په `localStorage` کې خوندي کیږي:

```typescript
Storage Key: 'healmate_admob_config'

د Configuration Structure:
{
  androidAppId: "ca-app-pub-...",
  androidBannerId: "ca-app-pub-...",
  androidInterstitialId: "ca-app-pub-...",
  androidRewardedId: "ca-app-pub-...",
  iosAppId: "ca-app-pub-...",
  iosBannerId: "ca-app-pub-...",
  iosInterstitialId: "ca-app-pub-...",
  iosRewardedId: "ca-app-pub-...",
  testMode: true/false,
  showAds: true/false
}
```

---

## 🛠️ د Configuration Files

### 1. `/config/admob-config.ts`
- د AdMob Configuration مدیریت
- localStorage integration
- Validation logic
- د Google Test IDs

### 2. `/config/admob-config.example.json`
- د Configuration نمونه
- د Export/Import لپاره
- د Documentation لپاره

### 3. `/components/AdminPanel.tsx`
- د Admin Panel UI
- د Login system
- د IDs مدیریت
- د Settings controls

### 4. `/components/AdBanner.tsx`
- د اعلاناتو ښکارندویی
- د showAds check
- د testMode indicator

---

## 🎯 د عملي ټیسټ لارښودونه

### ټیسټ 1: د Test IDs Load کول
```
1. Admin Panel > Settings Tab
2. "Load Test IDs" کلیک کړئ
3. Android او iOS Tabs وګورئ
4. ټول IDs باید د Google Test IDs وي
```

### ټیسټ 2: د Configuration خوندي کول
```
1. یو ID بدل کړئ
2. "Save Changes" کلیک کړئ
3. Browser Refresh کړئ
4. Admin Panel بیرته خلاص کړئ
5. تغیر باید خوندي وي
```

### ټیسټ 3: د Test Mode Toggle
```
1. Test Mode = ON
2. Save Changes
3. د اپلیکیشن صفحو ته ورشئ
4. د Ad Banners باندې "TEST" badge وګورئ
```

### ټیسټ 4: د Show Ads Toggle
```
1. Show Ads = OFF
2. Save Changes
3. د اپلیکیشن صفحو ته ورشئ
4. هیڅ Ad Banner نه باید ښکاره وي
```

---

## 🔒 د امنیت Checklist

```
☐ پاسورډ بدل شو (د Default څخه)
☐ د Admin Panel لاسرسی محدود دی
☐ د Production IDs په Private repository کې دي
☐ د Test Mode په Production کې OFF دی
☐ د Google AdMob Policies لوستل شوي
☐ د Invalid Clicks Policy پوه یم
```

---

## 📞 د مرستې معلومات

### د ټیکنیکي مسلو لپاره:
```
📧 Email: ibrahimkhaksar.it@gmail.com
📱 Phone: +93783040441
📱 Phone: +93779494512
```

### د Google AdMob مرستې:
```
🌐 AdMob Help: https://support.google.com/admob
📚 Documentation: https://developers.google.com/admob
```

---

## ✅ د بریالیتوب نښې

که تاسو دا ګامونه بشپړ کړي:
```
✓ Admin Panel ته لاسرسی لرئ
✓ د Test IDs کار کوي
✓ د Configuration خوندي کیږي
✓ د Show Ads toggle کار کوي
✓ د Test Mode toggle کار کوي
✓ د Production IDs چمتو دي
```

**مبارک شه! ستاسو HealMate اپلیکیشن د AdMob سره بشپړ تنظیم دی! 🎉**

---

## 🚀 د راتلونکو قدمونه

1. ✅ د Development کې د Test Mode سره ټیسټ کړئ
2. ✅ د Production IDs واخلئ
3. ✅ د Production Mode enable کړئ
4. ✅ د اپلیکیشن Publish کړئ
5. ✅ د عوایدو څارنه پیل کړئ

---

**د افغانستان لومړنی بشپړ روغتیا اپلیکیشن! 💚🇦🇫**

Made with ❤️ by HealMate Team
