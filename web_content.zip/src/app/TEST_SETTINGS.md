# ⚙️ د Settings Test لارښود
# Settings Testing Guide

---

## ✅ Settings موجود دی او بشپړ کار کوي!

---

## 📂 د Settings فایلونه:

```
✅ /components/Settings.tsx - بشپړ Component
✅ /translations.ts - د ۳ ژبو translations
✅ /App.tsx - د Settings page routing
✅ Header کې د Settings icon
```

---

## 🎯 د Settings ته څنګه ورشو:

### 1️⃣ د Header څخه:
```
1. د ماشین یا موبایل browser ته ورشئ
2. د Header په ښي خوا کې د ⚙️ (Settings) icon وګورئ
3. کلیک وکړئ
4. Settings صفحه باید خلاص شي
```

### 2️⃣ د Mobile Menu څخه:
```
1. د موبایل browser ته ورشئ
2. د Menu icon (☰) کلیک وکړئ
3. د "تنظیمات" یا "Settings" option باید وګورئ
4. کلیک وکړئ
```

### 3️⃣ د Keyboard Shortcut:
```
1. Browser کې وګورئ
2. د Console ته ورشئ (F12)
3. لیکئ: window.location.hash = '#settings'
4. یا په App کې manually navigate کړئ
```

---

## 🔧 که Settings نه ښکاري:

### Solution 1: د Browser Refresh وکړئ
```bash
# Hard Refresh:
Ctrl + Shift + R  (Windows/Linux)
Cmd + Shift + R   (Mac)

# یا Cache پاک کړئ:
Ctrl + Shift + Delete
```

### Solution 2: Console ته وګورئ
```javascript
// F12 → Console
// کوم error ښکاري؟

// د تڼۍ test:
document.querySelector('button[onClick*="settings"]')

// که null راغلل، نو تڼۍ نشته
```

### Solution 3: د Component Test:
```bash
# Terminal کې:
npm run dev

# او بیا وګورئ:
http://localhost:5173

# مستقیم Settings ته ورشئ:
# په URL کې #settings اضافه کړئ
```

---

## 🎨 د Settings Features:

### 1️⃣ د ژبې تبدیل (Language):
```
✅ پښتو
✅ دری  
✅ English

د کلیک سره تبدیلیږي
```

### 2️⃣ د اطلاعیو تنظیمات (Notifications):
```
✅ Enable/Disable switch
✅ د ګلوبل notifications کنټرول
```

### 3️⃣ د تیارې حالت (Dark Mode):
```
✅ Enable/Disable switch
✅ د شپې حالت (راتلونکی feature)
```

### 4️⃣ د Cache پاکول (Clear Cache):
```
✅ "پاک کول" تڼۍ
✅ Confirmation dialog
✅ localStorage پاکیږي
```

### 5️⃣ د App معلومات (App Info):
```
✅ Version: 1.0.0
✅ Developer: Ibrahim Khaksar
✅ Email: ibrahimkhaksar.it@gmail.com
```

### 6️⃣ د PWA معلومات:
```
✅ د نصب لارښود
✅ Progressive Web App info
```

---

## 🐛 د عام مسلو حل:

### مسله 1: Settings صفحه نه خلاصیږي
```typescript
// د App.tsx چک کړئ:
{currentPage === 'settings' && (
  <Settings 
    language={language} 
    onBack={() => setCurrentPage('home')} 
    onLanguageChange={setLanguage} 
  />
)}

// که missing وي، اضافه کړئ
```

### مسله 2: Settings icon نه ښکاري
```typescript
// د Header کې چک کړئ:
<Button variant="ghost" size="icon" onClick={() => setCurrentPage('settings')}>
  <SettingsIcon className="w-5 h-5" />
</Button>

// که missing وي، اضافه کړئ
```

### مسله 3: Translation نه ښکاري
```typescript
// translations.ts چک کړئ:
ps: {
  settings: 'تنظیمات',
  language: 'ژبه',
  // ...
},
fa: {
  settings: 'تنظیمات',
  language: 'زبان',
  // ...
},
en: {
  settings: 'Settings',
  language: 'Language',
  // ...
}
```

### مسله 4: د Back تڼۍ کار نه کوي
```typescript
// Settings.tsx کې:
<Button variant="ghost" size="icon" onClick={onBack}>
  <ArrowLeft className="w-5 h-5" />
</Button>

// onBack باید setCurrentPage('home') وکړي
```

---

## 🧪 د بشپړ Test Checklist:

### ✅ Basic Navigation:
- [ ] Settings icon په Header کې ښکاري
- [ ] کلیک سره Settings صفحه خلاصیږي
- [ ] Back button کار کوي
- [ ] د Home ته بیرته ورځي

### ✅ Language Switching:
- [ ] درې تڼۍ ښکاري (پښتو، دری، EN)
- [ ] Active language highlight کیږي
- [ ] کلیک سره ژبه تبدیلیږي
- [ ] بشپړ app ژبه بدلیږي

### ✅ Notifications:
- [ ] Switch ښکاري
- [ ] Toggle کار کوي
- [ ] State ذخیره کیږي (future)

### ✅ Dark Mode:
- [ ] Switch ښکاري
- [ ] Toggle کار کوي
- [ ] State ذخیره کیږي (future)

### ✅ Clear Cache:
- [ ] "پاک کول" تڼۍ ښکاري
- [ ] Confirmation dialog راځي
- [ ] localStorage پاک کیږي
- [ ] Success message ښکاري

### ✅ App Info:
- [ ] Version ښکاري
- [ ] Developer نوم ښکاري
- [ ] Email ښکاري

### ✅ PWA Info:
- [ ] د نصب معلومات ښکاري
- [ ] په سمه ژبه ښکاري

### ✅ Styling:
- [ ] Glassmorphism effect
- [ ] Gradient backgrounds
- [ ] Smooth animations
- [ ] Responsive layout

---

## 💡 د Manual Test لپاره:

```bash
# 1. App start کړئ
npm run dev

# 2. Browser ته ورشئ
http://localhost:5173

# 3. Settings icon کلیک کړئ (⚙️)
# په Header کې د ښي خوا

# 4. بشپړ Settings صفحه باید وګورئ:

┌─────────────────────────────────┐
│  ← تنظیمات                      │
│  خپل ترجیحات مدیریت کړئ         │
└─────────────────────────────────┘

┌─────────────────────────────────┐
│  🌐 ژبه                         │
│  خپله ژبه غوره کړئ              │
│  [پښتو] [دری] [English]        │
└─────────────────────────────────┘

┌─────────────────────────────────┐
│  🔔 اطلاعیې            [Switch]  │
│  د اطلاعیو فعالول                │
└─────────────────────────────────┘

┌─────────────────────────────────┐
│  🌙 تیاره حالت         [Switch]  │
│  د شپې حالت فعالول               │
└─────────────────────────────────┘

┌─────────────────────────────────┐
│  🗑️ Cache پاک کول     [پاک کول] │
│  ذخیره شوي ډاټا پاک کړئ         │
└─────────────────────────────────┘

┌─────────────────────────────────┐
│  ℹ️ د اپلیکیشن معلومات           │
│  Version:    1.0.0              │
│  Developer:  Ibrahim Khaksar    │
│  Email:      ibrahim...         │
└─────────────────────────────────┘

┌─────────────────────────────────┐
│  📱 د PWA معلومات                │
│  د موبایل اپلیکیشن په توګه...    │
└─────────────────────────────────┘
```

---

## 🎯 که Settings ستونزه لري:

### Quick Fix 1: د App.tsx تصدیق:
```typescript
// App.tsx کې د currentPage check:
{currentPage === 'settings' && (
  <Settings 
    language={language} 
    onBack={() => setCurrentPage('home')} 
    onLanguageChange={setLanguage} 
  />
)}
```

### Quick Fix 2: د Settings import تصدیق:
```typescript
// App.tsx په سر کې:
import { Settings } from './components/Settings';
```

### Quick Fix 3: د Settings.tsx موجودیت:
```bash
# Check:
ls -la components/Settings.tsx

# که نشته، بیرته جوړ کړئ
```

---

## 🚀 د بیرته جوړولو لپاره:

که Settings بیرته جوړولو ته اړتیا لري:

```typescript
// یو نوی بشپړ Settings component:
// /components/Settings.tsx

import { useState } from 'react';
import { ArrowLeft, Globe, Bell, Moon, Trash2, Info, Mail, Phone } from 'lucide-react';
import { motion } from 'motion/react';
import { Button } from './ui/button';
import { Switch } from './ui/switch';
import { translations } from '../translations';

interface SettingsProps {
  language: 'ps' | 'fa' | 'en';
  onBack: () => void;
  onLanguageChange: (lang: 'ps' | 'fa' | 'en') => void;
}

export function Settings({ language, onBack, onLanguageChange }: SettingsProps) {
  const [notifications, setNotifications] = useState(true);
  const [darkMode, setDarkMode] = useState(false);
  const t = translations[language];

  const handleClearCache = () => {
    if (confirm(language === 'ps' ? 'ایا تاسو ډاډه یاست؟' : language === 'fa' ? 'آیا مطمئن هستید؟' : 'Are you sure?')) {
      localStorage.clear();
      alert(language === 'ps' ? 'Cache پاک شو!' : language === 'fa' ? 'کش پاک شد!' : 'Cache cleared!');
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-gray-50 to-zinc-50 pb-20">
      {/* بشپړ Settings UI */}
    </div>
  );
}
```

---

## ✅ د بریالیتوب نښې:

که Settings سم کار کوي:
- ✅ Icon په header کې ښکاري
- ✅ کلیک سره Settings صفحه خلاصیږي
- ✅ د ژبې تڼۍ کار کوي
- ✅ د Back تڼۍ کار کوي
- ✅ Cache clear کار کوي
- ✅ بشپړ animations ښکاري

---

**Settings بشپړ جوړ دی او کار کوي! که لا هم نه ښکاري، راته ووایاست او زه به بیرته جوړ کړم! 🚀⚙️**
