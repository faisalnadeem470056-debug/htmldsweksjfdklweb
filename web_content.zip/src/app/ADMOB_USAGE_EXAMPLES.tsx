// ═══════════════════════════════════════════════════════════════
// 🎯 AdMob Usage Examples - Copy & Paste Ready
// ═══════════════════════════════════════════════════════════════
//
// دا file یوازې د examples لپاره دی
// دلته کوډ copy کړئ او په خپلو components کې paste کړئ
//
// ═══════════════════════════════════════════════════════════════

// ───────────────────────────────────────────────────────────────
// 📊 EXAMPLE 1: Banner Ad په Home Page کې
// ───────────────────────────────────────────────────────────────

// په App.tsx کې د imports برخه:
import { AdMobBanner } from './components/ads/AdMobBanner';

// په Home Page render کې:
{currentPage === 'home' && (
  <div className="container mx-auto px-4 py-8">
    {/* ستاسو نور content */}
    <HeroCarousel language={language} />
    
    {/* Categories */}
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
      {/* ... categories ... */}
    </div>
    
    {/* Banner Ad په bottom کې */}
    <AdMobBanner 
      position="bottom" 
      size="standard" 
      className="mb-4" 
    />
  </div>
)}

// ───────────────────────────────────────────────────────────────
// 📺 EXAMPLE 2: Interstitial Ad په Doctors Directory کې
// ───────────────────────────────────────────────────────────────

// په DoctorsDirectory.tsx کې imports:
import { AdMobBanner } from './ads/AdMobBanner';
import { AdMobInterstitial, useInterstitialAd } from './ads/AdMobInterstitial';

// په Component function کې:
export function DoctorsDirectory({ language, onBack }: DoctorsDirectoryProps) {
  // Ad hook
  const { showAd, checkAndShowAd, closeAd } = useInterstitialAd();
  
  // د doctor profile لیدو function
  const handleViewDoctor = (doctor: Doctor) => {
    // د profile لیدو مخکې ad check کړئ
    const adShown = checkAndShowAd();
    
    if (!adShown) {
      // که ad نه ښودل شو، direct profile ته لاړ شئ
      setSelectedDoctor(doctor);
    } else {
      // که ad ښودل شو، بیا profile ته لاړ شئ د ad بندولو وروسته
      // د closeAd callback کې handle کړئ
    }
  };

  return (
    <div>
      {/* Doctors List */}
      <div className="grid gap-4">
        {doctors.map((doctor) => (
          <div 
            key={doctor.id}
            onClick={() => handleViewDoctor(doctor)}
            className="cursor-pointer"
          >
            {/* Doctor Card */}
          </div>
        ))}
      </div>

      {/* Banner Ad */}
      <AdMobBanner position="bottom" size="standard" />

      {/* Interstitial Ad */}
      <AdMobInterstitial 
        isOpen={showAd} 
        onClose={() => {
          closeAd();
          // د ad بندولو وروسته selected doctor profile ته لاړ شئ
          if (selectedDoctor) {
            // profile logic
          }
        }}
      />
    </div>
  );
}

// ───────────────────────────────────────────────────────────────
// 🎁 EXAMPLE 3: Rewarded Ad د Coins/Points لپاره
// ───────────────────────────────────────────────────────────────

// په ProfilePage.tsx کې imports:
import { AdMobRewarded, useRewardedAd } from './ads/AdMobRewarded';
import { Button } from './ui/button';

// په Component function کې:
export function ProfilePage({ language, onBack }: ProfilePageProps) {
  const [userCoins, setUserCoins] = useState(0);
  const { showAd, requestRewardedAd, closeAd, handleRewardEarned } = useRewardedAd();

  // د ad watching button
  const handleWatchAd = () => {
    const success = requestRewardedAd();
    if (success) {
      console.log('Rewarded ad requested');
    }
  };

  // د reward ترلاسه کولو callback
  const onRewardReceived = (amount: number) => {
    setUserCoins(prev => {
      const newAmount = prev + amount;
      // په localStorage کې save کړئ
      localStorage.setItem('healmate_user_coins', String(newAmount));
      return newAmount;
    });
    
    // Success message ښکاره کړئ
    alert(`🎉 You earned ${amount} coins!`);
  };

  return (
    <div className="p-6">
      {/* User Coins Display */}
      <div className="bg-gradient-to-r from-yellow-400 to-orange-500 rounded-3xl p-6 mb-6 text-white text-center">
        <h2 className="text-2xl mb-2">Your Coins</h2>
        <div className="text-5xl font-bold">{userCoins} 🪙</div>
      </div>

      {/* Earn Coins Button */}
      <Button
        onClick={handleWatchAd}
        className="w-full bg-gradient-to-r from-purple-600 to-pink-600 text-white py-6 text-lg"
      >
        <span className="flex items-center justify-center gap-2">
          Watch Ad & Earn 10 Coins 🎁
        </span>
      </Button>

      {/* Rewarded Ad Component */}
      <AdMobRewarded
        isOpen={showAd}
        onClose={closeAd}
        onRewardEarned={onRewardReceived}
        rewardAmount={10}
        rewardName="Coins"
      />
    </div>
  );
}

// ───────────────────────────────────────────────────────────────
// 📋 EXAMPLE 4: Native Ad په Social Feed کې
// ───────────────────────────────────────────────────────────────

// په SimpleSocialFeed.tsx کې imports:
import { AdMobBanner } from './ads/AdMobBanner';
import { AdMobNative } from './ads/AdMobNative';

// په Component function کې:
export function SimpleSocialFeed({ language, currentUserId }: SimpleSocialFeedProps) {
  const [posts, setPosts] = useState<Post[]>([]);

  return (
    <div className="max-w-2xl mx-auto p-4">
      {/* Create Post */}
      <div className="mb-6">
        {/* ... create post form ... */}
      </div>

      {/* Posts Feed with Native Ads */}
      <div className="space-y-4">
        {posts.map((post, index) => (
          <div key={post.id}>
            {/* Post Card */}
            <div className="bg-white rounded-3xl p-6 shadow-lg">
              {/* ... post content ... */}
            </div>

            {/* د هر 5 posts وروسته Native Ad */}
            {(index + 1) % 5 === 0 && (
              <AdMobNative 
                layout="medium" 
                className="my-6" 
              />
            )}
          </div>
        ))}
      </div>

      {/* Banner Ad په bottom کې */}
      <AdMobBanner position="bottom" size="standard" />
    </div>
  );
}

// ───────────────────────────────────────────────────────────────
// 🏥 EXAMPLE 5: د Hospitals Directory کې ټول Ad Types
// ───────────────────────────────────────────────────────────────

// په HospitalsDirectory.tsx کې imports:
import { AdMobBanner } from './ads/AdMobBanner';
import { AdMobInterstitial, useInterstitialAd } from './ads/AdMobInterstitial';
import { AdMobNative } from './ads/AdMobNative';

export function HospitalsDirectory({ language, onBack }: HospitalsDirectoryProps) {
  const [hospitals, setHospitals] = useState<Hospital[]>([]);
  const { showAd, checkAndShowAd, closeAd } = useInterstitialAd();

  const handleViewHospital = (hospital: Hospital) => {
    checkAndShowAd(); // Interstitial ad ښکاره کړئ
    setSelectedHospital(hospital);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-purple-50 pb-24">
      {/* Header */}
      <div className="bg-white shadow-lg p-6">
        <h1 className="text-2xl">Hospitals Directory</h1>
      </div>

      {/* Top Banner Ad */}
      <AdMobBanner position="top" size="medium" className="mb-4" />

      {/* Hospitals Grid */}
      <div className="container mx-auto px-4 py-6">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {hospitals.map((hospital, index) => (
            <div key={hospital.id}>
              {/* Hospital Card */}
              <div 
                onClick={() => handleViewHospital(hospital)}
                className="bg-white rounded-3xl p-6 shadow-lg cursor-pointer"
              >
                {/* ... hospital content ... */}
              </div>

              {/* د هر 6 hospitals وروسته Native Ad */}
              {(index + 1) % 6 === 0 && (
                <AdMobNative 
                  layout="small" 
                  className="mt-4" 
                />
              )}
            </div>
          ))}
        </div>
      </div>

      {/* Bottom Banner Ad */}
      <AdMobBanner position="bottom" size="standard" />

      {/* Interstitial Ad */}
      <AdMobInterstitial 
        isOpen={showAd} 
        onClose={closeAd}
        onAdWatched={() => {
          // د ad لیدو وروسته logic
        }}
      />
    </div>
  );
}

// ───────────────────────────────────────────────────────────────
// 💊 EXAMPLE 6: د Medicine Guide کې Native Ads په List کې
// ───────────────────────────────────────────────────────────────

// په MedicineGuide.tsx کې imports:
import { AdMobBanner } from './ads/AdMobBanner';
import { AdMobNative } from './ads/AdMobNative';

export function MedicineGuide({ language, onBack }: MedicineGuideProps) {
  const [medicines, setMedicines] = useState<Medicine[]>([]);
  const [searchQuery, setSearchQuery] = useState('');

  const filteredMedicines = medicines.filter(m => 
    m.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 to-pink-50 pb-24">
      {/* Search Bar */}
      <div className="bg-white shadow-lg p-6">
        <input
          type="text"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          placeholder="Search medicines..."
          className="w-full px-4 py-3 rounded-xl border"
        />
      </div>

      {/* Top Banner */}
      <AdMobBanner position="top" size="medium" className="mb-4" />

      {/* Medicines List */}
      <div className="container mx-auto px-4 py-6 space-y-4">
        {filteredMedicines.map((medicine, index) => (
          <div key={medicine.id}>
            {/* Medicine Card */}
            <div className="bg-white rounded-3xl p-6 shadow-lg">
              <h3 className="text-xl font-bold mb-2">{medicine.name}</h3>
              <p className="text-gray-600">{medicine.description}</p>
            </div>

            {/* د هر 8 medicines وروسته Native Ad */}
            {(index + 1) % 8 === 0 && (
              <AdMobNative 
                layout="small" 
                className="my-4" 
              />
            )}
          </div>
        ))}
      </div>

      {/* Bottom Banner */}
      <AdMobBanner position="bottom" size="standard" />
    </div>
  );
}

// ───────────────────────────────────────────────────────────────
// ⚙️ EXAMPLE 7: د Settings Page کې Ad Management
// ───────────────────────────────────────────────────────────────

// په Settings.tsx کې imports:
import { AdSettings } from './config/admob.config';

export function Settings({ language, onBack }: SettingsProps) {
  const [adsEnabled, setAdsEnabled] = useState(true);

  const handleToggleAds = () => {
    const newState = !adsEnabled;
    setAdsEnabled(newState);
    
    // په localStorage کې save کړئ
    localStorage.setItem('healmate_ads_enabled', String(newState));
    
    // د AdSettings update (که ستاسو ad components دا چک کوي)
    // AdSettings.banner.enabled = newState;
    // AdSettings.interstitial.enabled = newState;
    // ... etc
  };

  return (
    <div className="p-6">
      <h2 className="text-2xl mb-6">Settings</h2>

      {/* Ad Settings Section */}
      <div className="bg-white rounded-3xl p-6 mb-4 shadow-lg">
        <h3 className="text-xl mb-4">Advertisement Settings</h3>
        
        <div className="flex items-center justify-between">
          <div>
            <p className="font-medium">Show Ads</p>
            <p className="text-sm text-gray-600">
              Enable/disable advertisements in the app
            </p>
          </div>
          
          <label className="relative inline-block w-12 h-6">
            <input
              type="checkbox"
              checked={adsEnabled}
              onChange={handleToggleAds}
              className="sr-only peer"
            />
            <div className="w-full h-full bg-gray-300 rounded-full peer-checked:bg-green-500 transition-colors" />
            <div className="absolute top-0.5 left-0.5 w-5 h-5 bg-white rounded-full transition-transform peer-checked:translate-x-6" />
          </label>
        </div>

        {adsEnabled && (
          <div className="mt-4 pt-4 border-t border-gray-200">
            <p className="text-sm text-gray-600 mb-2">
              Current Ad Settings:
            </p>
            <ul className="text-sm text-gray-600 space-y-1">
              <li>• Banner Ads: {AdSettings.banner.enabled ? '✅ Enabled' : '❌ Disabled'}</li>
              <li>• Interstitial Ads: {AdSettings.interstitial.enabled ? '✅ Enabled' : '❌ Disabled'}</li>
              <li>• Rewarded Ads: {AdSettings.rewarded.enabled ? '✅ Enabled' : '❌ Disabled'}</li>
              <li>• Native Ads: {AdSettings.native.enabled ? '✅ Enabled' : '❌ Disabled'}</li>
            </ul>
          </div>
        )}
      </div>
    </div>
  );
}

// ───────────────────────────────────────────────────────────────
// 📊 EXAMPLE 8: د Admin Panel کې Ad Statistics
// ───────────────────────────────────────────────────────────────

// په AdminPanel.tsx کې یو نوی tab اضافه کړئ:
export function AdminPanel({ language, onBack }: AdminPanelProps) {
  const [activeTab, setActiveTab] = useState<'dashboard' | 'ads'>('dashboard');

  // د Ad statistics ترلاسه کول
  const adStats = {
    bannerImpressions: parseInt(localStorage.getItem('admob_banner_impressions') || '0'),
    bannerClicks: parseInt(localStorage.getItem('admob_banner_clicks') || '0'),
    interstitialShows: parseInt(localStorage.getItem('admob_interstitial_impressions') || '0'),
    rewardedShows: parseInt(localStorage.getItem('admob_rewarded_impressions') || '0'),
    nativeImpressions: parseInt(localStorage.getItem('admob_native_impressions') || '0'),
    nativeClicks: parseInt(localStorage.getItem('admob_native_clicks') || '0'),
    totalRewards: parseInt(localStorage.getItem('admob_rewards_earned') || '0'),
  };

  return (
    <div className="p-6">
      {/* Tabs */}
      <div className="flex gap-2 mb-6">
        <button
          onClick={() => setActiveTab('dashboard')}
          className={activeTab === 'dashboard' ? 'active-tab' : 'inactive-tab'}
        >
          Dashboard
        </button>
        <button
          onClick={() => setActiveTab('ads')}
          className={activeTab === 'ads' ? 'active-tab' : 'inactive-tab'}
        >
          Ad Statistics
        </button>
      </div>

      {/* Ad Statistics Tab */}
      {activeTab === 'ads' && (
        <div className="space-y-6">
          <h2 className="text-2xl font-bold">Advertisement Statistics</h2>

          {/* Stats Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {/* Banner Stats */}
            <div className="bg-white rounded-3xl p-6 shadow-lg">
              <h3 className="text-lg font-bold mb-2">Banner Ads</h3>
              <div className="space-y-2">
                <div>
                  <p className="text-sm text-gray-600">Impressions</p>
                  <p className="text-2xl font-bold text-blue-600">{adStats.bannerImpressions}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-600">Clicks</p>
                  <p className="text-2xl font-bold text-green-600">{adStats.bannerClicks}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-600">CTR</p>
                  <p className="text-lg font-bold text-purple-600">
                    {adStats.bannerImpressions > 0 
                      ? ((adStats.bannerClicks / adStats.bannerImpressions) * 100).toFixed(2) 
                      : '0'}%
                  </p>
                </div>
              </div>
            </div>

            {/* Interstitial Stats */}
            <div className="bg-white rounded-3xl p-6 shadow-lg">
              <h3 className="text-lg font-bold mb-2">Interstitial Ads</h3>
              <div>
                <p className="text-sm text-gray-600">Shows</p>
                <p className="text-3xl font-bold text-orange-600">{adStats.interstitialShows}</p>
              </div>
            </div>

            {/* Rewarded Stats */}
            <div className="bg-white rounded-3xl p-6 shadow-lg">
              <h3 className="text-lg font-bold mb-2">Rewarded Ads</h3>
              <div className="space-y-2">
                <div>
                  <p className="text-sm text-gray-600">Shows</p>
                  <p className="text-2xl font-bold text-yellow-600">{adStats.rewardedShows}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-600">Total Rewards</p>
                  <p className="text-2xl font-bold text-green-600">{adStats.totalRewards}</p>
                </div>
              </div>
            </div>

            {/* Native Stats */}
            <div className="bg-white rounded-3xl p-6 shadow-lg">
              <h3 className="text-lg font-bold mb-2">Native Ads</h3>
              <div className="space-y-2">
                <div>
                  <p className="text-sm text-gray-600">Impressions</p>
                  <p className="text-2xl font-bold text-pink-600">{adStats.nativeImpressions}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-600">Clicks</p>
                  <p className="text-2xl font-bold text-purple-600">{adStats.nativeClicks}</p>
                </div>
              </div>
            </div>
          </div>

          {/* Reset Stats Button */}
          <button
            onClick={() => {
              if (confirm('Reset all ad statistics?')) {
                localStorage.removeItem('admob_banner_impressions');
                localStorage.removeItem('admob_banner_clicks');
                localStorage.removeItem('admob_interstitial_impressions');
                localStorage.removeItem('admob_rewarded_impressions');
                localStorage.removeItem('admob_native_impressions');
                localStorage.removeItem('admob_native_clicks');
                localStorage.removeItem('admob_rewards_earned');
                window.location.reload();
              }
            }}
            className="bg-red-500 text-white px-6 py-3 rounded-xl hover:bg-red-600"
          >
            Reset Statistics
          </button>
        </div>
      )}
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════
// 🎯 BEST PRACTICES SUMMARY
// ═══════════════════════════════════════════════════════════════
/*

1. Banner Ads:
   ✅ په bottom یا top کې
   ✅ هر 60 ثانیو refresh
   ✅ د page load سره ښکاره شي

2. Interstitial Ads:
   ✅ د مهم transitions په وخت (د یو section څخه بل ته)
   ✅ د 5+ actions وروسته
   ✅ 2 دقیقې cooldown د دوه ads ترمنځ
   ❌ په feed scroll کې مه ښکاروئ

3. Native Ads:
   ✅ په content feed کې integrate
   ✅ د 5-8 items وروسته
   ✅ د content سره match شوي styling

4. Rewarded Ads:
   ✅ د optional features لپاره
   ✅ Clear benefit ښکاره کړئ ("Earn 10 Coins")
   ✅ د user په خوښه وي (forced نه وي)

5. Testing:
   ✅ isDevelopment = true د testing لپاره
   ✅ Console logs چک کړئ
   ✅ د stats localStorage چک کړئ

6. Production:
   ✅ اصلي IDs په config file کې
   ✅ isDevelopment = false
   ✅ AndroidManifest updated
   ✅ App rebuilt

SUCCESS! 🎉

*/
