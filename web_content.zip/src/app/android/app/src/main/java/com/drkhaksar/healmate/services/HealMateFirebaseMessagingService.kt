package com.drkhaksar.healmate.services

import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.media.RingtoneManager
import androidx.core.app.NotificationCompat
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage
import com.drkhaksar.healmate.R

/**
 * HealMate Firebase Cloud Messaging Service
 * د Push Notifications لپاره
 */
class HealMateFirebaseMessagingService : FirebaseMessagingService() {

    /**
     * د نوي FCM token ترلاسه کول
     */
    override fun onNewToken(token: String) {
        super.onNewToken(token)
        android.util.Log.d(TAG, "New FCM Token: $token")
        
        // Token په server کې upload کړئ
        sendTokenToServer(token)
        
        // Token په local storage کې ذخیره کړئ
        saveTokenToPreferences(token)
    }

    /**
     * د Push Notification ترلاسه کول
     */
    override fun onMessageReceived(remoteMessage: RemoteMessage) {
        super.onMessageReceived(remoteMessage)
        
        android.util.Log.d(TAG, "Message received from: ${remoteMessage.from}")

        // د data payload چیک کول
        if (remoteMessage.data.isNotEmpty()) {
            android.util.Log.d(TAG, "Message data payload: ${remoteMessage.data}")
            
            // د data handle کول
            handleDataPayload(remoteMessage.data)
        }

        // د notification payload چیک کول
        remoteMessage.notification?.let {
            android.util.Log.d(TAG, "Message Notification Body: ${it.body}")
            
            // Notification display کول
            showNotification(
                title = it.title ?: "HealMate",
                message = it.body ?: "",
                data = remoteMessage.data
            )
        }
    }

    /**
     * د Notification display کول
     */
    private fun showNotification(
        title: String,
        message: String,
        data: Map<String, String>
    ) {
        // د notification type په اساس channel ID ټاکل
        val channelId = when (data["type"]) {
            "medicine_reminder" -> "healmate_medicine_channel"
            "appointment" -> "healmate_appointment_channel"
            "emergency" -> "healmate_emergency_channel"
            "health_tip" -> "healmate_health_tips_channel"
            else -> "healmate_default_channel"
        }

        // Intent جوړول
        val intent = packageManager.getLaunchIntentForPackage(packageName)?.apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
            // د data extras اضافه کول
            data.forEach { (key, value) ->
                putExtra(key, value)
            }
        }

        val pendingIntent = PendingIntent.getActivity(
            this,
            0,
            intent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        // د notification sound
        val defaultSoundUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)

        // Notification builder
        val notificationBuilder = NotificationCompat.Builder(this, channelId)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle(title)
            .setContentText(message)
            .setAutoCancel(true)
            .setSound(defaultSoundUri)
            .setContentIntent(pendingIntent)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setStyle(NotificationCompat.BigTextStyle().bigText(message))

        // د notification icon د type په اساس
        when (data["type"]) {
            "medicine_reminder" -> {
                notificationBuilder.setColor(getColor(R.color.colorAccent))
            }
            "emergency" -> {
                notificationBuilder.setColor(getColor(R.color.emergencyRed))
                notificationBuilder.priority = NotificationCompat.PRIORITY_MAX
            }
            "health_tip" -> {
                notificationBuilder.setColor(getColor(R.color.categoryGreen))
            }
        }

        val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        
        // Notification ID د unique کولو لپاره
        val notificationId = System.currentTimeMillis().toInt()
        
        notificationManager.notify(notificationId, notificationBuilder.build())
    }

    /**
     * د Data payload handle کول
     */
    private fun handleDataPayload(data: Map<String, String>) {
        val type = data["type"]
        
        when (type) {
            "medicine_reminder" -> {
                // د درملو یادونې handle کول
                android.util.Log.d(TAG, "Medicine reminder received")
            }
            "appointment" -> {
                // د appointment یادونې handle کول
                android.util.Log.d(TAG, "Appointment reminder received")
            }
            "emergency" -> {
                // د emergency alert handle کول
                android.util.Log.d(TAG, "Emergency alert received")
            }
            "health_tip" -> {
                // د health tip handle کول
                android.util.Log.d(TAG, "Health tip received")
            }
            else -> {
                android.util.Log.d(TAG, "Unknown notification type: $type")
            }
        }
    }

    /**
     * د Token په server کې upload کول
     */
    private fun sendTokenToServer(token: String) {
        // دلته د token په server کې upload کولو logic اضافه کړئ
        // مثلاً: د Firebase Firestore یا REST API په استفاده
        android.util.Log.d(TAG, "Sending token to server: $token")
        
        // Example: د Firestore استعمال
        /*
        val db = FirebaseFirestore.getInstance()
        val userId = FirebaseAuth.getInstance().currentUser?.uid
        
        if (userId != null) {
            db.collection("users").document(userId)
                .update("fcmToken", token)
                .addOnSuccessListener {
                    Log.d(TAG, "Token updated successfully")
                }
                .addOnFailureListener { e ->
                    Log.w(TAG, "Error updating token", e)
                }
        }
        */
    }

    /**
     * د Token په local storage کې ذخیره کول
     */
    private fun saveTokenToPreferences(token: String) {
        val sharedPreferences = getSharedPreferences("healmate_preferences", Context.MODE_PRIVATE)
        sharedPreferences.edit().apply {
            putString("fcm_token", token)
            putLong("fcm_token_timestamp", System.currentTimeMillis())
            apply()
        }
    }

    companion object {
        private const val TAG = "HealMateFCM"
    }
}
