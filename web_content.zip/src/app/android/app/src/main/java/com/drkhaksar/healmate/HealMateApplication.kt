package com.drkhaksar.healmate

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build
import androidx.work.Configuration
import androidx.work.WorkManager
import com.google.android.gms.ads.MobileAds
import com.google.firebase.FirebaseApp
import com.google.firebase.analytics.FirebaseAnalytics
import com.google.firebase.crashlytics.FirebaseCrashlytics
import com.google.firebase.messaging.FirebaseMessaging

/**
 * HealMate Application Class
 * د ډاکټر ابراهیم خاکسار لخوا جوړ شوی
 * د افغانستان بشپړ روغتیایي اپلیکیشن
 */
class HealMateApplication : Application() {

    private lateinit var analytics: FirebaseAnalytics

    override fun onCreate() {
        super.onCreate()
        
        // Firebase Initialize
        initializeFirebase()
        
        // AdMob Initialize
        initializeAdMob()
        
        // Notification Channels جوړول
        createNotificationChannels()
        
        // WorkManager Setup
        setupWorkManager()
        
        // FCM Token ترلاسه کول
        getFCMToken()
    }

    /**
     * د Firebase initialization
     */
    private fun initializeFirebase() {
        try {
            FirebaseApp.initializeApp(this)
            analytics = FirebaseAnalytics.getInstance(this)
            
            // Crashlytics فعالول
            FirebaseCrashlytics.getInstance().setCrashlyticsCollectionEnabled(true)
            
            // د User معلومات سیټ کول
            FirebaseCrashlytics.getInstance().setCustomKey("app_version", BuildConfig.VERSION_NAME)
            FirebaseCrashlytics.getInstance().setCustomKey("app_build", BuildConfig.VERSION_CODE)
            
            // Analytics Event
            analytics.logEvent("app_started", null)
            
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    /**
     * د AdMob initialization
     */
    private fun initializeAdMob() {
        try {
            MobileAds.initialize(this) { initializationStatus ->
                // د initialization status چیک کول
                val statusMap = initializationStatus.adapterStatusMap
                for (adapterClass in statusMap.keys) {
                    val status = statusMap[adapterClass]
                    android.util.Log.d(
                        "AdMob",
                        "Adapter: $adapterClass, Status: ${status?.initializationState}, Description: ${status?.description}"
                    )
                }
                
                // Analytics Event
                analytics.logEvent("admob_initialized", null)
            }
        } catch (e: Exception) {
            e.printStackTrace()
            FirebaseCrashlytics.getInstance().recordException(e)
        }
    }

    /**
     * د Notification Channels جوړول
     */
    private fun createNotificationChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val notificationManager = getSystemService(NotificationManager::class.java)
            
            // د default channel
            val defaultChannel = NotificationChannel(
                "healmate_default_channel",
                "HealMate Notifications",
                NotificationManager.IMPORTANCE_DEFAULT
            ).apply {
                description = "د HealMate عمومي اطلاعیې"
                enableLights(true)
                enableVibration(true)
            }
            
            // د Medicine Reminders channel
            val medicineChannel = NotificationChannel(
                "healmate_medicine_channel",
                "Medicine Reminders",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "د درملو یادونې"
                enableLights(true)
                enableVibration(true)
            }
            
            // د Appointments channel
            val appointmentChannel = NotificationChannel(
                "healmate_appointment_channel",
                "Appointments",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "د وخت ټاکلو یادونې"
                enableLights(true)
                enableVibration(true)
            }
            
            // د Emergency channel
            val emergencyChannel = NotificationChannel(
                "healmate_emergency_channel",
                "Emergency Alerts",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "د بیړني حالت خبرتیاوې"
                enableLights(true)
                enableVibration(true)
                setShowBadge(true)
            }
            
            // د Health Tips channel
            val healthTipsChannel = NotificationChannel(
                "healmate_health_tips_channel",
                "Health Tips",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "د روغتیا ټپونه او نصیحتونه"
                enableLights(false)
                enableVibration(false)
            }
            
            // Channels register کول
            notificationManager?.createNotificationChannel(defaultChannel)
            notificationManager?.createNotificationChannel(medicineChannel)
            notificationManager?.createNotificationChannel(appointmentChannel)
            notificationManager?.createNotificationChannel(emergencyChannel)
            notificationManager?.createNotificationChannel(healthTipsChannel)
        }
    }

    /**
     * د WorkManager setup
     */
    private fun setupWorkManager() {
        try {
            val config = Configuration.Builder()
                .setMinimumLoggingLevel(android.util.Log.INFO)
                .build()
            
            WorkManager.initialize(this, config)
        } catch (e: Exception) {
            e.printStackTrace()
            FirebaseCrashlytics.getInstance().recordException(e)
        }
    }

    /**
     * د FCM Token ترلاسه کول
     */
    private fun getFCMToken() {
        FirebaseMessaging.getInstance().token.addOnCompleteListener { task ->
            if (!task.isSuccessful) {
                android.util.Log.w("FCM", "Fetching FCM token failed", task.exception)
                return@addOnCompleteListener
            }

            // د FCM token ترلاسه کول
            val token = task.result
            android.util.Log.d("FCM", "FCM Token: $token")
            
            // Token په Firebase Crashlytics کې سیټ کول
            FirebaseCrashlytics.getInstance().setCustomKey("fcm_token", token)
            
            // Analytics Event
            analytics.logEvent("fcm_token_obtained", null)
        }
    }

    companion object {
        const val TAG = "HealMateApp"
        const val SHARED_PREFS_NAME = "healmate_preferences"
    }
}
