# HealMate ProGuard Rules

# Keep Firebase classes
-keep class com.google.firebase.** { *; }
-keep class com.google.android.gms.** { *; }

# Keep AndroidBrowserHelper (TWA)
-keep class com.google.androidbrowserhelper.** { *; }

# Keep AdMob
-keep class com.google.android.gms.ads.** { *; }

# Keep application class
-keep class com.drkhaksar.healmate.** { *; }

# Keep Kotlin coroutines
-keepclassmembernames class kotlinx.** {
    volatile <fields>;
}

# Keep WorkManager
-keep class androidx.work.** { *; }

# Remove logging in release
-assumenosideeffects class android.util.Log {
    public static *** d(...);
    public static *** v(...);
}
