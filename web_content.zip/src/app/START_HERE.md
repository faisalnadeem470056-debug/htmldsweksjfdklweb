# 🎯 دلته پیل وکړئ!
# START HERE!

---

## 🚀 د HealMate APK جوړولو بشپړ لارښود

---

## ❓ ستاسو مسله:

تاسو Vercel ته د Figma URL نشئ ورکولی ✖️  
**حل:** Vercel CLI وکاروئ یا GitHub ✅

---

## 🎯 2 لارې - غوره کړئ یوه:

---

### 🟢 لاره 1: Vercel CLI (سپارښتنه - 5 دقیقې)

**ښه لپاره:** ګړندۍ deployment، بغیر GitHub

📖 **بشپړ لارښود:** [DEPLOY_NOW_5MIN.md](./DEPLOY_NOW_5MIN.md)

#### ګړندۍ ګامونه:

```bash
# 1. Install
npm install -g vercel

# 2. Login
vercel login

# 3. د folder ته ورشئ
cd /path/to/healmate-app

# 4. Deploy
vercel --prod

# 5. ✅ URL ترلاسه کړئ!
```

**تفصیلات:** [VERCEL_CLI_DEPLOY.md](./VERCEL_CLI_DEPLOY.md)

---

### 🔵 لاره 2: GitHub + Vercel (10 دقیقې)

**ښه لپاره:** Automatic deployments، د راتلونکي لپاره

📖 **بشپړ لارښود:** [GITHUB_VERCEL_DEPLOY.md](./GITHUB_VERCEL_DEPLOY.md)

#### ګړندۍ ګامونه:

```bash
# 1. GitHub repository جوړ کړئ
# 2. Git install کړئ
# 3. Code push کړئ:

git init
git add .
git commit -m "Initial commit"
git remote add origin https://github.com/USERNAME/healmate-app.git
git push -u origin main

# 4. Vercel سره connect کړئ
# 5. ✅ اوتومات deploy!
```

**تفصیلات:** [GITHUB_VERCEL_DEPLOY.md](./GITHUB_VERCEL_DEPLOY.md)

---

## 📱 د APK جوړول (وروسته د Deployment)

کله چې Vercel URL ترلاسه شو:

### PWABuilder سره (2 دقیقې):

```
1. https://www.pwabuilder.com ته ورشئ
2. ستاسو URL داخل کړئ
3. "Start" کلیک وکړئ
4. Android → Generate
5. Download AAB/APK
```

📖 **تفصیلات:** [APK_BUILD_NOW.md](./APK_BUILD_NOW.md)

---

## 🏪 Play Store Upload

د APK وروسته:

```
1. https://play.google.com/console ته ورشئ
2. App create کړئ
3. Screenshots upload کړئ (4-8)
4. Feature graphic upload کړئ
5. AAB upload کړئ
6. Submit!
```

📖 **بشپړ لارښود:** [APK_BUILD_NOW.md](./APK_BUILD_NOW.md) (Play Store section)

---

## 📚 ټول Documentation:

| فایل | موضوع | وخت |
|------|-------|------|
| [DEPLOY_NOW_5MIN.md](./DEPLOY_NOW_5MIN.md) | ګړندۍ Deploy | 5 min |
| [VERCEL_CLI_DEPLOY.md](./VERCEL_CLI_DEPLOY.md) | Vercel CLI تفصیلي | 10 min |
| [GITHUB_VERCEL_DEPLOY.md](./GITHUB_VERCEL_DEPLOY.md) | GitHub Setup | 15 min |
| [APK_BUILD_NOW.md](./APK_BUILD_NOW.md) | APK جوړول | 5 min |
| [ICON_SETUP_GUIDE.md](./ICON_SETUP_GUIDE.md) | Icons Setup | 10 min |
| [QUICK_START.md](./QUICK_START.md) | بشپړ لاره | 30 min |
| [README.md](./README.md) | Project Info | - |

---

## ✅ Complete Workflow:

```
Step 1: د لارې غوره کول
        ↓
     [Vercel CLI] یا [GitHub]
        ↓
Step 2: Deployment
        ↓
    ⏳ 5-10 دقیقې
        ↓
Step 3: URL ترلاسه کول
        ↓
    https://healmate-app.vercel.app ✅
        ↓
Step 4: PWABuilder
        ↓
    APK/AAB Download ✅
        ↓
Step 5: Screenshots جوړول
        ↓
    1080x1920 × 4-8 images ✅
        ↓
Step 6: Play Console
        ↓
    Upload AAB ✅
        ↓
Step 7: Submit
        ↓
    Review (2-7 days)
        ↓
🎉 LIVE ON PLAY STORE! 🇦🇫
```

---

## 🎯 ستاسو د اوسنۍ مسلې حل:

### ❌ مسله: "Invalid repository URL" په Vercel کې

**سبب:** تاسو Figma URL کاروئ

**حل:** 2 options:

#### Option 1: Vercel CLI (ګړندۍ)
```bash
npm install -g vercel
vercel login
cd /path/to/healmate-app
vercel --prod
```

#### Option 2: GitHub (د راتلونکي لپاره ښه)
```bash
# 1. GitHub repository جوړ کړئ
# 2. Code push کړئ
# 3. Vercel سره connect کړئ
```

---

## 📞 د مرستې لپاره:

### مسله په Deployment کې:
- 📖 [VERCEL_CLI_DEPLOY.md](./VERCEL_CLI_DEPLOY.md) وګورئ
- 🌐 https://vercel.com/docs

### مسله په APK کې:
- 📖 [APK_BUILD_NOW.md](./APK_BUILD_NOW.md) وګورئ
- 🌐 https://www.pwabuilder.com/

### مسله په Play Store کې:
- 📖 [APK_BUILD_NOW.md](./APK_BUILD_NOW.md) (Store Listing)
- 🌐 https://support.google.com/googleplay

### نور مرسته:
- 📧 Email: ibrahimkhaksar.it@gmail.com
- 📱 Phone: +93 783 040 441 / +93 779 494 512

---

## 💡 د بریا لپاره Tips:

### 1. د Deployment لپاره:
- ✅ Vercel CLI کاروئ (ترټولو اسانه)
- ✅ یا GitHub کاروئ (د automatic deploys لپاره)
- ❌ د Figma URL په Vercel کې مه کاروئ

### 2. د PWABuilder لپاره:
- ✅ Deployed URL کاروئ (https://healmate-app.vercel.app)
- ✅ manifest.json valid وي (✅ لا دمخه سم دی!)
- ✅ Icons موجود وي (✅ لا دمخه دي!)

### 3. د Play Store لپاره:
- ✅ Screenshots (1080x1920)
- ✅ Feature Graphic (1024x500)
- ✅ App Description (✅ تیار دی!)
- ✅ Privacy Policy URL

---

## 🎊 اوس تاسو څه کوئ؟

### ګام 1: غوره کړئ:

**که تاسو ګړندۍ deployment غواړئ:**
👉 [DEPLOY_NOW_5MIN.md](./DEPLOY_NOW_5MIN.md) ته ورشئ

**که تاسو د GitHub سره کار غواړئ:**
👉 [GITHUB_VERCEL_DEPLOY.md](./GITHUB_VERCEL_DEPLOY.md) ته ورشئ

---

## 🚀 Quick Commands:

### د Vercel CLI:
```bash
npm install -g vercel
vercel login
cd /path/to/healmate-app
vercel --prod
```

### د GitHub:
```bash
git init
git add .
git commit -m "Initial commit"
git remote add origin YOUR_REPO_URL
git push -u origin main
```

---

## 🎯 Final Checklist:

- [ ] Vercel CLI installed یا GitHub setup
- [ ] App deployed شو
- [ ] URL ترلاسه شو
- [ ] PWABuilder test کړ
- [ ] APK download کړ
- [ ] Screenshots چمتو کړئ
- [ ] Play Console ته upload کړئ

---

## 🇦🇫 د افغانستان لپاره!

**HealMate - د روغتیا ستا ملګری**

د افغانستان میلیونونو خلکو ته د روغتیا خدمات په ګوتو کې! 📱❤️

---

**اوس پیل کړئ! 🚀**

👉 [DEPLOY_NOW_5MIN.md](./DEPLOY_NOW_5MIN.md) - ترټولو ګړندۍ لاره!
