# 🚀 د Bravo Studio بدیل - د APK جوړول | Bravo Studio Alternative

---

## ⚠️ مهم یادونه | Important Note

**Bravo Studio** او **HealMate** دوه مختلف شیان دي:

### ❌ Bravo Studio:
- یو no-code platform
- یوازې د Figma designs جوړوي
- د Figma لینک ته اړتیا لري
- د HealMate سره کار نه کوي

### ✅ HealMate:
- بشپړ React/TypeScript web application
- بشپړ کوډ شوی
- د Firebase سره وصل
- د Capacitor سره APK جوړولای شي

---

## 🎯 د APK جوړولو درې لارې | 3 Ways to Build APK

---

## 1️⃣ **د Capacitor استعمال (سپارښتنه شوی) ⭐**

دا ترټولو ښه لاره ده ځکه چې:
- ✅ Native Android/iOS APK جوړوي
- ✅ د Firebase بشپړ ملاتړ
- ✅ د Play Store لپاره چمتو
- ✅ تر ټولو معتبر

### قدمونه:

#### A. Capacitor Install کړئ

```bash
# 1. Capacitor install کړئ
npm install @capacitor/core @capacitor/cli
npm install @capacitor/android @capacitor/ios

# 2. Capacitor initialize کړئ
npx cap init "HealMate" "com.healmate.app"

# 3. د Web app build کړئ
npm run build

# 4. Android platform اضافه کړئ
npx cap add android

# 5. د Web build څخه Android sync کړئ
npx cap sync android

# 6. Android Studio خلاص کړئ
npx cap open android
```

#### B. Android Studio کې APK جوړ کړئ

```bash
1. Android Studio خلاص کیږي
2. Build → Generate Signed Bundle / APK کلیک کړئ
3. APK انتخاب کړئ → Next
4. Keystore جوړ کړئ (که نه وي):
   - Create new...
   - Location: د خپل project پوښه
   - Password: یو قوي password
   - Alias: healmate-key
   - Validity: 25 years
5. Next → Release → Finish
6. APK په app/release/ پوښه کې وي
```

#### C. د Capacitor Config تنظیم کړئ

په `capacitor.config.ts` کې:

```typescript
import { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.healmate.app',
  appName: 'HealMate',
  webDir: 'dist',
  server: {
    androidScheme: 'https',
    cleartext: true
  },
  plugins: {
    SplashScreen: {
      launchShowDuration: 2000,
      backgroundColor: "#10b981",
      showSpinner: false
    }
  }
};

export default config;
```

---

## 2️⃣ **د Expo (React Native) استعمال**

که تاسو د پخوا څخه React Native غواړئ:

```bash
# 1. Expo install کړئ
npm install -g expo-cli

# 2. نوی Expo project جوړ کړئ
expo init HealMateNative
cd HealMateNative

# 3. ستاسو د HealMate components کاپي کړئ
# (دا یو لوی کار دی - سپارښتنه نه کیږي)

# 4. Build کړئ
expo build:android
```

**⚠️ یادونه:** دا ډیر کار دی ځکه چې تاسو باید بشپړ app بیا ولیکئ.

---

## 3️⃣ **د Cordova استعمال**

د Cordova زاړه ده خو کار کوي:

```bash
# 1. Cordova install کړئ
npm install -g cordova

# 2. نوی Cordova project
cordova create HealMateCordova com.healmate.app HealMate
cd HealMateCordova

# 3. Android platform
cordova platform add android

# 4. ستاسو د build files کاپي کړئ
# dist/ فولډر ته www/ کاپي کړئ

# 5. Build
cordova build android --release
```

---

## 🎖️ د Capacitor مثال - بشپړ Setup

زه به تاسو لپاره یو بشپړ Capacitor setup جوړ کړم:

### 1. د Package.json کې Scripts اضافه کړئ:

```json
{
  "scripts": {
    "build": "vite build",
    "cap:init": "npx cap init HealMate com.healmate.app",
    "cap:add:android": "npx cap add android",
    "cap:sync": "npm run build && npx cap sync",
    "cap:open:android": "npx cap open android",
    "cap:build": "npm run build && npx cap sync && npx cap open android"
  }
}
```

### 2. د Capacitor پلګ انونه:

```bash
# د Firebase لپاره
npm install @capacitor-firebase/authentication
npm install @capacitor-firebase/firestore
npm install @capacitor-firebase/storage

# د AdMob لپاره
npm install @capacitor-community/admob

# د Network لپاره
npm install @capacitor/network

# د Camera لپاره (که ضرورت وي)
npm install @capacitor/camera
```

### 3. د Android Permissions:

په `android/app/src/main/AndroidManifest.xml` کې:

```xml
<manifest>
  <uses-permission android:name="android.permission.INTERNET" />
  <uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" />
  <uses-permission android:name="android.permission.CAMERA" />
  <uses-permission android:name="android.permission.READ_EXTERNAL_STORAGE" />
  <uses-permission android:name="android.permission.WRITE_EXTERNAL_STORAGE" />
  
  <application>
    <!-- ... -->
  </application>
</manifest>
```

---

## 📱 د APK Build Complete Workflow

```bash
# Step 1: د Project تیاری
npm install

# Step 2: د Capacitor Setup
npm install @capacitor/core @capacitor/cli @capacitor/android
npx cap init "HealMate" "com.healmate.app"

# Step 3: د Web Build
npm run build

# Step 4: د Android اضافه او Sync
npx cap add android
npx cap sync android

# Step 5: Android Studio خلاص کړئ
npx cap open android

# Step 6: په Android Studio کې:
# Build → Generate Signed Bundle / APK → APK → Next
# Create Keystore → Fill details → Next → Release → Finish

# Step 7: APK Location:
# android/app/release/app-release.apk
```

---

## 🆚 د Bravo Studio او Capacitor توپیر

| Feature | Bravo Studio | Capacitor (HealMate) |
|---------|--------------|----------------------|
| **Coding** | ❌ No code | ✅ Full code |
| **Figma Dependency** | ✅ Required | ❌ Not needed |
| **Customization** | ⚠️ Limited | ✅ Unlimited |
| **Firebase** | ⚠️ Basic | ✅ Full support |
| **Native Features** | ⚠️ Limited | ✅ All native APIs |
| **Cost** | 💰 Monthly fee | ✅ Free (open source) |
| **Performance** | ⚠️ Medium | ✅ High |
| **Play Store** | ✅ Yes | ✅ Yes |
| **Updates** | ⚠️ Platform dependent | ✅ You control |

---

## ⚡ د Quick APK Build (1 Hour)

که تاسو ګړندي APK غواړئ:

```bash
# 1. Install (5 min)
npm install @capacitor/core @capacitor/cli @capacitor/android

# 2. Init (2 min)
npx cap init "HealMate" "com.healmate.app"

# 3. Build (5 min)
npm run build

# 4. Add Android (10 min)
npx cap add android

# 5. Sync (5 min)
npx cap sync android

# 6. Open Android Studio (2 min)
npx cap open android

# 7. Generate APK (30 min)
# Android Studio → Build → Generate Signed Bundle/APK
```

**Total: ~1 Hour** ⏱️

---

## 🎯 د سپارښتنې | Recommendations

### ✅ د HealMate لپاره بهترین لاره:

**Capacitor استعمال کړئ** ځکه چې:

1. ✅ ستاسو بشپړ React code ساتي
2. ✅ د Firebase بشپړ کار کوي
3. ✅ د Play Store لپاره معیاري APK
4. ✅ د iOS هم کار کوي
5. ✅ بشپړ customization
6. ✅ مفت او open source

### ❌ Bravo Studio استعمال مه کوئ:

1. ❌ تاسو باید بشپړ app په Figma کې redesign کړئ
2. ❌ ټول functionality له لاسه ځي
3. ❌ د Firebase integration نه کیږي
4. ❌ Monthly subscription ته اړتیا لري
5. ❌ محدود customization

---

## 📞 د مرستې لپاره

### د Capacitor Official Docs:
- 🌐 https://capacitorjs.com/docs
- 📱 https://capacitorjs.com/docs/android

### د نورو مسلو لپاره:
- 📧 Email: ibrahimkhaksar.it@gmail.com
- 📱 Phone 1: +93783040441
- 📱 Phone 2: +93779494512

---

## 🎉 نتیجه | Conclusion

**Bravo Studio** د HealMate لپاره کار نه کوي ځکه چې دوه مختلف platforms دي.

**✅ د حل لپاره: Capacitor استعمال کړئ**

دا به:
- ستاسو بشپړ React app ساتي
- Native Android APK جوړوي
- د Play Store لپاره چمتو وي
- بشپړ مفت وي

---

**🚀 د بریالیتوب سره، HealMate Development Team** 💚

په راتلونکي پیغام کې زه به د Capacitor بشپړ setup code درکړم که تاسو غواړئ!
