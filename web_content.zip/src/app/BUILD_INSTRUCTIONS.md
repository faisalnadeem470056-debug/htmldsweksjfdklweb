# 📱 د HealMate APK جوړولو بشپړ لارښوونې
# HealMate APK Build Instructions

## 🎯 لاره 1: PWABuilder (اسانه او ګړندۍ - سپارښتنه شوې)

### قدم 1: د اپلیکیشن Deploy کول
```bash
# تاسو باید دا اپلیکیشن په یوه URL deploy کړئ (مثلاً Vercel, Netlify, Firebase Hosting)

# د Vercel لپاره:
npm install -g vercel
vercel login
vercel --prod

# یا د Netlify لپاره:
npm install -g netlify-cli
netlify login
netlify deploy --prod
```

### قدم 2: PWABuilder کارول
1. https://www.pwabuilder.com/ ته ورشئ
2. خپل د deployed app URL داخل کړئ
3. "Start" کلیک وکړئ
4. د "Android" package غوره کړئ
5. د Android options تنظیم کړئ:
   - Package ID: `com.healmate.afghanistan`
   - App Name: `HealMate`
   - App Version: `1.0.0`
   - Signing Key: د Google Play Console څخه یو نوی keystore جوړ کړئ
6. "Generate" کلیک وکړئ
7. APK یا AAB file download کړئ

---

## 🎯 لاره 2: Capacitor (د لوی customization لپاره)

### قدم 1: Capacitor Install کول
```bash
npm install @capacitor/core @capacitor/cli
npm install @capacitor/android
npx cap init
```

### قدم 2: Configuration
د `capacitor.config.json` file تنظیم کړئ:
```json
{
  "appId": "com.healmate.afghanistan",
  "appName": "HealMate",
  "webDir": "dist",
  "bundledWebRuntime": false,
  "server": {
    "androidScheme": "https"
  }
}
```

### قدم 3: د Android Platform اضافه کول
```bash
# Build the app first
npm run build

# Add Android platform
npx cap add android

# Copy web assets to native project
npx cap copy android

# Sync capacitor
npx cap sync android
```

### قدم 4: د Android Studio کې خلاصول
```bash
npx cap open android
```

### قدم 5: APK جوړول
Android Studio کې:
1. `Build` → `Build Bundle(s) / APK(s)` → `Build APK(s)`
2. APK به په `android/app/build/outputs/apk/` کې وي

---

## 🎯 لاره 3: Bubblewrap (Google کې ملاتړ شوی)

### Installation
```bash
npm install -g @bubblewrap/cli
```

### د APK جوړول
```bash
# Initialize
bubblewrap init --manifest https://your-app-url.com/manifest.json

# Build APK
bubblewrap build

# د Google Play لپاره AAB جوړول
bubblewrap build --buildMode release
```

---

## 📋 د Icon Files جوړول

تاسو باید دا icon files په `/public/` folder کې جوړ کړئ:

### Icons List:
- `icon-72x72.png`
- `icon-96x96.png`
- `icon-128x128.png`
- `icon-144x144.png`
- `icon-152x152.png`
- `icon-192x192.png`
- `icon-384x384.png`
- `icon-512x512.png`

### د Icons جوړولو اسانه لاره:
1. https://www.pwabuilder.com/imageGenerator ته ورشئ
2. د HealMate لوګو (د Heart icon) upload کړئ
3. ټول icons download کړئ
4. په `/public/` folder کې یې کېږدئ

---

## 🔐 د Signing Key جوړول (Play Store لپاره اړین)

```bash
# د Java JDK install کړئ که نه وي

# Keystore جوړول
keytool -genkey -v -keystore healmate-release-key.keystore -alias healmate -keyalg RSA -keysize 2048 -validity 10000

# د Keystore معلومات:
# - Password: یو قوي password غوره کړئ
# - Name: Ibrahim Khaksar
# - Organization: HealMate
# - Country: AF
```

---

## 📤 د Play Store ته Upload کول

### قدم 1: Google Play Console Setup
1. https://play.google.com/console ته ورشئ
2. یو نوی اپلیکیشن جوړ کړئ
3. د اپلیکیشن معلومات ډک کړئ:
   - Title: **HealMate - د افغانستان روغتیا اپلیکیشن**
   - Short description: **د دوکتورانو، روغتونونو، او روغتیا مشورې لپاره**
   - Full description: (بشپړ توضیحات په درې ژبو کې)

### قدم 2: Screenshots (اړین)
تاسو باید دا screenshots واخلئ:
- د موبایل لپاره (Phone): 4-8 screenshots (1080x1920px یا 720x1280px)
- د Tablet لپاره: 2-8 screenshots (1200x1920px)

### قدم 3: App Content Rating
د health category لپاره:
- Violence: None
- Sexual Content: None
- Language: None
- Health/Medical: **Yes - Health Information App**

### قدم 4: Privacy Policy (اړین)
تاسو باید یو Privacy Policy page جوړ کړئ:
```
د HealMate Privacy Policy

1. د معلوماتو راټولول:
   - موږ د کاروونکو شخصي معلومات نه راټولوو
   - یوازې د app usage analytics راټولوو

2. د معلوماتو کارول:
   - د app د performance بهتر کولو لپاره

3. د ثالث پوهانو:
   - موږ ستاسو معلومات نورو سره شریک نکوو

4. اړیکه:
   - Email: ibrahimkhaksar.it@gmail.com
   - Phone: +93 783 040 441
```

### قدم 5: د APK/AAB Upload کول
1. د "Production" track غوره کړئ
2. APK یا AAB file upload کړئ
3. د "Review" استازي کړئ
4. Google به ستاسو app review کړي (2-7 ورځې)

---

## 🎨 د App Store Listing

### App Icon (512x512px):
- د Heart icon سره د HealMate لوګو
- Background: Gradient (Red to Pink)

### Feature Graphic (1024x500px):
```
د App Screenshot + د HealMate لوګو + Text:
"د افغانستان بشپړ روغتیا اپلیکیشن"
"Afghanistan's Complete Health App"
```

### Screenshots څه ښکاره کړي:
1. Home screen د categories سره
2. Doctors Directory
3. Hospitals Directory
4. Medicine Guide
5. Community Feed
6. Language Selection (پښتو، دری، English)

---

## ⚠️ مهم یادښتونه

### د Play Store Requirements:
✅ Target SDK: Android 13 (API level 33) یا لوړ
✅ Min SDK: Android 5.0 (API level 21)
✅ 64-bit support: اړین
✅ Privacy Policy: اړین
✅ App Content Rating: اړین
✅ Signing Key: اړین

### د App Size:
- د PWA approach سره: 5-10 MB
- د Capacitor سره: 15-25 MB
- د Flutter سره: 20-40 MB

### د Testing:
```bash
# د Android device سره test کول
adb devices
adb install app-release.apk
```

---

## 🚀 د Deployment بهترین طریقه

### سپارښتنه شوې Workflow:
1. **Development**: دلته په Figma Make کې
2. **Deploy Web Version**: Vercel/Netlify ته
3. **Generate APK**: PWABuilder سره (اسانه) یا Capacitor سره (advanced)
4. **Test**: د Android emulator یا فزیکي device کې
5. **Submit**: Google Play Console ته

---

## 📞 د مرستې لپاره

که تاسو کوم مسله لرئ:
- Email: ibrahimkhaksar.it@gmail.com
- Phone: +93 783 040 441 / +93 779 494 512

---

## 🎉 بریا!

تاسو اوس خپل HealMate اپلیکیشن Play Store ته publish کولی شئ! 🎊

ستاسو اپلیکیشن به د افغانستان د میلیونونو خلکو لپاره ګټور وي! 🇦🇫❤️
