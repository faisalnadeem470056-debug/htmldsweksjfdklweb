import { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { 
  Users, Search, Mail, Calendar, Shield, 
  CheckCircle2, XCircle, Trash2, Eye, Download
} from 'lucide-react';
import { Button } from './ui/button';
import { Card } from './ui/card';
import { Input } from './ui/input';

interface RegisteredUsersPanelProps {
  language: 'ps' | 'fa' | 'en';
}

interface User {
  id: string;
  email: string;
  name: string;
  phone?: string;
  createdAt: string;
  isPremium?: boolean;
  profileImage?: string;
}

export function RegisteredUsersPanel({ language }: RegisteredUsersPanelProps) {
  const [users, setUsers] = useState<User[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [filteredUsers, setFilteredUsers] = useState<User[]>([]);

  const texts = {
    ps: {
      title: '👥 راجستر شوي کاروونکي',
      subtitle: 'د ټولو راجستر شوو کاروونکو لیست',
      totalUsers: 'ټول کاروونکي:',
      search: 'پلټنه...',
      email: 'برېښنالیک',
      name: 'نوم',
      joinDate: 'د راجستر نېټه',
      premium: 'پریمیم',
      actions: 'عملونه',
      delete: 'ډیلیټ',
      view: 'لیدل',
      export: 'اکسپورټ',
      noUsers: 'هیڅ کاروونکی راجستر شوی نه دی',
      deleteConfirm: 'ایا تاسو ډاډه یاست چې غواړئ دا کاروونکی ډیلیټ کړئ؟',
      yes: 'هو',
      no: 'نه'
    },
    fa: {
      title: '👥 کاربران ثبت‌شده',
      subtitle: 'لیست تمام کاربران ثبت‌شده',
      totalUsers: 'تعداد کاربران:',
      search: 'جستجو...',
      email: 'ایمیل',
      name: 'نام',
      joinDate: 'تاریخ ثبت‌نام',
      premium: 'پریمیم',
      actions: 'عملیات',
      delete: 'حذف',
      view: 'مشاهده',
      export: 'خروجی',
      noUsers: 'هیچ کاربری ثبت نشده است',
      deleteConfirm: 'آیا مطمئن هستید که می‌خواهید این کاربر را حذف کنید؟',
      yes: 'بله',
      no: 'خیر'
    },
    en: {
      title: '👥 Registered Users',
      subtitle: 'List of all registered users',
      totalUsers: 'Total Users:',
      search: 'Search...',
      email: 'Email',
      name: 'Name',
      joinDate: 'Join Date',
      premium: 'Premium',
      actions: 'Actions',
      delete: 'Delete',
      view: 'View',
      export: 'Export',
      noUsers: 'No users registered yet',
      deleteConfirm: 'Are you sure you want to delete this user?',
      yes: 'Yes',
      no: 'No'
    }
  };

  const t = texts[language];

  useEffect(() => {
    loadUsers();
  }, []);

  useEffect(() => {
    if (searchTerm) {
      const filtered = users.filter(user => 
        user.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        user.email.toLowerCase().includes(searchTerm.toLowerCase())
      );
      setFilteredUsers(filtered);
    } else {
      setFilteredUsers(users);
    }
  }, [searchTerm, users]);

  const loadUsers = () => {
    const storedUsers = JSON.parse(localStorage.getItem('healmate_users') || '[]');
    setUsers(storedUsers);
    setFilteredUsers(storedUsers);
  };

  const deleteUser = (userId: string) => {
    if (confirm(t.deleteConfirm)) {
      const updatedUsers = users.filter(u => u.id !== userId);
      localStorage.setItem('healmate_users', JSON.stringify(updatedUsers));
      setUsers(updatedUsers);
    }
  };

  const exportUsers = () => {
    const dataStr = JSON.stringify(users, null, 2);
    const dataBlob = new Blob([dataStr], { type: 'application/json' });
    const url = URL.createObjectURL(dataBlob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `healmate_users_${new Date().toISOString().split('T')[0]}.json`;
    link.click();
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    });
  };

  return (
    <div className="w-full p-6 bg-gradient-to-br from-indigo-50 via-purple-50 to-pink-50 min-h-screen">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="max-w-7xl mx-auto"
      >
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-4xl mb-2 bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent">
            {t.title}
          </h1>
          <p className="text-gray-600">{t.subtitle}</p>
        </div>

        {/* Stats & Actions */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
          <Card className="p-6 bg-gradient-to-br from-blue-500 to-blue-600 text-white">
            <div className="flex items-center justify-between">
              <div>
                <div className="text-sm opacity-90 mb-1">{t.totalUsers}</div>
                <div className="text-4xl">{users.length}</div>
              </div>
              <Users className="w-12 h-12 opacity-50" />
            </div>
          </Card>

          <Card className="p-6 bg-gradient-to-br from-purple-500 to-purple-600 text-white">
            <div className="flex items-center justify-between">
              <div>
                <div className="text-sm opacity-90 mb-1">{t.premium}</div>
                <div className="text-4xl">
                  {users.filter(u => u.isPremium).length}
                </div>
              </div>
              <Shield className="w-12 h-12 opacity-50" />
            </div>
          </Card>

          <Card className="p-6 bg-gradient-to-br from-green-500 to-green-600 text-white">
            <Button
              onClick={exportUsers}
              className="w-full bg-white/20 hover:bg-white/30 text-white border-0 h-full"
            >
              <Download className="w-5 h-5 mr-2" />
              {t.export}
            </Button>
          </Card>
        </div>

        {/* Search */}
        <Card className="p-4 mb-6">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
            <Input
              type="text"
              placeholder={t.search}
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>
        </Card>

        {/* Users Table */}
        {filteredUsers.length > 0 ? (
          <Card className="overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-gradient-to-r from-purple-500 to-pink-500 text-white">
                  <tr>
                    <th className="px-6 py-4 text-left">#</th>
                    <th className="px-6 py-4 text-left">{t.name}</th>
                    <th className="px-6 py-4 text-left">{t.email}</th>
                    <th className="px-6 py-4 text-left">{t.joinDate}</th>
                    <th className="px-6 py-4 text-left">{t.premium}</th>
                    <th className="px-6 py-4 text-left">{t.actions}</th>
                  </tr>
                </thead>
                <tbody>
                  {filteredUsers.map((user, index) => (
                    <motion.tr
                      key={user.id}
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: index * 0.05 }}
                      className="border-b border-gray-100 hover:bg-purple-50 transition-colors"
                    >
                      <td className="px-6 py-4">{index + 1}</td>
                      <td className="px-6 py-4">
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 rounded-full bg-gradient-to-br from-purple-500 to-pink-500 flex items-center justify-center text-white">
                            {user.name.charAt(0).toUpperCase()}
                          </div>
                          <span>{user.name}</span>
                        </div>
                      </td>
                      <td className="px-6 py-4">
                        <div className="flex items-center gap-2">
                          <Mail className="w-4 h-4 text-gray-400" />
                          {user.email}
                        </div>
                      </td>
                      <td className="px-6 py-4">
                        <div className="flex items-center gap-2">
                          <Calendar className="w-4 h-4 text-gray-400" />
                          {formatDate(user.createdAt)}
                        </div>
                      </td>
                      <td className="px-6 py-4">
                        {user.isPremium ? (
                          <div className="flex items-center gap-2 text-green-600">
                            <CheckCircle2 className="w-5 h-5" />
                            <span className="text-sm">Premium</span>
                          </div>
                        ) : (
                          <div className="flex items-center gap-2 text-gray-400">
                            <XCircle className="w-5 h-5" />
                            <span className="text-sm">Free</span>
                          </div>
                        )}
                      </td>
                      <td className="px-6 py-4">
                        <div className="flex items-center gap-2">
                          <Button
                            size="sm"
                            variant="outline"
                            className="border-blue-200 text-blue-600 hover:bg-blue-50"
                            onClick={() => {
                              alert(JSON.stringify(user, null, 2));
                            }}
                          >
                            <Eye className="w-4 h-4" />
                          </Button>
                          <Button
                            size="sm"
                            variant="outline"
                            className="border-red-200 text-red-600 hover:bg-red-50"
                            onClick={() => deleteUser(user.id)}
                          >
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </div>
                      </td>
                    </motion.tr>
                  ))}
                </tbody>
              </table>
            </div>
          </Card>
        ) : (
          <Card className="p-12 text-center">
            <Users className="w-16 h-16 text-gray-400 mx-auto mb-4" />
            <h3 className="text-xl text-gray-600 mb-2">{t.noUsers}</h3>
          </Card>
        )}
      </motion.div>
    </div>
  );
}
