import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  ArrowLeft, ChevronRight, Edit, Phone, Calendar, Globe, 
  Bell, Info, Shield, Lock, FileText, ExternalLink, Trash2, 
  Star, LogOut, Crown, Mail, MapPin, User, CheckCircle, X, Eye, EyeOff
} from 'lucide-react';
import { toast } from 'sonner@2.0.3';
import { Button } from './ui/button';
import { Input } from './ui/input';

interface SettingsProps {
  language: 'ps' | 'fa' | 'en';
  onBack: () => void;
  onLanguageChange: (lang: 'ps' | 'fa' | 'en') => void;
  currentUserEmail?: string;
  currentUserName?: string;
  onAdminClick?: () => void;
  onNavigate?: (page: string) => void;
  onLogout?: () => void;
}

export function Settings({ 
  language, 
  onBack, 
  onLanguageChange, 
  currentUserEmail = 'guest@healmate.com',
  currentUserName = 'Guest User',
  onAdminClick,
  onNavigate,
  onLogout
}: SettingsProps) {
  const [notifications, setNotifications] = useState(true);
  const [selectedLanguage, setSelectedLanguage] = useState(language);
  const [expandedItem, setExpandedItem] = useState<number | null>(null);
  const [showPasswordModal, setShowPasswordModal] = useState(false);
  const [showEditProfileModal, setShowEditProfileModal] = useState(false);
  
  // Password change states
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [showCurrentPassword, setShowCurrentPassword] = useState(false);
  const [showNewPassword, setShowNewPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);

  // Edit profile states
  const [editName, setEditName] = useState(currentUserName);
  const [editEmail, setEditEmail] = useState(currentUserEmail);
  const [editPhone, setEditPhone] = useState('');
  const [editBirthday, setEditBirthday] = useState('');

  const isRTL = language === 'ps' || language === 'fa';
  const isOwner = currentUserEmail === 'ibrahimkhaksar.it@gmail.com';

  // Translations
  const translations = {
    ps: {
      settings: 'تنظیمات',
      profile: 'پروفایل',
      account: 'حساب',
      accountSettings: 'د حساب تنظیمات',
      editProfile: 'پروفایل تعدیل',
      premiumSubscription: 'پریمیم اشتراک ترلاسه کړئ',
      preferences: 'ترجیحات',
      appLanguage: 'د اپلیکیشن ژبه',
      selectLanguage: 'ژبه غوره کړئ',
      notifications: 'خبرتیاوې',
      enableNotifications: 'خبرتیاوې فعال کړئ',
      support: 'ملاتړ',
      onlineSupport: 'آنلاین ملاتړ',
      contactSupport: 'ملاتړ سره اړیکه',
      phoneNumber: 'د تلیفون نمبر',
      callUs: 'موږ ته زنګ ووهئ',
      hesabPay: 'حساب پے',
      about: 'په اړه',
      aboutApp: 'د HealMate په اړه',
      version: 'نسخه 1.0.0',
      rateApp: 'اپلیکیشن ریټ کړئ',
      shareExperience: 'خپله تجربه شریکه کړئ',
      legal: 'قانوني',
      termsConditions: 'شرایط او مقررات',
      readTerms: 'شرایط ولولئ',
      privacyPolicy: 'د محرمیت پالیسي',
      privacyInfo: 'ستاسو معلومات محفوظ دي',
      website: 'ویب پاڼه',
      visitWebsite: 'ویب پاڼه وګورئ',
      security: 'امنیت',
      changePassword: 'پټنوم بدل کړئ',
      updatePassword: 'خپل پټنوم تازه کړئ',
      deleteAccount: 'حساب ړنګ کړئ',
      deleteAccountWarning: 'خپل حساب د تل لپاره ړنګ کړئ',
      logout: 'وتل',
      signOut: 'د خپل حساب څخه وتل',
      confirmLogout: 'ایا تاسو ډاډه یاست چې غواړئ ووځئ؟',
      confirmDelete: 'ایا تاسو ډاډه یاست چې غواړئ خپل حساب ړنګ کړئ؟',
      yes: 'هو',
      no: 'نه',
      cancel: 'لغوه',
      save: 'خوندي کړئ',
      close: 'تړل',
      logoutSuccess: '✅ تاسو بریالیتوب سره ووتلئ',
      accountDeleted: '✅ حساب ړنګ شو',
      languageChanged: '✅ ژبه بدله شوه',
      notificationsEnabled: '✅ خبرتیاوې فعال شول',
      notificationsDisabled: '✅ خبرتیاوې غیرفعال شول',
      ownerName: 'ډاکټر ابراهیم خاکسار',
      ownerEmail: 'ibrahimkhaksar.it@gmail.com',
      ownerPhone: '+93779494512',
      pashto: 'پښتو',
      dari: 'دری',
      english: 'انګلیسي',
      admin: 'ادمین پانل',
      currentPassword: 'اوسنی پټنوم',
      newPassword: 'نوی پټنوم',
      confirmNewPassword: 'نوی پټنوم تایید',
      enterCurrentPassword: 'اوسنی پټنوم داخل کړئ',
      enterNewPassword: 'نوی پټنوم داخل کړئ',
      enterConfirmPassword: 'نوی پټنوم بیا داخل کړئ',
      passwordChanged: '✅ پټنوم بریالیتوب سره بدل شو',
      passwordMismatch: '❌ نوي پټنومونه سره برابر نه دي',
      fillAllFields: '❌ ټول ځایونه ډک کړئ',
      passwordTooShort: '❌ پټنوم باید لږترلږه ۶ توري ولري',
      wrongPassword: '❌ اوسنی پټنوم غلط دی',
      name: 'نوم',
      email: 'ایمیل',
      phone: 'تلیفون',
      birthday: 'د زیږون نیټه',
      enterName: 'نوم داخل کړئ',
      enterEmail: 'ایمیل داخل کړئ',
      enterPhone: 'تلیفون داخل کړئ',
      enterBirthday: 'د زیږون نیټه داخل کړئ',
      profileUpdated: '✅ پروفایل تازه شو',
      invalidEmail: '❌ ایمیل سم نه دی'
    },
    fa: {
      settings: 'تنظیمات',
      profile: 'پروفایل',
      account: 'حساب',
      accountSettings: 'تنظیمات حساب',
      editProfile: 'ویرایش پروفایل',
      premiumSubscription: 'اشتراک پریمیم دریافت کنید',
      preferences: 'تنظیمات',
      appLanguage: 'زبان اپلیکیشن',
      selectLanguage: 'زبان را انتخاب کنید',
      notifications: 'اطلاعیه‌ها',
      enableNotifications: 'فعال کردن اطلاعیه‌ها',
      support: 'پشتیبانی',
      onlineSupport: 'پشتیبانی آنلاین',
      contactSupport: 'تماس با پشتیبانی',
      phoneNumber: 'شماره تلفن',
      callUs: 'با ما تماس بگیرید',
      hesabPay: 'حساب پے',
      about: 'درباره',
      aboutApp: 'درباره HealMate',
      version: 'نسخه 1.0.0',
      rateApp: 'امتیاز به اپلیکیشن',
      shareExperience: 'تجربه خود را به اشتراک بگذارید',
      legal: 'قانونی',
      termsConditions: 'قوانین و مقررات',
      readTerms: 'قوانین را بخوانید',
      privacyPolicy: 'سیاست حریم خصوصی',
      privacyInfo: 'داده‌های شما امن است',
      website: 'وب‌سایت',
      visitWebsite: 'بازدید از وب‌سایت',
      security: 'امنیت',
      changePassword: 'تغییر رمز عبور',
      updatePassword: 'رمز عبور خود را به‌روزرسانی کنید',
      deleteAccount: 'حذف حساب',
      deleteAccountWarning: 'حساب خود را برای همیشه حذف کنید',
      logout: 'خروج',
      signOut: 'از حساب خود خارج شوید',
      confirmLogout: 'آیا مطمئن هستید که می‌خواهید خارج شوید؟',
      confirmDelete: 'آیا مطمئن هستید که می‌خواهید حساب خود را حذف کنید؟',
      yes: 'بله',
      no: 'خیر',
      cancel: 'لغو',
      save: 'ذخیره',
      close: 'بستن',
      logoutSuccess: '✅ با موفقیت خارج شدید',
      accountDeleted: '✅ حساب حذف شد',
      languageChanged: '✅ زبان تغییر کرد',
      notificationsEnabled: '✅ اطلاعیه‌ها فعال شدند',
      notificationsDisabled: '✅ اطلاعیه‌ها غیرفعال شدند',
      ownerName: 'دکتر ابراهیم خاکسار',
      ownerEmail: 'ibrahimkhaksar.it@gmail.com',
      ownerPhone: '+93779494512',
      pashto: 'پښتو',
      dari: 'دری',
      english: 'English',
      admin: 'پنل مدیریت',
      currentPassword: 'رمز عبور فعلی',
      newPassword: 'رمز عبور جدید',
      confirmNewPassword: 'تایید رمز عبور جدید',
      enterCurrentPassword: 'رمز عبور فعلی را وارد کنید',
      enterNewPassword: 'رمز عبور جدید را وارد کنید',
      enterConfirmPassword: 'رمز عبور جدید را دوباره وارد کنید',
      passwordChanged: '✅ رمز عبور با موفقیت تغییر کرد',
      passwordMismatch: '❌ رمزهای عبور جدید مطابقت ندارند',
      fillAllFields: '❌ همه فیلدها را پر کنید',
      passwordTooShort: '❌ رمز عبور باید حداقل ۶ کاراکتر باشد',
      wrongPassword: '❌ رمز عبور فعلی اشتباه است',
      name: 'نام',
      email: 'ایمیل',
      phone: 'تلفن',
      birthday: 'تاریخ تولد',
      enterName: 'نام را وارد کنید',
      enterEmail: 'ایمیل را وارد کنید',
      enterPhone: 'تلفن را وارد کنید',
      enterBirthday: 'تاریخ تولد را وارد کنید',
      profileUpdated: '✅ پروفایل به‌روزرسانی شد',
      invalidEmail: '❌ ایمیل نامعتبر است'
    },
    en: {
      settings: 'Settings',
      profile: 'Profile',
      account: 'Account',
      accountSettings: 'Account Settings',
      editProfile: 'Edit Profile',
      premiumSubscription: 'Get Premium Subscription',
      preferences: 'Preferences',
      appLanguage: 'App Language',
      selectLanguage: 'Select Language',
      notifications: 'Notifications',
      enableNotifications: 'Enable Notifications',
      support: 'Support',
      onlineSupport: 'Online Support',
      contactSupport: 'Contact Support',
      phoneNumber: 'Phone Number',
      callUs: 'Call Us',
      hesabPay: 'Hesab Pay',
      about: 'About',
      aboutApp: 'About HealMate',
      version: 'Version 1.0.0',
      rateApp: 'Rate App',
      shareExperience: 'Share your experience',
      legal: 'Legal',
      termsConditions: 'Terms & Conditions',
      readTerms: 'Read our terms',
      privacyPolicy: 'Privacy Policy',
      privacyInfo: 'Your data is safe',
      website: 'Website',
      visitWebsite: 'Visit our website',
      security: 'Security',
      changePassword: 'Change Password',
      updatePassword: 'Update your password',
      deleteAccount: 'Delete Account',
      deleteAccountWarning: 'Permanently delete your account',
      logout: 'Logout',
      signOut: 'Sign out of your account',
      confirmLogout: 'Are you sure you want to logout?',
      confirmDelete: 'Are you sure you want to delete your account?',
      yes: 'Yes',
      no: 'No',
      cancel: 'Cancel',
      save: 'Save',
      close: 'Close',
      logoutSuccess: '✅ Logged out successfully',
      accountDeleted: '✅ Account deleted',
      languageChanged: '✅ Language changed',
      notificationsEnabled: '✅ Notifications enabled',
      notificationsDisabled: '✅ Notifications disabled',
      ownerName: 'Dr. Ibrahim Khaksar',
      ownerEmail: 'ibrahimkhaksar.it@gmail.com',
      ownerPhone: '+93779494512',
      pashto: 'پښتو',
      dari: 'دری',
      english: 'English',
      admin: 'Admin Panel',
      currentPassword: 'Current Password',
      newPassword: 'New Password',
      confirmNewPassword: 'Confirm New Password',
      enterCurrentPassword: 'Enter current password',
      enterNewPassword: 'Enter new password',
      enterConfirmPassword: 'Confirm new password',
      passwordChanged: '✅ Password changed successfully',
      passwordMismatch: '❌ Passwords do not match',
      fillAllFields: '❌ Please fill all fields',
      passwordTooShort: '❌ Password must be at least 6 characters',
      wrongPassword: '❌ Current password is incorrect',
      name: 'Name',
      email: 'Email',
      phone: 'Phone',
      birthday: 'Birthday',
      enterName: 'Enter name',
      enterEmail: 'Enter email',
      enterPhone: 'Enter phone',
      enterBirthday: 'Enter birthday',
      profileUpdated: '✅ Profile updated',
      invalidEmail: '❌ Invalid email'
    }
  };

  const t = translations[language];

  // Load settings
  useEffect(() => {
    const savedNotifications = localStorage.getItem('healmate_notifications') !== 'false';
    setNotifications(savedNotifications);
  }, []);

  // Handle language change
  const handleLanguageChange = (lang: 'ps' | 'fa' | 'en') => {
    setSelectedLanguage(lang);
    onLanguageChange(lang);
    toast.success(t.languageChanged);
    setExpandedItem(null);
  };

  // Handle notifications toggle
  const handleNotificationsToggle = () => {
    const newValue = !notifications;
    setNotifications(newValue);
    localStorage.setItem('healmate_notifications', newValue.toString());
    toast.success(newValue ? t.notificationsEnabled : t.notificationsDisabled);
  };

  // Handle password change
  const handlePasswordChange = () => {
    // Validation
    if (!currentPassword || !newPassword || !confirmPassword) {
      toast.error(t.fillAllFields);
      return;
    }

    if (newPassword.length < 6) {
      toast.error(t.passwordTooShort);
      return;
    }

    if (newPassword !== confirmPassword) {
      toast.error(t.passwordMismatch);
      return;
    }

    // Get stored user
    const storedUser = localStorage.getItem('healmate_user');
    if (storedUser) {
      const user = JSON.parse(storedUser);
      
      // Check current password
      if (user.password !== currentPassword) {
        toast.error(t.wrongPassword);
        return;
      }

      // Update password
      user.password = newPassword;
      localStorage.setItem('healmate_user', JSON.stringify(user));
      
      toast.success(t.passwordChanged);
      setShowPasswordModal(false);
      setCurrentPassword('');
      setNewPassword('');
      setConfirmPassword('');
    }
  };

  // Handle profile update
  const handleProfileUpdate = () => {
    if (!editName || !editEmail) {
      toast.error(t.fillAllFields);
      return;
    }

    // Simple email validation
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(editEmail)) {
      toast.error(t.invalidEmail);
      return;
    }

    // Update profile in localStorage
    const storedUser = localStorage.getItem('healmate_user');
    if (storedUser) {
      const user = JSON.parse(storedUser);
      user.name = editName;
      user.email = editEmail;
      user.phone = editPhone;
      user.birthday = editBirthday;
      localStorage.setItem('healmate_user', JSON.stringify(user));
    }

    toast.success(t.profileUpdated);
    setShowEditProfileModal(false);
    
    // Reload to show updated info
    setTimeout(() => {
      window.location.reload();
    }, 1000);
  };

  // Handle logout
  const handleLogout = () => {
    if (confirm(t.confirmLogout)) {
      if (onLogout) {
        onLogout();
        toast.success(t.logoutSuccess);
      } else {
        localStorage.removeItem('healmate_user');
        toast.success(t.logoutSuccess);
        setTimeout(() => {
          window.location.reload();
        }, 1000);
      }
    }
  };

  // Handle delete account
  const handleDeleteAccount = () => {
    if (confirm(t.confirmDelete)) {
      if (confirm(language === 'ps' ? 'دا عمل بیرته نشي راګرځیدلی!' : language === 'fa' ? 'این عمل غیرقابل بازگشت است!' : 'This action cannot be undone!')) {
        localStorage.removeItem('healmate_user');
        toast.success(t.accountDeleted);
        setTimeout(() => {
          window.location.reload();
        }, 1500);
      }
    }
  };

  const displayName = isOwner ? t.ownerName : currentUserName;
  const displayEmail = isOwner ? t.ownerEmail : currentUserEmail;

  return (
    <div className={`min-h-screen bg-gradient-to-br from-indigo-50 via-purple-50 to-pink-50 pb-28 md:pb-8 ${isRTL ? 'rtl' : 'ltr'}`}>
      {/* Header */}
      <header className="sticky top-0 z-40 backdrop-blur-xl bg-white/80 border-b border-purple-200 shadow-sm">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <button
              onClick={onBack}
              className={`p-2 rounded-xl bg-purple-100 hover:bg-purple-200 transition-all ${isRTL ? 'rotate-180' : ''}`}
            >
              <ArrowLeft className="w-5 h-5 text-purple-700" />
            </button>
            <h1 className="text-xl font-bold bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent">
              {t.settings}
            </h1>
            <button
              onClick={onBack}
              className="p-2 rounded-xl bg-red-100 hover:bg-red-200 transition-all"
            >
              <X className="w-5 h-5 text-red-700" />
            </button>
          </div>
        </div>
      </header>

      {/* Content */}
      <div className="container mx-auto px-4 py-6 pb-32 space-y-4 max-w-2xl">
        {/* Profile Card */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white rounded-3xl shadow-lg p-6 border border-white/50"
        >
          <div className="flex items-center gap-4 mb-4">
            <div className="w-16 h-16 rounded-full bg-gradient-to-br from-purple-500 to-pink-500 flex items-center justify-center text-white text-2xl font-bold shadow-lg">
              {displayName.charAt(0)}
            </div>
            <div className="flex-1">
              <h3 className="font-bold text-gray-900 text-lg">{displayName}</h3>
              <p className="text-sm text-gray-500">{displayEmail}</p>
              {isOwner && (
                <div className="flex items-center gap-2 mt-1">
                  <Crown className="w-4 h-4 text-yellow-500" />
                  <span className="text-xs font-bold text-yellow-600">Owner</span>
                </div>
              )}
            </div>
          </div>

          {/* Admin Panel Button (Owner Only) */}
          {isOwner && onAdminClick && (
            <button
              onClick={onAdminClick}
              className="w-full mb-3 py-3 rounded-2xl bg-gradient-to-r from-yellow-400 to-orange-500 text-white font-bold hover:shadow-lg transition-all flex items-center justify-center gap-2"
            >
              <Shield className="w-5 h-5" />
              {t.admin}
            </button>
          )}

          {/* Premium Button */}
          <button
            onClick={() => onNavigate?.('premium')}
            className="w-full py-3 rounded-2xl bg-gradient-to-r from-purple-500 via-pink-500 to-rose-500 text-white font-bold hover:shadow-lg transition-all"
          >
            ✨ {t.premiumSubscription}
          </button>
        </motion.div>

        {/* Account Section */}
        <div className="space-y-3">
          <h2 className="text-lg font-bold text-gray-800 px-2">{t.account}</h2>
          
          {/* Edit Profile */}
          <motion.button
            onClick={() => setShowEditProfileModal(true)}
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            className="w-full bg-white rounded-2xl shadow-md p-4 flex items-center justify-between hover:shadow-lg transition-all"
          >
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-blue-400 to-cyan-500 flex items-center justify-center text-white">
                <Edit className="w-5 h-5" />
              </div>
              <div className="text-left">
                <h3 className="font-semibold text-gray-900">{t.editProfile}</h3>
                <p className="text-xs text-gray-500">{t.accountSettings}</p>
              </div>
            </div>
            <ChevronRight className={`w-5 h-5 text-gray-400 ${isRTL ? 'rotate-180' : ''}`} />
          </motion.button>

          {/* Change Password */}
          <motion.button
            onClick={() => setShowPasswordModal(true)}
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            className="w-full bg-white rounded-2xl shadow-md p-4 flex items-center justify-between hover:shadow-lg transition-all"
          >
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-purple-400 to-indigo-500 flex items-center justify-center text-white">
                <Lock className="w-5 h-5" />
              </div>
              <div className="text-left">
                <h3 className="font-semibold text-gray-900">{t.changePassword}</h3>
                <p className="text-xs text-gray-500">{t.updatePassword}</p>
              </div>
            </div>
            <ChevronRight className={`w-5 h-5 text-gray-400 ${isRTL ? 'rotate-180' : ''}`} />
          </motion.button>
        </div>

        {/* Preferences Section */}
        <div className="space-y-3">
          <h2 className="text-lg font-bold text-gray-800 px-2">{t.preferences}</h2>

          {/* Language */}
          <motion.div className="bg-white rounded-2xl shadow-md overflow-hidden">
            <button
              onClick={() => setExpandedItem(expandedItem === 1 ? null : 1)}
              className="w-full p-4 flex items-center justify-between hover:bg-gray-50 transition-all"
            >
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-green-400 to-emerald-500 flex items-center justify-center text-white">
                  <Globe className="w-5 h-5" />
                </div>
                <div className="text-left">
                  <h3 className="font-semibold text-gray-900">{t.appLanguage}</h3>
                  <p className="text-xs text-gray-500">
                    {language === 'ps' ? t.pashto : language === 'fa' ? t.dari : t.english}
                  </p>
                </div>
              </div>
              <ChevronRight className={`w-5 h-5 text-gray-400 transition-transform ${expandedItem === 1 ? 'rotate-90' : ''} ${isRTL ? 'rotate-180' : ''}`} />
            </button>

            <AnimatePresence>
              {expandedItem === 1 && (
                <motion.div
                  initial={{ height: 0, opacity: 0 }}
                  animate={{ height: 'auto', opacity: 1 }}
                  exit={{ height: 0, opacity: 0 }}
                  className="border-t border-gray-100 p-4 space-y-2"
                >
                  {[
                    { code: 'ps' as const, name: t.pashto, flag: '🇦🇫' },
                    { code: 'fa' as const, name: t.dari, flag: '🇦🇫' },
                    { code: 'en' as const, name: t.english, flag: '🇬🇧' }
                  ].map((lang) => (
                    <button
                      key={lang.code}
                      onClick={() => handleLanguageChange(lang.code)}
                      className={`w-full flex items-center justify-between px-4 py-3 rounded-xl transition-all ${
                        selectedLanguage === lang.code
                          ? 'bg-gradient-to-r from-purple-500 to-pink-500 text-white shadow-lg'
                          : 'bg-gray-50 hover:bg-gray-100 text-gray-700'
                      }`}
                    >
                      <span className="flex items-center gap-3">
                        <span className="text-2xl">{lang.flag}</span>
                        <span className="font-semibold">{lang.name}</span>
                      </span>
                      {selectedLanguage === lang.code && <CheckCircle className="w-5 h-5" />}
                    </button>
                  ))}
                </motion.div>
              )}
            </AnimatePresence>
          </motion.div>

          {/* Notifications */}
          <motion.div
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            className="bg-white rounded-2xl shadow-md p-4 flex items-center justify-between"
          >
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-orange-400 to-red-500 flex items-center justify-center text-white">
                <Bell className="w-5 h-5" />
              </div>
              <div className="text-left">
                <h3 className="font-semibold text-gray-900">{t.notifications}</h3>
                <p className="text-xs text-gray-500">{t.enableNotifications}</p>
              </div>
            </div>
            <button
              onClick={handleNotificationsToggle}
              className={`relative w-14 h-8 rounded-full transition-all ${
                notifications ? 'bg-green-500' : 'bg-gray-300'
              }`}
            >
              <div
                className={`absolute top-1 ${isRTL ? (notifications ? 'left-1' : 'left-7') : (notifications ? 'left-7' : 'left-1')} w-6 h-6 bg-white rounded-full shadow-md transition-all`}
              />
            </button>
          </motion.div>
        </div>

        {/* Support Section */}
        <div className="space-y-3">
          <h2 className="text-lg font-bold text-gray-800 px-2">{t.support}</h2>

          {/* Contact Support */}
          <motion.button
            onClick={() => onNavigate?.('contact')}
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            className="w-full bg-white rounded-2xl shadow-md p-4 flex items-center justify-between hover:shadow-lg transition-all"
          >
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-teal-400 to-cyan-500 flex items-center justify-center text-white">
                <Mail className="w-5 h-5" />
              </div>
              <div className="text-left">
                <h3 className="font-semibold text-gray-900">{t.onlineSupport}</h3>
                <p className="text-xs text-gray-500">{t.contactSupport}</p>
              </div>
            </div>
            <ChevronRight className={`w-5 h-5 text-gray-400 ${isRTL ? 'rotate-180' : ''}`} />
          </motion.button>

          {/* Phone */}
          <motion.button
            onClick={() => window.location.href = `tel:${t.ownerPhone}`}
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            className="w-full bg-white rounded-2xl shadow-md p-4 flex items-center justify-between hover:shadow-lg transition-all"
          >
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-green-400 to-emerald-500 flex items-center justify-center text-white">
                <Phone className="w-5 h-5" />
              </div>
              <div className="text-left">
                <h3 className="font-semibold text-gray-900">{t.phoneNumber}</h3>
                <p className="text-xs text-gray-500">{t.ownerPhone}</p>
              </div>
            </div>
            <ChevronRight className={`w-5 h-5 text-gray-400 ${isRTL ? 'rotate-180' : ''}`} />
          </motion.button>

          {/* Help */}
          <motion.button
            onClick={() => onNavigate?.('help')}
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            className="w-full bg-white rounded-2xl shadow-md p-4 flex items-center justify-between hover:shadow-lg transition-all"
          >
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-blue-400 to-indigo-500 flex items-center justify-center text-white">
                <Info className="w-5 h-5" />
              </div>
              <div className="text-left">
                <h3 className="font-semibold text-gray-900">
                  {language === 'ps' ? 'مرسته' : language === 'fa' ? 'راهنما' : 'Help & Support'}
                </h3>
                <p className="text-xs text-gray-500">
                  {language === 'ps' ? 'مرسته مرکز' : language === 'fa' ? 'مرکز راهنما' : 'Help center'}
                </p>
              </div>
            </div>
            <ChevronRight className={`w-5 h-5 text-gray-400 ${isRTL ? 'rotate-180' : ''}`} />
          </motion.button>
        </div>

        {/* About Section */}
        <div className="space-y-3">
          <h2 className="text-lg font-bold text-gray-800 px-2">{t.about}</h2>

          {/* About App */}
          <motion.button
            onClick={() => onNavigate?.('about')}
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            className="w-full bg-white rounded-2xl shadow-md p-4 flex items-center justify-between hover:shadow-lg transition-all"
          >
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-purple-400 to-pink-500 flex items-center justify-center text-white">
                <Info className="w-5 h-5" />
              </div>
              <div className="text-left">
                <h3 className="font-semibold text-gray-900">{t.aboutApp}</h3>
                <p className="text-xs text-gray-500">{t.version}</p>
              </div>
            </div>
            <ChevronRight className={`w-5 h-5 text-gray-400 ${isRTL ? 'rotate-180' : ''}`} />
          </motion.button>

          {/* Rate App */}
          <motion.button
            onClick={() => onNavigate?.('rating')}
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            className="w-full bg-white rounded-2xl shadow-md p-4 flex items-center justify-between hover:shadow-lg transition-all"
          >
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-yellow-400 to-orange-500 flex items-center justify-center text-white">
                <Star className="w-5 h-5" />
              </div>
              <div className="text-left">
                <h3 className="font-semibold text-gray-900">{t.rateApp}</h3>
                <p className="text-xs text-gray-500">{t.shareExperience}</p>
              </div>
            </div>
            <ChevronRight className={`w-5 h-5 text-gray-400 ${isRTL ? 'rotate-180' : ''}`} />
          </motion.button>

          {/* Website */}
          <motion.button
            onClick={() => window.open('https://www.ibrahimkhaksar.com', '_blank')}
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            className="w-full bg-white rounded-2xl shadow-md p-4 flex items-center justify-between hover:shadow-lg transition-all"
          >
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-cyan-400 to-blue-500 flex items-center justify-center text-white">
                <ExternalLink className="w-5 h-5" />
              </div>
              <div className="text-left">
                <h3 className="font-semibold text-gray-900">{t.website}</h3>
                <p className="text-xs text-gray-500">www.ibrahimkhaksar.com</p>
              </div>
            </div>
            <ChevronRight className={`w-5 h-5 text-gray-400 ${isRTL ? 'rotate-180' : ''}`} />
          </motion.button>
        </div>

        {/* Legal Section */}
        <div className="space-y-3">
          <h2 className="text-lg font-bold text-gray-800 px-2">{t.legal}</h2>

          {/* Terms */}
          <motion.button
            onClick={() => onNavigate?.('terms')}
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            className="w-full bg-white rounded-2xl shadow-md p-4 flex items-center justify-between hover:shadow-lg transition-all"
          >
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-indigo-400 to-purple-500 flex items-center justify-center text-white">
                <FileText className="w-5 h-5" />
              </div>
              <div className="text-left">
                <h3 className="font-semibold text-gray-900">{t.termsConditions}</h3>
                <p className="text-xs text-gray-500">{t.readTerms}</p>
              </div>
            </div>
            <ChevronRight className={`w-5 h-5 text-gray-400 ${isRTL ? 'rotate-180' : ''}`} />
          </motion.button>

          {/* Privacy */}
          <motion.button
            onClick={() => onNavigate?.('privacy')}
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            className="w-full bg-white rounded-2xl shadow-md p-4 flex items-center justify-between hover:shadow-lg transition-all"
          >
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-pink-400 to-rose-500 flex items-center justify-center text-white">
                <Shield className="w-5 h-5" />
              </div>
              <div className="text-left">
                <h3 className="font-semibold text-gray-900">{t.privacyPolicy}</h3>
                <p className="text-xs text-gray-500">{t.privacyInfo}</p>
              </div>
            </div>
            <ChevronRight className={`w-5 h-5 text-gray-400 ${isRTL ? 'rotate-180' : ''}`} />
          </motion.button>
        </div>

        {/* Danger Zone */}
        <div className="space-y-3">
          <h2 className="text-lg font-bold text-red-600 px-2">
            {language === 'ps' ? 'خطرناکه زون' : language === 'fa' ? 'منطقه خطرناک' : 'Danger Zone'}
          </h2>

          {/* Delete Account */}
          <motion.button
            onClick={handleDeleteAccount}
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            className="w-full bg-white rounded-2xl shadow-md p-4 flex items-center justify-between hover:shadow-lg transition-all border-2 border-red-200"
          >
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-red-400 to-rose-500 flex items-center justify-center text-white">
                <Trash2 className="w-5 h-5" />
              </div>
              <div className="text-left">
                <h3 className="font-semibold text-red-600">{t.deleteAccount}</h3>
                <p className="text-xs text-red-400">{t.deleteAccountWarning}</p>
              </div>
            </div>
            <ChevronRight className={`w-5 h-5 text-red-400 ${isRTL ? 'rotate-180' : ''}`} />
          </motion.button>

          {/* Logout */}
          <motion.button
            onClick={handleLogout}
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            className="w-full bg-gradient-to-r from-red-500 to-pink-600 rounded-2xl shadow-lg p-4 flex items-center justify-center gap-3 text-white font-bold hover:shadow-xl transition-all"
          >
            <LogOut className="w-5 h-5" />
            {t.logout}
          </motion.button>
        </div>
      </div>

      {/* Change Password Modal */}
      <AnimatePresence>
        {showPasswordModal && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/70 backdrop-blur-sm z-50 flex items-center justify-center p-4"
            onClick={() => setShowPasswordModal(false)}
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="bg-white rounded-3xl max-w-md w-full p-6 shadow-2xl"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-2xl font-bold text-gray-900">{t.changePassword}</h2>
                <button
                  onClick={() => setShowPasswordModal(false)}
                  className="p-2 hover:bg-gray-100 rounded-full transition-colors"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <div className="space-y-4">
                {/* Current Password */}
                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-2">
                    {t.currentPassword}
                  </label>
                  <div className="relative">
                    <Input
                      type={showCurrentPassword ? 'text' : 'password'}
                      value={currentPassword}
                      onChange={(e) => setCurrentPassword(e.target.value)}
                      placeholder={t.enterCurrentPassword}
                      className="w-full px-4 py-3 rounded-xl border-2 border-gray-200 focus:border-purple-400 pr-12"
                    />
                    <button
                      onClick={() => setShowCurrentPassword(!showCurrentPassword)}
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500 hover:text-gray-700"
                    >
                      {showCurrentPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                    </button>
                  </div>
                </div>

                {/* New Password */}
                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-2">
                    {t.newPassword}
                  </label>
                  <div className="relative">
                    <Input
                      type={showNewPassword ? 'text' : 'password'}
                      value={newPassword}
                      onChange={(e) => setNewPassword(e.target.value)}
                      placeholder={t.enterNewPassword}
                      className="w-full px-4 py-3 rounded-xl border-2 border-gray-200 focus:border-purple-400 pr-12"
                    />
                    <button
                      onClick={() => setShowNewPassword(!showNewPassword)}
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500 hover:text-gray-700"
                    >
                      {showNewPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                    </button>
                  </div>
                </div>

                {/* Confirm Password */}
                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-2">
                    {t.confirmNewPassword}
                  </label>
                  <div className="relative">
                    <Input
                      type={showConfirmPassword ? 'text' : 'password'}
                      value={confirmPassword}
                      onChange={(e) => setConfirmPassword(e.target.value)}
                      placeholder={t.enterConfirmPassword}
                      className="w-full px-4 py-3 rounded-xl border-2 border-gray-200 focus:border-purple-400 pr-12"
                    />
                    <button
                      onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500 hover:text-gray-700"
                    >
                      {showConfirmPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                    </button>
                  </div>
                </div>
              </div>

              <div className="flex gap-3 mt-6">
                <Button
                  onClick={() => setShowPasswordModal(false)}
                  className="flex-1 bg-gray-100 text-gray-700 hover:bg-gray-200 py-3 rounded-xl"
                >
                  {t.cancel}
                </Button>
                <Button
                  onClick={handlePasswordChange}
                  className="flex-1 bg-gradient-to-r from-purple-600 to-pink-600 text-white hover:shadow-lg py-3 rounded-xl"
                >
                  {t.save}
                </Button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Edit Profile Modal */}
      <AnimatePresence>
        {showEditProfileModal && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/70 backdrop-blur-sm z-50 flex items-center justify-center p-4"
            onClick={() => setShowEditProfileModal(false)}
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="bg-white rounded-3xl max-w-md w-full p-6 shadow-2xl max-h-[90vh] overflow-y-auto"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-2xl font-bold text-gray-900">{t.editProfile}</h2>
                <button
                  onClick={() => setShowEditProfileModal(false)}
                  className="p-2 hover:bg-gray-100 rounded-full transition-colors"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <div className="space-y-4">
                {/* Name */}
                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-2">
                    {t.name}
                  </label>
                  <Input
                    type="text"
                    value={editName}
                    onChange={(e) => setEditName(e.target.value)}
                    placeholder={t.enterName}
                    className="w-full px-4 py-3 rounded-xl border-2 border-gray-200 focus:border-blue-400"
                  />
                </div>

                {/* Email */}
                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-2">
                    {t.email}
                  </label>
                  <Input
                    type="email"
                    value={editEmail}
                    onChange={(e) => setEditEmail(e.target.value)}
                    placeholder={t.enterEmail}
                    className="w-full px-4 py-3 rounded-xl border-2 border-gray-200 focus:border-blue-400"
                  />
                </div>

                {/* Phone */}
                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-2">
                    {t.phone}
                  </label>
                  <Input
                    type="tel"
                    value={editPhone}
                    onChange={(e) => setEditPhone(e.target.value)}
                    placeholder={t.enterPhone}
                    className="w-full px-4 py-3 rounded-xl border-2 border-gray-200 focus:border-blue-400"
                  />
                </div>

                {/* Birthday */}
                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-2">
                    {t.birthday}
                  </label>
                  <Input
                    type="date"
                    value={editBirthday}
                    onChange={(e) => setEditBirthday(e.target.value)}
                    className="w-full px-4 py-3 rounded-xl border-2 border-gray-200 focus:border-blue-400"
                  />
                </div>
              </div>

              <div className="flex gap-3 mt-6">
                <Button
                  onClick={() => setShowEditProfileModal(false)}
                  className="flex-1 bg-gray-100 text-gray-700 hover:bg-gray-200 py-3 rounded-xl"
                >
                  {t.cancel}
                </Button>
                <Button
                  onClick={handleProfileUpdate}
                  className="flex-1 bg-gradient-to-r from-blue-600 to-cyan-600 text-white hover:shadow-lg py-3 rounded-xl"
                >
                  {t.save}
                </Button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
