import { useLanguage } from "../contexts/LanguageContext";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";
import { Globe, CheckCircle, Heart, Shield, Users } from "lucide-react";

export function LanguageDemo() {
  const { t, language, dir } = useLanguage();

  return (
    <section className="py-16 bg-gradient-to-b from-white via-blue-50/30 to-white">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-blue-100 to-cyan-100 rounded-full mb-4">
            <Globe className="w-4 h-4 text-blue-600 animate-pulse-glow" />
            <span className="text-blue-700 text-sm uppercase tracking-wider">
              {t("language")}
            </span>
          </div>
          <h2 className="text-4xl md:text-5xl mb-4">
            <span className="bg-gradient-to-r from-blue-600 via-cyan-600 to-teal-600 bg-clip-text text-transparent">
              {t("app_name")}
            </span>
          </h2>
          <p className="text-gray-600 text-lg max-w-2xl mx-auto">
            {t("app_tagline")}
          </p>
        </div>

        {/* Language Info */}
        <Card className="border-0 shadow-lg mb-8">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Globe className="w-5 h-5 text-blue-600" />
              {t("language")}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="p-4 bg-gradient-to-r from-blue-50 to-cyan-50 rounded-lg text-center">
                <div className="text-3xl mb-2">🇦🇫</div>
                <p className="text-lg">پښتو</p>
                <p className="text-sm text-gray-600">Pashto</p>
                {language === "ps" && (
                  <Badge className="mt-2 bg-blue-600">
                    <CheckCircle className="w-3 h-3 mr-1" />
                    Active
                  </Badge>
                )}
              </div>

              <div className="p-4 bg-gradient-to-r from-emerald-50 to-teal-50 rounded-lg text-center">
                <div className="text-3xl mb-2">🇦🇫</div>
                <p className="text-lg">دری</p>
                <p className="text-sm text-gray-600">Dari</p>
                {language === "fa" && (
                  <Badge className="mt-2 bg-emerald-600">
                    <CheckCircle className="w-3 h-3 mr-1" />
                    Active
                  </Badge>
                )}
              </div>

              <div className="p-4 bg-gradient-to-r from-purple-50 to-pink-50 rounded-lg text-center">
                <div className="text-3xl mb-2">🇬🇧</div>
                <p className="text-lg">English</p>
                <p className="text-sm text-gray-600">انګلیسي</p>
                {language === "en" && (
                  <Badge className="mt-2 bg-purple-600">
                    <CheckCircle className="w-3 h-3 mr-1" />
                    Active
                  </Badge>
                )}
              </div>
            </div>

            <div className="mt-6 p-4 bg-gradient-to-r from-amber-50 to-orange-50 rounded-lg">
              <p className="text-sm text-amber-900 mb-2">
                <strong>Current Direction:</strong> {dir === "rtl" ? "Right-to-Left (RTL)" : "Left-to-Right (LTR)"}
              </p>
              <p className="text-sm text-amber-800">
                {language === "en" 
                  ? "English uses LTR text direction"
                  : "پښتو او دری د RTL (راست به چپ) متن جهت کاروي"}
              </p>
            </div>
          </CardContent>
        </Card>

        {/* Demo Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <Card className="border-0 shadow-lg hover-lift">
            <CardContent className="p-6">
              <div className="p-3 bg-gradient-to-br from-blue-100 to-cyan-100 rounded-lg w-fit mb-4">
                <Heart className="w-6 h-6 text-blue-600" />
              </div>
              <h3 className="text-xl mb-2">{t("find_doctor")}</h3>
              <p className="text-sm text-gray-600 mb-4">{t("find_doctor_desc")}</p>
              <Button className="w-full bg-gradient-to-r from-blue-500 to-cyan-600">
                {t("book_now")}
              </Button>
            </CardContent>
          </Card>

          <Card className="border-0 shadow-lg hover-lift">
            <CardContent className="p-6">
              <div className="p-3 bg-gradient-to-br from-purple-100 to-pink-100 rounded-lg w-fit mb-4">
                <Shield className="w-6 h-6 text-purple-600" />
              </div>
              <h3 className="text-xl mb-2">{t("health_insurance")}</h3>
              <p className="text-sm text-gray-600 mb-4">{t("check_coverage")}</p>
              <Button className="w-full bg-gradient-to-r from-purple-500 to-pink-600">
                {t("view_details")}
              </Button>
            </CardContent>
          </Card>

          <Card className="border-0 shadow-lg hover-lift">
            <CardContent className="p-6">
              <div className="p-3 bg-gradient-to-br from-emerald-100 to-teal-100 rounded-lg w-fit mb-4">
                <Users className="w-6 h-6 text-emerald-600" />
              </div>
              <h3 className="text-xl mb-2">{t("family_profiles")}</h3>
              <p className="text-sm text-gray-600 mb-4">{t("add_member")}</p>
              <Button className="w-full bg-gradient-to-r from-emerald-500 to-teal-600">
                {t("add_member")}
              </Button>
            </CardContent>
          </Card>
        </div>

        {/* Common Phrases Demo */}
        <Card className="border-0 shadow-lg mt-8">
          <CardHeader>
            <CardTitle>Common Phrases - عام جملې</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div className="p-3 bg-gray-50 rounded-lg">
                <p className="text-sm text-gray-600 mb-1">Home</p>
                <p className="font-medium">{t("home")}</p>
              </div>
              <div className="p-3 bg-gray-50 rounded-lg">
                <p className="text-sm text-gray-600 mb-1">Services</p>
                <p className="font-medium">{t("services")}</p>
              </div>
              <div className="p-3 bg-gray-50 rounded-lg">
                <p className="text-sm text-gray-600 mb-1">Medicines</p>
                <p className="font-medium">{t("medicines")}</p>
              </div>
              <div className="p-3 bg-gray-50 rounded-lg">
                <p className="text-sm text-gray-600 mb-1">Settings</p>
                <p className="font-medium">{t("settings")}</p>
              </div>
              <div className="p-3 bg-gray-50 rounded-lg">
                <p className="text-sm text-gray-600 mb-1">Doctor</p>
                <p className="font-medium">{t("find_doctor")}</p>
              </div>
              <div className="p-3 bg-gray-50 rounded-lg">
                <p className="text-sm text-gray-600 mb-1">Emergency</p>
                <p className="font-medium">{t("emergency")}</p>
              </div>
              <div className="p-3 bg-gray-50 rounded-lg">
                <p className="text-sm text-gray-600 mb-1">Search</p>
                <p className="font-medium">{t("search")}</p>
              </div>
              <div className="p-3 bg-gray-50 rounded-lg">
                <p className="text-sm text-gray-600 mb-1">Save</p>
                <p className="font-medium">{t("save")}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Days of Week Demo */}
        <Card className="border-0 shadow-lg mt-8">
          <CardHeader>
            <CardTitle>Days of the Week - د اونۍ ورځې</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex flex-wrap gap-2">
              {["monday", "tuesday", "wednesday", "thursday", "friday", "saturday", "sunday"].map((day) => (
                <Badge 
                  key={day} 
                  variant="outline" 
                  className="px-4 py-2 text-sm"
                >
                  {t(day)}
                </Badge>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Medical Specialties Demo */}
        <Card className="border-0 shadow-lg mt-8">
          <CardHeader>
            <CardTitle>Medical Specialties - طبي تخصصات</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
              {["cardiologist", "dermatologist", "pediatrician", "neurologist", "orthopedic", "gynecologist", "general_physician", "dentist"].map((specialty) => (
                <div key={specialty} className="p-3 border-2 border-gray-200 rounded-lg hover:border-blue-500 transition-colors">
                  <p className="text-sm">{t(specialty)}</p>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </section>
  );
}
