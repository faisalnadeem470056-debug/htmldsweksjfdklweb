import { useState } from "react";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Label } from "./ui/label";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "./ui/card";
import { Alert, AlertDescription } from "./ui/alert";
import { Eye, EyeOff, Mail, Lock, User, Phone, UserPlus, AlertCircle, Loader2, CheckCircle, XCircle } from "lucide-react";
import { useAuth } from "../contexts/AuthContext";
import { useLanguage } from "../contexts/LanguageContext";
import { toast } from "sonner";

interface SignUpFormProps {
  onSwitchToLogin: () => void;
  onSuccess: () => void;
}

export function SignUpForm({ onSwitchToLogin, onSuccess }: SignUpFormProps) {
  const { signup } = useAuth();
  const { language } = useLanguage();
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [error, setError] = useState("");
  const [isLoading, setIsLoading] = useState(false);

  const translations = {
    en: {
      title: "Create Account",
      subtitle: "Join HealMate family today",
      fullName: "Full Name",
      fullNamePlaceholder: "Ahmad Khan",
      email: "Email Address",
      emailPlaceholder: "your.email@example.com",
      phone: "Phone Number (Optional)",
      phonePlaceholder: "+93 7XX XXX XXX",
      password: "Password",
      passwordPlaceholder: "Create a strong password",
      confirmPassword: "Confirm Password",
      confirmPasswordPlaceholder: "Re-enter your password",
      signUpButton: "Create Account",
      signingUp: "Creating account...",
      haveAccount: "Already have an account?",
      signIn: "Sign In",
      passwordStrength: "Password Strength:",
      weak: "Weak",
      medium: "Medium",
      strong: "Strong",
      errorRequired: "Please fill in all required fields",
      errorPasswordMismatch: "Passwords do not match",
      errorPasswordLength: "Password must be at least 6 characters",
      successTitle: "Account created successfully!",
      successMessage: "Please sign in with your email and password.",
    },
    dari: {
      title: "حساب جدید بسازید",
      subtitle: "امروز به خانواده HealMate بپیوندید",
      fullName: "نام کامل",
      fullNamePlaceholder: "احمد خان",
      email: "ایمیل آدرس",
      emailPlaceholder: "your.email@example.com",
      phone: "شماره تلفن (اختیاری)",
      phonePlaceholder: "+93 7XX XXX XXX",
      password: "رمز عبور",
      passwordPlaceholder: "یک رمز قوی بسازید",
      confirmPassword: "تایید رمز عبور",
      confirmPasswordPlaceholder: "رمز خود را دوباره وارد کنید",
      signUpButton: "حساب بسازید",
      signingUp: "در حال ساخت حساب...",
      haveAccount: "حساب دارید؟",
      signIn: "ورود",
      passwordStrength: "قدرت رمز:",
      weak: "ضعیف",
      medium: "متوسط",
      strong: "قوی",
      errorRequired: "لطفاً همه فیلدهای ضروری را پر کنید",
      errorPasswordMismatch: "رمزهای عبور مطابقت ندارند",
      errorPasswordLength: "رمز عبور باید حداقل ۶ کاراکتر باشد",
      successTitle: "حساب با موفقیت ایجاد شد!",
      successMessage: "لطفاً با ایمیل و رمز عبور خود وارد شوید.",
    },
    pashto: {
      title: "نوی حساب جوړ کړئ",
      subtitle: "نن د HealMate کورنۍ سره یوځای شئ",
      fullName: "بشپړ نوم",
      fullNamePlaceholder: "احمد خان",
      email: "ایمیل آدرس",
      emailPlaceholder: "your.email@example.com",
      phone: "د تلیفون شمیره (اختیاري)",
      phonePlaceholder: "+93 7XX XXX XXX",
      password: "پاسورډ",
      passwordPlaceholder: "یو قوي پاسورډ جوړ کړئ",
      confirmPassword: "د پاسورډ تایید",
      confirmPasswordPlaceholder: "خپل پاسورډ بیا ولیکئ",
      signUpButton: "حساب جوړ کړئ",
      signingUp: "حساب جوړیږي...",
      haveAccount: "حساب لرئ؟",
      signIn: "ننوتل",
      passwordStrength: "د پاسورډ ځواک:",
      weak: "کمزوری",
      medium: "منځنی",
      strong: "قوي",
      errorRequired: "مهرباني وکړئ ټول اړین برخې ډک کړئ",
      errorPasswordMismatch: "پاسورډونه سره سمون نلري",
      errorPasswordLength: "پاسورډ باید لږ تر لږه ۶ توري ولري",
      successTitle: "حساب بریالیتوب سره جوړ شو!",
      successMessage: "مهرباني وکړئ خپل ایمیل او پاسورډ سره ننوځئ.",
    },
  };

  const t = translations[language as keyof typeof translations] || translations.en;

  // د Password strength محاسبه
  const getPasswordStrength = (pass: string): { strength: number; label: string; color: string } => {
    let strength = 0;
    if (pass.length >= 8) strength++;
    if (pass.match(/[a-z]/) && pass.match(/[A-Z]/)) strength++;
    if (pass.match(/[0-9]/)) strength++;
    if (pass.match(/[^a-zA-Z0-9]/)) strength++;

    if (strength <= 1) return { strength: 1, label: t.weak, color: "bg-red-500" };
    if (strength <= 2) return { strength: 2, label: t.medium, color: "bg-yellow-500" };
    return { strength: 3, label: t.strong, color: "bg-green-500" };
  };

  const passwordStrength = password ? getPasswordStrength(password) : null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    setIsLoading(true);

    // Validation
    if (!name || !email || !password || !confirmPassword) {
      setError(t.errorRequired);
      setIsLoading(false);
      return;
    }

    if (password !== confirmPassword) {
      setError(t.errorPasswordMismatch);
      setIsLoading(false);
      return;
    }

    if (password.length < 6) {
      setError(t.errorPasswordLength);
      setIsLoading(false);
      return;
    }

    const result = await signup(name, email, password, phone);
    
    if (result.success) {
      // د email lowercase کړئ د display لپاره
      const displayEmail = email.trim().toLowerCase();
      
      toast.success(
        `✅ ${t.successTitle}\n\nEmail: ${displayEmail}\n\n${t.successMessage}`, 
        {
          duration: 6000,
        }
      );
      
      // د form values reset کړئ
      setName("");
      setEmail("");
      setPhone("");
      setPassword("");
      setConfirmPassword("");
      
      // د 3 ثانیو وروسته Login form ته لاړ شئ
      setTimeout(() => {
        onSwitchToLogin();
      }, 3000);
    } else {
      setError(result.error || "Sign up failed");
      toast.error(result.error || "Sign up failed");
    }
    
    setIsLoading(false);
  };

  return (
    <Card className="glass-effect border-2 border-emerald-200 shadow-2xl">
      <CardHeader className="space-y-3 text-center">
        <div className="mx-auto w-16 h-16 bg-gradient-to-br from-purple-500 to-pink-500 rounded-full flex items-center justify-center shadow-lg">
          <UserPlus className="w-8 h-8 text-white" />
        </div>
        <CardTitle className="text-3xl gradient-text">{t.title}</CardTitle>
        <CardDescription className="text-base">{t.subtitle}</CardDescription>
      </CardHeader>

      <CardContent className="space-y-6">
        {error && (
          <Alert className="bg-red-50 border-red-200">
            <AlertCircle className="h-4 w-4 text-red-600" />
            <AlertDescription className="text-red-800">{error}</AlertDescription>
          </Alert>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          {/* Full Name */}
          <div className="space-y-2">
            <Label htmlFor="name">{t.fullName}</Label>
            <div className="relative">
              <User className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
              <Input
                id="name"
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder={t.fullNamePlaceholder}
                className="pl-10"
                disabled={isLoading}
              />
            </div>
          </div>

          {/* Email */}
          <div className="space-y-2">
            <Label htmlFor="email">{t.email}</Label>
            <div className="relative">
              <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
              <Input
                id="email"
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder={t.emailPlaceholder}
                className="pl-10"
                disabled={isLoading}
              />
            </div>
          </div>

          {/* Phone */}
          <div className="space-y-2">
            <Label htmlFor="phone">{t.phone}</Label>
            <div className="relative">
              <Phone className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
              <Input
                id="phone"
                type="tel"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                placeholder={t.phonePlaceholder}
                className="pl-10"
                disabled={isLoading}
              />
            </div>
          </div>

          {/* Password */}
          <div className="space-y-2">
            <Label htmlFor="password">{t.password}</Label>
            <div className="relative">
              <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
              <Input
                id="password"
                type={showPassword ? "text" : "password"}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder={t.passwordPlaceholder}
                className="pl-10 pr-12"
                disabled={isLoading}
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500 hover:text-gray-700"
              >
                {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
              </button>
            </div>
            
            {/* Password Strength Indicator */}
            {passwordStrength && (
              <div className="space-y-1">
                <div className="flex items-center justify-between text-xs">
                  <span className="text-gray-600">{t.passwordStrength}</span>
                  <span className={passwordStrength.strength === 3 ? "text-green-600" : passwordStrength.strength === 2 ? "text-yellow-600" : "text-red-600"}>
                    {passwordStrength.label}
                  </span>
                </div>
                <div className="h-1.5 bg-gray-200 rounded-full overflow-hidden">
                  <div 
                    className={`h-full transition-all ${passwordStrength.color}`}
                    style={{ width: `${(passwordStrength.strength / 3) * 100}%` }}
                  />
                </div>
              </div>
            )}
          </div>

          {/* Confirm Password */}
          <div className="space-y-2">
            <Label htmlFor="confirmPassword">{t.confirmPassword}</Label>
            <div className="relative">
              <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
              <Input
                id="confirmPassword"
                type={showConfirmPassword ? "text" : "password"}
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                placeholder={t.confirmPasswordPlaceholder}
                className="pl-10 pr-12"
                disabled={isLoading}
              />
              <button
                type="button"
                onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500 hover:text-gray-700"
              >
                {showConfirmPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
              </button>
              {confirmPassword && (
                <div className="absolute -right-10 top-1/2 -translate-y-1/2">
                  {password === confirmPassword ? (
                    <CheckCircle className="w-5 h-5 text-green-500" />
                  ) : (
                    <XCircle className="w-5 h-5 text-red-500" />
                  )}
                </div>
              )}
            </div>
          </div>

          {/* Sign Up Button */}
          <Button
            type="submit"
            className="w-full bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600"
            size="lg"
            disabled={isLoading}
          >
            {isLoading ? (
              <>
                <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                {t.signingUp}
              </>
            ) : (
              <>
                <UserPlus className="w-5 h-5 mr-2" />
                {t.signUpButton}
              </>
            )}
          </Button>
        </form>

        {/* Sign In Link */}
        <div className="text-center pt-4 border-t">
          <p className="text-sm text-gray-600">
            {t.haveAccount}{" "}
            <button
              onClick={onSwitchToLogin}
              className="text-emerald-600 hover:text-emerald-700 hover:underline"
            >
              {t.signIn}
            </button>
          </p>
        </div>

        {/* Info Note */}
        <div className="p-3 bg-gradient-to-r from-green-50 to-emerald-50 border border-green-200 rounded-lg">
          <p className="text-xs text-green-900 text-center">
            ✅ د Sign Up وروسته Login وکړئ<br/>
            <span className="text-green-700">After Sign Up, please Login</span><br/>
            <span className="text-green-700 text-[10px]">بعد از ثبت نام، لطفاً وارد شوید</span>
          </p>
        </div>
      </CardContent>
    </Card>
  );
}
