import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Activity, Droplet, Heart, Scale, Ruler, TrendingUp, 
  AlertCircle, CheckCircle2, BarChart3, Sparkles, Zap,
  ArrowRight, Info
} from 'lucide-react';
import { Button } from './ui/button';
import { Card } from './ui/card';
import { Input } from './ui/input';

interface QuickHealthScannerProps {
  language: 'ps' | 'fa' | 'en';
}

interface HealthMetrics {
  bmi: number | null;
  waterIntake: number;
  heartRate: number | null;
  steps: number;
}

export function QuickHealthScanner({ language }: QuickHealthScannerProps) {
  const [activeScanner, setActiveScanner] = useState<string | null>(null);
  const [weight, setWeight] = useState('');
  const [height, setHeight] = useState('');
  const [waterGlasses, setWaterGlasses] = useState(0);
  const [heartRate, setHeartRate] = useState('');
  const [steps, setSteps] = useState(0);
  const [showResults, setShowResults] = useState(false);
  const [metrics, setMetrics] = useState<HealthMetrics>({
    bmi: null,
    waterIntake: 0,
    heartRate: null,
    steps: 0
  });

  const texts = {
    ps: {
      title: '⚡ چټک روغتیا سکینر',
      subtitle: 'په یو کلیک سره خپل روغتیا وګورئ',
      bmiScanner: 'BMI سکینر',
      waterTracker: 'د اوبو ټریکر',
      heartRateChecker: 'د زړه ضربان',
      stepsCounter: 'د ګامونو شمیرنه',
      weight: 'وزن (کیلوګرام)',
      height: 'قد (سانتي متره)',
      calculate: 'محاسبه',
      addGlass: 'یو ګیلاس اوبه',
      glassesTarget: 'ګیلاسه / 8',
      enterHeartRate: 'د زړه ضربان ولیکئ',
      bpm: 'فی دقیقه',
      check: 'معاینه',
      addSteps: '+1000 ګامونه',
      stepsToday: 'نن ګامونه',
      goalSteps: 'هدف: 10,000',
      yourResults: 'ستاسو نتیجې',
      bmiResult: 'BMI:',
      status: 'حالت:',
      underweight: 'کم وزن',
      normal: 'نورمال',
      overweight: 'زیات وزن',
      obese: 'چاغ',
      waterStatus: 'د اوبو حالت:',
      needMore: 'نور اوبه په کار دي',
      excellent: 'عالي',
      heartStatus: 'د زړه حالت:',
      low: 'ټیټ',
      good: 'ښه',
      high: 'لوړ',
      stepsStatus: 'د ګامونو حالت:',
      keepGoing: 'دوام ورکړئ',
      almostThere: 'نږدې رسیدلئ',
      goalAchieved: 'هدف ترلاسه شو',
      quickScan: 'چټک سکین',
      scanAll: 'ټول سکین کړئ'
    },
    fa: {
      title: '⚡ اسکنر سریع سلامتی',
      subtitle: 'سلامتی خود را در یک کلیک ببینید',
      bmiScanner: 'اسکنر BMI',
      waterTracker: 'ردیاب آب',
      heartRateChecker: 'ضربان قلب',
      stepsCounter: 'شمارنده قدم',
      weight: 'وزن (کیلوگرم)',
      height: 'قد (سانتی‌متر)',
      calculate: 'محاسبه',
      addGlass: 'یک لیوان آب',
      glassesTarget: 'لیوان / 8',
      enterHeartRate: 'ضربان قلب را وارد کنید',
      bpm: 'در دقیقه',
      check: 'بررسی',
      addSteps: '+1000 قدم',
      stepsToday: 'قدم امروز',
      goalSteps: 'هدف: 10,000',
      yourResults: 'نتایج شما',
      bmiResult: 'BMI:',
      status: 'وضعیت:',
      underweight: 'کم‌وزن',
      normal: 'نرمال',
      overweight: 'اضافه‌وزن',
      obese: 'چاق',
      waterStatus: 'وضعیت آب:',
      needMore: 'نیاز به آب بیشتر',
      excellent: 'عالی',
      heartStatus: 'وضعیت قلب:',
      low: 'پایین',
      good: 'خوب',
      high: 'بالا',
      stepsStatus: 'وضعیت قدم:',
      keepGoing: 'ادامه دهید',
      almostThere: 'نزدیک هدف',
      goalAchieved: 'هدف محقق شد',
      quickScan: 'اسکن سریع',
      scanAll: 'اسکن همه'
    },
    en: {
      title: '⚡ Quick Health Scanner',
      subtitle: 'Check your health in one click',
      bmiScanner: 'BMI Scanner',
      waterTracker: 'Water Tracker',
      heartRateChecker: 'Heart Rate',
      stepsCounter: 'Steps Counter',
      weight: 'Weight (kg)',
      height: 'Height (cm)',
      calculate: 'Calculate',
      addGlass: 'Add Glass',
      glassesTarget: 'glasses / 8',
      enterHeartRate: 'Enter heart rate',
      bpm: 'BPM',
      check: 'Check',
      addSteps: '+1000 Steps',
      stepsToday: 'Steps Today',
      goalSteps: 'Goal: 10,000',
      yourResults: 'Your Results',
      bmiResult: 'BMI:',
      status: 'Status:',
      underweight: 'Underweight',
      normal: 'Normal',
      overweight: 'Overweight',
      obese: 'Obese',
      waterStatus: 'Water Status:',
      needMore: 'Need More Water',
      excellent: 'Excellent',
      heartStatus: 'Heart Status:',
      low: 'Low',
      good: 'Good',
      high: 'High',
      stepsStatus: 'Steps Status:',
      keepGoing: 'Keep Going',
      almostThere: 'Almost There',
      goalAchieved: 'Goal Achieved',
      quickScan: 'Quick Scan',
      scanAll: 'Scan All'
    }
  };

  const t = texts[language];

  const calculateBMI = () => {
    const w = parseFloat(weight);
    const h = parseFloat(height) / 100; // Convert cm to meters
    if (w && h) {
      const bmi = w / (h * h);
      setMetrics({ ...metrics, bmi });
      setShowResults(true);
    }
  };

  const addWater = () => {
    const newWater = Math.min(waterGlasses + 1, 12);
    setWaterGlasses(newWater);
    setMetrics({ ...metrics, waterIntake: newWater });
    setShowResults(true);
  };

  const checkHeartRate = () => {
    const hr = parseInt(heartRate);
    if (hr) {
      setMetrics({ ...metrics, heartRate: hr });
      setShowResults(true);
    }
  };

  const addStepsCount = () => {
    const newSteps = steps + 1000;
    setSteps(newSteps);
    setMetrics({ ...metrics, steps: newSteps });
    setShowResults(true);
  };

  const getBMIStatus = (bmi: number) => {
    if (bmi < 18.5) return { text: t.underweight, color: 'text-blue-600', bg: 'bg-blue-100' };
    if (bmi < 25) return { text: t.normal, color: 'text-green-600', bg: 'bg-green-100' };
    if (bmi < 30) return { text: t.overweight, color: 'text-orange-600', bg: 'bg-orange-100' };
    return { text: t.obese, color: 'text-red-600', bg: 'bg-red-100' };
  };

  const getWaterStatus = (glasses: number) => {
    if (glasses >= 8) return { text: t.excellent, color: 'text-green-600', bg: 'bg-green-100' };
    return { text: t.needMore, color: 'text-orange-600', bg: 'bg-orange-100' };
  };

  const getHeartRateStatus = (hr: number) => {
    if (hr < 60) return { text: t.low, color: 'text-blue-600', bg: 'bg-blue-100' };
    if (hr <= 100) return { text: t.good, color: 'text-green-600', bg: 'bg-green-100' };
    return { text: t.high, color: 'text-red-600', bg: 'bg-red-100' };
  };

  const getStepsStatus = (steps: number) => {
    if (steps >= 10000) return { text: t.goalAchieved, color: 'text-green-600', bg: 'bg-green-100' };
    if (steps >= 7000) return { text: t.almostThere, color: 'text-orange-600', bg: 'bg-orange-100' };
    return { text: t.keepGoing, color: 'text-blue-600', bg: 'bg-blue-100' };
  };

  const scanners = [
    {
      id: 'bmi',
      title: t.bmiScanner,
      icon: Scale,
      gradient: 'from-purple-500 to-pink-500',
      content: (
        <div className="space-y-4">
          <Input
            type="number"
            placeholder={t.weight}
            value={weight}
            onChange={(e) => setWeight(e.target.value)}
            className="border-2"
          />
          <Input
            type="number"
            placeholder={t.height}
            value={height}
            onChange={(e) => setHeight(e.target.value)}
            className="border-2"
          />
          <Button
            onClick={calculateBMI}
            className="w-full bg-gradient-to-r from-purple-500 to-pink-500 text-white"
          >
            <BarChart3 className="w-4 h-4 mr-2" />
            {t.calculate}
          </Button>
        </div>
      )
    },
    {
      id: 'water',
      title: t.waterTracker,
      icon: Droplet,
      gradient: 'from-blue-500 to-cyan-500',
      content: (
        <div className="space-y-4">
          <div className="text-center">
            <motion.div 
              className="text-6xl mb-2"
              animate={{ scale: [1, 1.1, 1] }}
              transition={{ duration: 2, repeat: Infinity }}
            >
              💧
            </motion.div>
            <div className="text-3xl mb-2">{waterGlasses} {t.glassesTarget}</div>
            <div className="w-full bg-gray-200 rounded-full h-3 overflow-hidden mb-4">
              <motion.div
                animate={{ width: `${(waterGlasses / 8) * 100}%` }}
                className="h-full bg-gradient-to-r from-blue-500 to-cyan-500"
              />
            </div>
          </div>
          <Button
            onClick={addWater}
            disabled={waterGlasses >= 8}
            className="w-full bg-gradient-to-r from-blue-500 to-cyan-500 text-white"
          >
            <Droplet className="w-4 h-4 mr-2" />
            {t.addGlass}
          </Button>
        </div>
      )
    },
    {
      id: 'heart',
      title: t.heartRateChecker,
      icon: Heart,
      gradient: 'from-red-500 to-pink-500',
      content: (
        <div className="space-y-4">
          <div className="text-center mb-4">
            <motion.div
              animate={{ scale: [1, 1.2, 1] }}
              transition={{ duration: 1, repeat: Infinity }}
            >
              <Heart className="w-16 h-16 text-red-500 fill-red-500 mx-auto" />
            </motion.div>
          </div>
          <Input
            type="number"
            placeholder={t.enterHeartRate}
            value={heartRate}
            onChange={(e) => setHeartRate(e.target.value)}
            className="border-2"
          />
          <div className="text-center text-sm text-gray-500">{t.bpm}</div>
          <Button
            onClick={checkHeartRate}
            className="w-full bg-gradient-to-r from-red-500 to-pink-500 text-white"
          >
            <Activity className="w-4 h-4 mr-2" />
            {t.check}
          </Button>
        </div>
      )
    },
    {
      id: 'steps',
      title: t.stepsCounter,
      icon: Activity,
      gradient: 'from-green-500 to-emerald-500',
      content: (
        <div className="space-y-4">
          <div className="text-center">
            <motion.div className="text-5xl mb-2">🚶</motion.div>
            <div className="text-4xl mb-2">{steps.toLocaleString()}</div>
            <div className="text-sm text-gray-500 mb-4">{t.stepsToday}</div>
            <div className="w-full bg-gray-200 rounded-full h-3 overflow-hidden mb-2">
              <motion.div
                animate={{ width: `${(steps / 10000) * 100}%` }}
                className="h-full bg-gradient-to-r from-green-500 to-emerald-500"
              />
            </div>
            <div className="text-xs text-gray-500">{t.goalSteps}</div>
          </div>
          <Button
            onClick={addStepsCount}
            className="w-full bg-gradient-to-r from-green-500 to-emerald-500 text-white"
          >
            <TrendingUp className="w-4 h-4 mr-2" />
            {t.addSteps}
          </Button>
        </div>
      )
    }
  ];

  return (
    <div className="w-full">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="mb-6"
      >
        <div className="text-center mb-6">
          <h2 className="text-3xl mb-2 bg-gradient-to-r from-blue-600 via-purple-600 to-pink-600 bg-clip-text text-transparent">
            {t.title}
          </h2>
          <p className="text-gray-600">{t.subtitle}</p>
        </div>

        {/* Scanner Cards */}
        <div className="grid grid-cols-2 gap-4 mb-6">
          {scanners.map((scanner, index) => {
            const Icon = scanner.icon;
            const isActive = activeScanner === scanner.id;
            
            return (
              <motion.div
                key={scanner.id}
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: index * 0.1 }}
              >
                <Card
                  onClick={() => setActiveScanner(isActive ? null : scanner.id)}
                  className={`cursor-pointer overflow-hidden transition-all ${
                    isActive 
                      ? 'ring-4 ring-purple-300 shadow-2xl' 
                      : 'hover:shadow-xl'
                  }`}
                >
                  <div className="p-4">
                    <motion.div
                      whileHover={{ scale: 1.1 }}
                      className={`w-14 h-14 rounded-2xl bg-gradient-to-br ${scanner.gradient} flex items-center justify-center mb-3 mx-auto shadow-lg`}
                    >
                      <Icon className="w-7 h-7 text-white" />
                    </motion.div>
                    <h3 className="text-center text-sm mb-2">{scanner.title}</h3>
                    
                    <AnimatePresence>
                      {isActive && (
                        <motion.div
                          initial={{ opacity: 0, height: 0 }}
                          animate={{ opacity: 1, height: 'auto' }}
                          exit={{ opacity: 0, height: 0 }}
                          className="mt-4"
                        >
                          {scanner.content}
                        </motion.div>
                      )}
                    </AnimatePresence>
                  </div>
                </Card>
              </motion.div>
            );
          })}
        </div>

        {/* Results Panel */}
        <AnimatePresence>
          {showResults && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: 20 }}
              className="bg-gradient-to-br from-purple-50 to-pink-50 rounded-2xl p-6 shadow-xl"
            >
              <div className="flex items-center gap-2 mb-4">
                <Sparkles className="w-6 h-6 text-purple-600" />
                <h3 className="text-xl">{t.yourResults}</h3>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {metrics.bmi && (
                  <div className={`p-4 rounded-xl ${getBMIStatus(metrics.bmi).bg}`}>
                    <div className="flex items-center gap-2 mb-2">
                      <Scale className="w-5 h-5" />
                      <span className="text-sm">{t.bmiResult}</span>
                    </div>
                    <div className="text-2xl mb-1">{metrics.bmi.toFixed(1)}</div>
                    <div className={`text-sm ${getBMIStatus(metrics.bmi).color}`}>
                      {t.status} {getBMIStatus(metrics.bmi).text}
                    </div>
                  </div>
                )}

                {metrics.waterIntake > 0 && (
                  <div className={`p-4 rounded-xl ${getWaterStatus(metrics.waterIntake).bg}`}>
                    <div className="flex items-center gap-2 mb-2">
                      <Droplet className="w-5 h-5" />
                      <span className="text-sm">{t.waterStatus}</span>
                    </div>
                    <div className="text-2xl mb-1">{metrics.waterIntake}/8</div>
                    <div className={`text-sm ${getWaterStatus(metrics.waterIntake).color}`}>
                      {getWaterStatus(metrics.waterIntake).text}
                    </div>
                  </div>
                )}

                {metrics.heartRate && (
                  <div className={`p-4 rounded-xl ${getHeartRateStatus(metrics.heartRate).bg}`}>
                    <div className="flex items-center gap-2 mb-2">
                      <Heart className="w-5 h-5" />
                      <span className="text-sm">{t.heartStatus}</span>
                    </div>
                    <div className="text-2xl mb-1">{metrics.heartRate} {t.bpm}</div>
                    <div className={`text-sm ${getHeartRateStatus(metrics.heartRate).color}`}>
                      {getHeartRateStatus(metrics.heartRate).text}
                    </div>
                  </div>
                )}

                {metrics.steps > 0 && (
                  <div className={`p-4 rounded-xl ${getStepsStatus(metrics.steps).bg}`}>
                    <div className="flex items-center gap-2 mb-2">
                      <Activity className="w-5 h-5" />
                      <span className="text-sm">{t.stepsStatus}</span>
                    </div>
                    <div className="text-2xl mb-1">{metrics.steps.toLocaleString()}</div>
                    <div className={`text-sm ${getStepsStatus(metrics.steps).color}`}>
                      {getStepsStatus(metrics.steps).text}
                    </div>
                  </div>
                )}
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </motion.div>
    </div>
  );
}
