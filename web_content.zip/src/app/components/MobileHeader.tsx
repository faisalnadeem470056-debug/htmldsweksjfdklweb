import { useState } from "react";
import { Menu, Bell, Search } from "lucide-react";
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";
import { ProfileSidebar } from "./ProfileSidebar";
import { LanguageSwitcher } from "./LanguageSwitcher";
import logoImage from "figma:asset/ba48654895779a4ce2efe10c107b371087cee470.png";

interface MobileHeaderProps {
  activePage: string;
  setActivePage: (page: string) => void;
}

export function MobileHeader({ activePage, setActivePage }: MobileHeaderProps) {
  const [sidebarOpen, setSidebarOpen] = useState(false);

  const pageTitle = {
    home: "HealMate",
    services: "Our Services",
    medicines: "Medicines Database",
    health: "Health Tips",
    settings: "Settings",
    family: "Family Profiles",
    "lab-tests": "Lab Tests",
    reminders: "Medicine Reminders",
    dashboard: "Health Dashboard",
    "e-pharmacy": "E-Pharmacy",
    insurance: "Health Insurance",
    "doctor-chat": "Doctor Chat",
    "video-consultation": "Video Consultation",
    "symptoms-tracker": "Symptoms Tracker",
    "ai-assistant": "AI Health Assistant",
    "health-analytics": "Health Analytics",
    "doctor-reviews": "Doctor Reviews",
    "appointments": "Appointments",
    "notifications": "Notifications",
    "profile": "My Profile",
    "admin": "Admin Panel",
    "emergency": "Emergency Services",
    "doctors": "Find Doctors",
    "pharmacy": "Pharmacy",
    "health-dashboard": "Health Dashboard"
  }[activePage] || "HealMate";

  return (
    <>
      <header className="sticky top-0 z-40 glass-effect border-b border-white/30 shadow-lg">
        <div className="flex items-center justify-between px-4 py-3">
          {/* Logo & Title */}
          <div className="flex items-center gap-3">
            <img src={logoImage} alt="HealMate" className="h-10 w-auto hover-scale transition-transform" />
            {activePage !== "home" && (
              <h1 className="gradient-text text-lg">{pageTitle}</h1>
            )}
          </div>

          {/* Right Actions */}
          <div className="flex items-center gap-2">
            <div className="hidden md:block">
              <LanguageSwitcher />
            </div>
            
            <Button variant="ghost" size="icon" className="rounded-full hover:bg-gray-100">
              <Search className="w-5 h-5 text-gray-600" />
            </Button>
            
            <Button variant="ghost" size="icon" className="rounded-full hover:bg-gray-100 relative">
              <Bell className="w-5 h-5 text-gray-600" />
              <Badge className="absolute -top-1 -right-1 w-5 h-5 p-0 flex items-center justify-center bg-gradient-to-r from-red-500 to-pink-500 text-white text-xs shadow-lg animate-pulse-glow">
                3
              </Badge>
            </Button>

            {/* Profile Sidebar Toggle */}
            <Button 
              variant="ghost" 
              size="icon" 
              className="rounded-full hover:bg-gray-100"
              onClick={() => setSidebarOpen(true)}
            >
              <Menu className="w-6 h-6 text-gray-600" />
            </Button>
          </div>
        </div>
      </header>

      {/* Profile Sidebar */}
      <ProfileSidebar 
        isOpen={sidebarOpen} 
        onClose={() => setSidebarOpen(false)}
        setActivePage={setActivePage}
      />
    </>
  );
}
