// Category Detail Modal - د کټګورۍ بشپړ معلومات
// Modal for showing complete category information with books

import { useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "./ui/dialog";
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs";
import { Card, CardContent } from "./ui/card";
import {
  Star,
  Clock,
  Users,
  BookOpen,
  Download,
  FileText,
  Eye,
  Heart,
  Share2,
  Stethoscope,
  ChevronRight,
} from "lucide-react";
import { useLanguage } from "../contexts/LanguageContext";
import { toast } from "sonner@2.0.3";
import { BookDetailModal } from "./BookDetailModal";

interface Doctor {
  name: string;
  specialty: string;
  experience: string;
  rating: number;
  patients: string;
}

interface Book {
  title: string;
  titlePs: string;
  titleFa: string;
  author: string;
  pages: number;
  language: string;
  rating: number;
  summary?: string;
  summaryPs?: string;
  summaryFa?: string;
  downloads?: number;
  views?: number;
}

interface Category {
  id: string;
  label: string;
  labelPashto: string;
  labelDari: string;
  gradient: string;
  bgColor: string;
  icon: any;
  doctors: Doctor[];
  books: Book[];
}

interface CategoryDetailModalProps {
  isOpen: boolean;
  onClose: () => void;
  category: Category | null;
  setActivePage?: (page: string) => void;
}

export function CategoryDetailModal({
  isOpen,
  onClose,
  category,
  setActivePage,
}: CategoryDetailModalProps) {
  const { language } = useLanguage();
  const [selectedBook, setSelectedBook] = useState<Book | null>(null);
  const [isBookModalOpen, setIsBookModalOpen] = useState(false);
  const [bookCoverImage, setBookCoverImage] = useState("");

  if (!category) return null;

  // د هرې کټګورۍ لپاره د کتابونو HD عکسونه
  const getBookCoverImage = (categoryId: string, bookIndex: number): string => {
    const bookImages = {
      cardiology: [
        "https://images.unsplash.com/photo-1505751172876-fa1923c5c528?w=400&q=80",
        "https://images.unsplash.com/photo-1576091160550-2173dba999ef?w=400&q=80",
        "https://images.unsplash.com/photo-1628348070889-cb656235b4eb?w=400&q=80",
        "https://images.unsplash.com/photo-1530026405186-ed1f139313f8?w=400&q=80",
        "https://images.unsplash.com/photo-1584515933487-779824d29309?w=400&q=80"
      ],
      neurology: [
        "https://images.unsplash.com/photo-1559757175-5700dde675bc?w=400&q=80",
        "https://images.unsplash.com/photo-1617791160505-6f00504e3519?w=400&q=80",
        "https://images.unsplash.com/photo-1507413245164-6160d8298b31?w=400&q=80",
        "https://images.unsplash.com/photo-1532187863486-abf9dbad1b69?w=400&q=80",
        "https://images.unsplash.com/photo-1516549655169-df83a0774514?w=400&q=80"
      ],
      pediatrics: [
        "https://images.unsplash.com/photo-1503454537195-1dcabb73ffb9?w=400&q=80",
        "https://images.unsplash.com/photo-1490650034439-fd184c3c86a5?w=400&q=80",
        "https://images.unsplash.com/photo-1515488042361-ee00e0ddd4e4?w=400&q=80",
        "https://images.unsplash.com/photo-1519689373023-dd07c7988603?w=400&q=80",
        "https://images.unsplash.com/photo-1471286174890-9c112ffca5b4?w=400&q=80"
      ],
      gynecology: [
        "https://images.unsplash.com/photo-1555252333-9f8e92e65df9?w=400&q=80",
        "https://images.unsplash.com/photo-1584820927498-cfe5211fd8bf?w=400&q=80",
        "https://images.unsplash.com/photo-1555252332-17943b7c3ff2?w=400&q=80",
        "https://images.unsplash.com/photo-1555252332-17943b7c3ff2?w=400&q=80",
        "https://images.unsplash.com/photo-1493666438817-866a91353ca9?w=400&q=80"
      ],
      dentistry: [
        "https://images.unsplash.com/photo-1606811841689-23dfddce3e95?w=400&q=80",
        "https://images.unsplash.com/photo-1588776814546-1ffcf47267a5?w=400&q=80",
        "https://images.unsplash.com/photo-1609840112855-9ab5ad8f66e4?w=400&q=80",
        "https://images.unsplash.com/photo-1598256989800-fe5f95da9787?w=400&q=80",
        "https://images.unsplash.com/photo-1606811841689-23dfddce3e95?w=400&q=80"
      ],
      ophthalmology: [
        "https://images.unsplash.com/photo-1559757148-5c350d0d3c56?w=400&q=80",
        "https://images.unsplash.com/photo-1583947581924-860bda6a26df?w=400&q=80",
        "https://images.unsplash.com/photo-1485827404703-89b55fcc595e?w=400&q=80",
        "https://images.unsplash.com/photo-1591370874773-6702e8f12fd8?w=400&q=80",
        "https://images.unsplash.com/photo-1574169208507-84376144848b?w=400&q=80"
      ],
      dermatology: [
        "https://images.unsplash.com/photo-1570172619644-dfd03ed5d881?w=400&q=80",
        "https://images.unsplash.com/photo-1616394584738-fc6e612e71b9?w=400&q=80",
        "https://images.unsplash.com/photo-1512290923902-8a9f81dc236c?w=400&q=80",
        "https://images.unsplash.com/photo-1598440947619-2c35fc9aa908?w=400&q=80",
        "https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?w=400&q=80"
      ],
      orthopedics: [
        "https://images.unsplash.com/photo-1576091160399-112ba8d25d1d?w=400&q=80",
        "https://images.unsplash.com/photo-1579684385127-1ef15d508118?w=400&q=80",
        "https://images.unsplash.com/photo-1530497610245-94d3c16cda28?w=400&q=80",
        "https://images.unsplash.com/photo-1434494878577-86c23bcb06b9?w=400&q=80",
        "https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?w=400&q=80"
      ],
      general: [
        "https://images.unsplash.com/photo-1505751172876-fa1923c5c528?w=400&q=80",
        "https://images.unsplash.com/photo-1584820927498-cfe5211fd8bf?w=400&q=80",
        "https://images.unsplash.com/photo-1581594693702-fbdc51b2763b?w=400&q=80",
        "https://images.unsplash.com/photo-1576091160399-112ba8d25d1d?w=400&q=80",
        "https://images.unsplash.com/photo-1519494026892-80bbd2d6fd0d?w=400&q=80"
      ],
      ent: [
        "https://images.unsplash.com/photo-1579684385127-1ef15d508118?w=400&q=80",
        "https://images.unsplash.com/photo-1631217868264-e5b90bb7e133?w=400&q=80",
        "https://images.unsplash.com/photo-1584515933487-779824d29309?w=400&q=80",
        "https://images.unsplash.com/photo-1538108149393-fbbd81895907?w=400&q=80",
        "https://images.unsplash.com/photo-1576091160550-2173dba999ef?w=400&q=80"
      ],
      emergency: [
        "https://images.unsplash.com/photo-1614935151651-0bea6508db6b?w=400&q=80",
        "https://images.unsplash.com/photo-1582719471384-894fbb16e074?w=400&q=80",
        "https://images.unsplash.com/photo-1516549655169-df83a0774514?w=400&q=80",
        "https://images.unsplash.com/photo-1519494026892-80bbd2d6fd0d?w=400&q=80",
        "https://images.unsplash.com/photo-1530026405186-ed1f139313f8?w=400&q=80"
      ],
      psychiatry: [
        "https://images.unsplash.com/photo-1559757175-5700dde675bc?w=400&q=80",
        "https://images.unsplash.com/photo-1607619056574-7b8d3ee536b2?w=400&q=80",
        "https://images.unsplash.com/photo-1507652313519-d4e9174996dd?w=400&q=80",
        "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=400&q=80",
        "https://images.unsplash.com/photo-1516549655169-df83a0774514?w=400&q=80"
      ]
    };

    const categoryImages = bookImages[categoryId as keyof typeof bookImages] || bookImages.general;
    return categoryImages[bookIndex % categoryImages.length];
  };

  const categoryName =
    language === "ps"
      ? category.labelPashto
      : language === "fa"
      ? category.labelDari
      : category.label;

  const handleBookClick = (book: Book, index: number) => {
    setSelectedBook(book);
    setBookCoverImage(getBookCoverImage(category.id, index));
    setIsBookModalOpen(true);
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-5xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <div className={`flex items-center gap-4 p-6 rounded-2xl bg-gradient-to-br ${category.gradient} text-white -m-6 mb-6`}>
            <div className="w-16 h-16 bg-white/20 backdrop-blur-xl rounded-2xl flex items-center justify-center">
              <category.icon className="w-10 h-10" />
            </div>
            <div className="flex-1">
              <DialogTitle className="text-3xl text-white mb-2">
                {categoryName}
              </DialogTitle>
              <DialogDescription className="text-white/90 text-base">
                {language === "ps"
                  ? `${category.doctors.length} ډاکټران • ${category.books.length} کتابونه`
                  : language === "fa"
                  ? `${category.doctors.length} دکتر • ${category.books.length} کتاب`
                  : `${category.doctors.length} Doctors • ${category.books.length} Books`}
              </DialogDescription>
            </div>
          </div>
        </DialogHeader>

        <Tabs defaultValue="books" className="w-full">
          <TabsList className="grid w-full grid-cols-2 mb-6">
            <TabsTrigger value="books" className="gap-2">
              <BookOpen className="w-4 h-4" />
              {language === "ps" ? "کتابونه" : language === "fa" ? "کتاب‌ها" : "Books"}
              <Badge variant="secondary" className="ml-2">{category.books.length}</Badge>
            </TabsTrigger>
            <TabsTrigger value="doctors" className="gap-2">
              <Stethoscope className="w-4 h-4" />
              {language === "ps" ? "ډاکټران" : language === "fa" ? "دکتران" : "Doctors"}
              <Badge variant="secondary" className="ml-2">{category.doctors.length}</Badge>
            </TabsTrigger>
          </TabsList>

          {/* Books Tab */}
          <TabsContent value="books" className="space-y-4">
            {category.books.map((book, index) => (
              <Card
                key={index}
                onClick={() => handleBookClick(book, index)}
                className="hover:shadow-xl transition-all duration-300 border-2 border-gray-100 hover:border-emerald-300 cursor-pointer"
              >
                <CardContent className="p-6">
                  <div className="flex items-start gap-4">
                    {/* Book Cover Image - د کتاب HD عکس */}
                    <div className="w-20 h-28 rounded-xl overflow-hidden flex-shrink-0 shadow-lg relative group">
                      <img
                        src={getBookCoverImage(category.id, index)}
                        alt={book.title}
                        className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                      />
                      <div className={`absolute inset-0 bg-gradient-to-br ${category.gradient} opacity-20 group-hover:opacity-30 transition-opacity`}></div>
                    </div>

                    {/* Book Info */}
                    <div className="flex-1 min-w-0">
                      {/* Title */}
                      <h3 className="text-xl mb-2">
                        {language === "ps"
                          ? book.titlePs
                          : language === "fa"
                          ? book.titleFa
                          : book.title}
                      </h3>

                      {/* Author & Metadata */}
                      <div className="flex items-center gap-4 mb-3 text-sm text-gray-600">
                        <span className="flex items-center gap-1">
                          <FileText className="w-4 h-4" />
                          {book.author}
                        </span>
                        <span className="flex items-center gap-1">
                          <BookOpen className="w-4 h-4" />
                          {book.pages}{" "}
                          {language === "ps" ? "مخونه" : language === "fa" ? "صفحه" : "pages"}
                        </span>
                        <span className="flex items-center gap-1 text-amber-600">
                          <Star className="w-4 h-4 fill-amber-400" />
                          {book.rating}
                        </span>
                      </div>

                      {/* Stats */}
                      {(book.downloads || book.views) && (
                        <div className="flex items-center gap-4 mb-3 text-sm text-gray-500">
                          {book.downloads && (
                            <span className="flex items-center gap-1">
                              <Download className="w-4 h-4" />
                              {book.downloads.toLocaleString()}{" "}
                              {language === "ps"
                                ? "ډاونلوډونه"
                                : language === "fa"
                                ? "دانلود"
                                : "downloads"}
                            </span>
                          )}
                          {book.views && (
                            <span className="flex items-center gap-1">
                              <Eye className="w-4 h-4" />
                              {book.views.toLocaleString()}{" "}
                              {language === "ps" ? "لیدل" : language === "fa" ? "بازدید" : "views"}
                            </span>
                          )}
                        </div>
                      )}

                      {/* Click to View Message */}
                      <div className="mt-3 p-3 bg-gradient-to-r from-emerald-50 to-teal-50 rounded-lg border border-emerald-200">
                        <p className="text-sm text-emerald-700 flex items-center gap-2">
                          <ChevronRight className="w-4 h-4" />
                          {language === "ps"
                            ? "د بشپړ معلوماتو او ډاونلوډ لپاره کلیک وکړئ"
                            : language === "fa"
                            ? "برای اطلاعات کامل و دانلود کلیک کنید"
                            : "Click for full details and download"}
                        </p>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </TabsContent>

          {/* Doctors Tab */}
          <TabsContent value="doctors" className="space-y-4">
            {category.doctors.map((doctor, index) => (
              <Card key={index} className="hover:shadow-xl transition-all duration-300 border-2 border-gray-100 hover:border-blue-200">
                <CardContent className="p-6">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <h3 className="text-xl mb-2">{doctor.name}</h3>
                      <p className={`text-sm mb-3 bg-gradient-to-r ${category.gradient} bg-clip-text text-transparent font-medium`}>
                        {doctor.specialty}
                      </p>
                      <div className="flex items-center gap-4 text-sm text-gray-600">
                        <span className="flex items-center gap-1">
                          <Clock className="w-4 h-4" />
                          {doctor.experience}
                        </span>
                        <span className="flex items-center gap-1">
                          <Users className="w-4 h-4" />
                          {doctor.patients}{" "}
                          {language === "ps" ? "ناروغان" : language === "fa" ? "بیمار" : "patients"}
                        </span>
                        <span className="flex items-center gap-1 text-amber-600">
                          <Star className="w-4 h-4 fill-amber-400" />
                          {doctor.rating}
                        </span>
                      </div>
                    </div>
                    <Button
                      onClick={() => {
                        setActivePage?.("doctors");
                        onClose();
                      }}
                      className={`bg-gradient-to-r ${category.gradient} hover:opacity-90 text-white gap-2`}
                    >
                      {language === "ps" ? "ملاقات" : language === "fa" ? "نوبت" : "Book"}
                      <ChevronRight className="w-4 h-4" />
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}

            <Button
              onClick={() => {
                setActivePage?.("doctors");
                onClose();
              }}
              variant="outline"
              className="w-full"
            >
              {language === "ps"
                ? "ټول ډاکټران وګورئ"
                : language === "fa"
                ? "مشاهده همه دکترها"
                : "View All Doctors"}
              <ChevronRight className="w-4 h-4 ml-2" />
            </Button>
          </TabsContent>
        </Tabs>
      </DialogContent>

      {/* Book Detail Modal - د کتاب بشپړ معلومات */}
      <BookDetailModal
        isOpen={isBookModalOpen}
        onClose={() => setIsBookModalOpen(false)}
        book={selectedBook}
        categoryGradient={category.gradient}
        categoryBgColor={category.bgColor}
        bookCoverImage={bookCoverImage}
      />
    </Dialog>
  );
}
