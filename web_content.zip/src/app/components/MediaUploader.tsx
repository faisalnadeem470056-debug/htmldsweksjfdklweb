import { useState, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Image as ImageIcon, Video, Upload, X, Camera, Search, Link } from 'lucide-react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { ImageWithFallback } from './figma/ImageWithFallback';

interface MediaUploaderProps {
  language: 'ps' | 'fa' | 'en';
  images: string[];
  videos: string[];
  onImagesChange: (images: string[]) => void;
  onVideosChange: (videos: string[]) => void;
}

export function MediaUploader({ 
  language, 
  images, 
  videos, 
  onImagesChange, 
  onVideosChange 
}: MediaUploaderProps) {
  const [showUploadMenu, setShowUploadMenu] = useState(false);
  const [uploadType, setUploadType] = useState<'image' | 'video' | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [unsplashResults, setUnsplashResults] = useState<string[]>([]);
  const [isSearching, setIsSearching] = useState(false);
  const [showSearchModal, setShowSearchModal] = useState(false);
  
  const imageInputRef = useRef<HTMLInputElement>(null);
  const videoInputRef = useRef<HTMLInputElement>(null);

  const texts = {
    ps: {
      addMedia: 'میډیا اضافه کړئ',
      addPhoto: 'عکس اضافه کړئ',
      addVideo: 'ویډیو اضافه کړئ',
      uploadFromDevice: 'د ډیوائس څخه اپلوډ',
      searchUnsplash: 'د Unsplash څخه پلټنه',
      takePhoto: 'عکس اخیستل',
      cancel: 'لغوه',
      search: 'پلټنه',
      searching: 'په پلټنې کې...',
      selectPhoto: 'عکس غوره کړئ',
      noResults: 'هیڅ نتیجه ونه موندل شوه',
      searchPlaceholder: 'د عکسونو لپاره پلټنه...',
      uploading: 'اپلوډیږي...',
      uploadSuccess: '✅ اپلوډ بریالیتوب!',
      uploadError: '❌ اپلوډ ستونزه',
      fileTooLarge: 'فایل ډیر لوی دی (Max 5MB)',
      invalidFileType: 'د فایل ډول سم نه دی',
      maxFiles: 'تاسو یوازې 10 فایلونه اضافه کولی شئ',
    },
    fa: {
      addMedia: 'افزودن رسانه',
      addPhoto: 'افزودن عکس',
      addVideo: 'افزودن ویدیو',
      uploadFromDevice: 'آپلود از دستگاه',
      searchUnsplash: 'جستجو در Unsplash',
      takePhoto: 'گرفتن عکس',
      cancel: 'لغو',
      search: 'جستجو',
      searching: 'در حال جستجو...',
      selectPhoto: 'انتخاب عکس',
      noResults: 'نتیجه‌ای یافت نشد',
      searchPlaceholder: 'جستجو برای عکس‌ها...',
      uploading: 'در حال آپلود...',
      uploadSuccess: '✅ آپلود موفق!',
      uploadError: '❌ خطا در آپلود',
      fileTooLarge: 'فایل بیش از حد بزرگ است (حداکثر 5MB)',
      invalidFileType: 'نوع فایل نامعتبر است',
      maxFiles: 'فقط می‌توانید 10 فایل اضافه کنید',
    },
    en: {
      addMedia: 'Add Media',
      addPhoto: 'Add Photo',
      addVideo: 'Add Video',
      uploadFromDevice: 'Upload from Device',
      searchUnsplash: 'Search Unsplash',
      takePhoto: 'Take Photo',
      cancel: 'Cancel',
      search: 'Search',
      searching: 'Searching...',
      selectPhoto: 'Select Photo',
      noResults: 'No results found',
      searchPlaceholder: 'Search for photos...',
      uploading: 'Uploading...',
      uploadSuccess: '✅ Upload Success!',
      uploadError: '❌ Upload Error',
      fileTooLarge: 'File too large (Max 5MB)',
      invalidFileType: 'Invalid file type',
      maxFiles: 'You can only add 10 files',
    },
  };

  const t = texts[language];

  // د عکس upload
  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files) return;

    if (images.length + files.length > 10) {
      alert(t.maxFiles);
      return;
    }

    Array.from(files).forEach((file) => {
      // د فایل سایز چک کول (5MB)
      if (file.size > 5 * 1024 * 1024) {
        alert(`${file.name}: ${t.fileTooLarge}`);
        return;
      }

      // د فایل type چک کول
      if (!file.type.startsWith('image/')) {
        alert(`${file.name}: ${t.invalidFileType}`);
        return;
      }

      const reader = new FileReader();
      reader.onloadend = () => {
        const result = reader.result as string;
        onImagesChange([...images, result]);
      };
      reader.onerror = () => {
        alert(t.uploadError);
      };
      reader.readAsDataURL(file);
    });

    // Reset input
    if (imageInputRef.current) {
      imageInputRef.current.value = '';
    }
  };

  // د ویډیو upload
  const handleVideoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files) return;

    if (videos.length + files.length > 5) {
      alert(language === 'ps' ? 'تاسو یوازې 5 ویډیو اضافه کولی شئ' : 
            language === 'fa' ? 'فقط می‌توانید 5 ویدیو اضافه کنید' :
            'You can only add 5 videos');
      return;
    }

    Array.from(files).forEach((file) => {
      // د فایل سایز چک کول (50MB)
      if (file.size > 50 * 1024 * 1024) {
        alert(`${file.name}: ${language === 'ps' ? 'فایل ډیر لوی دی (Max 50MB)' : 
              language === 'fa' ? 'فایل بیش از حد بزرگ است (حداکثر 50MB)' :
              'File too large (Max 50MB)'}`);
        return;
      }

      // د فایل type چک کول
      if (!file.type.startsWith('video/')) {
        alert(`${file.name}: ${t.invalidFileType}`);
        return;
      }

      const reader = new FileReader();
      reader.onloadend = () => {
        const result = reader.result as string;
        onVideosChange([...videos, result]);
      };
      reader.onerror = () => {
        alert(t.uploadError);
      };
      reader.readAsDataURL(file);
    });

    // Reset input
    if (videoInputRef.current) {
      videoInputRef.current.value = '';
    }
  };

  // د Unsplash پلټنه
  const handleUnsplashSearch = async () => {
    if (!searchQuery.trim()) return;
    
    setIsSearching(true);
    try {
      // د Unsplash sample عکسونه - په حقیقي اپلیکیشن کې د API استعمال کړئ
      const mockResults = [
        `https://images.unsplash.com/photo-1576091160399-112ba8d25d1d?w=800&q=80`,
        `https://images.unsplash.com/photo-1584820927498-cfe5211fd8bf?w=800&q=80`,
        `https://images.unsplash.com/photo-1559757175-5700dde675bc?w=800&q=80`,
        `https://images.unsplash.com/photo-1505751172876-fa1923c5c528?w=800&q=80`,
        `https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?w=800&q=80`,
        `https://images.unsplash.com/photo-1638202993928-7267aad84c31?w=800&q=80`,
      ];
      
      await new Promise(resolve => setTimeout(resolve, 1000));
      setUnsplashResults(mockResults);
    } catch (error) {
      console.error('Search error:', error);
    } finally {
      setIsSearching(false);
    }
  };

  // د Unsplash عکس غوره کول
  const handleSelectUnsplashImage = (imageUrl: string) => {
    if (images.length >= 10) {
      alert(t.maxFiles);
      return;
    }
    onImagesChange([...images, imageUrl]);
    setShowSearchModal(false);
    setSearchQuery('');
    setUnsplashResults([]);
  };

  // د عکس لرې کول
  const handleRemoveImage = (index: number) => {
    onImagesChange(images.filter((_, i) => i !== index));
  };

  // د ویډیو لرې کول
  const handleRemoveVideo = (index: number) => {
    onVideosChange(videos.filter((_, i) => i !== index));
  };

  return (
    <div className="space-y-4">
      {/* Hidden File Inputs */}
      <input
        ref={imageInputRef}
        type="file"
        accept="image/*"
        multiple
        onChange={handleImageUpload}
        className="hidden"
      />
      <input
        ref={videoInputRef}
        type="file"
        accept="video/*"
        multiple
        onChange={handleVideoUpload}
        className="hidden"
      />

      {/* Upload Buttons */}
      <div className="flex flex-wrap gap-2">
        <Button
          type="button"
          onClick={() => imageInputRef.current?.click()}
          variant="outline"
          size="sm"
          className="flex items-center gap-2 bg-gradient-to-r from-purple-50 to-pink-50 border-purple-200 hover:border-purple-300"
        >
          <Upload className="w-4 h-4 text-purple-600" />
          <span className="text-purple-700">{t.addPhoto}</span>
        </Button>

        <Button
          type="button"
          onClick={() => setShowSearchModal(true)}
          variant="outline"
          size="sm"
          className="flex items-center gap-2 bg-gradient-to-r from-blue-50 to-cyan-50 border-blue-200 hover:border-blue-300"
        >
          <Search className="w-4 h-4 text-blue-600" />
          <span className="text-blue-700">{t.searchUnsplash}</span>
        </Button>

        <Button
          type="button"
          onClick={() => videoInputRef.current?.click()}
          variant="outline"
          size="sm"
          className="flex items-center gap-2 bg-gradient-to-r from-green-50 to-emerald-50 border-green-200 hover:border-green-300"
        >
          <Video className="w-4 h-4 text-green-600" />
          <span className="text-green-700">{t.addVideo}</span>
        </Button>
      </div>

      {/* Uploaded Images Preview */}
      {images.length > 0 && (
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
          {images.map((image, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.8 }}
              className="relative rounded-xl overflow-hidden aspect-square bg-gray-100"
            >
              <ImageWithFallback
                src={image}
                alt={`Upload ${index + 1}`}
                className="w-full h-full object-cover"
              />
              <button
                type="button"
                onClick={() => handleRemoveImage(index)}
                className="absolute top-2 right-2 bg-red-500 hover:bg-red-600 text-white p-1.5 rounded-full shadow-lg transition-colors"
              >
                <X className="w-4 h-4" />
              </button>
              <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/50 to-transparent p-2">
                <p className="text-white text-xs text-center">
                  {index + 1}/{images.length}
                </p>
              </div>
            </motion.div>
          ))}
        </div>
      )}

      {/* Uploaded Videos Preview */}
      {videos.length > 0 && (
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
          {videos.map((video, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.8 }}
              className="relative rounded-xl overflow-hidden bg-gray-100"
            >
              <video
                src={video}
                className="w-full h-48 object-cover"
                controls
              />
              <button
                type="button"
                onClick={() => handleRemoveVideo(index)}
                className="absolute top-2 right-2 bg-red-500 hover:bg-red-600 text-white p-1.5 rounded-full shadow-lg transition-colors"
              >
                <X className="w-4 h-4" />
              </button>
            </motion.div>
          ))}
        </div>
      )}

      {/* Unsplash Search Modal */}
      <AnimatePresence>
        {showSearchModal && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4"
            onClick={() => setShowSearchModal(false)}
          >
            <motion.div
              initial={{ scale: 0.9, y: 20 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.9, y: 20 }}
              onClick={(e) => e.stopPropagation()}
              className="bg-white rounded-3xl p-6 max-w-2xl w-full max-h-[80vh] overflow-y-auto"
            >
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-xl font-bold">{t.searchUnsplash}</h3>
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => setShowSearchModal(false)}
                >
                  <X className="w-5 h-5" />
                </Button>
              </div>

              <div className="flex gap-2 mb-4">
                <Input
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder={t.searchPlaceholder}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') {
                      handleUnsplashSearch();
                    }
                  }}
                  className="flex-1"
                  dir={language === 'en' ? 'ltr' : 'rtl'}
                />
                <Button
                  onClick={handleUnsplashSearch}
                  disabled={isSearching || !searchQuery.trim()}
                  className="bg-gradient-to-r from-blue-500 to-cyan-600"
                >
                  <Search className="w-4 h-4 mr-2" />
                  {isSearching ? t.searching : t.search}
                </Button>
              </div>

              {unsplashResults.length > 0 ? (
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                  {unsplashResults.map((imageUrl, index) => (
                    <motion.div
                      key={index}
                      initial={{ opacity: 0, scale: 0.8 }}
                      animate={{ opacity: 1, scale: 1 }}
                      className="relative rounded-xl overflow-hidden aspect-square cursor-pointer group"
                      onClick={() => handleSelectUnsplashImage(imageUrl)}
                    >
                      <ImageWithFallback
                        src={imageUrl}
                        alt={`Result ${index + 1}`}
                        className="w-full h-full object-cover"
                      />
                      <div className="absolute inset-0 bg-black/0 group-hover:bg-black/30 transition-colors flex items-center justify-center">
                        <div className="opacity-0 group-hover:opacity-100 transition-opacity">
                          <div className="bg-white rounded-full p-2">
                            <ImageIcon className="w-5 h-5 text-purple-600" />
                          </div>
                        </div>
                      </div>
                    </motion.div>
                  ))}
                </div>
              ) : searchQuery && !isSearching ? (
                <div className="text-center py-12">
                  <Search className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                  <p className="text-gray-600">{t.noResults}</p>
                </div>
              ) : null}
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
