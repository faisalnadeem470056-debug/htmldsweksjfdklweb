import { useState, useEffect, useRef } from 'react';
import { ArrowLeft, Send, Bot, User, Copy, Download, Plus, Trash2, Crown, Sparkles, MessageCircle } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Textarea } from './ui/textarea';
import { AdBanner } from './AdBanner';
import { copyToClipboard } from '../utils/clipboard';

interface AIHealthAssistantProps {
  language: 'ps' | 'fa' | 'en';
  currentUser: any;
  onBack: () => void;
  onUpgrade: () => void;
}

interface Message {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: string;
  language: 'ps' | 'fa' | 'en';
  aiLevel?: 'basic' | 'advanced';
  liked?: boolean;
  disliked?: boolean;
}

interface ChatHistory {
  id: string;
  title: string;
  messages: Message[];
  createdAt: string;
  updatedAt: string;
}

export function AIHealthAssistant({ language, currentUser, onBack, onUpgrade }: AIHealthAssistantProps) {
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [chatHistories, setChatHistories] = useState<ChatHistory[]>([]);
  const [currentChatId, setCurrentChatId] = useState<string | null>(null);
  const [showHistory, setShowHistory] = useState(false);
  const [showSettings, setShowSettings] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const { isPremium } = usePremium(currentUser?.id);

  const t = {
    ps: {
      title: isPremium ? 'Advanced AI معاون' : 'AI روغتیا معاون',
      subtitle: isPremium ? 'د پرمختللي AI سره خبرې وکړئ' : 'د بنسټیز AI سره خبرې وکړئ',
      placeholder: 'خپله پوښتنه دلته ولیکئ...',
      send: 'لیږل',
      typing: 'لیکي...',
      newChat: 'نوې خبرې اترې',
      history: 'تاریخچه',
      settings: 'ترتیبات',
      clear: 'پاکول',
      delete: 'حذف',
      download: 'ډاونلوډ',
      copy: 'کاپي',
      copied: 'کاپي شو',
      like: 'خوښول',
      dislike: 'نا خوښول',
      retry: 'بیا هڅه',
      basicAI: 'بنسټیز AI',
      advancedAI: 'پرمختللی AI',
      upgradeForAdvanced: 'د پرمختللي AI لپاره Premium ته لوړ کړئ',
      quickQuestions: 'چټکې پوښتنې',
      suggested: 'وړاندیز شوي',
      disclaimer: 'یادښت: دا AI معاون د طبي مشورې بدیل نه دی. د جدي مسلو لپاره دوکتور ته مراجعه وکړئ.',
      limitations: {
        basic: 'بنسټیز AI - محدود ځوابونه',
        advanced: 'پرمختللی AI - تفصیلي او دقیق ځوابونه'
      },
      features: {
        basic: [
          'بنسټیز روغتیا معلومات',
          '۳ پوښتنې په ورځ',
          'ساده ځوابونه',
          'د اعلاناتو سره'
        ],
        advanced: [
          'تفصیلي طبي معلومات',
          'لامحدود پوښتنې',
          'شخصي مشورې',
          'د اعلاناتو پرته',
          'د خبرو اترو ساتل',
          'ډاونلوډ کول'
        ]
      },
      quickQuestionsList: [
        'د سر درد علت څه دی؟',
        'د تبې د کمولو لارې؟',
        'د زړه روغتیا څنګه ساتو؟',
        'د وینې فشار کنټرول؟'
      ],
      aiResponses: {
        greeting: 'سلام! زه ستاسو د AI روغتیا معاون یم. زه ستاسو د روغتیا په اړه پوښتنو ته ځواب ورکولی شم.',
        basicLimit: 'تاسو نن ورځ خپل ۳ پوښتنې کارولي دي. د نورو پوښتنو لپاره Premium ته لوړ کړئ.',
        helpPrompt: 'د مرستې لپاره، تاسو کولی شئ په اړه پوښتنه وکړئ:\n• عمومي روغتیا\n• ناروغۍ نښې\n• د درملو معلومات\n• د روغتیا پاملرنه'
      }
    },
    fa: {
      title: isPremium ? 'معاون Advanced AI' : 'معاون سلامت AI',
      subtitle: isPremium ? 'با AI پیشرفته صحبت کنید' : 'با AI پایه صحبت کنید',
      placeholder: 'سوال خود را اینجا بنویسید...',
      send: 'ارسال',
      typing: 'در حال نوشتن...',
      newChat: 'گفتگوی جدید',
      history: 'تاریخچه',
      settings: 'تنظیمات',
      clear: 'پاک کردن',
      delete: 'حذف',
      download: 'دانلود',
      copy: 'کپی',
      copied: 'کپی شد',
      like: 'پسندیدن',
      dislike: 'نپسندیدن',
      retry: 'تلاش مجدد',
      basicAI: 'AI پایه',
      advancedAI: 'AI پیشرفته',
      upgradeForAdvanced: 'برای AI پیشرفته به Premium ارتقا دهید',
      quickQuestions: 'سوالات سریع',
      suggested: 'پیشنهادی',
      disclaimer: 'توجه: این معاون AI جایگزین مشاوره پزشکی نیست. برای مسائل جدی به پزشک مراجعه کنید.',
      limitations: {
        basic: 'AI پایه - پاسخ‌های محدود',
        advanced: 'AI پیشرفته - پاسخ‌های دقیق و تفصیلی'
      },
      features: {
        basic: [
          'اطلاعات پایه سلامت',
          '۳ سوال در روز',
          'پاسخ‌های ساده',
          'با تبلیغات'
        ],
        advanced: [
          'اطلاعات تفصیلی پزشکی',
          'سوالات نامحدود',
          'مشاوره شخصی',
          'بدون تبلیغات',
          'ذخیره گفتگو',
          'دانلود'
        ]
      },
      quickQuestionsList: [
        'علت سردرد چیست؟',
        'راه‌های کاهش تب؟',
        'چگونه سلامت قلب را حفظ کنیم؟',
        'کنترل فشار خون؟'
      ],
      aiResponses: {
        greeting: 'سلام! من معاون سلامت AI شما هستم. می‌توانم به سوالات شما درباره سلامت پاسخ دهم.',
        basicLimit: 'شما امروز ۳ سوال خود را استفاده کرده‌اید. برای سوالات بیشتر به Premium ارتقا دهید.',
        helpPrompt: 'برای کمک، می‌توانید در مورد:\n• سلامت عمومی\n• علائم بیماری\n• اطلاعات دارویی\n• مراقبت سلامت\nسوال بپرسید'
      }
    },
    en: {
      title: isPremium ? 'Advanced AI Assistant' : 'AI Health Assistant',
      subtitle: isPremium ? 'Chat with Advanced AI' : 'Chat with Basic AI',
      placeholder: 'Type your question here...',
      send: 'Send',
      typing: 'Typing...',
      newChat: 'New Chat',
      history: 'History',
      settings: 'Settings',
      clear: 'Clear',
      delete: 'Delete',
      download: 'Download',
      copy: 'Copy',
      copied: 'Copied',
      like: 'Like',
      dislike: 'Dislike',
      retry: 'Retry',
      basicAI: 'Basic AI',
      advancedAI: 'Advanced AI',
      upgradeForAdvanced: 'Upgrade to Premium for Advanced AI',
      quickQuestions: 'Quick Questions',
      suggested: 'Suggested',
      disclaimer: 'Note: This AI assistant is not a substitute for medical advice. Consult a doctor for serious issues.',
      limitations: {
        basic: 'Basic AI - Limited responses',
        advanced: 'Advanced AI - Detailed and accurate responses'
      },
      features: {
        basic: [
          'Basic health information',
          '3 questions per day',
          'Simple answers',
          'With ads'
        ],
        advanced: [
          'Detailed medical information',
          'Unlimited questions',
          'Personalized advice',
          'Ad-free',
          'Save conversations',
          'Download'
        ]
      },
      quickQuestionsList: [
        'What causes headaches?',
        'How to reduce fever?',
        'How to maintain heart health?',
        'Control blood pressure?'
      ],
      aiResponses: {
        greeting: 'Hello! I am your AI health assistant. I can answer your health-related questions.',
        basicLimit: 'You have used your 3 questions today. Upgrade to Premium for more questions.',
        helpPrompt: 'For help, you can ask about:\n• General health\n• Disease symptoms\n• Medication information\n• Health care'
      }
    }
  };

  const text = t[language];

  useEffect(() => {
    loadChatHistories();
    scrollToBottom();
  }, [currentUser]);

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  const loadChatHistories = () => {
    if (!currentUser) return;
    const saved = localStorage.getItem(`healmate_ai_chats_${currentUser.id}`);
    if (saved) {
      setChatHistories(JSON.parse(saved));
    }
  };

  const saveChatHistory = () => {
    if (!currentUser || messages.length === 0) return;

    const chatHistory: ChatHistory = {
      id: currentChatId || `chat_${Date.now()}`,
      title: messages[0]?.content.substring(0, 50) || 'New Chat',
      messages,
      createdAt: currentChatId ? chatHistories.find(c => c.id === currentChatId)?.createdAt || new Date().toISOString() : new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };

    const updated = currentChatId
      ? chatHistories.map(c => c.id === currentChatId ? chatHistory : c)
      : [chatHistory, ...chatHistories];

    setChatHistories(updated);
    localStorage.setItem(`healmate_ai_chats_${currentUser.id}`, JSON.stringify(updated));
    
    if (!currentChatId) {
      setCurrentChatId(chatHistory.id);
    }
  };

  const checkDailyLimit = (): boolean => {
    if (isPremium) return true;

    const today = new Date().toDateString();
    const key = `healmate_ai_questions_${currentUser?.id}_${today}`;
    const count = parseInt(localStorage.getItem(key) || '0');

    return count < 3;
  };

  const incrementQuestionCount = () => {
    if (isPremium) return;

    const today = new Date().toDateString();
    const key = `healmate_ai_questions_${currentUser?.id}_${today}`;
    const count = parseInt(localStorage.getItem(key) || '0');
    localStorage.setItem(key, (count + 1).toString());
  };

  const getRemainingQuestions = (): number => {
    if (isPremium) return Infinity;

    const today = new Date().toDateString();
    const key = `healmate_ai_questions_${currentUser?.id}_${today}`;
    const count = parseInt(localStorage.getItem(key) || '0');
    return Math.max(0, 3 - count);
  };

  const generateAIResponse = async (userMessage: string): Promise<string> => {
    // Simulate AI processing time
    await new Promise(resolve => setTimeout(resolve, 1500));

    const lowerMessage = userMessage.toLowerCase();

    // Medical Knowledge Base Responses
    const responses = {
      ps: {
        headache: 'د سر درد ډیری علتونه شامل دي:\n\n1. فشار او اضطراب\n2. د خوب کموالی\n3. د اوبو کموالی\n4. د سترګو ستړیا\n5. د وینې فشار\n\nد سر د درد د کمولو لپاره:\n• کافي اوبه وڅښئ (۸-۱۰ ګیلاس په ورځ)\n• ښه خوب وکړئ (۷-۸ ساعته)\n• فشار اداره کړئ\n• منظم ورزش وکړئ\n\nکه درد جدي وي یا زیات وخت پاتې شي، دوکتر ته مراجعه وکړئ.',
        fever: 'د تبې د کمولو لارې:\n\n1. کافي اوبه وڅښئ\n2. یخ کمپرس وکاروئ\n3. سپک جامې اغوندئ\n4. آرام کړئ\n5. Paracetamol استعمال کړئ (د دوکتر مشورې سره)\n\nکه تبه له ۳ ورځو زیاته وي یا له ۱۰۳°F (۳۹.۴°C) لوړه وي، ژر دوکتر ته لاړ شئ.',
        heart: 'د زړه روغتیا ساتل:\n\n1. سالم خوراک:\n   • میوې او سبزیجات\n   • کم چربي\n   • مالګه او کاجو\n\n2. منظم ورزش:\n   • ۳۰ دقیقې په ورځ\n   • د تګ راتګ\n   • جاګنګ یا لامبو\n\n3. د فشار اداره\n4. سګرټ مه څکئ\n5. منظم معاینه',
        pressure: 'د وینې فشار کنټرول:\n\n1. د خوراک تغیرات:\n   • د مالګې کموالی\n   • میوې او سبزیجات\n   • کم چربي\n\n2. د وزن کنټرول\n3. منظم ورزش\n4. د الکول کموالی\n5. د فشار اداره\n6. کافي خوب\n\nهره ورځ د فشار څارنه کړئ او د دوکتر مشورې سره درمل استعمال کړئ.',
        default: isPremium
          ? 'د تاسو پوښتنه زما لپاره ځانګړې ده. زه د عمومي روغتیا معلومات ورکولی شم.\n\nتاسو کولی شئ په اړه پوښتنه وکړئ:\n• د سر درد\n• تبې\n• زړه روغتیا\n• وینې فشار\n• خوراک\n• ورزش\n\nمهرباني وکړئ خپله پوښتنه تفصیل سره ولیکئ.'
          : 'زه یوازې بنسټیز معلومات ورکولی شم. د تفصیلي معلوماتو لپاره Premium ته لوړ کړئ.\n\nد عمومي معلوماتو لپاره پوښتنه وکړئ.'
      },
      fa: {
        headache: 'علل اصلی سردرد شامل:\n\n1. استرس و اضطراب\n2. کمبود خواب\n3. کم آبی بدن\n4. خستگی چشم\n5. فشار خون\n\nبرای کاهش سردرد:\n• آب کافی بنوشید (۸-۱۰ لیوان در روز)\n• خواب کافی داشته باشید (۷-۸ ساعت)\n• استرس را مدیریت کنید\n• ورزش منظم انجام دهید\n\nاگر درد شدید یا مداوم است، به پزشک مراجعه کنید.',
        fever: 'راه‌های کاهش تب:\n\n1. آب کافی بنوشید\n2. کمپرس سرد استفاده کنید\n3. لباس سبک بپوشید\n4. استراحت کنید\n5. از Paracetamol استفاده کنید (با مشورت پزشک)\n\nاگر تب بیش از ۳ روز ادامه دارد یا بالاتر از ۱۰۳°F (۳۹.۴°C) است، فوراً به پزشک مراجعه کنید.',
        heart: 'حفظ سلامت قلب:\n\n1. رژیم غذایی سالم:\n   • میوه و سبزیجات\n   • کم چربی\n   • آجیل و مغزها\n\n2. ورزش منظم:\n   • ۳۰ دقیقه در روز\n   • پیاده‌روی\n   • دویدن یا شنا\n\n3. مدیریت استرس\n4. ترک سیگار\n5. معاینات منظم',
        pressure: 'کنترل فشار خون:\n\n1. تغییرات غذایی:\n   • کاهش نمک\n   • میوه و سبزیجات\n   • کم چربی\n\n2. کنترل وزن\n3. ورزش منظم\n4. کاهش الکل\n5. مدیریت استرس\n6. خواب کافی\n\nهر روز فشار خود را بررسی و با مشورت پزشک دارو مصرف کنید.',
        default: isPremium
          ? 'سوال شما برای من خاص است. من می‌توانم اطلاعات سلامت عمومی ارائه دهم.\n\nمی‌توانید در مورد:\n• سردرد\n• تب\n• سلامت قلب\n• فشار خون\n• تغذیه\n• ورزش\n\nلطفاً سوال خود را با جزئیات بنویسید.'
          : 'من فقط می‌توانم اطلاعات پایه ارائه دهم. برای اطلاعات تفصیلی به Premium ارتقا دهید.\n\nبرای اطلاعات عمومی سوال بپرسید.'
      },
      en: {
        headache: 'Main causes of headaches:\n\n1. Stress and anxiety\n2. Lack of sleep\n3. Dehydration\n4. Eye strain\n5. Blood pressure\n\nTo reduce headaches:\n• Drink enough water (8-10 glasses per day)\n• Get adequate sleep (7-8 hours)\n• Manage stress\n• Exercise regularly\n\nIf pain is severe or persistent, consult a doctor.',
        fever: 'Ways to reduce fever:\n\n1. Drink plenty of water\n2. Use cold compress\n3. Wear light clothing\n4. Rest\n5. Take Paracetamol (consult doctor)\n\nIf fever lasts more than 3 days or is higher than 103°F (39.4°C), see a doctor immediately.',
        heart: 'Maintaining heart health:\n\n1. Healthy diet:\n   • Fruits and vegetables\n   • Low fat\n   • Nuts and seeds\n\n2. Regular exercise:\n   • 30 minutes per day\n   • Walking\n   • Jogging or swimming\n\n3. Stress management\n4. Quit smoking\n5. Regular checkups',
        pressure: 'Blood pressure control:\n\n1. Dietary changes:\n   • Reduce salt\n   • Fruits and vegetables\n   • Low fat\n\n2. Weight control\n3. Regular exercise\n4. Reduce alcohol\n5. Stress management\n6. Adequate sleep\n\nCheck your pressure daily and take medication as prescribed by doctor.',
        default: isPremium
          ? 'Your question is specific. I can provide general health information.\n\nYou can ask about:\n• Headaches\n• Fever\n• Heart health\n• Blood pressure\n• Nutrition\n• Exercise\n\nPlease write your question in detail.'
          : 'I can only provide basic information. Upgrade to Premium for detailed information.\n\nAsk for general information.'
      }
    };

    const langResponses = responses[language];

    // Detect keywords and provide appropriate response
    if (lowerMessage.includes('head') || lowerMessage.includes('سر') || lowerMessage.includes('سردرد')) {
      return langResponses.headache;
    } else if (lowerMessage.includes('fever') || lowerMessage.includes('تب') || lowerMessage.includes('تبه')) {
      return langResponses.fever;
    } else if (lowerMessage.includes('heart') || lowerMessage.includes('زړه') || lowerMessage.includes('قلب')) {
      return langResponses.heart;
    } else if (lowerMessage.includes('pressure') || lowerMessage.includes('فشار') || lowerMessage.includes('blood')) {
      return langResponses.pressure;
    } else {
      return langResponses.default;
    }
  };

  const handleSend = async () => {
    if (!input.trim() || isTyping) return;

    // Check daily limit for free users
    if (!checkDailyLimit()) {
      alert(text.aiResponses.basicLimit);
      onUpgrade();
      return;
    }

    const userMessage: Message = {
      id: `msg_${Date.now()}`,
      role: 'user',
      content: input.trim(),
      timestamp: new Date().toISOString(),
      language
    };

    setMessages(prev => [...prev, userMessage]);
    setInput('');
    setIsTyping(true);

    // Increment question count
    incrementQuestionCount();

    try {
      const response = await generateAIResponse(userMessage.content);

      const aiMessage: Message = {
        id: `msg_${Date.now()}_ai`,
        role: 'assistant',
        content: response,
        timestamp: new Date().toISOString(),
        language,
        aiLevel: isPremium ? 'advanced' : 'basic'
      };

      setMessages(prev => [...prev, aiMessage]);
    } catch (error) {
      console.error('AI Error:', error);
    } finally {
      setIsTyping(false);
    }
  };

  const handleQuickQuestion = (question: string) => {
    setInput(question);
  };

  const handleNewChat = () => {
    if (messages.length > 0) {
      saveChatHistory();
    }
    setMessages([]);
    setCurrentChatId(null);
    
    // Send welcome message
    const welcomeMessage: Message = {
      id: `msg_${Date.now()}`,
      role: 'assistant',
      content: text.aiResponses.greeting,
      timestamp: new Date().toISOString(),
      language,
      aiLevel: isPremium ? 'advanced' : 'basic'
    };
    setMessages([welcomeMessage]);
  };

  const handleLoadChat = (chatId: string) => {
    const chat = chatHistories.find(c => c.id === chatId);
    if (chat) {
      setMessages(chat.messages);
      setCurrentChatId(chatId);
      setShowHistory(false);
    }
  };

  const handleDeleteChat = (chatId: string) => {
    const updated = chatHistories.filter(c => c.id !== chatId);
    setChatHistories(updated);
    localStorage.setItem(`healmate_ai_chats_${currentUser.id}`, JSON.stringify(updated));
    
    if (currentChatId === chatId) {
      handleNewChat();
    }
  };

  const handleCopyMessage = (content: string) => {
    copyToClipboard(content);
    alert(text.copied);
  };

  const handleDownloadChat = () => {
    if (!isPremium) {
      onUpgrade();
      return;
    }

    const chatText = messages.map(m => 
      `${m.role === 'user' ? 'You' : 'AI'}: ${m.content}\n`
    ).join('\n');

    const blob = new Blob([chatText], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `health_chat_${Date.now()}.txt`;
    a.click();
  };

  const handleLike = (messageId: string) => {
    setMessages(prev => prev.map(m => 
      m.id === messageId ? { ...m, liked: !m.liked, disliked: false } : m
    ));
  };

  const handleDislike = (messageId: string) => {
    setMessages(prev => prev.map(m => 
      m.id === messageId ? { ...m, disliked: !m.disliked, liked: false } : m
    ));
  };

  useEffect(() => {
    if (messages.length > 0 && isPremium) {
      const timer = setTimeout(() => {
        saveChatHistory();
      }, 2000);
      return () => clearTimeout(timer);
    }
  }, [messages]);

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-purple-50 to-pink-50 flex flex-col">
      {/* Header */}
      <div className="sticky top-0 z-40 backdrop-blur-xl bg-white/80 border-b border-white/20 shadow-lg">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Button variant="ghost" size="icon" onClick={onBack}>
                <ArrowLeft className="w-5 h-5" />
              </Button>
              <div className="flex items-center gap-3">
                <div className={`bg-gradient-to-br ${isPremium ? 'from-purple-500 to-pink-600' : 'from-blue-500 to-cyan-600'} p-2.5 rounded-2xl`}>
                  {isPremium ? <Sparkles className="w-6 h-6 text-white" /> : <Bot className="w-6 h-6 text-white" />}
                </div>
                <div>
                  <h1 className={`text-xl bg-gradient-to-r ${isPremium ? 'from-purple-600 to-pink-600' : 'from-blue-600 to-cyan-600'} bg-clip-text text-transparent flex items-center gap-2`}>
                    {text.title}
                    {isPremium && <PremiumBadge size="sm" />}
                  </h1>
                  <p className="text-sm text-gray-600">{text.subtitle}</p>
                </div>
              </div>
            </div>

            <div className="flex items-center gap-2">
              {!isPremium && (
                <div className="hidden sm:block text-sm text-gray-600 mr-2">
                  {getRemainingQuestions()} / 3 {language === 'ps' ? 'پوښتنې' : language === 'fa' ? 'سوال' : 'questions'}
                </div>
              )}
              <Button variant="ghost" size="icon" onClick={() => setShowHistory(!showHistory)}>
                <History className="w-5 h-5" />
              </Button>
              <Button variant="ghost" size="icon" onClick={handleNewChat}>
                <MessageCircle className="w-5 h-5" />
              </Button>
            </div>
          </div>
        </div>
      </div>

      {/* History Sidebar */}
      <AnimatePresence>
        {showHistory && (
          <motion.div
            initial={{ opacity: 0, x: -300 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -300 }}
            className="fixed left-0 top-[73px] bottom-0 w-80 bg-white border-r border-gray-200 z-30 overflow-y-auto"
          >
            <div className="p-4">
              <div className="flex items-center justify-between mb-4">
                <h3 className="font-medium">{text.history}</h3>
                <Button variant="ghost" size="icon" onClick={() => setShowHistory(false)}>
                  <X className="w-5 h-5" />
                </Button>
              </div>

              {chatHistories.length === 0 ? (
                <div className="text-center text-gray-500 py-8">
                  <History className="w-12 h-12 mx-auto mb-2 opacity-30" />
                  <p className="text-sm">{language === 'ps' ? 'تاریخچه نشته' : language === 'fa' ? 'تاریخچه‌ای نیست' : 'No history'}</p>
                </div>
              ) : (
                <div className="space-y-2">
                  {chatHistories.map(chat => (
                    <div
                      key={chat.id}
                      className={`p-3 rounded-xl border cursor-pointer hover:bg-gray-50 transition-colors ${
                        currentChatId === chat.id ? 'border-purple-300 bg-purple-50' : 'border-gray-200'
                      }`}
                    >
                      <div className="flex items-start justify-between gap-2">
                        <div className="flex-1 min-w-0" onClick={() => handleLoadChat(chat.id)}>
                          <h4 className="font-medium text-sm truncate">{chat.title}</h4>
                          <p className="text-xs text-gray-500">
                            {new Date(chat.updatedAt).toLocaleDateString()}
                          </p>
                        </div>
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-8 w-8"
                          onClick={(e) => {
                            e.stopPropagation();
                            handleDeleteChat(chat.id);
                          }}
                        >
                          <Trash2 className="w-4 h-4 text-red-500" />
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Main Content */}
      <div className="flex-1 container mx-auto px-4 py-6 flex flex-col max-w-4xl">
        {/* Disclaimer */}
        <div className="bg-yellow-50 border border-yellow-200 rounded-2xl p-4 mb-4 flex items-start gap-3">
          <AlertCircle className="w-5 h-5 text-yellow-600 flex-shrink-0 mt-0.5" />
          <p className="text-sm text-yellow-800">{text.disclaimer}</p>
        </div>

        {/* Upgrade Banner for Free Users */}
        {!isPremium && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-gradient-to-r from-purple-500 to-pink-600 rounded-3xl p-6 mb-4 text-white"
          >
            <div className="flex items-start justify-between gap-4">
              <div className="flex-1">
                <div className="flex items-center gap-2 mb-2">
                  <Crown className="w-6 h-6" />
                  <h3 className="text-lg font-medium">{text.upgradeForAdvanced}</h3>
                </div>
                <ul className="space-y-1 text-sm text-white/90 mb-4">
                  {text.features.advanced.map((feature, i) => (
                    <li key={i} className="flex items-center gap-2">
                      <CheckCircle className="w-4 h-4" />
                      {feature}
                    </li>
                  ))}
                </ul>
                <Button
                  onClick={onUpgrade}
                  className="bg-white text-purple-600 hover:bg-gray-100"
                >
                  <Crown className="w-4 h-4 mr-2" />
                  {language === 'ps' ? 'Premium ته لوړ کړئ' : language === 'fa' ? 'ارتقا به Premium' : 'Upgrade to Premium'}
                </Button>
              </div>
              <Sparkles className="w-12 h-12 opacity-50" />
            </div>
          </motion.div>
        )}

        {/* Quick Questions */}
        {messages.length === 0 && (
          <div className="mb-4">
            <h3 className="text-sm font-medium text-gray-700 mb-3">{text.quickQuestions}</h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {text.quickQuestionsList.map((q, i) => (
                <button
                  key={i}
                  onClick={() => handleQuickQuestion(q)}
                  className="text-left p-3 rounded-xl border border-gray-200 hover:border-purple-300 hover:bg-purple-50 transition-all text-sm"
                >
                  <ChevronRight className="w-4 h-4 inline mr-2 text-purple-600" />
                  {q}
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Messages */}
        <div className="flex-1 overflow-y-auto space-y-4 mb-4">
          {messages.map((message) => (
            <motion.div
              key={message.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className={`flex ${message.role === 'user' ? 'justify-end' : 'justify-start'}`}
            >
              <div className={`max-w-[80%] ${message.role === 'user' ? 'order-2' : 'order-1'}`}>
                <div className={`rounded-3xl p-4 ${
                  message.role === 'user'
                    ? 'bg-gradient-to-r from-blue-500 to-cyan-600 text-white'
                    : 'bg-white border border-gray-200'
                }`}>
                  {message.role === 'assistant' && (
                    <div className="flex items-center gap-2 mb-2">
                      {isPremium ? (
                        <Sparkles className="w-4 h-4 text-purple-600" />
                      ) : (
                        <Bot className="w-4 h-4 text-blue-600" />
                      )}
                      <span className="text-xs font-medium text-gray-600">
                        {message.aiLevel === 'advanced' ? text.advancedAI : text.basicAI}
                      </span>
                    </div>
                  )}
                  <p className="whitespace-pre-wrap">{message.content}</p>
                </div>

                {/* Message Actions */}
                {message.role === 'assistant' && (
                  <div className="flex items-center gap-2 mt-2 px-2">
                    <button
                      onClick={() => handleLike(message.id)}
                      className={`p-1 rounded-lg hover:bg-gray-100 ${message.liked ? 'text-green-600' : 'text-gray-400'}`}
                    >
                      <ThumbsUp className="w-4 h-4" />
                    </button>
                    <button
                      onClick={() => handleDislike(message.id)}
                      className={`p-1 rounded-lg hover:bg-gray-100 ${message.disliked ? 'text-red-600' : 'text-gray-400'}`}
                    >
                      <ThumbsDown className="w-4 h-4" />
                    </button>
                    <button
                      onClick={() => handleCopyMessage(message.content)}
                      className="p-1 rounded-lg hover:bg-gray-100 text-gray-400"
                    >
                      <Copy className="w-4 h-4" />
                    </button>
                    <span className="text-xs text-gray-400 ml-auto">
                      {new Date(message.timestamp).toLocaleTimeString()}
                    </span>
                  </div>
                )}
              </div>
            </motion.div>
          ))}

          {isTyping && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="flex justify-start"
            >
              <div className="bg-white border border-gray-200 rounded-3xl p-4 flex items-center gap-3">
                <Loader2 className="w-5 h-5 animate-spin text-purple-600" />
                <span className="text-gray-600">{text.typing}</span>
              </div>
            </motion.div>
          )}

          <div ref={messagesEndRef} />
        </div>

        {/* Input */}
        <div className="sticky bottom-0 bg-white border border-gray-200 rounded-3xl p-4 shadow-lg">
          <div className="flex items-center gap-3">
            <Input
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyPress={(e) => e.key === 'Enter' && handleSend()}
              placeholder={text.placeholder}
              className="flex-1 border-0 focus-visible:ring-0 bg-transparent"
              disabled={isTyping}
            />
            <Button
              onClick={handleSend}
              disabled={!input.trim() || isTyping}
              size="icon"
              className="bg-gradient-to-r from-purple-500 to-pink-600 hover:from-purple-600 hover:to-pink-700"
            >
              <Send className="w-5 h-5" />
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}