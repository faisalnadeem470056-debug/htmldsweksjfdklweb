import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  ArrowLeft, Mail, Lock, Camera, Eye, EyeOff, Shield, Bell,
  Globe, Users, FileText, HelpCircle, ChevronRight, Check, X,
  Smartphone, Key, AlertCircle, Upload, Image as ImageIcon
} from 'lucide-react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Card } from './ui/card';
import { ImageWithFallback } from './figma/ImageWithFallback';
import securityManager from '../utils/SecurityManager';

interface ProfileManagementProps {
  language: 'ps' | 'fa' | 'en';
  onBack: () => void;
  currentEmail: string;
  currentPassword: string;
}

export function ProfileManagement({ language, onBack, currentEmail, currentPassword }: ProfileManagementProps) {
  const [activeSection, setActiveSection] = useState<'main' | 'email' | 'password' | 'photo' | 'security' | 'privacy'>('main');
  const [showPassword, setShowPassword] = useState(false);
  const [showNewPassword, setShowNewPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  
  // Email Change State
  const [emailData, setEmailData] = useState({
    newEmail: '',
    password: '',
    verificationCode: ''
  });
  const [emailStep, setEmailStep] = useState<'input' | 'verify' | 'success'>('input');

  // Password Change State
  const [passwordData, setPasswordData] = useState({
    currentPassword: '',
    newPassword: '',
    confirmPassword: ''
  });
  const [passwordStrength, setPasswordStrength] = useState({ isStrong: false, score: 0, feedback: [] as string[] });

  // Photo Upload State
  const [photoPreview, setPhotoPreview] = useState('');
  const [uploadMethod, setUploadMethod] = useState<'camera' | 'gallery' | 'url'>('gallery');

  // Forgot Password State
  const [forgotEmail, setForgotEmail] = useState('');
  const [resetCode, setResetCode] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [resetStep, setResetStep] = useState<'email' | 'code' | 'password' | 'success'>('email');

  const texts = {
    ps: {
      profileSettings: 'د پروفایل تنظیمات',
      changeEmail: 'برېښنالیک بدل کړه',
      changePassword: 'پټنوم بدل کړه',
      changePhoto: 'عکس بدل کړه',
      securitySettings: 'امنیتي تنظیمات',
      privacySettings: 'د پټنتیا تنظیمات',
      currentEmail: 'اوسنی برېښنالیک',
      newEmail: 'نوی برېښنالیک',
      password: 'پټنوم',
      verificationCode: 'د تصدیق کوډ',
      sendCode: 'کوډ واستوه',
      verify: 'تصدیق کړه',
      currentPassword: 'اوسنی پټنوم',
      newPassword: 'نوی پټنوم',
      confirmPassword: 'پټنوم تایید کړه',
      passwordStrength: 'د پټنوم قوت',
      weak: 'کمزوری',
      medium: 'منځنی',
      strong: 'قوی',
      veryStrong: 'خورا قوی',
      save: 'خوندي کول',
      cancel: 'لغوه',
      uploadPhoto: 'عکس پورته کړه',
      takePhoto: 'عکس واخله',
      chooseFromGallery: 'د ګالري څخه غوره کړه',
      enterURL: 'URL دلته ولیکئ',
      forgotPassword: 'پټنوم مو هیر شوی؟',
      resetPassword: 'پټنوم بیرته تنظیم کړه',
      enterEmail: 'خپل برېښنالیک دلته ولیکئ',
      enterCode: 'د تصدیق کوډ دلته ولیکئ',
      createNewPassword: 'نوی پټنوم جوړ کړه',
      passwordChanged: 'پټنوم بریالۍ بدل شو!',
      emailChanged: 'برېښنالیک بریالۍ بدل شو!',
      photoChanged: 'عکس بریالۍ بدل شو!',
      codeSent: 'کوډ ستاسو برېښنالیک ته واستول شو!',
      invalidCode: 'غلط کوډ!',
      invalidPassword: 'غلط پټنوم!',
      passwordMismatch: 'پټنومونه برابر نه دي!',
      weakPassword: 'پټنوم ډیر کمزوری دی!',
      twoFactorAuth: 'دوه مرحلې تصدیق',
      loginAlerts: 'د ننوتلو خبرتیاوې',
      trustedDevices: 'باور لرونکي وسایل',
      activeNow: 'اوس فعال',
      whoCanSeeProfile: 'ستاسو پروفایل څوک لیدلی شي؟',
      whoCanContact: 'تاسو سره څوک اړیکه ونیسي؟',
      everyone: 'ټول',
      friends: 'ملګري',
      onlyMe: 'یوازې زه',
      blockList: 'د بلاک لیست',
      dataDownload: 'د معلوماتو ډاونلوډ',
      deleteAccount: 'حساب پاک کړه',
      requirements: 'اړتیاوې:',
      req8Chars: '• لږ تر لږه 8 توري',
      reqUppercase: '• لوی توري (A-Z)',
      reqLowercase: '• کوچني توري (a-z)',
      reqNumber: '• شمیرې (0-9)',
      reqSpecial: '• ځانګړي نښې (!@#$%)',
      emailInvalid: 'غلط برېښنالیک!',
      processing: 'پروسس کیږي...'
    },
    fa: {
      profileSettings: 'تنظیمات پروفایل',
      changeEmail: 'تغییر ایمیل',
      changePassword: 'تغییر رمز عبور',
      changePhoto: 'تغییر عکس',
      securitySettings: 'تنظیمات امنیتی',
      privacySettings: 'تنظیمات حریم خصوصی',
      currentEmail: 'ایمیل فعلی',
      newEmail: 'ایمیل جدید',
      password: 'رمز عبور',
      verificationCode: 'کد تایید',
      sendCode: 'ارسال کد',
      verify: 'تایید',
      currentPassword: 'رمز عبور فعلی',
      newPassword: 'رمز عبور جدید',
      confirmPassword: 'تایید رمز عبور',
      passwordStrength: 'قدرت رمز عبور',
      weak: 'ضعیف',
      medium: 'متوسط',
      strong: 'قوی',
      veryStrong: 'بسیار قوی',
      save: 'ذخیره',
      cancel: 'لغو',
      uploadPhoto: 'آپلود عکس',
      takePhoto: 'گرفتن عکس',
      chooseFromGallery: 'انتخاب از گالری',
      enterURL: 'وارد کردن URL',
      forgotPassword: 'رمز عبور را فراموش کرده‌اید؟',
      resetPassword: 'بازنشانی رمز عبور',
      enterEmail: 'ایمیل خود را وارد کنید',
      enterCode: 'کد تایید را وارد کنید',
      createNewPassword: 'رمز عبور جدید ایجاد کنید',
      passwordChanged: 'رمز عبور با موفقیت تغییر کرد!',
      emailChanged: 'ایمیل با موفقیت تغییر کرد!',
      photoChanged: 'عکس با موفقیت تغییر کرد!',
      codeSent: 'کد به ایمیل شما ارسال شد!',
      invalidCode: 'کد نامعتبر!',
      invalidPassword: 'رمز عبور نامعتبر!',
      passwordMismatch: 'رمز عبورها مطابقت ندارند!',
      weakPassword: 'رمز عبور بسیار ضعیف است!',
      twoFactorAuth: 'احراز هویت دو مرحله‌ای',
      loginAlerts: 'هشدارهای ورود',
      trustedDevices: 'دستگاه‌های مورد اعتماد',
      activeNow: 'اکنون فعال',
      whoCanSeeProfile: 'چه کسی می‌تواند پروفایل شما را ببیند؟',
      whoCanContact: 'چه کسی می‌تواند با شما تماس بگیرد؟',
      everyone: 'همه',
      friends: 'دوستان',
      onlyMe: 'فقط من',
      blockList: 'لیست مسدود شده‌ها',
      dataDownload: 'دانلود داده‌ها',
      deleteAccount: 'حذف حساب',
      requirements: 'الزامات:',
      req8Chars: '• حداقل 8 کاراکتر',
      reqUppercase: '• حروف بزرگ (A-Z)',
      reqLowercase: '• حروف کوچک (a-z)',
      reqNumber: '• اعداد (0-9)',
      reqSpecial: '• نمادهای خاص (!@#$%)',
      emailInvalid: 'ایمیل نامعتبر!',
      processing: 'در حال پردازش...'
    },
    en: {
      profileSettings: 'Profile Settings',
      changeEmail: 'Change Email',
      changePassword: 'Change Password',
      changePhoto: 'Change Photo',
      securitySettings: 'Security Settings',
      privacySettings: 'Privacy Settings',
      currentEmail: 'Current Email',
      newEmail: 'New Email',
      password: 'Password',
      verificationCode: 'Verification Code',
      sendCode: 'Send Code',
      verify: 'Verify',
      currentPassword: 'Current Password',
      newPassword: 'New Password',
      confirmPassword: 'Confirm Password',
      passwordStrength: 'Password Strength',
      weak: 'Weak',
      medium: 'Medium',
      strong: 'Strong',
      veryStrong: 'Very Strong',
      save: 'Save',
      cancel: 'Cancel',
      uploadPhoto: 'Upload Photo',
      takePhoto: 'Take Photo',
      chooseFromGallery: 'Choose from Gallery',
      enterURL: 'Enter URL',
      forgotPassword: 'Forgot Password?',
      resetPassword: 'Reset Password',
      enterEmail: 'Enter your email',
      enterCode: 'Enter verification code',
      createNewPassword: 'Create new password',
      passwordChanged: 'Password changed successfully!',
      emailChanged: 'Email changed successfully!',
      photoChanged: 'Photo changed successfully!',
      codeSent: 'Code sent to your email!',
      invalidCode: 'Invalid code!',
      invalidPassword: 'Invalid password!',
      passwordMismatch: 'Passwords do not match!',
      weakPassword: 'Password is too weak!',
      twoFactorAuth: 'Two-Factor Authentication',
      loginAlerts: 'Login Alerts',
      trustedDevices: 'Trusted Devices',
      activeNow: 'Active Now',
      whoCanSeeProfile: 'Who can see your profile?',
      whoCanContact: 'Who can contact you?',
      everyone: 'Everyone',
      friends: 'Friends',
      onlyMe: 'Only Me',
      blockList: 'Block List',
      dataDownload: 'Download Data',
      deleteAccount: 'Delete Account',
      requirements: 'Requirements:',
      req8Chars: '• At least 8 characters',
      reqUppercase: '• Uppercase letters (A-Z)',
      reqLowercase: '• Lowercase letters (a-z)',
      reqNumber: '• Numbers (0-9)',
      reqSpecial: '• Special characters (!@#$%)',
      emailInvalid: 'Invalid email!',
      processing: 'Processing...'
    }
  };

  const t = texts[language];

  // Handle Password Strength Check
  const checkPasswordStrength = (password: string) => {
    const strength = securityManager.validatePasswordStrength(password);
    setPasswordStrength(strength);
  };

  // Handle Email Change
  const handleEmailChange = () => {
    if (!securityManager.validateEmail(emailData.newEmail)) {
      alert(t.emailInvalid);
      return;
    }

    if (emailData.password !== currentPassword) {
      alert(t.invalidPassword);
      return;
    }

    if (emailStep === 'input') {
      // Send verification code (simulate)
      const code = Math.floor(100000 + Math.random() * 900000).toString();
      localStorage.setItem('healmate_verification_code', code);
      alert(`${t.codeSent}\n${language === 'ps' ? 'کوډ' : language === 'fa' ? 'کد' : 'Code'}: ${code}`);
      setEmailStep('verify');
    } else if (emailStep === 'verify') {
      const storedCode = localStorage.getItem('healmate_verification_code');
      if (emailData.verificationCode === storedCode) {
        // Update email
        localStorage.setItem('healmate_userEmail', emailData.newEmail);
        const users = JSON.parse(localStorage.getItem('healmate_users') || '[]');
        const updatedUsers = users.map((u: any) => {
          if (u.email === currentEmail) {
            return { ...u, email: emailData.newEmail };
          }
          return u;
        });
        localStorage.setItem('healmate_users', JSON.stringify(updatedUsers));
        localStorage.removeItem('healmate_verification_code');
        setEmailStep('success');
        setTimeout(() => {
          alert(t.emailChanged);
          setActiveSection('main');
          setEmailData({ newEmail: '', password: '', verificationCode: '' });
          setEmailStep('input');
        }, 2000);
      } else {
        alert(t.invalidCode);
      }
    }
  };

  // Handle Password Change
  const handlePasswordChange = () => {
    if (passwordData.currentPassword !== currentPassword) {
      alert(t.invalidPassword);
      return;
    }

    if (passwordData.newPassword !== passwordData.confirmPassword) {
      alert(t.passwordMismatch);
      return;
    }

    const strength = securityManager.validatePasswordStrength(passwordData.newPassword);
    if (!strength.isStrong) {
      alert(t.weakPassword + '\n' + strength.feedback.join('\n'));
      return;
    }

    // Update password
    const hashedPassword = securityManager.hashPassword(passwordData.newPassword);
    const users = JSON.parse(localStorage.getItem('healmate_users') || '[]');
    const updatedUsers = users.map((u: any) => {
      if (u.email === currentEmail) {
        return { ...u, password: hashedPassword };
      }
      return u;
    });
    localStorage.setItem('healmate_users', JSON.stringify(updatedUsers));
    
    alert(t.passwordChanged);
    setActiveSection('main');
    setPasswordData({ currentPassword: '', newPassword: '', confirmPassword: '' });
  };

  // Handle Photo Upload
  const handlePhotoUpload = (file?: File) => {
    if (uploadMethod === 'url') {
      const url = prompt(t.enterURL);
      if (url) {
        setPhotoPreview(url);
      }
    } else if (file) {
      const validation = securityManager.validateFileUpload(file);
      if (!validation.isValid) {
        alert(validation.error);
        return;
      }
      
      const reader = new FileReader();
      reader.onloadend = () => {
        setPhotoPreview(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const savePhoto = () => {
    if (!photoPreview) return;
    
    const users = JSON.parse(localStorage.getItem('healmate_users') || '[]');
    const updatedUsers = users.map((u: any) => {
      if (u.email === currentEmail) {
        return { ...u, profileImage: photoPreview };
      }
      return u;
    });
    localStorage.setItem('healmate_users', JSON.stringify(updatedUsers));
    
    alert(t.photoChanged);
    setActiveSection('main');
    setPhotoPreview('');
  };

  // Handle Forgot Password
  const handleForgotPassword = () => {
    if (resetStep === 'email') {
      if (!securityManager.validateEmail(forgotEmail)) {
        alert(t.emailInvalid);
        return;
      }
      
      const code = Math.floor(100000 + Math.random() * 900000).toString();
      localStorage.setItem('healmate_reset_code', code);
      alert(`${t.codeSent}\n${language === 'ps' ? 'کوډ' : language === 'fa' ? 'کد' : 'Code'}: ${code}`);
      setResetStep('code');
    } else if (resetStep === 'code') {
      const storedCode = localStorage.getItem('healmate_reset_code');
      if (resetCode === storedCode) {
        setResetStep('password');
      } else {
        alert(t.invalidCode);
      }
    } else if (resetStep === 'password') {
      const strength = securityManager.validatePasswordStrength(newPassword);
      if (!strength.isStrong) {
        alert(t.weakPassword + '\n' + strength.feedback.join('\n'));
        return;
      }
      
      const hashedPassword = securityManager.hashPassword(newPassword);
      const users = JSON.parse(localStorage.getItem('healmate_users') || '[]');
      const updatedUsers = users.map((u: any) => {
        if (u.email === forgotEmail) {
          return { ...u, password: hashedPassword };
        }
        return u;
      });
      localStorage.setItem('healmate_users', JSON.stringify(updatedUsers));
      localStorage.removeItem('healmate_reset_code');
      
      setResetStep('success');
      setTimeout(() => {
        alert(t.passwordChanged);
        setForgotEmail('');
        setResetCode('');
        setNewPassword('');
        setResetStep('email');
      }, 2000);
    }
  };

  // Main Settings Menu
  const MainMenu = () => (
    <div className="max-w-2xl mx-auto px-4 py-6 space-y-4">
      <Card className="bg-white rounded-2xl shadow-lg border-0 overflow-hidden">
        <div className="divide-y divide-gray-100">
          <button
            onClick={() => setActiveSection('email')}
            className="w-full flex items-center justify-between px-6 py-4 hover:bg-gray-50 transition-colors"
          >
            <div className="flex items-center gap-4">
              <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center">
                <Mail className="w-5 h-5 text-blue-600" />
              </div>
              <div className="text-left">
                <p className="text-gray-900">{t.changeEmail}</p>
                <p className="text-sm text-gray-500">{currentEmail}</p>
              </div>
            </div>
            <ChevronRight className="w-5 h-5 text-gray-400" />
          </button>

          <button
            onClick={() => setActiveSection('password')}
            className="w-full flex items-center justify-between px-6 py-4 hover:bg-gray-50 transition-colors"
          >
            <div className="flex items-center gap-4">
              <div className="w-10 h-10 bg-purple-100 rounded-full flex items-center justify-center">
                <Lock className="w-5 h-5 text-purple-600" />
              </div>
              <div className="text-left">
                <p className="text-gray-900">{t.changePassword}</p>
                <p className="text-sm text-gray-500">{t.forgotPassword}</p>
              </div>
            </div>
            <ChevronRight className="w-5 h-5 text-gray-400" />
          </button>

          <button
            onClick={() => setActiveSection('photo')}
            className="w-full flex items-center justify-between px-6 py-4 hover:bg-gray-50 transition-colors"
          >
            <div className="flex items-center gap-4">
              <div className="w-10 h-10 bg-green-100 rounded-full flex items-center justify-center">
                <Camera className="w-5 h-5 text-green-600" />
              </div>
              <p className="text-gray-900">{t.changePhoto}</p>
            </div>
            <ChevronRight className="w-5 h-5 text-gray-400" />
          </button>
        </div>
      </Card>

      <Card className="bg-white rounded-2xl shadow-lg border-0 overflow-hidden">
        <div className="divide-y divide-gray-100">
          <button
            onClick={() => setActiveSection('security')}
            className="w-full flex items-center justify-between px-6 py-4 hover:bg-gray-50 transition-colors"
          >
            <div className="flex items-center gap-4">
              <div className="w-10 h-10 bg-red-100 rounded-full flex items-center justify-center">
                <Shield className="w-5 h-5 text-red-600" />
              </div>
              <p className="text-gray-900">{t.securitySettings}</p>
            </div>
            <ChevronRight className="w-5 h-5 text-gray-400" />
          </button>

          <button
            onClick={() => setActiveSection('privacy')}
            className="w-full flex items-center justify-between px-6 py-4 hover:bg-gray-50 transition-colors"
          >
            <div className="flex items-center gap-4">
              <div className="w-10 h-10 bg-orange-100 rounded-full flex items-center justify-center">
                <Lock className="w-5 h-5 text-orange-600" />
              </div>
              <p className="text-gray-900">{t.privacySettings}</p>
            </div>
            <ChevronRight className="w-5 h-5 text-gray-400" />
          </button>
        </div>
      </Card>
    </div>
  );

  // Email Change Section
  const EmailChangeSection = () => (
    <div className="max-w-2xl mx-auto px-4 py-6">
      <Card className="bg-white rounded-2xl shadow-lg border-0 p-6">
        <h2 className="text-2xl mb-6">{t.changeEmail}</h2>
        
        <div className="space-y-4">
          <div>
            <Label className="text-gray-600 text-sm mb-2">{t.currentEmail}</Label>
            <Input
              value={currentEmail}
              disabled
              className="rounded-xl border-2 border-gray-200 bg-gray-50"
            />
          </div>

          {emailStep === 'input' && (
            <>
              <div>
                <Label className="text-gray-600 text-sm mb-2">{t.newEmail}</Label>
                <Input
                  type="email"
                  value={emailData.newEmail}
                  onChange={(e) => setEmailData({ ...emailData, newEmail: e.target.value })}
                  placeholder="example@email.com"
                  className="rounded-xl border-2 border-gray-200 focus:border-blue-500"
                />
              </div>

              <div>
                <Label className="text-gray-600 text-sm mb-2">{t.password}</Label>
                <div className="relative">
                  <Input
                    type={showPassword ? 'text' : 'password'}
                    value={emailData.password}
                    onChange={(e) => setEmailData({ ...emailData, password: e.target.value })}
                    placeholder="••••••••"
                    className="rounded-xl border-2 border-gray-200 focus:border-blue-500 pr-12"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500"
                  >
                    {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                  </button>
                </div>
              </div>
            </>
          )}

          {emailStep === 'verify' && (
            <div>
              <Label className="text-gray-600 text-sm mb-2">{t.verificationCode}</Label>
              <Input
                type="text"
                value={emailData.verificationCode}
                onChange={(e) => setEmailData({ ...emailData, verificationCode: e.target.value })}
                placeholder="123456"
                className="rounded-xl border-2 border-gray-200 focus:border-blue-500"
                maxLength={6}
              />
              <p className="text-sm text-gray-500 mt-2">
                {language === 'ps' ? 'کوډ ستاسو نوي برېښنالیک ته واستول شو' : 
                 language === 'fa' ? 'کد به ایمیل جدید شما ارسال شد' : 
                 'Code sent to your new email'}
              </p>
            </div>
          )}

          {emailStep === 'success' && (
            <div className="flex flex-col items-center justify-center py-8">
              <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mb-4">
                <Check className="w-8 h-8 text-green-600" />
              </div>
              <p className="text-xl text-green-600">{t.emailChanged}</p>
            </div>
          )}

          {emailStep !== 'success' && (
            <div className="flex gap-3 pt-4">
              <Button
                onClick={() => {
                  setActiveSection('main');
                  setEmailData({ newEmail: '', password: '', verificationCode: '' });
                  setEmailStep('input');
                }}
                variant="outline"
                className="flex-1 rounded-xl py-6 border-2"
              >
                {t.cancel}
              </Button>
              <Button
                onClick={handleEmailChange}
                className="flex-1 bg-gradient-to-r from-blue-600 to-indigo-600 text-white rounded-xl py-6"
              >
                {emailStep === 'input' ? t.sendCode : t.verify}
              </Button>
            </div>
          )}
        </div>
      </Card>
    </div>
  );

  // Password Change Section
  const PasswordChangeSection = () => (
    <div className="max-w-2xl mx-auto px-4 py-6">
      <Card className="bg-white rounded-2xl shadow-lg border-0 p-6">
        <h2 className="text-2xl mb-6">{t.changePassword}</h2>
        
        <div className="space-y-4">
          <div>
            <Label className="text-gray-600 text-sm mb-2">{t.currentPassword}</Label>
            <div className="relative">
              <Input
                type={showPassword ? 'text' : 'password'}
                value={passwordData.currentPassword}
                onChange={(e) => setPasswordData({ ...passwordData, currentPassword: e.target.value })}
                placeholder="••••••••"
                className="rounded-xl border-2 border-gray-200 focus:border-blue-500 pr-12"
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500"
              >
                {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
              </button>
            </div>
            <button
              onClick={() => {
                // Open Forgot Password Modal
                const resetConfirm = confirm(t.forgotPassword);
                if (resetConfirm) {
                  alert(`${t.codeSent}\n${language === 'ps' ? 'کوډ' : language === 'fa' ? 'کد' : 'Code'}: 123456`);
                }
              }}
              className="text-sm text-blue-600 hover:underline mt-2"
            >
              {t.forgotPassword}
            </button>
          </div>

          <div>
            <Label className="text-gray-600 text-sm mb-2">{t.newPassword}</Label>
            <div className="relative">
              <Input
                type={showNewPassword ? 'text' : 'password'}
                value={passwordData.newPassword}
                onChange={(e) => {
                  setPasswordData({ ...passwordData, newPassword: e.target.value });
                  checkPasswordStrength(e.target.value);
                }}
                placeholder="••••••••"
                className="rounded-xl border-2 border-gray-200 focus:border-blue-500 pr-12"
              />
              <button
                type="button"
                onClick={() => setShowNewPassword(!showNewPassword)}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500"
              >
                {showNewPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
              </button>
            </div>
          </div>

          {passwordData.newPassword && (
            <div className="bg-gray-50 rounded-xl p-4">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm text-gray-600">{t.passwordStrength}:</span>
                <span className={`text-sm ${
                  passwordStrength.score >= 80 ? 'text-green-600' :
                  passwordStrength.score >= 60 ? 'text-blue-600' :
                  passwordStrength.score >= 40 ? 'text-yellow-600' :
                  'text-red-600'
                }`}>
                  {passwordStrength.score >= 80 ? t.veryStrong :
                   passwordStrength.score >= 60 ? t.strong :
                   passwordStrength.score >= 40 ? t.medium :
                   t.weak}
                </span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-2">
                <div
                  className={`h-2 rounded-full transition-all ${
                    passwordStrength.score >= 80 ? 'bg-green-600' :
                    passwordStrength.score >= 60 ? 'bg-blue-600' :
                    passwordStrength.score >= 40 ? 'bg-yellow-600' :
                    'bg-red-600'
                  }`}
                  style={{ width: `${passwordStrength.score}%` }}
                />
              </div>
              <div className="mt-3 text-xs text-gray-600">
                <p className="mb-1">{t.requirements}</p>
                <ul className="space-y-1">
                  <li className={passwordData.newPassword.length >= 8 ? 'text-green-600' : ''}>{t.req8Chars}</li>
                  <li className={/[A-Z]/.test(passwordData.newPassword) ? 'text-green-600' : ''}>{t.reqUppercase}</li>
                  <li className={/[a-z]/.test(passwordData.newPassword) ? 'text-green-600' : ''}>{t.reqLowercase}</li>
                  <li className={/[0-9]/.test(passwordData.newPassword) ? 'text-green-600' : ''}>{t.reqNumber}</li>
                  <li className={/[^a-zA-Z0-9]/.test(passwordData.newPassword) ? 'text-green-600' : ''}>{t.reqSpecial}</li>
                </ul>
              </div>
            </div>
          )}

          <div>
            <Label className="text-gray-600 text-sm mb-2">{t.confirmPassword}</Label>
            <div className="relative">
              <Input
                type={showConfirmPassword ? 'text' : 'password'}
                value={passwordData.confirmPassword}
                onChange={(e) => setPasswordData({ ...passwordData, confirmPassword: e.target.value })}
                placeholder="••••••••"
                className="rounded-xl border-2 border-gray-200 focus:border-blue-500 pr-12"
              />
              <button
                type="button"
                onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500"
              >
                {showConfirmPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
              </button>
            </div>
            {passwordData.confirmPassword && passwordData.newPassword !== passwordData.confirmPassword && (
              <p className="text-sm text-red-600 mt-2 flex items-center gap-1">
                <AlertCircle className="w-4 h-4" />
                {t.passwordMismatch}
              </p>
            )}
          </div>

          <div className="flex gap-3 pt-4">
            <Button
              onClick={() => {
                setActiveSection('main');
                setPasswordData({ currentPassword: '', newPassword: '', confirmPassword: '' });
              }}
              variant="outline"
              className="flex-1 rounded-xl py-6 border-2"
            >
              {t.cancel}
            </Button>
            <Button
              onClick={handlePasswordChange}
              className="flex-1 bg-gradient-to-r from-blue-600 to-indigo-600 text-white rounded-xl py-6"
            >
              {t.save}
            </Button>
          </div>
        </div>
      </Card>
    </div>
  );

  // Photo Change Section
  const PhotoChangeSection = () => (
    <div className="max-w-2xl mx-auto px-4 py-6">
      <Card className="bg-white rounded-2xl shadow-lg border-0 p-6">
        <h2 className="text-2xl mb-6">{t.changePhoto}</h2>
        
        <div className="space-y-6">
          {/* Photo Preview */}
          <div className="flex justify-center">
            <div className="relative w-40 h-40 rounded-full overflow-hidden bg-gray-100 shadow-lg">
              {photoPreview ? (
                <ImageWithFallback
                  src={photoPreview}
                  alt="Preview"
                  className="w-full h-full object-cover"
                />
              ) : (
                <div className="w-full h-full flex items-center justify-center">
                  <Camera className="w-12 h-12 text-gray-400" />
                </div>
              )}
            </div>
          </div>

          {/* Upload Methods */}
          <div className="grid grid-cols-3 gap-3">
            <button
              onClick={() => setUploadMethod('camera')}
              className={`flex flex-col items-center gap-2 p-4 rounded-xl border-2 transition-all ${
                uploadMethod === 'camera' ? 'border-blue-500 bg-blue-50' : 'border-gray-200'
              }`}
            >
              <Camera className={`w-6 h-6 ${uploadMethod === 'camera' ? 'text-blue-600' : 'text-gray-600'}`} />
              <span className="text-xs text-gray-700">{t.takePhoto}</span>
            </button>

            <button
              onClick={() => setUploadMethod('gallery')}
              className={`flex flex-col items-center gap-2 p-4 rounded-xl border-2 transition-all ${
                uploadMethod === 'gallery' ? 'border-blue-500 bg-blue-50' : 'border-gray-200'
              }`}
            >
              <ImageIcon className={`w-6 h-6 ${uploadMethod === 'gallery' ? 'text-blue-600' : 'text-gray-600'}`} />
              <span className="text-xs text-gray-700">{t.chooseFromGallery}</span>
            </button>

            <button
              onClick={() => {
                setUploadMethod('url');
                handlePhotoUpload();
              }}
              className={`flex flex-col items-center gap-2 p-4 rounded-xl border-2 transition-all ${
                uploadMethod === 'url' ? 'border-blue-500 bg-blue-50' : 'border-gray-200'
              }`}
            >
              <Globe className={`w-6 h-6 ${uploadMethod === 'url' ? 'text-blue-600' : 'text-gray-600'}`} />
              <span className="text-xs text-gray-700">{t.enterURL}</span>
            </button>
          </div>

          {/* File Upload Input */}
          {uploadMethod !== 'url' && (
            <label className="block">
              <input
                type="file"
                accept="image/*"
                capture={uploadMethod === 'camera' ? 'environment' : undefined}
                onChange={(e) => e.target.files?.[0] && handlePhotoUpload(e.target.files[0])}
                className="hidden"
              />
              <div className="flex items-center justify-center gap-2 px-6 py-4 bg-gray-100 rounded-xl cursor-pointer hover:bg-gray-200 transition-colors">
                <Upload className="w-5 h-5 text-gray-600" />
                <span className="text-gray-700">{t.uploadPhoto}</span>
              </div>
            </label>
          )}

          <div className="flex gap-3">
            <Button
              onClick={() => {
                setActiveSection('main');
                setPhotoPreview('');
              }}
              variant="outline"
              className="flex-1 rounded-xl py-6 border-2"
            >
              {t.cancel}
            </Button>
            <Button
              onClick={savePhoto}
              disabled={!photoPreview}
              className="flex-1 bg-gradient-to-r from-blue-600 to-indigo-600 text-white rounded-xl py-6 disabled:opacity-50"
            >
              {t.save}
            </Button>
          </div>
        </div>
      </Card>
    </div>
  );

  // Security Settings Section
  const SecuritySection = () => (
    <div className="max-w-2xl mx-auto px-4 py-6 space-y-4">
      <Card className="bg-white rounded-2xl shadow-lg border-0 p-6">
        <h2 className="text-2xl mb-6">{t.securitySettings}</h2>
        
        <div className="space-y-4">
          <div className="flex items-center justify-between p-4 bg-gray-50 rounded-xl">
            <div className="flex items-center gap-3">
              <Key className="w-5 h-5 text-blue-600" />
              <div>
                <p className="text-gray-900">{t.twoFactorAuth}</p>
                <p className="text-sm text-gray-500">{language === 'ps' ? 'اضافي امنیت' : language === 'fa' ? 'امنیت بیشتر' : 'Extra security'}</p>
              </div>
            </div>
            <label className="relative inline-flex items-center cursor-pointer">
              <input type="checkbox" className="sr-only peer" />
              <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
            </label>
          </div>

          <div className="flex items-center justify-between p-4 bg-gray-50 rounded-xl">
            <div className="flex items-center gap-3">
              <Bell className="w-5 h-5 text-purple-600" />
              <div>
                <p className="text-gray-900">{t.loginAlerts}</p>
                <p className="text-sm text-gray-500">{language === 'ps' ? 'د ننوتلو خبرتیاوې' : language === 'fa' ? 'اطلاعیه‌های ورود' : 'Get notified of logins'}</p>
              </div>
            </div>
            <label className="relative inline-flex items-center cursor-pointer">
              <input type="checkbox" defaultChecked className="sr-only peer" />
              <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
            </label>
          </div>

          <button className="w-full flex items-center justify-between p-4 bg-gray-50 rounded-xl hover:bg-gray-100 transition-colors">
            <div className="flex items-center gap-3">
              <Smartphone className="w-5 h-5 text-green-600" />
              <div className="text-left">
                <p className="text-gray-900">{t.trustedDevices}</p>
                <p className="text-sm text-gray-500">3 {language === 'ps' ? 'وسایل' : language === 'fa' ? 'دستگاه' : 'devices'}</p>
              </div>
            </div>
            <ChevronRight className="w-5 h-5 text-gray-400" />
          </button>
        </div>
      </Card>

      <Button
        onClick={() => setActiveSection('main')}
        variant="outline"
        className="w-full rounded-xl py-6 border-2"
      >
        {t.cancel}
      </Button>
    </div>
  );

  // Privacy Settings Section
  const PrivacySection = () => (
    <div className="max-w-2xl mx-auto px-4 py-6 space-y-4">
      <Card className="bg-white rounded-2xl shadow-lg border-0 p-6">
        <h2 className="text-2xl mb-6">{t.privacySettings}</h2>
        
        <div className="space-y-4">
          <div>
            <Label className="text-gray-700 mb-3 block">{t.whoCanSeeProfile}</Label>
            <select className="w-full px-4 py-3 border-2 border-gray-200 rounded-xl bg-white focus:border-blue-500 focus:outline-none">
              <option>{t.everyone}</option>
              <option>{t.friends}</option>
              <option>{t.onlyMe}</option>
            </select>
          </div>

          <div>
            <Label className="text-gray-700 mb-3 block">{t.whoCanContact}</Label>
            <select className="w-full px-4 py-3 border-2 border-gray-200 rounded-xl bg-white focus:border-blue-500 focus:outline-none">
              <option>{t.everyone}</option>
              <option>{t.friends}</option>
              <option>{t.onlyMe}</option>
            </select>
          </div>

          <button className="w-full flex items-center justify-between p-4 bg-gray-50 rounded-xl hover:bg-gray-100 transition-colors">
            <div className="flex items-center gap-3">
              <Users className="w-5 h-5 text-red-600" />
              <p className="text-gray-900">{t.blockList}</p>
            </div>
            <ChevronRight className="w-5 h-5 text-gray-400" />
          </button>

          <button className="w-full flex items-center justify-between p-4 bg-gray-50 rounded-xl hover:bg-gray-100 transition-colors">
            <div className="flex items-center gap-3">
              <FileText className="w-5 h-5 text-blue-600" />
              <p className="text-gray-900">{t.dataDownload}</p>
            </div>
            <ChevronRight className="w-5 h-5 text-gray-400" />
          </button>

          <button 
            onClick={() => {
              if (confirm(language === 'ps' ? 'ایا تاسو ډاډه یاست چې غواړئ خپل حساب پاک کړئ؟' : 
                               language === 'fa' ? 'آیا مطمئن هستید که می‌خواهید حساب خود را حذف کنید؟' : 
                               'Are you sure you want to delete your account?')) {
                alert(language === 'ps' ? 'حساب پاک شو!' : language === 'fa' ? 'حساب حذف شد!' : 'Account deleted!');
              }
            }}
            className="w-full flex items-center justify-between p-4 bg-red-50 rounded-xl hover:bg-red-100 transition-colors"
          >
            <div className="flex items-center gap-3">
              <AlertCircle className="w-5 h-5 text-red-600" />
              <p className="text-red-600">{t.deleteAccount}</p>
            </div>
            <ChevronRight className="w-5 h-5 text-red-400" />
          </button>
        </div>
      </Card>

      <Button
        onClick={() => setActiveSection('main')}
        variant="outline"
        className="w-full rounded-xl py-6 border-2"
      >
        {t.cancel}
      </Button>
    </div>
  );

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 via-blue-50 to-purple-50 overflow-y-auto pb-24">
      {/* Header */}
      <div className="sticky top-0 z-40 bg-white/90 backdrop-blur-lg border-b border-gray-200 shadow-sm">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center gap-4">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => {
                if (activeSection === 'main') {
                  onBack();
                } else {
                  setActiveSection('main');
                }
              }}
              className="rounded-full"
            >
              <ArrowLeft className="w-5 h-5" />
            </Button>
            <h1 className="text-xl">{t.profileSettings}</h1>
          </div>
        </div>
      </div>

      {/* Content */}
      <AnimatePresence mode="wait">
        <motion.div
          key={activeSection}
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          exit={{ opacity: 0, x: -20 }}
          transition={{ duration: 0.2 }}
        >
          {activeSection === 'main' && <MainMenu />}
          {activeSection === 'email' && <EmailChangeSection />}
          {activeSection === 'password' && <PasswordChangeSection />}
          {activeSection === 'photo' && <PhotoChangeSection />}
          {activeSection === 'security' && <SecuritySection />}
          {activeSection === 'privacy' && <PrivacySection />}
        </motion.div>
      </AnimatePresence>
    </div>
  );
}
