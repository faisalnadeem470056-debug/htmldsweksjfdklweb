import { useState } from 'react';
import { ArrowLeft, Heart, MessageCircle, Share2, Send } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { Button } from './ui/button';
import { Textarea } from './ui/textarea';
import { translations } from '../translations';
import { AdBanner } from './AdBanner';

interface CommunityFeedProps {
  language: 'ps' | 'fa' | 'en';
  onBack: () => void;
}

const initialPosts = [
  {
    id: 1,
    author: { ps: 'احمد', fa: 'احمد', en: 'Ahmad' },
    avatar: '👨',
    content: {
      ps: 'زه د ډایبېټس سره مخ یم. ایا چا ښه مشوره لري؟',
      fa: 'من با دیابت مواجه هستم. آیا کسی مشوره خوبی دارد؟',
      en: 'I\'m dealing with diabetes. Does anyone have good advice?',
    },
    likes: 12,
    comments: 5,
    timestamp: '2h ago',
  },
  {
    id: 2,
    author: { ps: 'فاطمه', fa: 'فاطمه', en: 'Fatima' },
    avatar: '👩',
    content: {
      ps: 'د زړه روغتیا لپاره منظم ورزش خورا مهم دی. زه هره ورځ ۳۰ دقیقې ګرځم.',
      fa: 'ورزش منظم برای سلامت قلب بسیار مهم است. من هر روز ۳۰ دقیقه پیاده‌روی می‌کنم.',
      en: 'Regular exercise is very important for heart health. I walk 30 minutes every day.',
    },
    likes: 25,
    comments: 8,
    timestamp: '5h ago',
  },
  {
    id: 3,
    author: { ps: 'محمد', fa: 'محمد', en: 'Mohammad' },
    avatar: '👨',
    content: {
      ps: 'د خوب کمښت زما لپاره لویه ستونزه ده. څوک مرسته کولی شي؟',
      fa: 'کمبود خواب برای من مشکل بزرگی است. کسی می‌تواند کمک کند؟',
      en: 'Sleep deprivation is a big problem for me. Can anyone help?',
    },
    likes: 8,
    comments: 12,
    timestamp: '1d ago',
  },
];

export function CommunityFeed({ language, onBack }: CommunityFeedProps) {
  const [posts, setPosts] = useState(initialPosts);
  const [newPost, setNewPost] = useState('');
  const [showNewPost, setShowNewPost] = useState(false);
  const t = translations[language];

  const handleSubmitPost = () => {
    if (newPost.trim()) {
      const post = {
        id: Date.now(),
        author: { ps: 'تاسو', fa: 'شما', en: 'You' },
        avatar: '👤',
        content: { ps: newPost, fa: newPost, en: newPost },
        likes: 0,
        comments: 0,
        timestamp: 'Just now',
      };
      setPosts([post, ...posts]);
      setNewPost('');
      setShowNewPost(false);
    }
  };

  const handleLike = (postId: number) => {
    setPosts(posts.map(post =>
      post.id === postId ? { ...post, likes: post.likes + 1 } : post
    ));
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-pink-50 to-rose-50 pb-28 md:pb-12">
      {/* Header */}
      <div className="sticky top-[73px] z-30 backdrop-blur-xl bg-white/70 border-b border-white/20 shadow-lg">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Button variant="ghost" size="icon" onClick={onBack}>
                <ArrowLeft className="w-5 h-5" />
              </Button>
              <div>
                <h1 className="text-2xl bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent">
                  {t.communityFeed}
                </h1>
                <p className="text-sm text-gray-600">{posts.length} {t.totalPosts}</p>
              </div>
            </div>
            <Button
              onClick={() => setShowNewPost(!showNewPost)}
              className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700"
            >
              {showNewPost ? t.cancel : t.shareExperience}
            </Button>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="container mx-auto px-4 mt-6 max-w-2xl">
        <AdBanner type="medium" className="mb-6" />

        {/* New Post Form */}
        <AnimatePresence>
          {showNewPost && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              className="mb-6"
            >
              <div className="relative group">
                <div className="absolute inset-0 bg-gradient-to-br from-purple-500 to-pink-600 rounded-3xl blur-xl opacity-30" />
                <div className="relative bg-white/90 backdrop-blur-xl rounded-3xl p-6 border border-white/20 shadow-xl">
                  <h3 className="mb-4">{t.whatOnMind}</h3>
                  <Textarea
                    value={newPost}
                    onChange={(e) => setNewPost(e.target.value)}
                    placeholder={t.shareExperience + '...'}
                    className="mb-4 min-h-[120px] bg-white/80 backdrop-blur-md border-white/20"
                    dir={language === 'en' ? 'ltr' : 'rtl'}
                  />
                  <div className="flex gap-2 justify-end">
                    <Button variant="outline" onClick={() => setShowNewPost(false)}>
                      {t.cancel}
                    </Button>
                    <Button
                      onClick={handleSubmitPost}
                      className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700"
                    >
                      <Send className="w-4 h-4 mr-2" />
                      {t.post}
                    </Button>
                  </div>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Posts */}
        <div className="space-y-6">
          {posts.map((post, index) => (
            <motion.div
              key={post.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              className="relative group"
            >
              <div className="absolute inset-0 bg-gradient-to-br from-purple-500/20 to-pink-500/20 rounded-3xl blur-xl group-hover:blur-2xl transition-all" />
              <div className="relative bg-white/90 backdrop-blur-xl rounded-3xl p-6 border border-white/20 shadow-xl hover:shadow-2xl transition-all">
                {/* Author */}
                <div className="flex items-center gap-3 mb-4">
                  <div className="w-12 h-12 bg-gradient-to-br from-purple-500 to-pink-600 rounded-full flex items-center justify-center text-2xl">
                    {post.avatar}
                  </div>
                  <div className="flex-1">
                    <h4 className="font-medium">{post.author[language]}</h4>
                    <p className="text-sm text-gray-500">{post.timestamp}</p>
                  </div>
                </div>

                {/* Content */}
                <p 
                  className="text-gray-700 mb-4 leading-relaxed"
                  dir={language === 'en' ? 'ltr' : 'rtl'}
                >
                  {post.content[language]}
                </p>

                {/* Actions */}
                <div className="flex items-center gap-6 pt-4 border-t border-gray-200">
                  <button
                    onClick={() => handleLike(post.id)}
                    className="flex items-center gap-2 text-gray-600 hover:text-red-600 transition-colors group/like"
                  >
                    <Heart className="w-5 h-5 group-hover/like:fill-red-600 transition-all" />
                    <span className="text-sm">{post.likes} {t.like}</span>
                  </button>
                  <button className="flex items-center gap-2 text-gray-600 hover:text-blue-600 transition-colors">
                    <MessageCircle className="w-5 h-5" />
                    <span className="text-sm">{post.comments} {t.comments}</span>
                  </button>
                  <button className="flex items-center gap-2 text-gray-600 hover:text-green-600 transition-colors ml-auto">
                    <Share2 className="w-5 h-5" />
                    <span className="text-sm">{t.share}</span>
                  </button>
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        <AdBanner type="large" className="mt-8" />

        {/* Community Guidelines */}
        <div className="mt-8 p-6 bg-gradient-to-br from-blue-50 to-cyan-50 border border-blue-200 rounded-3xl">
          <h3 className="mb-3">
            {language === 'ps' && '📋 د ټولنې لارښوونې'}
            {language === 'fa' && '📋 راهنمای اجتماع'}
            {language === 'en' && '📋 Community Guidelines'}
          </h3>
          <ul className="space-y-2 text-sm text-gray-700" dir={language === 'en' ? 'ltr' : 'rtl'}>
            <li>
              {language === 'ps' && '• د نورو سره درناوی وکړئ'}
              {language === 'fa' && '• به دیگران احترام بگذارید'}
              {language === 'en' && '• Be respectful to others'}
            </li>
            <li>
              {language === 'ps' && '• د طبي مشورې لپاره تل ډاکټر سره مشوره وکړئ'}
              {language === 'fa' && '• برای مشاوره پزشکی همیشه با پزشک مشورت کنید'}
              {language === 'en' && '• Always consult a doctor for medical advice'}
            </li>
            <li>
              {language === 'ps' && '• شخصي معلومات شریک مه کوئ'}
              {language === 'fa' && '• اطلاعات شخصی را به اشتراک نگذارید'}
              {language === 'en' && '• Don\'t share personal information'}
            </li>
          </ul>
        </div>
      </div>
    </div>
  );
}
