import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
// FIXED: Hospital icon imported (v2.0 - Cache Buster)
import { Mail, Lock, User, Eye, EyeOff, ArrowLeft, Check, AlertCircle, Heart, Shield, Stethoscope, Phone as PhoneIcon, Hospital } from 'lucide-react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import Logo from './Logo';

interface AuthPageProps {
  language: 'ps' | 'fa' | 'en';
  onLogin: (email: string, name: string) => void;
  onBack: () => void;
  onNeedVerification?: (email: string, phone: string) => void;
}

type AuthMode = 'login' | 'signup' | 'forgot' | 'verify-email' | 'verify-phone';

export function AuthPage({ language, onLogin, onBack, onNeedVerification }: AuthPageProps) {
  const [mode, setMode] = useState<AuthMode>('login');
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  
  // Form states
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [verificationCode, setVerificationCode] = useState('');
  const [generatedCode, setGeneratedCode] = useState('');
  
  // Validation states
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [loading, setLoading] = useState(false);
  const [agreedToTerms, setAgreedToTerms] = useState(false);
  const [passwordStrength, setPasswordStrength] = useState(0);

  const t = {
    ps: {
      login: 'ننوتل',
      signup: 'راجستر کول',
      forgotPassword: 'پټنوم هیر شوی؟',
      email: 'برېښنالیک',
      password: 'پټنوم',
      confirmPassword: 'د پټنوم تایید',
      fullName: 'بشپړ نوم',
      loginButton: 'ننوتل',
      signupButton: 'راجستر کول',
      resetButton: 'پټنوم بیرته تنظیمول',
      backToLogin: 'ننوتلو ته بیرته',
      noAccount: 'حساب نه لرئ؟',
      haveAccount: 'حساب لرئ؟',
      emailPlaceholder: 'ستاسو برېښنالیک ولیکئ',
      passwordPlaceholder: 'ستاسو پټنوم ولیکئ',
      namePlaceholder: 'ستاسو بشپړ نوم ولیکئ',
      emailRequired: 'برېښنالیک اړین دی',
      passwordRequired: 'پټنوم اړین دی',
      nameRequired: 'نوم اړین دی',
      passwordMismatch: 'پټنومونه سره سم نه دي',
      passwordMinLength: 'پټنوم باید لږترلږه ۶ توري ولري',
      invalidEmail: 'برېښنالیک سم نه دی',
      loginSuccess: 'ښه راغلاست!',
      signupSuccess: 'حساب جوړ شو! ښه راغلاست!',
      resetSuccess: 'د پټنوم بیرته تنظیم لینک ستاسو برېښنالیک ته واستول شو',
      loginError: 'برېښنالیک یا پټنوم غلط دی',
      signupError: 'دا برېښنالیک مخکې راجستر شوی دی',
      welcomeTo: 'ښه راغلاست',
      healmate: 'HealMate ته',
      subtitle: 'د افغانستان بشپړ روغتیا اپلیکیشن',
      feature1: 'د ۲۵۰+ ډاکټرانو سره اړیکه',
      feature2: 'د ۱۵۰+ روغتونونو معلومات',
      feature3: 'د ۱۵۰۰+ درملو لارښود',
      feature4: '۲۴/۷ بیړني مرسته',
      or: 'یا',
      termsAgree: 'زه د شرایطو او ضوابطو سره موافق یم',
      termsRequired: 'تاسو باید د شرایطو او ضوابطو سره موافق شئ',
      termsLink: 'شرایط او ضوابط',
      privacyLink: 'د محرمیت پالیسي'
    },
    fa: {
      login: 'ورود',
      signup: 'ثبت نام',
      forgotPassword: 'رمز عبور را فراموش کردید؟',
      email: 'ایمیل',
      password: 'رمز عبور',
      confirmPassword: 'تایید رمز عبور',
      fullName: 'نام کامل',
      loginButton: 'ورود',
      signupButton: 'ثبت نام',
      resetButton: 'بازنشانی رمز عبور',
      backToLogin: 'بازگشت به ورود',
      noAccount: 'حساب ندارید؟',
      haveAccount: 'حساب دارید؟',
      emailPlaceholder: 'ایمیل شما',
      passwordPlaceholder: 'رمز عبور شما',
      namePlaceholder: 'نام کامل شما',
      emailRequired: 'ایمیل الزامی است',
      passwordRequired: 'رمز عبور الزامی است',
      nameRequired: 'نام الزامی است',
      passwordMismatch: 'رمزهای عبور مطابقت ندارند',
      passwordMinLength: 'رمز عبور باید حداقل ۶ کاراکتر باشد',
      invalidEmail: 'ایمیل نامعتبر است',
      loginSuccess: 'خوش آمدید!',
      signupSuccess: 'حساب ایجاد شد! خوش آمدید!',
      resetSuccess: 'لینک بازنشانی رمز عبور به ایمیل شما ارسال شد',
      loginError: 'ایمیل یا رمز عبور اشتباه است',
      signupError: 'این ایمیل قبلاً ثبت شده است',
      welcomeTo: 'خوش آمدید به',
      healmate: 'HealMate',
      subtitle: 'اپلیکیشن کامل سلامت افغانستان',
      feature1: 'دسترسی به ۲۵۰+ پزشک',
      feature2: 'اطلاعات ۱۵۰+ بیمارستان',
      feature3: 'راهنمای ۱۵۰۰+ دارو',
      feature4: 'کمک اورژانس ۲۴/۷',
      or: 'یا',
      termsAgree: 'من با شرایط و ضوابط موافق هستم',
      termsRequired: 'شما باید با شرایط و ضوابط موافق باشید',
      termsLink: 'شرایط و ضوابط',
      privacyLink: 'سیاست حفظ حریم خصوصی'
    },
    en: {
      login: 'Login',
      signup: 'Sign Up',
      forgotPassword: 'Forgot Password?',
      email: 'Email',
      password: 'Password',
      confirmPassword: 'Confirm Password',
      fullName: 'Full Name',
      loginButton: 'Login',
      signupButton: 'Sign Up',
      resetButton: 'Reset Password',
      backToLogin: 'Back to Login',
      noAccount: "Don't have an account?",
      haveAccount: 'Already have an account?',
      emailPlaceholder: 'Your email',
      passwordPlaceholder: 'Your password',
      namePlaceholder: 'Your full name',
      emailRequired: 'Email is required',
      passwordRequired: 'Password is required',
      nameRequired: 'Name is required',
      passwordMismatch: 'Passwords do not match',
      passwordMinLength: 'Password must be at least 6 characters',
      invalidEmail: 'Invalid email address',
      loginSuccess: 'Welcome back!',
      signupSuccess: 'Account created! Welcome!',
      resetSuccess: 'Password reset link sent to your email',
      loginError: 'Invalid email or password',
      signupError: 'This email is already registered',
      welcomeTo: 'Welcome to',
      healmate: 'HealMate',
      subtitle: "Afghanistan's Complete Health App",
      feature1: 'Access to 250+ Doctors',
      feature2: '150+ Hospital Information',
      feature3: '1500+ Medicine Guide',
      feature4: '24/7 Emergency Help',
      or: 'or',
      termsAgree: 'I agree to the Terms & Conditions',
      termsRequired: 'You must agree to the Terms & Conditions',
      termsLink: 'Terms & Conditions',
      privacyLink: 'Privacy Policy'
    }
  };

  const text = t[language];

  // Validate email
  const validateEmail = (email: string) => {
    const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return re.test(email);
  };

  // Calculate password strength
  const calculatePasswordStrength = (pwd: string) => {
    let strength = 0;
    if (pwd.length >= 6) strength += 1;
    if (pwd.length >= 8) strength += 1;
    if (/[a-z]/.test(pwd) && /[A-Z]/.test(pwd)) strength += 1;
    if (/\d/.test(pwd)) strength += 1;
    if (/[!@#$%^&*(),.?":{}|<>]/.test(pwd)) strength += 1;
    return strength;
  };

  // Update password strength when password changes
  const handlePasswordChange = (value: string) => {
    setPassword(value);
    if (mode === 'signup') {
      setPasswordStrength(calculatePasswordStrength(value));
    }
  };

  // Handle Login
  const handleLogin = async () => {
    setError('');
    setSuccess('');
    
    // Validation
    if (!email) {
      setError(text.emailRequired);
      return;
    }
    if (!validateEmail(email)) {
      setError(text.invalidEmail);
      return;
    }
    if (!password) {
      setError(text.passwordRequired);
      return;
    }
    if (password.length < 6) {
      setError(text.passwordMinLength);
      return;
    }

    setLoading(true);
    
    // Simulate API call with realistic delay
    setTimeout(() => {
      try {
        // Get registered users from localStorage
        const users = JSON.parse(localStorage.getItem('healmate_users') || '[]');
        
        // Find user with matching credentials
        const user = users.find((u: any) => 
          u.email.toLowerCase() === email.toLowerCase() && 
          u.password === password
        );
        
        if (user) {
          // Login successful
          setSuccess(text.loginSuccess);
          setTimeout(() => {
            onLogin(email, user.name);
          }, 800);
        } else {
          // Invalid credentials
          setError(text.loginError);
        }
      } catch (error) {
        // Handle any errors
        setError(text.loginError);
      } finally {
        setLoading(false);
      }
    }, 1200);
  };

  // Handle Sign Up
  const handleSignup = async () => {
    setError('');
    setSuccess('');
    
    // Validation
    if (!name) {
      setError(text.nameRequired);
      return;
    }
    if (!email) {
      setError(text.emailRequired);
      return;
    }
    if (!validateEmail(email)) {
      setError(text.invalidEmail);
      return;
    }
    if (!password) {
      setError(text.passwordRequired);
      return;
    }
    if (password.length < 6) {
      setError(text.passwordMinLength);
      return;
    }
    if (password !== confirmPassword) {
      setError(text.passwordMismatch);
      return;
    }
    if (!agreedToTerms) {
      setError(text.termsRequired);
      return;
    }

    setLoading(true);
    
    // Simulate API call with realistic delay
    setTimeout(() => {
      try {
        // Get existing users
        const users = JSON.parse(localStorage.getItem('healmate_users') || '[]');
        
        // Check if email already exists
        const emailExists = users.find((u: any) => 
          u.email.toLowerCase() === email.toLowerCase()
        );
        
        if (emailExists) {
          setError(text.signupError);
          setLoading(false);
          return;
        }
        
        // Create new user
        const newUser = {
          id: Date.now().toString(),
          email: email.toLowerCase(),
          password: password,
          name: name,
          phone: phone || '',
          createdAt: new Date().toISOString(),
          isPremium: false,
          profileImage: 'https://images.unsplash.com/photo-1633332755192-727a05c4013d?w=400'
        };
        
        // Add to users list
        users.push(newUser);
        
        // Save to localStorage
        localStorage.setItem('healmate_users', JSON.stringify(users));
        
        // Show success message
        setSuccess(text.signupSuccess);
        
        // Auto login after 1 second
        setTimeout(() => {
          onLogin(email, name);
        }, 800);
        
      } catch (error) {
        setError(text.signupError);
        setLoading(false);
      }
    }, 1200);
  };

  // Handle Forgot Password
  const handleForgotPassword = async () => {
    setError('');
    setSuccess('');
    
    // Validation
    if (!email) {
      setError(text.emailRequired);
      return;
    }
    if (!validateEmail(email)) {
      setError(text.invalidEmail);
      return;
    }

    setLoading(true);
    
    // Simulate API call
    setTimeout(() => {
      setSuccess(text.resetSuccess);
      setLoading(false);
    }, 1500);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-red-500 via-pink-500 to-purple-600 relative overflow-hidden">
      {/* Animated Background */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute top-20 left-10 w-72 h-72 bg-white/10 rounded-full blur-3xl animate-pulse" />
        <div className="absolute bottom-20 right-10 w-96 h-96 bg-white/10 rounded-full blur-3xl animate-pulse" style={{ animationDelay: '1s' }} />
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[500px] h-[500px] bg-white/5 rounded-full blur-3xl animate-pulse" style={{ animationDelay: '2s' }} />
      </div>

      {/* Back Button */}
      <div className="absolute top-6 left-6 z-50">
        <Button
          variant="ghost"
          size="icon"
          onClick={onBack}
          className="bg-white/20 backdrop-blur-xl border border-white/30 hover:bg-white/30 text-white"
        >
          <ArrowLeft className="w-5 h-5" />
        </Button>
      </div>

      {/* Main Content */}
      <div className="relative z-10 min-h-screen flex items-center justify-center p-4">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 max-w-6xl w-full">
          {/* Left Side - Branding */}
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            className="hidden lg:flex flex-col justify-center text-white space-y-6 p-8"
          >
            <div className="space-y-4">
              <motion.div
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                transition={{ duration: 0.5, delay: 0.2 }}
                className="mb-6"
              >
                <Logo size="2xl" showText={false} className="drop-shadow-2xl" />
              </motion.div>
              
              <div>
                <motion.h1
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.3 }}
                  className="text-5xl mb-2"
                >
                  {text.welcomeTo}
                </motion.h1>
                <motion.h2
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.4 }}
                  className="text-6xl font-bold"
                >
                  HealMate
                </motion.h2>
                <motion.p
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.5 }}
                  className="text-xl text-white/90 mt-4"
                >
                  {text.subtitle}
                </motion.p>
              </div>
            </div>

            {/* Features */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.6 }}
              className="space-y-4"
            >
              {[
                { icon: Stethoscope, text: text.feature1 },
                { icon: Hospital, text: text.feature2 },
                { icon: Shield, text: text.feature3 },
                { icon: Heart, text: text.feature4 }
              ].map((feature, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.7 + index * 0.1 }}
                  className="flex items-center gap-3 bg-white/10 backdrop-blur-xl rounded-2xl p-4 border border-white/20"
                >
                  <div className="w-12 h-12 bg-white/20 rounded-xl flex items-center justify-center">
                    <feature.icon className="w-6 h-6" />
                  </div>
                  <span className="text-lg">{feature.text}</span>
                </motion.div>
              ))}
            </motion.div>
          </motion.div>

          {/* Right Side - Auth Form */}
          <motion.div
            initial={{ opacity: 0, x: 50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            className="flex items-center justify-center"
          >
            <div className="bg-white/95 backdrop-blur-3xl rounded-3xl shadow-2xl p-8 w-full max-w-md border border-white/50">
              {/* Tabs */}
              <div className="flex gap-2 mb-8 bg-gray-100 rounded-2xl p-1">
                <button
                  onClick={() => setMode('login')}
                  className={`flex-1 py-3 rounded-xl transition-all ${
                    mode === 'login'
                      ? 'bg-gradient-to-r from-red-600 to-pink-600 text-white shadow-lg'
                      : 'text-gray-600 hover:text-gray-900'
                  }`}
                >
                  {text.login}
                </button>
                <button
                  onClick={() => setMode('signup')}
                  className={`flex-1 py-3 rounded-xl transition-all ${
                    mode === 'signup'
                      ? 'bg-gradient-to-r from-red-600 to-pink-600 text-white shadow-lg'
                      : 'text-gray-600 hover:text-gray-900'
                  }`}
                >
                  {text.signup}
                </button>
              </div>

              {/* Error/Success Messages */}
              <AnimatePresence mode="wait">
                {error && (
                  <motion.div
                    initial={{ opacity: 0, scale: 0.95, y: -10 }}
                    animate={{ opacity: 1, scale: 1, y: 0 }}
                    exit={{ opacity: 0, scale: 0.95, y: -10 }}
                    transition={{ duration: 0.2 }}
                    className="mb-4 p-4 bg-gradient-to-r from-red-50 to-red-100 border border-red-300 rounded-xl flex items-center gap-3 text-red-800 shadow-sm"
                  >
                    <AlertCircle className="w-5 h-5 flex-shrink-0" />
                    <span className="text-sm flex-1" dir={language === 'en' ? 'ltr' : 'rtl'}>{error}</span>
                  </motion.div>
                )}
                {success && (
                  <motion.div
                    initial={{ opacity: 0, scale: 0.95, y: -10 }}
                    animate={{ opacity: 1, scale: 1, y: 0 }}
                    exit={{ opacity: 0, scale: 0.95, y: -10 }}
                    transition={{ duration: 0.2 }}
                    className="mb-4 p-4 bg-gradient-to-r from-green-50 to-emerald-100 border border-green-300 rounded-xl flex items-center gap-3 text-green-800 shadow-sm"
                  >
                    <Check className="w-5 h-5 flex-shrink-0" />
                    <span className="text-sm flex-1" dir={language === 'en' ? 'ltr' : 'rtl'}>{success}</span>
                  </motion.div>
                )}
              </AnimatePresence>

              {/* Forms */}
              <AnimatePresence mode="wait">
                {/* Login Form */}
                {mode === 'login' && (
                  <motion.div
                    key="login"
                    initial={{ opacity: 0, x: 20 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: -20 }}
                    className="space-y-4"
                  >
                    <div>
                      <Label htmlFor="login-email">{text.email}</Label>
                      <div className="relative mt-2">
                        <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                        <Input
                          id="login-email"
                          type="email"
                          placeholder={text.emailPlaceholder}
                          value={email}
                          onChange={(e) => setEmail(e.target.value)}
                          className="pl-10"
                          dir={language === 'en' ? 'ltr' : 'rtl'}
                          onKeyPress={(e) => e.key === 'Enter' && handleLogin()}
                        />
                      </div>
                    </div>

                    <div>
                      <Label htmlFor="login-password">{text.password}</Label>
                      <div className="relative mt-2">
                        <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                        <Input
                          id="login-password"
                          type={showPassword ? 'text' : 'password'}
                          placeholder={text.passwordPlaceholder}
                          value={password}
                          onChange={(e) => handlePasswordChange(e.target.value)}
                          className="pl-10 pr-10"
                          dir="ltr"
                          onKeyPress={(e) => e.key === 'Enter' && handleLogin()}
                        />
                        <button
                          type="button"
                          onClick={() => setShowPassword(!showPassword)}
                          className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600"
                        >
                          {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                        </button>
                      </div>
                    </div>

                    <div className="text-right">
                      <button
                        onClick={() => setMode('forgot')}
                        className="text-sm text-red-600 hover:text-red-700"
                      >
                        {text.forgotPassword}
                      </button>
                    </div>

                    <Button
                      onClick={handleLogin}
                      disabled={loading || !email || !password}
                      className="w-full bg-gradient-to-r from-red-600 to-pink-600 hover:from-red-700 hover:to-pink-700 text-white h-12 disabled:opacity-50 disabled:cursor-not-allowed"
                    >
                      {loading ? (
                        <div className="flex items-center gap-2">
                          <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                          <span>{language === 'ps' ? 'لطفاً انتظار وکړئ...' : language === 'fa' ? 'لطفاً صبر کنید...' : 'Please wait...'}</span>
                        </div>
                      ) : (
                        text.loginButton
                      )}
                    </Button>
                  </motion.div>
                )}

                {/* Sign Up Form */}
                {mode === 'signup' && (
                  <motion.div
                    key="signup"
                    initial={{ opacity: 0, x: 20 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: -20 }}
                    className="space-y-4"
                  >
                    <div>
                      <Label htmlFor="signup-name">{text.fullName}</Label>
                      <div className="relative mt-2">
                        <User className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                        <Input
                          id="signup-name"
                          type="text"
                          placeholder={text.namePlaceholder}
                          value={name}
                          onChange={(e) => setName(e.target.value)}
                          className="pl-10"
                          dir={language === 'en' ? 'ltr' : 'rtl'}
                        />
                      </div>
                    </div>

                    <div>
                      <Label htmlFor="signup-email">{text.email}</Label>
                      <div className="relative mt-2">
                        <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                        <Input
                          id="signup-email"
                          type="email"
                          placeholder={text.emailPlaceholder}
                          value={email}
                          onChange={(e) => setEmail(e.target.value)}
                          className="pl-10"
                          dir={language === 'en' ? 'ltr' : 'rtl'}
                        />
                      </div>
                    </div>

                    <div>
                      <Label htmlFor="signup-password">{text.password}</Label>
                      <div className="relative mt-2">
                        <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                        <Input
                          id="signup-password"
                          type={showPassword ? 'text' : 'password'}
                          placeholder={text.passwordPlaceholder}
                          value={password}
                          onChange={(e) => handlePasswordChange(e.target.value)}
                          className="pl-10 pr-10"
                          dir="ltr"
                        />
                        <button
                          type="button"
                          onClick={() => setShowPassword(!showPassword)}
                          className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600"
                        >
                          {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                        </button>
                      </div>
                      
                      {/* Password Strength Indicator */}
                      {password && (
                        <div className="mt-2">
                          <div className="flex gap-1">
                            {[1, 2, 3, 4, 5].map((level) => (
                              <div
                                key={level}
                                className={`h-1 flex-1 rounded-full transition-all ${
                                  passwordStrength >= level
                                    ? passwordStrength <= 2
                                      ? 'bg-red-500'
                                      : passwordStrength === 3
                                      ? 'bg-yellow-500'
                                      : 'bg-green-500'
                                    : 'bg-gray-200'
                                }`}
                              />
                            ))}
                          </div>
                          <p className={`text-xs mt-1 ${
                            passwordStrength <= 2 ? 'text-red-600' : 
                            passwordStrength === 3 ? 'text-yellow-600' : 
                            'text-green-600'
                          }`}>
                            {passwordStrength <= 2 
                              ? (language === 'ps' ? 'کمزوری پټنوم' : language === 'fa' ? 'رمز ضعیف' : 'Weak password')
                              : passwordStrength === 3
                              ? (language === 'ps' ? 'منځنی پټنوم' : language === 'fa' ? 'رمز متوسط' : 'Medium password')
                              : (language === 'ps' ? 'قوي پټنوم' : language === 'fa' ? 'رمز قوی' : 'Strong password')
                            }
                          </p>
                        </div>
                      )}
                    </div>

                    <div>
                      <Label htmlFor="signup-confirm">{text.confirmPassword}</Label>
                      <div className="relative mt-2">
                        <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                        <Input
                          id="signup-confirm"
                          type={showConfirmPassword ? 'text' : 'password'}
                          placeholder={text.confirmPassword}
                          value={confirmPassword}
                          onChange={(e) => setConfirmPassword(e.target.value)}
                          className="pl-10 pr-10"
                          dir="ltr"
                          onKeyPress={(e) => e.key === 'Enter' && agreedToTerms && handleSignup()}
                        />
                        <button
                          type="button"
                          onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                          className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600"
                        >
                          {showConfirmPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                        </button>
                      </div>
                    </div>

                    <div className={`flex items-center gap-2 ${language === 'en' ? 'flex-row' : 'flex-row-reverse'}`}>
                      <input
                        id="terms-checkbox"
                        type="checkbox"
                        checked={agreedToTerms}
                        onChange={(e) => setAgreedToTerms(e.target.checked)}
                        className="w-4 h-4 text-red-600 border-gray-300 rounded focus:ring-red-500 cursor-pointer"
                      />
                      <Label htmlFor="terms-checkbox" className="text-sm cursor-pointer">
                        {text.termsAgree}{' '}
                        <a href="#" className="text-red-600 hover:underline font-medium">
                          {text.termsLink}
                        </a>
                        {' '}&{' '}
                        <a href="#" className="text-red-600 hover:underline font-medium">
                          {text.privacyLink}
                        </a>
                      </Label>
                    </div>

                    <Button
                      onClick={handleSignup}
                      disabled={loading || !name || !email || !password || !confirmPassword || !agreedToTerms}
                      className="w-full bg-gradient-to-r from-red-600 to-pink-600 hover:from-red-700 hover:to-pink-700 text-white h-12 disabled:opacity-50 disabled:cursor-not-allowed"
                    >
                      {loading ? (
                        <div className="flex items-center gap-2">
                          <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                          <span>{language === 'ps' ? 'حساب جوړیږي...' : language === 'fa' ? 'در حال ایجاد حساب...' : 'Creating account...'}</span>
                        </div>
                      ) : (
                        text.signupButton
                      )}
                    </Button>
                  </motion.div>
                )}

                {/* Forgot Password Form */}
                {mode === 'forgot' && (
                  <motion.div
                    key="forgot"
                    initial={{ opacity: 0, x: 20 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: -20 }}
                    className="space-y-4"
                  >
                    <div>
                      <Label htmlFor="forgot-email">{text.email}</Label>
                      <div className="relative mt-2">
                        <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                        <Input
                          id="forgot-email"
                          type="email"
                          placeholder={text.emailPlaceholder}
                          value={email}
                          onChange={(e) => setEmail(e.target.value)}
                          className="pl-10"
                          dir={language === 'en' ? 'ltr' : 'rtl'}
                        />
                      </div>
                    </div>

                    <Button
                      onClick={handleForgotPassword}
                      disabled={loading}
                      className="w-full bg-gradient-to-r from-red-600 to-pink-600 hover:from-red-700 hover:to-pink-700 text-white h-12"
                    >
                      {loading ? (
                        <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                      ) : (
                        text.resetButton
                      )}
                    </Button>

                    <div className="text-center">
                      <button
                        onClick={() => setMode('login')}
                        className="text-sm text-red-600 hover:text-red-700"
                      >
                        {text.backToLogin}
                      </button>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          </motion.div>
        </div>
      </div>

      {/* Floating Particles */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden">
        {[...Array(30)].map((_, i) => (
          <motion.div
            key={i}
            initial={{
              x: Math.random() * window.innerWidth,
              y: window.innerHeight + 100,
              opacity: 0
            }}
            animate={{
              y: -100,
              opacity: [0, 1, 0]
            }}
            transition={{
              duration: Math.random() * 10 + 10,
              repeat: Infinity,
              delay: Math.random() * 5
            }}
            className="absolute w-2 h-2 bg-white rounded-full"
            style={{
              left: `${Math.random() * 100}%`,
              filter: 'blur(1px)'
            }}
          />
        ))}
      </div>
    </div>
  );
}