// Charity Category for HomeScreen
// This will be manually inserted into HomeScreen.tsx healthCategories array

export const charityCategory = {
  id: "charity",
  icon: "Heart", // Will use Heart from lucide-react
  label: "مرسته وکړئ / کمک کنید / Help & Support",
  labelPashto: "مرسته وکړئ",
  labelDari: "کمک کنید",
  gradient: "from-pink-500 to-rose-600",
  bgColor: "from-pink-50 to-rose-50",
  doctors: [
    { 
      name: "Dr. ابراهیم خاکسار", 
      specialty: "Charity Director", 
      experience: "Founder", 
      rating: 5.0, 
      patients: "All" 
    },
    { 
      name: "Social Worker Team", 
      specialty: "Case Verification", 
      experience: "24/7", 
      rating: 4.9, 
      patients: "Community" 
    },
    { 
      name: "Volunteer Network", 
      specialty: "Support Services", 
      experience: "Active", 
      rating: 4.8, 
      patients: "Nationwide" 
    },
  ],
  books: [
    { 
      title: "Charity & Giving", 
      titlePs: "خیرات او ورکول", 
      titleFa: "خیریه و بخشش", 
      author: "Dr. Ibrahim Khaksar", 
      pages: 250, 
      language: "Multi", 
      rating: 5.0,
      downloads: 8500,
      views: 25000,
      summary: "Complete guide to charitable giving and helping those in need. Learn about effective fundraising, case verification, and community support.",
      summaryPs: "د خیرات او مرستې بشپړ لارښود. د اغیزمن پیسو راټولولو، قضیې تایید، او ټولنیز ملاتړ په اړه زده کړئ.",
      summaryFa: "راهنمای کامل بخشش خیریه و کمک به نیازمندان. در مورد جمع‌آوری کمک‌های مؤثر، تایید موارد و حمایت جامعه بیاموزید."
    },
    { 
      title: "Helping Communities", 
      titlePs: "د ټولنې سره مرسته", 
      titleFa: "کمک به جامعه", 
      author: "Social Team", 
      pages: 180, 
      language: "Multi", 
      rating: 4.9,
      downloads: 6200,
      views: 18500,
      summary: "Strategies for building strong community support networks and helping those facing hardships.",
      summaryPs: "د قوي ټولنیز ملاتړ شبکو جوړولو او د مشکلاتو سره مخامخ کسانو سره د مرستې ستراتیژۍ.",
      summaryFa: "استراتژی‌هایی برای ایجاد شبکه‌های حمایتی قوی جامعه و کمک به افراد در سختی."
    },
    { 
      title: "Fundraising Guide", 
      titlePs: "د پیسو راټولولو لارښود", 
      titleFa: "راهنمای جمع‌آوری کمک", 
      author: "NGO Network", 
      pages: 220, 
      language: "Multi", 
      rating: 4.8,
      downloads: 5400,
      views: 16800,
      summary: "Professional fundraising techniques for medical cases, emergency needs, and community projects.",
      summaryPs: "د طبي قضیو، بیړنیو اړتیاوو، او ټولنیز پروژو لپاره حرفه‌ای د پیسو راټولولو تخنیکونه.",
      summaryFa: "تکنیک‌های حرفه‌ای جمع‌آوری کمک برای موارد پزشکی، نیازهای اضطراری و پروژه‌های جامعه."
    },
    { 
      title: "Impact Stories", 
      titlePs: "د اغیزې کیسې", 
      titleFa: "داستان‌های تاثیرگذار", 
      author: "Community", 
      pages: 195, 
      language: "Multi", 
      rating: 4.7,
      downloads: 4800,
      views: 14200,
      summary: "Real stories of lives changed through charitable giving and community support in Afghanistan.",
      summaryPs: "د خیرات او ټولنیز ملاتړ له لارې په افغانستان کې د بدل شوو ژوندونو ریښتیني کیسې.",
      summaryFa: "داستان‌های واقعی از زندگی‌های تغییر یافته از طریق بخشش خیریه و حمایت جامعه در افغانستان."
    },
    { 
      title: "Volunteer Handbook", 
      titlePs: "د رضاکارانو لارښود", 
      titleFa: "کتابچه داوطلبان", 
      author: "Volunteer Team", 
      pages: 165, 
      language: "Multi", 
      rating: 4.6,
      downloads: 3900,
      views: 11700,
      summary: "Essential guide for volunteers working in healthcare charity and community support programs.",
      summaryPs: "د روغتیایي خیرات او ټولنیز ملاتړ پروګرامونو کې کار کوونکو رضاکارانو لپاره اړین لارښود.",
      summaryFa: "راهنمای ضروری برای داوطلبان فعال در برنامه‌های خیریه بهداشتی و حمایت جامعه."
    },
  ]
};

// To add to HomeScreen.tsx, insert this object between "general" category and "emergency" category
// Make sure to import Heart icon if not already imported
