import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";
import { Input } from "./ui/input";
import { Textarea } from "./ui/textarea";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "./ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs";
import { 
  ShoppingCart, 
  Search,
  Upload,
  Truck,
  MapPin,
  Clock,
  Phone,
  CheckCircle,
  XCircle,
  Star,
  TrendingDown,
  Building2,
  Package,
  CreditCard,
  FileText,
  AlertCircle,
  Sparkles,
  Plus,
  Minus,
  Trash2,
  Receipt,
  Home
} from "lucide-react";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select";
import { Separator } from "./ui/separator";
import { Alert, AlertDescription } from "./ui/alert";

interface CartItem {
  id: number;
  name: string;
  nameDari: string;
  price: number;
  quantity: number;
  pharmacy: string;
  inStock: boolean;
  image?: string;
}

interface Pharmacy {
  id: number;
  name: string;
  nameDari: string;
  location: string;
  locationDari: string;
  rating: number;
  deliveryTime: string;
  deliveryFee: number;
  phone: string;
  open: boolean;
}

interface PrescriptionUpload {
  id: number;
  fileName: string;
  date: string;
  status: "pending" | "approved" | "rejected";
  medicines?: string[];
}

const pharmacies: Pharmacy[] = [
  {
    id: 1,
    name: "Kabul Medical Pharmacy",
    nameDari: "کابل طبی درملتون",
    location: "Wazir Akbar Khan, Kabul",
    locationDari: "وزیر اکبر خان، کابل",
    rating: 4.8,
    deliveryTime: "30-45 min",
    deliveryFee: 50,
    phone: "+93 700 123 456",
    open: true
  },
  {
    id: 2,
    name: "Aria Pharmacy",
    nameDari: "آریا درملتون",
    location: "Shar-e-Naw, Kabul",
    locationDari: "شهر نو، کابل",
    rating: 4.6,
    deliveryTime: "40-60 min",
    deliveryFee: 60,
    phone: "+93 700 234 567",
    open: true
  },
  {
    id: 3,
    name: "Herat Medical Center",
    nameDari: "هرات طبی مرکز",
    location: "Center, Herat",
    locationDari: "مرکز، هرات",
    rating: 4.7,
    deliveryTime: "35-50 min",
    deliveryFee: 55,
    phone: "+93 700 345 678",
    open: false
  },
  {
    id: 4,
    name: "Mazar Pharmacy",
    nameDari: "مزار درملتون",
    location: "Balkh, Mazar-i-Sharif",
    locationDari: "بلخ، مزار شریف",
    rating: 4.5,
    deliveryTime: "45-60 min",
    deliveryFee: 65,
    phone: "+93 700 456 789",
    open: true
  }
];

const featuredMedicines = [
  { id: 1, name: "Paracetamol 500mg", nameDari: "پاراسیتامول", price: 50, inStock: true, pharmacy: "Kabul Medical Pharmacy" },
  { id: 2, name: "Amoxicillin 500mg", nameDari: "اموکسیسیلین", price: 120, inStock: true, pharmacy: "Aria Pharmacy" },
  { id: 3, name: "Vitamin D3 1000IU", nameDari: "ویټامین D3", price: 200, inStock: true, pharmacy: "Kabul Medical Pharmacy" },
  { id: 4, name: "Ibuprofen 400mg", nameDari: "ایبوپروفین", price: 80, inStock: true, pharmacy: "Herat Medical Center" },
  { id: 5, name: "Omeprazole 20mg", nameDari: "اومیپرازول", price: 150, inStock: true, pharmacy: "Mazar Pharmacy" },
  { id: 6, name: "Cetirizine 10mg", nameDari: "سیټیریزین", price: 60, inStock: true, pharmacy: "Aria Pharmacy" },
];

const mockPrescriptions: PrescriptionUpload[] = [
  {
    id: 1,
    fileName: "prescription_2025_11_10.pdf",
    date: "2025-11-10",
    status: "approved",
    medicines: ["Amoxicillin 500mg", "Paracetamol 500mg", "Vitamin B Complex"]
  },
  {
    id: 2,
    fileName: "prescription_2025_11_12.jpg",
    date: "2025-11-12",
    status: "pending",
    medicines: []
  }
];

export function EPharmacy() {
  const [activeTab, setActiveTab] = useState("browse");
  const [cart, setCart] = useState<CartItem[]>([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedPharmacy, setSelectedPharmacy] = useState<number | null>(null);
  const [checkoutOpen, setCheckoutOpen] = useState(false);
  const [prescriptions, setPrescriptions] = useState<PrescriptionUpload[]>(mockPrescriptions);
  const [compareMode, setCompareMode] = useState(false);

  const addToCart = (medicine: typeof featuredMedicines[0]) => {
    const existingItem = cart.find(item => item.id === medicine.id);
    
    if (existingItem) {
      setCart(cart.map(item => 
        item.id === medicine.id 
          ? { ...item, quantity: item.quantity + 1 }
          : item
      ));
    } else {
      setCart([...cart, {
        id: medicine.id,
        name: medicine.name,
        nameDari: medicine.nameDari,
        price: medicine.price,
        quantity: 1,
        pharmacy: medicine.pharmacy,
        inStock: medicine.inStock
      }]);
    }
  };

  const updateQuantity = (id: number, change: number) => {
    setCart(cart.map(item => {
      if (item.id === id) {
        const newQuantity = item.quantity + change;
        return newQuantity > 0 ? { ...item, quantity: newQuantity } : item;
      }
      return item;
    }).filter(item => item.quantity > 0));
  };

  const removeFromCart = (id: number) => {
    setCart(cart.filter(item => item.id !== id));
  };

  const getTotalPrice = () => {
    return cart.reduce((total, item) => total + (item.price * item.quantity), 0);
  };

  const getDeliveryFee = () => {
    if (selectedPharmacy) {
      const pharmacy = pharmacies.find(p => p.id === selectedPharmacy);
      return pharmacy?.deliveryFee || 0;
    }
    return 50; // Default delivery fee
  };

  return (
    <section className="py-16 md:py-24 bg-gradient-to-b from-white via-green-50/30 to-white relative overflow-hidden min-h-screen">
      {/* Background decoration */}
      <div className="absolute top-0 left-0 w-[500px] h-[500px] bg-gradient-to-br from-green-100/50 to-emerald-100/50 rounded-full blur-3xl animate-float"></div>
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        {/* Header */}
        <div className="text-center mb-12 md:mb-16 space-y-4">
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-green-100 to-emerald-100 rounded-full">
            <Sparkles className="w-4 h-4 text-green-600 animate-pulse-glow" />
            <span className="text-green-700 text-sm uppercase tracking-wider">E-Pharmacy</span>
          </div>
          <h2 className="text-4xl md:text-6xl">
            <span className="bg-gradient-to-r from-green-600 via-emerald-600 to-teal-600 bg-clip-text text-transparent">
              Online Pharmacy
            </span>
          </h2>
          <p className="text-gray-600 max-w-2xl mx-auto text-lg">
            Order medicines online with home delivery
          </p>
        </div>

        {/* Shopping Cart Badge */}
        <div className="fixed top-20 right-4 z-50">
          <Button
            className="relative bg-gradient-to-r from-green-500 to-emerald-600 hover:from-green-600 hover:to-emerald-700 shadow-lg rounded-full w-14 h-14"
            onClick={() => setActiveTab("cart")}
          >
            <ShoppingCart className="w-6 h-6" />
            {cart.length > 0 && (
              <Badge className="absolute -top-2 -right-2 bg-red-500 text-white w-6 h-6 flex items-center justify-center p-0 rounded-full animate-pulse-glow">
                {cart.length}
              </Badge>
            )}
          </Button>
        </div>

        {/* Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-4 mb-8">
            <TabsTrigger value="browse" className="flex items-center gap-2">
              <Search className="w-4 h-4" />
              <span className="hidden md:inline">Browse</span>
            </TabsTrigger>
            <TabsTrigger value="prescription" className="flex items-center gap-2">
              <Upload className="w-4 h-4" />
              <span className="hidden md:inline">Prescription</span>
            </TabsTrigger>
            <TabsTrigger value="cart" className="flex items-center gap-2">
              <ShoppingCart className="w-4 h-4" />
              <span className="hidden md:inline">Cart ({cart.length})</span>
            </TabsTrigger>
            <TabsTrigger value="pharmacies" className="flex items-center gap-2">
              <Building2 className="w-4 h-4" />
              <span className="hidden md:inline">Pharmacies</span>
            </TabsTrigger>
          </TabsList>

          {/* Browse Medicines Tab */}
          <TabsContent value="browse" className="space-y-6">
            {/* Search Bar */}
            <div className="flex gap-4 mb-6">
              <div className="flex-1 relative">
                <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                <Input
                  placeholder="Search medicines... | دوا ولټوئ..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-12 h-12 rounded-xl shadow-lg border-2 border-gray-200"
                />
              </div>
              <Button
                variant={compareMode ? "default" : "outline"}
                onClick={() => setCompareMode(!compareMode)}
                className={compareMode ? "bg-gradient-to-r from-blue-500 to-cyan-600" : ""}
              >
                <TrendingDown className="w-4 h-4 mr-2" />
                Compare Prices
              </Button>
            </div>

            {/* Featured Medicines */}
            <div>
              <h3 className="text-2xl mb-6 flex items-center gap-2">
                <Package className="w-6 h-6 text-green-600" />
                Featured Medicines - مشهور دواګانه
              </h3>

              {compareMode ? (
                /* Price Comparison View */
                <div className="space-y-4">
                  {featuredMedicines.map((medicine) => (
                    <Card key={medicine.id} className="hover-lift border-0 shadow-lg">
                      <CardContent className="p-6">
                        <div className="flex items-center justify-between mb-4">
                          <div>
                            <h4 className="text-lg mb-1">{medicine.name}</h4>
                            <p className="text-sm text-green-600">{medicine.nameDari}</p>
                          </div>
                          <Badge className={medicine.inStock ? "bg-green-100 text-green-700" : "bg-red-100 text-red-700"}>
                            {medicine.inStock ? "In Stock" : "Out of Stock"}
                          </Badge>
                        </div>

                        {/* Pharmacy Comparison */}
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                          {pharmacies.filter(p => p.open).map((pharmacy) => {
                            const priceVariation = Math.floor(Math.random() * 30) - 10;
                            const pharmacyPrice = medicine.price + priceVariation;
                            const isLowest = priceVariation <= -5;

                            return (
                              <div
                                key={pharmacy.id}
                                className={`p-4 rounded-lg border-2 transition-all ${
                                  isLowest 
                                    ? "border-green-500 bg-green-50" 
                                    : "border-gray-200 bg-gray-50"
                                }`}
                              >
                                <div className="flex items-center justify-between mb-2">
                                  <p className="text-sm text-gray-700">{pharmacy.name}</p>
                                  {isLowest && (
                                    <Badge className="bg-green-600 text-white text-xs">
                                      Lowest
                                    </Badge>
                                  )}
                                </div>
                                <p className="text-2xl text-green-600 mb-2">{pharmacyPrice} AFN</p>
                                <p className="text-xs text-gray-600 mb-2">
                                  <Clock className="w-3 h-3 inline mr-1" />
                                  {pharmacy.deliveryTime}
                                </p>
                                <Button
                                  size="sm"
                                  className="w-full bg-gradient-to-r from-green-500 to-emerald-600 hover:from-green-600 hover:to-emerald-700"
                                  onClick={() => addToCart({ ...medicine, price: pharmacyPrice, pharmacy: pharmacy.name })}
                                >
                                  <Plus className="w-3 h-3 mr-1" />
                                  Add to Cart
                                </Button>
                              </div>
                            );
                          })}
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              ) : (
                /* Normal Browse View */
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {featuredMedicines.map((medicine, index) => (
                    <Card
                      key={medicine.id}
                      className="hover-lift border-0 shadow-lg overflow-hidden"
                      style={{ animationDelay: `${index * 50}ms` }}
                    >
                      <div className="h-2 bg-gradient-to-r from-green-500 to-emerald-600"></div>
                      <CardHeader className="pb-3">
                        <div className="flex items-start justify-between mb-2">
                          <div className="flex-1">
                            <CardTitle className="text-base mb-1">{medicine.name}</CardTitle>
                            <p className="text-sm text-green-600">{medicine.nameDari}</p>
                          </div>
                          <Badge className={medicine.inStock ? "bg-green-100 text-green-700" : "bg-red-100 text-red-700"}>
                            {medicine.inStock ? <CheckCircle className="w-3 h-3 mr-1" /> : <XCircle className="w-3 h-3 mr-1" />}
                            {medicine.inStock ? "Stock" : "Out"}
                          </Badge>
                        </div>
                        <p className="text-xs text-gray-600">{medicine.pharmacy}</p>
                      </CardHeader>
                      <CardContent className="space-y-3">
                        <div className="flex items-center justify-between">
                          <span className="text-2xl text-green-600">{medicine.price} AFN</span>
                        </div>
                        <Button
                          className="w-full bg-gradient-to-r from-green-500 to-emerald-600 hover:from-green-600 hover:to-emerald-700"
                          disabled={!medicine.inStock}
                          onClick={() => addToCart(medicine)}
                        >
                          <ShoppingCart className="w-4 h-4 mr-2" />
                          Add to Cart
                        </Button>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              )}
            </div>
          </TabsContent>

          {/* Upload Prescription Tab */}
          <TabsContent value="prescription" className="space-y-6">
            <Alert className="bg-blue-50 border-blue-200">
              <AlertCircle className="h-4 w-4 text-blue-600" />
              <AlertDescription className="text-blue-800">
                Upload your prescription and our pharmacists will review it. You can then order the prescribed medicines.
                | خپل نسخه اپلوډ کړئ او زموږ درمل جوړوونکي به یې وګوري. بیا تاسو کولی شئ تجویز شوي دواګانه امر وکړئ.
              </AlertDescription>
            </Alert>

            <Card className="hover-lift border-0 shadow-lg">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Upload className="w-5 h-5 text-green-600" />
                  Upload New Prescription - نوې نسخه اپلوډ کړئ
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center hover:border-green-500 transition-colors cursor-pointer bg-gradient-to-br from-green-50/50 to-emerald-50/50">
                  <Upload className="w-12 h-12 text-green-600 mx-auto mb-4" />
                  <p className="text-gray-700 mb-2">Click to upload or drag and drop</p>
                  <p className="text-sm text-gray-500 mb-1">PNG, JPG, PDF up to 10MB</p>
                  <p className="text-sm text-green-600">د عکس یا PDF فایل اپلوډ کړئ</p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <Input placeholder="Patient Name" />
                  <Input placeholder="Doctor Name" />
                </div>

                <Textarea placeholder="Additional Notes (Optional)" className="min-h-[100px]" />

                <Button className="w-full bg-gradient-to-r from-green-500 to-emerald-600 hover:from-green-600 hover:to-emerald-700">
                  <Upload className="w-4 h-4 mr-2" />
                  Upload Prescription
                </Button>
              </CardContent>
            </Card>

            {/* Previous Prescriptions */}
            <div>
              <h3 className="text-2xl mb-6 flex items-center gap-2">
                <FileText className="w-6 h-6 text-green-600" />
                Previous Prescriptions - تیرې نسخې
              </h3>

              <div className="space-y-4">
                {prescriptions.map((prescription) => (
                  <Card key={prescription.id} className="hover-lift border-0 shadow-lg">
                    <CardContent className="p-6">
                      <div className="flex items-center justify-between mb-4">
                        <div className="flex items-center gap-4">
                          <div className="p-3 bg-gradient-to-br from-green-100 to-emerald-100 rounded-lg">
                            <FileText className="w-6 h-6 text-green-600" />
                          </div>
                          <div>
                            <h4 className="text-lg mb-1">{prescription.fileName}</h4>
                            <p className="text-sm text-gray-600">Uploaded: {prescription.date}</p>
                          </div>
                        </div>
                        <Badge className={
                          prescription.status === "approved" ? "bg-green-100 text-green-700" :
                          prescription.status === "pending" ? "bg-amber-100 text-amber-700" :
                          "bg-red-100 text-red-700"
                        }>
                          {prescription.status === "approved" && <CheckCircle className="w-3 h-3 mr-1" />}
                          {prescription.status.toUpperCase()}
                        </Badge>
                      </div>

                      {prescription.status === "approved" && prescription.medicines && (
                        <>
                          <Separator className="my-4" />
                          <div>
                            <p className="text-sm text-gray-600 mb-2">Prescribed Medicines:</p>
                            <div className="flex flex-wrap gap-2">
                              {prescription.medicines.map((med, idx) => (
                                <Badge key={idx} variant="outline" className="text-green-700 border-green-300">
                                  {med}
                                </Badge>
                              ))}
                            </div>
                          </div>
                          <Button className="w-full mt-4 bg-gradient-to-r from-green-500 to-emerald-600">
                            Order These Medicines
                          </Button>
                        </>
                      )}
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          </TabsContent>

          {/* Shopping Cart Tab */}
          <TabsContent value="cart" className="space-y-6">
            {cart.length === 0 ? (
              <Card className="border-0 shadow-lg">
                <CardContent className="p-12 text-center">
                  <ShoppingCart className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                  <h3 className="text-xl text-gray-600 mb-2">Your cart is empty</h3>
                  <p className="text-gray-500 mb-4">ستاسو کارټ خالي دی</p>
                  <Button
                    onClick={() => setActiveTab("browse")}
                    className="bg-gradient-to-r from-green-500 to-emerald-600"
                  >
                    Browse Medicines
                  </Button>
                </CardContent>
              </Card>
            ) : (
              <>
                <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                  {/* Cart Items */}
                  <div className="lg:col-span-2 space-y-4">
                    {cart.map((item) => (
                      <Card key={item.id} className="hover-lift border-0 shadow-lg">
                        <CardContent className="p-6">
                          <div className="flex items-center gap-4">
                            <div className="flex-1">
                              <h4 className="text-lg mb-1">{item.name}</h4>
                              <p className="text-sm text-green-600 mb-2">{item.nameDari}</p>
                              <p className="text-xs text-gray-600">{item.pharmacy}</p>
                            </div>
                            <div className="text-right">
                              <p className="text-xl text-green-600 mb-2">{item.price * item.quantity} AFN</p>
                              <div className="flex items-center gap-2">
                                <Button
                                  size="sm"
                                  variant="outline"
                                  onClick={() => updateQuantity(item.id, -1)}
                                  className="w-8 h-8 p-0"
                                >
                                  <Minus className="w-4 h-4" />
                                </Button>
                                <span className="w-8 text-center">{item.quantity}</span>
                                <Button
                                  size="sm"
                                  variant="outline"
                                  onClick={() => updateQuantity(item.id, 1)}
                                  className="w-8 h-8 p-0"
                                >
                                  <Plus className="w-4 h-4" />
                                </Button>
                                <Button
                                  size="sm"
                                  variant="outline"
                                  onClick={() => removeFromCart(item.id)}
                                  className="w-8 h-8 p-0 text-red-600 hover:bg-red-50"
                                >
                                  <Trash2 className="w-4 h-4" />
                                </Button>
                              </div>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>

                  {/* Order Summary */}
                  <div>
                    <Card className="border-0 shadow-lg sticky top-24">
                      <CardHeader>
                        <CardTitle className="flex items-center gap-2">
                          <Receipt className="w-5 h-5 text-green-600" />
                          Order Summary
                        </CardTitle>
                      </CardHeader>
                      <CardContent className="space-y-4">
                        <div className="space-y-2">
                          <div className="flex justify-between text-sm">
                            <span>Subtotal:</span>
                            <span>{getTotalPrice()} AFN</span>
                          </div>
                          <div className="flex justify-between text-sm">
                            <span>Delivery Fee:</span>
                            <span>{getDeliveryFee()} AFN</span>
                          </div>
                          <Separator />
                          <div className="flex justify-between text-lg">
                            <span>Total:</span>
                            <span className="text-green-600">{getTotalPrice() + getDeliveryFee()} AFN</span>
                          </div>
                        </div>

                        <Separator />

                        <Select value={selectedPharmacy?.toString()} onValueChange={(val) => setSelectedPharmacy(Number(val))}>
                          <SelectTrigger>
                            <SelectValue placeholder="Select Pharmacy" />
                          </SelectTrigger>
                          <SelectContent>
                            {pharmacies.filter(p => p.open).map(pharmacy => (
                              <SelectItem key={pharmacy.id} value={pharmacy.id.toString()}>
                                <div className="flex items-center gap-2">
                                  <Building2 className="w-4 h-4" />
                                  {pharmacy.name}
                                </div>
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>

                        <Button
                          className="w-full bg-gradient-to-r from-green-500 to-emerald-600 hover:from-green-600 hover:to-emerald-700"
                          onClick={() => setCheckoutOpen(true)}
                        >
                          <Truck className="w-4 h-4 mr-2" />
                          Proceed to Checkout
                        </Button>
                      </CardContent>
                    </Card>
                  </div>
                </div>
              </>
            )}
          </TabsContent>

          {/* Pharmacies Tab */}
          <TabsContent value="pharmacies" className="space-y-6">
            <h3 className="text-2xl mb-6 flex items-center gap-2">
              <Building2 className="w-6 h-6 text-green-600" />
              Available Pharmacies - موجود درملتونونه
            </h3>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {pharmacies.map((pharmacy, index) => (
                <Card
                  key={pharmacy.id}
                  className={`hover-lift border-0 shadow-lg overflow-hidden ${!pharmacy.open && 'opacity-60'}`}
                  style={{ animationDelay: `${index * 50}ms` }}
                >
                  <div className={`h-2 bg-gradient-to-r ${pharmacy.open ? 'from-green-500 to-emerald-600' : 'from-gray-400 to-gray-500'}`}></div>
                  <CardHeader>
                    <div className="flex items-start justify-between mb-2">
                      <div className="flex-1">
                        <CardTitle className="text-lg mb-1">{pharmacy.name}</CardTitle>
                        <p className="text-sm text-green-600">{pharmacy.nameDari}</p>
                      </div>
                      <Badge className={pharmacy.open ? "bg-green-100 text-green-700" : "bg-red-100 text-red-700"}>
                        {pharmacy.open ? "Open" : "Closed"}
                      </Badge>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <div className="flex items-center gap-2 text-sm text-gray-600">
                      <MapPin className="w-4 h-4" />
                      <div>
                        <p>{pharmacy.location}</p>
                        <p className="text-xs">{pharmacy.locationDari}</p>
                      </div>
                    </div>

                    <div className="flex items-center gap-2 text-sm text-gray-600">
                      <Clock className="w-4 h-4" />
                      <span>Delivery: {pharmacy.deliveryTime}</span>
                    </div>

                    <div className="flex items-center gap-2 text-sm text-gray-600">
                      <Truck className="w-4 h-4" />
                      <span>Delivery Fee: {pharmacy.deliveryFee} AFN</span>
                    </div>

                    <div className="flex items-center gap-2 text-sm text-gray-600">
                      <Phone className="w-4 h-4" />
                      <span>{pharmacy.phone}</span>
                    </div>

                    <div className="flex items-center gap-1">
                      {Array.from({ length: 5 }).map((_, i) => (
                        <Star
                          key={i}
                          className={`w-4 h-4 ${
                            i < Math.floor(pharmacy.rating)
                              ? "fill-yellow-400 text-yellow-400"
                              : "text-gray-300"
                          }`}
                        />
                      ))}
                      <span className="text-sm text-gray-600 ml-2">{pharmacy.rating}</span>
                    </div>

                    <Separator />

                    <Button
                      className="w-full bg-gradient-to-r from-green-500 to-emerald-600 hover:from-green-600 hover:to-emerald-700"
                      disabled={!pharmacy.open}
                      onClick={() => {
                        setSelectedPharmacy(pharmacy.id);
                        setActiveTab("browse");
                      }}
                    >
                      Browse Medicines
                    </Button>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>
        </Tabs>
      </div>

      {/* Checkout Modal */}
      <Dialog open={checkoutOpen} onOpenChange={setCheckoutOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle className="text-2xl">Checkout - نغد ورکول</DialogTitle>
            <DialogDescription>Complete your order and provide delivery details</DialogDescription>
          </DialogHeader>
          <div className="space-y-6">
            {/* Delivery Address */}
            <div>
              <h3 className="text-lg mb-4 flex items-center gap-2">
                <MapPin className="w-5 h-5 text-green-600" />
                Delivery Address - د رسولو پته
              </h3>
              <div className="space-y-3">
                <Input placeholder="Street Address" />
                <div className="grid grid-cols-2 gap-3">
                  <Input placeholder="City" />
                  <Input placeholder="District" />
                </div>
                <Input placeholder="Landmark (Optional)" />
                <Input placeholder="Phone Number" />
              </div>
            </div>

            <Separator />

            {/* Payment Method */}
            <div>
              <h3 className="text-lg mb-4 flex items-center gap-2">
                <CreditCard className="w-5 h-5 text-green-600" />
                Payment Method - د تادیې طریقه
              </h3>
              <div className="space-y-2">
                <div className="p-4 border-2 border-green-500 rounded-lg bg-green-50">
                  <div className="flex items-center gap-3">
                    <Home className="w-5 h-5 text-green-600" />
                    <div className="flex-1">
                      <p className="text-gray-900">Cash on Delivery</p>
                      <p className="text-sm text-green-600">نغدې پیسې په رسولو سره</p>
                    </div>
                    <CheckCircle className="w-5 h-5 text-green-600" />
                  </div>
                </div>
              </div>
            </div>

            <Separator />

            {/* Order Summary */}
            <div className="p-4 bg-gradient-to-r from-green-50 to-emerald-50 rounded-lg">
              <h4 className="mb-3">Order Summary:</h4>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span>Items ({cart.length}):</span>
                  <span>{getTotalPrice()} AFN</span>
                </div>
                <div className="flex justify-between">
                  <span>Delivery Fee:</span>
                  <span>{getDeliveryFee()} AFN</span>
                </div>
                <Separator />
                <div className="flex justify-between text-lg">
                  <span>Total:</span>
                  <span className="text-green-600">{getTotalPrice() + getDeliveryFee()} AFN</span>
                </div>
              </div>
            </div>

            <Button className="w-full bg-gradient-to-r from-green-500 to-emerald-600 hover:from-green-600 hover:to-emerald-700 h-12">
              <CheckCircle className="w-5 h-5 mr-2" />
              Place Order - امر ورکړئ
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </section>
  );
}

export default EPharmacy;
