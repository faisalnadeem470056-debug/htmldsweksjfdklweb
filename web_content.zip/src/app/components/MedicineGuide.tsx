import { useState, useEffect } from 'react';
import { ArrowLeft, Search, Pill, AlertCircle, Info, DollarSign, Package, Calendar, Shield, X } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Badge } from './ui/badge';
import { translations } from '../translations';
import { AdBanner } from './AdBanner';
import { fullMedicinesDatabase, medicineCategories, getMedicinesByCategory, searchMedicines, Medicine } from '../data/medicines-full-database';

interface MedicineGuideProps {
  language: 'ps' | 'fa' | 'en';
  onBack: () => void;
}

export function MedicineGuide({ language, onBack }: MedicineGuideProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedMedicine, setSelectedMedicine] = useState<Medicine | null>(null);
  const [selectedCategory, setSelectedCategory] = useState('all');
  
  const t = translations[language];

  // Get medicines based on search or category
  const displayMedicines = searchQuery 
    ? searchMedicines(searchQuery)
    : getMedicinesByCategory(selectedCategory);

  // د debugging لپاره - ډیټابیس معلومات وښایه
  useEffect(() => {
    console.log('Total medicines:', fullMedicinesDatabase.length);
    console.log('Selected category:', selectedCategory);
    console.log('Display medicines:', displayMedicines.length);
    console.log('Categories:', medicineCategories);
  }, [selectedCategory, displayMedicines.length]);

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-violet-50 to-purple-50 pb-28 md:pb-8">
      {/* Header */}
      <div className="sticky top-0 z-40 backdrop-blur-xl bg-white/80 border-b border-white/20 shadow-lg">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center gap-4 mb-4">
            <Button variant="ghost" size="icon" onClick={onBack}>
              <ArrowLeft className="w-5 h-5" />
            </Button>
            <div className="flex-1">
              <h1 className="text-2xl bg-gradient-to-r from-purple-600 to-violet-600 bg-clip-text text-transparent">
                {language === 'ps' ? 'د درملو لارښود' : language === 'fa' ? 'راهنمای داروها' : 'Medicine Guide'}
              </h1>
              <p className="text-sm text-gray-600">
                {fullMedicinesDatabase.length}+ {language === 'ps' ? 'درمل موجود دي' : language === 'fa' ? 'دارو موجود است' : 'Medicines Available'}
              </p>
            </div>
          </div>

          {/* Search */}
          <div className="relative mb-4">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
            <Input
              type="text"
              placeholder={language === 'ps' ? 'د درمل لټون...' : language === 'fa' ? 'جستجوی دارو...' : 'Search medicine...'}
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10 bg-white/80 backdrop-blur-md border-white/20"
            />
          </div>

          {/* Categories */}
          <div className="overflow-x-auto pb-2">
            <div className="flex gap-2 min-w-max">
              {medicineCategories.map((cat) => (
                <button
                  key={cat.id}
                  onClick={() => {
                    setSelectedCategory(cat.id);
                    setSearchQuery('');
                  }}
                  className={`px-4 py-2 rounded-full text-sm whitespace-nowrap transition-all ${
                    selectedCategory === cat.id
                      ? 'bg-gradient-to-r from-purple-600 to-violet-600 text-white shadow-lg'
                      : 'bg-white/80 text-gray-700 hover:bg-white'
                  }`}
                >
                  {language === 'ps' ? cat.pashto : language === 'fa' ? cat.dari : cat.name}
                  {selectedCategory === cat.id && ` (${displayMedicines.length})`}
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="container mx-auto px-4 mt-6">
        <AdBanner type="medium" className="mb-6" />

        {/* Results Count */}
        <div className="mb-4 text-center">
          <p className="text-gray-600">
            {displayMedicines.length} {language === 'ps' ? 'درمل وموندل شول' : language === 'fa' ? 'دارو پیدا شد' : 'medicines found'}
          </p>
        </div>

        {/* Medicines Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {displayMedicines.map((medicine, index) => (
            <motion.div
              key={medicine.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: Math.min(index * 0.05, 1) }}
              className="relative group cursor-pointer"
              onClick={() => setSelectedMedicine(medicine)}
            >
              <div className="absolute inset-0 bg-gradient-to-br from-purple-500 to-violet-600 opacity-10 rounded-3xl blur-xl group-hover:blur-2xl transition-all" />
              <div className="relative bg-white/90 backdrop-blur-xl rounded-3xl p-6 border border-white/20 shadow-xl hover:shadow-2xl transition-all">
                {/* Medicine Image */}
                <div className="mb-4 rounded-2xl overflow-hidden h-40 bg-gradient-to-br from-purple-100 to-violet-100">
                  <img 
                    src={medicine.image} 
                    alt={medicine.name}
                    className="w-full h-full object-cover"
                  />
                </div>

                {/* Header */}
                <div className="flex items-start gap-3 mb-3">
                  <div className="w-12 h-12 bg-gradient-to-br from-purple-500 to-violet-600 rounded-xl flex items-center justify-center flex-shrink-0">
                    <Pill className="w-6 h-6 text-white" />
                  </div>
                  <div className="flex-1">
                    <h3 className="text-lg mb-1 line-clamp-1">{medicine.name}</h3>
                    <p className="text-sm text-gray-600 line-clamp-1">
                      {language === 'ps' ? medicine.namePashto : language === 'fa' ? medicine.nameDari : medicine.genericName}
                    </p>
                  </div>
                </div>

                {/* Info */}
                <div className="space-y-2 mb-4">
                  <div className="flex items-center gap-2 text-sm text-gray-600">
                    <Package className="w-4 h-4" />
                    <span>{medicine.type} • {medicine.dosage}</span>
                  </div>
                  <div className="flex items-center gap-2 text-sm text-gray-600">
                    <Info className="w-4 h-4" />
                    <span className="line-clamp-1">
                      {language === 'ps' ? medicine.descriptionPashto : language === 'fa' ? medicine.descriptionDari : medicine.description}
                    </span>
                  </div>
                </div>

                {/* Footer */}
                <div className="flex items-center justify-between pt-4 border-t border-gray-200">
                  <div className="flex items-center gap-2">
                    <DollarSign className="w-4 h-4 text-gray-600" />
                    <span className="bg-gradient-to-r from-purple-600 to-violet-600 bg-clip-text text-transparent font-medium">
                      {medicine.price}
                    </span>
                  </div>
                  {medicine.prescriptionRequired && (
                    <Badge variant="outline" className="text-xs">
                      {language === 'ps' ? 'نسخه' : language === 'fa' ? 'نسخه' : 'Rx'}
                    </Badge>
                  )}
                  {!medicine.inStock && (
                    <Badge variant="destructive" className="text-xs">
                      {language === 'ps' ? 'نشته' : language === 'fa' ? 'نیست' : 'Out'}
                    </Badge>
                  )}
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        {displayMedicines.length === 0 && (
          <div className="text-center py-12">
            <Pill className="w-16 h-16 mx-auto mb-4 text-gray-400" />
            <h3 className="text-xl mb-2">
              {language === 'ps' ? 'درمل ونه موندل شو' : language === 'fa' ? 'داروی پیدا نشد' : 'No medicines found'}
            </h3>
            <p className="text-gray-600">
              {language === 'ps' ? 'مهرباني وکړئ بل څه ولټوئ' : language === 'fa' ? 'لطفاً چیز دیگری جستجو کنید' : 'Please try another search'}
            </p>
          </div>
        )}

        <AdBanner type="large" className="mt-8" />

        {/* Medicine Detail Modal */}
        <AnimatePresence>
          {selectedMedicine && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm overflow-y-auto"
              onClick={() => setSelectedMedicine(null)}
            >
              <motion.div
                initial={{ scale: 0.9, opacity: 0, y: 20 }}
                animate={{ scale: 1, opacity: 1, y: 0 }}
                exit={{ scale: 0.9, opacity: 0, y: 20 }}
                className="relative bg-white rounded-3xl w-full max-w-3xl my-8 shadow-2xl"
                onClick={(e) => e.stopPropagation()}
              >
                {/* Close Button - Fixed at top right */}
                <button
                  className="absolute top-4 right-4 z-10 w-10 h-10 bg-red-500 hover:bg-red-600 text-white rounded-full flex items-center justify-center shadow-lg transition-all hover:scale-110"
                  onClick={() => setSelectedMedicine(null)}
                >
                  <X className="w-5 h-5" />
                </button>

                {/* Scrollable Content */}
                <div className="overflow-y-auto max-h-[85vh] p-6 md:p-8">
                  {/* Image */}
                  <div className="mb-6 rounded-2xl overflow-hidden h-64 bg-gradient-to-br from-purple-100 to-violet-100">
                    <img 
                      src={selectedMedicine.image} 
                      alt={selectedMedicine.name}
                      className="w-full h-full object-cover"
                    />
                  </div>

                  {/* Header */}
                  <div className="flex items-start gap-4 mb-6 pr-12">
                    <div className="w-16 h-16 bg-gradient-to-br from-purple-500 to-violet-600 rounded-2xl flex items-center justify-center flex-shrink-0 shadow-lg">
                      <Pill className="w-8 h-8 text-white" />
                    </div>
                    <div className="flex-1">
                      <h2 className="text-2xl md:text-3xl mb-2 font-bold text-gray-800">{selectedMedicine.name}</h2>
                      <p className="text-gray-600 mb-3 text-lg">
                        {language === 'ps' ? selectedMedicine.namePashto : language === 'fa' ? selectedMedicine.nameDari : selectedMedicine.genericName}
                      </p>
                      <div className="flex flex-wrap gap-2">
                        {selectedMedicine.prescriptionRequired && (
                          <Badge variant="outline" className="text-sm">
                            {language === 'ps' ? '⚕️ نسخې ته اړتیا' : language === 'fa' ? '⚕️ نیاز به نسخه' : '⚕️ Prescription Required'}
                          </Badge>
                        )}
                        {selectedMedicine.inStock ? (
                          <Badge className="bg-green-500 text-sm">
                            {language === 'ps' ? '✓ موجود' : language === 'fa' ? '✓ موجود' : '✓ In Stock'}
                          </Badge>
                        ) : (
                          <Badge variant="destructive" className="text-sm">
                            {language === 'ps' ? '✗ نشته' : language === 'fa' ? '✗ نیست' : '✗ Out of Stock'}
                          </Badge>
                        )}
                      </div>
                    </div>
                  </div>

                  {/* Details */}
                  <div className="space-y-6">
                    <div className="bg-purple-50 rounded-2xl p-5 border-l-4 border-purple-500">
                      <h3 className="flex items-center gap-2 mb-3 text-purple-700 font-semibold text-lg">
                        <Info className="w-5 h-5" />
                        {language === 'ps' ? 'تفصیل' : language === 'fa' ? 'توضیحات' : 'Description'}
                      </h3>
                      <p className="text-gray-700 leading-relaxed">
                        {language === 'ps' ? selectedMedicine.descriptionPashto : language === 'fa' ? selectedMedicine.descriptionDari : selectedMedicine.description}
                      </p>
                    </div>

                    <div className="bg-blue-50 rounded-2xl p-5 border-l-4 border-blue-500">
                      <h3 className="flex items-center gap-2 mb-3 text-blue-700 font-semibold text-lg">
                        <Package className="w-5 h-5" />
                        {language === 'ps' ? 'معلومات' : language === 'fa' ? 'اطلاعات' : 'Information'}
                      </h3>
                      <div className="space-y-3">
                        <div className="flex justify-between items-center">
                          <span className="text-gray-600 font-medium">{language === 'ps' ? 'ډول:' : language === 'fa' ? 'نوع:' : 'Type:'}</span>
                          <span className="text-gray-800 font-semibold">{selectedMedicine.type}</span>
                        </div>
                        <div className="flex justify-between items-center">
                          <span className="text-gray-600 font-medium">{language === 'ps' ? 'مقدار:' : language === 'fa' ? 'دوز:' : 'Dosage:'}</span>
                          <span className="text-gray-800 font-semibold">{selectedMedicine.dosage}</span>
                        </div>
                        <div className="flex justify-between items-center">
                          <span className="text-gray-600 font-medium">{language === 'ps' ? 'شرکت:' : language === 'fa' ? 'سازنده:' : 'Manufacturer:'}</span>
                          <span className="text-gray-800 font-semibold text-sm">{selectedMedicine.manufacturer}</span>
                        </div>
                        <div className="flex justify-between items-center">
                          <span className="text-gray-600 font-medium">{language === 'ps' ? 'بسته:' : language === 'fa' ? 'بسته:' : 'Pack Size:'}</span>
                          <span className="text-gray-800 font-semibold">{selectedMedicine.packSize}</span>
                        </div>
                      </div>
                    </div>

                    <div className="bg-green-50 rounded-2xl p-5 border-l-4 border-green-500">
                      <h3 className="flex items-center gap-2 mb-3 text-green-700 font-semibold text-lg">
                        <Pill className="w-5 h-5" />
                        {language === 'ps' ? 'استعمال' : language === 'fa' ? 'استفاده' : 'Usage'}
                      </h3>
                      <p className="text-gray-700 leading-relaxed">
                        {language === 'ps' ? selectedMedicine.usageDari : language === 'fa' ? selectedMedicine.usageDari : selectedMedicine.usage}
                      </p>
                    </div>

                    <div className="bg-orange-50 rounded-2xl p-5 border-l-4 border-orange-500">
                      <h3 className="flex items-center gap-2 mb-3 text-orange-700 font-semibold text-lg">
                        <AlertCircle className="w-5 h-5" />
                        {language === 'ps' ? 'ضمني اغیزې' : language === 'fa' ? 'عوارض جانبی' : 'Side Effects'}
                      </h3>
                      <ul className="space-y-2">
                        {selectedMedicine.sideEffects.map((effect, idx) => (
                          <li key={idx} className="flex items-start gap-2 text-gray-700">
                            <span className="text-orange-500 font-bold">•</span>
                            <span>{effect}</span>
                          </li>
                        ))}
                      </ul>
                    </div>

                    <div className="bg-red-50 rounded-2xl p-5 border-l-4 border-red-500">
                      <h3 className="flex items-center gap-2 mb-3 text-red-700 font-semibold text-lg">
                        <Shield className="w-5 h-5" />
                        {language === 'ps' ? 'احتیاطونه' : language === 'fa' ? 'احتیاط‌ها' : 'Contraindications'}
                      </h3>
                      <ul className="space-y-2">
                        {selectedMedicine.contraindications.map((contra, idx) => (
                          <li key={idx} className="flex items-start gap-2 text-gray-700">
                            <span className="text-red-500 font-bold">•</span>
                            <span>{contra}</span>
                          </li>
                        ))}
                      </ul>
                    </div>

                    <div className="bg-gray-50 rounded-2xl p-5 border-l-4 border-gray-500">
                      <h3 className="flex items-center gap-2 mb-3 text-gray-700 font-semibold text-lg">
                        <Calendar className="w-5 h-5" />
                        {language === 'ps' ? 'نور معلومات' : language === 'fa' ? 'سایر اطلاعات' : 'Other Information'}
                      </h3>
                      <div className="space-y-3">
                        <div>
                          <span className="text-gray-600 font-medium block mb-1">
                            {language === 'ps' ? 'ذخیره:' : language === 'fa' ? 'نگهداری:' : 'Storage:'}
                          </span>
                          <p className="text-gray-700">{selectedMedicine.storage}</p>
                        </div>
                        <div>
                          <span className="text-gray-600 font-medium block mb-1">
                            {language === 'ps' ? 'د ختمیدو نیټه:' : language === 'fa' ? 'تاریخ انقضا:' : 'Expiry Date:'}
                          </span>
                          <p className="text-gray-700">{selectedMedicine.expiryDate}</p>
                        </div>
                      </div>
                    </div>

                    {/* Price - Prominent */}
                    <div className="bg-gradient-to-br from-purple-500 to-violet-600 rounded-2xl p-6 text-white shadow-xl">
                      <div className="flex items-center justify-between">
                        <div>
                          <span className="text-purple-100 text-sm block mb-1">
                            {language === 'ps' ? 'قیمت:' : language === 'fa' ? 'قیمت:' : 'Price:'}
                          </span>
                          <span className="text-3xl md:text-4xl font-bold">
                            {selectedMedicine.price}
                          </span>
                        </div>
                        <DollarSign className="w-12 h-12 text-purple-200" />
                      </div>
                    </div>
                  </div>

                  {/* Bottom Close Button */}
                  <div className="mt-8 flex gap-3">
                    <Button 
                      className="flex-1 bg-gradient-to-r from-purple-600 to-violet-600 hover:from-purple-700 hover:to-violet-700 text-lg py-6 shadow-lg"
                      onClick={() => setSelectedMedicine(null)}
                    >
                      {language === 'ps' ? '✓ تړل' : language === 'fa' ? '✓ بستن' : '✓ Close'}
                    </Button>
                  </div>
                </div>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}