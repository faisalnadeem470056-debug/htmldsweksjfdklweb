import { useState, useEffect } from 'react';
import {
  Search, Star, MapPin, Phone, Calendar, ArrowLeft, Stethoscope, Award,
  Clock, Check, Filter, X, Heart, MessageCircle, Video, Mail, Users,
  GraduationCap, Languages, ChevronDown, ChevronUp, Shield, Crown,
  PhoneCall, MessageSquare, Briefcase, TrendingUp, Activity, Eye
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { AdBanner } from './AdBanner';
import { ImageWithFallback } from './figma/ImageWithFallback';

interface EnhancedDoctorsDirectoryProps {
  language: 'ps' | 'fa' | 'en';
  onBack: () => void;
}

interface Doctor {
  id: number;
  name: { ps: string; fa: string; en: string };
  specialty: { ps: string; fa: string; en: string };
  category: string;
  experience: number;
  rating: number;
  reviews: number;
  location: { ps: string; fa: string; en: string };
  phone: string;
  available: boolean;
  verified: boolean;
  image: string;
  patients: number;
  consultationFee: number;
  education: { ps: string; fa: string; en: string };
  languages: string[];
  workingHours: { ps: string; fa: string; en: string };
  about: { ps: string; fa: string; en: string };
  isPremium?: boolean;
}

const translations = {
  ps: {
    title: 'دوکتوران',
    subtitle: 'د تجربه کار او ماهر دوکتوران ومومئ',
    search: 'د دوکتور نوم یا تخصص لټون...',
    allCategories: 'ټول کټګورۍ',
    filter: 'فلټر',
    sortBy: 'ترتیب کول',
    rating: 'ریټنګ',
    experience: 'تجربه',
    name: 'نوم',
    verified: 'تایید شوی',
    available: 'شته',
    notAvailable: 'نشته',
    yearsExp: 'کاله تجربه',
    patients: 'ناروغان',
    reviews: 'بیاکتنې',
    consultationFee: 'د معاینې فیس',
    callNow: 'اوس زنګ ووهئ',
    bookAppointment: 'وخت ونیسئ',
    viewProfile: 'پروفایل وګورئ',
    languages: 'ژبې',
    education: 'زده کړې',
    location: 'موقعیت',
    noDoctors: 'هیڅ دوکتور و نه موندل شو',
    tryDifferent: 'د بل شي په لټون کې هڅه وکړئ',
    topRated: 'غوره ریټنګ',
    mostExperienced: 'ډیره تجربه',
    workingHours: 'د کار وختونه',
    about: 'په اړه',
    totalDoctors: 'ټول دوکتوران',
    online: 'آنلاین',
    offline: 'آفلاین',
    premium: 'Premium',
    afn: 'افغانۍ',
    categories: {
      all: 'ټول',
      cardiologist: 'زړه متخصص',
      pediatrician: 'ماشومانو متخصص',
      surgeon: 'جراح',
      gynecologist: 'ښځو متخصص',
      dentist: 'غاښونو متخصص',
      ophthalmologist: 'سترګو متخصص',
      dermatologist: 'پوستکي متخصص',
      neurologist: 'عصبي متخصص',
      orthopedic: 'هډوکو متخصص',
      ent: 'غوږ، پوزه، ستوني متخصص',
      psychiatrist: 'رواني متخصص',
      urologist: 'پیشاب متخصص',
    },
  },
  fa: {
    title: 'دکتران',
    subtitle: 'دکتران با تجربه و متخصص را پیدا کنید',
    search: 'جستجوی نام دکتر یا تخصص...',
    allCategories: 'همه دسته‌بندی‌ها',
    filter: 'فیلتر',
    sortBy: 'مرتب‌سازی',
    rating: 'امتیاز',
    experience: 'تجربه',
    name: 'نام',
    verified: 'تایید شده',
    available: 'در دسترس',
    notAvailable: 'غیر فعال',
    yearsExp: 'سال تجربه',
    patients: 'بیماران',
    reviews: 'بازخوردها',
    consultationFee: 'هزینه معاینه',
    callNow: 'تماس فوری',
    bookAppointment: 'نوبت بگیرید',
    viewProfile: 'مشاهده پروفایل',
    languages: 'زبان‌ها',
    education: 'تحصیلات',
    location: 'موقعیت',
    noDoctors: 'هیچ دکتری یافت نشد',
    tryDifferent: 'چیز دیگری را جستجو کنید',
    topRated: 'بهترین امتیاز',
    mostExperienced: 'بیشترین تجربه',
    workingHours: 'ساعات کاری',
    about: 'درباره',
    totalDoctors: 'کل دکتران',
    online: 'آنلاین',
    offline: 'آفلاین',
    premium: 'پریمیوم',
    afn: 'افغانی',
    categories: {
      all: 'همه',
      cardiologist: 'متخصص قلب',
      pediatrician: 'متخصص اطفال',
      surgeon: 'جراح',
      gynecologist: 'متخصص زنان',
      dentist: 'دندانپزشک',
      ophthalmologist: 'متخصص چشم',
      dermatologist: 'متخصص پوست',
      neurologist: 'متخصص اعصاب',
      orthopedic: 'متخصص استخوان',
      ent: 'متخصص گوش، حلق، بینی',
      psychiatrist: 'روانپزشک',
      urologist: 'متخصص کلیه',
    },
  },
  en: {
    title: 'Doctors',
    subtitle: 'Find experienced and specialist doctors',
    search: 'Search doctor name or specialty...',
    allCategories: 'All Categories',
    filter: 'Filter',
    sortBy: 'Sort By',
    rating: 'Rating',
    experience: 'Experience',
    name: 'Name',
    verified: 'Verified',
    available: 'Available',
    notAvailable: 'Not Available',
    yearsExp: 'Years Experience',
    patients: 'Patients',
    reviews: 'Reviews',
    consultationFee: 'Consultation Fee',
    callNow: 'Call Now',
    bookAppointment: 'Book Appointment',
    viewProfile: 'View Profile',
    languages: 'Languages',
    education: 'Education',
    location: 'Location',
    noDoctors: 'No doctors found',
    tryDifferent: 'Try searching for something else',
    topRated: 'Top Rated',
    mostExperienced: 'Most Experienced',
    workingHours: 'Working Hours',
    about: 'About',
    totalDoctors: 'Total Doctors',
    online: 'Online',
    offline: 'Offline',
    premium: 'Premium',
    afn: 'AFN',
    categories: {
      all: 'All',
      cardiologist: 'Cardiologist',
      pediatrician: 'Pediatrician',
      surgeon: 'Surgeon',
      gynecologist: 'Gynecologist',
      dentist: 'Dentist',
      ophthalmologist: 'Ophthalmologist',
      dermatologist: 'Dermatologist',
      neurologist: 'Neurologist',
      orthopedic: 'Orthopedic',
      ent: 'ENT Specialist',
      psychiatrist: 'Psychiatrist',
      urologist: 'Urologist',
    },
  },
};

export function EnhancedDoctorsDirectory({ language, onBack }: EnhancedDoctorsDirectoryProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [filteredDoctors, setFilteredDoctors] = useState<Doctor[]>([]);
  const [showFilters, setShowFilters] = useState(false);
  const [selectedDoctor, setSelectedDoctor] = useState<Doctor | null>(null);
  const [sortBy, setSortBy] = useState<'rating' | 'experience' | 'name'>('rating');
  const [expandedDoctors, setExpandedDoctors] = useState<{ [key: number]: boolean }>({});

  const t = translations[language];

  // د Sample Doctors
  const doctors: Doctor[] = [
    {
      id: 1,
      name: { ps: 'دوکتور احمد خان', fa: 'دکتر احمد خان', en: 'Dr. Ahmad Khan' },
      specialty: { ps: 'زړه متخصص', fa: 'متخصص قلب', en: 'Cardiologist' },
      category: 'cardiologist',
      experience: 15,
      rating: 4.9,
      reviews: 320,
      location: { ps: 'کابل، افغانستان', fa: 'کابل، افغانستان', en: 'Kabul, Afghanistan' },
      phone: '+93 799 123 456',
      available: true,
      verified: true,
      image: 'https://images.unsplash.com/photo-1612349317150-e413f6a5b16d?w=400',
      patients: 1500,
      consultationFee: 500,
      education: {
        ps: 'د کابل طبي پوهنتون، MBBS، MD',
        fa: 'دانشگاه طبی کابل، MBBS، MD',
        en: 'Kabul Medical University, MBBS, MD',
      },
      languages: ['پښتو', 'دری', 'English'],
      workingHours: {
        ps: 'د یکشنبې څخه پنجشنبې، 9 AM - 5 PM',
        fa: 'یکشنبه تا پنجشنبه، 9 صبح - 5 عصر',
        en: 'Sunday to Thursday, 9 AM - 5 PM',
      },
      about: {
        ps: 'د زړه په ناروغیو کې 15 کاله تجربه لرم. د عصري تخنیکونو په استعمال سره درملنه کوم.',
        fa: 'دارای 15 سال تجربه در بیماری‌های قلبی. درمان با استفاده از تکنیک‌های مدرن.',
        en: '15 years of experience in cardiac diseases. Treatment using modern techniques.',
      },
      isPremium: true,
    },
    {
      id: 2,
      name: { ps: 'دوکتور فاطمه احمدي', fa: 'دکتر فاطمه احمدی', en: 'Dr. Fatima Ahmadi' },
      specialty: { ps: 'ماشومانو متخصص', fa: 'متخصص اطفال', en: 'Pediatrician' },
      category: 'pediatrician',
      experience: 10,
      rating: 4.8,
      reviews: 250,
      location: { ps: 'مزار شریف، افغانستان', fa: 'مزار شریف، افغانستان', en: 'Mazar-e-Sharif, Afghanistan' },
      phone: '+93 799 234 567',
      available: true,
      verified: true,
      image: 'https://images.unsplash.com/photo-1594824476967-48c8b964273f?w=400',
      patients: 1200,
      consultationFee: 400,
      education: {
        ps: 'د ننګرهار طبي پوهنتون، MBBS، DCH',
        fa: 'دانشگاه طبی ننگرهار، MBBS، DCH',
        en: 'Nangarhar Medical University, MBBS, DCH',
      },
      languages: ['پښتو', 'دری', 'English'],
      workingHours: {
        ps: 'هره ورځ، 8 AM - 4 PM',
        fa: 'هر روز، 8 صبح - 4 عصر',
        en: 'Daily, 8 AM - 4 PM',
      },
      about: {
        ps: 'د ماشومانو روغتیا کې ماهره یم. د واکسینیشن او ودې په څارنه کې تخصص لرم.',
        fa: 'متخصص در سلامت کودکان. تخصص در واکسیناسیون و نظارت بر رشد.',
        en: 'Specialist in children\'s health. Expert in vaccination and growth monitoring.',
      },
      isPremium: false,
    },
    {
      id: 3,
      name: { ps: 'دوکتور محمد عثمان', fa: 'دکتر محمد عثمان', en: 'Dr. Mohammad Usman' },
      specialty: { ps: 'جراح', fa: 'جراح', en: 'Surgeon' },
      category: 'surgeon',
      experience: 20,
      rating: 4.9,
      reviews: 400,
      location: { ps: 'هرات، افغانستان', fa: 'هرات، افغانستان', en: 'Herat, Afghanistan' },
      phone: '+93 799 345 678',
      available: false,
      verified: true,
      image: 'https://images.unsplash.com/photo-1622253692010-333f2da6031d?w=400',
      patients: 2000,
      consultationFee: 800,
      education: {
        ps: 'د کابل طبي پوهنتون، MBBS، MS',
        fa: 'دانشگاه طبی کابل، MBBS، MS',
        en: 'Kabul Medical University, MBBS, MS',
      },
      languages: ['پښتو', 'دری', 'English', 'اردو'],
      workingHours: {
        ps: 'د یکشنبې څخه پنجشنبې، 10 AM - 6 PM',
        fa: 'یکشنبه تا پنجشنبه، 10 صبح - 6 عصر',
        en: 'Sunday to Thursday, 10 AM - 6 PM',
      },
      about: {
        ps: 'د جراحۍ په برخه کې 20 کاله تجربه لرم. په لاپاروسکوپیک سرجري کې ماهر یم.',
        fa: 'دارای 20 سال تجربه در جراحی. متخصص در جراحی لاپاروسکوپیک.',
        en: '20 years of experience in surgery. Expert in laparoscopic surgery.',
      },
      isPremium: true,
    },
    {
      id: 4,
      name: { ps: 'دوکتور زینب رحیمي', fa: 'دکتر زینب رحیمی', en: 'Dr. Zainab Rahimi' },
      specialty: { ps: 'غاښونو متخصص', fa: 'دندانپزشک', en: 'Dentist' },
      category: 'dentist',
      experience: 8,
      rating: 4.7,
      reviews: 180,
      location: { ps: 'کندهار، افغانستان', fa: 'کندهار، افغانستان', en: 'Kandahar, Afghanistan' },
      phone: '+93 799 456 789',
      available: true,
      verified: true,
      image: 'https://images.unsplash.com/photo-1559839734-2b71ea197ec2?w=400',
      patients: 800,
      consultationFee: 300,
      education: {
        ps: 'د کابل طبي پوهنتون، BDS، MDS',
        fa: 'دانشگاه طبی کابل، BDS، MDS',
        en: 'Kabul Medical University, BDS, MDS',
      },
      languages: ['پښتو', 'دری'],
      workingHours: {
        ps: 'د یکشنبې څخه جمعې، 9 AM - 3 PM',
        fa: 'یکشنبه تا جمعه، 9 صبح - 3 عصر',
        en: 'Sunday to Friday, 9 AM - 3 PM',
      },
      about: {
        ps: 'د غاښونو درملنه او تجمیلي کارونو کې تخصص لرم. د بې درد درملنې تخنیکونه استعمالوم.',
        fa: 'تخصص در درمان و زیبایی دندان. استفاده از تکنیک‌های درمان بدون درد.',
        en: 'Specialist in dental treatment and cosmetics. Using painless treatment techniques.',
      },
      isPremium: false,
    },
    {
      id: 5,
      name: { ps: 'دوکتور حسن حسیني', fa: 'دکتر حسن حسینی', en: 'Dr. Hassan Husseini' },
      specialty: { ps: 'سترګو متخصص', fa: 'متخصص چشم', en: 'Ophthalmologist' },
      category: 'ophthalmologist',
      experience: 12,
      rating: 4.8,
      reviews: 210,
      location: { ps: 'جلال آباد، افغانستان', fa: 'جلال‌آباد، افغانستان', en: 'Jalalabad, Afghanistan' },
      phone: '+93 799 567 890',
      available: true,
      verified: true,
      image: 'https://images.unsplash.com/photo-1537368910025-700350fe46c7?w=400',
      patients: 1000,
      consultationFee: 450,
      education: {
        ps: 'د ننګرهار طبي پوهنتون، MBBS، DO',
        fa: 'دانشگاه طبی ننگرهار، MBBS، DO',
        en: 'Nangarhar Medical University, MBBS, DO',
      },
      languages: ['پښتو', 'دری', 'English'],
      workingHours: {
        ps: 'د یکشنبې څخه پنجشنبې، 8 AM - 5 PM',
        fa: 'یکشنبه تا پنجشنبه، 8 صبح - 5 عصر',
        en: 'Sunday to Thursday, 8 AM - 5 PM',
      },
      about: {
        ps: 'د سترګو په ناروغیو کې ماهر یم. د کټریکټ سرجري او لیزر درملنه کوم.',
        fa: 'متخصص در بیماری‌های چشم. جراحی کاتاراکت و درمان لیزری.',
        en: 'Expert in eye diseases. Cataract surgery and laser treatment.',
      },
      isPremium: false,
    },
    {
      id: 6,
      name: { ps: 'دوکتور مریم نوري', fa: 'دکتر مریم نوری', en: 'Dr. Maryam Noori' },
      specialty: { ps: 'پوستکي متخصص', fa: 'متخصص پوست', en: 'Dermatologist' },
      category: 'dermatologist',
      experience: 9,
      rating: 4.7,
      reviews: 150,
      location: { ps: 'کابل، افغانستان', fa: 'کابل، افغانستان', en: 'Kabul, Afghanistan' },
      phone: '+93 799 678 901',
      available: true,
      verified: false,
      image: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=400',
      patients: 600,
      consultationFee: 350,
      education: {
        ps: 'د کابل طبي پوهنتون، MBBS، MD',
        fa: 'دانشگاه طبی کابل، MBBS، MD',
        en: 'Kabul Medical University, MBBS, MD',
      },
      languages: ['پښتو', 'دری', 'English'],
      workingHours: {
        ps: 'د یکشنبې څخه پنجشنبې، 10 AM - 4 PM',
        fa: 'یکشنبه تا پنجشنبه، 10 صبح - 4 عصر',
        en: 'Sunday to Thursday, 10 AM - 4 PM',
      },
      about: {
        ps: 'د پوستکي او ویښتو په ناروغیو کې تخصص لرم. د تجمیلي درملنې خدمتونه هم وړاندې کوم.',
        fa: 'تخصص در بیماری‌های پوست و مو. خدمات درمان زیبایی نیز ارائه می‌دهم.',
        en: 'Specialist in skin and hair diseases. Also providing cosmetic treatment services.',
      },
      isPremium: false,
    },
  ];

  useEffect(() => {
    filterDoctors();
  }, [searchQuery, selectedCategory, sortBy]);

  const filterDoctors = () => {
    let result = [...doctors];

    // Category filter
    if (selectedCategory !== 'all') {
      result = result.filter((doc) => doc.category === selectedCategory);
    }

    // Search filter
    if (searchQuery.trim()) {
      result = result.filter(
        (doc) =>
          doc.name[language].toLowerCase().includes(searchQuery.toLowerCase()) ||
          doc.specialty[language].toLowerCase().includes(searchQuery.toLowerCase()) ||
          doc.location[language].toLowerCase().includes(searchQuery.toLowerCase())
      );
    }

    // Sort
    if (sortBy === 'rating') {
      result.sort((a, b) => b.rating - a.rating);
    } else if (sortBy === 'experience') {
      result.sort((a, b) => b.experience - a.experience);
    } else if (sortBy === 'name') {
      result.sort((a, b) => a.name[language].localeCompare(b.name[language]));
    }

    setFilteredDoctors(result);
  };

  // د phone call function
  const handleCallDoctor = (phone: string, doctorName: string) => {
    // د phone call
    window.location.href = `tel:${phone}`;
  };

  const toggleDoctorExpand = (doctorId: number) => {
    setExpandedDoctors({
      ...expandedDoctors,
      [doctorId]: !expandedDoctors[doctorId],
    });
  };

  const categories = Object.keys(t.categories).map((key) => ({
    id: key,
    name: t.categories[key as keyof typeof t.categories],
  }));

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50 pb-28 md:pb-8">
      {/* Header */}
      <div className="bg-gradient-to-r from-blue-600 via-indigo-600 to-purple-600 text-white py-8">
        <div className="container mx-auto px-4">
          <div className="flex items-center gap-4 mb-4">
            <Button
              onClick={onBack}
              variant="ghost"
              size="icon"
              className="text-white hover:bg-white/20"
            >
              <ArrowLeft className="w-6 h-6" />
            </Button>
            <div className="flex-1">
              <h1 className="text-3xl mb-1">{t.title}</h1>
              <p className="text-blue-100">{t.subtitle}</p>
            </div>
            <div className="bg-white/20 backdrop-blur-xl rounded-2xl px-4 py-2">
              <div className="text-2xl font-bold">{doctors.length}</div>
              <div className="text-xs">{t.totalDoctors}</div>
            </div>
          </div>

          {/* Search Bar */}
          <div className="relative">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
            <Input
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder={t.search}
              className="pl-12 pr-4 py-6 text-lg bg-white/95 backdrop-blur-xl border-0 shadow-xl"
            />
          </div>
        </div>
      </div>

      {/* Categories Tabs */}
      <div className="bg-white/90 backdrop-blur-xl border-b border-gray-200 sticky top-0 z-30 shadow-md">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-hide">
            {categories.map((category) => (
              <button
                key={category.id}
                onClick={() => setSelectedCategory(category.id)}
                className={`px-4 py-2 rounded-full whitespace-nowrap transition-all ${
                  selectedCategory === category.id
                    ? 'bg-gradient-to-r from-blue-600 to-purple-600 text-white shadow-lg scale-105'
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                }`}
              >
                {category.name}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Sort & Filter Bar */}
      <div className="container mx-auto px-4 py-4">
        <div className="flex items-center justify-between gap-4 bg-white/90 backdrop-blur-xl rounded-2xl p-4 shadow-lg">
          <div className="flex items-center gap-2">
            <Stethoscope className="w-5 h-5 text-blue-600" />
            <span className="font-bold text-gray-700">
              {filteredDoctors.length} {language === 'ps' ? 'دوکتوران' : language === 'fa' ? 'دکتر' : 'Doctors'}
            </span>
          </div>

          <div className="flex items-center gap-2">
            <span className="text-sm text-gray-600">{t.sortBy}:</span>
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value as any)}
              className="border border-gray-300 rounded-lg px-3 py-2 text-sm"
            >
              <option value="rating">{t.rating}</option>
              <option value="experience">{t.experience}</option>
              <option value="name">{t.name}</option>
            </select>
          </div>
        </div>
      </div>

      {/* AdMob Banner */}
      <div className="container mx-auto px-4 mb-6">
        <AdBanner type="large" />
      </div>

      {/* Doctors List */}
      <div className="container mx-auto px-4">
        {filteredDoctors.length === 0 ? (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-white/90 backdrop-blur-xl rounded-3xl p-12 text-center shadow-xl"
          >
            <Stethoscope className="w-16 h-16 text-gray-400 mx-auto mb-4" />
            <h3 className="text-xl mb-2 text-gray-700">{t.noDoctors}</h3>
            <p className="text-gray-600">{t.tryDifferent}</p>
          </motion.div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredDoctors.map((doctor, index) => (
              <motion.div
                key={doctor.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                className="bg-white/90 backdrop-blur-xl rounded-3xl overflow-hidden shadow-xl hover:shadow-2xl transition-all border border-white/50"
              >
                {/* Doctor Image & Status */}
                <div className="relative h-48 bg-gradient-to-br from-blue-500 to-purple-600">
                  <ImageWithFallback
                    src={doctor.image}
                    alt={doctor.name[language]}
                    className="w-full h-full object-cover"
                  />
                  
                  {/* Badges */}
                  <div className="absolute top-3 left-3 flex flex-col gap-2">
                    {doctor.verified && (
                      <span className="bg-blue-500 text-white px-3 py-1 rounded-full text-xs flex items-center gap-1 shadow-lg">
                        <Check className="w-3 h-3" />
                        {t.verified}
                      </span>
                    )}
                    {doctor.isPremium && (
                      <span className="bg-gradient-to-r from-yellow-400 to-orange-500 text-white px-3 py-1 rounded-full text-xs flex items-center gap-1 shadow-lg">
                        <Crown className="w-3 h-3" />
                        {t.premium}
                      </span>
                    )}
                  </div>

                  {/* Availability Status */}
                  <div className="absolute top-3 right-3">
                    <span
                      className={`px-3 py-1 rounded-full text-xs font-bold flex items-center gap-1 shadow-lg ${
                        doctor.available
                          ? 'bg-green-500 text-white'
                          : 'bg-gray-500 text-white'
                      }`}
                    >
                      <div
                        className={`w-2 h-2 rounded-full ${
                          doctor.available ? 'bg-white animate-pulse' : 'bg-gray-300'
                        }`}
                      />
                      {doctor.available ? t.online : t.offline}
                    </span>
                  </div>

                  {/* Rating */}
                  <div className="absolute bottom-3 right-3 bg-white/95 backdrop-blur-xl rounded-full px-3 py-1 flex items-center gap-1 shadow-lg">
                    <Star className="w-4 h-4 text-yellow-500 fill-yellow-500" />
                    <span className="font-bold">{doctor.rating}</span>
                    <span className="text-xs text-gray-600">({doctor.reviews})</span>
                  </div>
                </div>

                {/* Doctor Info */}
                <div className="p-6">
                  <h3 className="text-xl font-bold mb-1">{doctor.name[language]}</h3>
                  <p className="text-blue-600 mb-3">{doctor.specialty[language]}</p>

                  <div className="grid grid-cols-2 gap-3 mb-4">
                    <div className="bg-blue-50 rounded-xl p-3">
                      <div className="flex items-center gap-2 mb-1">
                        <Briefcase className="w-4 h-4 text-blue-600" />
                        <span className="text-xs text-gray-600">{t.experience}</span>
                      </div>
                      <div className="font-bold text-blue-600">{doctor.experience} {t.yearsExp}</div>
                    </div>

                    <div className="bg-purple-50 rounded-xl p-3">
                      <div className="flex items-center gap-2 mb-1">
                        <Users className="w-4 h-4 text-purple-600" />
                        <span className="text-xs text-gray-600">{t.patients}</span>
                      </div>
                      <div className="font-bold text-purple-600">{doctor.patients}+</div>
                    </div>
                  </div>

                  <div className="space-y-2 mb-4">
                    <div className="flex items-center gap-2 text-sm text-gray-600">
                      <MapPin className="w-4 h-4 text-gray-400" />
                      <span>{doctor.location[language]}</span>
                    </div>

                    <div className="flex items-center gap-2 text-sm text-gray-600">
                      <Languages className="w-4 h-4 text-gray-400" />
                      <span>{doctor.languages.join(', ')}</span>
                    </div>

                    <div className="flex items-center gap-2 text-sm">
                      <Award className="w-4 h-4 text-green-600" />
                      <span className="font-bold text-green-600">
                        {doctor.consultationFee} {t.afn}
                      </span>
                    </div>
                  </div>

                  {/* Expanded Details */}
                  <AnimatePresence>
                    {expandedDoctors[doctor.id] && (
                      <motion.div
                        initial={{ height: 0, opacity: 0 }}
                        animate={{ height: 'auto', opacity: 1 }}
                        exit={{ height: 0, opacity: 0 }}
                        className="space-y-3 mb-4 pt-4 border-t"
                      >
                        <div>
                          <div className="flex items-center gap-2 mb-2">
                            <GraduationCap className="w-4 h-4 text-blue-600" />
                            <span className="font-bold text-sm">{t.education}</span>
                          </div>
                          <p className="text-xs text-gray-600 pl-6">{doctor.education[language]}</p>
                        </div>

                        <div>
                          <div className="flex items-center gap-2 mb-2">
                            <Clock className="w-4 h-4 text-green-600" />
                            <span className="font-bold text-sm">{t.workingHours}</span>
                          </div>
                          <p className="text-xs text-gray-600 pl-6">{doctor.workingHours[language]}</p>
                        </div>

                        <div>
                          <div className="flex items-center gap-2 mb-2">
                            <Eye className="w-4 h-4 text-purple-600" />
                            <span className="font-bold text-sm">{t.about}</span>
                          </div>
                          <p className="text-xs text-gray-600 pl-6" dir={language === 'en' ? 'ltr' : 'rtl'}>
                            {doctor.about[language]}
                          </p>
                        </div>
                      </motion.div>
                    )}
                  </AnimatePresence>

                  {/* Action Buttons */}
                  <div className="space-y-2">
                    {/* Call Now Button - د ټولو لپاره */}
                    <Button
                      onClick={() => handleCallDoctor(doctor.phone, doctor.name[language])}
                      className="w-full bg-gradient-to-r from-green-500 to-emerald-600 hover:from-green-600 hover:to-emerald-700 text-white shadow-lg"
                    >
                      <PhoneCall className="w-4 h-4 mr-2" />
                      {t.callNow}
                    </Button>

                    <div className="grid grid-cols-2 gap-2">
                      <Button
                        variant="outline"
                        className="border-blue-200 text-blue-600 hover:bg-blue-50"
                      >
                        <Calendar className="w-4 h-4 mr-2" />
                        {language === 'ps' ? 'وخت' : language === 'fa' ? 'نوبت' : 'Book'}
                      </Button>

                      <Button
                        onClick={() => toggleDoctorExpand(doctor.id)}
                        variant="outline"
                        className="border-purple-200 text-purple-600 hover:bg-purple-50"
                      >
                        {expandedDoctors[doctor.id] ? (
                          <>
                            <ChevronUp className="w-4 h-4 mr-2" />
                            {language === 'ps' ? 'لږ' : language === 'fa' ? 'کمتر' : 'Less'}
                          </>
                        ) : (
                          <>
                            <ChevronDown className="w-4 h-4 mr-2" />
                            {language === 'ps' ? 'نور' : language === 'fa' ? 'بیشتر' : 'More'}
                          </>
                        )}
                      </Button>
                    </div>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        )}
      </div>

      {/* AdMob Banner */}
      <div className="container mx-auto px-4 mt-8">
        <AdBanner type="medium" />
      </div>
    </div>
  );
}
