import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Badge } from "./ui/badge";
import { 
  Activity, 
  Heart,
  Droplets,
  Footprints,
  Moon,
  TrendingUp,
  TrendingDown,
  Minus,
  Sparkles,
  Calendar
} from "lucide-react";
import { LineChart, Line, BarChart, Bar, AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from "recharts";

// Mock data for charts
const bloodPressureData = [
  { date: "Nov 1", systolic: 120, diastolic: 80 },
  { date: "Nov 3", systolic: 125, diastolic: 82 },
  { date: "Nov 5", systolic: 118, diastolic: 78 },
  { date: "Nov 7", systolic: 122, diastolic: 81 },
  { date: "Nov 9", systolic: 119, diastolic: 79 },
  { date: "Nov 11", systolic: 121, diastolic: 80 },
  { date: "Nov 13", systolic: 123, diastolic: 82 }
];

const heartRateData = [
  { time: "6 AM", bpm: 68 },
  { time: "9 AM", bpm: 72 },
  { time: "12 PM", bpm: 85 },
  { time: "3 PM", bpm: 78 },
  { time: "6 PM", bpm: 75 },
  { time: "9 PM", bpm: 70 },
  { time: "12 AM", bpm: 65 }
];

const stepsData = [
  { day: "Mon", steps: 8500 },
  { day: "Tue", steps: 9200 },
  { day: "Wed", steps: 7800 },
  { day: "Thu", steps: 10500 },
  { day: "Fri", steps: 9800 },
  { day: "Sat", steps: 12000 },
  { day: "Sun", steps: 8900 }
];

const waterIntakeData = [
  { day: "Mon", glasses: 6 },
  { day: "Tue", glasses: 8 },
  { day: "Wed", glasses: 7 },
  { day: "Thu", glasses: 9 },
  { day: "Fri", glasses: 8 },
  { day: "Sat", glasses: 10 },
  { day: "Sun", glasses: 7 }
];

const sleepData = [
  { day: "Mon", hours: 7.5 },
  { day: "Tue", hours: 6.5 },
  { day: "Wed", hours: 8 },
  { day: "Thu", hours: 7 },
  { day: "Fri", hours: 6 },
  { day: "Sat", hours: 9 },
  { day: "Sun", hours: 8.5 }
];

const weightData = [
  { date: "Week 1", weight: 75 },
  { date: "Week 2", weight: 74.5 },
  { date: "Week 3", weight: 74.8 },
  { date: "Week 4", weight: 74.2 }
];

interface HealthMetric {
  title: string;
  titleDari: string;
  value: string;
  unit: string;
  change: number;
  status: "good" | "warning" | "danger";
  icon: any;
  color: string;
}

const metrics: HealthMetric[] = [
  {
    title: "Blood Pressure",
    titleDari: "د وینې فشار",
    value: "121/80",
    unit: "mmHg",
    change: -2,
    status: "good",
    icon: Activity,
    color: "from-blue-500 to-cyan-500"
  },
  {
    title: "Heart Rate",
    titleDari: "د زړه ضربان",
    value: "72",
    unit: "bpm",
    change: 0,
    status: "good",
    icon: Heart,
    color: "from-red-500 to-pink-500"
  },
  {
    title: "Steps Today",
    titleDari: "د نن ورځې قدمونه",
    value: "8,900",
    unit: "steps",
    change: 12,
    status: "good",
    icon: Footprints,
    color: "from-emerald-500 to-teal-500"
  },
  {
    title: "Water Intake",
    titleDari: "د اوبو مقدار",
    value: "7",
    unit: "glasses",
    change: -1,
    status: "warning",
    icon: Droplets,
    color: "from-cyan-500 to-blue-500"
  },
  {
    title: "Sleep",
    titleDari: "خوب",
    value: "7.5",
    unit: "hours",
    change: 0.5,
    status: "good",
    icon: Moon,
    color: "from-indigo-500 to-purple-500"
  },
  {
    title: "Weight",
    titleDari: "وزن",
    value: "74.2",
    unit: "kg",
    change: -0.8,
    status: "good",
    icon: Activity,
    color: "from-purple-500 to-pink-500"
  }
];

export function HealthDashboard() {
  return (
    <section className="py-16 md:py-24 bg-gradient-to-b from-white via-blue-50/30 to-white relative overflow-hidden min-h-screen">
      {/* Background decoration */}
      <div className="absolute top-0 left-0 w-[500px] h-[500px] bg-gradient-to-br from-blue-100/50 to-cyan-100/50 rounded-full blur-3xl animate-float"></div>
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        {/* Header */}
        <div className="text-center mb-12 md:mb-16 space-y-4">
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-blue-100 to-cyan-100 rounded-full">
            <Sparkles className="w-4 h-4 text-blue-600 animate-pulse-glow" />
            <span className="text-blue-700 text-sm uppercase tracking-wider">Health Analytics</span>
          </div>
          <h2 className="text-4xl md:text-6xl">
            <span className="bg-gradient-to-r from-blue-600 via-cyan-600 to-teal-600 bg-clip-text text-transparent">
              Health Dashboard
            </span>
          </h2>
          <p className="text-gray-600 max-w-2xl mx-auto text-lg">
            د روغتیا ډشبورډ - Track your health metrics and trends
          </p>
          <div className="flex items-center justify-center gap-2 text-sm text-gray-600">
            <Calendar className="w-4 h-4" />
            <span>Last updated: November 15, 2025</span>
          </div>
        </div>

        {/* Quick Metrics Grid */}
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4 mb-12">
          {metrics.map((metric, index) => (
            <Card
              key={index}
              className="hover-lift border-0 shadow-lg overflow-hidden"
              style={{ animationDelay: `${index * 50}ms` }}
            >
              <div className={`h-1 bg-gradient-to-r ${metric.color}`}></div>
              <CardContent className="p-4">
                <div className="flex items-start justify-between mb-2">
                  <div className={`p-2 bg-gradient-to-br ${metric.color} rounded-lg`}>
                    <metric.icon className="w-4 h-4 text-white" />
                  </div>
                  {metric.change !== 0 && (
                    <Badge className={
                      metric.change > 0 && metric.status === "good" ? "bg-green-100 text-green-700" :
                      metric.change < 0 && metric.status === "good" ? "bg-green-100 text-green-700" :
                      "bg-amber-100 text-amber-700"
                    }>
                      {metric.change > 0 ? <TrendingUp className="w-3 h-3 mr-1" /> : 
                       metric.change < 0 ? <TrendingDown className="w-3 h-3 mr-1" /> :
                       <Minus className="w-3 h-3 mr-1" />}
                      {Math.abs(metric.change)}
                    </Badge>
                  )}
                </div>
                <p className="text-xs text-gray-600 mb-1">{metric.title}</p>
                <p className="text-xs text-gray-500 mb-2">{metric.titleDari}</p>
                <div className="flex items-baseline gap-1">
                  <span className="text-2xl">{metric.value}</span>
                  <span className="text-xs text-gray-500">{metric.unit}</span>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Charts Section */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
          {/* Blood Pressure Chart */}
          <Card className="hover-lift border-0 shadow-lg">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Activity className="w-5 h-5 text-blue-600" />
                Blood Pressure Trend - د وینې فشار رجحان
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={250}>
                <LineChart data={bloodPressureData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                  <XAxis dataKey="date" stroke="#888" fontSize={12} />
                  <YAxis stroke="#888" fontSize={12} />
                  <Tooltip 
                    contentStyle={{ 
                      backgroundColor: 'rgba(255, 255, 255, 0.95)', 
                      border: 'none', 
                      borderRadius: '8px',
                      boxShadow: '0 4px 6px rgba(0,0,0,0.1)'
                    }}
                  />
                  <Legend />
                  <Line 
                    type="monotone" 
                    dataKey="systolic" 
                    stroke="#3b82f6" 
                    strokeWidth={2}
                    name="Systolic"
                  />
                  <Line 
                    type="monotone" 
                    dataKey="diastolic" 
                    stroke="#06b6d4" 
                    strokeWidth={2}
                    name="Diastolic"
                  />
                </LineChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          {/* Heart Rate Chart */}
          <Card className="hover-lift border-0 shadow-lg">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Heart className="w-5 h-5 text-red-600" />
                Heart Rate Today - د نن ورځې زړه ضربان
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={250}>
                <AreaChart data={heartRateData}>
                  <defs>
                    <linearGradient id="heartGradient" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#ef4444" stopOpacity={0.3}/>
                      <stop offset="95%" stopColor="#ef4444" stopOpacity={0}/>
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                  <XAxis dataKey="time" stroke="#888" fontSize={12} />
                  <YAxis stroke="#888" fontSize={12} domain={[60, 90]} />
                  <Tooltip 
                    contentStyle={{ 
                      backgroundColor: 'rgba(255, 255, 255, 0.95)', 
                      border: 'none', 
                      borderRadius: '8px',
                      boxShadow: '0 4px 6px rgba(0,0,0,0.1)'
                    }}
                  />
                  <Area 
                    type="monotone" 
                    dataKey="bpm" 
                    stroke="#ef4444" 
                    strokeWidth={2}
                    fillOpacity={1}
                    fill="url(#heartGradient)"
                  />
                </AreaChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          {/* Steps Chart */}
          <Card className="hover-lift border-0 shadow-lg">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Footprints className="w-5 h-5 text-emerald-600" />
                Weekly Steps - اونیزې قدمونه
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={250}>
                <BarChart data={stepsData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                  <XAxis dataKey="day" stroke="#888" fontSize={12} />
                  <YAxis stroke="#888" fontSize={12} />
                  <Tooltip 
                    contentStyle={{ 
                      backgroundColor: 'rgba(255, 255, 255, 0.95)', 
                      border: 'none', 
                      borderRadius: '8px',
                      boxShadow: '0 4px 6px rgba(0,0,0,0.1)'
                    }}
                  />
                  <Bar 
                    dataKey="steps" 
                    fill="url(#stepsGradient)"
                    radius={[8, 8, 0, 0]}
                  />
                  <defs>
                    <linearGradient id="stepsGradient" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="0%" stopColor="#10b981" />
                      <stop offset="100%" stopColor="#14b8a6" />
                    </linearGradient>
                  </defs>
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          {/* Water Intake Chart */}
          <Card className="hover-lift border-0 shadow-lg">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Droplets className="w-5 h-5 text-cyan-600" />
                Water Intake - د اوبو مقدار
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={250}>
                <BarChart data={waterIntakeData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                  <XAxis dataKey="day" stroke="#888" fontSize={12} />
                  <YAxis stroke="#888" fontSize={12} domain={[0, 10]} />
                  <Tooltip 
                    contentStyle={{ 
                      backgroundColor: 'rgba(255, 255, 255, 0.95)', 
                      border: 'none', 
                      borderRadius: '8px',
                      boxShadow: '0 4px 6px rgba(0,0,0,0.1)'
                    }}
                  />
                  <Bar 
                    dataKey="glasses" 
                    fill="url(#waterGradient)"
                    radius={[8, 8, 0, 0]}
                  />
                  <defs>
                    <linearGradient id="waterGradient" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="0%" stopColor="#06b6d4" />
                      <stop offset="100%" stopColor="#3b82f6" />
                    </linearGradient>
                  </defs>
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </div>

        {/* Sleep and Weight Charts */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Sleep Chart */}
          <Card className="hover-lift border-0 shadow-lg">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Moon className="w-5 h-5 text-indigo-600" />
                Sleep Pattern - د خوب نمونه
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={250}>
                <AreaChart data={sleepData}>
                  <defs>
                    <linearGradient id="sleepGradient" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#6366f1" stopOpacity={0.3}/>
                      <stop offset="95%" stopColor="#6366f1" stopOpacity={0}/>
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                  <XAxis dataKey="day" stroke="#888" fontSize={12} />
                  <YAxis stroke="#888" fontSize={12} domain={[0, 10]} />
                  <Tooltip 
                    contentStyle={{ 
                      backgroundColor: 'rgba(255, 255, 255, 0.95)', 
                      border: 'none', 
                      borderRadius: '8px',
                      boxShadow: '0 4px 6px rgba(0,0,0,0.1)'
                    }}
                  />
                  <Area 
                    type="monotone" 
                    dataKey="hours" 
                    stroke="#6366f1" 
                    strokeWidth={2}
                    fillOpacity={1}
                    fill="url(#sleepGradient)"
                  />
                </AreaChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          {/* Weight Chart */}
          <Card className="hover-lift border-0 shadow-lg">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Activity className="w-5 h-5 text-purple-600" />
                Weight Progress - د وزن پرمختګ
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={250}>
                <LineChart data={weightData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                  <XAxis dataKey="date" stroke="#888" fontSize={12} />
                  <YAxis stroke="#888" fontSize={12} domain={[73, 76]} />
                  <Tooltip 
                    contentStyle={{ 
                      backgroundColor: 'rgba(255, 255, 255, 0.95)', 
                      border: 'none', 
                      borderRadius: '8px',
                      boxShadow: '0 4px 6px rgba(0,0,0,0.1)'
                    }}
                  />
                  <Line 
                    type="monotone" 
                    dataKey="weight" 
                    stroke="#a855f7" 
                    strokeWidth={3}
                    dot={{ fill: '#a855f7', strokeWidth: 2, r: 4 }}
                  />
                </LineChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </div>
      </div>
    </section>
  );
}

export default HealthDashboard;
