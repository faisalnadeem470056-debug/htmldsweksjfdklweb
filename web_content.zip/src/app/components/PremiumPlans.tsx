import { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { X, Crown, Check, Star, Zap, Shield, Heart, Sparkles, TrendingUp, Award, Lock, Unlock, Smartphone } from 'lucide-react';
import { Button } from './ui/button';
import { premiumManager } from '../utils/PremiumManager';
import { Plans } from '../config/premium.config';
import { PaymentGateway } from './PaymentGateway';

interface PremiumPlansProps {
  language: 'ps' | 'fa' | 'en';
  onBack: () => void;
  currentUserId?: string;
}

const translations = {
  ps: {
    title: 'پریمیم پلانونه',
    subtitle: 'خپل روغتیا تجربه لوړه کړئ',
    currentPlan: 'ستاسو اوسنی پلان',
    upgrade: 'اپګریډ کړئ',
    choosePlan: 'پلان غوره کړئ',
    popular: 'مشهور',
    recommended: 'وړاندیز شوی',
    free: 'وړیا',
    monthly: 'میاشتنی',
    yearly: 'کلنی',
    save: 'سپما وکړئ',
    features: 'ځانګړتیاوې',
    perMonth: '/میاشت',
    perYear: '/کال',
    currentlyActive: 'فعال',
    subscribe: 'ګډون وکړئ',
    comparePlans: 'پلانونه پرتله کړئ',
    freeFeatures: {
      title: 'وړیا پلان',
      feature1: 'لومړني روغتیا مشورې',
      feature2: 'د دوکتورانو لست لیدل',
      feature3: 'د درملو لومړني معلومات',
      feature4: 'د روغتونونو لست',
      feature5: 'د لومړنیو مرستو لارښود',
      feature6: 'اساسي روغتیا لارښود',
    },
    premiumFeatures: {
      title: 'پریمیم ځانګړتیاوې',
      feature1: '🩺 د دوکتورانو بشپړ معلومات',
      feature2: '💊 د 1500+ دواګانو بشپړ ډیټابیس',
      feature3: '🤖 AI روغتیا چټ (نامحدود)',
      feature4: '📚 د روغتیا بشپړ کتابتون',
      feature5: '⚡ بې اعلاناتو تجربه',
      feature6: '🎯 شخصي روغتیا پلان',
      feature7: '📊 د روغتیا پرمختګ ټریکنګ',
      feature8: '🔔 د یادونې خدمات',
      feature9: '🏥 د ډاکټر نوبت آنلاین',
      feature10: '💬 د ډاکټرانو سره مستقیم چټ',
      feature11: '📱 لومړی ملاتړ او مرسته',
      feature12: '🎁 د ځانګړو تخفیفونو لاسرسی',
    },
    monthlyPlan: {
      title: 'میاشتنی پریمیم',
      price: '200',
      currency: 'افغانۍ',
      description: 'ټولې پریمیم ځانګړتیاوې د یوې میاشتې لپاره',
    },
    yearlyPlan: {
      title: 'کلنی پریمیم',
      price: '2000',
      currency: 'افغانۍ',
      description: 'د کال لپاره بشپړ لاسرسی - 400 افغانۍ سپما',
      savings: '17% سپما',
    },
    benefits: 'د پریمیم ګټې',
    benefit1: 'بې محدودیت لاسرسی',
    benefit2: 'بې اعلاناتو تجربه',
    benefit3: 'لومړی ملاتړ',
    benefit4: 'نوې ځانګړتیاوې لومړی',
    whyPremium: 'ولې پریمیم؟',
    whyReason1: 'د روغتیا بشپړ معلومات',
    whyReason2: 'د AI مصنوعي هوښیارتیا سره مشوره',
    whyReason3: 'د ډاکټرانو سره مستقیم اړیکه',
    whyReason4: 'د روغتیا پرمختګ څارنه',
    guarantee: '30 ورځې د پیسو بیرته ورکولو تضمین',
    securePayment: 'خوندي تادیه',
  },
  fa: {
    title: 'پلان‌های پریمیم',
    subtitle: 'تجربه سلامتی خود را ارتقا دهید',
    currentPlan: 'پلان فعلی شما',
    upgrade: 'ارتقا دهید',
    choosePlan: 'پلان انتخاب کنید',
    popular: 'محبوب',
    recommended: 'توصیه شده',
    free: 'رایگان',
    monthly: 'ماهانه',
    yearly: 'سالانه',
    save: 'صرفه‌جویی',
    features: 'ویژگی‌ها',
    perMonth: '/ماه',
    perYear: '/سال',
    currentlyActive: 'فعال',
    subscribe: 'اشتراک',
    comparePlans: 'مقایسه پلان‌ها',
    freeFeatures: {
      title: 'پلان رایگان',
      feature1: 'مشاوره‌های اولیه سلامتی',
      feature2: 'مشاهده لیست داکتران',
      feature3: 'اطلاعات اولیه دواها',
      feature4: 'لیست شفاخانه‌ها',
      feature5: 'راهنمای کمک‌های اولیه',
      feature6: 'راهنمای اساسی سلامت',
    },
    premiumFeatures: {
      title: 'ویژگی‌های پریمیم',
      feature1: '🩺 اطلاعات کامل داکتران',
      feature2: '💊 پایگاه داده کامل 1500+ دوا',
      feature3: '🤖 چت AI سلامتی (نامحدود)',
      feature4: '📚 کتابخانه کامل سلامتی',
      feature5: '⚡ تجربه بدون اعلانات',
      feature6: '🎯 برنامه شخصی سلامتی',
      feature7: '📊 پیگیری پیشرفت سلامتی',
      feature8: '🔔 خدمات یادآوری',
      feature9: '🏥 نوبت آنلاین داکتر',
      feature10: '💬 چت مستقیم با داکتران',
      feature11: '📱 پشتیبانی اولویت',
      feature12: '🎁 دسترسی به تخفیف‌های ویژه',
    },
    monthlyPlan: {
      title: 'پریمیم ماهانه',
      price: '200',
      currency: 'افغانی',
      description: 'تمام ویژگی‌های پریمیم برای یک ماه',
    },
    yearlyPlan: {
      title: 'پریمیم سالانه',
      price: '2000',
      currency: 'افغانی',
      description: 'دسترسی کامل برای یک سال - 400 افغانی صرفه‌جویی',
      savings: '17% صرفه‌جویی',
    },
    benefits: 'مزایای پریمیم',
    benefit1: 'دسترسی نامحدود',
    benefit2: 'تجربه بدون اعلانات',
    benefit3: 'پشتیبانی اولویت',
    benefit4: 'ویژگی‌های جدید اول',
    whyPremium: 'چرا پریمیم؟',
    whyReason1: 'اطلاعات کامل سلامتی',
    whyReason2: 'مشاوره با AI',
    whyReason3: 'ارتباط مستقیم با داکتران',
    whyReason4: 'نظارت پیشرفت سلامتی',
    guarantee: '30 روز ضمانت بازگشت پول',
    securePayment: 'پرداخت امن',
  },
  en: {
    title: 'Premium Plans',
    subtitle: 'Elevate Your Health Experience',
    currentPlan: 'Your Current Plan',
    upgrade: 'Upgrade',
    choosePlan: 'Choose Plan',
    popular: 'Popular',
    recommended: 'Recommended',
    free: 'Free',
    monthly: 'Monthly',
    yearly: 'Yearly',
    save: 'Save',
    features: 'Features',
    perMonth: '/month',
    perYear: '/year',
    currentlyActive: 'Active',
    subscribe: 'Subscribe',
    comparePlans: 'Compare Plans',
    freeFeatures: {
      title: 'Free Plan',
      feature1: 'Basic health tips',
      feature2: 'View doctors list',
      feature3: 'Basic medicine info',
      feature4: 'Hospitals list',
      feature5: 'First aid guide',
      feature6: 'Basic health guide',
    },
    premiumFeatures: {
      title: 'Premium Features',
      feature1: '🩺 Complete Doctor Profiles',
      feature2: '💊 Complete 1500+ Medicine Database',
      feature3: '🤖 AI Health Chat (Unlimited)',
      feature4: '📚 Complete Health Library',
      feature5: '⚡ Ad-Free Experience',
      feature6: '🎯 Personalized Health Plan',
      feature7: '📊 Health Progress Tracking',
      feature8: '🔔 Reminder Services',
      feature9: '🏥 Online Doctor Appointment',
      feature10: '💬 Direct Chat with Doctors',
      feature11: '📱 Priority Support',
      feature12: '🎁 Access to Special Discounts',
    },
    monthlyPlan: {
      title: 'Monthly Premium',
      price: '200',
      currency: 'AFN',
      description: 'All premium features for one month',
    },
    yearlyPlan: {
      title: 'Yearly Premium',
      price: '2000',
      currency: 'AFN',
      description: 'Full access for one year - Save 400 AFN',
      savings: '17% off',
    },
    benefits: 'Premium Benefits',
    benefit1: 'Unlimited Access',
    benefit2: 'Ad-Free Experience',
    benefit3: 'Priority Support',
    benefit4: 'New Features First',
    whyPremium: 'Why Premium?',
    whyReason1: 'Complete health information',
    whyReason2: 'AI consultation',
    whyReason3: 'Direct contact with doctors',
    whyReason4: 'Health progress monitoring',
    guarantee: '30-day money-back guarantee',
    securePayment: 'Secure Payment',
  },
};

export function PremiumPlans({ language, onBack, currentUserId }: PremiumPlansProps) {
  const t = translations[language];
  const [selectedPlan, setSelectedPlan] = useState<'free' | 'monthly' | 'yearly'>('free');
  const [currentUserPlan, setCurrentUserPlan] = useState<'free' | 'monthly' | 'yearly'>('free');
  const [showPaymentGateway, setShowPaymentGateway] = useState(false);
  const [planToSubscribe, setPlanToSubscribe] = useState<any>(null);

  // د user premium status چک کړئ
  const checkUserPremiumStatus = () => {
    const premiumStatus = localStorage.getItem(`healmate_premium_${currentUserId}`);
    if (premiumStatus) {
      const { plan, expiryDate } = JSON.parse(premiumStatus);
      const now = new Date().getTime();
      if (now < expiryDate) {
        setCurrentUserPlan(plan);
        return plan;
      }
    }
    return 'free';
  };

  // د plan subscription
  const handleSubscribe = (plan: 'monthly' | 'yearly') => {
    if (!currentUserId) {
      alert(language === 'ps' ? 'مهرباني وکړئ لومړی ننوځئ!' : 
            language === 'fa' ? 'لطفاً اول وارد شوید!' : 
            'Please login first!');
      return;
    }

    // د plan معلومات تنظیم کړئ
    const planDetails = plan === 'monthly' ? {
      name: t.monthlyPlan.title,
      price: parseInt(t.monthlyPlan.price),
      duration: language === 'ps' ? '1 میاشت' : language === 'fa' ? '1 ماه' : '1 Month',
      features: Object.values(t.premiumFeatures).slice(1, 7)
    } : {
      name: t.yearlyPlan.title,
      price: parseInt(t.yearlyPlan.price),
      duration: language === 'ps' ? '1 کال' : language === 'fa' ? '1 سال' : '1 Year',
      features: Object.values(t.premiumFeatures).slice(1)
    };

    setPlanToSubscribe(planDetails);
    setShowPaymentGateway(true);
  };

  // د payment success callback
  const handlePaymentSuccess = () => {
    const now = new Date();
    const expiryDate = new Date();
    
    if (planToSubscribe.duration.includes('Month') || planToSubscribe.duration.includes('میاشت') || planToSubscribe.duration.includes('ماه')) {
      expiryDate.setMonth(expiryDate.getMonth() + 1);
      setCurrentUserPlan('monthly');
    } else {
      expiryDate.setFullYear(expiryDate.getFullYear() + 1);
      setCurrentUserPlan('yearly');
    }

    const premiumData = {
      plan: planToSubscribe.duration.includes('Month') || planToSubscribe.duration.includes('میاشت') || planToSubscribe.duration.includes('ماه') ? 'monthly' : 'yearly',
      startDate: now.getTime(),
      expiryDate: expiryDate.getTime(),
      userId: currentUserId,
    };

    localStorage.setItem(`healmate_premium_${currentUserId}`, JSON.stringify(premiumData));
    
    setShowPaymentGateway(false);
    setPlanToSubscribe(null);
  };

  useEffect(() => {
    if (currentUserId) {
      const plan = checkUserPremiumStatus();
      setSelectedPlan(plan);
    }
  }, [currentUserId]);

  return (
    <>
      {/* Payment Gateway Modal */}
      {showPaymentGateway && planToSubscribe ? (
        <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-sm">
          <PaymentGateway
            language={language}
            plan={planToSubscribe}
            onBack={() => setShowPaymentGateway(false)}
            onSuccess={handlePaymentSuccess}
          />
        </div>
      ) : null}

      <div className="min-h-screen bg-gradient-to-br from-purple-50 via-pink-50 to-orange-50 pb-24">
        {/* Header */}
        <div className="bg-gradient-to-r from-purple-600 via-pink-600 to-orange-600 text-white p-6 shadow-2xl">
          <div className="flex items-center justify-between mb-4">
            <button onClick={onBack} className="p-2 hover:bg-white/20 rounded-full transition-colors">
              <X className="w-6 h-6" />
            </button>
            <Crown className="w-8 h-8 text-yellow-300" />
          </div>
          
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-center"
          >
            <h1 className="text-3xl font-bold mb-2 flex items-center justify-center gap-2">
              <Sparkles className="w-8 h-8 text-yellow-300" />
              {t.title}
              <Sparkles className="w-8 h-8 text-yellow-300" />
            </h1>
            <p className="text-lg opacity-90">{t.subtitle}</p>
          </motion.div>
        </div>

        {/* Current Plan Status */}
        {currentUserPlan !== 'free' && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="mx-4 mt-4 bg-gradient-to-r from-green-500 to-emerald-600 text-white rounded-3xl p-6 shadow-xl"
          >
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <Crown className="w-8 h-8 text-yellow-300" />
                <div>
                  <p className="text-sm opacity-90">{t.currentPlan}</p>
                  <p className="text-xl font-bold capitalize">{currentUserPlan} Premium</p>
                </div>
              </div>
              <div className="bg-white/20 backdrop-blur-sm px-4 py-2 rounded-full">
                <Check className="w-6 h-6" />
              </div>
            </div>
          </motion.div>
        )}

        {/* Plans Grid */}
        <div className="container mx-auto px-4 py-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
            {/* Free Plan */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1 }}
              className={`bg-white rounded-3xl p-6 shadow-xl border-4 ${
                currentUserPlan === 'free' ? 'border-green-500' : 'border-transparent'
              }`}
            >
              <div className="text-center mb-6">
                <div className="inline-block bg-gray-100 p-4 rounded-2xl mb-4">
                  <Heart className="w-12 h-12 text-gray-600" />
                </div>
                <h3 className="text-2xl font-bold mb-2">{t.free}</h3>
                <div className="text-4xl font-bold text-gray-900 mb-2">
                  0
                  <span className="text-lg text-gray-600">{t.perMonth}</span>
                </div>
                {currentUserPlan === 'free' && (
                  <div className="bg-green-100 text-green-700 px-4 py-2 rounded-full text-sm font-medium">
                    {t.currentlyActive}
                  </div>
                )}
              </div>

              <div className="space-y-3 mb-6">
                {Object.values(t.freeFeatures).slice(1).map((feature, index) => (
                  <div key={index} className="flex items-start gap-2">
                    <Check className="w-5 h-5 text-green-500 flex-shrink-0 mt-0.5" />
                    <span className="text-sm text-gray-700">{feature}</span>
                  </div>
                ))}
              </div>
            </motion.div>

            {/* Monthly Plan */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 }}
              className={`bg-gradient-to-br from-purple-600 to-pink-600 text-white rounded-3xl p-6 shadow-2xl transform scale-105 border-4 ${
                currentUserPlan === 'monthly' ? 'border-yellow-300' : 'border-transparent'
              }`}
            >
              <div className="absolute top-4 right-4 bg-yellow-400 text-purple-900 px-3 py-1 rounded-full text-xs font-bold">
                {t.popular}
              </div>

              <div className="text-center mb-6">
                <div className="inline-block bg-white/20 backdrop-blur-sm p-4 rounded-2xl mb-4">
                  <Crown className="w-12 h-12 text-yellow-300" />
                </div>
                <h3 className="text-2xl font-bold mb-2">{t.monthlyPlan.title}</h3>
                <div className="text-5xl font-bold mb-2">
                  {t.monthlyPlan.price}
                  <span className="text-lg opacity-90">{t.perMonth}</span>
                </div>
                <p className="text-sm opacity-90">{t.monthlyPlan.currency}</p>
              </div>

              <Button
                onClick={() => handleSubscribe('monthly')}
                disabled={currentUserPlan === 'monthly'}
                className="w-full bg-white text-purple-600 hover:bg-purple-50 py-6 text-lg rounded-2xl mb-6 font-bold"
              >
                {currentUserPlan === 'monthly' ? t.currentlyActive : t.subscribe}
              </Button>

              <div className="space-y-3">
                {Object.values(t.premiumFeatures).slice(1, 7).map((feature, index) => (
                  <div key={index} className="flex items-start gap-2">
                    <Check className="w-5 h-5 text-yellow-300 flex-shrink-0 mt-0.5" />
                    <span className="text-sm">{feature}</span>
                  </div>
                ))}
              </div>
            </motion.div>

            {/* Yearly Plan */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3 }}
              className={`bg-gradient-to-br from-orange-500 to-red-600 text-white rounded-3xl p-6 shadow-2xl border-4 ${
                currentUserPlan === 'yearly' ? 'border-yellow-300' : 'border-transparent'
              }`}
            >
              <div className="absolute top-4 right-4 bg-yellow-400 text-orange-900 px-3 py-1 rounded-full text-xs font-bold flex items-center gap-1">
                <TrendingUp className="w-3 h-3" />
                {t.yearlyPlan.savings}
              </div>

              <div className="text-center mb-6">
                <div className="inline-block bg-white/20 backdrop-blur-sm p-4 rounded-2xl mb-4">
                  <Award className="w-12 h-12 text-yellow-300" />
                </div>
                <h3 className="text-2xl font-bold mb-2">{t.yearlyPlan.title}</h3>
                <div className="text-5xl font-bold mb-2">
                  {t.yearlyPlan.price}
                  <span className="text-lg opacity-90">{t.perYear}</span>
                </div>
                <p className="text-sm opacity-90">{t.yearlyPlan.currency}</p>
                <div className="mt-2 bg-white/20 backdrop-blur-sm px-4 py-2 rounded-full inline-block">
                  <p className="text-xs font-medium">{t.yearlyPlan.description}</p>
                </div>
              </div>

              <Button
                onClick={() => handleSubscribe('yearly')}
                disabled={currentUserPlan === 'yearly'}
                className="w-full bg-white text-orange-600 hover:bg-orange-50 py-6 text-lg rounded-2xl mb-6 font-bold"
              >
                {currentUserPlan === 'yearly' ? t.currentlyActive : t.subscribe}
              </Button>

              <div className="space-y-3">
                {Object.values(t.premiumFeatures).slice(1).map((feature, index) => (
                  <div key={index} className="flex items-start gap-2">
                    <Check className="w-5 h-5 text-yellow-300 flex-shrink-0 mt-0.5" />
                    <span className="text-sm">{feature}</span>
                  </div>
                ))}
              </div>
            </motion.div>
          </div>

          {/* Why Premium */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4 }}
            className="bg-white rounded-3xl p-8 shadow-xl mb-8"
          >
            <h2 className="text-2xl font-bold text-center mb-6 flex items-center justify-center gap-2">
              <Star className="w-8 h-8 text-yellow-500 fill-yellow-500" />
              {t.whyPremium}
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {[
                { icon: Shield, text: t.whyReason1, color: 'text-blue-600' },
                { icon: Zap, text: t.whyReason2, color: 'text-purple-600' },
                { icon: Heart, text: t.whyReason3, color: 'text-pink-600' },
                { icon: TrendingUp, text: t.whyReason4, color: 'text-orange-600' },
              ].map((item, index) => (
                <div key={index} className="text-center">
                  <div className={`inline-block p-4 rounded-2xl bg-gradient-to-br from-gray-50 to-gray-100 mb-3`}>
                    <item.icon className={`w-8 h-8 ${item.color}`} />
                  </div>
                  <p className="text-sm text-gray-700">{item.text}</p>
                </div>
              ))}
            </div>
          </motion.div>

          {/* Guarantee & Security */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.5 }}
              className="bg-gradient-to-br from-green-500 to-emerald-600 text-white rounded-3xl p-6 shadow-xl"
            >
              <div className="flex items-center gap-4">
                <div className="bg-white/20 backdrop-blur-sm p-4 rounded-2xl">
                  <Shield className="w-10 h-10" />
                </div>
                <div>
                  <h3 className="text-xl font-bold mb-1">{t.guarantee}</h3>
                  <p className="text-sm opacity-90">Try risk-free</p>
                </div>
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.5 }}
              className="bg-gradient-to-br from-blue-500 to-indigo-600 text-white rounded-3xl p-6 shadow-xl"
            >
              <div className="flex items-center gap-4">
                <div className="bg-white/20 backdrop-blur-sm p-4 rounded-2xl">
                  <Lock className="w-10 h-10" />
                </div>
                <div>
                  <h3 className="text-xl font-bold mb-1">{t.securePayment}</h3>
                  <p className="text-sm opacity-90">100% secure & encrypted</p>
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </div>
    </>
  );
}