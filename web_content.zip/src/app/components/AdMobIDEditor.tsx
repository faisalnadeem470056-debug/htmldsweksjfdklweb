import React, { useState } from 'react';
import { Input } from './ui/input';
import { Button } from './ui/button';
import { Label } from './ui/label';
import { Copy, Check, X, Edit2 } from 'lucide-react';
import { copyToClipboard } from '../utils/clipboard';

interface AdMobIDEditorProps {
  id: string;
  label: string;
  value: string;
  onSave: (newValue: string) => void;
  language: 'ps' | 'fa' | 'en';
  color?: string;
  description?: string;
}

export function AdMobIDEditor({ id, label, value, onSave, language, color, description }: AdMobIDEditorProps) {
  const [isEditing, setIsEditing] = useState(false);
  const [editValue, setEditValue] = useState(value);

  const handleSave = () => {
    onSave(editValue);
    setIsEditing(false);
  };

  const handleCancel = () => {
    setEditValue(value);
    setIsEditing(false);
  };

  const handleCopy = () => {
    copyToClipboard(value);
    alert(language === 'ps' ? 'کاپي شو!' : language === 'fa' ? 'کپی شد!' : 'Copied!');
  };

  return (
    <div className={`rounded-lg p-4 border-2 ${color || 'border-gray-200'}`}>
      <Label className="mb-2 block font-medium">
        {label}
      </Label>
      {description && (
        <p className="text-xs text-gray-600 mb-2">{description}</p>
      )}
      <div className="flex gap-2">
        {isEditing ? (
          <>
            <Input
              value={editValue}
              onChange={(e) => setEditValue(e.target.value)}
              className="font-mono text-sm flex-1"
              placeholder={language === 'ps' ? 'نوی ID دلته واچوئ' : language === 'fa' ? 'ID جدید را اینجا وارد کنید' : 'Enter new ID here'}
            />
            <Button
              variant="outline"
              size="sm"
              className="border-green-600 text-green-700 hover:bg-green-50"
              onClick={handleSave}
            >
              <Check className="w-4 h-4" />
            </Button>
            <Button
              variant="outline"
              size="sm"
              className="border-red-600 text-red-700 hover:bg-red-50"
              onClick={handleCancel}
            >
              <X className="w-4 h-4" />
            </Button>
          </>
        ) : (
          <>
            <Input
              value={value}
              className="font-mono text-sm flex-1"
              readOnly
            />
            <Button
              variant="outline"
              size="sm"
              className="border-blue-600 text-blue-700 hover:bg-blue-50"
              onClick={() => setIsEditing(true)}
            >
              <Edit2 className="w-4 h-4" />
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={handleCopy}
            >
              <Copy className="w-4 h-4" />
            </Button>
          </>
        )}
      </div>
    </div>
  );
}