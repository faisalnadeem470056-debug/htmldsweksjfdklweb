import { Home, BookOpen, MessageCircle, Pill, Settings } from 'lucide-react';
import { motion } from 'motion/react';

interface BottomNavigationProps {
  currentPage: string;
  onPageChange: (page: 'home' | 'doctors' | 'hospitals' | 'medicine' | 'firstaid' | 'health-tips' | 'nutrition' | 'community' | 'contact' | 'about' | 'settings' | 'admin' | 'books' | 'profile' | 'premium' | 'privacy' | 'terms' | 'help' | 'ai-chat') => void;
  language: 'ps' | 'fa' | 'en';
  userEmail?: string;
}

export function BottomNavigation({ currentPage, onPageChange, language, userEmail }: BottomNavigationProps) {
  const navItems = [
    {
      id: 'home' as const,
      icon: Home,
      label: { ps: 'کور', fa: 'خانه', en: 'Home' },
      gradient: 'from-blue-500 to-cyan-500',
    },
    {
      id: 'medicine' as const,
      icon: Pill,
      label: { ps: 'درمل', fa: 'دارو', en: 'Medicine' },
      gradient: 'from-purple-500 to-violet-500',
    },
    {
      id: 'community' as const,
      icon: MessageCircle,
      label: { ps: 'پوست', fa: 'پست', en: 'Posts' },
      gradient: 'from-red-500 to-pink-500',
    },
    {
      id: 'books' as const,
      icon: BookOpen,
      label: { ps: 'کتابونه', fa: 'کتاب‌ها', en: 'Books' },
      gradient: 'from-teal-500 to-cyan-500',
    },
    {
      id: 'settings' as const,
      icon: Settings,
      label: { ps: 'تنظیمات', fa: 'تنظیمات', en: 'Settings' },
      gradient: 'from-orange-500 to-red-500',
    },
  ];

  return (
    <div className="fixed bottom-0 left-0 right-0 z-50 lg:hidden">
      {/* Backdrop Blur */}
      <div className="absolute inset-0 backdrop-blur-xl bg-white/80 border-t border-white/20 shadow-2xl" />
      
      {/* Navigation Items */}
      <div className="relative px-4 py-2 safe-area-bottom">
        <div className="flex items-center justify-around">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = currentPage === item.id;
            
            return (
              <motion.button
                key={item.id}
                whileTap={{ scale: 0.9 }}
                onClick={() => onPageChange(item.id)}
                className="relative flex flex-col items-center justify-center gap-1 p-2 min-w-[60px]"
              >
                {/* Active Background */}
                {isActive && (
                  <motion.div
                    layoutId="activeTab"
                    className={`absolute inset-0 bg-gradient-to-r ${item.gradient} rounded-2xl opacity-10`}
                    transition={{ type: 'spring', bounce: 0.2, duration: 0.6 }}
                  />
                )}
                
                {/* Icon */}
                <div
                  className={`relative p-2 rounded-xl transition-all ${
                    isActive
                      ? `bg-gradient-to-r ${item.gradient} text-white shadow-lg scale-110`
                      : 'text-gray-600'
                  }`}
                >
                  <Icon className="w-5 h-5" />
                </div>
                
                {/* Label */}
                <span
                  className={`text-xs transition-all ${
                    isActive
                      ? 'bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent font-medium'
                      : 'text-gray-600'
                  }`}
                >
                  {item.label[language]}
                </span>

                {/* Active Indicator Dot */}
                {isActive && (
                  <motion.div
                    initial={{ scale: 0 }}
                    animate={{ scale: 1 }}
                    className={`absolute -top-1 w-1 h-1 bg-gradient-to-r ${item.gradient} rounded-full`}
                  />
                )}
              </motion.button>
            );
          })}
        </div>
      </div>
    </div>
  );
}
