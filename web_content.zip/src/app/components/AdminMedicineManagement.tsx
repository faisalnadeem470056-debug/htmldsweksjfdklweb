import { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import {
  Pill, Plus, Edit2, Trash2, Search, Filter, Save, X,
  AlertCircle, CheckCircle, Upload, Download, RefreshCw
} from 'lucide-react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Textarea } from './ui/textarea';
import { Badge } from './ui/badge';
import { Medicine, medicineCategories } from '../data/medicinesData';

interface AdminMedicineManagementProps {
  language: 'ps' | 'fa' | 'en';
}

export function AdminMedicineManagement({ language }: AdminMedicineManagementProps) {
  const [medicines, setMedicines] = useState<Medicine[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [showAddModal, setShowAddModal] = useState(false);
  const [editingMedicine, setEditingMedicine] = useState<Medicine | null>(null);
  const [formData, setFormData] = useState<Partial<Medicine>>({});

  const t = {
    ps: {
      title: 'د دواګانو مدیریت',
      addMedicine: 'دوا اضافه',
      editMedicine: 'دوا سمون',
      deleteMedicine: 'دوا حذف',
      search: 'لټون...',
      allCategories: 'ټولې کټګورۍ',
      name: 'نوم',
      genericName: 'عمومي نوم',
      category: 'کټګوري',
      usage: 'استعمال',
      dosage: 'مقدار',
      sideEffects: 'منفي اغیزې (د کاما سره جلا کړئ)',
      warnings: 'خبرتیاوې (د کاما سره جلا کړئ)',
      price: 'نرخ (AFN)',
      prescription: 'د نسخې اړتیا',
      manufacturer: 'جوړوونکی',
      save: 'خوندي',
      cancel: 'لغوه',
      delete: 'حذف',
      edit: 'سمون',
      confirmDelete: 'آیا تاسو ډاډه یاست؟',
      deleteSuccess: 'په بریالیتوب سره حذف شو',
      addSuccess: 'په بریالیتوب سره اضافه شو',
      updateSuccess: 'په بریالیتوب سره تازه شو',
      error: 'تېروتنه رامینځته شوه',
      total: 'ټول دواګانې',
      yes: 'هو',
      no: 'نه',
      namePashto: 'نوم (پښتو)',
      nameDari: 'نوم (دری)',
      nameEnglish: 'نوم (انګلیسي)',
      usagePashto: 'استعمال (پښتو)',
      usageDari: 'استعمال (دری)',
      usageEnglish: 'استعمال (انګلیسي)',
      dosagePashto: 'مقدار (پښتو)',
      dosageDari: 'مقدار (دری)',
      dosageEnglish: 'مقدار (انګلیسي)',
      sideEffectsPashto: 'منفي اغیزې (پښتو)',
      sideEffectsDari: 'منفي اغیزې (دری)',
      sideEffectsEnglish: 'منفي اغیزې (انګلیسي)',
      warningsPashto: 'خبرتیاوې (پښتو)',
      warningsDari: 'خبرتیاوې (دری)',
      warningsEnglish: 'خبرتیاوې (انګلیسي)',
      exportData: 'ډیټا ایکسپورټ',
      importData: 'ډیټا امپورټ',
      refresh: 'تازه کول'
    },
    fa: {
      title: 'مدیریت داروها',
      addMedicine: 'افزودن دارو',
      editMedicine: 'ویرایش دارو',
      deleteMedicine: 'حذف دارو',
      search: 'جستجو...',
      allCategories: 'همه دسته‌ها',
      name: 'نام',
      genericName: 'نام عمومی',
      category: 'دسته',
      usage: 'استفاده',
      dosage: 'دوز',
      sideEffects: 'عوارض جانبی (با کاما جدا کنید)',
      warnings: 'هشدارها (با کاما جدا کنید)',
      price: 'قیمت (AFN)',
      prescription: 'نیاز به نسخه',
      manufacturer: 'تولیدکننده',
      save: 'ذخیره',
      cancel: 'لغو',
      delete: 'حذف',
      edit: 'ویرایش',
      confirmDelete: 'آیا مطمئن هستید؟',
      deleteSuccess: 'با موفقیت حذف شد',
      addSuccess: 'با موفقیت اضافه شد',
      updateSuccess: 'با موفقیت بروز شد',
      error: 'خطا رخ داد',
      total: 'کل داروها',
      yes: 'بله',
      no: 'خیر',
      namePashto: 'نام (پشتو)',
      nameDari: 'نام (دری)',
      nameEnglish: 'نام (انگلیسی)',
      usagePashto: 'استفاده (پشتو)',
      usageDari: 'استفاده (دری)',
      usageEnglish: 'استفاده (انگلیسی)',
      dosagePashto: 'دوز (پشتو)',
      dosageDari: 'دوز (دری)',
      dosageEnglish: 'دوز (انگلیسی)',
      sideEffectsPashto: 'عوارض (پشتو)',
      sideEffectsDari: 'عوارض (دری)',
      sideEffectsEnglish: 'عوارض (انگلیسی)',
      warningsPashto: 'هشدارها (پشتو)',
      warningsDari: 'هشدارها (دری)',
      warningsEnglish: 'هشدارها (انگلیسی)',
      exportData: 'خروجی داده',
      importData: 'ورودی داده',
      refresh: 'بروزرسانی'
    },
    en: {
      title: 'Medicine Management',
      addMedicine: 'Add Medicine',
      editMedicine: 'Edit Medicine',
      deleteMedicine: 'Delete Medicine',
      search: 'Search...',
      allCategories: 'All Categories',
      name: 'Name',
      genericName: 'Generic Name',
      category: 'Category',
      usage: 'Usage',
      dosage: 'Dosage',
      sideEffects: 'Side Effects (comma separated)',
      warnings: 'Warnings (comma separated)',
      price: 'Price (AFN)',
      prescription: 'Prescription Required',
      manufacturer: 'Manufacturer',
      save: 'Save',
      cancel: 'Cancel',
      delete: 'Delete',
      edit: 'Edit',
      confirmDelete: 'Are you sure?',
      deleteSuccess: 'Deleted successfully',
      addSuccess: 'Added successfully',
      updateSuccess: 'Updated successfully',
      error: 'An error occurred',
      total: 'Total Medicines',
      yes: 'Yes',
      no: 'No',
      namePashto: 'Name (Pashto)',
      nameDari: 'Name (Dari)',
      nameEnglish: 'Name (English)',
      usagePashto: 'Usage (Pashto)',
      usageDari: 'Usage (Dari)',
      usageEnglish: 'Usage (English)',
      dosagePashto: 'Dosage (Pashto)',
      dosageDari: 'Dosage (Dari)',
      dosageEnglish: 'Dosage (English)',
      sideEffectsPashto: 'Side Effects (Pashto)',
      sideEffectsDari: 'Side Effects (Dari)',
      sideEffectsEnglish: 'Side Effects (English)',
      warningsPashto: 'Warnings (Pashto)',
      warningsDari: 'Warnings (Dari)',
      warningsEnglish: 'Warnings (English)',
      exportData: 'Export Data',
      importData: 'Import Data',
      refresh: 'Refresh'
    }
  };

  const text = t[language];

  useEffect(() => {
    loadMedicines();
  }, []);

  const loadMedicines = () => {
    const saved = localStorage.getItem('healmate_medicines');
    if (saved) {
      setMedicines(JSON.parse(saved));
    } else {
      // Load from default database
      const { medicinesDatabase } = require('../data/medicinesData');
      setMedicines(medicinesDatabase);
      localStorage.setItem('healmate_medicines', JSON.stringify(medicinesDatabase));
    }
  };

  const saveMedicines = (updatedMedicines: Medicine[]) => {
    localStorage.setItem('healmate_medicines', JSON.stringify(updatedMedicines));
    setMedicines(updatedMedicines);
  };

  const handleAddMedicine = () => {
    if (!formData.name?.ps || !formData.name?.generic || !formData.category) {
      alert(text.error);
      return;
    }

    const newMedicine: Medicine = {
      id: `MED${Date.now()}`,
      name: formData.name as any,
      category: formData.category,
      usage: formData.usage as any,
      dosage: formData.dosage as any,
      sideEffects: formData.sideEffects as any,
      warnings: formData.warnings as any,
      price: formData.price,
      prescription: formData.prescription || false,
      manufacturer: formData.manufacturer
    };

    const updated = [...medicines, newMedicine];
    saveMedicines(updated);
    setShowAddModal(false);
    setFormData({});
    alert(text.addSuccess);
  };

  const handleUpdateMedicine = () => {
    if (!editingMedicine) return;

    const updated = medicines.map(med =>
      med.id === editingMedicine.id ? { ...editingMedicine, ...formData } : med
    );
    saveMedicines(updated);
    setEditingMedicine(null);
    setFormData({});
    alert(text.updateSuccess);
  };

  const handleDeleteMedicine = (id: string) => {
    if (confirm(text.confirmDelete)) {
      const updated = medicines.filter(med => med.id !== id);
      saveMedicines(updated);
      alert(text.deleteSuccess);
    }
  };

  const handleExport = () => {
    const dataStr = JSON.stringify(medicines, null, 2);
    const dataBlob = new Blob([dataStr], { type: 'application/json' });
    const url = URL.createObjectURL(dataBlob);
    const link = document.createElement('a');
    link.href = url;
    link.download = 'healmate_medicines_export.json';
    link.click();
  };

  const filteredMedicines = medicines.filter(med => {
    const matchesSearch = searchQuery ? (
      med.name.ps.toLowerCase().includes(searchQuery.toLowerCase()) ||
      med.name.fa.toLowerCase().includes(searchQuery.toLowerCase()) ||
      med.name.en.toLowerCase().includes(searchQuery.toLowerCase()) ||
      med.name.generic.toLowerCase().includes(searchQuery.toLowerCase())
    ) : true;

    const matchesCategory = selectedCategory ? med.category === selectedCategory : true;

    return matchesSearch && matchesCategory;
  });

  const categories = Object.keys(medicineCategories.en);

  return (
    <div className="space-y-6">
      {/* Header Actions */}
      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
          <Input
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder={text.search}
            className="pl-10"
          />
        </div>
        <div className="flex gap-2">
          <Button onClick={() => setShowAddModal(true)} className="bg-gradient-to-r from-blue-500 to-cyan-600">
            <Plus className="w-4 h-4 mr-2" />
            {text.addMedicine}
          </Button>
          <Button variant="outline" onClick={handleExport}>
            <Download className="w-4 h-4" />
          </Button>
          <Button variant="outline" onClick={loadMedicines}>
            <RefreshCw className="w-4 h-4" />
          </Button>
        </div>
      </div>

      {/* Categories Filter */}
      <div className="flex gap-2 overflow-x-auto pb-2">
        <button
          onClick={() => setSelectedCategory(null)}
          className={`px-4 py-2 rounded-full whitespace-nowrap text-sm transition-all ${
            !selectedCategory
              ? 'bg-gradient-to-r from-blue-500 to-cyan-600 text-white shadow-lg'
              : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
          }`}
        >
          {text.allCategories}
        </button>
        {categories.map(cat => (
          <button
            key={cat}
            onClick={() => setSelectedCategory(cat)}
            className={`px-4 py-2 rounded-full whitespace-nowrap text-sm transition-all ${
              selectedCategory === cat
                ? 'bg-gradient-to-r from-blue-500 to-cyan-600 text-white shadow-lg'
                : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
            }`}
          >
            {medicineCategories[language][cat as keyof typeof medicineCategories.en]}
          </button>
        ))}
      </div>

      {/* Stats */}
      <div className="bg-white rounded-2xl p-4 border border-gray-200 shadow-lg">
        <div className="flex items-center justify-between">
          <span className="text-gray-600">{text.total}:</span>
          <span className="text-2xl font-bold text-blue-600">{filteredMedicines.length}</span>
        </div>
      </div>

      {/* Medicines Table */}
      <div className="bg-white rounded-2xl border border-gray-200 shadow-lg overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50 border-b border-gray-200">
              <tr>
                <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">ID</th>
                <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">{text.name}</th>
                <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">{text.category}</th>
                <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">{text.price}</th>
                <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">{text.prescription}</th>
                <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200">
              {filteredMedicines.map((medicine) => (
                <tr key={medicine.id} className="hover:bg-gray-50 transition-colors">
                  <td className="px-4 py-3 text-sm text-gray-600">{medicine.id}</td>
                  <td className="px-4 py-3">
                    <div>
                      <p className="font-medium">{medicine.name[language]}</p>
                      <p className="text-xs text-gray-500">{medicine.name.generic}</p>
                    </div>
                  </td>
                  <td className="px-4 py-3">
                    <Badge variant="secondary" className="text-xs">
                      {medicineCategories[language][medicine.category as keyof typeof medicineCategories.en]}
                    </Badge>
                  </td>
                  <td className="px-4 py-3 text-sm">{medicine.price || '-'} AFN</td>
                  <td className="px-4 py-3">
                    <Badge variant={medicine.prescription ? "destructive" : "default"} className="text-xs">
                      {medicine.prescription ? text.yes : text.no}
                    </Badge>
                  </td>
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-2">
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => {
                          setEditingMedicine(medicine);
                          setFormData(medicine);
                        }}
                      >
                        <Edit2 className="w-4 h-4" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="icon"
                        className="text-red-600"
                        onClick={() => handleDeleteMedicine(medicine.id)}
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Add/Edit Modal */}
      {(showAddModal || editingMedicine) && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="bg-white rounded-3xl p-6 max-w-4xl w-full max-h-[90vh] overflow-y-auto"
          >
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-2xl">{editingMedicine ? text.editMedicine : text.addMedicine}</h2>
              <Button
                variant="ghost"
                size="icon"
                onClick={() => {
                  setShowAddModal(false);
                  setEditingMedicine(null);
                  setFormData({});
                }}
              >
                <X className="w-5 h-5" />
              </Button>
            </div>

            <div className="space-y-4">
              {/* Names */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                  <Label>{text.namePashto}</Label>
                  <Input
                    value={formData.name?.ps || ''}
                    onChange={(e) => setFormData({
                      ...formData,
                      name: { ...formData.name, ps: e.target.value } as any
                    })}
                  />
                </div>
                <div>
                  <Label>{text.nameDari}</Label>
                  <Input
                    value={formData.name?.fa || ''}
                    onChange={(e) => setFormData({
                      ...formData,
                      name: { ...formData.name, fa: e.target.value } as any
                    })}
                  />
                </div>
                <div>
                  <Label>{text.nameEnglish}</Label>
                  <Input
                    value={formData.name?.en || ''}
                    onChange={(e) => setFormData({
                      ...formData,
                      name: { ...formData.name, en: e.target.value } as any
                    })}
                  />
                </div>
              </div>

              {/* Generic Name & Category */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label>{text.genericName}</Label>
                  <Input
                    value={formData.name?.generic || ''}
                    onChange={(e) => setFormData({
                      ...formData,
                      name: { ...formData.name, generic: e.target.value } as any
                    })}
                  />
                </div>
                <div>
                  <Label>{text.category}</Label>
                  <select
                    value={formData.category || ''}
                    onChange={(e) => setFormData({ ...formData, category: e.target.value })}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md"
                  >
                    <option value="">Select...</option>
                    {categories.map(cat => (
                      <option key={cat} value={cat}>
                        {medicineCategories[language][cat as keyof typeof medicineCategories.en]}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              {/* Usage */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                  <Label>{text.usagePashto}</Label>
                  <Textarea
                    value={formData.usage?.ps || ''}
                    onChange={(e) => setFormData({
                      ...formData,
                      usage: { ...formData.usage, ps: e.target.value } as any
                    })}
                    rows={3}
                  />
                </div>
                <div>
                  <Label>{text.usageDari}</Label>
                  <Textarea
                    value={formData.usage?.fa || ''}
                    onChange={(e) => setFormData({
                      ...formData,
                      usage: { ...formData.usage, fa: e.target.value } as any
                    })}
                    rows={3}
                  />
                </div>
                <div>
                  <Label>{text.usageEnglish}</Label>
                  <Textarea
                    value={formData.usage?.en || ''}
                    onChange={(e) => setFormData({
                      ...formData,
                      usage: { ...formData.usage, en: e.target.value } as any
                    })}
                    rows={3}
                  />
                </div>
              </div>

              {/* Dosage */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                  <Label>{text.dosagePashto}</Label>
                  <Input
                    value={formData.dosage?.ps || ''}
                    onChange={(e) => setFormData({
                      ...formData,
                      dosage: { ...formData.dosage, ps: e.target.value } as any
                    })}
                  />
                </div>
                <div>
                  <Label>{text.dosageDari}</Label>
                  <Input
                    value={formData.dosage?.fa || ''}
                    onChange={(e) => setFormData({
                      ...formData,
                      dosage: { ...formData.dosage, fa: e.target.value } as any
                    })}
                  />
                </div>
                <div>
                  <Label>{text.dosageEnglish}</Label>
                  <Input
                    value={formData.dosage?.en || ''}
                    onChange={(e) => setFormData({
                      ...formData,
                      dosage: { ...formData.dosage, en: e.target.value } as any
                    })}
                  />
                </div>
              </div>

              {/* Price, Prescription, Manufacturer */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                  <Label>{text.price}</Label>
                  <Input
                    type="number"
                    value={formData.price || ''}
                    onChange={(e) => setFormData({ ...formData, price: Number(e.target.value) })}
                  />
                </div>
                <div>
                  <Label>{text.prescription}</Label>
                  <select
                    value={formData.prescription ? 'true' : 'false'}
                    onChange={(e) => setFormData({ ...formData, prescription: e.target.value === 'true' })}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md"
                  >
                    <option value="false">{text.no}</option>
                    <option value="true">{text.yes}</option>
                  </select>
                </div>
                <div>
                  <Label>{text.manufacturer}</Label>
                  <Input
                    value={formData.manufacturer || ''}
                    onChange={(e) => setFormData({ ...formData, manufacturer: e.target.value })}
                  />
                </div>
              </div>

              {/* Actions */}
              <div className="flex gap-3 pt-4">
                <Button
                  onClick={editingMedicine ? handleUpdateMedicine : handleAddMedicine}
                  className="flex-1 bg-gradient-to-r from-blue-500 to-cyan-600"
                >
                  <Save className="w-4 h-4 mr-2" />
                  {text.save}
                </Button>
                <Button
                  variant="outline"
                  onClick={() => {
                    setShowAddModal(false);
                    setEditingMedicine(null);
                    setFormData({});
                  }}
                >
                  {text.cancel}
                </Button>
              </div>
            </div>
          </motion.div>
        </div>
      )}
    </div>
  );
}
