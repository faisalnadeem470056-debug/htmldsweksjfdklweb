import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Heart, MessageCircle, Share2, Flag, MoreVertical, X, Send, Image as ImageIcon, Smile, MapPin, Users, Check } from 'lucide-react';
import { Button } from './ui/button';
import { Textarea } from './ui/textarea';
import { ImageWithFallback } from './figma/ImageWithFallback';

interface SocialFeedProps {
  language: 'ps' | 'fa' | 'en';
  currentUserId: string;
  onViewProfile: (userId: string) => void;
}

interface Post {
  id: string;
  userId: string;
  userName: string;
  userImage: string;
  verified: boolean;
  content: string;
  images: string[];
  likes: string[];
  comments: Comment[];
  shares: number;
  timestamp: string;
  location?: string;
}

interface Comment {
  id: string;
  userId: string;
  userName: string;
  userImage: string;
  content: string;
  timestamp: string;
}

export function SocialFeed({ language, currentUserId, onViewProfile }: SocialFeedProps) {
  const [posts, setPosts] = useState<Post[]>([]);
  const [newPostContent, setNewPostContent] = useState('');
  const [newPostImages, setNewPostImages] = useState<string[]>([]);
  const [showCreatePost, setShowCreatePost] = useState(false);
  const [selectedPost, setSelectedPost] = useState<Post | null>(null);
  const [commentText, setCommentText] = useState('');
  const [showReportModal, setShowReportModal] = useState(false);
  const [reportPostId, setReportPostId] = useState('');

  const t = {
    ps: {
      whatsOnMind: 'تاسو څه فکر کوئ؟',
      createPost: 'پوست جوړ کړئ',
      post: 'خپور کړئ',
      cancel: 'لغوه',
      addPhotos: 'عکسونه اضافه کړئ',
      location: 'موقعیت',
      feeling: 'احساس',
      like: 'خوښ',
      likes: 'خوښونه',
      comment: 'تبصره',
      comments: 'تبصرې',
      share: 'شریک کړئ',
      shares: 'شریکونه',
      writeComment: 'تبصره ولیکئ...',
      send: 'واستوئ',
      report: 'ریپورټ',
      delete: 'حذف',
      edit: 'سمون',
      justNow: 'اوس',
      minutesAgo: 'منټې مخکې',
      hoursAgo: 'ساعتونه مخکې',
      daysAgo: 'ورځې مخکې',
      verified: 'تایید شوی',
      reportPost: 'پوست ریپورټ کړئ',
      spam: 'سپم',
      harassment: 'ځورول',
      inappropriate: 'نامناسب',
      fake: 'جعلي',
      noPostsYet: 'تراوسه هیڅ پوست نشته',
      startSharing: 'خپل فکرونه شریک کړئ!'
    },
    fa: {
      whatsOnMind: 'چه فکری می‌کنید؟',
      createPost: 'ایجاد پست',
      post: 'انتشار',
      cancel: 'لغو',
      addPhotos: 'افزودن عکس',
      location: 'موقعیت',
      feeling: 'احساس',
      like: 'پسند',
      likes: 'پسندها',
      comment: 'نظر',
      comments: 'نظرات',
      share: 'اشتراک',
      shares: 'اشتراک‌ها',
      writeComment: 'نظر بنویسید...',
      send: 'ارسال',
      report: 'گزارش',
      delete: 'حذف',
      edit: 'ویرایش',
      justNow: 'الان',
      minutesAgo: 'دقیقه پیش',
      hoursAgo: 'ساعت پیش',
      daysAgo: 'روز پیش',
      verified: 'تایید شده',
      reportPost: 'گزارش پست',
      spam: 'اسپم',
      harassment: 'آزار',
      inappropriate: 'نامناسب',
      fake: 'جعلی',
      noPostsYet: 'هنوز پستی نیست',
      startSharing: 'افکار خود را به اشتراک بگذارید!'
    },
    en: {
      whatsOnMind: "What's on your mind?",
      createPost: 'Create Post',
      post: 'Post',
      cancel: 'Cancel',
      addPhotos: 'Add Photos',
      location: 'Location',
      feeling: 'Feeling',
      like: 'Like',
      likes: 'Likes',
      comment: 'Comment',
      comments: 'Comments',
      share: 'Share',
      shares: 'Shares',
      writeComment: 'Write a comment...',
      send: 'Send',
      report: 'Report',
      delete: 'Delete',
      edit: 'Edit',
      justNow: 'Just now',
      minutesAgo: 'minutes ago',
      hoursAgo: 'hours ago',
      daysAgo: 'days ago',
      verified: 'Verified',
      reportPost: 'Report Post',
      spam: 'Spam',
      harassment: 'Harassment',
      inappropriate: 'Inappropriate',
      fake: 'Fake',
      noPostsYet: 'No posts yet',
      startSharing: 'Start sharing your thoughts!'
    }
  };

  const text = t[language];

  useEffect(() => {
    loadPosts();
  }, []);

  const loadPosts = () => {
    const savedPosts = JSON.parse(localStorage.getItem('healmate_posts') || '[]');
    setPosts(savedPosts.sort((a: Post, b: Post) => 
      new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()
    ));
  };

  const handleCreatePost = () => {
    if (!newPostContent.trim()) return;

    const currentUser = JSON.parse(localStorage.getItem('healmate_users_data') || '[]')
      .find((u: any) => u.id === currentUserId);

    const newPost: Post = {
      id: Date.now().toString(),
      userId: currentUserId,
      userName: currentUser?.name || 'User',
      userImage: currentUser?.profileImage || 'https://images.unsplash.com/photo-1633332755192-727a05c4013d?w=400',
      verified: currentUser?.verified || false,
      content: newPostContent,
      images: newPostImages,
      likes: [],
      comments: [],
      shares: 0,
      timestamp: new Date().toISOString()
    };

    const updatedPosts = [newPost, ...posts];
    setPosts(updatedPosts);
    localStorage.setItem('healmate_posts', JSON.stringify(updatedPosts));

    // Update user's post count
    const users = JSON.parse(localStorage.getItem('healmate_users_data') || '[]');
    const userIndex = users.findIndex((u: any) => u.id === currentUserId);
    if (userIndex !== -1) {
      users[userIndex].posts = (users[userIndex].posts || 0) + 1;
      localStorage.setItem('healmate_users_data', JSON.stringify(users));
    }

    setNewPostContent('');
    setNewPostImages([]);
    setShowCreatePost(false);
  };

  const handleLike = (postId: string) => {
    const updatedPosts = posts.map(post => {
      if (post.id === postId) {
        const hasLiked = post.likes.includes(currentUserId);
        return {
          ...post,
          likes: hasLiked
            ? post.likes.filter(id => id !== currentUserId)
            : [...post.likes, currentUserId]
        };
      }
      return post;
    });
    
    setPosts(updatedPosts);
    localStorage.setItem('healmate_posts', JSON.stringify(updatedPosts));
  };

  const handleComment = (postId: string) => {
    if (!commentText.trim()) return;

    const currentUser = JSON.parse(localStorage.getItem('healmate_users_data') || '[]')
      .find((u: any) => u.id === currentUserId);

    const newComment: Comment = {
      id: Date.now().toString(),
      userId: currentUserId,
      userName: currentUser?.name || 'User',
      userImage: currentUser?.profileImage || 'https://images.unsplash.com/photo-1633332755192-727a05c4013d?w=400',
      content: commentText,
      timestamp: new Date().toISOString()
    };

    const updatedPosts = posts.map(post => {
      if (post.id === postId) {
        return {
          ...post,
          comments: [...post.comments, newComment]
        };
      }
      return post;
    });

    setPosts(updatedPosts);
    localStorage.setItem('healmate_posts', JSON.stringify(updatedPosts));
    setCommentText('');
  };

  const handleDeletePost = (postId: string) => {
    const updatedPosts = posts.filter(post => post.id !== postId);
    setPosts(updatedPosts);
    localStorage.setItem('healmate_posts', JSON.stringify(updatedPosts));
  };

  const handleReportPost = (postId: string, reason: string) => {
    const reports = JSON.parse(localStorage.getItem('healmate_post_reports') || '[]');
    reports.push({
      reporterId: currentUserId,
      postId,
      reason,
      timestamp: new Date().toISOString()
    });
    localStorage.setItem('healmate_post_reports', JSON.stringify(reports));
    setShowReportModal(false);
    alert(text.report + ' submitted');
  };

  const getTimeAgo = (timestamp: string) => {
    const now = new Date();
    const postTime = new Date(timestamp);
    const diffMs = now.getTime() - postTime.getTime();
    const diffMins = Math.floor(diffMs / 60000);
    const diffHours = Math.floor(diffMs / 3600000);
    const diffDays = Math.floor(diffMs / 86400000);

    if (diffMins < 1) return text.justNow;
    if (diffMins < 60) return `${diffMins} ${text.minutesAgo}`;
    if (diffHours < 24) return `${diffHours} ${text.hoursAgo}`;
    return `${diffDays} ${text.daysAgo}`;
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-red-50 via-pink-50 to-purple-50 pb-28 md:pb-8">
      <div className="container mx-auto px-4 py-6 max-w-2xl">
        {/* Create Post Card */}
        <div className="bg-white/90 backdrop-blur-xl rounded-3xl shadow-xl border border-white/20 p-6 mb-6">
          <div className="flex gap-3">
            <div className="w-12 h-12 rounded-full overflow-hidden">
              <ImageWithFallback
                src="https://images.unsplash.com/photo-1633332755192-727a05c4013d?w=400"
                alt="User"
                className="w-full h-full object-cover"
              />
            </div>
            <button
              onClick={() => setShowCreatePost(true)}
              className="flex-1 text-left px-4 py-3 bg-gray-100 hover:bg-gray-200 rounded-full transition-all"
            >
              <span className="text-gray-500">{text.whatsOnMind}</span>
            </button>
          </div>

          <div className="flex gap-2 mt-4 pt-4 border-t border-gray-200">
            <button className="flex-1 flex items-center justify-center gap-2 p-2 hover:bg-gray-100 rounded-lg transition-all">
              <ImageIcon className="w-5 h-5 text-green-600" />
              <span className="text-sm">{text.addPhotos}</span>
            </button>
            <button className="flex-1 flex items-center justify-center gap-2 p-2 hover:bg-gray-100 rounded-lg transition-all">
              <Smile className="w-5 h-5 text-yellow-600" />
              <span className="text-sm">{text.feeling}</span>
            </button>
            <button className="flex-1 flex items-center justify-center gap-2 p-2 hover:bg-gray-100 rounded-lg transition-all">
              <MapPin className="w-5 h-5 text-red-600" />
              <span className="text-sm">{text.location}</span>
            </button>
          </div>
        </div>

        {/* Posts Feed */}
        <AnimatePresence>
          {posts.length === 0 ? (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="bg-white/90 backdrop-blur-xl rounded-3xl shadow-xl border border-white/20 p-12 text-center"
            >
              <MessageCircle className="w-16 h-16 text-gray-400 mx-auto mb-4" />
              <h3 className="text-2xl mb-2">{text.noPostsYet}</h3>
              <p className="text-gray-600">{text.startSharing}</p>
            </motion.div>
          ) : (
            posts.map((post, index) => (
              <motion.div
                key={post.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                className="bg-white/90 backdrop-blur-xl rounded-3xl shadow-xl border border-white/20 p-6 mb-6"
              >
                {/* Post Header */}
                <div className="flex items-start justify-between mb-4">
                  <div className="flex items-center gap-3">
                    <div
                      onClick={() => onViewProfile(post.userId)}
                      className="w-12 h-12 rounded-full overflow-hidden cursor-pointer"
                    >
                      <ImageWithFallback
                        src={post.userImage}
                        alt={post.userName}
                        className="w-full h-full object-cover"
                      />
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <span
                          onClick={() => onViewProfile(post.userId)}
                          className="font-medium cursor-pointer hover:underline"
                        >
                          {post.userName}
                        </span>
                        {post.verified && (
                          <div className="bg-blue-500 text-white p-1 rounded-full">
                            <Check className="w-3 h-3" />
                          </div>
                        )}
                      </div>
                      <span className="text-sm text-gray-500">{getTimeAgo(post.timestamp)}</span>
                    </div>
                  </div>

                  {/* Post Menu */}
                  <div className="relative">
                    <button className="p-2 hover:bg-gray-100 rounded-full">
                      <MoreVertical className="w-5 h-5 text-gray-600" />
                    </button>
                  </div>
                </div>

                {/* Post Content */}
                <p className="mb-4 whitespace-pre-wrap">{post.content}</p>

                {/* Post Images */}
                {post.images.length > 0 && (
                  <div className={`grid gap-2 mb-4 ${
                    post.images.length === 1 ? 'grid-cols-1' :
                    post.images.length === 2 ? 'grid-cols-2' :
                    post.images.length === 3 ? 'grid-cols-3' :
                    'grid-cols-2'
                  }`}>
                    {post.images.map((img, idx) => (
                      <div key={idx} className="rounded-2xl overflow-hidden aspect-square">
                        <ImageWithFallback
                          src={img}
                          alt={`Post image ${idx + 1}`}
                          className="w-full h-full object-cover"
                        />
                      </div>
                    ))}
                  </div>
                )}

                {/* Post Stats */}
                <div className="flex items-center justify-between py-3 border-t border-b border-gray-200 text-sm text-gray-600">
                  <span>{post.likes.length} {text.likes}</span>
                  <div className="flex gap-4">
                    <span>{post.comments.length} {text.comments}</span>
                    <span>{post.shares} {text.shares}</span>
                  </div>
                </div>

                {/* Post Actions */}
                <div className="flex gap-2 mt-4">
                  <button
                    onClick={() => handleLike(post.id)}
                    className={`flex-1 flex items-center justify-center gap-2 p-2 rounded-lg transition-all ${
                      post.likes.includes(currentUserId)
                        ? 'text-red-600 bg-red-50'
                        : 'hover:bg-gray-100'
                    }`}
                  >
                    <Heart
                      className={`w-5 h-5 ${post.likes.includes(currentUserId) ? 'fill-current' : ''}`}
                    />
                    <span>{text.like}</span>
                  </button>
                  <button
                    onClick={() => setSelectedPost(post)}
                    className="flex-1 flex items-center justify-center gap-2 p-2 hover:bg-gray-100 rounded-lg transition-all"
                  >
                    <MessageCircle className="w-5 h-5" />
                    <span>{text.comment}</span>
                  </button>
                  <button className="flex-1 flex items-center justify-center gap-2 p-2 hover:bg-gray-100 rounded-lg transition-all">
                    <Share2 className="w-5 h-5" />
                    <span>{text.share}</span>
                  </button>
                </div>

                {/* Comments Section */}
                {post.comments.length > 0 && (
                  <div className="mt-4 space-y-3">
                    {post.comments.slice(0, 3).map((comment) => (
                      <div key={comment.id} className="flex gap-3">
                        <div className="w-8 h-8 rounded-full overflow-hidden flex-shrink-0">
                          <ImageWithFallback
                            src={comment.userImage}
                            alt={comment.userName}
                            className="w-full h-full object-cover"
                          />
                        </div>
                        <div className="flex-1 bg-gray-100 rounded-2xl p-3">
                          <div className="font-medium text-sm mb-1">{comment.userName}</div>
                          <p className="text-sm">{comment.content}</p>
                          <span className="text-xs text-gray-500 mt-1">
                            {getTimeAgo(comment.timestamp)}
                          </span>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </motion.div>
            ))
          )}
        </AnimatePresence>
      </div>

      {/* Create Post Modal */}
      <AnimatePresence>
        {showCreatePost && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4"
            onClick={() => setShowCreatePost(false)}
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              onClick={(e) => e.stopPropagation()}
              className="bg-white rounded-3xl p-6 max-w-2xl w-full max-h-[90vh] overflow-y-auto"
            >
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-2xl">{text.createPost}</h2>
                <Button variant="ghost" size="icon" onClick={() => setShowCreatePost(false)}>
                  <X className="w-5 h-5" />
                </Button>
              </div>

              <Textarea
                placeholder={text.whatsOnMind}
                value={newPostContent}
                onChange={(e) => setNewPostContent(e.target.value)}
                className="min-h-32 mb-4"
                dir={language === 'en' ? 'ltr' : 'rtl'}
              />

              <div className="flex gap-3">
                <Button
                  onClick={handleCreatePost}
                  disabled={!newPostContent.trim()}
                  className="flex-1 bg-gradient-to-r from-red-600 to-pink-600"
                >
                  {text.post}
                </Button>
                <Button variant="outline" onClick={() => setShowCreatePost(false)}>
                  {text.cancel}
                </Button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Comment Modal */}
      <AnimatePresence>
        {selectedPost && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4"
            onClick={() => setSelectedPost(null)}
          >
            <motion.div
              initial={{ scale: 0.9, y: 50 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.9, y: 50 }}
              onClick={(e) => e.stopPropagation()}
              className="bg-white rounded-3xl p-6 max-w-2xl w-full max-h-[90vh] overflow-y-auto"
            >
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-2xl">{text.comments}</h3>
                <Button variant="ghost" size="icon" onClick={() => setSelectedPost(null)}>
                  <X className="w-5 h-5" />
                </Button>
              </div>

              {/* All Comments */}
              <div className="space-y-4 mb-6">
                {selectedPost.comments.map((comment) => (
                  <div key={comment.id} className="flex gap-3">
                    <div className="w-10 h-10 rounded-full overflow-hidden flex-shrink-0">
                      <ImageWithFallback
                        src={comment.userImage}
                        alt={comment.userName}
                        className="w-full h-full object-cover"
                      />
                    </div>
                    <div className="flex-1">
                      <div className="bg-gray-100 rounded-2xl p-3">
                        <div className="font-medium mb-1">{comment.userName}</div>
                        <p className="text-sm">{comment.content}</p>
                      </div>
                      <span className="text-xs text-gray-500 mt-1 ml-3">
                        {getTimeAgo(comment.timestamp)}
                      </span>
                    </div>
                  </div>
                ))}
              </div>

              {/* Comment Input */}
              <div className="flex gap-3 sticky bottom-0 bg-white pt-4 border-t">
                <Input
                  placeholder={text.writeComment}
                  value={commentText}
                  onChange={(e) => setCommentText(e.target.value)}
                  className="flex-1"
                  dir={language === 'en' ? 'ltr' : 'rtl'}
                  onKeyPress={(e) => {
                    if (e.key === 'Enter') {
                      handleComment(selectedPost.id);
                    }
                  }}
                />
                <Button
                  onClick={() => handleComment(selectedPost.id)}
                  disabled={!commentText.trim()}
                  className="bg-gradient-to-r from-red-600 to-pink-600"
                >
                  <Send className="w-4 h-4" />
                </Button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
