import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  X, Share2, Copy, Check, 
  MessageCircle, Send, Mail, Link2,
  Facebook, Twitter, Instagram, Linkedin
} from 'lucide-react';
import { SimpleButton as Button } from './SimpleButton';
import { toast } from 'sonner@2.0.3';

interface ShareModalProps {
  isOpen: boolean;
  onClose: () => void;
  language: 'ps' | 'fa' | 'en';
  shareContent?: {
    title?: string;
    description?: string;
    url?: string;
  };
}

export const ShareModal = ({ isOpen, onClose, language, shareContent }: ShareModalProps) => {
  const [copied, setCopied] = useState(false);

  const text = {
    ps: {
      title: 'شریک کول',
      subtitle: 'خپل مینځپانګه د نورو سره شریکه کړئ',
      copyLink: 'لینک کاپی کړئ',
      linkCopied: 'لینک کاپی شو!',
      shareVia: 'د یوې میډیا له لارې شریک کړئ',
      whatsapp: 'WhatsApp',
      telegram: 'Telegram',
      facebook: 'Facebook',
      twitter: 'Twitter',
      instagram: 'Instagram',
      linkedin: 'LinkedIn',
      email: 'برېښنالیک',
      sms: 'SMS',
      messenger: 'Messenger',
      moreOptions: 'نورې انتخابونه',
      close: 'بندول'
    },
    fa: {
      title: 'اشتراک‌گذاری',
      subtitle: 'محتوای خود را با دیگران به اشتراک بگذارید',
      copyLink: 'کپی لینک',
      linkCopied: 'لینک کپی شد!',
      shareVia: 'اشتراک از طریق',
      whatsapp: 'واتساپ',
      telegram: 'تلگرام',
      facebook: 'فیسبوک',
      twitter: 'توییتر',
      instagram: 'اینستاگرام',
      linkedin: 'لینکدین',
      email: 'ایمیل',
      sms: 'پیامک',
      messenger: 'مسنجر',
      moreOptions: 'گزینه‌های بیشتر',
      close: 'بستن'
    },
    en: {
      title: 'Share',
      subtitle: 'Share your content with others',
      copyLink: 'Copy Link',
      linkCopied: 'Link Copied!',
      shareVia: 'Share via',
      whatsapp: 'WhatsApp',
      telegram: 'Telegram',
      facebook: 'Facebook',
      twitter: 'Twitter',
      instagram: 'Instagram',
      linkedin: 'LinkedIn',
      email: 'Email',
      sms: 'SMS',
      messenger: 'Messenger',
      moreOptions: 'More Options',
      close: 'Close'
    }
  };

  const t = text[language];

  const shareUrl = shareContent?.url || window.location.href;
  const shareTitle = shareContent?.title || 'HealMate - د افغانستان روغتیا اپلیکیشن';
  const shareDescription = shareContent?.description || 'د روغتیا بشپړ معلومات په درې ژبو کې';

  const handleCopyLink = async () => {
    try {
      await navigator.clipboard.writeText(shareUrl);
      setCopied(true);
      
      toast.success(t.linkCopied, {
        duration: 2000,
        style: {
          background: 'linear-gradient(135deg, #10b981 0%, #059669 100%)',
          color: 'white',
          fontWeight: 'bold',
          padding: '16px',
          borderRadius: '12px'
        }
      });

      setTimeout(() => setCopied(false), 2000);
    } catch (err) {
      console.error('Failed to copy:', err);
    }
  };

  const shareOptions = [
    {
      id: 'whatsapp',
      name: t.whatsapp,
      icon: MessageCircle,
      color: 'from-green-500 to-green-600',
      url: `https://wa.me/?text=${encodeURIComponent(shareTitle + '\n' + shareUrl)}`,
      available: true
    },
    {
      id: 'telegram',
      name: t.telegram,
      icon: Send,
      color: 'from-blue-400 to-blue-500',
      url: `https://t.me/share/url?url=${encodeURIComponent(shareUrl)}&text=${encodeURIComponent(shareTitle)}`,
      available: true
    },
    {
      id: 'facebook',
      name: t.facebook,
      icon: Facebook,
      color: 'from-blue-600 to-blue-700',
      url: `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(shareUrl)}`,
      available: true
    },
    {
      id: 'twitter',
      name: t.twitter,
      icon: Twitter,
      color: 'from-sky-400 to-sky-500',
      url: `https://twitter.com/intent/tweet?url=${encodeURIComponent(shareUrl)}&text=${encodeURIComponent(shareTitle)}`,
      available: true
    },
    {
      id: 'linkedin',
      name: t.linkedin,
      icon: Linkedin,
      color: 'from-blue-700 to-blue-800',
      url: `https://www.linkedin.com/sharing/share-offsite/?url=${encodeURIComponent(shareUrl)}`,
      available: true
    },
    {
      id: 'email',
      name: t.email,
      icon: Mail,
      color: 'from-red-500 to-red-600',
      url: `mailto:?subject=${encodeURIComponent(shareTitle)}&body=${encodeURIComponent(shareDescription + '\n\n' + shareUrl)}`,
      available: true
    },
    {
      id: 'sms',
      name: t.sms,
      icon: MessageCircle,
      color: 'from-purple-500 to-purple-600',
      url: `sms:?body=${encodeURIComponent(shareTitle + '\n' + shareUrl)}`,
      available: true
    },
    {
      id: 'messenger',
      name: t.messenger,
      icon: MessageCircle,
      color: 'from-blue-500 to-pink-500',
      url: `fb-messenger://share/?link=${encodeURIComponent(shareUrl)}`,
      available: true
    }
  ];

  const handleShare = (option: typeof shareOptions[0]) => {
    window.open(option.url, '_blank', 'width=600,height=400');
    
    toast.success(
      language === 'ps' 
        ? `${option.name} ته شریک شو!` 
        : language === 'fa'
        ? `به ${option.name} اشتراک گذاشته شد!`
        : `Shared to ${option.name}!`,
      {
        duration: 2000,
        style: {
          background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
          color: 'white',
          fontWeight: 'bold',
          padding: '16px',
          borderRadius: '12px'
        }
      }
    );
  };

  const handleNativeShare = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: shareTitle,
          text: shareDescription,
          url: shareUrl
        });
      } catch (err) {
        // که share ناکامه شي یا user یې cancel کړي
        if (err instanceof Error && err.name !== 'AbortError') {
          console.error('Error sharing:', err);
          // د fallback په توګه link کاپي کړه
          handleCopyLink();
        }
      }
    }
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 bg-black/50 backdrop-blur-sm z-[9998]"
          />

          {/* Modal */}
          <motion.div
            initial={{ opacity: 0, scale: 0.95, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 20 }}
            transition={{ type: 'spring', damping: 25, stiffness: 300 }}
            className="fixed inset-x-4 top-1/2 -translate-y-1/2 max-w-lg mx-auto bg-white rounded-2xl shadow-2xl z-[9999] overflow-hidden"
            style={{ maxHeight: '85vh' }}
          >
            {/* Header */}
            <div className="bg-gradient-to-r from-red-600 to-pink-600 px-6 py-4 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-white/20 backdrop-blur-lg rounded-full flex items-center justify-center">
                  <Share2 className="w-5 h-5 text-white" />
                </div>
                <div>
                  <h2 className="text-xl text-white">{t.title}</h2>
                  <p className="text-sm text-white/80">{t.subtitle}</p>
                </div>
              </div>
              <button
                onClick={onClose}
                className="w-8 h-8 bg-white/20 hover:bg-white/30 rounded-full flex items-center justify-center transition-colors"
              >
                <X className="w-5 h-5 text-white" />
              </button>
            </div>

            {/* Content */}
            <div className="p-6 overflow-y-auto" style={{ maxHeight: 'calc(85vh - 180px)' }}>
              {/* Copy Link Section */}
              <div className="mb-6">
                <div className="flex items-center gap-2 p-3 bg-gray-100 rounded-lg">
                  <Link2 className="w-5 h-5 text-gray-500 flex-shrink-0" />
                  <input
                    type="text"
                    value={shareUrl}
                    readOnly
                    className="flex-1 bg-transparent text-sm text-gray-700 outline-none"
                    dir="ltr"
                  />
                  <Button
                    onClick={handleCopyLink}
                    className="px-4 py-2 bg-gradient-to-r from-red-600 to-pink-600 text-white rounded-lg text-sm hover:from-red-700 hover:to-pink-700 transition-all flex items-center gap-2"
                  >
                    {copied ? (
                      <>
                        <Check className="w-4 h-4" />
                        <span>{t.linkCopied}</span>
                      </>
                    ) : (
                      <>
                        <Copy className="w-4 h-4" />
                        <span>{t.copyLink}</span>
                      </>
                    )}
                  </Button>
                </div>
              </div>

              {/* Share Options */}
              <div className="mb-4">
                <h3 className="text-sm text-gray-500 mb-3" dir={language === 'en' ? 'ltr' : 'rtl'}>
                  {t.shareVia}
                </h3>
                <div className="grid grid-cols-4 gap-4">
                  {shareOptions.map((option, index) => (
                    <motion.button
                      key={option.id}
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: index * 0.05 }}
                      onClick={() => handleShare(option)}
                      className="flex flex-col items-center gap-2 p-3 rounded-xl hover:bg-gray-50 transition-all group"
                    >
                      <div className={`w-14 h-14 bg-gradient-to-br ${option.color} rounded-full flex items-center justify-center shadow-lg group-hover:scale-110 transition-transform`}>
                        <option.icon className="w-7 h-7 text-white" />
                      </div>
                      <span className="text-xs text-gray-700 text-center">
                        {option.name}
                      </span>
                    </motion.button>
                  ))}
                </div>
              </div>

              {/* Native Share (if available) */}
              {navigator.share && (
                <div className="mt-4">
                  <Button
                    onClick={handleNativeShare}
                    className="w-full py-3 bg-gradient-to-r from-purple-600 to-indigo-600 text-white rounded-xl hover:from-purple-700 hover:to-indigo-700 transition-all flex items-center justify-center gap-2"
                  >
                    <Share2 className="w-5 h-5" />
                    <span>{t.moreOptions}</span>
                  </Button>
                </div>
              )}
            </div>

            {/* Footer */}
            <div className="px-6 py-4 bg-gray-50 border-t border-gray-200">
              <Button
                onClick={onClose}
                className="w-full py-3 bg-gray-200 hover:bg-gray-300 text-gray-700 rounded-xl transition-all"
              >
                {t.close}
              </Button>
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
};
