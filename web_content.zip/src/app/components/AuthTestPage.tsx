// Authentication Test Page - د Firebase Auth ټیسټ پاڼه
// د Signup او Login ټیسټولو لپاره

import { useState } from 'react';
import { motion } from 'motion/react';
import { ArrowLeft, UserPlus, LogIn, Shield } from 'lucide-react';
import { SimpleButton as Button } from './SimpleButton';
import { SignupPage } from './SignupPage';

interface AuthTestPageProps {
  language: 'ps' | 'fa' | 'en';
  onBack: () => void;
}

export function AuthTestPage({ language, onBack }: AuthTestPageProps) {
  const [activeView, setActiveView] = useState<'menu' | 'signup'>('menu');

  const translations = {
    ps: {
      title: 'د Authentication ټیسټ پاڼه',
      subtitle: 'د Firebase signup او login ټیسټول',
      testSignup: 'د Signup ټیسټ',
      signupDesc: 'د Firebase Authentication signup ټیسټ کړئ',
      back: 'بیرته',
      features: 'فیچرونه:',
      feature1: 'د Firebase createUserWithEmailAndPassword',
      feature2: 'د Firestore کې د user معلومات ساتل',
      feature3: 'بشپړ validation او error handling',
      feature4: 'Trilingual support (پښتو، دری، انګلیسي)'
    },
    fa: {
      title: 'صفحه تست احراز هویت',
      subtitle: 'تست ثبت نام و ورود Firebase',
      testSignup: 'تست ثبت نام',
      signupDesc: 'تست ثبت نام Firebase Authentication',
      back: 'بازگشت',
      features: 'ویژگی‌ها:',
      feature1: 'Firebase createUserWithEmailAndPassword',
      feature2: 'ذخیره اطلاعات کاربر در Firestore',
      feature3: 'اعتبارسنجی کامل و مدیریت خطا',
      feature4: 'پشتیبانی سه زبانه (پشتو، دری، انگلیسی)'
    },
    en: {
      title: 'Authentication Test Page',
      subtitle: 'Test Firebase signup and login',
      testSignup: 'Test Signup',
      signupDesc: 'Test Firebase Authentication signup',
      back: 'Back',
      features: 'Features:',
      feature1: 'Firebase createUserWithEmailAndPassword',
      feature2: 'Save user data to Firestore',
      feature3: 'Complete validation & error handling',
      feature4: 'Trilingual support (Pashto, Dari, English)'
    }
  };

  const txt = translations[language];

  if (activeView === 'signup') {
    return (
      <SignupPage
        language={language}
        onSignupSuccess={() => {
          setActiveView('menu');
        }}
        onSwitchToLogin={() => {
          setActiveView('menu');
        }}
        onClose={() => setActiveView('menu')}
      />
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-purple-50 to-pink-50">
      {/* Animated Background Mesh */}
      <div className="fixed inset-0 pointer-events-none overflow-hidden">
        <div className="absolute top-0 left-0 w-96 h-96 bg-blue-400 rounded-full blur-3xl opacity-20 animate-pulse" style={{ animationDuration: '4s' }} />
        <div className="absolute bottom-0 right-0 w-96 h-96 bg-purple-400 rounded-full blur-3xl opacity-20 animate-pulse" style={{ animationDuration: '6s', animationDelay: '1s' }} />
      </div>

      <div className="container mx-auto px-4 py-8 relative z-10">
        {/* Header */}
        <div className="mb-8">
          <Button
            variant="ghost"
            size="sm"
            onClick={onBack}
            className="mb-4"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            {txt.back}
          </Button>

          <div className="text-center">
            <motion.h1
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              className="text-4xl font-bold mb-2 bg-gradient-to-r from-blue-600 via-purple-600 to-pink-600 bg-clip-text text-transparent"
            >
              {txt.title}
            </motion.h1>
            <p className="text-gray-600">
              {txt.subtitle}
            </p>
          </div>
        </div>

        {/* Test Card */}
        <div className="max-w-2xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="relative group"
          >
            <div className="absolute inset-0 bg-gradient-to-br from-blue-500 to-purple-600 opacity-0 group-hover:opacity-10 rounded-3xl blur-xl transition-all duration-500" />
            <div className="relative backdrop-blur-xl rounded-3xl p-8 border border-white/50 bg-white/70 shadow-xl hover:shadow-2xl transition-all duration-300 hover:scale-[1.02]">
              <div className="mb-6">
                <div className="w-16 h-16 bg-gradient-to-br from-blue-600 to-purple-600 rounded-2xl flex items-center justify-center mb-4 shadow-lg">
                  <UserPlus className="w-8 h-8 text-white" />
                </div>
                <h3 className="text-2xl font-bold text-gray-900 mb-2">
                  {txt.testSignup}
                </h3>
                <p className="text-gray-600">
                  {txt.signupDesc}
                </p>
              </div>

              <div className="mb-6 p-4 rounded-2xl bg-gradient-to-br from-blue-50 to-purple-50 border border-blue-200">
                <p className="font-bold text-gray-900 mb-3">{txt.features}</p>
                <ul className="space-y-2">
                  {[txt.feature1, txt.feature2, txt.feature3, txt.feature4].map((feature, index) => (
                    <li key={index} className="flex items-start gap-2 text-sm text-gray-700">
                      <Shield className="w-4 h-4 text-blue-600 flex-shrink-0 mt-0.5" />
                      {feature}
                    </li>
                  ))}
                </ul>
              </div>

              {/* Code Example */}
              <div className="mb-6 p-4 rounded-xl bg-gray-900 border border-gray-700 overflow-x-auto">
                <p className="text-xs text-gray-400 mb-2">Flutter Code:</p>
                <pre className="text-xs text-green-400 font-mono">
{`Future<void> signup(String email, String password) async {
  await FirebaseAuth.instance
    .createUserWithEmailAndPassword(
      email: email,
      password: password,
    );
}`}
                </pre>
                <p className="text-xs text-gray-400 mt-3 mb-2">React Code (HealMate):</p>
                <pre className="text-xs text-blue-400 font-mono">
{`await firebaseManager.signUp(
  email,
  password,
  name,
  phone
);`}
                </pre>
              </div>

              <Button
                onClick={() => setActiveView('signup')}
                className="w-full bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white font-bold py-3 rounded-xl border-0"
              >
                <UserPlus className="w-5 h-5 mr-2" />
                {language === 'ps' ? 'د Signup پاڼه خلاصول' : language === 'fa' ? 'باز کردن صفحه ثبت نام' : 'Open Signup Page'}
              </Button>
            </div>
          </motion.div>

          {/* Info */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="mt-6 backdrop-blur-xl rounded-2xl p-6 border border-white/50 bg-white/70 shadow-lg"
          >
            <div className="flex items-start gap-4">
              <div className="w-10 h-10 bg-gradient-to-br from-green-500 to-emerald-600 rounded-xl flex items-center justify-center flex-shrink-0">
                <Shield className="w-5 h-5 text-white" />
              </div>
              <div>
                <p className="font-bold text-gray-900 mb-2">
                  {language === 'ps' 
                    ? 'د Firebase Authentication معلومات'
                    : language === 'fa'
                    ? 'اطلاعات Firebase Authentication'
                    : 'Firebase Authentication Info'
                  }
                </p>
                <p className="text-sm text-gray-700">
                  {language === 'ps'
                    ? 'دا signup سیسټم د Flutter په شان کار کوي. کله چې تاسو signup کړئ، نوی account په Firebase Authentication کې جوړیږي او د user معلومات په Firestore کې ساتل کیږي.'
                    : language === 'fa'
                    ? 'این سیستم ثبت نام مانند Flutter کار می‌کند. وقتی ثبت نام می‌کنید، یک حساب جدید در Firebase Authentication ایجاد می‌شود و اطلاعات کاربر در Firestore ذخیره می‌گردد.'
                    : 'This signup system works like Flutter. When you sign up, a new account is created in Firebase Authentication and user data is saved to Firestore.'
                  }
                </p>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </div>
  );
}
