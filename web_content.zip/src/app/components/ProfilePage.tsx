import { useState, useEffect } from 'react';
import { ArrowLeft, User, Mail, Phone, Globe, Edit2, Save, Camera, Crown, Sparkles, Zap } from 'lucide-react';
import { motion } from 'motion/react';
import { Button } from './ui/button';
import { Input } from './ui/input';

interface ProfilePageProps {
  language: 'ps' | 'fa' | 'en';
  onBack: () => void;
  onLanguageChange: (lang: 'ps' | 'fa' | 'en') => void;
  onNavigate?: (page: string) => void; // د Premium Plans ته navigate کولو لپاره
}

export function ProfilePage({ language, onBack, onLanguageChange, onNavigate }: ProfilePageProps) {
  // User info state - Using localStorage for simple profile
  const [displayName, setDisplayName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [isEditing, setIsEditing] = useState(false);
  const [isPremium, setIsPremium] = useState(false);
  const [premiumPlan, setPremiumPlan] = useState<'monthly' | 'yearly' | null>(null);
  const [premiumExpiry, setPremiumExpiry] = useState<Date | null>(null);
  
  // Temp values for editing
  const [tempName, setTempName] = useState('');
  const [tempEmail, setTempEmail] = useState('');
  const [tempPhone, setTempPhone] = useState('');

  // Debug - confirm component is rendering
  console.log('ProfilePage rendered!', { language, displayName });

  useEffect(() => {
    // Load profile from localStorage
    const savedName = localStorage.getItem('profileName') || (language === 'ps' ? 'کاروونکی' : language === 'fa' ? 'کاربر' : 'User');
    const savedEmail = localStorage.getItem('profileEmail') || 'user@example.com';
    const savedPhone = localStorage.getItem('profilePhone') || '+93 700 000 000';
    
    setDisplayName(savedName);
    setEmail(savedEmail);
    setPhone(savedPhone);
    
    // Check premium status
    const userEmail = localStorage.getItem('healmate_userEmail');
    const premiumData = localStorage.getItem(`healmate_premium_${userEmail}`);
    if (premiumData) {
      const { plan, expiryDate } = JSON.parse(premiumData);
      const now = new Date().getTime();
      if (now < expiryDate) {
        setIsPremium(true);
        setPremiumPlan(plan);
        setPremiumExpiry(new Date(expiryDate));
      }
    }
    
    console.log('Profile loaded:', { savedName, savedEmail, savedPhone });
  }, [language]);

  const handleSave = () => {
    // Save to localStorage
    localStorage.setItem('profileName', tempName || displayName);
    localStorage.setItem('profileEmail', tempEmail || email);
    localStorage.setItem('profilePhone', tempPhone || phone);
    
    setDisplayName(tempName || displayName);
    setEmail(tempEmail || email);
    setPhone(tempPhone || phone);
    
    setIsEditing(false);
    setTempName('');
    setTempEmail('');
    setTempPhone('');
  };

  const handleEdit = () => {
    setTempName(displayName);
    setTempEmail(email);
    setTempPhone(phone);
    setIsEditing(true);
  };

  const handleCancel = () => {
    setIsEditing(false);
    setTempName('');
    setTempEmail('');
    setTempPhone('');
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 via-amber-50 to-yellow-50 pb-28 md:pb-8">
      {/* Header */}
      <div className="sticky top-0 z-40 backdrop-blur-xl bg-white/80 border-b border-white/20 shadow-lg">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center gap-4">
            <Button variant="ghost" size="icon" onClick={onBack}>
              <ArrowLeft className="w-5 h-5" />
            </Button>
            <div className="flex-1">
              <h1 className="text-2xl bg-gradient-to-r from-orange-600 to-amber-600 bg-clip-text text-transparent">
                {language === 'ps' ? '👤 پروفایل' : language === 'fa' ? '👤 پروفایل' : '👤 Profile'}
              </h1>
            </div>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="container mx-auto px-4 mt-6 max-w-2xl">
        <div className="space-y-6">
          {/* Profile Photo */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-white/90 backdrop-blur-xl rounded-3xl p-8 border border-white/20 shadow-xl"
          >
            <div className="flex flex-col items-center">
              <div className="relative mb-4">
                <div className="w-32 h-32 rounded-full overflow-hidden border-4 border-orange-500 shadow-lg bg-gradient-to-br from-orange-400 to-amber-500 flex items-center justify-center">
                  <User className="w-16 h-16 text-white" />
                </div>
                
                <div className="absolute bottom-0 right-0 w-10 h-10 bg-orange-600 rounded-full flex items-center justify-center shadow-lg cursor-pointer hover:bg-orange-700 transition-all">
                  <Camera className="w-5 h-5 text-white" />
                </div>
              </div>
              
              <h2 className="text-2xl mb-1">{displayName}</h2>
              <p className="text-gray-600 text-sm">
                {language === 'ps' ? 'د HealMate کاروونکی' : language === 'fa' ? 'کاربر HealMate' : 'HealMate User'}
              </p>
            </div>
          </motion.div>

          {/* Profile Info */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="bg-white/90 backdrop-blur-xl rounded-3xl p-6 border border-white/20 shadow-xl"
          >
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-xl">
                {language === 'ps' ? 'د پروفایل معلومات' : language === 'fa' ? 'اطلاعات پروفایل' : 'Profile Information'}
              </h3>
              {!isEditing && (
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={handleEdit}
                  className="bg-orange-50 hover:bg-orange-100"
                >
                  <Edit2 className="w-4 h-4 mr-2" />
                  {language === 'ps' ? 'سمون' : language === 'fa' ? 'ویرایش' : 'Edit'}
                </Button>
              )}
            </div>

            <div className="space-y-4">
              {/* Name */}
              <div className="flex items-start gap-3">
                <User className="w-5 h-5 text-orange-600 mt-1" />
                <div className="flex-1">
                  <label className="text-sm text-gray-600 mb-1 block">
                    {language === 'ps' ? 'نوم' : language === 'fa' ? 'نام' : 'Name'}
                  </label>
                  {isEditing ? (
                    <Input
                      value={tempName}
                      onChange={(e) => setTempName(e.target.value)}
                      placeholder={displayName}
                      className="w-full"
                    />
                  ) : (
                    <p className="text-lg">{displayName}</p>
                  )}
                </div>
              </div>

              {/* Email */}
              <div className="flex items-start gap-3">
                <Mail className="w-5 h-5 text-orange-600 mt-1" />
                <div className="flex-1">
                  <label className="text-sm text-gray-600 mb-1 block">
                    {language === 'ps' ? 'ایمیل' : language === 'fa' ? 'ایمیل' : 'Email'}
                  </label>
                  {isEditing ? (
                    <Input
                      type="email"
                      value={tempEmail}
                      onChange={(e) => setTempEmail(e.target.value)}
                      placeholder={email}
                      className="w-full"
                    />
                  ) : (
                    <p className="text-lg">{email}</p>
                  )}
                </div>
              </div>

              {/* Phone */}
              <div className="flex items-start gap-3">
                <Phone className="w-5 h-5 text-orange-600 mt-1" />
                <div className="flex-1">
                  <label className="text-sm text-gray-600 mb-1 block">
                    {language === 'ps' ? 'نمبر' : language === 'fa' ? 'شماره' : 'Phone'}
                  </label>
                  {isEditing ? (
                    <Input
                      type="tel"
                      value={tempPhone}
                      onChange={(e) => setTempPhone(e.target.value)}
                      placeholder={phone}
                      className="w-full"
                    />
                  ) : (
                    <p className="text-lg">{phone}</p>
                  )}
                </div>
              </div>
            </div>

            {/* Save/Cancel Buttons */}
            {isEditing && (
              <div className="flex gap-3 mt-6">
                <Button
                  className="flex-1 bg-green-600 hover:bg-green-700"
                  onClick={handleSave}
                >
                  <Save className="w-4 h-4 mr-2" />
                  {language === 'ps' ? 'خوندي کول' : language === 'fa' ? 'ذخیره' : 'Save'}
                </Button>
                <Button
                  variant="outline"
                  onClick={handleCancel}
                >
                  {language === 'ps' ? 'لغوه' : language === 'fa' ? 'لغو' : 'Cancel'}
                </Button>
              </div>
            )}
          </motion.div>

          {/* Language Selection */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="bg-white/90 backdrop-blur-xl rounded-3xl p-6 border border-white/20 shadow-xl"
          >
            <div className="flex items-center gap-3 mb-4">
              <Globe className="w-5 h-5 text-orange-600" />
              <h3 className="text-xl">
                {language === 'ps' ? 'ژبه' : language === 'fa' ? 'زبان' : 'Language'}
              </h3>
            </div>
            
            <div className="grid grid-cols-3 gap-3">
              <button
                onClick={() => onLanguageChange('ps')}
                className={`p-4 rounded-xl border-2 transition-all ${
                  language === 'ps'
                    ? 'border-orange-600 bg-orange-50 scale-105'
                    : 'border-gray-200 hover:border-orange-300 hover:scale-105'
                }`}
              >
                <div className="text-3xl mb-2">🇦🇫</div>
                <div className="text-sm">پښتو</div>
              </button>
              
              <button
                onClick={() => onLanguageChange('fa')}
                className={`p-4 rounded-xl border-2 transition-all ${
                  language === 'fa'
                    ? 'border-orange-600 bg-orange-50 scale-105'
                    : 'border-gray-200 hover:border-orange-300 hover:scale-105'
                }`}
              >
                <div className="text-3xl mb-2">🇦🇫</div>
                <div className="text-sm">دری</div>
              </button>
              
              <button
                onClick={() => onLanguageChange('en')}
                className={`p-4 rounded-xl border-2 transition-all ${
                  language === 'en'
                    ? 'border-orange-600 bg-orange-50 scale-105'
                    : 'border-gray-200 hover:border-orange-300 hover:scale-105'
                }`}
              >
                <div className="text-3xl mb-2">🇬🇧</div>
                <div className="text-sm">English</div>
              </button>
            </div>
          </motion.div>

          {/* Premium Status */}
          {isPremium && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3 }}
              className="bg-gradient-to-br from-orange-500/10 to-amber-500/10 rounded-3xl p-6 border border-orange-200/50"
            >
              <div className="text-center">
                <div className="text-4xl mb-3">👑</div>
                <h3 className="text-xl mb-2 bg-gradient-to-r from-orange-600 to-amber-600 bg-clip-text text-transparent">
                  {language === 'ps' ? 'پرمیوم' : language === 'fa' ? 'پرمیوم' : 'Premium'}
                </h3>
                <p className="text-gray-600 text-sm">
                  {language === 'ps' 
                    ? 'د شما پرمیوم پلان دی' 
                    : language === 'fa' 
                    ? 'شما پلن پرمیوم دارید' 
                    : 'You have a Premium Plan'}
                </p>
                <p className="text-gray-600 text-sm">
                  {language === 'ps' 
                    ? `د پرمیوم پلان ${premiumPlan}یه` 
                    : language === 'fa' 
                    ? `پلن پرمیوم ${premiumPlan}یه` 
                    : `Premium Plan ${premiumPlan}`}
                </p>
                <p className="text-gray-600 text-sm">
                  {language === 'ps' 
                    ? `تیرمنځت: ${premiumExpiry?.toLocaleDateString()}` 
                    : language === 'fa' 
                    ? `تاریخ پایان: ${premiumExpiry?.toLocaleDateString()}` 
                    : `Expiry Date: ${premiumExpiry?.toLocaleDateString()}`}
                </p>
              </div>
            </motion.div>
          )}

          {/* App Info */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
            className="bg-gradient-to-br from-orange-500/10 to-amber-500/10 rounded-3xl p-6 border border-orange-200/50"
          >
            <div className="text-center">
              <div className="text-4xl mb-3">❤️</div>
              <h3 className="text-xl mb-2 bg-gradient-to-r from-orange-600 to-amber-600 bg-clip-text text-transparent">
                HealMate v1.0
              </h3>
              <p className="text-gray-600 text-sm">
                {language === 'ps' 
                  ? 'د افغانستان ترټولو بشپړ روغتیا اپلیکیشن' 
                  : language === 'fa' 
                  ? 'کامل‌ترین اپلیکیشن سلامت افغانستان' 
                  : 'Afghanistan\'s Complete Health App'}
              </p>
            </div>
          </motion.div>
        </div>
      </div>
    </div>
  );
}