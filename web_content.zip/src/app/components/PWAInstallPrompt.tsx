import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Download, X, Smartphone, Share, Home } from 'lucide-react';
import { SimpleButton as Button } from './SimpleButton';

interface PWAInstallPromptProps {
  language: 'ps' | 'fa' | 'en';
}

export function PWAInstallPrompt({ language }: PWAInstallPromptProps) {
  const [deferredPrompt, setDeferredPrompt] = useState<any>(null);
  const [showPrompt, setShowPrompt] = useState(false);
  const [isIOS, setIsIOS] = useState(false);
  const [showIOSInstructions, setShowIOSInstructions] = useState(false);
  const [isInstalled, setIsInstalled] = useState(false);

  useEffect(() => {
    // د iOS check کول
    const iOS = /iPad|iPhone|iPod/.test(navigator.userAgent);
    setIsIOS(iOS);

    // Check که اپلیکیشن مخکې نصب شوی وي
    if (window.matchMedia('(display-mode: standalone)').matches) {
      setIsInstalled(true);
      return;
    }

    // د beforeinstallprompt event listener
    const handleBeforeInstall = (e: Event) => {
      console.log('⚡ PWA Install prompt ready');
      e.preventDefault();
      setDeferredPrompt(e);
      
      // که install مخکې reject نه وي شوی، prompt وښایئ
      const installDismissed = localStorage.getItem('healmate_install_dismissed');
      if (!installDismissed) {
        setTimeout(() => setShowPrompt(true), 3000); // 3 ثانیې وروسته
      }
    };

    window.addEventListener('beforeinstallprompt', handleBeforeInstall);

    // د iOS لپاره، که standalone mode کې نه وي
    if (iOS && !window.navigator.standalone) {
      const installDismissed = localStorage.getItem('healmate_install_dismissed');
      if (!installDismissed) {
        setTimeout(() => setShowPrompt(true), 3000);
      }
    }

    return () => {
      window.removeEventListener('beforeinstallprompt', handleBeforeInstall);
    };
  }, []);

  const handleInstallClick = async () => {
    if (!deferredPrompt && !isIOS) {
      return;
    }

    // که iOS وي، د instructions وښایئ
    if (isIOS) {
      setShowIOSInstructions(true);
      return;
    }

    // د Android/Desktop لپاره
    deferredPrompt.prompt();
    const { outcome } = await deferredPrompt.userChoice;
    
    console.log(`User response: ${outcome}`);
    
    if (outcome === 'accepted') {
      console.log('✅ User accepted the install prompt');
      setIsInstalled(true);
    }
    
    setDeferredPrompt(null);
    setShowPrompt(false);
  };

  const handleDismiss = () => {
    setShowPrompt(false);
    localStorage.setItem('healmate_install_dismissed', 'true');
  };

  const translations = {
    ps: {
      title: 'HealMate Install کړئ',
      description: 'د اپلیکیشن د ګړندي رسرسي لپاره، HealMate په خپل فون کې install کړئ',
      install: 'اوس Install کړئ',
      later: 'وروسته',
      iosTitle: 'د iOS لپاره Install کول',
      iosStep1: '۱. د Share بټن وکوهئ',
      iosStep2: '۲. "Add to Home Screen" انتخاب کړئ',
      iosStep3: '۳. "Add" تصدیق کړئ',
      benefits: [
        '🚀 ګړندی رسرسی',
        '📱 د فون په بڼه کار کوي',
        '🔔 د Push خبرتیاوې',
        '💾 Offline کار کوي'
      ]
    },
    fa: {
      title: 'نصب HealMate',
      description: 'برای دسترسی سریع، HealMate را در گوشی خود نصب کنید',
      install: 'اکنون نصب کنید',
      later: 'بعداً',
      iosTitle: 'نصب برای iOS',
      iosStep1: '۱. دکمه Share را بزنید',
      iosStep2: '۲. "Add to Home Screen" را انتخاب کنید',
      iosStep3: '۳. "Add" را تایید کنید',
      benefits: [
        '🚀 دسترسی سریع',
        '📱 مانند اپ کار می‌کند',
        '🔔 اعلان‌های فشاری',
        '💾 آفلاین کار می‌کند'
      ]
    },
    en: {
      title: 'Install HealMate',
      description: 'Install HealMate on your device for quick access',
      install: 'Install Now',
      later: 'Later',
      iosTitle: 'Install for iOS',
      iosStep1: '1. Tap the Share button',
      iosStep2: '2. Select "Add to Home Screen"',
      iosStep3: '3. Confirm "Add"',
      benefits: [
        '🚀 Quick Access',
        '📱 Works like an app',
        '🔔 Push Notifications',
        '💾 Works Offline'
      ]
    }
  };

  const t = translations[language];

  // که مخکې install شوی وي، مه وښایئ
  if (isInstalled) {
    return null;
  }

  // iOS Instructions Modal
  if (showIOSInstructions) {
    return (
      <AnimatePresence>
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-[100] flex items-end justify-center bg-black/50 backdrop-blur-sm p-4"
          onClick={() => setShowIOSInstructions(false)}
        >
          <motion.div
            initial={{ y: 100, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            exit={{ y: 100, opacity: 0 }}
            onClick={(e) => e.stopPropagation()}
            className="w-full max-w-md bg-white rounded-3xl shadow-2xl overflow-hidden"
          >
            {/* Header */}
            <div className="bg-gradient-to-r from-purple-600 to-pink-600 p-6 text-white">
              <div className="flex items-center justify-between mb-2">
                <h3 className="text-2xl font-bold">{t.iosTitle}</h3>
                <button 
                  onClick={() => setShowIOSInstructions(false)}
                  className="p-2 hover:bg-white/20 rounded-full transition-colors"
                >
                  <X className="w-6 h-6" />
                </button>
              </div>
              <p className="text-white/90 text-sm">{t.description}</p>
            </div>

            {/* Instructions */}
            <div className="p-6 space-y-4">
              <div className="flex items-start gap-4 p-4 bg-blue-50 rounded-2xl">
                <div className="w-10 h-10 bg-blue-500 rounded-full flex items-center justify-center flex-shrink-0">
                  <Share className="w-5 h-5 text-white" />
                </div>
                <div>
                  <p className="font-bold text-gray-900">{t.iosStep1}</p>
                  <p className="text-sm text-gray-600">د Safari browser کې لاندې</p>
                </div>
              </div>

              <div className="flex items-start gap-4 p-4 bg-purple-50 rounded-2xl">
                <div className="w-10 h-10 bg-purple-500 rounded-full flex items-center justify-center flex-shrink-0">
                  <Home className="w-5 h-5 text-white" />
                </div>
                <div>
                  <p className="font-bold text-gray-900">{t.iosStep2}</p>
                  <p className="text-sm text-gray-600">له list څخه انتخاب کړئ</p>
                </div>
              </div>

              <div className="flex items-start gap-4 p-4 bg-green-50 rounded-2xl">
                <div className="w-10 h-10 bg-green-500 rounded-full flex items-center justify-center flex-shrink-0">
                  <Download className="w-5 h-5 text-white" />
                </div>
                <div>
                  <p className="font-bold text-gray-900">{t.iosStep3}</p>
                  <p className="text-sm text-gray-600">بس تیار دی! 🎉</p>
                </div>
              </div>

              <Button
                onClick={() => setShowIOSInstructions(false)}
                className="w-full bg-gradient-to-r from-purple-600 to-pink-600 text-white"
              >
                پوهیږم
              </Button>
            </div>
          </motion.div>
        </motion.div>
      </AnimatePresence>
    );
  }

  // Main Install Prompt
  return (
    <AnimatePresence>
      {showPrompt && (
        <motion.div
          initial={{ y: 100, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          exit={{ y: 100, opacity: 0 }}
          className="fixed bottom-20 md:bottom-8 left-4 right-4 md:left-auto md:right-8 z-50 max-w-md"
        >
          <div className="bg-white rounded-3xl shadow-2xl overflow-hidden border border-purple-200">
            {/* Header */}
            <div className="bg-gradient-to-r from-purple-600 to-pink-600 p-6 text-white relative overflow-hidden">
              <div className="absolute top-0 right-0 w-40 h-40 bg-white/10 rounded-full -translate-y-20 translate-x-20"></div>
              <div className="relative z-10">
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-3">
                    <div className="w-12 h-12 bg-white/20 backdrop-blur-xl rounded-2xl flex items-center justify-center">
                      <Smartphone className="w-6 h-6" />
                    </div>
                    <div>
                      <h3 className="text-xl font-bold">{t.title}</h3>
                      <p className="text-white/90 text-sm">{t.description}</p>
                    </div>
                  </div>
                  <button 
                    onClick={handleDismiss}
                    className="p-2 hover:bg-white/20 rounded-full transition-colors"
                  >
                    <X className="w-5 h-5" />
                  </button>
                </div>
              </div>
            </div>

            {/* Benefits */}
            <div className="p-6">
              <div className="grid grid-cols-2 gap-3 mb-6">
                {t.benefits.map((benefit, index) => (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, scale: 0.8 }}
                    animate={{ opacity: 1, scale: 1 }}
                    transition={{ delay: index * 0.1 }}
                    className="bg-gradient-to-br from-purple-50 to-pink-50 rounded-2xl p-3 text-center"
                  >
                    <p className="text-sm font-bold text-gray-800">{benefit}</p>
                  </motion.div>
                ))}
              </div>

              {/* Buttons */}
              <div className="flex gap-3">
                <Button
                  onClick={handleDismiss}
                  variant="outline"
                  className="flex-1 border-gray-300"
                >
                  {t.later}
                </Button>
                <Button
                  onClick={handleInstallClick}
                  className="flex-1 bg-gradient-to-r from-purple-600 to-pink-600 text-white"
                >
                  <Download className="w-4 h-4 mr-2" />
                  {t.install}
                </Button>
              </div>
            </div>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
