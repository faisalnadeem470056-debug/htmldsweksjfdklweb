import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "./ui/avatar";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogFooter } from "./ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select";
import { Calendar } from "./ui/calendar";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs";
import { Separator } from "./ui/separator";
import { Alert, AlertDescription } from "./ui/alert";
import { 
  Calendar as CalendarIcon,
  Clock,
  MapPin,
  User,
  Phone,
  Video,
  AlertCircle,
  CheckCircle2,
  XCircle,
  RefreshCw,
  Trash2,
  Edit3,
  ChevronRight,
  Sparkles,
  Bell,
  History,
  Filter,
  Download,
  Share2,
  MessageSquare,
  Star,
  TrendingUp,
  Heart,
  Activity
} from "lucide-react";
import { useLanguage } from "../contexts/LanguageContext";
import { toast } from "sonner@2.0.3";

interface Appointment {
  id: number;
  doctorName: string;
  doctorImage: string;
  specialty: string;
  type: "video" | "in-person";
  date: string;
  time: string;
  location?: string;
  status: "upcoming" | "completed" | "cancelled";
  canCancel: boolean;
  canReschedule: boolean;
  notes?: string;
  rating?: number;
}

const mockAppointments: Appointment[] = [
  {
    id: 1,
    doctorName: "Dr. Ahmad Naseri",
    doctorImage: "https://images.unsplash.com/photo-1755189118414-14c8dacdb082?w=100&h=100&fit=crop",
    specialty: "Cardiologist",
    type: "video",
    date: "2025-11-18",
    time: "10:00 AM",
    status: "upcoming",
    canCancel: true,
    canReschedule: true,
    notes: "Annual heart checkup"
  },
  {
    id: 2,
    doctorName: "Dr. Fatima Ahmadi",
    doctorImage: "https://images.unsplash.com/photo-1594824476967-48c8b964273f?w=100&h=100&fit=crop",
    specialty: "Dermatologist",
    type: "in-person",
    date: "2025-11-20",
    time: "2:30 PM",
    location: "Kabul Medical Center, Room 305",
    status: "upcoming",
    canCancel: true,
    canReschedule: true
  },
  {
    id: 3,
    doctorName: "Dr. Hassan Karimi",
    doctorImage: "https://images.unsplash.com/photo-1582750433449-648ed127bb54?w=100&h=100&fit=crop",
    specialty: "General Physician",
    type: "in-person",
    date: "2025-11-12",
    time: "9:00 AM",
    location: "City Health Clinic",
    status: "completed",
    canCancel: false,
    canReschedule: false,
    rating: 5
  },
  {
    id: 4,
    doctorName: "Dr. Mariam Hashimi",
    doctorImage: "https://images.unsplash.com/photo-1559839734-2b71ea197ec2?w=100&h=100&fit=crop",
    specialty: "Pediatrician",
    type: "video",
    date: "2025-11-08",
    time: "11:00 AM",
    status: "cancelled",
    canCancel: false,
    canReschedule: false
  },
  {
    id: 5,
    doctorName: "Dr. Omar Safi",
    doctorImage: "https://images.unsplash.com/photo-1612349317150-e413f6a5b16d?w=100&h=100&fit=crop",
    specialty: "Orthopedic",
    type: "in-person",
    date: "2025-11-25",
    time: "3:00 PM",
    location: "Sports Medicine Center",
    status: "upcoming",
    canCancel: true,
    canReschedule: true
  },
];

function AppointmentManagement() {
  const { t } = useLanguage();
  const [appointments, setAppointments] = useState<Appointment[]>(mockAppointments);
  const [activeTab, setActiveTab] = useState("upcoming");
  const [selectedAppointment, setSelectedAppointment] = useState<Appointment | null>(null);
  const [cancelDialogOpen, setCancelDialogOpen] = useState(false);
  const [rescheduleDialogOpen, setRescheduleDialogOpen] = useState(false);
  const [selectedDate, setSelectedDate] = useState<Date | undefined>(new Date());
  const [selectedTime, setSelectedTime] = useState("");
  const [cancelReason, setCancelReason] = useState("");

  // Filter appointments by status
  const upcomingAppointments = appointments.filter(a => a.status === "upcoming");
  const completedAppointments = appointments.filter(a => a.status === "completed");
  const cancelledAppointments = appointments.filter(a => a.status === "cancelled");

  // Available time slots
  const timeSlots = [
    "9:00 AM", "9:30 AM", "10:00 AM", "10:30 AM", "11:00 AM", "11:30 AM",
    "12:00 PM", "2:00 PM", "2:30 PM", "3:00 PM", "3:30 PM", "4:00 PM"
  ];

  const handleCancelAppointment = () => {
    if (selectedAppointment) {
      setAppointments(appointments.map(a => 
        a.id === selectedAppointment.id ? { ...a, status: "cancelled" as const } : a
      ));
      toast.success("Appointment cancelled successfully", {
        description: "We've notified the doctor about the cancellation."
      });
      setCancelDialogOpen(false);
      setSelectedAppointment(null);
      setCancelReason("");
    }
  };

  const handleRescheduleAppointment = () => {
    if (selectedAppointment && selectedDate && selectedTime) {
      const newDate = selectedDate.toISOString().split('T')[0];
      setAppointments(appointments.map(a => 
        a.id === selectedAppointment.id 
          ? { ...a, date: newDate, time: selectedTime } 
          : a
      ));
      toast.success("Appointment rescheduled successfully", {
        description: `New appointment: ${newDate} at ${selectedTime}`
      });
      setRescheduleDialogOpen(false);
      setSelectedAppointment(null);
      setSelectedTime("");
    }
  };

  const AppointmentCard = ({ appointment }: { appointment: Appointment }) => {
    const isPast = new Date(appointment.date) < new Date();
    const statusColors = {
      upcoming: "bg-blue-100 text-blue-700",
      completed: "bg-green-100 text-green-700",
      cancelled: "bg-red-100 text-red-700"
    };

    return (
      <Card className="hover-lift border-0 shadow-lg">
        <CardContent className="p-6">
          {/* Header */}
          <div className="flex items-start justify-between mb-4">
            <div className="flex items-start gap-3 flex-1">
              <Avatar className="w-14 h-14">
                <AvatarImage src={appointment.doctorImage} />
                <AvatarFallback>{appointment.doctorName[0]}</AvatarFallback>
              </Avatar>
              <div className="flex-1">
                <h3 className="text-base text-gray-900 mb-1">{appointment.doctorName}</h3>
                <p className="text-sm text-gray-600 mb-2">{appointment.specialty}</p>
                <Badge className={statusColors[appointment.status]}>
                  {appointment.status === "upcoming" && <Clock className="w-3 h-3 mr-1" />}
                  {appointment.status === "completed" && <CheckCircle2 className="w-3 h-3 mr-1" />}
                  {appointment.status === "cancelled" && <XCircle className="w-3 h-3 mr-1" />}
                  {appointment.status.charAt(0).toUpperCase() + appointment.status.slice(1)}
                </Badge>
              </div>
            </div>
            <Badge variant="outline" className={appointment.type === "video" ? "border-purple-200 bg-purple-50" : "border-blue-200 bg-blue-50"}>
              {appointment.type === "video" ? (
                <><Video className="w-3 h-3 mr-1" /> Video</>
              ) : (
                <><MapPin className="w-3 h-3 mr-1" /> In-Person</>
              )}
            </Badge>
          </div>

          {/* Appointment Details */}
          <div className="space-y-2 mb-4">
            <div className="flex items-center gap-2 text-sm text-gray-700">
              <CalendarIcon className="w-4 h-4 text-blue-600" />
              <span>{new Date(appointment.date).toLocaleDateString('en-US', { 
                weekday: 'long', 
                year: 'numeric', 
                month: 'long', 
                day: 'numeric' 
              })}</span>
            </div>
            <div className="flex items-center gap-2 text-sm text-gray-700">
              <Clock className="w-4 h-4 text-blue-600" />
              <span>{appointment.time}</span>
            </div>
            {appointment.location && (
              <div className="flex items-center gap-2 text-sm text-gray-700">
                <MapPin className="w-4 h-4 text-blue-600" />
                <span>{appointment.location}</span>
              </div>
            )}
            {appointment.notes && (
              <div className="flex items-start gap-2 text-sm text-gray-700">
                <MessageSquare className="w-4 h-4 text-blue-600 mt-0.5" />
                <span className="text-gray-600 italic">{appointment.notes}</span>
              </div>
            )}
          </div>

          <Separator className="mb-4" />

          {/* Actions */}
          <div className="flex flex-wrap gap-2">
            {appointment.status === "upcoming" && (
              <>
                {appointment.type === "video" && (
                  <Button className="bg-gradient-to-r from-purple-500 to-pink-600 hover:from-purple-600 hover:to-pink-700">
                    <Video className="w-4 h-4 mr-2" />
                    Join Call
                  </Button>
                )}
                {appointment.canReschedule && (
                  <Button 
                    variant="outline"
                    onClick={() => {
                      setSelectedAppointment(appointment);
                      setRescheduleDialogOpen(true);
                    }}
                  >
                    <RefreshCw className="w-4 h-4 mr-2" />
                    Reschedule
                  </Button>
                )}
                {appointment.canCancel && (
                  <Button 
                    variant="outline"
                    onClick={() => {
                      setSelectedAppointment(appointment);
                      setCancelDialogOpen(true);
                    }}
                    className="text-red-600 hover:bg-red-50 hover:text-red-700"
                  >
                    <Trash2 className="w-4 h-4 mr-2" />
                    Cancel
                  </Button>
                )}
              </>
            )}
            
            {appointment.status === "completed" && (
              <>
                <Button variant="outline">
                  <Download className="w-4 h-4 mr-2" />
                  Download Report
                </Button>
                {!appointment.rating && (
                  <Button className="bg-gradient-to-r from-amber-500 to-yellow-600">
                    <Star className="w-4 h-4 mr-2" />
                    Rate Doctor
                  </Button>
                )}
                {appointment.rating && (
                  <div className="flex items-center gap-1 px-3 py-2 bg-amber-50 rounded-lg">
                    {[...Array(5)].map((_, i) => (
                      <Star key={i} className={`w-4 h-4 ${i < appointment.rating! ? 'fill-yellow-400 text-yellow-400' : 'text-gray-300'}`} />
                    ))}
                  </div>
                )}
              </>
            )}
            
            {appointment.status === "cancelled" && (
              <Button variant="outline">
                <RefreshCw className="w-4 h-4 mr-2" />
                Book Again
              </Button>
            )}
          </div>
        </CardContent>
      </Card>
    );
  };

  return (
    <section className="py-16 md:py-24 bg-gradient-to-b from-white via-purple-50/30 to-white relative overflow-hidden min-h-screen">
      {/* Background decoration */}
      <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-gradient-to-br from-purple-100/50 to-pink-100/50 rounded-full blur-3xl animate-float"></div>
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        {/* Header */}
        <div className="text-center mb-12 md:mb-16 space-y-4">
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-purple-100 to-pink-100 rounded-full">
            <Sparkles className="w-4 h-4 text-purple-600 animate-pulse-glow" />
            <span className="text-purple-700 text-sm uppercase tracking-wider">Appointments</span>
          </div>
          <h2 className="text-4xl md:text-6xl">
            <span className="bg-gradient-to-r from-purple-600 via-pink-600 to-rose-600 bg-clip-text text-transparent">
              Manage Your Appointments
            </span>
          </h2>
          <p className="text-gray-600 max-w-2xl mx-auto text-lg">
            د ملاقاتونو مدیریت - Schedule, reschedule, or cancel appointments
          </p>
        </div>

        {/* Quick Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <Card className="border-0 shadow-lg hover-lift">
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-2">
                <div className="p-3 bg-gradient-to-br from-blue-500 to-cyan-600 rounded-xl">
                  <Clock className="w-6 h-6 text-white" />
                </div>
                <Badge className="bg-blue-100 text-blue-700">Active</Badge>
              </div>
              <p className="text-3xl text-gray-900 mb-1">{upcomingAppointments.length}</p>
              <p className="text-sm text-gray-600">Upcoming</p>
            </CardContent>
          </Card>

          <Card className="border-0 shadow-lg hover-lift">
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-2">
                <div className="p-3 bg-gradient-to-br from-green-500 to-emerald-600 rounded-xl">
                  <CheckCircle2 className="w-6 h-6 text-white" />
                </div>
                <Badge className="bg-green-100 text-green-700">Done</Badge>
              </div>
              <p className="text-3xl text-gray-900 mb-1">{completedAppointments.length}</p>
              <p className="text-sm text-gray-600">Completed</p>
            </CardContent>
          </Card>

          <Card className="border-0 shadow-lg hover-lift">
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-2">
                <div className="p-3 bg-gradient-to-br from-red-500 to-pink-600 rounded-xl">
                  <XCircle className="w-6 h-6 text-white" />
                </div>
                <Badge className="bg-red-100 text-red-700">Cancelled</Badge>
              </div>
              <p className="text-3xl text-gray-900 mb-1">{cancelledAppointments.length}</p>
              <p className="text-sm text-gray-600">Cancelled</p>
            </CardContent>
          </Card>

          <Card className="border-0 shadow-lg hover-lift">
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-2">
                <div className="p-3 bg-gradient-to-br from-purple-500 to-pink-600 rounded-xl">
                  <TrendingUp className="w-6 h-6 text-white" />
                </div>
                <Badge className="bg-purple-100 text-purple-700">Total</Badge>
              </div>
              <p className="text-3xl text-gray-900 mb-1">{appointments.length}</p>
              <p className="text-sm text-gray-600">All Time</p>
            </CardContent>
          </Card>
        </div>

        {/* Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-3 mb-8">
            <TabsTrigger value="upcoming">
              <Clock className="w-4 h-4 mr-2" />
              Upcoming ({upcomingAppointments.length})
            </TabsTrigger>
            <TabsTrigger value="completed">
              <CheckCircle2 className="w-4 h-4 mr-2" />
              Completed ({completedAppointments.length})
            </TabsTrigger>
            <TabsTrigger value="cancelled">
              <XCircle className="w-4 h-4 mr-2" />
              Cancelled ({cancelledAppointments.length})
            </TabsTrigger>
          </TabsList>

          <TabsContent value="upcoming" className="space-y-6">
            {upcomingAppointments.length === 0 ? (
              <Card className="border-0 shadow-lg">
                <CardContent className="p-12 text-center">
                  <CalendarIcon className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                  <h3 className="text-xl text-gray-900 mb-2">No upcoming appointments</h3>
                  <p className="text-gray-600 mb-6">Schedule your next health checkup</p>
                  <Button className="bg-gradient-to-r from-purple-500 to-pink-600">
                    Book Appointment
                  </Button>
                </CardContent>
              </Card>
            ) : (
              upcomingAppointments.map(appointment => (
                <AppointmentCard key={appointment.id} appointment={appointment} />
              ))
            )}
          </TabsContent>

          <TabsContent value="completed" className="space-y-6">
            {completedAppointments.length === 0 ? (
              <Card className="border-0 shadow-lg">
                <CardContent className="p-12 text-center">
                  <History className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                  <h3 className="text-xl text-gray-900 mb-2">No completed appointments</h3>
                  <p className="text-gray-600">Your appointment history will appear here</p>
                </CardContent>
              </Card>
            ) : (
              completedAppointments.map(appointment => (
                <AppointmentCard key={appointment.id} appointment={appointment} />
              ))
            )}
          </TabsContent>

          <TabsContent value="cancelled" className="space-y-6">
            {cancelledAppointments.length === 0 ? (
              <Card className="border-0 shadow-lg">
                <CardContent className="p-12 text-center">
                  <CheckCircle2 className="w-16 h-16 text-green-300 mx-auto mb-4" />
                  <h3 className="text-xl text-gray-900 mb-2">Great! No cancelled appointments</h3>
                  <p className="text-gray-600">You haven't cancelled any appointments</p>
                </CardContent>
              </Card>
            ) : (
              cancelledAppointments.map(appointment => (
                <AppointmentCard key={appointment.id} appointment={appointment} />
              ))
            )}
          </TabsContent>
        </Tabs>
      </div>

      {/* Cancel Appointment Dialog */}
      <Dialog open={cancelDialogOpen} onOpenChange={setCancelDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle className="text-2xl">Cancel Appointment - ملاقات کنسل کړئ</DialogTitle>
            <DialogDescription>Are you sure you want to cancel this appointment?</DialogDescription>
          </DialogHeader>
          <Alert className="border-yellow-200 bg-yellow-50">
            <AlertCircle className="w-4 h-4 text-yellow-600" />
            <AlertDescription className="text-sm text-yellow-800">
              Are you sure you want to cancel this appointment? This action cannot be undone.
            </AlertDescription>
          </Alert>
          {selectedAppointment && (
            <div className="space-y-4">
              <div className="p-4 bg-gray-50 rounded-lg">
                <div className="flex items-center gap-3 mb-3">
                  <Avatar>
                    <AvatarImage src={selectedAppointment.doctorImage} />
                    <AvatarFallback>{selectedAppointment.doctorName[0]}</AvatarFallback>
                  </Avatar>
                  <div>
                    <p className="text-sm text-gray-900">{selectedAppointment.doctorName}</p>
                    <p className="text-xs text-gray-600">{selectedAppointment.specialty}</p>
                  </div>
                </div>
                <div className="flex items-center gap-2 text-sm text-gray-700">
                  <CalendarIcon className="w-4 h-4" />
                  <span>{selectedAppointment.date} at {selectedAppointment.time}</span>
                </div>
              </div>
              
              <div>
                <label className="text-sm text-gray-700 mb-2 block">
                  Reason for cancellation (optional)
                </label>
                <Select value={cancelReason} onValueChange={setCancelReason}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select a reason" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="emergency">Emergency came up</SelectItem>
                    <SelectItem value="schedule">Schedule conflict</SelectItem>
                    <SelectItem value="feeling-better">Feeling better</SelectItem>
                    <SelectItem value="financial">Financial reasons</SelectItem>
                    <SelectItem value="other">Other</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          )}
          <DialogFooter>
            <Button variant="outline" onClick={() => setCancelDialogOpen(false)}>
              Keep Appointment
            </Button>
            <Button 
              onClick={handleCancelAppointment}
              className="bg-gradient-to-r from-red-500 to-pink-600"
            >
              <Trash2 className="w-4 h-4 mr-2" />
              Cancel Appointment
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Reschedule Appointment Dialog */}
      <Dialog open={rescheduleDialogOpen} onOpenChange={setRescheduleDialogOpen}>
        <DialogContent className="max-w-3xl">
          <DialogHeader>
            <DialogTitle className="text-2xl">Reschedule Appointment - ملاقات بدل کړئ</DialogTitle>
            <DialogDescription>Select a new date and time for your appointment</DialogDescription>
          </DialogHeader>
          {selectedAppointment && (
            <div className="space-y-6">
              <div className="p-4 bg-gradient-to-r from-purple-50 to-pink-50 rounded-lg">
                <div className="flex items-center gap-3">
                  <Avatar>
                    <AvatarImage src={selectedAppointment.doctorImage} />
                    <AvatarFallback>{selectedAppointment.doctorName[0]}</AvatarFallback>
                  </Avatar>
                  <div>
                    <p className="text-sm text-gray-900">{selectedAppointment.doctorName}</p>
                    <p className="text-xs text-gray-600">{selectedAppointment.specialty}</p>
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="text-sm text-gray-700 mb-2 block">
                    Select New Date - نوې نیټه وټاکئ
                  </label>
                  <Calendar
                    mode="single"
                    selected={selectedDate}
                    onSelect={setSelectedDate}
                    disabled={(date) => date < new Date()}
                    className="rounded-lg border"
                  />
                </div>

                <div>
                  <label className="text-sm text-gray-700 mb-2 block">
                    Select New Time - نوې وخت وټاکئ
                  </label>
                  <div className="grid grid-cols-2 gap-2 max-h-[300px] overflow-y-auto">
                    {timeSlots.map((time) => (
                      <Button
                        key={time}
                        variant={selectedTime === time ? "default" : "outline"}
                        onClick={() => setSelectedTime(time)}
                        className={selectedTime === time ? "bg-gradient-to-r from-purple-500 to-pink-600" : ""}
                      >
                        <Clock className="w-4 h-4 mr-2" />
                        {time}
                      </Button>
                    ))}
                  </div>
                </div>
              </div>

              {selectedDate && selectedTime && (
                <Alert className="border-green-200 bg-green-50">
                  <CheckCircle2 className="w-4 h-4 text-green-600" />
                  <AlertDescription className="text-sm text-green-800">
                    New appointment: {selectedDate.toLocaleDateString()} at {selectedTime}
                  </AlertDescription>
                </Alert>
              )}
            </div>
          )}
          <DialogFooter>
            <Button variant="outline" onClick={() => setRescheduleDialogOpen(false)}>
              Cancel
            </Button>
            <Button 
              onClick={handleRescheduleAppointment}
              disabled={!selectedDate || !selectedTime}
              className="bg-gradient-to-r from-purple-500 to-pink-600"
            >
              <RefreshCw className="w-4 h-4 mr-2" />
              Confirm Reschedule
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </section>
  );
}

export default AppointmentManagement;
