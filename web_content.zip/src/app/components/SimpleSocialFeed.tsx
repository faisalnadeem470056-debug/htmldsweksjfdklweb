import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Heart, MessageCircle, Share2, Send, Image as ImageIcon, Trash2, MoreVertical, ThumbsUp, X, Camera, Globe, Lock, Users as UsersIcon, Crown } from 'lucide-react';
import { Button } from './ui/button';
import { Textarea } from './ui/textarea';
import { ImageWithFallback } from './figma/ImageWithFallback';
import { ShareModal } from './ShareModal';
import { PremiumContentLock, PremiumBadge } from './PremiumContentLock';
import { premiumManager } from '../utils/PremiumManager';

interface SimpleSocialFeedProps {
  language: 'ps' | 'fa' | 'en';
  currentUserId: string;
  currentUserName: string;
  currentUserImage: string;
  onNavigateToPremium?: () => void;
}

interface Post {
  id: string;
  userId: string;
  userName: string;
  userImage: string;
  content: string;
  images: string[];
  likes: string[];
  comments: Comment[];
  shares: number;
  timestamp: string;
  privacy: 'public' | 'friends' | 'private';
  isPremium?: boolean; // د Premium posts لپاره
}

interface Comment {
  id: string;
  userId: string;
  userName: string;
  userImage: string;
  content: string;
  timestamp: string;
  likes: string[];
}

export function SimpleSocialFeed({ language, currentUserId, currentUserName, currentUserImage, onNavigateToPremium }: SimpleSocialFeedProps) {
  const [posts, setPosts] = useState<Post[]>([]);
  const [newPostContent, setNewPostContent] = useState('');
  const [showCreatePost, setShowCreatePost] = useState(false);
  const [commentTexts, setCommentTexts] = useState<{ [key: string]: string }>({});
  const [showComments, setShowComments] = useState<{ [key: string]: boolean }>({});
  const [postPrivacy, setPostPrivacy] = useState<'public' | 'friends' | 'private'>('public');
  const [shareModalOpen, setShareModalOpen] = useState(false);
  const [sharingPost, setSharingPost] = useState<Post | null>(null);

  const translations = {
    ps: {
      whatsOnMind: 'تاسو څه فکر کوئ؟',
      createPost: 'پوست جوړ کړئ',
      post: 'خپور کړئ',
      cancel: 'لغوه',
      addPhoto: 'عکس اضافه کړئ',
      like: 'خوښ',
      comment: 'تبصره',
      share: 'شریک',
      likes: 'خوښونه',
      comments: 'تبصرې',
      shares: 'شریکونه',
      writeComment: 'تبصره ولیکئ...',
      send: 'واستوئ',
      delete: 'حذف',
      noPostsYet: 'تراوسه هیڅ پوست نشته',
      startSharing: 'خپل فکرونه شریک کړئ!',
      justNow: 'اوس',
      minutesAgo: 'منټې مخکې',
      hoursAgo: 'ساعتونه مخکې',
      daysAgo: 'ورځې مخکې',
      public: 'عامه',
      friends: 'ملګري',
      private: 'شخصي',
      viewAll: 'ټول وګورئ',
      hide: 'پټول',
      edited: 'سم شوی'
    },
    fa: {
      whatsOnMind: 'به چه فکر می‌کنید؟',
      createPost: 'ایجاد پست',
      post: 'انتشار',
      cancel: 'لغو',
      addPhoto: 'افزودن عکس',
      like: 'پسند',
      comment: 'نظر',
      share: 'اشتراک',
      likes: 'پسندها',
      comments: 'نظرات',
      shares: 'اشتراک‌ها',
      writeComment: 'نظر بنویسید...',
      send: 'ارسال',
      delete: 'حذف',
      noPostsYet: 'هنوز پستی نیست',
      startSharing: 'افکار خود را به اشتراک بگذارید!',
      justNow: 'الان',
      minutesAgo: 'دقیقه پیش',
      hoursAgo: 'ساعت پیش',
      daysAgo: 'روز پیش',
      public: 'عمومی',
      friends: 'دوستان',
      private: 'خصوصی',
      viewAll: 'مشاهده همه',
      hide: 'پنهان',
      edited: 'ویرایش شده'
    },
    en: {
      whatsOnMind: 'What\'s on your mind?',
      createPost: 'Create Post',
      post: 'Post',
      cancel: 'Cancel',
      addPhoto: 'Add Photo',
      like: 'Like',
      comment: 'Comment',
      share: 'Share',
      likes: 'Likes',
      comments: 'Comments',
      shares: 'Shares',
      writeComment: 'Write a comment...',
      send: 'Send',
      delete: 'Delete',
      noPostsYet: 'No posts yet',
      startSharing: 'Start sharing your thoughts!',
      justNow: 'Just now',
      minutesAgo: 'minutes ago',
      hoursAgo: 'hours ago',
      daysAgo: 'days ago',
      public: 'Public',
      friends: 'Friends',
      private: 'Private',
      viewAll: 'View all',
      hide: 'Hide',
      edited: 'Edited'
    }
  };

  const t = translations[language];

  // Load posts from localStorage
  useEffect(() => {
    const savedPosts = localStorage.getItem('healmate_posts');
    if (savedPosts) {
      setPosts(JSON.parse(savedPosts));
    } else {
      // Create initial demo posts (د Premium posts سره)
      const demoPosts: Post[] = [
        {
          id: 'demo-1',
          userId: 'demo-user-1',
          userName: language === 'ps' ? 'احمد خان' : language === 'fa' ? 'احمد خان' : 'Ahmad Khan',
          userImage: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400',
          content: language === 'ps' 
            ? 'سلام! د HealMate په ټولنه کې ښه راغلاست. دا یو عالي اپلیکیشن دی د روغتیا معلوماتو لپاره.' 
            : language === 'fa' 
            ? 'سلام! به انجمن HealMate خوش آمدید. این یک برنامه عالی برای اطلاعات سلامت است.'
            : 'Hello! Welcome to HealMate community. This is a great app for health information.',
          images: [],
          likes: ['demo-user-2', 'demo-user-3'],
          comments: [],
          shares: 5,
          timestamp: new Date(Date.now() - 3600000).toISOString(),
          privacy: 'public',
          isPremium: false
        },
        {
          id: 'demo-premium-1',
          userId: 'dr-premium-1',
          userName: language === 'ps' ? '👑 ډاکټر سعید احمدی' : language === 'fa' ? '👑 دکتر سعید احمدی' : '👑 Dr. Saeed Ahmadi',
          userImage: 'https://images.unsplash.com/photo-1612349317150-e413f6a5b16d?w=400',
          content: language === 'ps'
            ? '🩺 د Premium روغتیا مشوره: د زړه د ساتلو لپاره د صحیح تغذیه، منظم ورزش او د فشار کمولو ترکیب ډیر مهم دی. په هره ورځ لږترلږه 30 منټه پیاده روی وکړئ او د تازه میوو او سابه څخه استفاده وکړئ. د خوب کیفیت هم ډیر مهم دی - لږترلږه 7-8 ساعته خوب ته اړتیا لرئ. که تاسو د زړه کومه مسله لرئ، نو حتماً له خپل ډاکټر سره مشوره وکړئ او د منظم معاینې نه غافل مه شئ. #PremiumHealth #HeartCare'
            : language === 'fa'
            ? '🩺 مشاوره سلامتی پریمیوم: برای حفاظت از قلب، ترکیب تغذیه صحیح، ورزش منظم و کاهش استرس بسیار مهم است. روزانه حداقل 30 دقیقه پیاده‌روی کنید و از میوه‌ها و سبزیجات تازه استفاده کنید. کیفیت خواب نیز بسیار مهم است - حداقل 7-8 ساعت خواب نیاز دارید. اگر مشکل قلبی دارید، حتماً با پزشک خود مشورت کنید و معاینات منظم را فراموش نکنید. #PremiumHealth #HeartCare'
            : '🩺 Premium Health Advice: For heart protection, the combination of proper nutrition, regular exercise, and stress reduction is very important. Walk at least 30 minutes daily and use fresh fruits and vegetables. Sleep quality is also very important - you need at least 7-8 hours of sleep. If you have any heart problems, be sure to consult your doctor and don\'t miss regular check-ups. #PremiumHealth #HeartCare',
          images: ['https://images.unsplash.com/photo-1505751172876-fa1923c5c528?w=800'],
          likes: ['demo-user-1', 'demo-user-2'],
          comments: [],
          shares: 25,
          timestamp: new Date(Date.now() - 5400000).toISOString(),
          privacy: 'public',
          isPremium: true
        },
        {
          id: 'demo-2',
          userId: 'demo-user-2',
          userName: language === 'ps' ? 'ډاکټر فاطمه' : language === 'fa' ? 'دکتر فاطمه' : 'Dr. Fatima',
          userImage: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=400',
          content: language === 'ps'
            ? 'د روغتیا په اړه یو مهم خبرتیا: د ورځې په اوږدو کې لږترلږه 8 ګیلاس اوبه وڅښئ. دا ستاسو د بدن لپاره ډیر مهم دی.'
            : language === 'fa'
            ? 'یک اطلاعیه مهم در مورد سلامتی: حداقل 8 لیوان آب در طول روز بنوشید. این برای بدن شما بسیار مهم است.'
            : 'Important health tip: Drink at least 8 glasses of water throughout the day. It\'s very important for your body.',
          images: ['https://images.unsplash.com/photo-1548839140-29a749e1cf4d?w=800'],
          likes: ['demo-user-1', 'demo-user-3', currentUserId],
          comments: [
            {
              id: 'c1',
              userId: 'demo-user-1',
              userName: language === 'ps' ? 'احمد خان' : language === 'fa' ? 'احمد خان' : 'Ahmad Khan',
              userImage: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400',
              content: language === 'ps' ? 'مننه د مشورې لپاره!' : language === 'fa' ? 'متشکرم از مشاوره!' : 'Thanks for the advice!',
              timestamp: new Date(Date.now() - 1800000).toISOString(),
              likes: []
            }
          ],
          shares: 12,
          timestamp: new Date(Date.now() - 7200000).toISOString(),
          privacy: 'public',
          isPremium: false
        },
        {
          id: 'demo-premium-2',
          userId: 'nutritionist-premium',
          userName: language === 'ps' ? '👑 تغذیه پوهاند مریم' : language === 'fa' ? '👑 متخصص تغذیه مریم' : '👑 Nutritionist Maryam',
          userImage: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=400',
          content: language === 'ps'
            ? '🥗 د Premium تغذیه پلان: د صحتمند وزن ساتلو لپاره، د صبح د ډوډۍ نه غفلت مه کوئ! یو مثالي صبح ډوډی: د جوارو ګولۍ + یو کیله + ملا شیدې + یو څه وچ میوې. دا ترکیب ستاسو ته د ورځې لپاره انرژي درکوي او ستاسو میتابولیزم هم ښه کوي. د ورځې په اوږدو کې 5-6 کوچني ډوډۍ د 3 لویو څخه ښه ده. #HealthyEating #PremiumNutrition'
            : language === 'fa'
            ? '🥗 برنامه تغذیه پریمیوم: برای حفظ وزن سالم، از غذای صبحانه غافل نشوید! یک صبحانه ایده‌آل: پورج جو دوسر + یک موز + شیر + مقداری میوه خشک. این ترکیب به شما انرژی روزانه می‌دهد و متابولیسم شما را نیز بهبود می‌بخشد. 5-6 وعده کوچک در طول روز بهتر از 3 وعده بزرگ است. #HealthyEating #PremiumNutrition'
            : '🥗 Premium Nutrition Plan: For healthy weight maintenance, don\'t skip breakfast! An ideal breakfast: Oatmeal + One banana + Milk + Some dried fruits. This combination gives you daily energy and also improves your metabolism. 5-6 small meals throughout the day are better than 3 large meals. #HealthyEating #PremiumNutrition',
          images: ['https://images.unsplash.com/photo-1490645935967-10de6ba17061?w=800'],
          likes: [],
          comments: [],
          shares: 18,
          timestamp: new Date(Date.now() - 10800000).toISOString(),
          privacy: 'public',
          isPremium: true
        }
      ];
      setPosts(demoPosts);
      localStorage.setItem('healmate_posts', JSON.stringify(demoPosts));
    }
  }, []);

  // Save posts to localStorage
  useEffect(() => {
    if (posts.length > 0) {
      localStorage.setItem('healmate_posts', JSON.stringify(posts));
    }
  }, [posts]);

  const handleCreatePost = () => {
    if (!newPostContent.trim()) return;

    const newPost: Post = {
      id: `post-${Date.now()}`,
      userId: currentUserId,
      userName: currentUserName,
      userImage: currentUserImage,
      content: newPostContent,
      images: [],
      likes: [],
      comments: [],
      shares: 0,
      timestamp: new Date().toISOString(),
      privacy: postPrivacy
    };

    setPosts([newPost, ...posts]);
    setNewPostContent('');
    setShowCreatePost(false);
    setPostPrivacy('public');
  };

  const handleLike = (postId: string) => {
    setPosts(posts.map(post => {
      if (post.id === postId) {
        const hasLiked = post.likes.includes(currentUserId);
        return {
          ...post,
          likes: hasLiked 
            ? post.likes.filter(id => id !== currentUserId)
            : [...post.likes, currentUserId]
        };
      }
      return post;
    }));
  };

  const handleComment = (postId: string) => {
    const commentText = commentTexts[postId];
    if (!commentText?.trim()) return;

    setPosts(posts.map(post => {
      if (post.id === postId) {
        const newComment: Comment = {
          id: `comment-${Date.now()}`,
          userId: currentUserId,
          userName: currentUserName,
          userImage: currentUserImage,
          content: commentText,
          timestamp: new Date().toISOString(),
          likes: []
        };
        return {
          ...post,
          comments: [...post.comments, newComment]
        };
      }
      return post;
    }));

    setCommentTexts({ ...commentTexts, [postId]: '' });
  };

  const handleDeletePost = (postId: string) => {
    if (confirm(t.delete + '?')) {
      setPosts(posts.filter(post => post.id !== postId));
    }
  };

  const handleShare = (postId: string) => {
    const post = posts.find(p => p.id === postId);
    if (post) {
      setSharingPost(post);
      setShareModalOpen(true);
      
      // Increment share count
      setPosts(posts.map(p => {
        if (p.id === postId) {
          return { ...p, shares: p.shares + 1 };
        }
        return p;
      }));
    }
  };

  const formatTime = (timestamp: string) => {
    const now = new Date();
    const time = new Date(timestamp);
    const diff = Math.floor((now.getTime() - time.getTime()) / 1000);

    if (diff < 60) return t.justNow;
    if (diff < 3600) return `${Math.floor(diff / 60)} ${t.minutesAgo}`;
    if (diff < 86400) return `${Math.floor(diff / 3600)} ${t.hoursAgo}`;
    return `${Math.floor(diff / 86400)} ${t.daysAgo}`;
  };

  const toggleComments = (postId: string) => {
    setShowComments({
      ...showComments,
      [postId]: !showComments[postId]
    });
  };

  // د user premium status چک کړئ
  const isPremiumUser = premiumManager.isPremium(currentUserId);

  // د post access determine کړئ
  const canAccessPost = (post: Post) => {
    // که post premium نه دی، ټول access لري
    if (!post.isPremium) return true;
    
    // که post premium دی، یوازې premium users access لري
    return isPremiumUser;
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-purple-50 pb-20">
      {/* Header */}
      <div className="sticky top-0 z-30 backdrop-blur-xl bg-white/80 border-b border-gray-200 shadow-sm">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <MessageCircle className="w-8 h-8 text-blue-600" />
              <div>
                <h1 className="text-2xl bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
                  {language === 'ps' ? 'د ټولنې' : language === 'fa' ? 'انجمن' : 'Community'}
                </h1>
                <p className="text-sm text-gray-600">
                  {language === 'ps' ? 'خپل تجربې شریک کړئ' : language === 'fa' ? 'تجربیات خود را به اشتراک بگذارید' : 'Share your experiences'}
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-6 max-w-2xl">
        {/* Create Post Card */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white rounded-3xl shadow-xl p-6 mb-6 border border-gray-100"
        >
          <div className="flex items-center gap-3 mb-4">
            <div className="w-12 h-12 rounded-full bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center text-white overflow-hidden">
              <ImageWithFallback 
                src={currentUserImage} 
                alt={currentUserName}
                className="w-full h-full object-cover"
              />
            </div>
            <button
              onClick={() => setShowCreatePost(true)}
              className="flex-1 text-right bg-gray-100 hover:bg-gray-200 rounded-full px-6 py-3 text-gray-600 transition-all"
            >
              {t.whatsOnMind}
            </button>
          </div>

          <div className="flex items-center justify-around pt-4 border-t border-gray-100">
            <button className="flex items-center gap-2 px-4 py-2 hover:bg-gray-50 rounded-lg transition-all">
              <Camera className="w-5 h-5 text-green-600" />
              <span className="text-sm text-gray-700">{t.addPhoto}</span>
            </button>
          </div>
        </motion.div>

        {/* Create Post Modal */}
        <AnimatePresence>
          {showCreatePost && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4"
              onClick={() => setShowCreatePost(false)}
            >
              <motion.div
                initial={{ scale: 0.9, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                exit={{ scale: 0.9, opacity: 0 }}
                onClick={(e) => e.stopPropagation()}
                className="bg-white rounded-3xl shadow-2xl max-w-lg w-full max-h-[90vh] overflow-y-auto"
              >
                <div className="sticky top-0 bg-white border-b border-gray-200 p-4 flex items-center justify-between rounded-t-3xl">
                  <h2 className="text-xl">{t.createPost}</h2>
                  <Button variant="ghost" size="icon" onClick={() => setShowCreatePost(false)}>
                    <X className="w-5 h-5" />
                  </Button>
                </div>

                <div className="p-6">
                  <div className="flex items-center gap-3 mb-4">
                    <div className="w-12 h-12 rounded-full bg-gradient-to-br from-blue-500 to-purple-600 overflow-hidden">
                      <ImageWithFallback 
                        src={currentUserImage} 
                        alt={currentUserName}
                        className="w-full h-full object-cover"
                      />
                    </div>
                    <div>
                      <p className="font-medium">{currentUserName}</p>
                      <div className="flex items-center gap-2 text-sm text-gray-600">
                        <select 
                          value={postPrivacy}
                          onChange={(e) => setPostPrivacy(e.target.value as any)}
                          className="border border-gray-300 rounded-lg px-2 py-1"
                        >
                          <option value="public">{t.public}</option>
                          <option value="friends">{t.friends}</option>
                          <option value="private">{t.private}</option>
                        </select>
                      </div>
                    </div>
                  </div>

                  <Textarea
                    value={newPostContent}
                    onChange={(e) => setNewPostContent(e.target.value)}
                    placeholder={t.whatsOnMind}
                    className="min-h-[150px] text-lg border-0 focus:ring-0 resize-none"
                    dir={language === 'en' ? 'ltr' : 'rtl'}
                  />

                  <div className="flex gap-2 mt-4">
                    <Button
                      onClick={handleCreatePost}
                      disabled={!newPostContent.trim()}
                      className="flex-1 bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700"
                    >
                      {t.post}
                    </Button>
                    <Button
                      variant="outline"
                      onClick={() => setShowCreatePost(false)}
                    >
                      {t.cancel}
                    </Button>
                  </div>
                </div>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Posts Feed */}
        <div className="space-y-6">
          {posts.length === 0 ? (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="bg-white rounded-3xl shadow-xl p-12 text-center"
            >
              <MessageCircle className="w-16 h-16 text-gray-300 mx-auto mb-4" />
              <h3 className="text-xl text-gray-600 mb-2">{t.noPostsYet}</h3>
              <p className="text-gray-500">{t.startSharing}</p>
            </motion.div>
          ) : (
            posts.map((post, index) => {
              const hasAccess = canAccessPost(post);
              
              return (
              <motion.div
                key={post.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                className="bg-white rounded-3xl shadow-xl overflow-hidden border border-gray-100"
              >
                <PremiumContentLock
                  language={language}
                  onUpgrade={() => onNavigateToPremium?.()}
                  contentType="post"
                  isLocked={!hasAccess}
                >
                  {/* Post Header */}
                  <div className="p-6 pb-3">
                    <div className="flex items-center justify-between mb-4">
                      <div className="flex items-center gap-3">
                        <div className="w-12 h-12 rounded-full bg-gradient-to-br from-blue-500 to-purple-600 overflow-hidden">
                          <ImageWithFallback 
                            src={post.userImage} 
                            alt={post.userName}
                            className="w-full h-full object-cover"
                          />
                        </div>
                        <div>
                          <div className="flex items-center gap-2">
                            <p className="font-semibold">{post.userName}</p>
                            {post.isPremium && <PremiumBadge language={language} size="xs" />}
                          </div>
                          <div className="flex items-center gap-2 text-sm text-gray-500">
                            <span>{formatTime(post.timestamp)}</span>
                            <span>•</span>
                            {post.privacy === 'public' && <Globe className="w-3 h-3" />}
                            {post.privacy === 'friends' && <UsersIcon className="w-3 h-3" />}
                            {post.privacy === 'private' && <Lock className="w-3 h-3" />}
                          </div>
                        </div>
                      </div>
                      {post.userId === currentUserId && (
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => handleDeletePost(post.id)}
                        >
                          <Trash2 className="w-4 h-4 text-red-600" />
                        </Button>
                      )}
                    </div>

                    {/* Post Content */}
                    <p className="text-gray-800 mb-4 whitespace-pre-wrap" dir={language === 'en' ? 'ltr' : 'rtl'}>
                      {post.content}
                    </p>

                    {/* Post Images */}
                    {post.images.length > 0 && (
                      <div className="grid grid-cols-1 gap-2 mb-4">
                        {post.images.map((image, idx) => (
                          <div key={idx} className="rounded-2xl overflow-hidden">
                            <ImageWithFallback 
                              src={image} 
                              alt="Post"
                              className="w-full h-auto"
                            />
                          </div>
                        ))}
                      </div>
                    )}

                    {/* Stats */}
                    <div className="flex items-center justify-between text-sm text-gray-600 pt-3 border-t border-gray-100">
                      <span>{post.likes.length} {t.likes}</span>
                      <div className="flex items-center gap-3">
                        <button onClick={() => toggleComments(post.id)}>
                          {post.comments.length} {t.comments}
                        </button>
                        <span>{post.shares} {t.shares}</span>
                      </div>
                    </div>
                  </div>

                  {/* Actions */}
                  <div className="border-t border-gray-100 px-6 py-2 flex items-center justify-around">
                    <button
                      onClick={() => handleLike(post.id)}
                      className={`flex items-center gap-2 px-4 py-2 rounded-lg transition-all ${
                        post.likes.includes(currentUserId)
                          ? 'text-blue-600 bg-blue-50'
                          : 'text-gray-600 hover:bg-gray-50'
                      }`}
                    >
                      <ThumbsUp className={`w-5 h-5 ${post.likes.includes(currentUserId) ? 'fill-current' : ''}`} />
                      <span>{t.like}</span>
                    </button>
                    <button
                      onClick={() => toggleComments(post.id)}
                      className="flex items-center gap-2 px-4 py-2 rounded-lg text-gray-600 hover:bg-gray-50 transition-all"
                    >
                      <MessageCircle className="w-5 h-5" />
                      <span>{t.comment}</span>
                    </button>
                    <button
                      onClick={() => handleShare(post.id)}
                      className="flex items-center gap-2 px-4 py-2 rounded-lg text-gray-600 hover:bg-gray-50 transition-all"
                    >
                      <Share2 className="w-5 h-5" />
                      <span>{t.share}</span>
                    </button>
                  </div>

                  {/* Comments Section */}
                  <AnimatePresence>
                    {showComments[post.id] && (
                      <motion.div
                        initial={{ height: 0, opacity: 0 }}
                        animate={{ height: 'auto', opacity: 1 }}
                        exit={{ height: 0, opacity: 0 }}
                        className="border-t border-gray-100 bg-gray-50"
                      >
                        {/* Comments List */}
                        <div className="px-6 py-4 space-y-4 max-h-96 overflow-y-auto">
                          {post.comments.map((comment) => (
                            <div key={comment.id} className="flex gap-3">
                              <div className="w-10 h-10 rounded-full bg-gradient-to-br from-blue-500 to-purple-600 overflow-hidden flex-shrink-0">
                                <ImageWithFallback 
                                  src={comment.userImage} 
                                  alt={comment.userName}
                                  className="w-full h-full object-cover"
                                />
                              </div>
                              <div className="flex-1">
                                <div className="bg-white rounded-2xl px-4 py-2 shadow-sm">
                                  <p className="font-medium text-sm mb-1">{comment.userName}</p>
                                  <p className="text-gray-800" dir={language === 'en' ? 'ltr' : 'rtl'}>
                                    {comment.content}
                                  </p>
                                </div>
                                <div className="flex items-center gap-4 mt-1 px-2 text-sm text-gray-500">
                                  <span>{formatTime(comment.timestamp)}</span>
                                </div>
                              </div>
                            </div>
                          ))}
                        </div>

                        {/* Add Comment */}
                        <div className="px-6 py-4 border-t border-gray-200">
                          <div className="flex gap-3">
                            <div className="w-10 h-10 rounded-full bg-gradient-to-br from-blue-500 to-purple-600 overflow-hidden flex-shrink-0">
                              <ImageWithFallback 
                                src={currentUserImage} 
                                alt={currentUserName}
                                className="w-full h-full object-cover"
                              />
                            </div>
                            <div className="flex-1 flex gap-2">
                              <input
                                type="text"
                                value={commentTexts[post.id] || ''}
                                onChange={(e) => setCommentTexts({ ...commentTexts, [post.id]: e.target.value })}
                                onKeyPress={(e) => e.key === 'Enter' && handleComment(post.id)}
                                placeholder={t.writeComment}
                                className="flex-1 bg-white border border-gray-200 rounded-full px-4 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                                dir={language === 'en' ? 'ltr' : 'rtl'}
                              />
                              <Button
                                size="icon"
                                onClick={() => handleComment(post.id)}
                                disabled={!commentTexts[post.id]?.trim()}
                                className="rounded-full bg-gradient-to-r from-blue-500 to-purple-600"
                              >
                                <Send className="w-4 h-4" />
                              </Button>
                            </div>
                          </div>
                        </div>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </PremiumContentLock>
              </motion.div>
            );
            })
          )}
        </div>
      </div>

      {/* Share Modal */}
      <ShareModal
        isOpen={shareModalOpen}
        onClose={() => {
          setShareModalOpen(false);
          setSharingPost(null);
        }}
        language={language}
        shareContent={{
          title: sharingPost ? `${sharingPost.userName}: ${sharingPost.content.slice(0, 100)}...` : 'HealMate Post',
          description: sharingPost?.content || '',
          url: window.location.href
        }}
      />
    </div>
  );
}