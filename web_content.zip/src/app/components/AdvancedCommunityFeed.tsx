import { useState } from 'react';
import { ArrowLeft, Heart, MessageCircle, Share2, Send, Image, Video, Crown, TrendingUp, Clock, Fire, Award, Users, Filter, Search, Plus, BookmarkPlus, Flag } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { Button } from './ui/button';
import { Textarea } from './ui/textarea';
import { Input } from './ui/input';
import { Badge } from './ui/badge';
import { Tabs, TabsList, TabsTrigger, TabsContent } from './ui/tabs';
import { Card } from './ui/card';
import { Avatar } from './ui/avatar';
import { translations } from '../translations';
import { AdBanner } from './AdBanner';
import { ShareModal } from './ShareModal';

interface AdvancedCommunityFeedProps {
  language: 'ps' | 'fa' | 'en';
  onBack: () => void;
}

const categories = [
  { id: 'all', icon: Users, label: { ps: 'ټول', fa: 'همه', en: 'All' }, color: 'from-blue-500 to-cyan-500' },
  { id: 'diabetes', icon: Activity, label: { ps: 'ډایبېټس', fa: 'دیابت', en: 'Diabetes' }, color: 'from-red-500 to-orange-500' },
  { id: 'heart', icon: Heart, label: { ps: 'زړه', fa: 'قلب', en: 'Heart' }, color: 'from-pink-500 to-rose-500' },
  { id: 'mental', icon: Brain, label: { ps: 'ذهني', fa: 'ذهنی', en: 'Mental' }, color: 'from-purple-500 to-indigo-500' },
  { id: 'nutrition', icon: Salad, label: { ps: 'تغذیه', fa: 'تغذیه', en: 'Nutrition' }, color: 'from-green-500 to-emerald-500' },
  { id: 'fitness', icon: Dumbbell, label: { ps: 'ورزش', fa: 'ورزش', en: 'Fitness' }, color: 'from-orange-500 to-amber-500' },
];

const premiumPosts = [
  {
    id: 'p1',
    author: { ps: 'ډاکټر احمد زی', fa: 'دکتر احمد حسینی', en: 'Dr. Ahmad Hosseini' },
    avatar: '👨‍⚕️',
    verified: true,
    specialty: { ps: 'د زړه متخصص', fa: 'متخصص قلب', en: 'Cardiologist' },
    content: {
      ps: 'د زړه ناروغیو مخنیوی: ۵ مهم ګامونه چې باید هره ورځ یې پلي کړئ',
      fa: 'پیشگیری از بیماری‌های قلبی: ۵ گام مهم که باید هر روز انجام دهید',
      en: '5 Essential Steps for Heart Disease Prevention You Should Follow Daily',
    },
    image: 'https://images.unsplash.com/photo-1628348068343-c6a848d2b6dd?w=800',
    category: 'heart',
    likes: 234,
    comments: 45,
    shares: 67,
    timestamp: '3h ago',
    isPremium: true,
  },
  {
    id: 'p2',
    author: { ps: 'ډاکټر فاطمه کریمي', fa: 'دکتر فاطمه کریمی', en: 'Dr. Fatima Karimi' },
    avatar: '👩‍⚕️',
    verified: true,
    specialty: { ps: 'د تغذیې متخصص', fa: 'متخصص تغذیه', en: 'Nutritionist' },
    content: {
      ps: 'د صحي غذا ۷ ورځنۍ پلان - وزن کمول او انرژي زیاتول',
      fa: 'برنامه غذایی ۷ روزه سالم - کاهش وزن و افزایش انرژی',
      en: '7-Day Healthy Meal Plan - Weight Loss & Energy Boost',
    },
    image: 'https://images.unsplash.com/photo-1490645935967-10de6ba17061?w=800',
    category: 'nutrition',
    likes: 189,
    comments: 34,
    shares: 52,
    timestamp: '5h ago',
    isPremium: true,
  },
];

const initialPosts = [
  {
    id: 1,
    author: { ps: 'احمد حسن', fa: 'احمد حسن', en: 'Ahmad Hassan' },
    avatar: '👨',
    content: {
      ps: 'زه د ډایبېټس سره مخ یم. ایا چا ښه مشوره لري؟ د خوراک کوم پلان سپارښتنه کوئ؟',
      fa: 'من با دیابت مواجه هستم. آیا کسی مشوره خوبی دارد؟ چه برنامه غذایی پیشنهاد می‌کنید؟',
      en: 'I\'m dealing with diabetes. Does anyone have good advice? What diet plan do you recommend?',
    },
    category: 'diabetes',
    likes: 45,
    comments: 23,
    shares: 8,
    timestamp: '2h ago',
    isPremium: false,
  },
  {
    id: 2,
    author: { ps: 'فاطمه علي', fa: 'فاطمه علی', en: 'Fatima Ali' },
    avatar: '👩',
    content: {
      ps: 'د زړه روغتیا لپاره منظم ورزش خورا مهم دی. زه هره ورځ ۳۰ دقیقې ګرځم او خورا ښه احساس کوم!',
      fa: 'ورزش منظم برای سلامت قلب بسیار مهم است. من هر روز ۳۰ دقیقه پیاده‌روی می‌کنم و احساس خیلی خوبی دارم!',
      en: 'Regular exercise is very important for heart health. I walk 30 minutes every day and feel great!',
    },
    category: 'heart',
    image: 'https://images.unsplash.com/photo-1476480862126-209bfaa8edc8?w=800',
    likes: 78,
    comments: 15,
    shares: 12,
    timestamp: '5h ago',
    isPremium: false,
  },
  {
    id: 3,
    author: { ps: 'محمد کریم', fa: 'محمد کریم', en: 'Mohammad Karim' },
    avatar: '👨',
    content: {
      ps: 'د خوب کمښت زما لپاره لویه ستونزه ده. څوک مرسته کولی شي؟ د شپې ساعت ۳ بجو راویښیږم.',
      fa: 'کمبود خواب برای من مشکل بزرگی است. کسی می‌تواند کمک کند؟ ساعت ۳ شب بیدار می‌شوم.',
      en: 'Sleep deprivation is a big problem for me. Can anyone help? I wake up at 3 AM every night.',
    },
    category: 'mental',
    likes: 34,
    comments: 28,
    shares: 5,
    timestamp: '1d ago',
    isPremium: false,
  },
  {
    id: 4,
    author: { ps: 'زینب احمد', fa: 'زینب احمد', en: 'Zainab Ahmad' },
    avatar: '👩',
    content: {
      ps: 'د ورزش ۳۰ ورځنۍ چلنج پای ته رسول! ۵ کیلو وزن کم شو او انرژي یې ډېر زیات شو. تاسو هم کولی شئ!',
      fa: 'چالش ۳۰ روزه ورزشی را به پایان رساندم! ۵ کیلو وزن کم کردم و انرژی خیلی زیاد شد. شما هم می‌توانید!',
      en: 'Completed the 30-day fitness challenge! Lost 5kg and energy levels are through the roof. You can do it too!',
    },
    category: 'fitness',
    image: 'https://images.unsplash.com/photo-1517836357463-d25dfeac3438?w=800',
    likes: 156,
    comments: 42,
    shares: 34,
    timestamp: '2d ago',
    isPremium: false,
  },
  {
    id: 5,
    author: { ps: 'عمر خان', fa: 'عمر خان', en: 'Omar Khan' },
    avatar: '👨',
    content: {
      ps: 'د سبزیجاتو او میوو خوړل خورا مهم دی. زه یو ښه smoothie ترکیب شریکوم: سپنڅلي، کیله، بادام شیدې...',
      fa: 'خوردن سبزیجات و میوه‌ها خیلی مهم است. یک ترکیب اسموتی عالی به اشتراک می‌گذارم: اسفناج، موز، شیر بادام...',
      en: 'Eating vegetables and fruits is crucial. Sharing a great smoothie recipe: spinach, banana, almond milk...',
    },
    category: 'nutrition',
    likes: 91,
    comments: 19,
    shares: 27,
    timestamp: '3d ago',
    isPremium: false,
  },
];

export function AdvancedCommunityFeed({ language, onBack }: AdvancedCommunityFeedProps) {
  const [posts, setPosts] = useState(initialPosts);
  const [newPost, setNewPost] = useState('');
  const [showNewPost, setShowNewPost] = useState(false);
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [activeTab, setActiveTab] = useState('trending');
  const [searchQuery, setSearchQuery] = useState('');
  const [shareModalOpen, setShareModalOpen] = useState(false);
  const [sharingPost, setSharingPost] = useState<any>(null);
  
  const t = translations[language];

  const handleSubmitPost = () => {
    if (newPost.trim()) {
      const post = {
        id: Date.now(),
        author: { ps: 'تاسو', fa: 'شما', en: 'You' },
        avatar: '👤',
        content: { ps: newPost, fa: newPost, en: newPost },
        category: selectedCategory === 'all' ? 'general' : selectedCategory,
        likes: 0,
        comments: 0,
        shares: 0,
        timestamp: 'Just now',
        isPremium: false,
      };
      setPosts([post, ...posts]);
      setNewPost('');
      setShowNewPost(false);
    }
  };

  const handleLike = (postId: number | string) => {
    setPosts(posts.map(post =>
      post.id === postId ? { ...post, likes: post.likes + 1 } : post
    ));
  };

  const filteredPosts = posts.filter(post => {
    const matchesCategory = selectedCategory === 'all' || post.category === selectedCategory;
    const matchesSearch = searchQuery === '' || 
      post.content[language].toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  const allPosts = activeTab === 'premium' ? premiumPosts : [...premiumPosts, ...filteredPosts];

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-pink-50 to-rose-50 pb-28 md:pb-8">
      {/* Header */}
      <div className="sticky top-0 z-40 backdrop-blur-xl bg-white/80 border-b border-white/20 shadow-lg">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center gap-4">
            <Button variant="ghost" size="icon" onClick={onBack}>
              <ArrowLeft className="w-5 h-5" />
            </Button>
            <div className="flex-1">
              <h1 className="text-2xl bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent">
                {language === 'ps' ? 'ټولنیز فیډ' : language === 'fa' ? 'فید اجتماعی' : 'Community Feed'}
              </h1>
              <p className="text-sm text-gray-600">
                {allPosts.length} {language === 'ps' ? 'پوستونه' : language === 'fa' ? 'پست' : 'Posts'}
              </p>
            </div>
            <Button 
              onClick={() => setShowNewPost(true)}
              className="bg-gradient-to-r from-purple-600 to-pink-600 text-white"
            >
              <Plus className="w-5 h-5 mr-2" />
              {language === 'ps' ? 'نوی پوست' : language === 'fa' ? 'پست جدید' : 'New Post'}
            </Button>
          </div>

          {/* Search Bar */}
          <div className="mt-4">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
              <Input
                type="text"
                placeholder={language === 'ps' ? 'لټون...' : language === 'fa' ? 'جستجو...' : 'Search...'}
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10 bg-white/50 border-white/20"
              />
            </div>
          </div>

          {/* Tabs */}
          <Tabs value={activeTab} onValueChange={setActiveTab} className="mt-4">
            <TabsList className="grid w-full grid-cols-3 bg-white/50">
              <TabsTrigger value="trending" className="flex items-center gap-2">
                <TrendingUp className="w-4 h-4" />
                {language === 'ps' ? 'مشهور' : language === 'fa' ? 'محبوب' : 'Trending'}
              </TabsTrigger>
              <TabsTrigger value="recent" className="flex items-center gap-2">
                <Clock className="w-4 h-4" />
                {language === 'ps' ? 'تازه' : language === 'fa' ? 'جدید' : 'Recent'}
              </TabsTrigger>
              <TabsTrigger value="premium" className="flex items-center gap-2">
                <Crown className="w-4 h-4 text-amber-500" />
                {language === 'ps' ? 'پریمیم' : language === 'fa' ? 'ویژه' : 'Premium'}
              </TabsTrigger>
            </TabsList>
          </Tabs>
        </div>
      </div>

      <div className="container mx-auto px-4 py-6">
        {/* Categories */}
        <div className="mb-6 overflow-x-auto pb-4">
          <div className="flex gap-3 min-w-max">
            {categories.map((cat) => {
              const Icon = cat.icon;
              const isActive = selectedCategory === cat.id;
              return (
                <motion.button
                  key={cat.id}
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  onClick={() => setSelectedCategory(cat.id)}
                  className={`flex items-center gap-2 px-4 py-2 rounded-full transition-all ${
                    isActive
                      ? `bg-gradient-to-r ${cat.color} text-white shadow-lg`
                      : 'bg-white/70 text-gray-700 hover:bg-white'
                  }`}
                >
                  <Icon className="w-4 h-4" />
                  <span className="text-sm whitespace-nowrap">{cat.label[language]}</span>
                </motion.button>
              );
            })}
          </div>
        </div>

        <AdBanner type="medium" className="mb-6" />

        {/* New Post Modal */}
        <AnimatePresence>
          {showNewPost && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4"
              onClick={() => setShowNewPost(false)}
            >
              <motion.div
                initial={{ scale: 0.9, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                exit={{ scale: 0.9, opacity: 0 }}
                onClick={(e) => e.stopPropagation()}
                className="bg-white rounded-3xl p-6 max-w-lg w-full shadow-2xl"
              >
                <h2 className="text-2xl mb-4">
                  {language === 'ps' ? 'نوی پوست' : language === 'fa' ? 'پست جدید' : 'New Post'}
                </h2>
                <Textarea
                  value={newPost}
                  onChange={(e) => setNewPost(e.target.value)}
                  placeholder={language === 'ps' ? 'خپل پوست ولیکئ...' : language === 'fa' ? 'پست خود را بنویسید...' : 'Write your post...'}
                  className="min-h-[150px] mb-4"
                />
                <div className="flex gap-2">
                  <Button
                    onClick={handleSubmitPost}
                    className="flex-1 bg-gradient-to-r from-purple-600 to-pink-600 text-white"
                  >
                    <Send className="w-4 h-4 mr-2" />
                    {language === 'ps' ? 'خپرول' : language === 'fa' ? 'انتشار' : 'Post'}
                  </Button>
                  <Button variant="outline" onClick={() => setShowNewPost(false)}>
                    {language === 'ps' ? 'لغوه' : language === 'fa' ? 'لغو' : 'Cancel'}
                  </Button>
                </div>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Posts Feed */}
        <div className="space-y-6">
          {allPosts.map((post) => (
            <motion.div
              key={post.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className={`bg-white/90 backdrop-blur-xl rounded-3xl p-6 shadow-xl hover:shadow-2xl transition-all border ${
                post.isPremium ? 'border-amber-400 bg-gradient-to-br from-amber-50/50 to-white/90' : 'border-white/20'
              }`}
            >
              {/* Post Header */}
              <div className="flex items-start justify-between mb-4">
                <div className="flex items-center gap-3">
                  <div className="text-4xl">{post.avatar}</div>
                  <div>
                    <div className="flex items-center gap-2">
                      <h3 className="font-semibold">{post.author[language]}</h3>
                      {post.isPremium && (
                        <Crown className="w-4 h-4 text-amber-500 fill-amber-500" />
                      )}
                    </div>
                    {post.specialty && (
                      <p className="text-sm text-gray-600">{post.specialty[language]}</p>
                    )}
                    <p className="text-xs text-gray-500">{post.timestamp}</p>
                  </div>
                </div>
                {post.isPremium && (
                  <Badge className="bg-gradient-to-r from-amber-500 to-orange-500 text-white">
                    {language === 'ps' ? 'پریمیم' : language === 'fa' ? 'ویژه' : 'Premium'}
                  </Badge>
                )}
              </div>

              {/* Post Content */}
              <p className="text-gray-800 mb-4 leading-relaxed">{post.content[language]}</p>

              {/* Post Image */}
              {post.image && (
                <div className="mb-4 rounded-2xl overflow-hidden">
                  <img 
                    src={post.image} 
                    alt="Post" 
                    className="w-full h-64 object-cover"
                  />
                </div>
              )}

              {/* Post Actions */}
              <div className="flex items-center justify-between pt-4 border-t border-gray-200">
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => handleLike(post.id)}
                  className="flex items-center gap-2 hover:text-red-600"
                >
                  <Heart className="w-5 h-5" />
                  <span>{post.likes}</span>
                </Button>
                <Button variant="ghost" size="sm" className="flex items-center gap-2 hover:text-blue-600">
                  <MessageCircle className="w-5 h-5" />
                  <span>{post.comments}</span>
                </Button>
                <Button 
                  variant="ghost" 
                  size="sm" 
                  className="flex items-center gap-2 hover:text-green-600"
                  onClick={() => {
                    setSharingPost(post);
                    setShareModalOpen(true);
                  }}
                >
                  <Share2 className="w-5 h-5" />
                  <span>{post.shares}</span>
                </Button>
                <Button variant="ghost" size="sm" className="hover:text-purple-600">
                  <BookmarkPlus className="w-5 h-5" />
                </Button>
              </div>
            </motion.div>
          ))}
        </div>

        <AdBanner type="large" className="mt-6" />

        {/* Empty State */}
        {allPosts.length === 0 && (
          <div className="text-center py-12">
            <MessageCircle className="w-16 h-16 mx-auto mb-4 text-gray-400" />
            <h3 className="text-xl mb-2">
              {language === 'ps' ? 'پوست نشته' : language === 'fa' ? 'پستی وجود ندارد' : 'No Posts'}
            </h3>
            <p className="text-gray-600">
              {language === 'ps' ? 'لومړی پوست تاسو وکړئ!' : language === 'fa' ? 'اولین پست را شما بگذارید!' : 'Be the first to post!'}
            </p>
          </div>
        )}
      </div>

      {/* Share Modal */}
      <ShareModal
        isOpen={shareModalOpen}
        onClose={() => {
          setShareModalOpen(false);
          setSharingPost(null);
        }}
        language={language}
        shareContent={{
          title: sharingPost ? `${sharingPost.author}: ${sharingPost.content[language].slice(0, 100)}...` : 'HealMate Community',
          description: sharingPost?.content[language] || '',
          url: window.location.href
        }}
      />
    </div>
  );
}

// Missing icon imports
import { Activity, Brain, Salad, Dumbbell } from 'lucide-react';
