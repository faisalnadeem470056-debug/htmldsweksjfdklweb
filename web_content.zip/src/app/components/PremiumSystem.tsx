import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Crown, Check, X, Sparkles, Zap, Shield, Star, TrendingUp,
  Users, Heart, MessageCircle, Bell, Download, Upload, Lock,
  Unlock, CreditCard, Calendar, RefreshCw, AlertCircle, ChevronRight,
  Gift, Award, Infinity, CheckCircle, XCircle, ArrowLeft, Settings
} from 'lucide-react';
import { Button } from './ui/button';

interface PremiumSystemProps {
  language: 'ps' | 'fa' | 'en';
  currentUser: any;
  onBack: () => void;
  onSubscribe?: (plan: 'monthly' | 'yearly') => void;
}

export interface PremiumSubscription {
  userId: string;
  plan: 'monthly' | 'yearly' | 'free';
  status: 'active' | 'cancelled' | 'expired' | 'pending';
  startDate: string;
  endDate: string;
  autoRenew: boolean;
  platform: 'android' | 'ios' | 'web';
  transactionId?: string;
  price: number;
  currency: string;
}

export function PremiumSystem({ language, currentUser, onBack, onSubscribe }: PremiumSystemProps) {
  const [selectedPlan, setSelectedPlan] = useState<'monthly' | 'yearly' | null>(null);
  const [subscription, setSubscription] = useState<PremiumSubscription | null>(null);
  const [showPayment, setShowPayment] = useState(false);
  const [processing, setProcessing] = useState(false);

  const t = {
    ps: {
      title: 'HealMate Premium',
      subtitle: 'د ښو ځانګړتیاوو څخه خوند واخلئ',
      currentPlan: 'اوسنی پلان',
      upgradeTo: 'ته لوړ کړئ',
      free: 'وړیا',
      monthly: 'میاشتنی',
      yearly: 'کلنی',
      subscribe: 'ګډون',
      subscribed: 'ګډون شوی',
      cancel: 'لغوه',
      restore: 'بیرته راوستل',
      manageSubscription: 'د ګډون مدیریت',
      renewsOn: 'نوي کیږي په',
      expiresOn: 'ختمیږي په',
      autoRenew: 'اتوماتیک نوي کول',
      on: 'فعال',
      off: 'غیر فعال',
      save: 'سپما',
      perMonth: '/ په میاشت',
      perYear: '/ په کال',
      billedMonthly: 'د میاشتې حساب',
      billedYearly: 'د کال حساب',
      paymentMethod: 'د تادیې طریقه',
      googlePlay: 'Google Play',
      appleStore: 'App Store',
      processing: 'په پروسس کې...',
      success: 'بریالی!',
      failed: 'ناکام!',
      premiumFeatures: 'Premium ځانګړتیاوې',
      freeFeatures: 'وړیا ځانګړتیاوې',
      features: {
        unlimitedPosts: 'لامحدود پوستونه',
        prioritySupport: 'لومړیتوب ملاتړ',
        adFree: 'د اعلاناتو پرته',
        verifiedBadge: 'Verified تمغه',
        advancedSearch: 'پرمختللی لټون',
        offlineMode: 'بې انټرنېټ حالت',
        customThemes: 'دودیز تیمونه',
        analytics: 'شننې او مطالعې',
        exportData: 'معلومات ایکسپورټ',
        priorityListing: 'لومړیتوب لیست',
        directMessages: 'مستقیم پیغامونه',
        videoConsult: 'ویډیو مشوره',
        bookmarking: 'نښه ایښودل',
        multiplePosts: '۱۰ پوستونه په ورځ',
        singlePost: '۳ پوستونه په ورځ',
        basicSupport: 'بنسټیز ملاتړ',
        withAds: 'د اعلاناتو سره',
        basicSearch: 'بنسټیز لټون',
        onlineOnly: 'یوازې انټرنېټ'
      },
      benefits: 'ګټې',
      popularChoice: 'مشهور انتخاب',
      bestValue: 'غوره ارزښت',
      limited: 'محدود',
      unlimited: 'لامحدود',
      terms: 'شرایط او اصول',
      privacy: 'د محرمیت پالیسي',
      refund: 'د بیرته ورکولو پالیسي',
      subscriptionHistory: 'د ګډون تاریخچه',
      transactionId: 'د لیږد پیژندنه',
      status: 'حالت',
      active: 'فعال',
      cancelled: 'لغوه شوی',
      expired: 'ختم شوی',
      pending: 'په انتظار',
      confirmCancel: 'آیا تاسو ډاډه یاست چې غواړئ ګډون لغوه کړئ؟',
      cancelSuccess: 'ګډون په بریالیتوب سره لغوه شو',
      restoreSuccess: 'ګډون په بریالیتوب سره بیرته راوستل شو',
      purchaseSuccess: 'ستاسو Premium ګډون فعال شو!',
      purchaseFailed: 'تادیه ناکامه شوه. بیا هڅه وکړئ.',
      loading: 'بارېږي...'
    },
    fa: {
      title: 'HealMate Premium',
      subtitle: 'از ویژگی‌های برتر لذت ببرید',
      currentPlan: 'پلان فعلی',
      upgradeTo: 'ارتقا به',
      free: 'رایگان',
      monthly: 'ماهانه',
      yearly: 'سالانه',
      subscribe: 'اشتراک',
      subscribed: 'مشترک شده',
      cancel: 'لغو',
      restore: 'بازیابی',
      manageSubscription: 'مدیریت اشتراک',
      renewsOn: 'تمدید در',
      expiresOn: 'انقضا در',
      autoRenew: 'تمدید خودکار',
      on: 'فعال',
      off: 'غیرفعال',
      save: 'صرفه‌جویی',
      perMonth: '/ ماه',
      perYear: '/ سال',
      billedMonthly: 'صورت‌حساب ماهانه',
      billedYearly: 'صورت‌حساب سالانه',
      paymentMethod: 'روش پرداخت',
      googlePlay: 'Google Play',
      appleStore: 'App Store',
      processing: 'در حال پردازش...',
      success: 'موفق!',
      failed: 'ناموفق!',
      premiumFeatures: 'ویژگی‌های Premium',
      freeFeatures: 'ویژگی‌های رایگان',
      features: {
        unlimitedPosts: 'پست‌های نامحدود',
        prioritySupport: 'پشتیبانی اولویت‌دار',
        adFree: 'بدون تبلیغات',
        verifiedBadge: 'نشان Verified',
        advancedSearch: 'جستجوی پیشرفته',
        offlineMode: 'حالت آفلاین',
        customThemes: 'تم‌های سفارشی',
        analytics: 'تحلیل و آمار',
        exportData: 'خروجی داده‌ها',
        priorityListing: 'لیست اولویت‌دار',
        directMessages: 'پیام مستقیم',
        videoConsult: 'مشاوره ویدیویی',
        bookmarking: 'نشانه‌گذاری',
        multiplePosts: '۱۰ پست در روز',
        singlePost: '۳ پست در روز',
        basicSupport: 'پشتیبانی پایه',
        withAds: 'با تبلیغات',
        basicSearch: 'جستجوی پایه',
        onlineOnly: 'فقط آنلاین'
      },
      benefits: 'مزایا',
      popularChoice: 'انتخاب محبوب',
      bestValue: 'بهترین ارزش',
      limited: 'محدود',
      unlimited: 'نامحدود',
      terms: 'شرایط و قوانین',
      privacy: 'سیاست حریم خصوصی',
      refund: 'سیاست بازپرداخت',
      subscriptionHistory: 'تاریخچه اشتراک',
      transactionId: 'شناسه تراکنش',
      status: 'وضعیت',
      active: 'فعال',
      cancelled: 'لغو شده',
      expired: 'منقضی شده',
      pending: 'در انتظار',
      confirmCancel: 'آیا مطمئن هستید که می‌خواهید اشتراک را لغو کنید؟',
      cancelSuccess: 'اشتراک با موفقیت لغو شد',
      restoreSuccess: 'اشتراک با موفقیت بازیابی شد',
      purchaseSuccess: 'اشتراک Premium شما فعال شد!',
      purchaseFailed: 'پرداخت ناموفق بود. دوباره تلاش کنید.',
      loading: 'در حال بارگذاری...'
    },
    en: {
      title: 'HealMate Premium',
      subtitle: 'Unlock premium features and benefits',
      currentPlan: 'Current Plan',
      upgradeTo: 'Upgrade to',
      free: 'Free',
      monthly: 'Monthly',
      yearly: 'Yearly',
      subscribe: 'Subscribe',
      subscribed: 'Subscribed',
      cancel: 'Cancel',
      restore: 'Restore',
      manageSubscription: 'Manage Subscription',
      renewsOn: 'Renews on',
      expiresOn: 'Expires on',
      autoRenew: 'Auto Renew',
      on: 'On',
      off: 'Off',
      save: 'Save',
      perMonth: '/ month',
      perYear: '/ year',
      billedMonthly: 'Billed monthly',
      billedYearly: 'Billed yearly',
      paymentMethod: 'Payment Method',
      googlePlay: 'Google Play',
      appleStore: 'App Store',
      processing: 'Processing...',
      success: 'Success!',
      failed: 'Failed!',
      premiumFeatures: 'Premium Features',
      freeFeatures: 'Free Features',
      features: {
        unlimitedPosts: 'Unlimited Posts',
        prioritySupport: 'Priority Support',
        adFree: 'Ad-Free Experience',
        verifiedBadge: 'Verified Badge',
        advancedSearch: 'Advanced Search',
        offlineMode: 'Offline Mode',
        customThemes: 'Custom Themes',
        analytics: 'Analytics & Insights',
        exportData: 'Export Data',
        priorityListing: 'Priority Listing',
        directMessages: 'Direct Messages',
        videoConsult: 'Video Consultation',
        bookmarking: 'Bookmarking',
        multiplePosts: '10 Posts per day',
        singlePost: '3 Posts per day',
        basicSupport: 'Basic Support',
        withAds: 'With Ads',
        basicSearch: 'Basic Search',
        onlineOnly: 'Online Only'
      },
      benefits: 'Benefits',
      popularChoice: 'Popular Choice',
      bestValue: 'Best Value',
      limited: 'Limited',
      unlimited: 'Unlimited',
      terms: 'Terms & Conditions',
      privacy: 'Privacy Policy',
      refund: 'Refund Policy',
      subscriptionHistory: 'Subscription History',
      transactionId: 'Transaction ID',
      status: 'Status',
      active: 'Active',
      cancelled: 'Cancelled',
      expired: 'Expired',
      pending: 'Pending',
      confirmCancel: 'Are you sure you want to cancel your subscription?',
      cancelSuccess: 'Subscription cancelled successfully',
      restoreSuccess: 'Subscription restored successfully',
      purchaseSuccess: 'Your Premium subscription is now active!',
      purchaseFailed: 'Payment failed. Please try again.',
      loading: 'Loading...'
    }
  };

  const text = t[language];

  useEffect(() => {
    loadSubscription();
  }, [currentUser]);

  const loadSubscription = () => {
    if (!currentUser) return;
    
    const saved = localStorage.getItem(`healmate_premium_${currentUser.id}`);
    if (saved) {
      const sub: PremiumSubscription = JSON.parse(saved);
      
      // Check expiry
      const now = new Date();
      const endDate = new Date(sub.endDate);
      
      if (now > endDate && sub.status === 'active') {
        // Expired
        sub.status = 'expired';
        localStorage.setItem(`healmate_premium_${currentUser.id}`, JSON.stringify(sub));
      }
      
      setSubscription(sub);
    }
  };

  const handleSubscribe = async (plan: 'monthly' | 'yearly') => {
    setProcessing(true);
    setSelectedPlan(plan);
    
    // Simulate payment processing
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    const now = new Date();
    const endDate = new Date();
    
    if (plan === 'monthly') {
      endDate.setMonth(endDate.getMonth() + 1);
    } else {
      endDate.setFullYear(endDate.getFullYear() + 1);
    }
    
    const newSubscription: PremiumSubscription = {
      userId: currentUser.id,
      plan,
      status: 'active',
      startDate: now.toISOString(),
      endDate: endDate.toISOString(),
      autoRenew: true,
      platform: getPlatform(),
      transactionId: `TXN_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      price: plan === 'monthly' ? 299 : 2999,
      currency: 'AFN'
    };
    
    localStorage.setItem(`healmate_premium_${currentUser.id}`, JSON.stringify(newSubscription));
    setSubscription(newSubscription);
    setProcessing(false);
    setShowPayment(false);
    
    alert(text.purchaseSuccess);
    
    if (onSubscribe) {
      onSubscribe(plan);
    }
  };

  const handleCancel = () => {
    if (!subscription) return;
    
    if (confirm(text.confirmCancel)) {
      const updated = {
        ...subscription,
        status: 'cancelled' as const,
        autoRenew: false
      };
      
      localStorage.setItem(`healmate_premium_${currentUser.id}`, JSON.stringify(updated));
      setSubscription(updated);
      alert(text.cancelSuccess);
    }
  };

  const handleRestore = async () => {
    setProcessing(true);
    
    // Simulate restore from Google Play or App Store
    await new Promise(resolve => setTimeout(resolve, 1500));
    
    // Check if there's a valid purchase to restore
    const saved = localStorage.getItem(`healmate_premium_${currentUser.id}`);
    if (saved) {
      const sub: PremiumSubscription = JSON.parse(saved);
      const now = new Date();
      const endDate = new Date(sub.endDate);
      
      if (now < endDate) {
        sub.status = 'active';
        sub.autoRenew = true;
        localStorage.setItem(`healmate_premium_${currentUser.id}`, JSON.stringify(sub));
        setSubscription(sub);
        alert(text.restoreSuccess);
      }
    }
    
    setProcessing(false);
  };

  const toggleAutoRenew = () => {
    if (!subscription) return;
    
    const updated = {
      ...subscription,
      autoRenew: !subscription.autoRenew
    };
    
    localStorage.setItem(`healmate_premium_${currentUser.id}`, JSON.stringify(updated));
    setSubscription(updated);
  };

  const getPlatform = (): 'android' | 'ios' | 'web' => {
    const userAgent = navigator.userAgent.toLowerCase();
    if (userAgent.includes('android')) return 'android';
    if (userAgent.includes('iphone') || userAgent.includes('ipad')) return 'ios';
    return 'web';
  };

  const isPremium = subscription?.status === 'active';
  const currentPlan = subscription?.plan || 'free';

  const plans = [
    {
      id: 'monthly' as const,
      name: text.monthly,
      price: 299,
      period: text.perMonth,
      billing: text.billedMonthly,
      popular: false,
      save: null
    },
    {
      id: 'yearly' as const,
      name: text.yearly,
      price: 2999,
      period: text.perYear,
      billing: text.billedYearly,
      popular: true,
      save: '17%'
    }
  ];

  const premiumFeatures = [
    { icon: Infinity, label: text.features.unlimitedPosts, free: false },
    { icon: Zap, label: text.features.prioritySupport, free: false },
    { icon: Shield, label: text.features.adFree, free: false },
    { icon: Award, label: text.features.verifiedBadge, free: false },
    { icon: Star, label: text.features.advancedSearch, free: false },
    { icon: Download, label: text.features.offlineMode, free: false },
    { icon: Sparkles, label: text.features.customThemes, free: false },
    { icon: TrendingUp, label: text.features.analytics, free: false },
    { icon: Upload, label: text.features.exportData, free: false },
    { icon: Crown, label: text.features.priorityListing, free: false },
    { icon: MessageCircle, label: text.features.directMessages, free: false },
    { icon: Users, label: text.features.videoConsult, free: false }
  ];

  const freeFeatures = [
    { icon: MessageCircle, label: text.features.singlePost, free: true },
    { icon: Users, label: text.features.basicSupport, free: true },
    { icon: Bell, label: text.features.withAds, free: true },
    { icon: Star, label: text.features.basicSearch, free: true },
    { icon: Lock, label: text.features.onlineOnly, free: true }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-pink-50 to-yellow-50 pb-20">
      {/* Header */}
      <div className="sticky top-0 z-40 backdrop-blur-xl bg-white/80 border-b border-white/20 shadow-lg">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center gap-4">
            <Button variant="ghost" size="icon" onClick={onBack}>
              <ArrowLeft className="w-5 h-5" />
            </Button>
            <div className="flex items-center gap-3">
              <div className="bg-gradient-to-br from-yellow-400 to-orange-500 p-2.5 rounded-2xl">
                <Crown className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-2xl bg-gradient-to-r from-yellow-600 to-orange-600 bg-clip-text text-transparent">
                  {text.title}
                </h1>
                <p className="text-sm text-gray-600">{text.subtitle}</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-6">
        {/* Current Status */}
        {isPremium && subscription && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-gradient-to-r from-yellow-400 to-orange-500 rounded-3xl p-6 mb-6 text-white"
          >
            <div className="flex items-start justify-between mb-4">
              <div className="flex items-center gap-3">
                <Crown className="w-8 h-8" />
                <div>
                  <h2 className="text-xl font-medium">Premium {subscription.plan === 'monthly' ? text.monthly : text.yearly}</h2>
                  <p className="text-sm text-white/90">{text.currentPlan}</p>
                </div>
              </div>
              <CheckCircle className="w-6 h-6" />
            </div>

            <div className="grid grid-cols-2 gap-4 mb-4">
              <div className="bg-white/20 backdrop-blur-xl rounded-2xl p-4">
                <p className="text-xs text-white/80 mb-1">
                  {subscription.autoRenew ? text.renewsOn : text.expiresOn}
                </p>
                <p className="font-medium">
                  {new Date(subscription.endDate).toLocaleDateString()}
                </p>
              </div>
              <div className="bg-white/20 backdrop-blur-xl rounded-2xl p-4">
                <p className="text-xs text-white/80 mb-1">{text.autoRenew}</p>
                <p className="font-medium">{subscription.autoRenew ? text.on : text.off}</p>
              </div>
            </div>

            <div className="flex gap-2">
              <Button
                variant="outline"
                className="flex-1 bg-white/20 border-white/30 text-white hover:bg-white/30"
                onClick={toggleAutoRenew}
              >
                <RefreshCw className="w-4 h-4 mr-2" />
                {text.autoRenew}
              </Button>
              <Button
                variant="outline"
                className="flex-1 bg-white/20 border-white/30 text-white hover:bg-white/30"
                onClick={handleCancel}
              >
                <XCircle className="w-4 h-4 mr-2" />
                {text.cancel}
              </Button>
            </div>
          </motion.div>
        )}

        {/* Free Plan Status */}
        {!isPremium && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-white rounded-3xl p-6 mb-6 border border-gray-200"
          >
            <div className="flex items-center gap-3 mb-2">
              <div className="bg-gray-100 p-2 rounded-xl">
                <Lock className="w-5 h-5 text-gray-600" />
              </div>
              <h2 className="text-xl font-medium">{text.free} {text.currentPlan}</h2>
            </div>
            <p className="text-sm text-gray-600 mb-4">
              {language === 'ps' 
                ? 'Premium ته لوړ کړئ ترڅو د نورو ځانګړتیاوو څخه استفاده وکړئ' 
                : language === 'fa'
                ? 'برای استفاده از ویژگی‌های بیشتر، به Premium ارتقا دهید'
                : 'Upgrade to Premium to unlock more features'}
            </p>
            <Button
              onClick={() => setShowPayment(true)}
              className="w-full bg-gradient-to-r from-yellow-400 to-orange-500 hover:from-yellow-500 hover:to-orange-600 text-white"
            >
              <Crown className="w-4 h-4 mr-2" />
              {text.upgradeTo} Premium
            </Button>
          </motion.div>
        )}

        {/* Subscription Plans */}
        {!isPremium && (
          <div className="mb-6">
            <h2 className="text-2xl font-medium mb-4">
              {language === 'ps' ? 'پلانونه غوره کړئ' : language === 'fa' ? 'پلان خود را انتخاب کنید' : 'Choose Your Plan'}
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {plans.map((plan) => (
                <motion.div
                  key={plan.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  className={`relative bg-white rounded-3xl p-6 border-2 transition-all ${
                    plan.popular
                      ? 'border-yellow-400 shadow-2xl scale-105'
                      : 'border-gray-200 hover:border-gray-300'
                  }`}
                >
                  {plan.popular && (
                    <div className="absolute -top-3 left-1/2 -translate-x-1/2 bg-gradient-to-r from-yellow-400 to-orange-500 text-white px-4 py-1 rounded-full text-sm font-medium">
                      {text.bestValue}
                    </div>
                  )}
                  
                  <div className="text-center mb-6">
                    <h3 className="text-2xl font-medium mb-2">{plan.name}</h3>
                    <div className="flex items-baseline justify-center gap-1">
                      <span className="text-4xl font-bold">{plan.price}</span>
                      <span className="text-gray-600">افغانی</span>
                    </div>
                    <p className="text-sm text-gray-600">{plan.billing}</p>
                    {plan.save && (
                      <div className="inline-block bg-green-100 text-green-700 px-3 py-1 rounded-full text-sm font-medium mt-2">
                        {text.save} {plan.save}
                      </div>
                    )}
                  </div>

                  <Button
                    onClick={() => handleSubscribe(plan.id)}
                    disabled={processing}
                    className={`w-full ${
                      plan.popular
                        ? 'bg-gradient-to-r from-yellow-400 to-orange-500 hover:from-yellow-500 hover:to-orange-600 text-white'
                        : 'bg-gray-900 hover:bg-gray-800 text-white'
                    }`}
                  >
                    {processing && selectedPlan === plan.id ? (
                      <>
                        <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                        {text.processing}
                      </>
                    ) : (
                      <>
                        <Crown className="w-4 h-4 mr-2" />
                        {text.subscribe}
                      </>
                    )}
                  </Button>
                </motion.div>
              ))}
            </div>
          </div>
        )}

        {/* Premium Features */}
        <div className="mb-6">
          <h2 className="text-2xl font-medium mb-4 flex items-center gap-2">
            <Sparkles className="w-6 h-6 text-yellow-500" />
            {text.premiumFeatures}
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {premiumFeatures.map((feature, index) => {
              const Icon = feature.icon;
              return (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: index * 0.05 }}
                  className="bg-gradient-to-r from-yellow-50 to-orange-50 rounded-2xl p-4 flex items-center gap-3 border border-yellow-200"
                >
                  <div className="bg-gradient-to-br from-yellow-400 to-orange-500 p-2 rounded-xl">
                    <Icon className="w-5 h-5 text-white" />
                  </div>
                  <span className="font-medium">{feature.label}</span>
                  <CheckCircle className="w-5 h-5 text-green-600 ml-auto" />
                </motion.div>
              );
            })}
          </div>
        </div>

        {/* Free Features */}
        <div className="mb-6">
          <h2 className="text-2xl font-medium mb-4 flex items-center gap-2">
            <Lock className="w-6 h-6 text-gray-500" />
            {text.freeFeatures}
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {freeFeatures.map((feature, index) => {
              const Icon = feature.icon;
              return (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: index * 0.05 }}
                  className="bg-white rounded-2xl p-4 flex items-center gap-3 border border-gray-200"
                >
                  <div className="bg-gray-100 p-2 rounded-xl">
                    <Icon className="w-5 h-5 text-gray-600" />
                  </div>
                  <span className="text-gray-700">{feature.label}</span>
                  <XCircle className="w-5 h-5 text-gray-400 ml-auto" />
                </motion.div>
              );
            })}
          </div>
        </div>

        {/* Restore Purchase */}
        {!isPremium && (
          <div className="text-center">
            <Button
              variant="outline"
              onClick={handleRestore}
              disabled={processing}
              className="text-gray-600"
            >
              {processing ? (
                <>
                  <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                  {text.loading}
                </>
              ) : (
                <>
                  <Upload className="w-4 h-4 mr-2" />
                  {text.restore} {text.subscribe}
                </>
              )}
            </Button>
          </div>
        )}

        {/* Payment Methods */}
        <div className="mt-8 bg-white rounded-3xl p-6 border border-gray-200">
          <h3 className="font-medium mb-4">{text.paymentMethod}</h3>
          <div className="grid grid-cols-2 gap-4">
            <div className="border border-gray-200 rounded-2xl p-4 text-center">
              <div className="w-12 h-12 bg-green-100 rounded-xl mx-auto mb-2 flex items-center justify-center">
                <svg className="w-6 h-6" viewBox="0 0 24 24" fill="#34A853">
                  <path d="M3,12.5c0,5.52,4.48,10,10,10s10-4.48,10-10s-4.48-10-10-10S3,6.98,3,12.5z M14.47,11.47l-3.5,3.5c-0.29,0.29-0.77,0.29-1.06,0l-1.5-1.5c-0.29-0.29-0.29-0.77,0-1.06c0.29-0.29,0.77-0.29,1.06,0l0.97,0.97l2.97-2.97c0.29-0.29,0.77-0.29,1.06,0C14.76,10.7,14.76,11.18,14.47,11.47z"/>
                </svg>
              </div>
              <p className="text-sm font-medium">Google Play</p>
            </div>
            <div className="border border-gray-200 rounded-2xl p-4 text-center">
              <div className="w-12 h-12 bg-gray-100 rounded-xl mx-auto mb-2 flex items-center justify-center">
                <svg className="w-6 h-6" viewBox="0 0 24 24" fill="#000">
                  <path d="M18.71,19.5C17.88,20.74 17,21.95 15.66,21.97C14.32,22 13.89,21.18 12.37,21.18C10.84,21.18 10.37,21.95 9.1,22C7.79,22.05 6.8,20.68 5.96,19.47C4.25,17 2.94,12.45 4.7,9.39C5.57,7.87 7.13,6.91 8.82,6.88C10.1,6.86 11.32,7.75 12.11,7.75C12.89,7.75 14.37,6.68 15.92,6.84C16.57,6.87 18.39,7.1 19.56,8.82C19.47,8.88 17.39,10.1 17.41,12.63C17.44,15.65 20.06,16.66 20.09,16.67C20.06,16.74 19.67,18.11 18.71,19.5M13,3.5C13.73,2.67 14.94,2.04 15.94,2C16.07,3.17 15.6,4.35 14.9,5.19C14.21,6.04 13.07,6.7 11.95,6.61C11.8,5.46 12.36,4.26 13,3.5Z"/>
                </svg>
              </div>
              <p className="text-sm font-medium">App Store</p>
            </div>
          </div>
        </div>

        {/* Subscription Info */}
        {subscription && (
          <div className="mt-6 bg-white rounded-3xl p-6 border border-gray-200">
            <h3 className="font-medium mb-4">{text.subscriptionHistory}</h3>
            <div className="space-y-3">
              <div className="flex justify-between text-sm">
                <span className="text-gray-600">{text.transactionId}:</span>
                <span className="font-mono text-xs">{subscription.transactionId}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-gray-600">{text.status}:</span>
                <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                  subscription.status === 'active' ? 'bg-green-100 text-green-700' :
                  subscription.status === 'cancelled' ? 'bg-yellow-100 text-yellow-700' :
                  subscription.status === 'expired' ? 'bg-red-100 text-red-700' :
                  'bg-gray-100 text-gray-700'
                }`}>
                  {text[subscription.status]}
                </span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-gray-600">{text.paymentMethod}:</span>
                <span className="capitalize">{subscription.platform}</span>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

// Premium Check Hook
export function usePremium(userId: string | undefined) {
  const [isPremium, setIsPremium] = useState(false);
  const [subscription, setSubscription] = useState<PremiumSubscription | null>(null);

  useEffect(() => {
    if (!userId) {
      setIsPremium(false);
      setSubscription(null);
      return;
    }

    const checkPremium = () => {
      const saved = localStorage.getItem(`healmate_premium_${userId}`);
      if (saved) {
        const sub: PremiumSubscription = JSON.parse(saved);
        const now = new Date();
        const endDate = new Date(sub.endDate);

        if (now < endDate && sub.status === 'active') {
          setIsPremium(true);
          setSubscription(sub);
        } else {
          setIsPremium(false);
          setSubscription(sub);
          
          // Update status if expired
          if (now > endDate && sub.status === 'active') {
            sub.status = 'expired';
            localStorage.setItem(`healmate_premium_${userId}`, JSON.stringify(sub));
          }
        }
      } else {
        setIsPremium(false);
        setSubscription(null);
      }
    };

    checkPremium();

    // Check every minute for expiry
    const interval = setInterval(checkPremium, 60000);

    return () => clearInterval(interval);
  }, [userId]);

  return { isPremium, subscription };
}
