import { useEffect, useRef, useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, ExternalLink } from 'lucide-react';
import { BANNER_AD_ID, isDevelopment, AdSettings } from '../../config/admob.config';

interface AdMobBannerProps {
  className?: string;
  position?: 'top' | 'bottom';
  size?: 'standard' | 'large' | 'medium';
}

export function AdMobBanner({ className = '', position = 'bottom', size = 'standard' }: AdMobBannerProps) {
  const [isVisible, setIsVisible] = useState(true);
  const [isLoading, setIsLoading] = useState(true);
  const adRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    // Simulate ad loading
    const loadTimeout = setTimeout(() => {
      setIsLoading(false);
    }, 1500);

    // Auto refresh banner ad
    const refreshInterval = setInterval(() => {
      if (AdSettings.banner.enabled) {
        setIsLoading(true);
        setTimeout(() => setIsLoading(false), 1000);
      }
    }, AdSettings.banner.refreshInterval);

    return () => {
      clearTimeout(loadTimeout);
      clearInterval(refreshInterval);
    };
  }, []);

  // Log ad impression
  useEffect(() => {
    if (!isLoading && isVisible) {
      console.log(`[AdMob] Banner Ad Impression - ID: ${BANNER_AD_ID}`);
      
      // د localStorage کې ad impressions save کړئ
      const impressions = JSON.parse(localStorage.getItem('admob_banner_impressions') || '0');
      localStorage.setItem('admob_banner_impressions', String(impressions + 1));
    }
  }, [isLoading, isVisible]);

  if (!AdSettings.banner.enabled || !isVisible) {
    return null;
  }

  const sizeClasses = {
    standard: 'h-[50px]',
    medium: 'h-[90px]',
    large: 'h-[250px]',
  };

  const handleClose = () => {
    setIsVisible(false);
    console.log('[AdMob] Banner Ad Closed by User');
  };

  const handleClick = () => {
    console.log('[AdMob] Banner Ad Clicked');
    
    // د localStorage کې ad clicks save کړئ
    const clicks = JSON.parse(localStorage.getItem('admob_banner_clicks') || '0');
    localStorage.setItem('admob_banner_clicks', String(clicks + 1));
  };

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0, y: position === 'bottom' ? 20 : -20 }}
        animate={{ opacity: 1, y: 0 }}
        exit={{ opacity: 0, y: position === 'bottom' ? 20 : -20 }}
        className={`relative w-full ${sizeClasses[size]} ${className}`}
        ref={adRef}
      >
        {isLoading ? (
          // Loading skeleton
          <div className="w-full h-full bg-gradient-to-r from-gray-200 via-gray-300 to-gray-200 animate-pulse rounded-lg flex items-center justify-center">
            <div className="text-gray-500 text-sm">Loading Ad...</div>
          </div>
        ) : (
          // Ad content
          <div 
            className="relative w-full h-full bg-gradient-to-r from-blue-500 via-purple-500 to-pink-500 rounded-lg overflow-hidden cursor-pointer group"
            onClick={handleClick}
          >
            {/* Ad Background Pattern */}
            <div className="absolute inset-0 opacity-20">
              <div className="absolute inset-0" style={{
                backgroundImage: 'repeating-linear-gradient(45deg, transparent, transparent 10px, rgba(255,255,255,.1) 10px, rgba(255,255,255,.1) 20px)'
              }} />
            </div>

            {/* Ad Content */}
            <div className="relative z-10 h-full flex items-center justify-between px-4">
              <div className="flex items-center gap-3">
                {/* Ad Badge */}
                <div className="bg-white/20 backdrop-blur-sm px-2 py-1 rounded text-xs text-white border border-white/30">
                  {isDevelopment ? '🧪 Test Ad' : 'Ad'}
                </div>
                
                {/* Ad Message */}
                <div className="text-white">
                  <p className="text-sm font-medium">
                    {isDevelopment ? 'Google AdMob Test Banner' : 'Advertisement'}
                  </p>
                  <p className="text-xs opacity-90">
                    {isDevelopment ? `ID: ${BANNER_AD_ID.slice(0, 30)}...` : 'Sponsored Content'}
                  </p>
                </div>
              </div>

              {/* Ad CTA */}
              <div className="flex items-center gap-2">
                <div className="bg-white text-purple-600 px-4 py-2 rounded-lg text-sm font-medium group-hover:bg-purple-50 transition-colors flex items-center gap-1">
                  Learn More
                  <ExternalLink className="w-3 h-3" />
                </div>
              </div>
            </div>

            {/* Close Button */}
            <button
              onClick={(e) => {
                e.stopPropagation();
                handleClose();
              }}
              className="absolute top-1 right-1 bg-black/30 backdrop-blur-sm text-white p-1 rounded-full hover:bg-black/50 transition-colors"
            >
              <X className="w-3 h-3" />
            </button>

            {/* Development Info */}
            {isDevelopment && (
              <div className="absolute bottom-1 left-1 bg-yellow-400 text-yellow-900 px-2 py-0.5 rounded text-[10px] font-mono">
                TEST MODE
              </div>
            )}
          </div>
        )}

        {/* Ad Info */}
        {isDevelopment && !isLoading && (
          <div className="mt-1 text-[10px] text-gray-500 font-mono">
            Type: Banner | Size: {size} | Refresh: {AdSettings.banner.refreshInterval / 1000}s
          </div>
        )}
      </motion.div>
    </AnimatePresence>
  );
}
