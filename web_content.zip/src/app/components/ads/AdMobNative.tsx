import { useEffect, useState } from 'react';
import { motion } from 'motion/react';
import { ExternalLink, Star, ThumbsUp, MessageCircle } from 'lucide-react';
import { NATIVE_AD_ID, isDevelopment } from '../../config/admob.config';
import { Button } from '../ui/button';
import { ImageWithFallback } from '../figma/ImageWithFallback';

interface AdMobNativeProps {
  className?: string;
  layout?: 'small' | 'medium' | 'large';
}

export function AdMobNative({ className = '', layout = 'medium' }: AdMobNativeProps) {
  const [isLoading, setIsLoading] = useState(true);
  const [isVisible, setIsVisible] = useState(true);

  useEffect(() => {
    // Simulate ad loading
    const loadTimeout = setTimeout(() => {
      setIsLoading(false);
      
      // Log impression
      console.log(`[AdMob] Native Ad Impression - ID: ${NATIVE_AD_ID}`);
      const impressions = JSON.parse(localStorage.getItem('admob_native_impressions') || '0');
      localStorage.setItem('admob_native_impressions', String(impressions + 1));
    }, 1500);

    return () => clearTimeout(loadTimeout);
  }, []);

  const handleClick = () => {
    console.log('[AdMob] Native Ad Clicked');
    const clicks = JSON.parse(localStorage.getItem('admob_native_clicks') || '0');
    localStorage.setItem('admob_native_clicks', String(clicks + 1));
  };

  if (!isVisible) return null;

  if (isLoading) {
    return (
      <div className={`bg-gradient-to-r from-gray-200 via-gray-300 to-gray-200 animate-pulse rounded-2xl ${className}`}>
        <div className="p-4 space-y-3">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 bg-gray-300 rounded-full" />
            <div className="flex-1 space-y-2">
              <div className="h-4 bg-gray-300 rounded w-3/4" />
              <div className="h-3 bg-gray-300 rounded w-1/2" />
            </div>
          </div>
          {layout !== 'small' && (
            <>
              <div className="h-40 bg-gray-300 rounded-xl" />
              <div className="h-4 bg-gray-300 rounded w-full" />
              <div className="h-4 bg-gray-300 rounded w-5/6" />
            </>
          )}
        </div>
      </div>
    );
  }

  // Small layout (list item style)
  if (layout === 'small') {
    return (
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className={`bg-white rounded-2xl border border-gray-200 overflow-hidden hover:shadow-lg transition-shadow cursor-pointer ${className}`}
        onClick={handleClick}
      >
        <div className="p-4">
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2">
              <div className="bg-yellow-100 text-yellow-800 px-2 py-1 rounded text-xs font-medium">
                Ad
              </div>
              {isDevelopment && (
                <div className="bg-green-100 text-green-800 px-2 py-1 rounded text-xs font-medium">
                  Test
                </div>
              )}
            </div>
            <Star className="w-4 h-4 text-yellow-500 fill-yellow-500" />
          </div>

          <div className="flex items-center gap-3">
            <ImageWithFallback
              src="https://images.unsplash.com/photo-1611162617474-5b21e879e113?w=100"
              alt="Ad"
              className="w-16 h-16 rounded-xl object-cover"
            />
            <div className="flex-1">
              <h3 className="font-medium text-sm mb-1">
                {isDevelopment ? 'Test Native Ad - Small Layout' : 'Sponsored Content'}
              </h3>
              <p className="text-xs text-gray-600 line-clamp-2">
                Click to learn more about this amazing offer!
              </p>
            </div>
            <ExternalLink className="w-4 h-4 text-gray-400" />
          </div>
        </div>
      </motion.div>
    );
  }

  // Medium layout (card style)
  if (layout === 'medium') {
    return (
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className={`bg-white rounded-2xl border border-gray-200 overflow-hidden hover:shadow-xl transition-shadow cursor-pointer ${className}`}
        onClick={handleClick}
      >
        {/* Ad Badge */}
        <div className="bg-gradient-to-r from-yellow-100 to-orange-100 px-4 py-2 flex items-center justify-between border-b border-gray-200">
          <div className="flex items-center gap-2">
            <div className="bg-yellow-500 text-white px-2 py-1 rounded text-xs font-bold">
              Ad
            </div>
            <span className="text-xs text-gray-600">Sponsored</span>
          </div>
          {isDevelopment && (
            <div className="bg-green-500 text-white px-2 py-1 rounded text-xs font-bold">
              TEST
            </div>
          )}
        </div>

        {/* Ad Content */}
        <div className="p-4">
          {/* Advertiser Info */}
          <div className="flex items-center gap-3 mb-4">
            <ImageWithFallback
              src="https://images.unsplash.com/photo-1611162617474-5b21e879e113?w=100"
              alt="Advertiser"
              className="w-12 h-12 rounded-full object-cover border-2 border-gray-200"
            />
            <div>
              <h3 className="font-semibold text-sm">
                {isDevelopment ? 'Test Advertiser' : 'Premium Sponsor'}
              </h3>
              <div className="flex items-center gap-1">
                <Star className="w-3 h-3 text-yellow-500 fill-yellow-500" />
                <span className="text-xs text-gray-600">4.8 Rating</span>
              </div>
            </div>
          </div>

          {/* Ad Image */}
          <div className="relative mb-4 rounded-xl overflow-hidden">
            <ImageWithFallback
              src="https://images.unsplash.com/photo-1556742502-ec7c0e9f34b1?w=600"
              alt="Ad Content"
              className="w-full h-48 object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent" />
            <div className="absolute bottom-3 left-3 right-3">
              <h2 className="text-white text-lg font-bold mb-1">
                {isDevelopment ? 'Test Native Advertisement' : 'Amazing Offer Inside!'}
              </h2>
            </div>
          </div>

          {/* Ad Description */}
          <p className="text-sm text-gray-700 mb-4 line-clamp-3">
            {isDevelopment 
              ? 'This is a Google AdMob test native advertisement. In production, real native ads from advertisers will appear here with actual content and offers.'
              : 'Discover amazing deals and exclusive offers. Click to learn more about this limited-time opportunity that you don\'t want to miss!'
            }
          </p>

          {/* Ad Actions */}
          <div className="flex items-center gap-2">
            <Button className="flex-1 bg-gradient-to-r from-blue-500 to-purple-600 text-white">
              <span className="flex items-center justify-center gap-2">
                Learn More
                <ExternalLink className="w-4 h-4" />
              </span>
            </Button>
          </div>

          {/* Ad Stats */}
          <div className="flex items-center gap-4 mt-4 pt-4 border-t border-gray-200">
            <div className="flex items-center gap-1 text-gray-500">
              <ThumbsUp className="w-4 h-4" />
              <span className="text-xs">2.3k</span>
            </div>
            <div className="flex items-center gap-1 text-gray-500">
              <MessageCircle className="w-4 h-4" />
              <span className="text-xs">432</span>
            </div>
            <div className="flex items-center gap-1 text-gray-500">
              <Star className="w-4 h-4 fill-yellow-500 text-yellow-500" />
              <span className="text-xs">4.8</span>
            </div>
          </div>

          {/* Development Info */}
          {isDevelopment && (
            <div className="mt-4 pt-4 border-t border-gray-200">
              <p className="text-[10px] text-gray-500 font-mono">
                Native Ad ID: {NATIVE_AD_ID.slice(0, 40)}...
              </p>
            </div>
          )}
        </div>
      </motion.div>
    );
  }

  // Large layout (hero style)
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className={`bg-gradient-to-br from-purple-50 to-pink-50 rounded-3xl border border-purple-200 overflow-hidden hover:shadow-2xl transition-all cursor-pointer ${className}`}
      onClick={handleClick}
    >
      {/* Ad Header */}
      <div className="bg-gradient-to-r from-purple-500 to-pink-600 text-white px-6 py-3 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="bg-white/20 backdrop-blur-sm px-3 py-1 rounded-full text-xs font-bold border border-white/30">
            Sponsored Ad
          </div>
          <span className="text-xs opacity-90">Featured Content</span>
        </div>
        {isDevelopment && (
          <div className="bg-yellow-400 text-yellow-900 px-3 py-1 rounded-full text-xs font-bold">
            TEST MODE
          </div>
        )}
      </div>

      {/* Ad Body */}
      <div className="p-6">
        {/* Hero Image */}
        <div className="relative rounded-2xl overflow-hidden mb-6">
          <ImageWithFallback
            src="https://images.unsplash.com/photo-1557804506-669a67965ba0?w=800"
            alt="Ad Hero"
            className="w-full h-64 object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-transparent to-transparent" />
          <div className="absolute bottom-0 left-0 right-0 p-6">
            <div className="flex items-center gap-3 mb-3">
              <ImageWithFallback
                src="https://images.unsplash.com/photo-1611162617474-5b21e879e113?w=100"
                alt="Advertiser"
                className="w-16 h-16 rounded-full object-cover border-4 border-white"
              />
              <div className="text-white">
                <h3 className="font-bold text-lg">
                  {isDevelopment ? 'Test Premium Brand' : 'Premium Advertiser'}
                </h3>
                <div className="flex items-center gap-2">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                  ))}
                  <span className="text-sm ml-1">(4.9)</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Ad Content */}
        <div className="space-y-4">
          <div>
            <h2 className="text-2xl font-bold text-gray-900 mb-2">
              {isDevelopment ? 'Test Native Ad - Large Layout' : 'Exclusive Premium Offer'}
            </h2>
            <p className="text-gray-700">
              {isDevelopment 
                ? 'This is a comprehensive test of the large native ad format. In production, this would display rich media content from real advertisers with detailed information and compelling calls-to-action.'
                : 'Experience the best deals with our premium offerings. Limited time offer with exclusive benefits and amazing features that you won\'t find anywhere else. Don\'t miss out on this opportunity!'
              }
            </p>
          </div>

          {/* Features */}
          <div className="grid grid-cols-3 gap-4">
            {['Premium Quality', 'Best Value', 'Trusted Brand'].map((feature, i) => (
              <div key={i} className="text-center p-3 bg-white rounded-xl border border-gray-200">
                <div className="text-2xl mb-1">
                  {['⭐', '💎', '🏆'][i]}
                </div>
                <p className="text-xs text-gray-600">{feature}</p>
              </div>
            ))}
          </div>

          {/* CTA */}
          <Button className="w-full bg-gradient-to-r from-purple-600 to-pink-600 text-white py-6 text-lg rounded-xl">
            <span className="flex items-center justify-center gap-2">
              Get Started Now
              <ExternalLink className="w-5 h-5" />
            </span>
          </Button>

          {/* Stats */}
          <div className="flex items-center justify-around py-4 bg-white rounded-xl border border-gray-200">
            <div className="text-center">
              <div className="text-2xl font-bold text-purple-600">50K+</div>
              <div className="text-xs text-gray-600">Users</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-pink-600">4.9</div>
              <div className="text-xs text-gray-600">Rating</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-orange-600">1M+</div>
              <div className="text-xs text-gray-600">Downloads</div>
            </div>
          </div>

          {/* Development Info */}
          {isDevelopment && (
            <div className="bg-gray-100 rounded-xl p-4">
              <p className="text-xs text-gray-600 mb-1">
                <strong>Native Ad Type:</strong> Large Layout
              </p>
              <p className="text-[10px] text-gray-500 font-mono">
                Ad Unit ID: {NATIVE_AD_ID}
              </p>
            </div>
          )}
        </div>
      </div>
    </motion.div>
  );
}
