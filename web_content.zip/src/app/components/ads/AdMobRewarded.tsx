import { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, Clock, Gift, Star, Check } from 'lucide-react';
import { REWARDED_AD_ID, isDevelopment, AdSettings } from '../../config/admob.config';
import { Button } from '../ui/button';

interface AdMobRewardedProps {
  isOpen: boolean;
  onClose: () => void;
  onRewardEarned: (reward: number) => void;
  rewardAmount?: number;
  rewardName?: string;
}

export function AdMobRewarded({ 
  isOpen, 
  onClose, 
  onRewardEarned,
  rewardAmount = AdSettings.rewarded.rewardAmount,
  rewardName = 'Points'
}: AdMobRewardedProps) {
  const [progress, setProgress] = useState(0);
  const [isLoading, setIsLoading] = useState(true);
  const [isWatching, setIsWatching] = useState(false);
  const [isComplete, setIsComplete] = useState(false);
  const [canSkip, setCanSkip] = useState(false);
  const adDuration = 30; // 30 seconds

  useEffect(() => {
    if (isOpen) {
      // Reset states
      setProgress(0);
      setIsLoading(true);
      setIsWatching(false);
      setIsComplete(false);
      setCanSkip(false);

      // Simulate ad loading
      const loadTimeout = setTimeout(() => {
        setIsLoading(false);
        setIsWatching(true);
      }, 2000);

      // Log impression
      console.log(`[AdMob] Rewarded Ad Shown - ID: ${REWARDED_AD_ID}`);
      const impressions = JSON.parse(localStorage.getItem('admob_rewarded_impressions') || '0');
      localStorage.setItem('admob_rewarded_impressions', String(impressions + 1));

      return () => clearTimeout(loadTimeout);
    }
  }, [isOpen]);

  useEffect(() => {
    if (isWatching && !isComplete) {
      const interval = setInterval(() => {
        setProgress((prev) => {
          const newProgress = prev + (100 / adDuration);
          
          // Allow skip after 80% completion
          if (newProgress >= 80 && !canSkip) {
            setCanSkip(true);
          }

          if (newProgress >= 100) {
            setIsComplete(true);
            setIsWatching(false);
            
            // Grant reward
            console.log(`[AdMob] Reward Earned: ${rewardAmount} ${rewardName}`);
            const rewards = JSON.parse(localStorage.getItem('admob_rewards_earned') || '0');
            localStorage.setItem('admob_rewards_earned', String(rewards + rewardAmount));
            
            onRewardEarned(rewardAmount);
            return 100;
          }
          
          return newProgress;
        });
      }, 1000);

      return () => clearInterval(interval);
    }
  }, [isWatching, isComplete, onRewardEarned, rewardAmount, rewardName, canSkip]);

  const handleClose = () => {
    if (isComplete || canSkip) {
      console.log('[AdMob] Rewarded Ad Closed');
      onClose();
    }
  };

  const handleSkip = () => {
    if (!canSkip) return;
    
    console.log('[AdMob] Rewarded Ad Skipped (after 80%)');
    setIsComplete(true);
    setIsWatching(false);
    
    // Grant partial reward
    const partialReward = Math.floor(rewardAmount * 0.8);
    onRewardEarned(partialReward);
  };

  if (!AdSettings.rewarded.enabled) {
    return null;
  }

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-[100] bg-black/90 backdrop-blur-sm flex items-center justify-center p-4"
        >
          {isLoading ? (
            // Loading state
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              className="bg-white rounded-3xl p-8 max-w-md w-full text-center"
            >
              <div className="w-16 h-16 mx-auto mb-4">
                <motion.div
                  animate={{ rotate: 360 }}
                  transition={{ duration: 2, repeat: Infinity, ease: 'linear' }}
                  className="w-full h-full border-4 border-yellow-500 border-t-transparent rounded-full"
                />
              </div>
              <p className="text-gray-600 mb-2">Preparing Your Reward...</p>
              <p className="text-sm text-gray-500">Loading advertisement</p>
              {isDevelopment && (
                <p className="text-xs text-gray-400 mt-4 font-mono">Test Rewarded Ad</p>
              )}
            </motion.div>
          ) : isComplete ? (
            // Reward earned state
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="bg-gradient-to-br from-yellow-400 via-orange-500 to-pink-600 rounded-3xl p-8 max-w-md w-full text-center relative overflow-hidden"
            >
              {/* Celebration animation */}
              <div className="absolute inset-0 pointer-events-none">
                {[...Array(20)].map((_, i) => (
                  <motion.div
                    key={i}
                    initial={{ 
                      opacity: 0, 
                      scale: 0,
                      x: '50%',
                      y: '50%'
                    }}
                    animate={{ 
                      opacity: [0, 1, 0],
                      scale: [0, 2, 3],
                      x: `${50 + (Math.random() - 0.5) * 100}%`,
                      y: `${50 + (Math.random() - 0.5) * 100}%`
                    }}
                    transition={{
                      duration: 1.5,
                      delay: i * 0.05,
                      ease: 'easeOut'
                    }}
                    className="absolute text-2xl"
                  >
                    {['⭐', '💰', '🎁', '✨'][i % 4]}
                  </motion.div>
                ))}
              </div>

              {/* Content */}
              <div className="relative z-10 text-white">
                <motion.div
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  transition={{ type: 'spring', delay: 0.2 }}
                  className="w-24 h-24 mx-auto mb-6 bg-white/20 backdrop-blur-xl rounded-full flex items-center justify-center border-4 border-white"
                >
                  <Check className="w-12 h-12" />
                </motion.div>

                <motion.h2
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.3 }}
                  className="text-3xl mb-4"
                >
                  Reward Earned! 🎉
                </motion.h2>

                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.4 }}
                  className="bg-white/20 backdrop-blur-xl rounded-2xl p-6 mb-6 border border-white/30"
                >
                  <div className="flex items-center justify-center gap-3 mb-2">
                    <Star className="w-8 h-8 fill-white" />
                    <span className="text-5xl">+{rewardAmount}</span>
                    <Star className="w-8 h-8 fill-white" />
                  </div>
                  <p className="text-lg opacity-90">{rewardName} Added!</p>
                </motion.div>

                <Button
                  onClick={handleClose}
                  className="bg-white text-orange-600 hover:bg-orange-50 px-8 py-6 text-lg rounded-2xl w-full"
                >
                  Claim Reward
                </Button>

                {isDevelopment && (
                  <p className="text-xs opacity-70 mt-4 font-mono">Test Rewarded Ad Complete</p>
                )}
              </div>
            </motion.div>
          ) : (
            // Watching ad state
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="relative bg-gradient-to-br from-indigo-600 via-purple-600 to-pink-600 rounded-3xl overflow-hidden max-w-lg w-full shadow-2xl"
            >
              {/* Skip Button (only after 80%) */}
              {canSkip && (
                <button
                  onClick={handleSkip}
                  className="absolute top-4 right-4 z-10 bg-black/50 backdrop-blur-sm text-white px-4 py-2 rounded-full hover:bg-black/70 transition-all"
                >
                  Skip Ad →
                </button>
              )}

              {/* Development Badge */}
              {isDevelopment && (
                <div className="absolute top-4 left-4 z-10 bg-yellow-400 text-yellow-900 px-3 py-1 rounded-full text-xs font-bold">
                  🧪 TEST REWARDED
                </div>
              )}

              {/* Progress Bar */}
              <div className="absolute top-0 left-0 right-0 h-2 bg-black/30 z-20">
                <motion.div
                  className="h-full bg-gradient-to-r from-yellow-400 to-orange-500"
                  initial={{ width: 0 }}
                  animate={{ width: `${progress}%` }}
                  transition={{ duration: 0.5 }}
                />
              </div>

              {/* Timer */}
              <div className="absolute top-12 right-4 z-10 bg-black/50 backdrop-blur-md text-white px-4 py-2 rounded-xl flex items-center gap-2">
                <Clock className="w-4 h-4" />
                <span className="text-sm font-medium">
                  {Math.ceil((100 - progress) * adDuration / 100)}s
                </span>
              </div>

              {/* Ad Content */}
              <div className="relative min-h-[500px] flex flex-col">
                {/* Background Pattern */}
                <div className="absolute inset-0 opacity-20">
                  <div className="absolute inset-0" style={{
                    backgroundImage: 'repeating-linear-gradient(45deg, transparent, transparent 20px, rgba(255,255,255,.1) 20px, rgba(255,255,255,.1) 40px)'
                  }} />
                </div>

                {/* Main Content */}
                <div className="relative z-10 flex-1 flex flex-col items-center justify-center p-8 text-center text-white">
                  {/* Reward Preview */}
                  <motion.div
                    animate={{ 
                      scale: [1, 1.1, 1],
                      rotate: [0, 5, -5, 0]
                    }}
                    transition={{ 
                      duration: 2,
                      repeat: Infinity,
                      ease: 'easeInOut'
                    }}
                    className="w-32 h-32 bg-white/20 backdrop-blur-xl rounded-3xl flex items-center justify-center mb-6 border-4 border-white/30"
                  >
                    <Gift className="w-16 h-16" />
                  </motion.div>

                  {/* Ad Title */}
                  <h2 className="text-3xl mb-4">
                    {isDevelopment ? 'Test Rewarded Ad' : 'Watch & Earn!'}
                  </h2>

                  {/* Ad Description */}
                  <p className="text-lg opacity-90 mb-6">
                    {isDevelopment 
                      ? 'This is a test rewarded ad. Watch the entire ad to earn your reward.'
                      : 'Watch this short video to earn your reward!'
                    }
                  </p>

                  {/* Reward Info */}
                  <div className="bg-white/20 backdrop-blur-xl rounded-2xl p-6 mb-6 border border-white/30">
                    <div className="flex items-center justify-center gap-3 mb-2">
                      <Star className="w-6 h-6 fill-yellow-300" />
                      <span className="text-4xl font-bold">+{rewardAmount}</span>
                      <Star className="w-6 h-6 fill-yellow-300" />
                    </div>
                    <p className="text-sm opacity-90">{rewardName} Reward</p>
                    <p className="text-xs opacity-70 mt-2">
                      Watch {canSkip ? '80%' : '100%'} to claim
                    </p>
                  </div>

                  {/* Progress Info */}
                  <div className="text-sm opacity-70">
                    Progress: {Math.floor(progress)}%
                  </div>
                </div>

                {/* Ad Footer */}
                <div className="relative z-10 bg-black/20 backdrop-blur-md px-6 py-4 border-t border-white/10">
                  <div className="flex items-center justify-between text-white text-sm">
                    <div className="flex items-center gap-2">
                      <div className="bg-white/20 px-2 py-1 rounded text-xs">Rewarded Ad</div>
                      <span className="opacity-70">Watch to earn rewards</span>
                    </div>
                    {isDevelopment && (
                      <span className="text-xs opacity-50 font-mono">
                        {REWARDED_AD_ID.slice(0, 20)}...
                      </span>
                    )}
                  </div>
                </div>
              </div>
            </motion.div>
          )}
        </motion.div>
      )}
    </AnimatePresence>
  );
}

// ═══════════════════════════════════════════════════════════════
// 🎯 HOOK: useRewardedAd
// ═══════════════════════════════════════════════════════════════

export function useRewardedAd() {
  const [showAd, setShowAd] = useState(false);
  const [reward, setReward] = useState(0);

  const requestRewardedAd = () => {
    if (!AdSettings.rewarded.enabled) {
      console.warn('[AdMob] Rewarded ads are disabled');
      return false;
    }
    setShowAd(true);
    return true;
  };

  const closeAd = () => {
    setShowAd(false);
  };

  const handleRewardEarned = (amount: number) => {
    setReward(amount);
    console.log(`[AdMob] Reward earned: ${amount}`);
  };

  return {
    showAd,
    reward,
    requestRewardedAd,
    closeAd,
    handleRewardEarned,
  };
}
