import { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, Clock, ExternalLink } from 'lucide-react';
import { INTERSTITIAL_AD_ID, isDevelopment, AdSettings } from '../../config/admob.config';
import { Button } from '../ui/button';

interface AdMobInterstitialProps {
  isOpen: boolean;
  onClose: () => void;
  onAdWatched?: () => void;
}

export function AdMobInterstitial({ isOpen, onClose, onAdWatched }: AdMobInterstitialProps) {
  const [countdown, setCountdown] = useState(5);
  const [canClose, setCanClose] = useState(false);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    if (isOpen) {
      // Reset states
      setCountdown(5);
      setCanClose(false);
      setIsLoading(true);

      // Simulate ad loading
      const loadTimeout = setTimeout(() => {
        setIsLoading(false);
      }, 1500);

      // Log impression
      console.log(`[AdMob] Interstitial Ad Shown - ID: ${INTERSTITIAL_AD_ID}`);
      const impressions = JSON.parse(localStorage.getItem('admob_interstitial_impressions') || '0');
      localStorage.setItem('admob_interstitial_impressions', String(impressions + 1));

      return () => clearTimeout(loadTimeout);
    }
  }, [isOpen]);

  useEffect(() => {
    if (isOpen && !isLoading && countdown > 0) {
      const timer = setInterval(() => {
        setCountdown((prev) => {
          if (prev <= 1) {
            setCanClose(true);
            return 0;
          }
          return prev - 1;
        });
      }, 1000);

      return () => clearInterval(timer);
    }
  }, [isOpen, isLoading, countdown]);

  const handleClose = () => {
    if (canClose) {
      console.log('[AdMob] Interstitial Ad Closed');
      onClose();
      if (onAdWatched) {
        onAdWatched();
      }
    }
  };

  const handleAdClick = () => {
    console.log('[AdMob] Interstitial Ad Clicked');
    const clicks = JSON.parse(localStorage.getItem('admob_interstitial_clicks') || '0');
    localStorage.setItem('admob_interstitial_clicks', String(clicks + 1));
  };

  if (!AdSettings.interstitial.enabled) {
    return null;
  }

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-[100] bg-black/80 backdrop-blur-sm flex items-center justify-center p-4"
        >
          {isLoading ? (
            // Loading state
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              className="bg-white rounded-3xl p-8 max-w-md w-full text-center"
            >
              <div className="w-16 h-16 mx-auto mb-4 border-4 border-purple-500 border-t-transparent rounded-full animate-spin" />
              <p className="text-gray-600">Loading Advertisement...</p>
              {isDevelopment && (
                <p className="text-xs text-gray-400 mt-2 font-mono">Test Mode Active</p>
              )}
            </motion.div>
          ) : (
            // Ad content
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="relative bg-gradient-to-br from-purple-600 via-pink-600 to-red-600 rounded-3xl overflow-hidden max-w-lg w-full shadow-2xl"
            >
              {/* Close Button */}
              <button
                onClick={handleClose}
                disabled={!canClose}
                className={`absolute top-4 right-4 z-10 bg-black/50 backdrop-blur-sm text-white p-2 rounded-full transition-all ${
                  canClose ? 'hover:bg-black/70 cursor-pointer' : 'opacity-50 cursor-not-allowed'
                }`}
                title={canClose ? 'Close Ad' : `Wait ${countdown}s`}
              >
                {canClose ? (
                  <X className="w-5 h-5" />
                ) : (
                  <div className="w-5 h-5 flex items-center justify-center text-xs font-bold">
                    {countdown}
                  </div>
                )}
              </button>

              {/* Development Badge */}
              {isDevelopment && (
                <div className="absolute top-4 left-4 z-10 bg-yellow-400 text-yellow-900 px-3 py-1 rounded-full text-xs font-bold">
                  🧪 TEST AD
                </div>
              )}

              {/* Countdown Timer */}
              {!canClose && (
                <div className="absolute top-16 right-4 z-10 bg-white/20 backdrop-blur-md text-white px-3 py-2 rounded-xl flex items-center gap-2 border border-white/30">
                  <Clock className="w-4 h-4" />
                  <span className="text-sm font-medium">{countdown}s</span>
                </div>
              )}

              {/* Ad Content */}
              <div className="relative min-h-[400px] flex flex-col">
                {/* Background Pattern */}
                <div className="absolute inset-0 opacity-20">
                  <div className="absolute inset-0" style={{
                    backgroundImage: 'repeating-linear-gradient(45deg, transparent, transparent 20px, rgba(255,255,255,.1) 20px, rgba(255,255,255,.1) 40px)'
                  }} />
                </div>

                {/* Main Content */}
                <div className="relative z-10 flex-1 flex flex-col items-center justify-center p-8 text-center text-white">
                  {/* Ad Icon/Image */}
                  <div className="w-32 h-32 bg-white/20 backdrop-blur-xl rounded-3xl flex items-center justify-center mb-6 border border-white/30">
                    <div className="text-6xl">🎯</div>
                  </div>

                  {/* Ad Title */}
                  <h2 className="text-3xl mb-4">
                    {isDevelopment ? 'Test Interstitial Ad' : 'Special Offer!'}
                  </h2>

                  {/* Ad Description */}
                  <p className="text-lg opacity-90 mb-6">
                    {isDevelopment 
                      ? 'This is a Google AdMob test interstitial advertisement. In production, real ads will appear here.'
                      : 'Amazing deals waiting for you! Click to learn more about this exclusive offer.'
                    }
                  </p>

                  {/* Ad ID (Development Only) */}
                  {isDevelopment && (
                    <p className="text-xs opacity-70 font-mono mb-6 bg-black/20 px-4 py-2 rounded-lg">
                      ID: {INTERSTITIAL_AD_ID.slice(0, 40)}...
                    </p>
                  )}

                  {/* CTA Button */}
                  <Button
                    onClick={handleAdClick}
                    className="bg-white text-purple-600 hover:bg-purple-50 px-8 py-6 text-lg rounded-2xl shadow-xl"
                  >
                    <span className="flex items-center gap-2">
                      Learn More
                      <ExternalLink className="w-5 h-5" />
                    </span>
                  </Button>
                </div>

                {/* Ad Footer */}
                <div className="relative z-10 bg-black/20 backdrop-blur-md px-6 py-4 border-t border-white/10">
                  <div className="flex items-center justify-between text-white text-sm">
                    <div className="flex items-center gap-2">
                      <div className="bg-white/20 px-2 py-1 rounded text-xs">Ad</div>
                      <span className="opacity-70">Sponsored Content</span>
                    </div>
                    {canClose && (
                      <button
                        onClick={handleClose}
                        className="text-white/70 hover:text-white transition-colors"
                      >
                        Skip Ad →
                      </button>
                    )}
                  </div>
                </div>
              </div>
            </motion.div>
          )}
        </motion.div>
      )}
    </AnimatePresence>
  );
}

// ═══════════════════════════════════════════════════════════════
// 🎯 HOOK: useInterstitialAd
// ═══════════════════════════════════════════════════════════════

let actionCount = 0;
let lastAdTime = 0;

export function useInterstitialAd() {
  const [showAd, setShowAd] = useState(false);

  const checkAndShowAd = () => {
    if (!AdSettings.interstitial.enabled) return false;

    actionCount++;
    const now = Date.now();
    const timeSinceLastAd = now - lastAdTime;

    // Check if enough actions have passed and cooldown is over
    if (
      actionCount >= AdSettings.interstitial.showAfterActions &&
      timeSinceLastAd >= AdSettings.interstitial.cooldownTime
    ) {
      actionCount = 0;
      lastAdTime = now;
      setShowAd(true);
      return true;
    }

    return false;
  };

  const closeAd = () => {
    setShowAd(false);
  };

  return {
    showAd,
    checkAndShowAd,
    closeAd,
  };
}
