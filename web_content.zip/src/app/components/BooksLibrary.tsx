import { useState } from 'react';
import { ArrowLeft, Search, BookOpen, Download, Eye, Star, Filter, Calendar, User, Plus, X, Upload, FileText } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Textarea } from './ui/textarea';
import { Badge } from './ui/badge';
import { translations } from '../translations';
import { AdBanner } from './AdBanner';
import { completeBookDatabase, bookCategories, searchBooks, getBooksByCategory, Book } from '../data/books-database';
import { BookCoverGenerator } from './BookCoverGenerator';

interface BooksLibraryProps {
  language: 'ps' | 'fa' | 'en';
  onBack: () => void;
  currentUserEmail?: string;
}

export function BooksLibrary({ language, onBack, currentUserEmail }: BooksLibraryProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [selectedBook, setSelectedBook] = useState<Book | null>(null);
  const [showAddBookModal, setShowAddBookModal] = useState(false);
  
  // د نوي کتاب معلومات
  const [newBookData, setNewBookData] = useState({
    title: '',
    author: '',
    category: '',
    description: '',
    pages: '',
    publishYear: '',
    pdfFile: null as File | null,
  });
  
  const t = translations[language];
  // ټول کاروونکي کولی شي کتابونه upload کړي
  // All users can upload books

  // د کتابونو ګټلو د search یا category له مخې
  const displayBooks = searchQuery 
    ? searchBooks(searchQuery)
    : getBooksByCategory(selectedCategory);

  const translations_books = {
    ps: {
      title: 'د کتابونو کتابتون',
      subtitle: 'طبي کتابونه',
      search: 'کتابونه ولټوئ...',
      found: 'کتابونه وموندل شول',
      read: 'لوستل',
      download: 'ډاونلوډ',
      addBook: 'نوی کتاب اضافه کړئ',
      bookDetails: 'د کتاب تفصیلات',
      author: 'لیکوال:',
      pages: 'مخونه:',
      publishYear: 'د خپرېدو کال:',
      language_label: 'ژبه:',
      rating: 'درجه بندي:',
      downloads_label: 'ډاونلوډونه:',
      category: 'کټګوري:',
      description: 'تفصیل:',
      content: 'مینځپانګه:',
      close: 'بندول',
      premium: 'Premium',
      free: 'وړیا',
      uploadPDF: 'PDF فایل پورته کړئ',
      pdfOnly: 'یوازې PDF فایلونه',
      bookTitle: 'د کتاب نوم',
      selectCategory: 'کټګوري غوره کړئ',
      coverPreview: 'د کتاب عکس (اتومات)',
    },
    fa: {
      title: 'کتابخانه',
      subtitle: 'کتب طبی',
      search: 'جستجوی کتاب...',
      found: 'کتاب پیدا شد',
      read: 'خواندن',
      download: 'دانلود',
      addBook: 'افزودن کتاب جدید',
      bookDetails: 'جزئیات کتاب',
      author: 'نویسنده:',
      pages: 'صفحات:',
      publishYear: 'سال انتشار:',
      language_label: 'زبان:',
      rating: 'امتیاز:',
      downloads_label: 'دانلودها:',
      category: 'دسته:',
      description: 'توضیحات:',
      content: 'محتوا:',
      close: 'بستن',
      premium: 'پریمیوم',
      free: 'رایگان',
      uploadPDF: 'آپلود فایل PDF',
      pdfOnly: 'فقط فایل‌های PDF',
      bookTitle: 'نام کتاب',
      selectCategory: 'انتخاب دسته',
      coverPreview: 'تصویر کتاب (خودکار)',
    },
    en: {
      title: 'Books Library',
      subtitle: 'Medical Books',
      search: 'Search books...',
      found: 'books found',
      read: 'Read',
      download: 'Download',
      addBook: 'Add New Book',
      bookDetails: 'Book Details',
      author: 'Author:',
      pages: 'Pages:',
      publishYear: 'Publish Year:',
      language_label: 'Language:',
      rating: 'Rating:',
      downloads_label: 'Downloads:',
      category: 'Category:',
      description: 'Description:',
      content: 'Content:',
      close: 'Close',
      premium: 'Premium',
      free: 'Free',
      uploadPDF: 'Upload PDF File',
      pdfOnly: 'PDF files only',
      bookTitle: 'Book Title',
      selectCategory: 'Select Category',
      coverPreview: 'Book Cover (Auto-generated)',
      premium: 'Premium',
      free: 'Free',
    }
  };

  const tb = translations_books[language];

  return (
    <div className="min-h-screen bg-gradient-to-br from-amber-50 via-orange-50 to-yellow-50 pb-28 md:pb-8">
      {/* Header */}
      <div className="sticky top-0 z-40 backdrop-blur-xl bg-white/80 border-b border-white/20 shadow-lg">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center gap-4 mb-4">
            <Button variant="ghost" size="icon" onClick={onBack}>
              <ArrowLeft className="w-5 h-5" />
            </Button>
            <div className="flex-1">
              <h1 className="text-2xl bg-gradient-to-r from-amber-600 to-orange-600 bg-clip-text text-transparent">
                {tb.title}
              </h1>
              <p className="text-sm text-gray-600">
                {completeBookDatabase.length}+ {tb.subtitle}
              </p>
            </div>
            
            {/* د نوي کتاب اضافه کولو بټن - ټولو لپاره */}
            <Button
              onClick={() => setShowAddBookModal(true)}
              className="bg-gradient-to-r from-green-600 to-emerald-600 text-white"
            >
              <Plus className="w-4 h-4 mr-2" />
              {tb.addBook}
            </Button>
          </div>

          {/* Search */}
          <div className="relative mb-4">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
            <Input
              type="text"
              placeholder={tb.search}
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10 bg-white/80 backdrop-blur-md border-white/20"
              style={{ fontSize: '16px' }}
            />
          </div>

          {/* Categories */}
          <div className="overflow-x-auto pb-2">
            <div className="flex gap-2 min-w-max">
              {bookCategories.map((cat) => (
                <button
                  key={cat.id}
                  onClick={() => {
                    setSelectedCategory(cat.id);
                    setSearchQuery('');
                  }}
                  className={`px-4 py-2 rounded-full text-sm whitespace-nowrap transition-all ${
                    selectedCategory === cat.id
                      ? 'bg-gradient-to-r from-amber-600 to-orange-600 text-white shadow-lg'
                      : 'bg-white/80 text-gray-700 hover:bg-white'
                  }`}
                >
                  {language === 'ps' ? cat.pashto : language === 'fa' ? cat.dari : cat.name}
                  {selectedCategory === cat.id && ` (${displayBooks.length})`}
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="container mx-auto px-4 mt-6">
        <AdBanner type="medium" className="mb-6" />

        {/* Results Count */}
        <div className="mb-4 text-center">
          <p className="text-gray-600">
            {displayBooks.length} {tb.found}
          </p>
        </div>

        {/* Books Grid */}
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4">
          {displayBooks.map((book, index) => (
            <motion.div
              key={book.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: Math.min(index * 0.05, 1) }}
              className="group cursor-pointer"
              onClick={() => setSelectedBook(book)}
            >
              <div className="relative bg-white/90 backdrop-blur-xl rounded-2xl overflow-hidden border border-white/20 shadow-xl hover:shadow-2xl transition-all hover:-translate-y-2">
                {/* Book Cover */}
                <div className="relative h-48 md:h-64 bg-gradient-to-br from-amber-100 to-orange-100 overflow-hidden">
                  <img 
                    src={book.cover} 
                    alt={book.title}
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
                  
                  {/* Premium Badge */}
                  {book.isPremium && (
                    <Badge className="absolute top-2 right-2 bg-yellow-500 text-white">
                      {tb.premium}
                    </Badge>
                  )}
                  
                  {/* Rating */}
                  <div className="absolute bottom-2 left-2 flex items-center gap-1 bg-black/50 backdrop-blur-sm px-2 py-1 rounded-full">
                    <Star className="w-3 h-3 text-yellow-400 fill-yellow-400" />
                    <span className="text-xs text-white font-bold">{book.rating}</span>
                  </div>
                </div>

                {/* Book Info */}
                <div className="p-3">
                  <h3 className="text-sm font-bold mb-1 line-clamp-2 h-10">
                    {language === 'ps' ? book.titlePashto : language === 'fa' ? book.titleDari : book.title}
                  </h3>
                  <p className="text-xs text-gray-600 mb-2 line-clamp-1">
                    {language === 'ps' ? book.authorPashto : language === 'fa' ? book.authorDari : book.author}
                  </p>
                  
                  {/* Stats */}
                  <div className="flex items-center justify-between text-xs text-gray-500 mb-2">
                    <span className="flex items-center gap-1">
                      <BookOpen className="w-3 h-3" />
                      {book.pages}
                    </span>
                    <span className="flex items-center gap-1">
                      <Download className="w-3 h-3" />
                      {book.downloads}
                    </span>
                  </div>

                  {/* Read Button */}
                  <Button 
                    size="sm" 
                    className="w-full bg-gradient-to-r from-amber-600 to-orange-600 hover:from-amber-700 hover:to-orange-700 text-white"
                    onClick={(e) => {
                      e.stopPropagation();
                      setSelectedBook(book);
                    }}
                  >
                    <Eye className="w-3 h-3 mr-1" />
                    {tb.read}
                  </Button>
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        {displayBooks.length === 0 && (
          <div className="text-center py-12">
            <BookOpen className="w-16 h-16 mx-auto mb-4 text-gray-400" />
            <h3 className="text-xl mb-2">
              {language === 'ps' ? 'کتاب ونه موندل شو' : language === 'fa' ? 'کتابی پیدا نشد' : 'No books found'}
            </h3>
            <p className="text-gray-600">
              {language === 'ps' ? 'مهرباني وکړئ بل څه ولټوئ' : language === 'fa' ? 'لطفاً چیز دیگری جستجو کنید' : 'Please try another search'}
            </p>
          </div>
        )}

        <AdBanner type="large" className="mt-8" />
      </div>

      {/* Book Detail Modal */}
      <AnimatePresence>
        {selectedBook && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm overflow-y-auto"
            onClick={() => setSelectedBook(null)}
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0, y: 20 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.9, opacity: 0, y: 20 }}
              className="relative bg-white rounded-3xl w-full max-w-4xl my-8 shadow-2xl"
              onClick={(e) => e.stopPropagation()}
            >
              {/* Close Button */}
              <button
                className="absolute top-4 right-4 z-10 w-10 h-10 bg-red-500 hover:bg-red-600 text-white rounded-full flex items-center justify-center shadow-lg transition-all hover:scale-110"
                onClick={() => setSelectedBook(null)}
              >
                <X className="w-5 h-5" />
              </button>

              {/* Scrollable Content */}
              <div className="overflow-y-auto max-h-[85vh] p-6 md:p-8">
                <div className="flex flex-col md:flex-row gap-6">
                  {/* Book Cover */}
                  <div className="md:w-1/3">
                    <div className="relative rounded-2xl overflow-hidden shadow-2xl">
                      <img 
                        src={selectedBook.cover} 
                        alt={selectedBook.title}
                        className="w-full h-auto"
                      />
                      {selectedBook.isPremium && (
                        <Badge className="absolute top-4 right-4 bg-yellow-500 text-white">
                          {tb.premium}
                        </Badge>
                      )}
                    </div>
                  </div>

                  {/* Book Details */}
                  <div className="md:w-2/3">
                    <h2 className="text-2xl md:text-3xl mb-3 font-bold text-gray-800">
                      {language === 'ps' ? selectedBook.titlePashto : language === 'fa' ? selectedBook.titleDari : selectedBook.title}
                    </h2>

                    <div className="space-y-3 mb-6">
                      <div className="flex items-center gap-2">
                        <User className="w-5 h-5 text-gray-500" />
                        <span className="text-gray-600">{tb.author}</span>
                        <span className="font-medium">
                          {language === 'ps' ? selectedBook.authorPashto : language === 'fa' ? selectedBook.authorDari : selectedBook.author}
                        </span>
                      </div>

                      <div className="flex items-center gap-2">
                        <BookOpen className="w-5 h-5 text-gray-500" />
                        <span className="text-gray-600">{tb.pages}</span>
                        <span className="font-medium">{selectedBook.pages}</span>
                      </div>

                      <div className="flex items-center gap-2">
                        <Calendar className="w-5 h-5 text-gray-500" />
                        <span className="text-gray-600">{tb.publishYear}</span>
                        <span className="font-medium">{selectedBook.publishYear}</span>
                      </div>

                      <div className="flex items-center gap-2">
                        <Filter className="w-5 h-5 text-gray-500" />
                        <span className="text-gray-600">{tb.language_label}</span>
                        <span className="font-medium">{selectedBook.language}</span>
                      </div>

                      <div className="flex items-center gap-2">
                        <Star className="w-5 h-5 text-yellow-500 fill-yellow-500" />
                        <span className="text-gray-600">{tb.rating}</span>
                        <span className="font-medium">{selectedBook.rating}/5.0</span>
                      </div>

                      <div className="flex items-center gap-2">
                        <Download className="w-5 h-5 text-gray-500" />
                        <span className="text-gray-600">{tb.downloads_label}</span>
                        <span className="font-medium">{selectedBook.downloads}</span>
                      </div>
                    </div>

                    {/* Description */}
                    <div className="bg-amber-50 rounded-2xl p-4 mb-4">
                      <h3 className="font-bold mb-2 text-amber-800">{tb.description}</h3>
                      <p className="text-gray-700 text-sm leading-relaxed">
                        {language === 'ps' ? selectedBook.descriptionPashto : language === 'fa' ? selectedBook.descriptionDari : selectedBook.description}
                      </p>
                    </div>

                    {/* Content */}
                    <div className="bg-orange-50 rounded-2xl p-4 mb-4">
                      <h3 className="font-bold mb-2 text-orange-800">{tb.content}</h3>
                      <div className="text-gray-700 text-sm leading-relaxed whitespace-pre-line max-h-64 overflow-y-auto">
                        {language === 'ps' ? selectedBook.contentPashto : language === 'fa' ? selectedBook.contentDari : selectedBook.content}
                      </div>
                    </div>

                    {/* Actions */}
                    <div className="flex gap-3">
                      <Button 
                        className="flex-1 bg-gradient-to-r from-amber-600 to-orange-600 hover:from-amber-700 hover:to-orange-700 text-white py-6"
                        onClick={() => {
                          alert(language === 'ps' ? 'د کتاب لوستل پیل کیږي...' : language === 'fa' ? 'شروع به خواندن کتاب...' : 'Starting to read book...');
                        }}
                      >
                        <Eye className="w-5 h-5 mr-2" />
                        {tb.read}
                      </Button>
                      <Button 
                        variant="outline"
                        className="flex-1 border-amber-600 text-amber-600 hover:bg-amber-50 py-6"
                        onClick={() => {
                          alert(language === 'ps' ? 'کتاب ډاونلوډ کیږي...' : language === 'fa' ? 'در حال دانلود کتاب...' : 'Downloading book...');
                        }}
                      >
                        <Download className="w-5 h-5 mr-2" />
                        {tb.download}
                      </Button>
                    </div>
                  </div>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Add New Book Modal - د ټولو لپاره */}
      <AnimatePresence>
        {showAddBookModal && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm overflow-y-auto"
            onClick={() => setShowAddBookModal(false)}
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="relative bg-white rounded-3xl w-full max-w-2xl my-8 shadow-2xl"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="p-6 md:p-8">
                <div className="flex items-center justify-between mb-6">
                  <h2 className="text-2xl font-bold bg-gradient-to-r from-green-600 to-emerald-600 bg-clip-text text-transparent">
                    {tb.addBook}
                  </h2>
                  <button
                    className="w-10 h-10 bg-red-500 hover:bg-red-600 text-white rounded-full flex items-center justify-center"
                    onClick={() => setShowAddBookModal(false)}
                  >
                    <X className="w-5 h-5" />
                  </button>
                </div>

                <div className="space-y-5">
                  {/* د کتاب نوم */}
                  <div>
                    <label className="block text-sm font-medium mb-2">
                      {tb.bookTitle} <span className="text-red-500">*</span>
                    </label>
                    <Input 
                      value={newBookData.title}
                      onChange={(e) => setNewBookData({ ...newBookData, title: e.target.value })}
                      placeholder={language === 'ps' ? 'د کتاب نوم دلته ولیکئ' : language === 'fa' ? 'نام کتاب را اینجا بنویسید' : 'Enter book title'}
                      style={{ fontSize: '16px' }}
                      required
                    />
                  </div>

                  {/* لیکوال */}
                  <div>
                    <label className="block text-sm font-medium mb-2">
                      {tb.author} <span className="text-red-500">*</span>
                    </label>
                    <Input 
                      value={newBookData.author}
                      onChange={(e) => setNewBookData({ ...newBookData, author: e.target.value })}
                      placeholder={language === 'ps' ? 'د لیکوال نوم' : language === 'fa' ? 'نام نویسنده' : 'Author name'}
                      style={{ fontSize: '16px' }}
                      required
                    />
                  </div>

                  {/* کټګوري */}
                  <div>
                    <label className="block text-sm font-medium mb-2">
                      {tb.category} <span className="text-red-500">*</span>
                    </label>
                    <select 
                      value={newBookData.category}
                      onChange={(e) => setNewBookData({ ...newBookData, category: e.target.value })}
                      className="w-full px-4 py-3 rounded-xl border border-gray-200" 
                      style={{ fontSize: '16px' }}
                      required
                    >
                      <option value="">{tb.selectCategory}</option>
                      {bookCategories.map(cat => (
                        <option key={cat.id} value={cat.id}>
                          {language === 'ps' ? cat.pashto : language === 'fa' ? cat.dari : cat.name}
                        </option>
                      ))}
                    </select>
                  </div>

                  {/* تفصیل */}
                  <div>
                    <label className="block text-sm font-medium mb-2">
                      {tb.description}
                    </label>
                    <Textarea 
                      value={newBookData.description}
                      onChange={(e) => setNewBookData({ ...newBookData, description: e.target.value })}
                      placeholder={language === 'ps' ? 'د کتاب په اړه لنډ تفصیل' : language === 'fa' ? 'توضیح کوتاه درباره کتاب' : 'Brief description about the book'}
                      rows={3}
                      style={{ fontSize: '16px' }}
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    {/* مخونه */}
                    <div>
                      <label className="block text-sm font-medium mb-2">
                        {tb.pages}
                      </label>
                      <Input 
                        type="number"
                        value={newBookData.pages}
                        onChange={(e) => setNewBookData({ ...newBookData, pages: e.target.value })}
                        placeholder="300"
                        style={{ fontSize: '16px' }}
                      />
                    </div>

                    {/* د خپرېدو کال */}
                    <div>
                      <label className="block text-sm font-medium mb-2">
                        {tb.publishYear}
                      </label>
                      <Input 
                        type="number"
                        value={newBookData.publishYear}
                        onChange={(e) => setNewBookData({ ...newBookData, publishYear: e.target.value })}
                        placeholder="2024"
                        style={{ fontSize: '16px' }}
                      />
                    </div>
                  </div>

                  {/* د اتومات عکس Preview */}
                  {newBookData.title && newBookData.author && (
                    <div>
                      <label className="block text-sm font-medium mb-2">
                        {tb.coverPreview}
                      </label>
                      <div className="w-full h-64 rounded-xl overflow-hidden border-2 border-gray-200">
                        <BookCoverGenerator 
                          title={newBookData.title}
                          author={newBookData.author}
                          category={newBookData.category}
                        />
                      </div>
                    </div>
                  )}
                  
                  {/* PDF Upload */}
                  <div>
                    <label className="block text-sm font-medium mb-2">
                      {tb.uploadPDF} <span className="text-red-500">*</span>
                    </label>
                    <div className="border-2 border-dashed border-gray-300 rounded-xl p-8 text-center cursor-pointer hover:border-green-500 transition-colors relative">
                      <input 
                        type="file" 
                        accept=".pdf"
                        onChange={(e) => {
                          const file = e.target.files?.[0];
                          if (file && file.type === 'application/pdf') {
                            setNewBookData({ ...newBookData, pdfFile: file });
                          } else {
                            alert(tb.pdfOnly);
                          }
                        }}
                        className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                      />
                      {newBookData.pdfFile ? (
                        <>
                          <FileText className="w-12 h-12 mx-auto mb-3 text-green-500" />
                          <p className="text-green-600 font-medium">{newBookData.pdfFile.name}</p>
                          <p className="text-sm text-gray-500 mt-1">
                            {(newBookData.pdfFile.size / 1024 / 1024).toFixed(2)} MB
                          </p>
                        </>
                      ) : (
                        <>
                          <Upload className="w-12 h-12 mx-auto mb-3 text-gray-400" />
                          <p className="text-gray-600 font-medium mb-1">
                            {tb.uploadPDF}
                          </p>
                          <p className="text-sm text-gray-500">
                            {tb.pdfOnly}
                          </p>
                        </>
                      )}
                    </div>
                  </div>

                  {/* Submit Button */}
                  <Button 
                    className="w-full bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-700 hover:to-emerald-700 text-white py-6"
                    onClick={() => {
                      if (!newBookData.title || !newBookData.author || !newBookData.category || !newBookData.pdfFile) {
                        alert(language === 'ps' ? 'مهرباني وکړئ ټولې مهمې برخې ډکې کړئ' : language === 'fa' ? 'لطفاً تمام فیلدهای ضروری را پر کنید' : 'Please fill all required fields');
                        return;
                      }
                      alert(language === 'ps' ? `کتاب "${newBookData.title}" بریالیتوب سره اضافه شو!` : language === 'fa' ? `کتاب "${newBookData.title}" با موفقیت اضافه شد!` : `Book "${newBookData.title}" added successfully!`);
                      setShowAddBookModal(false);
                      setNewBookData({
                        title: '',
                        author: '',
                        category: '',
                        description: '',
                        pages: '',
                        publishYear: '',
                        pdfFile: null,
                      });
                    }}
                  >
                    {tb.addBook}
                  </Button>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
