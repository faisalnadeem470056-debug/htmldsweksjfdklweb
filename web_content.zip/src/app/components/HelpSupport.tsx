import { ArrowLeft, HelpCircle, MessageCircle, Book, Video, Mail, Phone, Search, ExternalLink } from 'lucide-react';
import { useState } from 'react';
import { motion } from 'motion/react';
import { Button } from './ui/button';
import { Card, CardContent } from './ui/card';
import { Input } from './ui/input';
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from './ui/accordion';

interface HelpSupportProps {
  language: 'ps' | 'fa' | 'en';
  onBack: () => void;
}

export function HelpSupport({ language, onBack }: HelpSupportProps) {
  const [searchQuery, setSearchQuery] = useState('');

  const faqs = [
    {
      id: 'faq1',
      question: {
        ps: 'زه څنګه د HealMate اپلیکیشن نصب کړم؟',
        fa: 'چگونه برنامه HealMate را نصب کنم؟',
        en: 'How do I install the HealMate app?'
      },
      answer: {
        ps: 'تاسو کولی شئ HealMate د هر browser څخه وکاروئ. که غواړئ یې د app په توګه install کړئ، په خپل موبایل browser کې د site لاسرسي وکړئ او "Add to Home Screen" غوره کړئ. دا یو Progressive Web App (PWA) دی چې د native app په شان کار کوي.',
        fa: 'شما می‌توانید HealMate را از هر مرورگر استفاده کنید. اگر می‌خواهید آن را به عنوان برنامه نصب کنید، از مرورگر موبایل خود به سایت دسترسی پیدا کرده و "Add to Home Screen" را انتخاب کنید. این یک Progressive Web App (PWA) است که مانند برنامه بومی کار می‌کند.',
        en: 'You can use HealMate from any browser. If you want to install it as an app, access the site from your mobile browser and select "Add to Home Screen". This is a Progressive Web App (PWA) that works like a native app.'
      }
    },
    {
      id: 'faq2',
      question: {
        ps: 'ایا د HealMate کارول وړیا دی؟',
        fa: 'آیا استفاده از HealMate رایگان است؟',
        en: 'Is HealMate free to use?'
      },
      answer: {
        ps: 'هو، HealMate بشپړ وړیا دی! ټول فیچرونه او خدمتونه د افغانستان خلکو لپاره بغیر کومې هزینې شته دي. موږ د تبلیغاتو له لارې مالي ملاتړ ترلاسه کوو ترڅو خدمتونه وړیا وساتو.',
        fa: 'بله، HealMate کاملاً رایگان است! تمام ویژگی‌ها و خدمات برای مردم افغانستان بدون هیچ هزینه‌ای در دسترس است. ما از طریق تبلیغات حمایت مالی می‌کنیم تا خدمات را رایگان نگه داریم.',
        en: 'Yes, HealMate is completely free! All features and services are available to the people of Afghanistan at no cost. We are supported by ads to keep the services free.'
      }
    },
    {
      id: 'faq3',
      question: {
        ps: 'ایا زه کولی شم د بې انټرنیټ HealMate وکاروم؟',
        fa: 'آیا می‌توانم HealMate را بدون اینترنت استفاده کنم؟',
        en: 'Can I use HealMate offline?'
      },
      answer: {
        ps: 'ځینې فیچرونه لکه د saved medicines، first aid guides، او health tips د محدود offline لاسرسي لري. مګر د نویو معلوماتو لپاره، د ډاکټرانو لټون، او د community features لپاره تاسو ته internet اړتیا ده.',
        fa: 'برخی از ویژگی‌ها مانند داروهای ذخیره شده، راهنمای کمک‌های اولیه و نکات سلامتی دسترسی محدود آفلاین دارند. اما برای اطلاعات جدید، جستجوی داکتران و ویژگی‌های انجمن به اینترنت نیاز دارید.',
        en: 'Some features like saved medicines, first aid guides, and health tips have limited offline access. But for new information, doctor searches, and community features you need internet.'
      }
    },
    {
      id: 'faq4',
      question: {
        ps: 'زما معلومات څومره خوندي دي؟',
        fa: 'اطلاعات من چقدر ایمن است؟',
        en: 'How safe is my information?'
      },
      answer: {
        ps: 'موږ ستاسو محرمیت ډېر جدي اخلو. ټول معلومات د SSL/TLS encryption سره خوندي کیږي او په secure Firebase/Supabase servers کې ذخیره کیږي. موږ هیڅکله ستاسو معلومات third parties ته نه پلورو. د نورو معلوماتو لپاره زموږ Privacy Policy وګورئ.',
        fa: 'ما حریم خصوصی شما را بسیار جدی می‌گیریم. تمام اطلاعات با رمزگذاری SSL/TLS محافظت می‌شوند و در سرورهای امن Firebase/Supabase ذخیره می‌شوند. ما هرگز اطلاعات شما را به اشخاص ثالث نمی‌فروشیم. برای اطلاعات بیشتر سیاست حریم خصوصی ما را ببینید.',
        en: 'We take your privacy very seriously. All information is protected with SSL/TLS encryption and stored on secure Firebase/Supabase servers. We never sell your information to third parties. See our Privacy Policy for more information.'
      }
    },
    {
      id: 'faq5',
      question: {
        ps: 'زه څنګه د خپل profile عکس بدل کړم؟',
        fa: 'چگونه عکس پروفایل خود را تغییر دهم؟',
        en: 'How do I change my profile picture?'
      },
      answer: {
        ps: 'د Profile صفحې ته لاړشئ (د Bottom Navigation څخه د وروستي icon)، بیا د profile عکس په سر کلیک وکړئ. تاسو کولی شئ د خپلې وسیلې څخه یو نوی عکس غوره کړئ. د عکس اندازه باید 5MB څخه کم وي.',
        fa: 'به صفحه پروفایل بروید (آیکون آخر از ناوبری پایین)، سپس روی عکس پروفایل کلیک کنید. می‌توانید یک عکس جدید از دستگاه خود انتخاب کنید. اندازه عکس باید کمتر از 5MB باشد.',
        en: 'Go to the Profile page (last icon from Bottom Navigation), then click on the profile picture. You can select a new image from your device. Image size should be less than 5MB.'
      }
    },
    {
      id: 'faq6',
      question: {
        ps: 'زه څنګه د ژبې تغیر کړم؟',
        fa: 'چگونه زبان را تغییر دهم؟',
        en: 'How do I change language?'
      },
      answer: {
        ps: 'د Settings صفحې ته لاړشئ (د gear icon) او د Language برخه کې خپله غوښتنې ژبه غوره کړئ: پښتو، دری، یا English. ټول اپلیکیشن به سمدستي په هغې ژبې بدل شي.',
        fa: 'به صفحه تنظیمات بروید (آیکون چرخ دنده) و در بخش زبان، زبان مورد نظر خود را انتخاب کنید: پشتو، دری یا انگلیسی. کل برنامه فوراً به آن زبان تغییر می‌کند.',
        en: 'Go to the Settings page (gear icon) and in the Language section select your preferred language: Pashto, Dari, or English. The entire app will immediately switch to that language.'
      }
    },
    {
      id: 'faq7',
      question: {
        ps: 'ایا زه کولی شم د ډاکټرانو سره مستقیماً اړیکه ونیسم؟',
        fa: 'آیا می‌توانم مستقیماً با داکتران تماس بگیرم؟',
        en: 'Can I contact doctors directly?'
      },
      answer: {
        ps: 'هو! د Doctors Directory کې، هر ډاکټر د تلیفون شمیره او موقعیت لري. تاسو کولی شئ د ټیلیفون شمیرې په سر کلیک وکړئ ترڅو مستقیماً زنګ ووهئ یا د appointment لپاره اړیکه ونیسئ. موږ د ډاکټرانو معلومات منظم تازه کوو.',
        fa: 'بله! در فهرست داکتران، هر داکتر شماره تلفن و موقعیت دارد. می‌توانید روی شماره تلفن کلیک کنید تا مستقیماً تماس بگیرید یا برای قرار ملاقات تماس بگیرید. ما اطلاعات داکتران را به طور منظم به‌روزرسانی می‌کنیم.',
        en: 'Yes! In the Doctors Directory, each doctor has a phone number and location. You can click on the phone number to call directly or contact for an appointment. We regularly update doctor information.'
      }
    },
    {
      id: 'faq8',
      question: {
        ps: 'د Community Feed څه دی؟',
        fa: 'Community Feed چیست؟',
        en: 'What is Community Feed?'
      },
      answer: {
        ps: 'Community Feed یوه ټولنیزه برخه ده چیرې چې کاروونکي کولی شي د روغتیا پوښتنې وکړي، تجربې شریکې کړي، او د نورو سره د روغتیا موضوعاتو په اړه خبرې وکړي. تاسو کولی شئ posts ولیکئ، نظرونه وکړئ، او د نورو posts like کړئ.',
        fa: 'Community Feed یک بخش اجتماعی است که کاربران می‌توانند سوالات سلامتی بپرسند، تجربیات را به اشتراک بگذارند و در مورد موضوعات سلامتی با دیگران صحبت کنند. می‌توانید پست بنویسید، نظر دهید و پست‌های دیگران را لایک کنید.',
        en: 'Community Feed is a social section where users can ask health questions, share experiences, and talk about health topics with others. You can write posts, comment, and like other posts.'
      }
    }
  ];

  const helpTopics = [
    {
      icon: Book,
      title: {
        ps: 'د کارونې لارښود',
        fa: 'راهنمای استفاده',
        en: 'User Guide'
      },
      description: {
        ps: 'د اپلیکیشن ټولو فیچرونو په اړه بشپړ معلومات',
        fa: 'اطلاعات کامل در مورد تمام ویژگی‌های برنامه',
        en: 'Complete information about all app features'
      },
      color: 'from-blue-500 to-cyan-600'
    },
    {
      icon: Video,
      title: {
        ps: 'ویډیو ټیوټوریلونه',
        fa: 'آموزش‌های ویدیویی',
        en: 'Video Tutorials'
      },
      description: {
        ps: 'د بصري زده کړې لپاره ګام په ګام ویډیوګانې',
        fa: 'ویدیوهای گام به گام برای یادگیری بصری',
        en: 'Step-by-step videos for visual learning'
      },
      color: 'from-purple-500 to-pink-600'
    },
    {
      icon: MessageCircle,
      title: {
        ps: 'مستقیم ملاتړ',
        fa: 'پشتیبانی مستقیم',
        en: 'Direct Support'
      },
      description: {
        ps: 'زموږ د ملاتړ ټیم سره په ژیو کې خبرې وکړئ',
        fa: 'با تیم پشتیبانی ما به صورت زنده صحبت کنید',
        en: 'Chat live with our support team'
      },
      color: 'from-green-500 to-emerald-600'
    }
  ];

  const contactMethods = [
    {
      icon: Mail,
      title: {
        ps: 'بریښنالیک',
        fa: 'ایمیل',
        en: 'Email'
      },
      value: 'ibrahimkhaksar.it@gmail.com',
      action: 'mailto:ibrahimkhaksar.it@gmail.com',
      color: 'from-orange-500 to-red-600'
    },
    {
      icon: Phone,
      title: {
        ps: 'تلیفون',
        fa: 'تلفن',
        en: 'Phone'
      },
      value: '+93 783 040 441',
      action: 'tel:+93783040441',
      color: 'from-teal-500 to-cyan-600'
    },
    {
      icon: Phone,
      title: {
        ps: 'بل شمیره',
        fa: 'شماره دیگر',
        en: 'Alternate'
      },
      value: '+93 779 494 512',
      action: 'tel:+93779494512',
      color: 'from-indigo-500 to-purple-600'
    },
    {
      icon: MessageCircle,
      title: {
        ps: 'واتساپ مرسته',
        fa: 'پشتیبانی واتساپ',
        en: 'WhatsApp Support'
      },
      value: '+93 779 494 512',
      action: 'https://wa.me/93779494512',
      color: 'from-green-500 to-emerald-600',
      isWhatsApp: true,
      external: true
    }
  ];

  const filteredFaqs = faqs.filter(faq =>
    faq.question[language].toLowerCase().includes(searchQuery.toLowerCase()) ||
    faq.answer[language].toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-50 via-blue-50 to-cyan-50 pb-28 md:pb-8">
      {/* Header */}
      <div className="sticky top-0 z-40 backdrop-blur-xl bg-white/80 border-b border-white/20 shadow-lg">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center gap-4">
            <Button variant="ghost" size="icon" onClick={onBack}>
              <ArrowLeft className="w-5 h-5" />
            </Button>
            <div className="flex-1">
              <h1 className="text-2xl bg-gradient-to-r from-indigo-600 to-cyan-600 bg-clip-text text-transparent">
                {language === 'ps' && 'مرسته او ملاتړ'}
                {language === 'fa' && 'کمک و پشتیبانی'}
                {language === 'en' && 'Help & Support'}
              </h1>
              <p className="text-sm text-gray-600">
                {language === 'ps' && 'موږ ستاسو د مرستې لپاره دلته یو'}
                {language === 'fa' && 'ما اینجا هستیم تا کمک کنیم'}
                {language === 'en' && 'We are here to help you'}
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="container mx-auto px-4 py-8 max-w-4xl">
        
        {/* Help Topics */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
          {helpTopics.map((topic, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
            >
              <Card className="border-0 shadow-lg hover-lift cursor-pointer group">
                <CardContent className="p-6">
                  <div className={`w-14 h-14 bg-gradient-to-br ${topic.color} rounded-2xl flex items-center justify-center mb-4 shadow-lg group-hover:scale-110 transition-transform`}>
                    <topic.icon className="w-7 h-7 text-white" />
                  </div>
                  <h3 className="font-semibold mb-2">{topic.title[language]}</h3>
                  <p className="text-sm text-gray-600" dir={language === 'en' ? 'ltr' : 'rtl'}>
                    {topic.description[language]}
                  </p>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>

        {/* FAQ Section */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
        >
          <Card className="mb-6 border-0 shadow-xl">
            <CardContent className="p-8">
              <div className="flex items-center gap-4 mb-6">
                <div className="w-14 h-14 bg-gradient-to-br from-violet-500 to-purple-600 rounded-2xl flex items-center justify-center shadow-lg">
                  <HelpCircle className="w-7 h-7 text-white" />
                </div>
                <div>
                  <h2 className="text-2xl">
                    {language === 'ps' && 'ډیری پوښتل شوي پوښتنې'}
                    {language === 'fa' && 'سوالات متداول'}
                    {language === 'en' && 'Frequently Asked Questions'}
                  </h2>
                  <p className="text-sm text-gray-600">
                    {language === 'ps' && 'د عامو پوښتنو ځوابونه'}
                    {language === 'fa' && 'پاسخ به سوالات رایج'}
                    {language === 'en' && 'Answers to common questions'}
                  </p>
                </div>
              </div>

              {/* Search FAQs */}
              <div className="relative mb-6">
                <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
                <Input
                  type="text"
                  placeholder={
                    language === 'ps' ? 'پوښتنې ولټوئ...' :
                    language === 'fa' ? 'جستجوی سوالات...' :
                    'Search questions...'
                  }
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-12 pr-4 py-3 rounded-xl border-2 border-gray-200 focus:border-violet-500"
                  dir={language === 'en' ? 'ltr' : 'rtl'}
                />
              </div>

              {/* FAQ Accordion */}
              <Accordion type="single" collapsible className="space-y-2">
                {filteredFaqs.map((faq) => (
                  <AccordionItem key={faq.id} value={faq.id} className="border rounded-xl px-4 bg-gray-50">
                    <AccordionTrigger className="hover:no-underline" dir={language === 'en' ? 'ltr' : 'rtl'}>
                      <span className="text-left">{faq.question[language]}</span>
                    </AccordionTrigger>
                    <AccordionContent className="text-gray-700" dir={language === 'en' ? 'ltr' : 'rtl'}>
                      {faq.answer[language]}
                    </AccordionContent>
                  </AccordionItem>
                ))}
              </Accordion>

              {filteredFaqs.length === 0 && (
                <div className="text-center py-8 text-gray-500">
                  {language === 'ps' && 'هیڅ پوښتنه و نه موندل شوه'}
                  {language === 'fa' && 'هیچ سوالی یافت نشد'}
                  {language === 'en' && 'No questions found'}
                </div>
              )}
            </CardContent>
          </Card>
        </motion.div>

        {/* Contact Methods */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
        >
          <Card className="mb-6 border-0 shadow-xl">
            <CardContent className="p-8">
              <h3 className="text-xl mb-6 text-center">
                {language === 'ps' && 'مونږ سره اړیکه ونیسئ'}
                {language === 'fa' && 'با ما تماس بگیرید'}
                {language === 'en' && 'Contact Us'}
              </h3>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {contactMethods.map((method, index) => {
                  const isExternal = 'external' in method && method.external;
                  const isWhatsApp = 'isWhatsApp' in method && method.isWhatsApp;
                  
                  return (
                    <a
                      key={index}
                      href={method.action}
                      target={isExternal ? '_blank' : undefined}
                      rel={isExternal ? 'noopener noreferrer' : undefined}
                      className="block"
                    >
                      <div className={`bg-gradient-to-br from-gray-50 to-white p-6 rounded-2xl border-2 border-gray-100 hover:border-violet-300 hover:shadow-lg transition-all cursor-pointer group ${isWhatsApp ? 'animate-pulse hover:animate-none' : ''}`}>
                        <div className={`w-12 h-12 bg-gradient-to-br ${method.color} rounded-xl flex items-center justify-center mb-3 group-hover:scale-110 transition-transform relative`}>
                          <method.icon className="w-6 h-6 text-white" />
                          {isWhatsApp && (
                            <div className="absolute -top-1 -right-1 w-4 h-4 bg-green-400 rounded-full border-2 border-white animate-ping"></div>
                          )}
                        </div>
                        <p className="text-sm text-gray-600 mb-1 flex items-center gap-2">
                          {method.title[language]}
                          {isExternal && <ExternalLink className="w-3 h-3" />}
                        </p>
                        <p className={`font-medium ${isWhatsApp ? 'text-green-600' : 'text-gray-800'}`}>
                          {method.value}
                        </p>
                        {isWhatsApp && (
                          <p className="text-xs text-green-600 mt-2">
                            {language === 'ps' ? '💬 فوری ځواب ترلاسه کړئ' : language === 'fa' ? '💬 پاسخ سریع دریافت کنید' : '💬 Get instant reply'}
                          </p>
                        )}
                      </div>
                    </a>
                  );
                })}
              </div>
            </CardContent>
          </Card>
        </motion.div>

        {/* Need More Help */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5 }}
        >
          <Card className="border-0 shadow-xl bg-gradient-to-br from-violet-50 to-purple-50">
            <CardContent className="p-8 text-center">
              <div className="w-16 h-16 bg-gradient-to-br from-violet-500 to-purple-600 rounded-2xl flex items-center justify-center mx-auto mb-4 shadow-lg">
                <MessageCircle className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-xl mb-2">
                {language === 'ps' && 'نورې مرستې ته اړتیا لرئ؟'}
                {language === 'fa' && 'به کمک بیشتری نیاز دارید؟'}
                {language === 'en' && 'Need More Help?'}
              </h3>
              <p className="text-gray-700 mb-4" dir={language === 'en' ? 'ltr' : 'rtl'}>
                {language === 'ps' && 'زموږ ملاتړ ټیم 24/7 ستاسو د خدمت لپاره تیار دی'}
                {language === 'fa' && 'تیم پشتیبانی ما 24/7 آماده خدمت به شماست'}
                {language === 'en' && 'Our support team is ready to serve you 24/7'}
              </p>
              <Button className="bg-gradient-to-r from-violet-600 to-purple-600 hover:from-violet-700 hover:to-purple-700">
                <Mail className="w-4 h-4 mr-2" />
                {language === 'ps' && 'پیغام واستوئ'}
                {language === 'fa' && 'ارسال پیام'}
                {language === 'en' && 'Send Message'}
              </Button>
            </CardContent>
          </Card>
        </motion.div>

        {/* Bottom Spacing */}
        <div className="h-20" />
      </div>
    </div>
  );
}
