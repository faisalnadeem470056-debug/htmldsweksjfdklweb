import { Card, CardContent } from "./ui/card";
import { ImageWithFallback } from "./figma/ImageWithFallback";
import { Badge } from "./ui/badge";
import { Clock, TrendingUp, ArrowRight, Bookmark, Share2, Eye, Sparkles } from "lucide-react";

const blogPosts = [
  {
    id: 1,
    title: "10 Ways to Keep Your Heart Healthy",
    titleDari: "د زړه د روغتيا لپاره ۱۰ لارې",
    excerpt: "Learn essential tips for maintaining cardiovascular health and preventing heart disease.",
    image: "https://images.unsplash.com/photo-1762939079730-23708c0dd337?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxoZWFydCUyMGhlYWx0aCUyMGNhcmRpb2xvZ3l8ZW58MXx8fHwxNzYzMTE1Mjg0fDA&ixlib=rb-4.1.0&q=80&w=1080",
    category: "Cardiology",
    gradient: "from-red-500 via-rose-500 to-pink-500",
    readTime: "5 min",
    views: "2.3k",
    featured: true,
    trending: true,
  },
  {
    id: 2,
    title: "Mental Health & Wellness",
    titleDari: "په افغانستان کې رواني روغتيا",
    excerpt: "Understanding mental health challenges and available resources in Afghan communities.",
    image: "https://images.unsplash.com/photo-1620389701363-b1d7a601e0c9?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtZW50YWwlMjBoZWFsdGglMjB3ZWxsbmVzc3xlbnwxfHx8fDE3NjMwNjUzOTB8MA&ixlib=rb-4.1.0&q=80&w=1080",
    category: "Mental Health",
    gradient: "from-purple-500 via-violet-500 to-indigo-500",
    readTime: "7 min",
    views: "1.8k",
    featured: false,
    trending: true,
  },
  {
    id: 3,
    title: "Nutrition Guide for Afghan Families",
    titleDari: "د افغان کورنيو لپاره د تغذيې لارښود",
    excerpt: "Practical nutrition advice using locally available foods for better health.",
    image: "https://images.unsplash.com/photo-1670164747721-d3500ef757a6?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxoZWFsdGh5JTIwZm9vZCUyMG51dHJpdGlvbnxlbnwxfHx8fDE3NjMwODExODN8MA&ixlib=rb-4.1.0&q=80&w=1080",
    category: "Nutrition",
    gradient: "from-green-500 via-emerald-500 to-teal-500",
    readTime: "6 min",
    views: "3.1k",
    featured: false,
    trending: false,
  },
  {
    id: 4,
    title: "Maternal Health: Pregnancy Care",
    titleDari: "د مور روغتيا: د امیندوارۍ پاملرنه",
    excerpt: "Essential prenatal care and health tips for expecting mothers.",
    image: "https://images.unsplash.com/photo-1621726988105-f03ae8772ca4?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwcmVnbmFudCUyMHdvbWFuJTIwbWF0ZXJuYWx8ZW58MXx8fHwxNjMxNjQ3NDd8MA&ixlib=rb-4.1.0&q=80&w=1080",
    category: "Maternal Care",
    gradient: "from-pink-500 via-rose-500 to-fuchsia-500",
    readTime: "8 min",
    views: "2.7k",
    featured: false,
    trending: false,
  },
  {
    id: 5,
    title: "Dental Health: Complete Guide",
    titleDari: "د غاښونو روغتيا: بشپړ لارښود",
    excerpt: "Everything you need to know about maintaining healthy teeth and gums.",
    image: "https://images.unsplash.com/photo-1684607632845-723f8f427110?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxkZW50YWwlMjBjYXJlJTIwc21pbGV8ZW58MXx8fHwxNzYzMTY0NzQ3fDA&ixlib=rb-4.1.0&q=80&w=1080",
    category: "Dental Care",
    gradient: "from-blue-500 via-cyan-500 to-teal-500",
    readTime: "5 min",
    views: "1.9k",
    featured: false,
    trending: true,
  },
  {
    id: 6,
    title: "Pediatric Care Essentials",
    titleDari: "د ماشومانو پاملرنه",
    excerpt: "Essential healthcare tips for children and growing families.",
    image: "https://images.unsplash.com/photo-1758691463080-30a990ef61bb?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwZWRpYXRyaWMlMjBjaGlsZCUyMGhlYWx0aHxlbnwxfHx8fDE3NjMxNjQ3NTN8MA&ixlib=rb-4.1.0&q=80&w=1080",
    category: "Pediatrics",
    gradient: "from-amber-500 via-orange-500 to-red-500",
    readTime: "6 min",
    views: "2.1k",
    featured: false,
    trending: false,
  },
];

export function BlogSection() {
  return (
    <section id="blog" className="py-16 md:py-24 bg-gradient-to-b from-white via-slate-50 to-white relative overflow-hidden">
      {/* Background Decoration */}
      <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-gradient-to-bl from-violet-100/50 to-purple-100/50 rounded-full blur-3xl animate-blob"></div>
      <div className="absolute bottom-0 left-0 w-[400px] h-[400px] bg-gradient-to-tr from-emerald-100/50 to-teal-100/50 rounded-full blur-3xl animate-float-slow"></div>
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        {/* Header */}
        <div className="flex items-center justify-between mb-12 md:mb-16">
          <div className="space-y-3">
            <div className="inline-flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-emerald-100 to-teal-100 rounded-full">
              <Sparkles className="w-4 h-4 text-emerald-600 animate-pulse-glow" />
              <span className="text-emerald-700 text-sm uppercase tracking-wider">Health Insights</span>
            </div>
            <h2 className="text-4xl md:text-6xl">
              <span className="gradient-text">Latest Articles</span>
            </h2>
            <p className="text-gray-600 text-lg">د روغتيا مقالې - Expert health advice & wellness tips</p>
          </div>
          <button className="hidden lg:flex items-center gap-2 px-6 py-3 bg-white hover:bg-gray-50 rounded-xl shadow-md hover-lift transition-all group border border-gray-200">
            <span className="text-gray-700">View All</span>
            <ArrowRight className="w-4 h-4 text-emerald-600 group-hover:translate-x-1 transition-transform" />
          </button>
        </div>

        {/* Bento Grid */}
        <div className="bento-grid">
          {blogPosts.map((post, index) => (
            <Card 
              key={post.id} 
              className={`bento-item group cursor-pointer border-0 bg-white shadow-lg overflow-hidden relative ${
                index === 0 ? 'lg:col-span-2 lg:row-span-2' : ''
              }`}
              style={{ animationDelay: `${index * 100}ms` }}
            >
              {/* Image Container */}
              <div className={`relative overflow-hidden ${
                index === 0 ? 'h-64 md:h-80 lg:h-full' : 'h-56 md:h-64'
              }`}>
                <ImageWithFallback
                  src={post.image}
                  alt={post.title}
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
                />
                <div className={`absolute inset-0 bg-gradient-to-t ${post.gradient} opacity-40 group-hover:opacity-50 transition-opacity`}></div>
                
                {/* Floating Badges */}
                <div className="absolute top-4 left-4 flex flex-col gap-2">
                  <Badge className="glass-effect text-gray-900 shadow-lg border border-white/30">
                    {post.category}
                  </Badge>
                  {post.featured && (
                    <Badge className="bg-gradient-to-r from-amber-500 to-orange-500 text-white shadow-lg neon-glow">
                      <Sparkles className="w-3 h-3 mr-1" />
                      Featured
                    </Badge>
                  )}
                  {post.trending && (
                    <Badge className="glass-dark text-white shadow-lg">
                      <TrendingUp className="w-3 h-3 mr-1" />
                      Trending
                    </Badge>
                  )}
                </div>

                {/* Action Buttons */}
                <div className="absolute top-4 right-4 flex gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                  <button className="p-2 glass-effect rounded-full hover:bg-white/90 transition-colors">
                    <Bookmark className="w-4 h-4 text-gray-700" />
                  </button>
                  <button className="p-2 glass-effect rounded-full hover:bg-white/90 transition-colors">
                    <Share2 className="w-4 h-4 text-gray-700" />
                  </button>
                </div>

                {/* Gradient Overlay */}
                <div className="absolute bottom-0 left-0 right-0 h-32 bg-gradient-to-t from-black/60 to-transparent"></div>
              </div>
              
              {/* Content */}
              <div className={`absolute bottom-0 left-0 right-0 p-6 ${
                index === 0 ? 'lg:p-8' : 'p-5'
              }`}>
                <h3 className={`text-white mb-2 line-clamp-2 group-hover:text-emerald-300 transition-colors ${
                  index === 0 ? 'text-2xl md:text-3xl' : 'text-lg md:text-xl'
                }`}>
                  {post.title}
                </h3>
                <p className="text-emerald-200 text-sm mb-3">
                  {post.titleDari}
                </p>
                
                {index === 0 && (
                  <p className="text-white/90 mb-4 line-clamp-2 hidden lg:block">
                    {post.excerpt}
                  </p>
                )}
                
                {/* Meta Info */}
                <div className="flex items-center justify-between pt-4 border-t border-white/20">
                  <div className="flex items-center gap-4 text-xs text-white/80">
                    <div className="flex items-center gap-1.5">
                      <Clock className="w-4 h-4" />
                      <span>{post.readTime}</span>
                    </div>
                    <div className="flex items-center gap-1.5">
                      <Eye className="w-4 h-4" />
                      <span>{post.views}</span>
                    </div>
                  </div>
                  <ArrowRight className="w-5 h-5 text-white group-hover:translate-x-1 transition-transform" />
                </div>
              </div>
            </Card>
          ))}
        </div>

        {/* View All Button for Mobile */}
        <div className="flex justify-center mt-10 lg:hidden">
          <button className="flex items-center gap-2 px-8 py-4 bg-gradient-to-r from-emerald-600 to-teal-600 text-white rounded-xl shadow-lg hover-lift neon-glow">
            <span>View All Articles</span>
            <ArrowRight className="w-5 h-5" />
          </button>
        </div>
      </div>
    </section>
  );
}
