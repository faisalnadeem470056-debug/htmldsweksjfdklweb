import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";
import { Input } from "./ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "./ui/dialog";
import { 
  Users, 
  UserPlus, 
  Calendar,
  FileText,
  Syringe,
  Heart,
  Baby,
  User,
  Edit,
  Trash2,
  Eye,
  Activity,
  Sparkles
} from "lucide-react";
import { Separator } from "./ui/separator";
import { Avatar, AvatarFallback, AvatarImage } from "./ui/avatar";

interface FamilyMember {
  id: number;
  name: string;
  nameDari: string;
  relationship: string;
  relationshipDari: string;
  age: number;
  gender: string;
  bloodType: string;
  avatar: string;
  appointments: number;
  prescriptions: number;
  vaccinations: number;
}

const initialMembers: FamilyMember[] = [
  {
    id: 1,
    name: "User Profile",
    nameDari: "کاروونکی پروفایل",
    relationship: "Self",
    relationshipDari: "خود",
    age: 35,
    gender: "Male",
    bloodType: "O+",
    avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=200",
    appointments: 5,
    prescriptions: 8,
    vaccinations: 12
  },
  {
    id: 2,
    name: "Fatima Khan",
    nameDari: "فاطمه خان",
    relationship: "Wife",
    relationshipDari: "میرمن",
    age: 32,
    gender: "Female",
    bloodType: "A+",
    avatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=200",
    appointments: 3,
    prescriptions: 6,
    vaccinations: 10
  },
  {
    id: 3,
    name: "Hamid Khan",
    nameDari: "حامد خان",
    relationship: "Son",
    relationshipDari: "زوی",
    age: 8,
    gender: "Male",
    bloodType: "O+",
    avatar: "https://images.unsplash.com/photo-1522771739844-6a9f6d5f14af?w=200",
    appointments: 4,
    prescriptions: 5,
    vaccinations: 15
  },
  {
    id: 4,
    name: "Zainab Khan",
    nameDari: "زینب خان",
    relationship: "Daughter",
    relationshipDari: "لور",
    age: 5,
    gender: "Female",
    bloodType: "A+",
    avatar: "https://images.unsplash.com/photo-1581985673473-0784a7a44e39?w=200",
    appointments: 6,
    prescriptions: 4,
    vaccinations: 14
  }
];

const appointmentsHistory = {
  1: [
    { date: "2025-11-10", doctor: "Dr. Sarah Johnson", type: "Cardiology Checkup", status: "Completed" },
    { date: "2025-10-15", doctor: "Dr. Hassan Karimi", type: "Mental Health", status: "Completed" },
    { date: "2025-09-20", doctor: "Dr. Sarah Johnson", type: "Follow-up", status: "Completed" },
  ]
};

const prescriptionsHistory = {
  1: [
    { date: "2025-11-10", medicine: "Atorvastatin 20mg", dosage: "1 tablet daily", duration: "30 days" },
    { date: "2025-10-15", medicine: "Vitamin D3 1000IU", dosage: "1 capsule daily", duration: "90 days" },
    { date: "2025-09-20", medicine: "Aspirin 100mg", dosage: "1 tablet daily", duration: "Ongoing" },
  ]
};

const vaccinationsHistory = {
  1: [
    { name: "COVID-19 Booster", date: "2025-10-01", nextDue: "2026-10-01" },
    { name: "Influenza Vaccine", date: "2024-11-15", nextDue: "2025-11-15" },
    { name: "Hepatitis B", date: "2020-05-10", nextDue: "Complete" },
  ]
};

export function FamilyProfiles() {
  const [members, setMembers] = useState<FamilyMember[]>(initialMembers);
  const [selectedMember, setSelectedMember] = useState<FamilyMember | null>(null);
  const [modalOpen, setModalOpen] = useState(false);
  const [viewType, setViewType] = useState<"appointments" | "prescriptions" | "vaccinations">("appointments");

  const handleViewDetails = (member: FamilyMember, type: "appointments" | "prescriptions" | "vaccinations") => {
    setSelectedMember(member);
    setViewType(type);
    setModalOpen(true);
  };

  return (
    <>
      <section className="py-16 md:py-24 bg-gradient-to-b from-white via-purple-50/30 to-white relative overflow-hidden min-h-screen">
        {/* Background decoration */}
        <div className="absolute top-0 left-0 w-[500px] h-[500px] bg-gradient-to-br from-purple-100/50 to-pink-100/50 rounded-full blur-3xl animate-float"></div>
        
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          {/* Header */}
          <div className="text-center mb-12 md:mb-16 space-y-4">
            <div className="inline-flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-purple-100 to-pink-100 rounded-full">
              <Sparkles className="w-4 h-4 text-purple-600 animate-pulse-glow" />
              <span className="text-purple-700 text-sm uppercase tracking-wider">Family Care</span>
            </div>
            <h2 className="text-4xl md:text-6xl">
              <span className="bg-gradient-to-r from-purple-600 via-pink-600 to-rose-600 bg-clip-text text-transparent">
                Family Health Profiles
              </span>
            </h2>
            <p className="text-gray-600 max-w-2xl mx-auto text-lg">
              د کورنۍ روغتیا پروفایلونه - Manage health records for your entire family
            </p>
          </div>

          {/* Add Member Button */}
          <div className="mb-8 flex justify-end">
            <Button className="bg-gradient-to-r from-purple-500 to-pink-600 hover:from-purple-600 hover:to-pink-700 shadow-lg">
              <UserPlus className="w-5 h-5 mr-2" />
              Add Family Member
            </Button>
          </div>

          {/* Family Members Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {members.map((member, index) => (
              <Card
                key={member.id}
                className="hover-lift border-0 shadow-lg overflow-hidden"
                style={{ animationDelay: `${index * 100}ms` }}
              >
                <div className="h-2 bg-gradient-to-r from-purple-500 via-pink-500 to-rose-500"></div>
                <CardHeader className="text-center pb-4">
                  <div className="relative inline-block mb-4">
                    <Avatar className="w-24 h-24 border-4 border-purple-200 shadow-lg">
                      <AvatarImage src={member.avatar} />
                      <AvatarFallback className="bg-gradient-to-br from-purple-400 to-pink-400 text-white text-2xl">
                        {member.name[0]}
                      </AvatarFallback>
                    </Avatar>
                    {member.relationship === "Self" && (
                      <div className="absolute -bottom-2 -right-2 bg-gradient-to-r from-emerald-500 to-teal-600 rounded-full p-2 shadow-lg">
                        <Heart className="w-4 h-4 text-white" />
                      </div>
                    )}
                  </div>
                  <CardTitle className="text-lg mb-1">{member.name}</CardTitle>
                  <p className="text-sm text-purple-600">{member.nameDari}</p>
                  <Badge className="mt-2 bg-purple-100 text-purple-700">
                    {member.relationship} - {member.relationshipDari}
                  </Badge>
                </CardHeader>

                <CardContent className="space-y-4">
                  {/* Basic Info */}
                  <div className="grid grid-cols-2 gap-2 text-sm">
                    <div className="p-2 bg-blue-50 rounded-lg text-center">
                      <p className="text-xs text-gray-600">Age</p>
                      <p className="text-blue-600">{member.age} years</p>
                    </div>
                    <div className="p-2 bg-pink-50 rounded-lg text-center">
                      <p className="text-xs text-gray-600">Blood</p>
                      <p className="text-pink-600">{member.bloodType}</p>
                    </div>
                  </div>

                  <Separator />

                  {/* Health Stats */}
                  <div className="space-y-2">
                    <button 
                      className="w-full flex items-center justify-between p-3 bg-emerald-50 rounded-lg hover:bg-emerald-100 transition-colors"
                      onClick={() => handleViewDetails(member, "appointments")}
                    >
                      <div className="flex items-center gap-2">
                        <Calendar className="w-4 h-4 text-emerald-600" />
                        <span className="text-sm text-gray-700">Appointments</span>
                      </div>
                      <Badge className="bg-emerald-600 text-white">{member.appointments}</Badge>
                    </button>

                    <button 
                      className="w-full flex items-center justify-between p-3 bg-blue-50 rounded-lg hover:bg-blue-100 transition-colors"
                      onClick={() => handleViewDetails(member, "prescriptions")}
                    >
                      <div className="flex items-center gap-2">
                        <FileText className="w-4 h-4 text-blue-600" />
                        <span className="text-sm text-gray-700">Prescriptions</span>
                      </div>
                      <Badge className="bg-blue-600 text-white">{member.prescriptions}</Badge>
                    </button>

                    <button 
                      className="w-full flex items-center justify-between p-3 bg-purple-50 rounded-lg hover:bg-purple-100 transition-colors"
                      onClick={() => handleViewDetails(member, "vaccinations")}
                    >
                      <div className="flex items-center gap-2">
                        <Syringe className="w-4 h-4 text-purple-600" />
                        <span className="text-sm text-gray-700">Vaccinations</span>
                      </div>
                      <Badge className="bg-purple-600 text-white">{member.vaccinations}</Badge>
                    </button>
                  </div>

                  <Separator />

                  {/* Actions */}
                  <div className="flex gap-2">
                    <Button variant="outline" className="flex-1" size="sm">
                      <Edit className="w-3 h-3 mr-1" />
                      Edit
                    </Button>
                    {member.relationship !== "Self" && (
                      <Button variant="outline" className="border-red-300 text-red-600 hover:bg-red-50" size="sm">
                        <Trash2 className="w-3 h-3" />
                      </Button>
                    )}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Details Modal */}
      <Dialog open={modalOpen} onOpenChange={setModalOpen}>
        <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <div className="flex items-center gap-4 mb-4">
              <Avatar className="w-16 h-16 border-4 border-purple-200">
                <AvatarImage src={selectedMember?.avatar} />
                <AvatarFallback>{selectedMember?.name[0]}</AvatarFallback>
              </Avatar>
              <div>
                <DialogTitle className="text-2xl">{selectedMember?.name}</DialogTitle>
                <DialogDescription className="text-lg text-purple-600">
                  {selectedMember?.nameDari} - {selectedMember?.relationship}
                </DialogDescription>
                <p className="text-lg text-purple-600">{selectedMember?.nameDari}</p>
              </div>
            </div>
          </DialogHeader>

          <div className="space-y-6">
            {viewType === "appointments" && (
              <div>
                <h3 className="text-lg mb-4 flex items-center gap-2">
                  <Calendar className="w-5 h-5 text-emerald-600" />
                  Appointment History - د ملاقاتونو تاریخچه
                </h3>
                <div className="space-y-3">
                  {(appointmentsHistory[selectedMember?.id as keyof typeof appointmentsHistory] || []).map((apt, idx) => (
                    <div key={idx} className="p-4 bg-emerald-50 rounded-lg border border-emerald-200">
                      <div className="flex items-start justify-between mb-2">
                        <div>
                          <p className="text-sm text-gray-900">{apt.type}</p>
                          <p className="text-sm text-emerald-600">{apt.doctor}</p>
                        </div>
                        <Badge className="bg-green-100 text-green-700">{apt.status}</Badge>
                      </div>
                      <p className="text-xs text-gray-600">Date: {apt.date}</p>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {viewType === "prescriptions" && (
              <div>
                <h3 className="text-lg mb-4 flex items-center gap-2">
                  <FileText className="w-5 h-5 text-blue-600" />
                  Prescriptions - نسخې
                </h3>
                <div className="space-y-3">
                  {(prescriptionsHistory[selectedMember?.id as keyof typeof prescriptionsHistory] || []).map((presc, idx) => (
                    <div key={idx} className="p-4 bg-blue-50 rounded-lg border border-blue-200">
                      <div className="flex items-start justify-between mb-2">
                        <div>
                          <p className="text-sm text-gray-900">{presc.medicine}</p>
                          <p className="text-sm text-blue-600">{presc.dosage}</p>
                        </div>
                        <Badge className="bg-blue-600 text-white">{presc.duration}</Badge>
                      </div>
                      <p className="text-xs text-gray-600">Prescribed: {presc.date}</p>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {viewType === "vaccinations" && (
              <div>
                <h3 className="text-lg mb-4 flex items-center gap-2">
                  <Syringe className="w-5 h-5 text-purple-600" />
                  Vaccination Records - د واکسین ریکارډونه
                </h3>
                <div className="space-y-3">
                  {(vaccinationsHistory[selectedMember?.id as keyof typeof vaccinationsHistory] || []).map((vac, idx) => (
                    <div key={idx} className="p-4 bg-purple-50 rounded-lg border border-purple-200">
                      <div className="flex items-start justify-between mb-2">
                        <div>
                          <p className="text-sm text-gray-900">{vac.name}</p>
                          <p className="text-sm text-purple-600">Given: {vac.date}</p>
                        </div>
                        <Badge className={vac.nextDue === "Complete" ? "bg-green-100 text-green-700" : "bg-amber-100 text-amber-700"}>
                          {vac.nextDue === "Complete" ? "Complete" : `Due: ${vac.nextDue}`}
                        </Badge>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}

export default FamilyProfiles;
