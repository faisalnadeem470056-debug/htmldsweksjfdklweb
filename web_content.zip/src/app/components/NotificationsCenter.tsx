import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "./ui/avatar";
import { Switch } from "./ui/switch";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs";
import { Separator } from "./ui/separator";
import { ScrollArea } from "./ui/scroll-area";
import { 
  Bell,
  BellRing,
  BellOff,
  Calendar,
  Clock,
  MessageSquare,
  FileText,
  Heart,
  Pill,
  Activity,
  AlertCircle,
  CheckCircle2,
  Info,
  TrendingUp,
  Trash2,
  Settings,
  Filter,
  Volume2,
  VolumeX,
  Smartphone,
  Mail,
  User,
  Sparkles,
  X,
  Check,
  ChevronRight,
  Eye,
  EyeOff
} from "lucide-react";
import { useLanguage } from "../contexts/LanguageContext";
import { toast } from "sonner@2.0.3";

interface Notification {
  id: number;
  type: "appointment" | "lab" | "medicine" | "message" | "health" | "general";
  title: string;
  message: string;
  time: string;
  read: boolean;
  priority: "high" | "medium" | "low";
  actionUrl?: string;
  icon?: string;
  image?: string;
}

const mockNotifications: Notification[] = [
  {
    id: 1,
    type: "appointment",
    title: "Appointment Reminder",
    message: "Your appointment with Dr. Ahmad Naseri is tomorrow at 10:00 AM",
    time: "2 hours ago",
    read: false,
    priority: "high"
  },
  {
    id: 2,
    type: "lab",
    title: "Lab Results Ready",
    message: "Your blood test results are now available. Click to view.",
    time: "5 hours ago",
    read: false,
    priority: "high"
  },
  {
    id: 3,
    type: "medicine",
    title: "Medicine Reminder",
    message: "Time to take your medication: Aspirin 100mg",
    time: "6 hours ago",
    read: false,
    priority: "medium"
  },
  {
    id: 4,
    type: "message",
    title: "New Message from Dr. Fatima",
    message: "Dr. Fatima Ahmadi sent you a message regarding your treatment plan",
    time: "1 day ago",
    read: true,
    priority: "medium"
  },
  {
    id: 5,
    type: "health",
    title: "Weekly Health Summary",
    message: "Your health score improved by 8% this week. Great job!",
    time: "2 days ago",
    read: true,
    priority: "low"
  },
  {
    id: 6,
    type: "appointment",
    title: "Appointment Confirmed",
    message: "Your appointment with Dr. Hassan Karimi has been confirmed for Nov 25",
    time: "3 days ago",
    read: true,
    priority: "medium"
  },
  {
    id: 7,
    type: "medicine",
    title: "Prescription Refill Due",
    message: "Your prescription for Blood Pressure medication is due for refill",
    time: "4 days ago",
    read: true,
    priority: "high"
  },
  {
    id: 8,
    type: "general",
    title: "New Health Tips Available",
    message: "Check out our latest health tips for winter season wellness",
    time: "5 days ago",
    read: true,
    priority: "low"
  },
];

function NotificationsCenter() {
  const { t } = useLanguage();
  const [notifications, setNotifications] = useState<Notification[]>(mockNotifications);
  const [activeTab, setActiveTab] = useState("all");
  
  // Notification Settings
  const [settings, setSettings] = useState({
    pushEnabled: true,
    emailEnabled: true,
    smsEnabled: false,
    soundEnabled: true,
    vibrationEnabled: true,
    appointment: true,
    labResults: true,
    medicine: true,
    messages: true,
    health: true,
    promotional: false
  });

  // Filter and counts
  const unreadNotifications = notifications.filter(n => !n.read);
  const appointmentNotifs = notifications.filter(n => n.type === "appointment");
  const labNotifs = notifications.filter(n => n.type === "lab");
  const medicineNotifs = notifications.filter(n => n.type === "medicine");
  const messageNotifs = notifications.filter(n => n.type === "message");

  const getFilteredNotifications = () => {
    if (activeTab === "all") return notifications;
    if (activeTab === "unread") return unreadNotifications;
    return notifications.filter(n => n.type === activeTab);
  };

  const markAsRead = (id: number) => {
    setNotifications(notifications.map(n => 
      n.id === id ? { ...n, read: true } : n
    ));
  };

  const markAllAsRead = () => {
    setNotifications(notifications.map(n => ({ ...n, read: true })));
    toast.success("All notifications marked as read");
  };

  const deleteNotification = (id: number) => {
    setNotifications(notifications.filter(n => n.id !== id));
    toast.success("Notification deleted");
  };

  const clearAll = () => {
    setNotifications([]);
    toast.success("All notifications cleared");
  };

  const getNotificationIcon = (type: string) => {
    switch (type) {
      case "appointment": return <Calendar className="w-5 h-5" />;
      case "lab": return <FileText className="w-5 h-5" />;
      case "medicine": return <Pill className="w-5 h-5" />;
      case "message": return <MessageSquare className="w-5 h-5" />;
      case "health": return <Heart className="w-5 h-5" />;
      default: return <Bell className="w-5 h-5" />;
    }
  };

  const getNotificationColor = (type: string) => {
    switch (type) {
      case "appointment": return "from-blue-500 to-cyan-600";
      case "lab": return "from-green-500 to-emerald-600";
      case "medicine": return "from-purple-500 to-pink-600";
      case "message": return "from-indigo-500 to-blue-600";
      case "health": return "from-red-500 to-pink-600";
      default: return "from-gray-500 to-slate-600";
    }
  };

  const getPriorityBadge = (priority: string) => {
    switch (priority) {
      case "high": return <Badge className="bg-red-100 text-red-700">High</Badge>;
      case "medium": return <Badge className="bg-yellow-100 text-yellow-700">Medium</Badge>;
      case "low": return <Badge className="bg-blue-100 text-blue-700">Low</Badge>;
      default: return null;
    }
  };

  const NotificationCard = ({ notification }: { notification: Notification }) => {
    return (
      <Card className={`hover-lift border-0 shadow-md ${!notification.read ? 'bg-blue-50/50' : ''}`}>
        <CardContent className="p-4">
          <div className="flex items-start gap-4">
            {/* Icon */}
            <div className={`p-3 bg-gradient-to-br ${getNotificationColor(notification.type)} rounded-xl shrink-0`}>
              <div className="text-white">
                {getNotificationIcon(notification.type)}
              </div>
            </div>

            {/* Content */}
            <div className="flex-1 min-w-0">
              <div className="flex items-start justify-between gap-2 mb-1">
                <h4 className={`text-sm ${!notification.read ? 'text-gray-900' : 'text-gray-700'}`}>
                  {notification.title}
                </h4>
                {!notification.read && (
                  <div className="w-2 h-2 bg-blue-600 rounded-full shrink-0 mt-1.5"></div>
                )}
              </div>
              <p className="text-sm text-gray-600 mb-2 line-clamp-2">
                {notification.message}
              </p>
              <div className="flex items-center gap-2 flex-wrap">
                <span className="text-xs text-gray-500 flex items-center gap-1">
                  <Clock className="w-3 h-3" />
                  {notification.time}
                </span>
                {getPriorityBadge(notification.priority)}
              </div>
            </div>

            {/* Actions */}
            <div className="flex items-center gap-1 shrink-0">
              {!notification.read && (
                <Button
                  size="icon"
                  variant="ghost"
                  onClick={() => markAsRead(notification.id)}
                  className="text-blue-600 hover:text-blue-700 hover:bg-blue-50"
                >
                  <Check className="w-4 h-4" />
                </Button>
              )}
              <Button
                size="icon"
                variant="ghost"
                onClick={() => deleteNotification(notification.id)}
                className="text-red-600 hover:text-red-700 hover:bg-red-50"
              >
                <Trash2 className="w-4 h-4" />
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    );
  };

  return (
    <section className="py-16 md:py-24 bg-gradient-to-b from-white via-indigo-50/30 to-white relative overflow-hidden min-h-screen">
      {/* Background decoration */}
      <div className="absolute top-0 left-0 w-[500px] h-[500px] bg-gradient-to-br from-indigo-100/50 to-blue-100/50 rounded-full blur-3xl animate-float"></div>
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        {/* Header */}
        <div className="text-center mb-12 md:mb-16 space-y-4">
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-indigo-100 to-blue-100 rounded-full">
            <Sparkles className="w-4 h-4 text-indigo-600 animate-pulse-glow" />
            <span className="text-indigo-700 text-sm uppercase tracking-wider">Notifications</span>
          </div>
          <h2 className="text-4xl md:text-6xl">
            <span className="bg-gradient-to-r from-indigo-600 via-blue-600 to-cyan-600 bg-clip-text text-transparent">
              Notification Center
            </span>
          </h2>
          <p className="text-gray-600 max-w-2xl mx-auto text-lg">
            د اعلانونو مرکز - Stay updated with all your health notifications
          </p>
        </div>

        {/* Quick Stats */}
        <div className="grid grid-cols-2 md:grid-cols-5 gap-4 mb-8">
          <Card className="border-0 shadow-lg hover-lift">
            <CardContent className="p-4 text-center">
              <div className="p-2 bg-gradient-to-br from-indigo-500 to-blue-600 rounded-lg w-fit mx-auto mb-2">
                <Bell className="w-5 h-5 text-white" />
              </div>
              <p className="text-2xl text-gray-900">{notifications.length}</p>
              <p className="text-xs text-gray-600">Total</p>
            </CardContent>
          </Card>

          <Card className="border-0 shadow-lg hover-lift">
            <CardContent className="p-4 text-center">
              <div className="p-2 bg-gradient-to-br from-blue-500 to-cyan-600 rounded-lg w-fit mx-auto mb-2">
                <BellRing className="w-5 h-5 text-white" />
              </div>
              <p className="text-2xl text-gray-900">{unreadNotifications.length}</p>
              <p className="text-xs text-gray-600">Unread</p>
            </CardContent>
          </Card>

          <Card className="border-0 shadow-lg hover-lift">
            <CardContent className="p-4 text-center">
              <div className="p-2 bg-gradient-to-br from-green-500 to-emerald-600 rounded-lg w-fit mx-auto mb-2">
                <Calendar className="w-5 h-5 text-white" />
              </div>
              <p className="text-2xl text-gray-900">{appointmentNotifs.length}</p>
              <p className="text-xs text-gray-600">Appointments</p>
            </CardContent>
          </Card>

          <Card className="border-0 shadow-lg hover-lift">
            <CardContent className="p-4 text-center">
              <div className="p-2 bg-gradient-to-br from-purple-500 to-pink-600 rounded-lg w-fit mx-auto mb-2">
                <Pill className="w-5 h-5 text-white" />
              </div>
              <p className="text-2xl text-gray-900">{medicineNotifs.length}</p>
              <p className="text-xs text-gray-600">Medicine</p>
            </CardContent>
          </Card>

          <Card className="border-0 shadow-lg hover-lift">
            <CardContent className="p-4 text-center">
              <div className="p-2 bg-gradient-to-br from-red-500 to-pink-600 rounded-lg w-fit mx-auto mb-2">
                <FileText className="w-5 h-5 text-white" />
              </div>
              <p className="text-2xl text-gray-900">{labNotifs.length}</p>
              <p className="text-xs text-gray-600">Lab Results</p>
            </CardContent>
          </Card>
        </div>

        {/* Main Content */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Notifications List */}
          <div className="lg:col-span-2">
            <Card className="border-0 shadow-lg">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle className="flex items-center gap-2">
                    <Bell className="w-5 h-5 text-indigo-600" />
                    All Notifications - ټول اعلانونه
                  </CardTitle>
                  <div className="flex items-center gap-2">
                    {unreadNotifications.length > 0 && (
                      <Button 
                        size="sm" 
                        variant="outline"
                        onClick={markAllAsRead}
                      >
                        <CheckCircle2 className="w-4 h-4 mr-2" />
                        Mark all read
                      </Button>
                    )}
                    {notifications.length > 0 && (
                      <Button 
                        size="sm" 
                        variant="outline"
                        onClick={clearAll}
                        className="text-red-600 hover:bg-red-50"
                      >
                        <Trash2 className="w-4 h-4 mr-2" />
                        Clear all
                      </Button>
                    )}
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <Tabs value={activeTab} onValueChange={setActiveTab}>
                  <TabsList className="grid w-full grid-cols-6 mb-6">
                    <TabsTrigger value="all" className="text-xs">
                      All
                    </TabsTrigger>
                    <TabsTrigger value="unread" className="text-xs">
                      Unread
                      {unreadNotifications.length > 0 && (
                        <Badge className="ml-1 bg-blue-600 text-white text-xs">
                          {unreadNotifications.length}
                        </Badge>
                      )}
                    </TabsTrigger>
                    <TabsTrigger value="appointment" className="text-xs">
                      <Calendar className="w-3 h-3" />
                    </TabsTrigger>
                    <TabsTrigger value="lab" className="text-xs">
                      <FileText className="w-3 h-3" />
                    </TabsTrigger>
                    <TabsTrigger value="medicine" className="text-xs">
                      <Pill className="w-3 h-3" />
                    </TabsTrigger>
                    <TabsTrigger value="message" className="text-xs">
                      <MessageSquare className="w-3 h-3" />
                    </TabsTrigger>
                  </TabsList>

                  <ScrollArea className="h-[600px] pr-4">
                    <div className="space-y-4">
                      {getFilteredNotifications().length === 0 ? (
                        <div className="text-center py-12">
                          <BellOff className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                          <h3 className="text-lg text-gray-900 mb-2">No notifications</h3>
                          <p className="text-sm text-gray-600">You're all caught up!</p>
                        </div>
                      ) : (
                        getFilteredNotifications().map(notification => (
                          <NotificationCard key={notification.id} notification={notification} />
                        ))
                      )}
                    </div>
                  </ScrollArea>
                </Tabs>
              </CardContent>
            </Card>
          </div>

          {/* Settings Sidebar */}
          <div className="lg:col-span-1">
            <Card className="border-0 shadow-lg sticky top-24">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Settings className="w-5 h-5 text-indigo-600" />
                  Notification Settings
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                {/* Delivery Methods */}
                <div>
                  <h4 className="text-sm text-gray-900 mb-3">Delivery Methods</h4>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <Smartphone className="w-4 h-4 text-gray-600" />
                        <span className="text-sm text-gray-700">Push Notifications</span>
                      </div>
                      <Switch 
                        checked={settings.pushEnabled}
                        onCheckedChange={(checked) => setSettings({...settings, pushEnabled: checked})}
                      />
                    </div>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <Mail className="w-4 h-4 text-gray-600" />
                        <span className="text-sm text-gray-700">Email</span>
                      </div>
                      <Switch 
                        checked={settings.emailEnabled}
                        onCheckedChange={(checked) => setSettings({...settings, emailEnabled: checked})}
                      />
                    </div>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <MessageSquare className="w-4 h-4 text-gray-600" />
                        <span className="text-sm text-gray-700">SMS</span>
                      </div>
                      <Switch 
                        checked={settings.smsEnabled}
                        onCheckedChange={(checked) => setSettings({...settings, smsEnabled: checked})}
                      />
                    </div>
                  </div>
                </div>

                <Separator />

                {/* Sound & Vibration */}
                <div>
                  <h4 className="text-sm text-gray-900 mb-3">Sound & Vibration</h4>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <Volume2 className="w-4 h-4 text-gray-600" />
                        <span className="text-sm text-gray-700">Sound</span>
                      </div>
                      <Switch 
                        checked={settings.soundEnabled}
                        onCheckedChange={(checked) => setSettings({...settings, soundEnabled: checked})}
                      />
                    </div>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <Smartphone className="w-4 h-4 text-gray-600" />
                        <span className="text-sm text-gray-700">Vibration</span>
                      </div>
                      <Switch 
                        checked={settings.vibrationEnabled}
                        onCheckedChange={(checked) => setSettings({...settings, vibrationEnabled: checked})}
                      />
                    </div>
                  </div>
                </div>

                <Separator />

                {/* Notification Types */}
                <div>
                  <h4 className="text-sm text-gray-900 mb-3">Notification Types</h4>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <Calendar className="w-4 h-4 text-blue-600" />
                        <span className="text-sm text-gray-700">Appointments</span>
                      </div>
                      <Switch 
                        checked={settings.appointment}
                        onCheckedChange={(checked) => setSettings({...settings, appointment: checked})}
                      />
                    </div>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <FileText className="w-4 h-4 text-green-600" />
                        <span className="text-sm text-gray-700">Lab Results</span>
                      </div>
                      <Switch 
                        checked={settings.labResults}
                        onCheckedChange={(checked) => setSettings({...settings, labResults: checked})}
                      />
                    </div>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <Pill className="w-4 h-4 text-purple-600" />
                        <span className="text-sm text-gray-700">Medicine</span>
                      </div>
                      <Switch 
                        checked={settings.medicine}
                        onCheckedChange={(checked) => setSettings({...settings, medicine: checked})}
                      />
                    </div>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <MessageSquare className="w-4 h-4 text-indigo-600" />
                        <span className="text-sm text-gray-700">Messages</span>
                      </div>
                      <Switch 
                        checked={settings.messages}
                        onCheckedChange={(checked) => setSettings({...settings, messages: checked})}
                      />
                    </div>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <Heart className="w-4 h-4 text-red-600" />
                        <span className="text-sm text-gray-700">Health Tips</span>
                      </div>
                      <Switch 
                        checked={settings.health}
                        onCheckedChange={(checked) => setSettings({...settings, health: checked})}
                      />
                    </div>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <TrendingUp className="w-4 h-4 text-amber-600" />
                        <span className="text-sm text-gray-700">Promotional</span>
                      </div>
                      <Switch 
                        checked={settings.promotional}
                        onCheckedChange={(checked) => setSettings({...settings, promotional: checked})}
                      />
                    </div>
                  </div>
                </div>

                <Separator />

                <Button className="w-full bg-gradient-to-r from-indigo-500 to-blue-600">
                  Save Settings
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </section>
  );
}

export default NotificationsCenter;
