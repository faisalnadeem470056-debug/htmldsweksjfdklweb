import { motion, AnimatePresence } from 'motion/react';
import { 
  Home, Heart, X, Shield, Star, Phone, HelpCircle, MessageCircle, 
  Activity, Stethoscope, Brain, Pill, Baby, Apple, Dumbbell, 
  Calendar, BookOpen, Bot, Settings as SettingsIcon, User, Crown,
  Sparkles, LogOut, ChevronRight, Zap, Hospital, FileText, Info,
  Menu, Search, Flame, TrendingUp, Award, Gift, Bell
} from 'lucide-react';
import { Button } from './ui/button';
import { useState } from 'react';
import Logo from './Logo';

interface ModernSidebarProps {
  menuOpen: boolean;
  setMenuOpen: (open: boolean) => void;
  language: 'ps' | 'fa' | 'en';
  isAuthenticated: boolean;
  userName: string;
  userEmail: string;
  checkAuthAndNavigate: (page: string) => void;
  setCurrentPage: (page: string) => void;
  handleLogout: () => void;
  t: any;
  categories: any[];
}

interface MenuItemType {
  icon: any;
  label: string;
  onClick: () => void;
  gradient?: string;
  badge?: string;
  isNew?: boolean;
  isPremium?: boolean;
}

function MenuItem({ icon: Icon, label, onClick, gradient, badge, isNew, isPremium }: MenuItemType) {
  return (
    <motion.button
      whileHover={{ x: 4, scale: 1.02 }}
      whileTap={{ scale: 0.98 }}
      onClick={onClick}
      className="group w-full flex items-center gap-3 p-3.5 rounded-2xl bg-white/60 hover:bg-white/90 backdrop-blur-xl border border-white/50 hover:border-white shadow-sm hover:shadow-lg transition-all duration-300"
    >
      <div className={`relative flex-shrink-0 w-11 h-11 rounded-xl bg-gradient-to-br ${gradient || 'from-gray-400 to-gray-600'} flex items-center justify-center shadow-lg`}>
        <Icon className="w-5 h-5 text-white" />
        {badge && (
          <div className="absolute -top-1 -right-1 bg-red-500 text-white text-xs font-bold rounded-full w-5 h-5 flex items-center justify-center shadow-lg">
            {badge}
          </div>
        )}
      </div>
      <div className="flex-1 text-left">
        <p className="font-semibold text-gray-900 group-hover:text-transparent group-hover:bg-clip-text group-hover:bg-gradient-to-r group-hover:from-pink-600 group-hover:to-purple-600 transition-all">
          {label}
        </p>
      </div>
      <div className="flex items-center gap-2">
        {isNew && (
          <span className="text-xs font-bold px-2 py-0.5 rounded-full bg-gradient-to-r from-green-500 to-emerald-600 text-white shadow-sm">
            NEW
          </span>
        )}
        {isPremium && (
          <Crown className="w-4 h-4 text-amber-500" />
        )}
        <ChevronRight className="w-5 h-5 text-gray-400 group-hover:text-pink-500 group-hover:translate-x-1 transition-all" />
      </div>
    </motion.button>
  );
}

export function ModernSidebar({
  menuOpen,
  setMenuOpen,
  language,
  isAuthenticated,
  userName,
  userEmail,
  checkAuthAndNavigate,
  setCurrentPage,
  handleLogout,
  t,
  categories
}: ModernSidebarProps) {
  const isOwner = userEmail === 'ibrahimkhaksar.it@gmail.com';
  const [searchQuery, setSearchQuery] = useState('');
  
  const handleNavigate = (page: string) => {
    checkAuthAndNavigate(page);
    setMenuOpen(false);
  };

  const handleDirectNavigate = (page: string) => {
    setCurrentPage(page);
    setMenuOpen(false);
  };

  // Menu sections
  const mainMenuItems: MenuItemType[] = [
    { 
      icon: Home, 
      label: t.nav.home, 
      onClick: () => handleNavigate('home'),
      gradient: 'from-blue-500 to-cyan-600'
    },
    { 
      icon: MessageCircle, 
      label: t.nav.community, 
      onClick: () => handleNavigate('community'),
      gradient: 'from-green-500 to-emerald-600',
      badge: '12'
    },
    { 
      icon: Hospital, 
      label: t.nav.hospitals, 
      onClick: () => handleNavigate('hospitals'),
      gradient: 'from-red-500 to-rose-600'
    },
    { 
      icon: Stethoscope, 
      label: t.nav.doctors, 
      onClick: () => handleNavigate('doctors'),
      gradient: 'from-purple-500 to-indigo-600'
    }
  ];

  const healthMenuItems: MenuItemType[] = [
    { 
      icon: Bot, 
      label: t.nav.aiChat, 
      onClick: () => handleNavigate('ai-chat'),
      gradient: 'from-violet-500 to-purple-600',
      isNew: true
    },
    { 
      icon: Activity, 
      label: language === 'ps' ? 'روغتیا ټریکر' : language === 'fa' ? 'پیگیری سلامت' : 'Health Tracker',
      onClick: () => handleNavigate('health-tracker'),
      gradient: 'from-pink-500 to-rose-600'
    },
    { 
      icon: Pill, 
      label: language === 'ps' ? 'د درملو یادښت' : language === 'fa' ? 'یادآوری دارو' : 'Medicine Reminder',
      onClick: () => handleNavigate('medicine-reminder'),
      gradient: 'from-orange-500 to-amber-600'
    },
    { 
      icon: Calendar, 
      label: language === 'ps' ? 'وقت ورکول' : language === 'fa' ? 'نوبت‌دهی' : 'Appointments',
      onClick: () => handleNavigate('appointments'),
      gradient: 'from-blue-500 to-indigo-600'
    },
    { 
      icon: Zap, 
      label: language === 'ps' ? 'بیړني SOS' : language === 'fa' ? 'اورژانس SOS' : 'Emergency SOS',
      onClick: () => handleNavigate('emergency'),
      gradient: 'from-red-600 to-pink-600'
    }
  ];

  const toolsMenuItems: MenuItemType[] = [
    { 
      icon: Activity, 
      label: 'BMI Calculator',
      onClick: () => handleNavigate('bmi'),
      gradient: 'from-cyan-500 to-blue-600'
    },
    { 
      icon: Brain, 
      label: language === 'ps' ? 'د علایمو معاینه' : language === 'fa' ? 'بررسی علائم' : 'Symptoms Checker',
      onClick: () => handleNavigate('symptoms'),
      gradient: 'from-indigo-500 to-purple-600'
    },
    { 
      icon: FileText, 
      label: language === 'ps' ? 'د ناروغیو دایرة المعارف' : language === 'fa' ? 'دایره‌المعارف بیماری‌ها' : 'Disease Encyclopedia',
      onClick: () => handleNavigate('diseases'),
      gradient: 'from-teal-500 to-cyan-600'
    }
  ];

  const resourcesMenuItems: MenuItemType[] = [
    { 
      icon: BookOpen, 
      label: t.nav.books, 
      onClick: () => handleNavigate('books'),
      gradient: 'from-amber-500 to-orange-600'
    },
    { 
      icon: MessageCircle, 
      label: language === 'ps' ? 'طبي مشورې' : language === 'fa' ? 'مشاوره‌های طبی' : 'Consultations', 
      onClick: () => handleNavigate('consultations'),
      gradient: 'from-pink-500 to-rose-600'
    },
    { 
      icon: Pill, 
      label: t.nav.medicine, 
      onClick: () => handleNavigate('medicine'),
      gradient: 'from-green-500 to-emerald-600'
    },
    { 
      icon: Heart, 
      label: t.nav.firstaid, 
      onClick: () => handleNavigate('firstaid'),
      gradient: 'from-red-500 to-pink-600'
    }
  ];

  const supportMenuItems: MenuItemType[] = [
    { 
      icon: SettingsIcon, 
      label: language === 'ps' ? 'تنظیمات' : language === 'fa' ? 'تنظیمات' : 'Settings', 
      onClick: () => handleDirectNavigate('settings'),
      gradient: 'from-orange-500 to-red-600'
    },
    { 
      icon: Phone, 
      label: t.nav.contact, 
      onClick: () => handleDirectNavigate('contact'),
      gradient: 'from-blue-500 to-indigo-600'
    },
    { 
      icon: Info, 
      label: t.nav.about, 
      onClick: () => handleDirectNavigate('about'),
      gradient: 'from-purple-500 to-pink-600'
    },
    { 
      icon: HelpCircle, 
      label: t.nav.help, 
      onClick: () => handleNavigate('help'),
      gradient: 'from-cyan-500 to-blue-600'
    }
  ];

  // Filter all menu items
  const filteredMainItems = mainMenuItems.filter(item => 
    item.label && item.label.toLowerCase().includes(searchQuery.toLowerCase())
  );
  
  const filteredHealthItems = healthMenuItems.filter(item => 
    item.label && item.label.toLowerCase().includes(searchQuery.toLowerCase())
  );
  
  const filteredToolsItems = toolsMenuItems.filter(item => 
    item.label && item.label.toLowerCase().includes(searchQuery.toLowerCase())
  );
  
  const filteredResourcesItems = resourcesMenuItems.filter(item => 
    item.label && item.label.toLowerCase().includes(searchQuery.toLowerCase())
  );
  
  const filteredSupportItems = supportMenuItems.filter(item => 
    item.label && item.label.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <AnimatePresence>
      {menuOpen && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-50 lg:hidden"
        >
          {/* Enhanced Backdrop with animated gradient */}
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="absolute inset-0 bg-gradient-to-br from-black/70 via-purple-900/40 to-pink-900/40 backdrop-blur-md"
            onClick={() => setMenuOpen(false)}
          >
            {/* Animated gradient orbs */}
            <motion.div
              animate={{
                scale: [1, 1.2, 1],
                rotate: [0, 90, 0],
              }}
              transition={{
                duration: 20,
                repeat: Infinity,
                ease: "linear"
              }}
              className="absolute top-0 left-0 w-96 h-96 bg-purple-500/20 rounded-full blur-3xl"
            />
            <motion.div
              animate={{
                scale: [1, 1.3, 1],
                rotate: [0, -90, 0],
              }}
              transition={{
                duration: 25,
                repeat: Infinity,
                ease: "linear"
              }}
              className="absolute bottom-0 right-0 w-96 h-96 bg-pink-500/20 rounded-full blur-3xl"
            />
          </motion.div>
          
          {/* Menu Panel with glassmorphism */}
          <motion.div
            initial={{ x: '100%' }}
            animate={{ x: 0 }}
            exit={{ x: '100%' }}
            transition={{ type: 'spring', damping: 30, stiffness: 300 }}
            className="absolute inset-y-0 right-0 w-full sm:w-96 backdrop-blur-2xl bg-gradient-to-br from-white/95 via-pink-50/90 to-purple-50/90 shadow-2xl overflow-hidden flex flex-col"
          >
            {/* Elegant Header with profile */}
            <div className="relative">
              {/* Gradient background */}
              <div className="absolute inset-0 bg-gradient-to-br from-pink-500 via-purple-600 to-indigo-600 opacity-90" />
              <div className="absolute inset-0 backdrop-blur-xl" />
              
              {/* Header content */}
              <div className="relative p-6 space-y-4">
                {/* Top bar */}
                <div className="flex justify-between items-center">
                  <motion.div 
                    initial={{ scale: 0 }}
                    animate={{ scale: 1 }}
                    transition={{ type: 'spring', delay: 0.1 }}
                    className="flex items-center gap-3"
                  >
                    <div className="relative">
                      <div className="absolute inset-0 bg-white/30 rounded-2xl blur-xl" />
                      <div className="relative bg-white/95 backdrop-blur-xl p-3 rounded-2xl shadow-2xl">
                        <Logo size="sm" showText={false} />
                      </div>
                    </div>
                    <div>
                      <h2 className="text-2xl font-bold text-white">
                        HealMate
                      </h2>
                      <p className="text-xs text-white/90 font-medium">
                        {language === 'ps' ? 'د افغانستان لپاره' : language === 'fa' ? 'برای افغانستان' : 'For Afghanistan'}
                      </p>
                    </div>
                  </motion.div>
                  <Button 
                    variant="ghost" 
                    size="icon" 
                    onClick={() => setMenuOpen(false)}
                    className="text-white hover:bg-white/20 rounded-2xl w-11 h-11"
                  >
                    <X className="w-6 h-6" />
                  </Button>
                </div>

                {/* User Profile Card */}
                {isAuthenticated ? (
                  <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.2 }}
                    className="bg-white/95 backdrop-blur-xl rounded-3xl p-5 shadow-2xl border border-white/50"
                  >
                    <div className="flex items-center gap-4 mb-4">
                      <div className="relative">
                        <div className="absolute inset-0 bg-gradient-to-br from-pink-400 to-purple-500 rounded-full blur-lg opacity-60 animate-pulse" />
                        <div className="relative bg-gradient-to-br from-pink-500 via-purple-600 to-indigo-600 p-4 rounded-2xl shadow-xl">
                          <User className="w-7 h-7 text-white" />
                        </div>
                        {isOwner && (
                          <div className="absolute -top-2 -right-2 bg-gradient-to-r from-amber-400 to-orange-500 p-1.5 rounded-full shadow-lg animate-pulse">
                            <Crown className="w-4 h-4 text-white" />
                          </div>
                        )}
                      </div>
                      <div className="flex-1 min-w-0">
                        <h3 className="font-bold text-gray-900 truncate flex items-center gap-2">
                          {userName}
                          {isOwner && <Award className="w-4 h-4 text-amber-500" />}
                        </h3>
                        <p className="text-sm text-gray-600 truncate">{userEmail}</p>
                        <div className="flex items-center gap-1 mt-1">
                          <Star className="w-3 h-3 text-amber-400 fill-amber-400" />
                          <span className="text-xs font-medium text-gray-700">
                            {language === 'ps' ? 'فعال غړی' : language === 'fa' ? 'عضو فعال' : 'Active Member'}
                          </span>
                        </div>
                      </div>
                    </div>
                    <Button
                      size="sm"
                      onClick={() => handleNavigate('profile')}
                      className="w-full bg-gradient-to-r from-pink-500 via-purple-600 to-indigo-600 hover:from-pink-600 hover:via-purple-700 hover:to-indigo-700 text-white font-bold rounded-xl py-6 shadow-lg"
                    >
                      <Sparkles className="w-5 h-5 mr-2" />
                      {language === 'ps' ? 'پروفایل وګورئ' : language === 'fa' ? 'مشاهده پروفایل' : 'View Profile'}
                    </Button>
                  </motion.div>
                ) : (
                  <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.2 }}
                    className="bg-white/95 backdrop-blur-xl rounded-3xl p-5 shadow-2xl border border-white/50"
                  >
                    <p className="text-gray-700 mb-3 text-center">
                      {language === 'ps' ? 'د ټولو فیچرونو لپاره ننوځئ' : language === 'fa' ? 'برای دسترسی به همه ویژگی‌ها وارد شوید' : 'Sign in to access all features'}
                    </p>
                    <Button
                      size="sm"
                      onClick={() => handleNavigate('profile')}
                      className="w-full bg-gradient-to-r from-pink-500 via-purple-600 to-indigo-600 hover:from-pink-600 hover:via-purple-700 hover:to-indigo-700 text-white font-bold rounded-xl py-6 shadow-lg"
                    >
                      <User className="w-5 h-5 mr-2" />
                      {language === 'ps' ? 'ننوتل' : language === 'fa' ? 'ورود' : 'Sign In'}
                    </Button>
                  </motion.div>
                )}

                {/* Search Bar */}
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.3 }}
                  className="relative"
                >
                  <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                  <input
                    type="text"
                    placeholder={language === 'ps' ? 'لټون...' : language === 'fa' ? 'جستجو...' : 'Search...'}
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="w-full pl-12 pr-4 py-3.5 rounded-2xl bg-white/95 backdrop-blur-xl border border-white/50 focus:outline-none focus:ring-2 focus:ring-purple-500 shadow-lg font-medium text-gray-900 placeholder:text-gray-400"
                  />
                </motion.div>
              </div>
            </div>

            {/* Menu Content - Scrollable */}
            <div className="flex-1 overflow-y-auto overscroll-contain p-6 space-y-8 pb-8">
              {/* Main Menu */}
              {filteredMainItems.length > 0 && (
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.4 }}
                >
                  <div className="flex items-center justify-between mb-4">
                    <h3 className="text-xs uppercase tracking-wider font-bold text-gray-500">
                      {language === 'ps' ? '🏠 اصلي مینو' : language === 'fa' ? '🏠 منوی اصلی' : '🏠 Main Menu'}
                    </h3>
                    <Flame className="w-4 h-4 text-orange-500" />
                  </div>
                  <div className="space-y-2">
                    {filteredMainItems.map((item, index) => (
                      <MenuItem key={index} {...item} />
                    ))}
                  </div>
                </motion.div>
              )}

              {/* Health Tools */}
              {filteredHealthItems.length > 0 && (
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.5 }}
                >
                  <div className="flex items-center justify-between mb-4">
                    <h3 className="text-xs uppercase tracking-wider font-bold text-gray-500">
                      {language === 'ps' ? '❤️ روغتیایي وسیلې' : language === 'fa' ? '❤️ ابزارهای سلامت' : '❤️ Health Tools'}
                    </h3>
                    <TrendingUp className="w-4 h-4 text-green-500" />
                  </div>
                  <div className="space-y-2">
                    {filteredHealthItems.map((item, index) => (
                      <MenuItem key={index} {...item} />
                    ))}
                  </div>
                </motion.div>
              )}

              {/* Calculators & Checkers */}
              {filteredToolsItems.length > 0 && (
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.6 }}
                >
                  <div className="flex items-center justify-between mb-4">
                    <h3 className="text-xs uppercase tracking-wider font-bold text-gray-500">
                      {language === 'ps' ? '🧮 محاسبه کوونکي' : language === 'fa' ? '🧮 ماشین‌حساب‌ها' : '🧮 Calculators'}
                    </h3>
                    <Sparkles className="w-4 h-4 text-purple-500" />
                  </div>
                  <div className="space-y-2">
                    {filteredToolsItems.map((item, index) => (
                      <MenuItem key={index} {...item} />
                    ))}
                  </div>
                </motion.div>
              )}

              {/* Resources */}
              {filteredResourcesItems.length > 0 && (
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.7 }}
                >
                  <div className="flex items-center justify-between mb-4">
                    <h3 className="text-xs uppercase tracking-wider font-bold text-gray-500">
                      {language === 'ps' ? '📚 سرچینې' : language === 'fa' ? '📚 منابع' : '📚 Resources'}
                    </h3>
                    <BookOpen className="w-4 h-4 text-amber-500" />
                  </div>
                  <div className="space-y-2">
                    {filteredResourcesItems.map((item, index) => (
                      <MenuItem key={index} {...item} />
                    ))}
                  </div>
                </motion.div>
              )}

              {/* Support */}
              {filteredSupportItems.length > 0 && (
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.8 }}
                >
                  <div className="flex items-center justify-between mb-4">
                    <h3 className="text-xs uppercase tracking-wider font-bold text-gray-500">
                      {language === 'ps' ? '🆘 ملاتړ' : language === 'fa' ? '🆘 پشتیبانی' : '🆘 Support'}
                    </h3>
                    <HelpCircle className="w-4 h-4 text-blue-500" />
                  </div>
                  <div className="space-y-2">
                    {filteredSupportItems.map((item, index) => (
                      <MenuItem key={index} {...item} />
                    ))}
                  </div>
                </motion.div>
              )}

              {/* Premium Section */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.9 }}
                className="relative group cursor-pointer"
                onClick={() => handleNavigate('premium')}
              >
                <div className="absolute inset-0 bg-gradient-to-r from-amber-400 via-orange-500 to-pink-500 rounded-3xl blur-lg opacity-60 group-hover:opacity-80 transition-all" />
                <div className="relative bg-gradient-to-br from-amber-400 via-orange-500 to-pink-500 rounded-3xl p-6 shadow-2xl">
                  <div className="flex items-center gap-3 mb-3">
                    <Crown className="w-8 h-8 text-white" />
                    <div>
                      <h3 className="font-bold text-white text-lg">
                        {language === 'ps' ? 'پریمیم واخلئ' : language === 'fa' ? 'پریمیوم دریافت کنید' : 'Get Premium'}
                      </h3>
                      <p className="text-xs text-white/90">
                        {language === 'ps' ? 'پرته له اعلاناتو + AI بې حده' : language === 'fa' ? 'بدون تبلیغات + AI نامحدود' : 'Ad-free + Unlimited AI'}
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-bold text-white">
                      {language === 'ps' ? 'یوازې ۵۰۰ افغانی/میاشت' : language === 'fa' ? 'فقط ۵۰۰ افغانی/ماه' : 'Only 500 AFN/month'}
                    </span>
                    <ChevronRight className="w-6 h-6 text-white group-hover:translate-x-2 transition-transform" />
                  </div>
                </div>
              </motion.div>

              {/* Settings & Admin */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 1.0 }}
                className="space-y-2"
              >
                <MenuItem
                  icon={SettingsIcon}
                  label={language === 'ps' ? 'تنظیمات' : language === 'fa' ? 'تنظیمات' : 'Settings'}
                  onClick={() => handleDirectNavigate('settings')}
                  gradient="from-gray-500 to-slate-600"
                />
                
                {isOwner && (
                  <MenuItem
                    icon={Shield}
                    label="Admin Panel"
                    onClick={() => handleDirectNavigate('admin')}
                    gradient="from-purple-600 to-pink-600"
                    isPremium
                  />
                )}

                {isAuthenticated && (
                  <motion.button
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.98 }}
                    onClick={handleLogout}
                    className="w-full flex items-center gap-3 p-3.5 rounded-2xl bg-red-50 hover:bg-red-100 border-2 border-red-200 hover:border-red-400 transition-all duration-300"
                  >
                    <div className="w-11 h-11 rounded-xl bg-gradient-to-br from-red-500 to-rose-600 flex items-center justify-center shadow-lg">
                      <LogOut className="w-5 h-5 text-white" />
                    </div>
                    <p className="flex-1 font-semibold text-red-700 text-left">
                      {language === 'ps' ? 'وتل' : language === 'fa' ? 'خروج' : 'Log Out'}
                    </p>
                    <ChevronRight className="w-5 h-5 text-red-500" />
                  </motion.button>
                )}
              </motion.div>

              {/* Footer Info */}
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 1.1 }}
                className="text-center pt-4 border-t-2 border-gray-200"
              >
                <p className="text-xs text-gray-500 mb-2">
                  HealMate v2.0 - {language === 'ps' ? 'د افغانستان لپاره جوړ شوی' : language === 'fa' ? 'ساخته شده برای افغانستان' : 'Made for Afghanistan'}
                </p>
                <p className="text-xs text-gray-400">
                  {language === 'ps' ? 'د ډاکټر ابراهیم خاکسار لخوا' : language === 'fa' ? 'توسط دکتر ابراهیم خاکسار' : 'By Dr. Ibrahim Khaksar'}
                </p>
              </motion.div>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
