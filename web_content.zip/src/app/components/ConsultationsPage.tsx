import { useState } from 'react';
import { ArrowLeft, Send, MessageSquare, User, Phone, Mail, FileText, Clock, CheckCircle, AlertCircle, Plus } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Textarea } from './ui/textarea';
import { AdBanner } from './AdBanner';

interface ConsultationsPageProps {
  language: 'ps' | 'fa' | 'en';
  onBack: () => void;
  userName?: string;
  userEmail?: string;
}

interface Consultation {
  id: string;
  name: string;
  email: string;
  phone: string;
  subject: string;
  message: string;
  status: 'pending' | 'answered' | 'processing';
  date: string;
  category: string;
}

export function ConsultationsPage({ language, onBack, userName = '', userEmail = '' }: ConsultationsPageProps) {
  const [showForm, setShowForm] = useState(false);
  const [formData, setFormData] = useState({
    name: userName,
    email: userEmail,
    phone: '',
    subject: '',
    message: '',
    category: 'general',
  });
  const [submittedConsultations, setSubmittedConsultations] = useState<Consultation[]>([]);

  const t = {
    ps: {
      title: 'طبي مشورې',
      subtitle: 'د ډاکټرانو څخه مشوره واخلئ',
      newConsultation: 'نوې مشوره پوست کړئ',
      yourConsultations: 'ستاسو مشورې',
      formTitle: 'د مشورې فورمه',
      name: 'نوم',
      email: 'برېښنالیک',
      phone: 'د تلیفون شمېره',
      subject: 'موضوع',
      message: 'پیغام / د مشورې تفصیل',
      category: 'کټګوري',
      categories: {
        general: 'عمومي',
        emergency: 'بیړني',
        followup: 'د تعقیب',
        prescription: 'نسخه',
        symptoms: 'نښې او علامات',
        chronic: 'اوږدمهاله ناروغي',
      },
      submit: 'مشوره ولیږئ',
      cancel: 'بندول',
      namePlaceholder: 'خپل نوم ولیکئ',
      emailPlaceholder: 'خپل برېښنالیک ولیکئ',
      phonePlaceholder: '+93 XXX XXX XXX',
      subjectPlaceholder: 'د مشورې موضوع',
      messagePlaceholder: 'د خپلې مشورې تفصیل دلته ولیکئ. ټول معلومات محرم دي.',
      status: {
        pending: 'د تصمیم په انتظار',
        answered: 'ځواب ورکړل شوی',
        processing: 'د پروسس په حال کې',
      },
      submittedOn: 'پوست شوی په:',
      noConsultations: 'تاسو تر اوسه هیڅ مشوره نه ده پوست کړې',
      successMessage: 'ستاسو مشوره بریالیتوب سره پوست شوه!',
      fillAllFields: 'مهرباني وکړئ ټولې برخې ډکې کړئ',
    },
    fa: {
      title: 'مشاوره‌های طبی',
      subtitle: 'از داکتران مشوره بگیرید',
      newConsultation: 'ارسال مشاوره جدید',
      yourConsultations: 'مشاوره‌های شما',
      formTitle: 'فورم مشاوره',
      name: 'نام',
      email: 'ایمیل',
      phone: 'شماره تلفون',
      subject: 'موضوع',
      message: 'پیام / جزئیات مشاوره',
      category: 'دسته',
      categories: {
        general: 'عمومی',
        emergency: 'اضطراری',
        followup: 'پیگیری',
        prescription: 'نسخه',
        symptoms: 'علایم و نشانه‌ها',
        chronic: 'بیماری مزمن',
      },
      submit: 'ارسال مشاوره',
      cancel: 'بستن',
      namePlaceholder: 'نام خود را وارد کنید',
      emailPlaceholder: 'ایمیل خود را وارد کنید',
      phonePlaceholder: '+93 XXX XXX XXX',
      subjectPlaceholder: 'موضوع مشاوره',
      messagePlaceholder: 'جزئیات مشاوره خود را اینجا بنویسید. تمام معلومات محرم است.',
      status: {
        pending: 'در انتظار بررسی',
        answered: 'پاسخ داده شده',
        processing: 'در حال پردازش',
      },
      submittedOn: 'ارسال شده در:',
      noConsultations: 'شما هنوز هیچ مشاوره‌ای ارسال نکرده‌اید',
      successMessage: 'مشاوره شما با موفقیت ارسال شد!',
      fillAllFields: 'لطفاً تمام فیلدها را پر کنید',
    },
    en: {
      title: 'Medical Consultations',
      subtitle: 'Get advice from doctors',
      newConsultation: 'Post New Consultation',
      yourConsultations: 'Your Consultations',
      formTitle: 'Consultation Form',
      name: 'Name',
      email: 'Email',
      phone: 'Phone Number',
      subject: 'Subject',
      message: 'Message / Consultation Details',
      category: 'Category',
      categories: {
        general: 'General',
        emergency: 'Emergency',
        followup: 'Follow-up',
        prescription: 'Prescription',
        symptoms: 'Symptoms',
        chronic: 'Chronic Disease',
      },
      submit: 'Submit Consultation',
      cancel: 'Cancel',
      namePlaceholder: 'Enter your name',
      emailPlaceholder: 'Enter your email',
      phonePlaceholder: '+93 XXX XXX XXX',
      subjectPlaceholder: 'Consultation subject',
      messagePlaceholder: 'Write your consultation details here. All information is confidential.',
      status: {
        pending: 'Pending Review',
        answered: 'Answered',
        processing: 'Processing',
      },
      submittedOn: 'Submitted on:',
      noConsultations: 'You haven\'t submitted any consultations yet',
      successMessage: 'Your consultation was submitted successfully!',
      fillAllFields: 'Please fill all fields',
    },
  };

  const tb = t[language];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.name || !formData.email || !formData.phone || !formData.subject || !formData.message) {
      alert(tb.fillAllFields);
      return;
    }

    const newConsultation: Consultation = {
      id: `cons_${Date.now()}`,
      name: formData.name,
      email: formData.email,
      phone: formData.phone,
      subject: formData.subject,
      message: formData.message,
      category: formData.category,
      status: 'pending',
      date: new Date().toLocaleDateString('en-GB'),
    };

    setSubmittedConsultations([newConsultation, ...submittedConsultations]);
    alert(tb.successMessage);
    setShowForm(false);
    setFormData({
      name: userName,
      email: userEmail,
      phone: '',
      subject: '',
      message: '',
      category: 'general',
    });
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'answered': return 'bg-green-100 text-green-700';
      case 'processing': return 'bg-blue-100 text-blue-700';
      default: return 'bg-yellow-100 text-yellow-700';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'answered': return <CheckCircle className="w-4 h-4" />;
      case 'processing': return <Clock className="w-4 h-4" />;
      default: return <AlertCircle className="w-4 h-4" />;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50 pb-20">
      {/* Header */}
      <div className="sticky top-0 z-40 backdrop-blur-xl bg-white/80 border-b border-white/20 shadow-lg">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center gap-4 mb-2">
            <Button variant="ghost" size="icon" onClick={onBack}>
              <ArrowLeft className="w-5 h-5" />
            </Button>
            <div className="flex-1">
              <h1 className="text-2xl bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
                {tb.title}
              </h1>
              <p className="text-sm text-gray-600">{tb.subtitle}</p>
            </div>
            <Button
              onClick={() => setShowForm(true)}
              className="bg-gradient-to-r from-blue-600 to-purple-600 text-white"
            >
              <Plus className="w-4 h-4 mr-2" />
              {tb.newConsultation}
            </Button>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="container mx-auto px-4 py-6">
        <AdBanner type="medium" className="mb-6" />

        {/* Hero Section */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white/90 backdrop-blur-xl rounded-3xl p-8 mb-6 border border-white/20 shadow-xl"
        >
          <div className="flex items-center gap-4 mb-4">
            <div className="w-16 h-16 bg-gradient-to-br from-blue-500 to-purple-500 rounded-2xl flex items-center justify-center">
              <MessageSquare className="w-8 h-8 text-white" />
            </div>
            <div>
              <h2 className="text-xl mb-1">
                {language === 'ps' ? 'خپله مشوره د ډاکټرانو سره شریکه کړئ' : 
                 language === 'fa' ? 'مشاوره خود را با داکتران شریک کنید' : 
                 'Share your consultation with doctors'}
              </h2>
              <p className="text-sm text-gray-600">
                {language === 'ps' ? 'ستاسو ټولې معلومات بشپړ محرم دي' : 
                 language === 'fa' ? 'تمام معلومات شما کاملاً محرم است' : 
                 'All your information is completely confidential'}
              </p>
            </div>
          </div>
        </motion.div>

        {/* Submitted Consultations */}
        <div className="mb-6">
          <h2 className="text-xl mb-4">{tb.yourConsultations}</h2>
          
          {submittedConsultations.length === 0 ? (
            <div className="bg-white/90 backdrop-blur-xl rounded-3xl p-12 text-center border border-white/20">
              <MessageSquare className="w-16 h-16 mx-auto mb-4 text-gray-300" />
              <p className="text-gray-600">{tb.noConsultations}</p>
              <Button
                onClick={() => setShowForm(true)}
                className="mt-4 bg-gradient-to-r from-blue-600 to-purple-600 text-white"
              >
                <Plus className="w-4 h-4 mr-2" />
                {tb.newConsultation}
              </Button>
            </div>
          ) : (
            <div className="space-y-4">
              {submittedConsultations.map((consultation, index) => (
                <motion.div
                  key={consultation.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.1 }}
                  className="bg-white/90 backdrop-blur-xl rounded-2xl p-6 border border-white/20 shadow-lg"
                >
                  <div className="flex items-start justify-between mb-4">
                    <div className="flex-1">
                      <h3 className="text-lg mb-2">{consultation.subject}</h3>
                      <div className="flex items-center gap-2 text-sm text-gray-600 mb-2">
                        <Clock className="w-4 h-4" />
                        <span>{tb.submittedOn} {consultation.date}</span>
                      </div>
                    </div>
                    <div className={`flex items-center gap-2 px-3 py-1 rounded-full text-sm ${getStatusColor(consultation.status)}`}>
                      {getStatusIcon(consultation.status)}
                      <span>{tb.status[consultation.status]}</span>
                    </div>
                  </div>
                  
                  <div className="bg-gray-50 rounded-xl p-4 mb-3">
                    <p className="text-gray-700 text-sm whitespace-pre-line">{consultation.message}</p>
                  </div>
                  
                  <div className="flex items-center gap-4 text-xs text-gray-500">
                    <span className="flex items-center gap-1">
                      <User className="w-3 h-3" />
                      {consultation.name}
                    </span>
                    <span className="flex items-center gap-1">
                      <Mail className="w-3 h-3" />
                      {consultation.email}
                    </span>
                    <span className="flex items-center gap-1">
                      <Phone className="w-3 h-3" />
                      {consultation.phone}
                    </span>
                  </div>
                </motion.div>
              ))}
            </div>
          )}
        </div>

        <AdBanner type="large" className="mt-6" />
      </div>

      {/* Consultation Form Modal */}
      <AnimatePresence>
        {showForm && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm overflow-y-auto"
            onClick={() => setShowForm(false)}
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="relative bg-white rounded-3xl w-full max-w-2xl my-8 shadow-2xl"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="p-6 md:p-8 max-h-[85vh] overflow-y-auto">
                <div className="flex items-center justify-between mb-6">
                  <h2 className="text-2xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
                    {tb.formTitle}
                  </h2>
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => setShowForm(false)}
                    className="rounded-full"
                  >
                    <ArrowLeft className="w-5 h-5" />
                  </Button>
                </div>

                <form onSubmit={handleSubmit} className="space-y-4">
                  {/* Name */}
                  <div>
                    <label className="block text-sm mb-2 font-medium">
                      {tb.name} <span className="text-red-500">*</span>
                    </label>
                    <div className="relative">
                      <User className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                      <Input
                        type="text"
                        value={formData.name}
                        onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                        placeholder={tb.namePlaceholder}
                        className="pl-10"
                        style={{ fontSize: '16px' }}
                        required
                      />
                    </div>
                  </div>

                  {/* Email */}
                  <div>
                    <label className="block text-sm mb-2 font-medium">
                      {tb.email} <span className="text-red-500">*</span>
                    </label>
                    <div className="relative">
                      <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                      <Input
                        type="email"
                        value={formData.email}
                        onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                        placeholder={tb.emailPlaceholder}
                        className="pl-10"
                        style={{ fontSize: '16px' }}
                        required
                      />
                    </div>
                  </div>

                  {/* Phone */}
                  <div>
                    <label className="block text-sm mb-2 font-medium">
                      {tb.phone} <span className="text-red-500">*</span>
                    </label>
                    <div className="relative">
                      <Phone className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                      <Input
                        type="tel"
                        value={formData.phone}
                        onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                        placeholder={tb.phonePlaceholder}
                        className="pl-10"
                        style={{ fontSize: '16px' }}
                        required
                      />
                    </div>
                  </div>

                  {/* Category */}
                  <div>
                    <label className="block text-sm mb-2 font-medium">
                      {tb.category}
                    </label>
                    <select
                      value={formData.category}
                      onChange={(e) => setFormData({ ...formData, category: e.target.value })}
                      className="w-full px-4 py-3 rounded-xl border border-gray-200 bg-white"
                      style={{ fontSize: '16px' }}
                    >
                      <option value="general">{tb.categories.general}</option>
                      <option value="emergency">{tb.categories.emergency}</option>
                      <option value="followup">{tb.categories.followup}</option>
                      <option value="prescription">{tb.categories.prescription}</option>
                      <option value="symptoms">{tb.categories.symptoms}</option>
                      <option value="chronic">{tb.categories.chronic}</option>
                    </select>
                  </div>

                  {/* Subject */}
                  <div>
                    <label className="block text-sm mb-2 font-medium">
                      {tb.subject} <span className="text-red-500">*</span>
                    </label>
                    <div className="relative">
                      <FileText className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                      <Input
                        type="text"
                        value={formData.subject}
                        onChange={(e) => setFormData({ ...formData, subject: e.target.value })}
                        placeholder={tb.subjectPlaceholder}
                        className="pl-10"
                        style={{ fontSize: '16px' }}
                        required
                      />
                    </div>
                  </div>

                  {/* Message */}
                  <div>
                    <label className="block text-sm mb-2 font-medium">
                      {tb.message} <span className="text-red-500">*</span>
                    </label>
                    <Textarea
                      value={formData.message}
                      onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                      placeholder={tb.messagePlaceholder}
                      rows={6}
                      style={{ fontSize: '16px' }}
                      required
                    />
                  </div>

                  {/* Buttons */}
                  <div className="flex gap-3 pt-4">
                    <Button
                      type="submit"
                      className="flex-1 bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white py-6"
                    >
                      <Send className="w-5 h-5 mr-2" />
                      {tb.submit}
                    </Button>
                    <Button
                      type="button"
                      variant="outline"
                      onClick={() => setShowForm(false)}
                      className="px-8 py-6"
                    >
                      {tb.cancel}
                    </Button>
                  </div>
                </form>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
