// Admin Users Management Component - Firebase Firestore Integration
// د Admin کاروونکو مدیریت کمپوننټ - د Firebase Firestore سره یوځای کول

import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Users, 
  Search, 
  RefreshCw, 
  Mail, 
  Phone, 
  Calendar, 
  Crown, 
  Shield, 
  Stethoscope,
  User as UserIcon,
  Star,
  TrendingUp,
  Activity,
  Filter,
  Download,
  X,
  Check,
  AlertCircle,
  CheckCircle2,
  Plus,
  Save
} from 'lucide-react';
import { firebaseManager } from '../utils/FirebaseManager';
import { SimpleButton as Button } from './SimpleButton';
import { SimpleInput as Input } from './SimpleInput';
import { toast } from 'sonner@2.0.3';

interface User {
  id: string;
  email: string;
  name: string;
  phone?: string;
  avatar?: string;
  role: 'owner' | 'admin' | 'doctor' | 'user';
  isPremium?: boolean;
  premiumExpiryDate?: string;
  createdAt: string;
  lastLogin?: string;
}

interface AdminUsersManagementProps {
  language: 'ps' | 'fa' | 'en';
  darkMode?: boolean;
  onClose?: () => void;
}

export function AdminUsersManagement({ language, darkMode = false, onClose }: AdminUsersManagementProps) {
  const [users, setUsers] = useState<User[]>([]);
  const [filteredUsers, setFilteredUsers] = useState<User[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [filterRole, setFilterRole] = useState<string>('all');
  const [showNotification, setShowNotification] = useState('');
  const [selectedUser, setSelectedUser] = useState<User | null>(null);
  const [showAddUserModal, setShowAddUserModal] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [newUserData, setNewUserData] = useState({
    name: '',
    email: '',
    phone: '',
    role: 'user' as 'owner' | 'admin' | 'doctor' | 'user',
    isPremium: false
  });

  // د Users لیست واخلئ
  useEffect(() => {
    loadUsers();
  }, []);

  // د Search او Filter
  useEffect(() => {
    let filtered = users;

    // د Search Query
    if (searchQuery.trim()) {
      filtered = filtered.filter(user => 
        user.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        user.email.toLowerCase().includes(searchQuery.toLowerCase()) ||
        user.phone?.includes(searchQuery)
      );
    }

    // د Role Filter
    if (filterRole !== 'all') {
      filtered = filtered.filter(user => user.role === filterRole);
    }

    setFilteredUsers(filtered);
  }, [searchQuery, filterRole, users]);

  const loadUsers = async () => {
    setIsLoading(true);
    try {
      const allUsers = await firebaseManager.getAllUsers();
      setUsers(allUsers);
      setFilteredUsers(allUsers);
      
      showSuccess(
        language === 'ps' ? `✅ ${allUsers.length} کاروونکي وموندل شول` :
        language === 'fa' ? `✅ ${allUsers.length} کاربر یافت شد` :
        `✅ Found ${allUsers.length} users`
      );
    } catch (error) {
      console.error('Error loading users:', error);
      toast.error(
        language === 'ps' ? 'د کاروونکو لوستل ناکام شو' :
        language === 'fa' ? 'خواندن کاربران ناموفق بود' :
        'Failed to load users'
      );
    } finally {
      setIsLoading(false);
    }
  };

  const showSuccess = (message: string) => {
    setShowNotification(message);
    setTimeout(() => setShowNotification(''), 3000);
  };

  const saveUser = async () => {
    // Validation
    if (!newUserData.name.trim()) {
      toast.error(
        language === 'ps' ? 'نوم اړین دی' :
        language === 'fa' ? 'نام الزامی است' :
        'Name is required'
      );
      return;
    }
    if (!newUserData.email.trim() || !newUserData.email.includes('@')) {
      toast.error(
        language === 'ps' ? 'سم بریښنالیک اړین دی' :
        language === 'fa' ? 'ایمیل صحیح الزامی است' :
        'Valid email is required'
      );
      return;
    }

    setIsSaving(true);
    try {
      // د Flutter کوډ په شان - Firestore کې نوی کاروونکی ساتل
      await firebaseManager.addUser(newUserData);
      
      showSuccess(
        language === 'ps' ? '✅ نوی کاروونکی بریالیتوب سره اضافه شو!' :
        language === 'fa' ? '✅ کاربر جدید با موفقیت اضافه شد!' :
        '✅ New user added successfully!'
      );
      
      // Modal بندول او reset کول
      setShowAddUserModal(false);
      setNewUserData({
        name: '',
        email: '',
        phone: '',
        role: 'user',
        isPremium: false
      });
      
      // Users list تازه کول
      await loadUsers();
    } catch (error) {
      console.error('Error saving user:', error);
      toast.error(
        language === 'ps' ? 'د کاروونکي ساتل ناکام شو' :
        language === 'fa' ? 'ذخیره کاربر ناموفق بود' :
        'Failed to save user'
      );
    } finally {
      setIsSaving(false);
    }
  };

  const formatDate = (isoString: string) => {
    const date = new Date(isoString);
    return date.toLocaleDateString(
      language === 'ps' ? 'ps-AF' : language === 'fa' ? 'fa-IR' : 'en-US',
      { year: 'numeric', month: 'short', day: 'numeric' }
    );
  };

  const getTimeAgo = (isoString: string | undefined) => {
    if (!isoString) return language === 'ps' ? 'هیڅکله' : language === 'fa' ? 'هرگز' : 'Never';
    
    const date = new Date(isoString);
    const now = new Date();
    const diffMs = now.getTime() - date.getTime();
    const diffMins = Math.floor(diffMs / 60000);
    
    if (diffMins < 1) return language === 'ps' ? 'اوس' : language === 'fa' ? 'اکنون' : 'Just now';
    if (diffMins < 60) return `${diffMins} ${language === 'ps' ? 'دقیقې' : language === 'fa' ? 'دقیقه' : 'min'}`;
    
    const diffHours = Math.floor(diffMins / 60);
    if (diffHours < 24) return `${diffHours} ${language === 'ps' ? 'ساعته' : language === 'fa' ? 'ساعت' : 'hrs'}`;
    
    const diffDays = Math.floor(diffHours / 24);
    return `${diffDays} ${language === 'ps' ? 'ورځې' : language === 'fa' ? 'روز' : 'days'}`;
  };

  const getRoleIcon = (role: string) => {
    switch (role) {
      case 'owner': return <Crown className="w-4 h-4" />;
      case 'admin': return <Shield className="w-4 h-4" />;
      case 'doctor': return <Stethoscope className="w-4 h-4" />;
      default: return <UserIcon className="w-4 h-4" />;
    }
  };

  const getRoleColor = (role: string) => {
    switch (role) {
      case 'owner': return 'from-yellow-500 to-amber-600';
      case 'admin': return 'from-purple-500 to-indigo-600';
      case 'doctor': return 'from-green-500 to-emerald-600';
      default: return 'from-blue-500 to-cyan-600';
    }
  };

  const getRoleLabel = (role: string) => {
    const labels = {
      ps: { owner: 'مالک', admin: 'اډمین', doctor: 'ډاکټر', user: 'کاروونکی' },
      fa: { owner: 'مالک', admin: 'مدیر', doctor: 'دکتر', user: 'کاربر' },
      en: { owner: 'Owner', admin: 'Admin', doctor: 'Doctor', user: 'User' }
    };
    return labels[language][role as keyof typeof labels.en] || role;
  };

  const getStats = () => {
    return {
      total: users.length,
      premium: users.filter(u => u.isPremium).length,
      doctors: users.filter(u => u.role === 'doctor').length,
      admins: users.filter(u => u.role === 'admin' || u.role === 'owner').length
    };
  };

  const stats = getStats();

  const translations = {
    en: {
      title: 'Users Management',
      subtitle: 'View and manage all registered users',
      search: 'Search users...',
      filterAll: 'All Users',
      filterOwner: 'Owners',
      filterAdmin: 'Admins',
      filterDoctor: 'Doctors',
      filterUser: 'Users',
      refresh: 'Refresh',
      export: 'Export',
      addUser: 'Add User',
      addNewUser: 'Add New User',
      enterDetails: 'Enter user details',
      save: 'Save',
      cancel: 'Cancel',
      totalUsers: 'Total Users',
      premiumUsers: 'Premium',
      doctors: 'Doctors',
      admins: 'Admins',
      name: 'Name',
      email: 'Email',
      phone: 'Phone',
      role: 'Role',
      joined: 'Joined',
      lastSeen: 'Last Seen',
      premium: 'Premium',
      free: 'Free',
      loading: 'Loading users...',
      noUsers: 'No users found',
      close: 'Close'
    },
    ps: {
      title: 'د کاروونکو مدیریت',
      subtitle: 'د ټولو ثبت شوي کاروونکو لیدل او اداره کول',
      search: 'کاروونکي ولټوئ...',
      filterAll: 'ټول کاروونکي',
      filterOwner: 'مالکان',
      filterAdmin: 'اډمینان',
      filterDoctor: 'ډاکټران',
      filterUser: 'کاروونکي',
      refresh: 'تازه کړئ',
      export: 'Export',
      addUser: 'نوی کاروونکی',
      addNewUser: 'نوی کاروونکی اضافه کړئ',
      enterDetails: 'د کاروونکي معلومات داخل کړئ',
      save: 'ساتل',
      cancel: 'لغوه',
      totalUsers: 'ټول کاروونکي',
      premiumUsers: 'پریمیم',
      doctors: 'ډاکټران',
      admins: 'اډمینان',
      name: 'نوم',
      email: 'بریښنالیک',
      phone: 'تلیفون',
      role: 'رول',
      joined: 'شامل شوی',
      lastSeen: 'وروستی لیدل',
      premium: 'پریمیم',
      free: 'وړیا',
      loading: 'کاروونکي لوستل کیږي...',
      noUsers: 'هیڅ کاروونکی و نه موندل شو',
      close: 'بندول'
    },
    fa: {
      title: 'مدیریت کاربران',
      subtitle: 'مشاهده و مدیریت تمام کاربران ثبت شده',
      search: 'جستجوی کاربران...',
      filterAll: 'همه کاربران',
      filterOwner: 'مالکان',
      filterAdmin: 'مدیران',
      filterDoctor: 'دکتران',
      filterUser: 'کاربران',
      refresh: 'بروزرسانی',
      export: 'خروجی',
      addUser: 'افزودن کاربر',
      addNewUser: 'افزودن کاربر جدید',
      enterDetails: 'جزئیات کاربر را وارد کنید',
      save: 'ذخیره',
      cancel: 'لغو',
      totalUsers: 'کل کاربران',
      premiumUsers: 'پریمیوم',
      doctors: 'دکتران',
      admins: 'مدیران',
      name: 'نام',
      email: 'ایمیل',
      phone: 'تلفن',
      role: 'نقش',
      joined: 'عضویت',
      lastSeen: 'آخرین بازدید',
      premium: 'پریمیوم',
      free: 'رایگان',
      loading: 'در حال بارگذاری کاربران...',
      noUsers: 'کاربری یافت نشد',
      close: 'بستن'
    }
  };

  const txt = translations[language];

  return (
    <div className={`w-full h-full overflow-auto ${darkMode ? 'dark' : ''}`}>
      {/* Animated Background Mesh */}
      <div className="fixed inset-0 pointer-events-none overflow-hidden">
        <motion.div 
          animate={{
            scale: [1, 1.2, 1],
            rotate: [0, 90, 0],
          }}
          transition={{
            duration: 20,
            repeat: Infinity,
            ease: "linear"
          }}
          className={`absolute -top-1/4 -left-1/4 w-1/2 h-1/2 rounded-full blur-3xl opacity-20 ${
            darkMode ? 'bg-blue-600' : 'bg-blue-400'
          }`} 
        />
        <motion.div 
          animate={{
            scale: [1, 1.3, 1],
            rotate: [0, -90, 0],
          }}
          transition={{
            duration: 25,
            repeat: Infinity,
            ease: "linear"
          }}
          className={`absolute -bottom-1/4 -right-1/4 w-1/2 h-1/2 rounded-full blur-3xl opacity-20 ${
            darkMode ? 'bg-purple-600' : 'bg-purple-400'
          }`} 
        />
      </div>

      {/* Success Notification */}
      <AnimatePresence>
        {showNotification && (
          <motion.div
            initial={{ opacity: 0, y: -50, scale: 0.9 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -50, scale: 0.9 }}
            className="fixed top-4 left-1/2 -translate-x-1/2 z-50 px-6 py-4 rounded-2xl shadow-2xl backdrop-blur-xl border"
            style={{
              background: darkMode 
                ? 'linear-gradient(135deg, rgba(34, 197, 94, 0.2), rgba(16, 185, 129, 0.2))'
                : 'linear-gradient(135deg, rgba(34, 197, 94, 0.95), rgba(16, 185, 129, 0.95))',
              borderColor: darkMode ? 'rgba(34, 197, 94, 0.3)' : 'rgba(255, 255, 255, 0.3)'
            }}
          >
            <div className="flex items-center gap-3">
              <div className="w-6 h-6 bg-white rounded-full flex items-center justify-center">
                <Check className="w-4 h-4 text-green-600" />
              </div>
              <span className="font-medium text-white">
                {showNotification}
              </span>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Main Content */}
      <div className="container mx-auto p-6 max-w-7xl relative z-10">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center gap-3">
              <motion.div
                animate={{
                  scale: [1, 1.1, 1]
                }}
                transition={{
                  duration: 2,
                  repeat: Infinity,
                  ease: "easeInOut"
                }}
              >
                <Users className={`w-12 h-12 ${darkMode ? 'text-blue-400' : 'text-blue-600'}`} />
              </motion.div>
              <div>
                <h2 className={`text-4xl font-bold bg-gradient-to-r bg-clip-text text-transparent ${
                  darkMode 
                    ? 'from-blue-400 via-purple-400 to-pink-400'
                    : 'from-blue-600 via-purple-600 to-pink-600'
                }`}>
                  {txt.title}
                </h2>
                <p className={`text-sm ${darkMode ? 'text-gray-400' : 'text-gray-600'}`}>
                  {txt.subtitle}
                </p>
              </div>
            </div>
            {onClose && (
              <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={onClose}
                  className={`rounded-full ${darkMode ? 'hover:bg-gray-800' : 'hover:bg-gray-100'}`}
                >
                  <X className="w-5 h-5" />
                </Button>
              </motion.div>
            )}
          </div>
        </motion.div>

        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
          {/* Total Users */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="relative group"
          >
            <div className="absolute inset-0 bg-gradient-to-br from-blue-500 to-cyan-600 opacity-0 group-hover:opacity-10 rounded-2xl blur-xl transition-all duration-500" />
            <div className={`relative backdrop-blur-xl rounded-2xl p-4 border shadow-lg hover:shadow-xl transition-all ${
              darkMode ? 'bg-gray-800/70 border-gray-700/50' : 'bg-white/70 border-white/50'
            }`}>
              <div className="flex items-center justify-between">
                <div>
                  <p className={`text-sm ${darkMode ? 'text-gray-400' : 'text-gray-600'}`}>{txt.totalUsers}</p>
                  <p className={`text-3xl font-bold mt-1 ${darkMode ? 'text-white' : 'text-gray-900'}`}>{stats.total}</p>
                </div>
                <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-cyan-600 rounded-xl flex items-center justify-center">
                  <Users className="w-6 h-6 text-white" />
                </div>
              </div>
            </div>
          </motion.div>

          {/* Premium Users */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.15 }}
            className="relative group"
          >
            <div className="absolute inset-0 bg-gradient-to-br from-yellow-500 to-amber-600 opacity-0 group-hover:opacity-10 rounded-2xl blur-xl transition-all duration-500" />
            <div className={`relative backdrop-blur-xl rounded-2xl p-4 border shadow-lg hover:shadow-xl transition-all ${
              darkMode ? 'bg-gray-800/70 border-gray-700/50' : 'bg-white/70 border-white/50'
            }`}>
              <div className="flex items-center justify-between">
                <div>
                  <p className={`text-sm ${darkMode ? 'text-gray-400' : 'text-gray-600'}`}>{txt.premiumUsers}</p>
                  <p className={`text-3xl font-bold mt-1 ${darkMode ? 'text-white' : 'text-gray-900'}`}>{stats.premium}</p>
                </div>
                <div className="w-12 h-12 bg-gradient-to-br from-yellow-500 to-amber-600 rounded-xl flex items-center justify-center">
                  <Star className="w-6 h-6 text-white" />
                </div>
              </div>
            </div>
          </motion.div>

          {/* Doctors */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="relative group"
          >
            <div className="absolute inset-0 bg-gradient-to-br from-green-500 to-emerald-600 opacity-0 group-hover:opacity-10 rounded-2xl blur-xl transition-all duration-500" />
            <div className={`relative backdrop-blur-xl rounded-2xl p-4 border shadow-lg hover:shadow-xl transition-all ${
              darkMode ? 'bg-gray-800/70 border-gray-700/50' : 'bg-white/70 border-white/50'
            }`}>
              <div className="flex items-center justify-between">
                <div>
                  <p className={`text-sm ${darkMode ? 'text-gray-400' : 'text-gray-600'}`}>{txt.doctors}</p>
                  <p className={`text-3xl font-bold mt-1 ${darkMode ? 'text-white' : 'text-gray-900'}`}>{stats.doctors}</p>
                </div>
                <div className="w-12 h-12 bg-gradient-to-br from-green-500 to-emerald-600 rounded-xl flex items-center justify-center">
                  <Stethoscope className="w-6 h-6 text-white" />
                </div>
              </div>
            </div>
          </motion.div>

          {/* Admins */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.25 }}
            className="relative group"
          >
            <div className="absolute inset-0 bg-gradient-to-br from-purple-500 to-indigo-600 opacity-0 group-hover:opacity-10 rounded-2xl blur-xl transition-all duration-500" />
            <div className={`relative backdrop-blur-xl rounded-2xl p-4 border shadow-lg hover:shadow-xl transition-all ${
              darkMode ? 'bg-gray-800/70 border-gray-700/50' : 'bg-white/70 border-white/50'
            }`}>
              <div className="flex items-center justify-between">
                <div>
                  <p className={`text-sm ${darkMode ? 'text-gray-400' : 'text-gray-600'}`}>{txt.admins}</p>
                  <p className={`text-3xl font-bold mt-1 ${darkMode ? 'text-white' : 'text-gray-900'}`}>{stats.admins}</p>
                </div>
                <div className="w-12 h-12 bg-gradient-to-br from-purple-500 to-indigo-600 rounded-xl flex items-center justify-center">
                  <Shield className="w-6 h-6 text-white" />
                </div>
              </div>
            </div>
          </motion.div>
        </div>

        {/* Search and Filters */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="relative group mb-6"
        >
          <div className="absolute inset-0 bg-gradient-to-br from-blue-500 to-purple-600 opacity-0 group-hover:opacity-10 rounded-2xl blur-xl transition-all duration-500" />
          <div className={`relative backdrop-blur-xl rounded-2xl p-4 border shadow-lg ${
            darkMode ? 'bg-gray-800/70 border-gray-700/50' : 'bg-white/70 border-white/50'
          }`}>
            <div className="flex flex-col md:flex-row gap-4">
              {/* Search */}
              <div className="flex-1 relative">
                <Search className={`absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 ${
                  darkMode ? 'text-gray-400' : 'text-gray-500'
                }`} />
                <Input
                  type="text"
                  placeholder={txt.search}
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className={`pl-10 ${darkMode ? 'bg-gray-700/50 border-gray-600' : 'bg-white/50'}`}
                />
              </div>

              {/* Role Filter */}
              <div className="flex gap-2 flex-wrap">
                {['all', 'owner', 'admin', 'doctor', 'user'].map((role) => (
                  <motion.button
                    key={role}
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                    onClick={() => setFilterRole(role)}
                    className={`px-4 py-2 rounded-xl text-sm font-medium transition-all ${
                      filterRole === role
                        ? 'bg-gradient-to-r from-blue-600 to-purple-600 text-white shadow-lg'
                        : darkMode
                        ? 'bg-gray-700/50 text-gray-300 hover:bg-gray-600/50'
                        : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                    }`}
                  >
                    {role === 'all' ? txt.filterAll :
                     role === 'owner' ? txt.filterOwner :
                     role === 'admin' ? txt.filterAdmin :
                     role === 'doctor' ? txt.filterDoctor :
                     txt.filterUser}
                  </motion.button>
                ))}
              </div>

              {/* Actions */}
              <div className="flex gap-2">
                <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                  <Button
                    variant="default"
                    size="sm"
                    onClick={() => setShowAddUserModal(true)}
                    className="bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-700 hover:to-emerald-700 text-white border-0"
                  >
                    <Plus className="w-4 h-4 mr-2" />
                    {txt.addUser}
                  </Button>
                </motion.div>
                <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={loadUsers}
                    disabled={isLoading}
                    className={`${darkMode ? 'border-blue-700 text-blue-400' : 'border-blue-200 text-blue-600'}`}
                  >
                    <RefreshCw className={`w-4 h-4 mr-2 ${isLoading ? 'animate-spin' : ''}`} />
                    {txt.refresh}
                  </Button>
                </motion.div>
              </div>
            </div>
          </div>
        </motion.div>

        {/* Users Table */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          className="relative group"
        >
          <div className="absolute inset-0 bg-gradient-to-br from-indigo-500 to-purple-600 opacity-0 group-hover:opacity-10 rounded-2xl blur-xl transition-all duration-500" />
          <div className={`relative backdrop-blur-xl rounded-2xl border shadow-xl overflow-hidden ${
            darkMode ? 'bg-gray-800/70 border-gray-700/50' : 'bg-white/70 border-white/50'
          }`}>
            {/* Loading State */}
            {isLoading ? (
              <div className="p-12 text-center">
                <motion.div
                  animate={{ rotate: 360 }}
                  transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
                  className="inline-block mb-4"
                >
                  <RefreshCw className={`w-12 h-12 ${darkMode ? 'text-blue-400' : 'text-blue-600'}`} />
                </motion.div>
                <p className={`text-lg ${darkMode ? 'text-gray-300' : 'text-gray-700'}`}>
                  {txt.loading}
                </p>
              </div>
            ) : filteredUsers.length === 0 ? (
              <div className="p-12 text-center">
                <AlertCircle className={`w-12 h-12 mx-auto mb-4 ${darkMode ? 'text-gray-400' : 'text-gray-500'}`} />
                <p className={`text-lg ${darkMode ? 'text-gray-300' : 'text-gray-700'}`}>
                  {txt.noUsers}
                </p>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className={`border-b ${darkMode ? 'border-gray-700' : 'border-gray-200'}`}>
                      <th className={`px-6 py-4 text-left text-sm font-bold ${darkMode ? 'text-gray-300' : 'text-gray-700'}`}>
                        {txt.name}
                      </th>
                      <th className={`px-6 py-4 text-left text-sm font-bold ${darkMode ? 'text-gray-300' : 'text-gray-700'}`}>
                        {txt.email}
                      </th>
                      <th className={`px-6 py-4 text-left text-sm font-bold ${darkMode ? 'text-gray-300' : 'text-gray-700'}`}>
                        {txt.role}
                      </th>
                      <th className={`px-6 py-4 text-left text-sm font-bold ${darkMode ? 'text-gray-300' : 'text-gray-700'}`}>
                        {txt.joined}
                      </th>
                      <th className={`px-6 py-4 text-left text-sm font-bold ${darkMode ? 'text-gray-300' : 'text-gray-700'}`}>
                        {txt.lastSeen}
                      </th>
                    </tr>
                  </thead>
                  <tbody>
                    {filteredUsers.map((user, index) => (
                      <motion.tr
                        key={user.id}
                        initial={{ opacity: 0, x: -20 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ delay: index * 0.05 }}
                        onClick={() => setSelectedUser(user)}
                        className={`border-b cursor-pointer transition-all ${
                          darkMode 
                            ? 'border-gray-700 hover:bg-gray-700/30' 
                            : 'border-gray-100 hover:bg-gray-50'
                        }`}
                      >
                        <td className="px-6 py-4">
                          <div className="flex items-center gap-3">
                            <div className={`w-10 h-10 rounded-full bg-gradient-to-br ${getRoleColor(user.role)} flex items-center justify-center text-white font-bold`}>
                              {user.name.charAt(0).toUpperCase()}
                            </div>
                            <div>
                              <p className={`font-medium ${darkMode ? 'text-white' : 'text-gray-900'}`}>
                                {user.name}
                              </p>
                              {user.isPremium && (
                                <div className="flex items-center gap-1 mt-1">
                                  <Star className="w-3 h-3 text-yellow-500 fill-yellow-500" />
                                  <span className="text-xs text-yellow-500 font-medium">{txt.premium}</span>
                                </div>
                              )}
                            </div>
                          </div>
                        </td>
                        <td className={`px-6 py-4 text-sm ${darkMode ? 'text-gray-300' : 'text-gray-700'}`}>
                          <div className="flex items-center gap-2">
                            <Mail className="w-4 h-4 opacity-50" />
                            {user.email}
                          </div>
                        </td>
                        <td className="px-6 py-4">
                          <div className={`inline-flex items-center gap-2 px-3 py-1 rounded-lg bg-gradient-to-r ${getRoleColor(user.role)} text-white text-xs font-bold shadow-lg`}>
                            {getRoleIcon(user.role)}
                            {getRoleLabel(user.role)}
                          </div>
                        </td>
                        <td className={`px-6 py-4 text-sm ${darkMode ? 'text-gray-400' : 'text-gray-600'}`}>
                          <div className="flex items-center gap-2">
                            <Calendar className="w-4 h-4 opacity-50" />
                            {formatDate(user.createdAt)}
                          </div>
                        </td>
                        <td className={`px-6 py-4 text-sm ${darkMode ? 'text-gray-400' : 'text-gray-600'}`}>
                          <div className="flex items-center gap-2">
                            <Activity className="w-4 h-4 opacity-50" />
                            {getTimeAgo(user.lastLogin)}
                          </div>
                        </td>
                      </motion.tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </motion.div>

        {/* User Details Modal */}
        <AnimatePresence>
          {selectedUser && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 bg-black/60 backdrop-blur-md z-50 flex items-center justify-center p-4"
              onClick={() => setSelectedUser(null)}
            >
              <motion.div
                initial={{ scale: 0.9, y: 20 }}
                animate={{ scale: 1, y: 0 }}
                exit={{ scale: 0.9, y: 20 }}
                onClick={(e) => e.stopPropagation()}
                className={`max-w-2xl w-full backdrop-blur-xl rounded-3xl p-6 border shadow-2xl ${
                  darkMode ? 'bg-gray-800/90 border-gray-700' : 'bg-white/90 border-white/50'
                }`}
              >
                <div className="flex items-center justify-between mb-6">
                  <h3 className={`text-2xl font-bold ${darkMode ? 'text-white' : 'text-gray-900'}`}>
                    {language === 'ps' ? 'د کاروونکي تفصیلات' : language === 'fa' ? 'جزئیات کاربر' : 'User Details'}
                  </h3>
                  <Button variant="ghost" size="icon" onClick={() => setSelectedUser(null)}>
                    <X className="w-5 h-5" />
                  </Button>
                </div>

                <div className="space-y-4">
                  <div className="flex items-center gap-4 p-4 rounded-2xl bg-gradient-to-br from-blue-50 to-purple-50 dark:from-blue-900/20 dark:to-purple-900/20">
                    <div className={`w-16 h-16 rounded-full bg-gradient-to-br ${getRoleColor(selectedUser.role)} flex items-center justify-center text-white text-2xl font-bold`}>
                      {selectedUser.name.charAt(0).toUpperCase()}
                    </div>
                    <div className="flex-1">
                      <h4 className={`text-xl font-bold ${darkMode ? 'text-white' : 'text-gray-900'}`}>
                        {selectedUser.name}
                      </h4>
                      <div className={`inline-flex items-center gap-2 px-3 py-1 rounded-lg bg-gradient-to-r ${getRoleColor(selectedUser.role)} text-white text-xs font-bold shadow-lg mt-1`}>
                        {getRoleIcon(selectedUser.role)}
                        {getRoleLabel(selectedUser.role)}
                      </div>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className={`p-4 rounded-xl ${darkMode ? 'bg-gray-700/30' : 'bg-gray-50'}`}>
                      <div className="flex items-center gap-2 mb-2">
                        <Mail className="w-4 h-4 opacity-50" />
                        <p className={`text-sm ${darkMode ? 'text-gray-400' : 'text-gray-600'}`}>{txt.email}</p>
                      </div>
                      <p className={`font-medium ${darkMode ? 'text-white' : 'text-gray-900'}`}>{selectedUser.email}</p>
                    </div>

                    {selectedUser.phone && (
                      <div className={`p-4 rounded-xl ${darkMode ? 'bg-gray-700/30' : 'bg-gray-50'}`}>
                        <div className="flex items-center gap-2 mb-2">
                          <Phone className="w-4 h-4 opacity-50" />
                          <p className={`text-sm ${darkMode ? 'text-gray-400' : 'text-gray-600'}`}>{txt.phone}</p>
                        </div>
                        <p className={`font-medium ${darkMode ? 'text-white' : 'text-gray-900'}`}>{selectedUser.phone}</p>
                      </div>
                    )}

                    <div className={`p-4 rounded-xl ${darkMode ? 'bg-gray-700/30' : 'bg-gray-50'}`}>
                      <div className="flex items-center gap-2 mb-2">
                        <Calendar className="w-4 h-4 opacity-50" />
                        <p className={`text-sm ${darkMode ? 'text-gray-400' : 'text-gray-600'}`}>{txt.joined}</p>
                      </div>
                      <p className={`font-medium ${darkMode ? 'text-white' : 'text-gray-900'}`}>{formatDate(selectedUser.createdAt)}</p>
                    </div>

                    <div className={`p-4 rounded-xl ${darkMode ? 'bg-gray-700/30' : 'bg-gray-50'}`}>
                      <div className="flex items-center gap-2 mb-2">
                        <Activity className="w-4 h-4 opacity-50" />
                        <p className={`text-sm ${darkMode ? 'text-gray-400' : 'text-gray-600'}`}>{txt.lastSeen}</p>
                      </div>
                      <p className={`font-medium ${darkMode ? 'text-white' : 'text-gray-900'}`}>{getTimeAgo(selectedUser.lastLogin)}</p>
                    </div>
                  </div>

                  {selectedUser.isPremium && (
                    <div className="p-4 rounded-xl bg-gradient-to-br from-yellow-50 to-amber-50 dark:from-yellow-900/20 dark:to-amber-900/20 border-2 border-yellow-300 dark:border-yellow-700">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 bg-gradient-to-br from-yellow-500 to-amber-600 rounded-xl flex items-center justify-center">
                          <Star className="w-5 h-5 text-white fill-white" />
                        </div>
                        <div>
                          <p className="font-bold text-yellow-700 dark:text-yellow-400">{txt.premium} Member</p>
                          <p className="text-sm text-yellow-600 dark:text-yellow-500">
                            {selectedUser.premiumExpiryDate && `Expires: ${formatDate(selectedUser.premiumExpiryDate)}`}
                          </p>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Add User Modal - د نوي کاروونکي اضافه کول */}
        <AnimatePresence>
          {showAddUserModal && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 bg-black/60 backdrop-blur-md z-50 flex items-center justify-center p-4"
              onClick={() => setShowAddUserModal(false)}
            >
              <motion.div
                initial={{ scale: 0.9, y: 20 }}
                animate={{ scale: 1, y: 0 }}
                exit={{ scale: 0.9, y: 20 }}
                onClick={(e) => e.stopPropagation()}
                className={`max-w-lg w-full backdrop-blur-xl rounded-3xl p-6 border shadow-2xl ${
                  darkMode ? 'bg-gray-800/90 border-gray-700' : 'bg-white/90 border-white/50'
                }`}
              >
                <div className="flex items-center justify-between mb-6">
                  <div className="flex items-center gap-3">
                    <div className="w-12 h-12 bg-gradient-to-br from-green-500 to-emerald-600 rounded-xl flex items-center justify-center">
                      <Plus className="w-6 h-6 text-white" />
                    </div>
                    <h3 className={`text-2xl font-bold ${darkMode ? 'text-white' : 'text-gray-900'}`}>
                      {txt.addNewUser}
                    </h3>
                  </div>
                  <Button variant="ghost" size="icon" onClick={() => setShowAddUserModal(false)}>
                    <X className="w-5 h-5" />
                  </Button>
                </div>

                <p className={`text-sm mb-6 ${darkMode ? 'text-gray-400' : 'text-gray-600'}`}>
                  {txt.enterDetails}
                </p>

                <div className="space-y-4">
                  {/* Name Input */}
                  <div>
                    <label className={`block text-sm font-medium mb-2 ${darkMode ? 'text-gray-300' : 'text-gray-700'}`}>
                      {txt.name} *
                    </label>
                    <div className="relative">
                      <UserIcon className={`absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 ${
                        darkMode ? 'text-gray-400' : 'text-gray-500'
                      }`} />
                      <Input
                        type="text"
                        value={newUserData.name}
                        onChange={(e) => setNewUserData({ ...newUserData, name: e.target.value })}
                        placeholder={language === 'ps' ? 'نوم ولیکئ' : language === 'fa' ? 'نام را وارد کنید' : 'Enter name'}
                        className={`pl-10 ${darkMode ? 'bg-gray-700/50 border-gray-600' : 'bg-white/50'}`}
                      />
                    </div>
                  </div>

                  {/* Email Input */}
                  <div>
                    <label className={`block text-sm font-medium mb-2 ${darkMode ? 'text-gray-300' : 'text-gray-700'}`}>
                      {txt.email} *
                    </label>
                    <div className="relative">
                      <Mail className={`absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 ${
                        darkMode ? 'text-gray-400' : 'text-gray-500'
                      }`} />
                      <Input
                        type="email"
                        value={newUserData.email}
                        onChange={(e) => setNewUserData({ ...newUserData, email: e.target.value })}
                        placeholder={language === 'ps' ? 'بریښنالیک ولیکئ' : language === 'fa' ? 'ایمیل را وارد کنید' : 'Enter email'}
                        className={`pl-10 ${darkMode ? 'bg-gray-700/50 border-gray-600' : 'bg-white/50'}`}
                      />
                    </div>
                  </div>

                  {/* Phone Input */}
                  <div>
                    <label className={`block text-sm font-medium mb-2 ${darkMode ? 'text-gray-300' : 'text-gray-700'}`}>
                      {txt.phone}
                    </label>
                    <div className="relative">
                      <Phone className={`absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 ${
                        darkMode ? 'text-gray-400' : 'text-gray-500'
                      }`} />
                      <Input
                        type="tel"
                        value={newUserData.phone}
                        onChange={(e) => setNewUserData({ ...newUserData, phone: e.target.value })}
                        placeholder={language === 'ps' ? 'تلیفون نمبر ولیکئ' : language === 'fa' ? 'شماره تلفن را وارد کنید' : 'Enter phone number'}
                        className={`pl-10 ${darkMode ? 'bg-gray-700/50 border-gray-600' : 'bg-white/50'}`}
                      />
                    </div>
                  </div>

                  {/* Role Select */}
                  <div>
                    <label className={`block text-sm font-medium mb-2 ${darkMode ? 'text-gray-300' : 'text-gray-700'}`}>
                      {txt.role}
                    </label>
                    <div className="grid grid-cols-2 gap-2">
                      {(['user', 'doctor', 'admin', 'owner'] as const).map((role) => (
                        <button
                          key={role}
                          onClick={() => setNewUserData({ ...newUserData, role })}
                          className={`p-3 rounded-xl border-2 transition-all ${
                            newUserData.role === role
                              ? `border-transparent bg-gradient-to-r ${getRoleColor(role)} text-white shadow-lg`
                              : darkMode
                              ? 'border-gray-600 bg-gray-700/30 text-gray-300 hover:border-gray-500'
                              : 'border-gray-200 bg-gray-50 text-gray-700 hover:border-gray-300'
                          }`}
                        >
                          <div className="flex items-center gap-2 justify-center">
                            {getRoleIcon(role)}
                            <span className="font-medium text-sm">{getRoleLabel(role)}</span>
                          </div>
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Premium Toggle */}
                  <div className={`p-4 rounded-xl border-2 ${
                    newUserData.isPremium
                      ? 'border-yellow-500 bg-gradient-to-br from-yellow-50 to-amber-50 dark:from-yellow-900/20 dark:to-amber-900/20'
                      : darkMode
                      ? 'border-gray-600 bg-gray-700/30'
                      : 'border-gray-200 bg-gray-50'
                  }`}>
                    <label className="flex items-center justify-between cursor-pointer">
                      <div className="flex items-center gap-3">
                        <Star className={`w-5 h-5 ${newUserData.isPremium ? 'text-yellow-500 fill-yellow-500' : darkMode ? 'text-gray-400' : 'text-gray-500'}`} />
                        <span className={`font-medium ${newUserData.isPremium ? 'text-yellow-700 dark:text-yellow-400' : darkMode ? 'text-gray-300' : 'text-gray-700'}`}>
                          {txt.premium}
                        </span>
                      </div>
                      <input
                        type="checkbox"
                        checked={newUserData.isPremium}
                        onChange={(e) => setNewUserData({ ...newUserData, isPremium: e.target.checked })}
                        className="w-5 h-5 rounded accent-yellow-500"
                      />
                    </label>
                  </div>
                </div>

                {/* Actions */}
                <div className="flex gap-3 mt-6">
                  <motion.div whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }} className="flex-1">
                    <Button
                      variant="outline"
                      onClick={() => setShowAddUserModal(false)}
                      className={`w-full ${darkMode ? 'border-gray-600 text-gray-300' : ''}`}
                      disabled={isSaving}
                    >
                      {txt.cancel}
                    </Button>
                  </motion.div>
                  <motion.div whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }} className="flex-1">
                    <Button
                      onClick={saveUser}
                      disabled={isSaving}
                      className="w-full bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-700 hover:to-emerald-700 text-white border-0"
                    >
                      {isSaving ? (
                        <>
                          <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                          {language === 'ps' ? 'ساتل کیږي...' : language === 'fa' ? 'در حال ذخیره...' : 'Saving...'}
                        </>
                      ) : (
                        <>
                          <Save className="w-4 h-4 mr-2" />
                          {txt.save}
                        </>
                      )}
                    </Button>
                  </motion.div>
                </div>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}
