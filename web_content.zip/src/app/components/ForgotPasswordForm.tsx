import { useState } from "react";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Label } from "./ui/label";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "./ui/card";
import { Alert, AlertDescription } from "./ui/alert";
import { Mail, KeyRound, AlertCircle, Loader2, CheckCircle, ArrowLeft } from "lucide-react";
import { useAuth } from "../contexts/AuthContext";
import { useLanguage } from "../contexts/LanguageContext";
import { toast } from "sonner";

interface ForgotPasswordFormProps {
  onSwitchToLogin: () => void;
}

export function ForgotPasswordForm({ onSwitchToLogin }: ForgotPasswordFormProps) {
  const { resetPassword } = useAuth();
  const { language } = useLanguage();
  const [email, setEmail] = useState("");
  const [error, setError] = useState("");
  const [success, setSuccess] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  const translations = {
    en: {
      title: "Forgot Password",
      subtitle: "We'll send you reset instructions",
      email: "Email Address",
      emailPlaceholder: "your.email@example.com",
      resetButton: "Send Reset Link",
      sending: "Sending...",
      backToLogin: "Back to Login",
      successMessage: "Password reset instructions sent to your email!",
      checkEmail: "Please check your email inbox and spam folder.",
    },
    dari: {
      title: "فراموشی رمز عبور",
      subtitle: "ما دستورالعمل های بازنشانی را برای شما می فرستیم",
      email: "ایمیل آدرس",
      emailPlaceholder: "your.email@example.com",
      resetButton: "ارسال لینک بازنشانی",
      sending: "در حال ارسال...",
      backToLogin: "بازگشت به ورود",
      successMessage: "دستورالعمل های بازنشانی رمز به ایمیل شما ارسال شد!",
      checkEmail: "لطفاً صندوق ایمیل و پوشه اسپم خود را چک کنید.",
    },
    pashto: {
      title: "پاسورډ هیر شو",
      subtitle: "موږ به تاسو ته د بیا ټاکلو لارښودونه واستوو",
      email: "ایمیل آدرس",
      emailPlaceholder: "your.email@example.com",
      resetButton: "د بیا ټاکلو لینک واستوه",
      sending: "استول کیږي...",
      backToLogin: "ننوتلو ته بیرته",
      successMessage: "د پاسورډ بیا ټاکلو لارښودونه ستاسو ایمیل ته واستول شول!",
      checkEmail: "مهرباني وکړئ خپل ایمیل او spam پوښه وګورئ.",
    },
  };

  const t = translations[language as keyof typeof translations] || translations.en;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    setIsLoading(true);

    if (!email) {
      setError("Please enter your email address");
      setIsLoading(false);
      return;
    }

    // Email validation
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
      setError("Please enter a valid email address");
      setIsLoading(false);
      return;
    }

    const result = await resetPassword(email);
    
    if (result.success) {
      setSuccess(true);
      toast.success("Password reset email sent! 📧");
    } else {
      setError(result.error || "Failed to send reset email");
      toast.error(result.error || "Failed to send reset email");
    }
    
    setIsLoading(false);
  };

  if (success) {
    return (
      <Card className="glass-effect border-2 border-green-200 shadow-2xl">
        <CardHeader className="space-y-3 text-center">
          <div className="mx-auto w-16 h-16 bg-gradient-to-br from-green-500 to-emerald-500 rounded-full flex items-center justify-center shadow-lg animate-bounce">
            <CheckCircle className="w-8 h-8 text-white" />
          </div>
          <CardTitle className="text-3xl gradient-text">Email Sent!</CardTitle>
          <CardDescription className="text-base">{t.successMessage}</CardDescription>
        </CardHeader>

        <CardContent className="space-y-6">
          <Alert className="bg-green-50 border-green-200">
            <Mail className="h-4 w-4 text-green-600" />
            <AlertDescription className="text-green-800">
              {t.checkEmail}
            </AlertDescription>
          </Alert>

          <div className="space-y-3">
            <Button
              onClick={onSwitchToLogin}
              className="w-full bg-gradient-to-r from-emerald-500 to-blue-500 hover:from-emerald-600 hover:to-blue-600"
              size="lg"
            >
              <ArrowLeft className="w-5 h-5 mr-2" />
              {t.backToLogin}
            </Button>

            <Button
              onClick={() => {
                setSuccess(false);
                setEmail("");
              }}
              variant="outline"
              className="w-full"
            >
              Send to Different Email
            </Button>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="glass-effect border-2 border-blue-200 shadow-2xl">
      <CardHeader className="space-y-3 text-center">
        <div className="mx-auto w-16 h-16 bg-gradient-to-br from-blue-500 to-cyan-500 rounded-full flex items-center justify-center shadow-lg">
          <KeyRound className="w-8 h-8 text-white" />
        </div>
        <CardTitle className="text-3xl gradient-text">{t.title}</CardTitle>
        <CardDescription className="text-base">{t.subtitle}</CardDescription>
      </CardHeader>

      <CardContent className="space-y-6">
        {error && (
          <Alert className="bg-red-50 border-red-200">
            <AlertCircle className="h-4 w-4 text-red-600" />
            <AlertDescription className="text-red-800">{error}</AlertDescription>
          </Alert>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          {/* Email */}
          <div className="space-y-2">
            <Label htmlFor="email">{t.email}</Label>
            <div className="relative">
              <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
              <Input
                id="email"
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder={t.emailPlaceholder}
                className="pl-10"
                disabled={isLoading}
              />
            </div>
          </div>

          {/* Reset Button */}
          <Button
            type="submit"
            className="w-full bg-gradient-to-r from-blue-500 to-cyan-500 hover:from-blue-600 hover:to-cyan-600"
            size="lg"
            disabled={isLoading}
          >
            {isLoading ? (
              <>
                <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                {t.sending}
              </>
            ) : (
              <>
                <Mail className="w-5 h-5 mr-2" />
                {t.resetButton}
              </>
            )}
          </Button>
        </form>

        {/* Back to Login */}
        <div className="text-center pt-4 border-t">
          <button
            onClick={onSwitchToLogin}
            className="text-sm text-emerald-600 hover:text-emerald-700 hover:underline inline-flex items-center gap-1"
          >
            <ArrowLeft className="w-4 h-4" />
            {t.backToLogin}
          </button>
        </div>

        {/* Info */}
        <Alert className="bg-blue-50 border-blue-200">
          <AlertCircle className="h-4 w-4 text-blue-600" />
          <AlertDescription className="text-xs text-blue-800">
            For demo purposes, password reset will work for any registered email.
            In production, a real email will be sent.
          </AlertDescription>
        </Alert>
      </CardContent>
    </Card>
  );
}
