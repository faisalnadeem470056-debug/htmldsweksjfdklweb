import { useState } from 'react';
import { motion } from 'motion/react';
import { BookOpen, Search, ArrowLeft, Heart, Brain, Wind, Activity, Shield, AlertTriangle } from 'lucide-react';
import { Button } from './ui/button';
import { AdBanner } from './AdBanner';

interface DiseaseEncyclopediaProps {
  language: 'ps' | 'fa' | 'en';
  onBack: () => void;
}

interface Disease {
  id: string;
  name: { ps: string; fa: string; en: string };
  category: string;
  icon: any;
  description: { ps: string; fa: string; en: string };
  symptoms: { ps: string[]; fa: string[]; en: string[] };
  causes: { ps: string[]; fa: string[]; en: string[] };
  prevention: { ps: string[]; fa: string[]; en: string[] };
  treatment: { ps: string; fa: string; en: string };
  severity: 'low' | 'medium' | 'high';
}

export function DiseaseEncyclopedia({ language, onBack }: DiseaseEncyclopediaProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [selectedDisease, setSelectedDisease] = useState<Disease | null>(null);

  const t = {
    title: {
      ps: 'د ناروغیو معلومات',
      fa: 'دایره‌المعارف بیماری‌ها',
      en: 'Disease Encyclopedia'
    },
    subtitle: {
      ps: 'د ناروغیو په اړه بشپړ معلومات',
      fa: 'اطلاعات کامل در مورد بیماری‌ها',
      en: 'Complete information about diseases'
    },
    searchPlaceholder: {
      ps: 'د ناروغۍ لټون...',
      fa: 'جستجوی بیماری...',
      en: 'Search disease...'
    },
    all: { ps: 'ټول', fa: 'همه', en: 'All' },
    symptoms: { ps: 'نښې', fa: 'علائم', en: 'Symptoms' },
    causes: { ps: 'علتونه', fa: 'علل', en: 'Causes' },
    prevention: { ps: 'مخنیوی', fa: 'پیشگیری', en: 'Prevention' },
    treatment: { ps: 'درملنه', fa: 'درمان', en: 'Treatment' },
    severity: {
      low: { ps: 'کم خطر', fa: 'خطر کم', en: 'Low Risk' },
      medium: { ps: 'منځنی خطر', fa: 'خطر متوسط', en: 'Medium Risk' },
      high: { ps: 'لوړ خطر', fa: 'خطر بالا', en: 'High Risk' }
    }
  };

  const categories = [
    { id: 'all', name: { ps: 'ټول', fa: 'همه', en: 'All' }, icon: BookOpen },
    { id: 'heart', name: { ps: 'زړه', fa: 'قلب', en: 'Heart' }, icon: Heart },
    { id: 'brain', name: { ps: 'دماغ', fa: 'مغز', en: 'Brain' }, icon: Brain },
    { id: 'respiratory', name: { ps: 'تنفسي', fa: 'تنفسی', en: 'Respiratory' }, icon: Wind },
    { id: 'metabolic', name: { ps: 'میټابولیک', fa: 'متابولیک', en: 'Metabolic' }, icon: Activity },
    { id: 'infectious', name: { ps: 'انتاني', fa: 'عفونی', en: 'Infectious' }, icon: AlertTriangle }
  ];

  const diseases: Disease[] = [
    {
      id: 'diabetes',
      name: { ps: 'شکري ناروغي', fa: 'دیابت', en: 'Diabetes' },
      category: 'metabolic',
      icon: Activity,
      description: {
        ps: 'یو اوږدمهاله حالت چې د وینې شکر سطحه لوړوي',
        fa: 'یک وضعیت طولانی مدت که سطح قند خون را افزایش می‌دهد',
        en: 'A chronic condition that raises blood sugar levels'
      },
      symptoms: {
        ps: ['ډیره تنده', 'ډیر ادراره', 'ستړیا', 'د وزن کمښت', 'تیاره لید'],
        fa: ['تشنگی زیاد', 'ادرار زیاد', 'خستگی', 'کاهش وزن', 'تاری دید'],
        en: ['Excessive thirst', 'Frequent urination', 'Fatigue', 'Weight loss', 'Blurred vision']
      },
      causes: {
        ps: ['جنیتیکي فکتورونه', 'ډیر وزن', 'بې فعالیته', 'ناسم خوراک'],
        fa: ['عوامل ژنتیکی', 'اضافه وزن', 'بی‌تحرکی', 'رژیم غذایی نامناسب'],
        en: ['Genetic factors', 'Overweight', 'Inactivity', 'Poor diet']
      },
      prevention: {
        ps: ['صحي وزن ساتل', 'فعالیت', 'صحي خوراک', 'نظمی معاینات'],
        fa: ['حفظ وزن سالم', 'فعالیت بدنی', 'رژیم غذایی سالم', 'معاینات منظم'],
        en: ['Maintain healthy weight', 'Physical activity', 'Healthy diet', 'Regular checkups']
      },
      treatment: {
        ps: 'انسولین، خوراکي درمل، د خوراک بدلون، او ورزش',
        fa: 'انسولین، داروهای خوراکی، تغییر رژیم غذایی، و ورزش',
        en: 'Insulin, oral medications, diet changes, and exercise'
      },
      severity: 'high'
    },
    {
      id: 'hypertension',
      name: { ps: 'لوړ فشار', fa: 'فشار خون بالا', en: 'Hypertension' },
      category: 'heart',
      icon: Heart,
      description: {
        ps: 'د وینې فشار چې د نورمال سطحې څخه لوړ وي',
        fa: 'فشار خون که از سطح نرمال بالاتر است',
        en: 'Blood pressure above normal levels'
      },
      symptoms: {
        ps: ['سر درد', 'د سینې درد', 'د ساه تنګي', 'د پوزې وینه', 'سر خوځېدل'],
        fa: ['سردرد', 'درد قفسه سینه', 'تنگی نفس', 'خونریزی بینی', 'سرگیجه'],
        en: ['Headaches', 'Chest pain', 'Shortness of breath', 'Nosebleeds', 'Dizziness']
      },
      causes: {
        ps: ['ډیر مالګه', 'فشار', 'چرس او سګرټ', 'ډیر وزن', 'بې فعالیته'],
        fa: ['مصرف زیاد نمک', 'استرس', 'الکل و سیگار', 'اضافه وزن', 'بی‌تحرکی'],
        en: ['High salt intake', 'Stress', 'Alcohol & smoking', 'Overweight', 'Inactivity']
      },
      prevention: {
        ps: ['کم مالګه خوراک', 'ورزش', 'د وزن کنټرول', 'د فشار اداره'],
        fa: ['رژیم کم نمک', 'ورزش', 'کنترل وزن', 'مدیریت استرس'],
        en: ['Low salt diet', 'Exercise', 'Weight control', 'Stress management']
      },
      treatment: {
        ps: 'د فشار درمل، د خوراک بدلون، او د ژوند طرز بدلون',
        fa: 'داروهای فشار خون، تغییر رژیم غذایی، و تغییر سبک زندگی',
        en: 'Blood pressure medications, diet changes, and lifestyle modifications'
      },
      severity: 'high'
    },
    {
      id: 'asthma',
      name: { ps: 'د ساه تنګي', fa: 'آسم', en: 'Asthma' },
      category: 'respiratory',
      icon: Wind,
      description: {
        ps: 'د تنفسي لارو یو اوږدمهاله التهابي ناروغي',
        fa: 'یک بیماری التهابی مزمن راه‌های تنفسی',
        en: 'A chronic inflammatory disease of the airways'
      },
      symptoms: {
        ps: ['د ساه تنګي', 'د سینې تنګښت', 'ټوخی', 'سینې غږ'],
        fa: ['تنگی نفس', 'فشردگی قفسه سینه', 'سرفه', 'خس خس سینه'],
        en: ['Shortness of breath', 'Chest tightness', 'Coughing', 'Wheezing']
      },
      causes: {
        ps: ['الرجي', 'هوا ککړتیا', 'سګرټ دود', 'د تنفسي انتخاب'],
        fa: ['آلرژی', 'آلودگی هوا', 'دود سیگار', 'عفونت تنفسی'],
        en: ['Allergies', 'Air pollution', 'Smoke', 'Respiratory infections']
      },
      prevention: {
        ps: ['د الرجي مخنیوی', 'د هوا پاکوالی', 'د سګرټ پریښودل', 'نظمی درمل'],
        fa: ['اجتناب از آلرژن‌ها', 'تمیزی هوا', 'ترک سیگار', 'داروهای منظم'],
        en: ['Avoid allergens', 'Clean air', 'Quit smoking', 'Regular medication']
      },
      treatment: {
        ps: 'انهیلر، سټیرایډونه، او د الرجي درمل',
        fa: 'اینهیلر، استروئیدها، و داروهای آلرژی',
        en: 'Inhalers, steroids, and allergy medications'
      },
      severity: 'medium'
    },
    {
      id: 'tuberculosis',
      name: { ps: 'نري ناروغي', fa: 'سل', en: 'Tuberculosis' },
      category: 'infectious',
      icon: AlertTriangle,
      description: {
        ps: 'یو جدي بکټیریایي انتخاب چې سږي اغیزمن کوي',
        fa: 'یک عفونت جدی باکتریایی که ریه‌ها را تحت تاثیر قرار می‌دهد',
        en: 'A serious bacterial infection affecting the lungs'
      },
      symptoms: {
        ps: ['اوږدمهاله ټوخی', 'د وینې ټوخی', 'تبه', 'شپنۍ خولې', 'د وزن کمښت'],
        fa: ['سرفه طولانی مدت', 'سرفه خونی', 'تب', 'تعریق شبانه', 'کاهش وزن'],
        en: ['Persistent cough', 'Coughing blood', 'Fever', 'Night sweats', 'Weight loss']
      },
      causes: {
        ps: ['مایکوبکټیریوم ټیوبرکلوسس بکټریا', 'د ضعیف مدافعتي سیستم'],
        fa: ['باکتری مایکوباکتریوم توبرکلوزیس', 'سیستم ایمنی ضعیف'],
        en: ['Mycobacterium tuberculosis bacteria', 'Weak immune system']
      },
      prevention: {
        ps: ['BCG واکسین', 'د انتخاب کنټرول', 'ښه هوا جریان', 'د تشخیص معاینات'],
        fa: ['واکسن BCG', 'کنترل عفونت', 'تهویه خوب', 'معاینات تشخیصی'],
        en: ['BCG vaccine', 'Infection control', 'Good ventilation', 'Screening tests']
      },
      treatment: {
        ps: '6-9 میاشتې انټي بیوټیک درملنه',
        fa: '6-9 ماه درمان آنتی‌بیوتیک',
        en: '6-9 months of antibiotic treatment'
      },
      severity: 'high'
    },
    {
      id: 'migraine',
      name: { ps: 'میګرین', fa: 'میگرن', en: 'Migraine' },
      category: 'brain',
      icon: Brain,
      description: {
        ps: 'سخت سر درد چې ډیری وختونه د نورو نښو سره',
        fa: 'سردرد شدید که اغلب با علائم دیگر همراه است',
        en: 'Severe headache often with other symptoms'
      },
      symptoms: {
        ps: ['یو اړخي سر درد', 'زړه بدوالی', 'د رڼا حساسیت', 'د آواز حساسیت'],
        fa: ['سردرد یک طرفه', 'حالت تهوع', 'حساسیت به نور', 'حساسیت به صدا'],
        en: ['One-sided headache', 'Nausea', 'Light sensitivity', 'Sound sensitivity']
      },
      causes: {
        ps: ['جنیتیک', 'هورموني بدلونونه', 'فشار', 'ځینې خوړ', 'د خوب نشتوالی'],
        fa: ['ژنتیک', 'تغییرات هورمونی', 'استرس', 'برخی غذاها', 'کمبود خواب'],
        en: ['Genetics', 'Hormonal changes', 'Stress', 'Certain foods', 'Lack of sleep']
      },
      prevention: {
        ps: ['نظمی خوب', 'د فشار اداره', 'د ټریګر مخنیوی', 'ورزش'],
        fa: ['خواب منظم', 'مدیریت استرس', 'اجتناب از محرک‌ها', 'ورزش'],
        en: ['Regular sleep', 'Stress management', 'Avoid triggers', 'Exercise']
      },
      treatment: {
        ps: 'درد کموونکي، د میګرین ځانګړي درمل، او مخنیوي درملنه',
        fa: 'مسکن‌ها، داروهای اختصاصی میگرن، و درمان پیشگیرانه',
        en: 'Pain relievers, specific migraine drugs, and preventive treatment'
      },
      severity: 'medium'
    },
    {
      id: 'malaria',
      name: { ps: 'ملریا', fa: 'مالاریا', en: 'Malaria' },
      category: 'infectious',
      icon: AlertTriangle,
      description: {
        ps: 'د ملیریا یو جدي انتخاب چې د مچۍ له لارې خپریږي',
        fa: 'یک عفونت جدی مالاریا که توسط پشه منتقل می‌شود',
        en: 'A serious parasitic infection transmitted by mosquitoes'
      },
      symptoms: {
        ps: ['تبه', 'یخ', 'سر درد', 'عضلاتو درد', 'ستړیا'],
        fa: ['تب', 'لرز', 'سردرد', 'درد عضلانی', 'خستگی'],
        en: ['Fever', 'Chills', 'Headache', 'Muscle pain', 'Fatigue']
      },
      causes: {
        ps: ['پلازموډیم پرازیټ چې د انفیکټ شوي مچۍ له لارې خپریږي'],
        fa: ['انگل پلاسمودیوم که توسط پشه آلوده منتقل می‌شود'],
        en: ['Plasmodium parasite transmitted by infected mosquitoes']
      },
      prevention: {
        ps: ['د مچۍ جالۍ', 'د حشراتو وژونکي', 'د ملریا درمل', 'په خوندي ساحو کې پاتې کیدل'],
        fa: ['تور پشه‌بند', 'حشره‌کش‌ها', 'داروهای ضد مالاریا', 'ماندن در مناطق امن'],
        en: ['Mosquito nets', 'Insect repellents', 'Anti-malarial drugs', 'Stay in safe areas']
      },
      treatment: {
        ps: 'د ملریا ضد درمل لکه کلوروکین یا آرټیمیسینین',
        fa: 'داروهای ضد مالاریا مانند کلروکین یا آرتمیزینین',
        en: 'Anti-malarial drugs like chloroquine or artemisinin'
      },
      severity: 'high'
    }
  ];

  const filteredDiseases = diseases.filter(disease => {
    const matchesSearch = disease.name[language].toLowerCase().includes(searchTerm.toLowerCase()) ||
                         disease.name.en.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = selectedCategory === 'all' || disease.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'low':
        return 'from-green-500 to-emerald-500';
      case 'medium':
        return 'from-yellow-500 to-orange-500';
      case 'high':
        return 'from-red-500 to-pink-500';
      default:
        return 'from-gray-500 to-gray-600';
    }
  };

  if (selectedDisease) {
    const Icon = selectedDisease.icon;
    
    return (
      <div className="min-h-screen bg-gradient-to-br from-indigo-50 via-purple-50 to-pink-50 pb-20">
        {/* Header */}
        <div className="sticky top-0 z-40 backdrop-blur-xl bg-white/70 border-b border-white/20 shadow-lg">
          <div className="container mx-auto px-4 py-4">
            <div className="flex items-center gap-4">
              <Button variant="ghost" size="icon" onClick={() => setSelectedDisease(null)}>
                <ArrowLeft className="w-6 h-6" />
              </Button>
              <div className="flex items-center gap-3">
                <div className={`bg-gradient-to-br ${getSeverityColor(selectedDisease.severity)} p-3 rounded-2xl`}>
                  <Icon className="w-6 h-6 text-white" />
                </div>
                <div>
                  <h1 className="text-xl font-bold text-gray-800">
                    {selectedDisease.name[language]}
                  </h1>
                  <p className="text-xs text-gray-600">{selectedDisease.description[language]}</p>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="container mx-auto px-4 py-8">
          <AdBanner type="medium" />

          {/* Severity Badge */}
          <div className="mb-6 flex justify-center">
            <div className={`px-6 py-3 rounded-full bg-gradient-to-r ${getSeverityColor(selectedDisease.severity)} text-white font-bold shadow-lg`}>
              {t.severity[selectedDisease.severity][language]}
            </div>
          </div>

          {/* Description */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-white/90 backdrop-blur-xl rounded-3xl p-6 shadow-xl border border-white/20 mb-6"
          >
            <p className="text-gray-700 text-lg" dir={language === 'en' ? 'ltr' : 'rtl'}>
              {selectedDisease.description[language]}
            </p>
          </motion.div>

          {/* Symptoms */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="bg-white/90 backdrop-blur-xl rounded-3xl p-6 shadow-xl border border-white/20 mb-6"
          >
            <h2 className="text-xl font-bold mb-4 flex items-center gap-2">
              <AlertTriangle className="w-5 h-5 text-orange-600" />
              {t.symptoms[language]}
            </h2>
            <ul className="space-y-2" dir={language === 'en' ? 'ltr' : 'rtl'}>
              {selectedDisease.symptoms[language].map((symptom, index) => (
                <li key={index} className="flex items-start gap-2">
                  <div className="w-2 h-2 bg-orange-500 rounded-full mt-2 flex-shrink-0" />
                  <span className="text-gray-700">{symptom}</span>
                </li>
              ))}
            </ul>
          </motion.div>

          {/* Causes */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="bg-white/90 backdrop-blur-xl rounded-3xl p-6 shadow-xl border border-white/20 mb-6"
          >
            <h2 className="text-xl font-bold mb-4 flex items-center gap-2">
              <Search className="w-5 h-5 text-blue-600" />
              {t.causes[language]}
            </h2>
            <ul className="space-y-2" dir={language === 'en' ? 'ltr' : 'rtl'}>
              {selectedDisease.causes[language].map((cause, index) => (
                <li key={index} className="flex items-start gap-2">
                  <div className="w-2 h-2 bg-blue-500 rounded-full mt-2 flex-shrink-0" />
                  <span className="text-gray-700">{cause}</span>
                </li>
              ))}
            </ul>
          </motion.div>

          {/* Prevention */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
            className="bg-white/90 backdrop-blur-xl rounded-3xl p-6 shadow-xl border border-white/20 mb-6"
          >
            <h2 className="text-xl font-bold mb-4 flex items-center gap-2">
              <Shield className="w-5 h-5 text-green-600" />
              {t.prevention[language]}
            </h2>
            <ul className="space-y-2" dir={language === 'en' ? 'ltr' : 'rtl'}>
              {selectedDisease.prevention[language].map((prev, index) => (
                <li key={index} className="flex items-start gap-2">
                  <div className="w-2 h-2 bg-green-500 rounded-full mt-2 flex-shrink-0" />
                  <span className="text-gray-700">{prev}</span>
                </li>
              ))}
            </ul>
          </motion.div>

          {/* Treatment */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4 }}
            className="bg-gradient-to-br from-purple-50 to-pink-50 border-2 border-purple-200 rounded-3xl p-6 shadow-xl mb-6"
          >
            <h2 className="text-xl font-bold mb-4 flex items-center gap-2">
              <Heart className="w-5 h-5 text-purple-600" />
              {t.treatment[language]}
            </h2>
            <p className="text-gray-700 text-lg" dir={language === 'en' ? 'ltr' : 'rtl'}>
              {selectedDisease.treatment[language]}
            </p>
          </motion.div>

          <AdBanner type="large" />
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-50 via-purple-50 to-pink-50 pb-20">
      {/* Header */}
      <div className="sticky top-0 z-40 backdrop-blur-xl bg-white/70 border-b border-white/20 shadow-lg">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center gap-4">
            <Button variant="ghost" size="icon" onClick={onBack}>
              <ArrowLeft className="w-6 h-6" />
            </Button>
            <div className="flex items-center gap-3">
              <div className="bg-gradient-to-br from-blue-500 to-purple-600 p-3 rounded-2xl">
                <BookOpen className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-xl bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
                  {t.title[language]}
                </h1>
                <p className="text-xs text-gray-600">{t.subtitle[language]}</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-8">
        <AdBanner type="medium" />

        {/* Search */}
        <div className="mb-6">
          <div className="relative">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder={t.searchPlaceholder[language]}
              className="w-full pl-12 pr-4 py-4 rounded-2xl border border-gray-200 focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white/50 backdrop-blur-sm"
            />
          </div>
        </div>

        {/* Categories */}
        <div className="flex gap-3 overflow-x-auto pb-4 mb-6 scrollbar-hide">
          {categories.map((category) => {
            const Icon = category.icon;
            const isActive = selectedCategory === category.id;
            
            return (
              <button
                key={category.id}
                onClick={() => setSelectedCategory(category.id)}
                className={`flex items-center gap-2 px-4 py-2 rounded-full whitespace-nowrap transition-all ${
                  isActive
                    ? 'bg-gradient-to-r from-blue-500 to-purple-600 text-white shadow-lg'
                    : 'bg-white text-gray-700 border border-gray-200 hover:border-blue-300'
                }`}
              >
                <Icon className={`w-4 h-4 ${isActive ? 'text-white' : 'text-gray-600'}`} />
                {category.name[language]}
              </button>
            );
          })}
        </div>

        {/* Diseases Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {filteredDiseases.map((disease, index) => {
            const Icon = disease.icon;
            
            return (
              <motion.div
                key={disease.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                onClick={() => setSelectedDisease(disease)}
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                className="bg-white/90 backdrop-blur-xl rounded-3xl p-6 shadow-xl border border-white/20 cursor-pointer hover:shadow-2xl transition-all"
              >
                <div className="flex items-start gap-4 mb-4">
                  <div className={`w-16 h-16 bg-gradient-to-br ${getSeverityColor(disease.severity)} rounded-2xl flex items-center justify-center flex-shrink-0`}>
                    <Icon className="w-8 h-8 text-white" />
                  </div>
                  <div className="flex-1">
                    <h3 className="text-lg font-bold text-gray-800 mb-1">
                      {disease.name[language]}
                    </h3>
                    <div className={`inline-block px-3 py-1 rounded-full text-xs font-bold text-white bg-gradient-to-r ${getSeverityColor(disease.severity)}`}>
                      {t.severity[disease.severity][language]}
                    </div>
                  </div>
                </div>
                <p className="text-sm text-gray-600 line-clamp-2" dir={language === 'en' ? 'ltr' : 'rtl'}>
                  {disease.description[language]}
                </p>
              </motion.div>
            );
          })}
        </div>

        <div className="mt-8">
          <AdBanner type="large" />
        </div>
      </div>
    </div>
  );
}