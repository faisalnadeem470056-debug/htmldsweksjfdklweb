import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ChevronDown, Plus, Heart, MessageCircle, Share2, Send, X, ThumbsUp, MoreVertical, Trash2, Edit, Flag, Image as ImageIcon, Camera, Globe, Award, Shield, UsersIcon, Lock, Check, Edit2, Video, Upload, Link } from 'lucide-react';
import { Button } from './ui/button';
import { Textarea } from './ui/textarea';
import { Card } from './ui/card';
import { Avatar } from './ui/avatar';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { ImageWithFallback } from './figma/ImageWithFallback';
import { copyToClipboard } from '../utils/clipboard';
import { MediaUploader } from './MediaUploader';
import { ShareModal } from './ShareModal';

interface EnhancedSocialFeedProps {
  language: 'ps' | 'fa' | 'en';
  currentUserId: string;
  currentUserName: string;
  currentUserImage: string;
  onNavigateToPremium?: () => void;
  onNavigateToProfile?: (userId: string) => void;
}

interface Post {
  id: string;
  userId: string;
  userName: string;
  userImage: string;
  content: string;
  images: string[];
  videos?: string[];
  likes: string[];
  comments: Comment[];
  shares: number;
  timestamp: string;
  privacy: 'public' | 'friends' | 'private';
  isPremium?: boolean;
  isEdited?: boolean;
  reports?: number;
}

interface Comment {
  id: string;
  userId: string;
  userName: string;
  userImage: string;
  content: string;
  timestamp: string;
  likes: string[];
}

const translations = {
  ps: {
    whatsOnMind: 'تاسو څه فکر کوئ؟',
    createPost: 'پوست جوړ کړئ',
    post: 'خپور کړئ',
    cancel: 'لغوه',
    addPhoto: 'عکس اضافه کړئ',
    addPhotos: 'عکسونه اضافه کړئ',
    like: 'خوښ',
    comment: 'تبصره',
    share: 'شریک',
    likes: 'خوښونه',
    comments: 'تبصرې',
    shares: 'شریکونه',
    writeComment: 'تبصره ولیکئ...',
    send: 'واستوئ',
    delete: 'حذف',
    edit: 'سم کړئ',
    report: 'ریپورټ',
    save: 'خوندي کړئ',
    noPostsYet: 'تراوسه هیڅ پوست نشته',
    startSharing: 'خپل فکرونه شریک کړئ!',
    justNow: 'اوس',
    minutesAgo: 'منټې مخکې',
    hoursAgo: 'ساعتونه مخکې',
    daysAgo: 'ورځې مخکې',
    public: 'عامه',
    friends: 'ملګري',
    private: 'شخصي',
    viewAll: 'ټول وګورئ',
    hide: 'پټول',
    edited: 'سم شوی',
    owner: 'مالک',
    admin: 'ادمین',
    premium: 'Premium',
    verified: 'تایید شوی',
    reportPost: 'پوست ریپورټ کړئ',
    reportReason: 'د ریپورټ دلیل',
    reportDescription: 'تفصیل',
    reportReasons: {
      spam: 'سپام',
      harassment: 'ځورونه',
      inappropriate: 'ناسم مینځپانګه',
      misinformation: 'غلط معلومات',
      other: 'نور',
    },
    reportSubmit: 'ریپورټ واستوئ',
    reportSuccess: 'ریپورټ واستول شو',
    deleteConfirm: 'ایا تاسو غواړئ دا پوست حذف کړئ؟',
    editPost: 'پوست سم کړئ',
    update: 'تازه کړئ',
    viewProfile: 'پروفایل وګورئ',
    and: 'او',
    others: 'نور',
    you: 'تاسو',
    likedThis: 'دا خوښ کړل',
    commentLike: 'خوښ کړئ',
    reply: 'ځواب',
    seeMore: 'نور وګورئ',
    seeLess: 'لږ وګورئ',
    sharePost: 'پوست شریک کړئ',
    shareSuccess: 'پوست شریک شو',
    copyLink: 'لینک کاپی',
    linkCopied: 'لینک کاپی شو',
  },
  fa: {
    whatsOnMind: 'به چه فکر می‌کنید؟',
    createPost: 'ایجاد پست',
    post: 'انتشار',
    cancel: 'لغو',
    addPhoto: 'افزودن عکس',
    addPhotos: 'افزودن عکس‌ها',
    like: 'پسند',
    comment: 'نظر',
    share: 'اشتراک',
    likes: 'پسندها',
    comments: 'نظرات',
    shares: 'اشتراک‌ها',
    writeComment: 'نظر بنویسید...',
    send: 'ارسال',
    delete: 'حذف',
    edit: 'ویرایش',
    report: 'گزارش',
    save: 'ذخیره',
    noPostsYet: 'هنوز پستی نیست',
    startSharing: 'افکار خود را به اشتراک بگذارید!',
    justNow: 'الان',
    minutesAgo: 'دقیقه پیش',
    hoursAgo: 'ساعت پیش',
    daysAgo: 'روز پیش',
    public: 'عمومی',
    friends: 'دوستان',
    private: 'خصوصی',
    viewAll: 'مشاهده همه',
    hide: 'پنهان',
    edited: 'ویرایش شده',
    owner: 'مالک',
    admin: 'مدیر',
    premium: 'پریمیوم',
    verified: 'تایید شده',
    reportPost: 'گزارش پست',
    reportReason: 'دلیل گزارش',
    reportDescription: 'توضیحات',
    reportReasons: {
      spam: 'هرزنامه',
      harassment: 'آزار',
      inappropriate: 'محتوای نامناسب',
      misinformation: 'اطلاعات نادرست',
      other: 'دیگر',
    },
    reportSubmit: 'ارسال گزارش',
    reportSuccess: 'گزارش ارسال شد',
    deleteConfirm: 'آیا می‌خواهید این پست را حذف کنید؟',
    editPost: 'ویرایش پست',
    update: 'به‌روزرسانی',
    viewProfile: 'مشاهده پروفایل',
    and: 'و',
    others: 'دیگران',
    you: 'شما',
    likedThis: 'پسندیده‌اند',
    commentLike: 'پسند',
    reply: 'پاسخ',
    seeMore: 'بیشتر',
    seeLess: 'کمتر',
    sharePost: 'اشتراک پست',
    shareSuccess: 'پست به اشتراک گذاشته شد',
    copyLink: 'کپی لینک',
    linkCopied: 'لینک کپی شد',
  },
  en: {
    whatsOnMind: 'What\'s on your mind?',
    createPost: 'Create Post',
    post: 'Post',
    cancel: 'Cancel',
    addPhoto: 'Add Photo',
    addPhotos: 'Add Photos',
    like: 'Like',
    comment: 'Comment',
    share: 'Share',
    likes: 'Likes',
    comments: 'Comments',
    shares: 'Shares',
    writeComment: 'Write a comment...',
    send: 'Send',
    delete: 'Delete',
    edit: 'Edit',
    report: 'Report',
    save: 'Save',
    noPostsYet: 'No posts yet',
    startSharing: 'Start sharing your thoughts!',
    justNow: 'Just now',
    minutesAgo: 'minutes ago',
    hoursAgo: 'hours ago',
    daysAgo: 'days ago',
    public: 'Public',
    friends: 'Friends',
    private: 'Private',
    viewAll: 'View all',
    hide: 'Hide',
    edited: 'Edited',
    owner: 'Owner',
    admin: 'Admin',
    premium: 'Premium',
    verified: 'Verified',
    reportPost: 'Report Post',
    reportReason: 'Report Reason',
    reportDescription: 'Description',
    reportReasons: {
      spam: 'Spam',
      harassment: 'Harassment',
      inappropriate: 'Inappropriate Content',
      misinformation: 'Misinformation',
      other: 'Other',
    },
    reportSubmit: 'Submit Report',
    reportSuccess: 'Report submitted',
    deleteConfirm: 'Do you want to delete this post?',
    editPost: 'Edit Post',
    update: 'Update',
    viewProfile: 'View Profile',
    and: 'and',
    others: 'others',
    you: 'You',
    likedThis: 'liked this',
    commentLike: 'Like',
    reply: 'Reply',
    seeMore: 'See more',
    seeLess: 'See less',
    sharePost: 'Share Post',
    shareSuccess: 'Post shared',
    copyLink: 'Copy Link',
    linkCopied: 'Link copied',
  },
};

export function EnhancedSocialFeed({
  language,
  currentUserId,
  currentUserName,
  currentUserImage,
  onNavigateToPremium,
  onNavigateToProfile,
}: EnhancedSocialFeedProps) {
  const [posts, setPosts] = useState<Post[]>([]);
  const [newPostContent, setNewPostContent] = useState('');
  const [newPostImages, setNewPostImages] = useState<string[]>([]);
  const [newPostVideos, setNewPostVideos] = useState<string[]>([]);
  const [showCreatePost, setShowCreatePost] = useState(false);
  const [commentTexts, setCommentTexts] = useState<{ [key: string]: string }>({});
  const [showComments, setShowComments] = useState<{ [key: string]: boolean }>({});
  const [postPrivacy, setPostPrivacy] = useState<'public' | 'friends' | 'private'>('public');
  const [showReportModal, setShowReportModal] = useState(false);
  const [reportingPostId, setReportingPostId] = useState('');
  const [reportReason, setReportReason] = useState('');
  const [reportDescription, setReportDescription] = useState('');
  const [editingPostId, setEditingPostId] = useState('');
  const [editingContent, setEditingContent] = useState('');
  const [showMenuForPost, setShowMenuForPost] = useState('');
  const [notification, setNotification] = useState('');
  const [expandedPosts, setExpandedPosts] = useState<{ [key: string]: boolean }>({});
  const [shareModalOpen, setShareModalOpen] = useState(false);
  const [sharingPost, setSharingPost] = useState<Post | null>(null);

  const t = translations[language];
  const isAdmin = currentUserId === 'ibrahimkhaksar.it@gmail.com';

  // Load posts from localStorage
  useEffect(() => {
    const savedPosts = localStorage.getItem('healmate_posts');
    if (savedPosts) {
      setPosts(JSON.parse(savedPosts));
    } else {
      // د sample posts
      const samplePosts: Post[] = [
        {
          id: '1',
          userId: 'sample@user.com',
          userName: 'Dr. Ahmad Khan',
          userImage: 'https://images.unsplash.com/photo-1612349317150-e413f6a5b16d?w=400',
          content: language === 'ps' 
            ? 'د روغتیا ساتنې په اړه یو مهم خبر: هره ورځ لږترلږه 30 منټې ورزش وکړئ!'
            : language === 'fa'
            ? 'یک خبر مهم درباره سلامت: هر روز حداقل 30 دقیقه ورزش کنید!'
            : 'Important health tip: Exercise at least 30 minutes every day!',
          images: ['https://images.unsplash.com/photo-1571019614242-c5c5dee9f50b?w=800'],
          likes: ['user1', 'user2', 'user3'],
          comments: [],
          shares: 5,
          timestamp: new Date(Date.now() - 2 * 60 * 60 * 1000).toISOString(),
          privacy: 'public',
        },
      ];
      setPosts(samplePosts);
      localStorage.setItem('healmate_posts', JSON.stringify(samplePosts));
    }
  }, [language]);

  // Save posts to localStorage
  const savePosts = (updatedPosts: Post[]) => {
    setPosts(updatedPosts);
    localStorage.setItem('healmate_posts', JSON.stringify(updatedPosts));
  };

  // Create post
  const handleCreatePost = () => {
    if (!newPostContent.trim() && newPostImages.length === 0 && newPostVideos.length === 0) return;

    const newPost: Post = {
      id: Date.now().toString(),
      userId: currentUserId,
      userName: currentUserName,
      userImage: currentUserImage,
      content: newPostContent,
      images: newPostImages,
      videos: newPostVideos,
      likes: [],
      comments: [],
      shares: 0,
      timestamp: new Date().toISOString(),
      privacy: postPrivacy,
    };

    savePosts([newPost, ...posts]);
    setNewPostContent('');
    setNewPostImages([]);
    setNewPostVideos([]);
    setShowCreatePost(false);
    showNotification(language === 'ps' ? 'پوست خپور شو!' : language === 'fa' ? 'پست منتشر شد!' : 'Post published!');
  };

  // Like/Unlike post
  const handleLikePost = (postId: string) => {
    const updatedPosts = posts.map((post) => {
      if (post.id === postId) {
        const hasLiked = post.likes.includes(currentUserId);
        return {
          ...post,
          likes: hasLiked
            ? post.likes.filter((id) => id !== currentUserId)
            : [...post.likes, currentUserId],
        };
      }
      return post;
    });
    savePosts(updatedPosts);
  };

  // Add comment
  const handleAddComment = (postId: string) => {
    const commentText = commentTexts[postId]?.trim();
    if (!commentText) return;

    const newComment: Comment = {
      id: Date.now().toString(),
      userId: currentUserId,
      userName: currentUserName,
      userImage: currentUserImage,
      content: commentText,
      timestamp: new Date().toISOString(),
      likes: [],
    };

    const updatedPosts = posts.map((post) => {
      if (post.id === postId) {
        return {
          ...post,
          comments: [...post.comments, newComment],
        };
      }
      return post;
    });

    savePosts(updatedPosts);
    setCommentTexts({ ...commentTexts, [postId]: '' });
    showNotification(t.send);
  };

  // Like comment
  const handleLikeComment = (postId: string, commentId: string) => {
    const updatedPosts = posts.map((post) => {
      if (post.id === postId) {
        return {
          ...post,
          comments: post.comments.map((comment) => {
            if (comment.id === commentId) {
              const hasLiked = comment.likes.includes(currentUserId);
              return {
                ...comment,
                likes: hasLiked
                  ? comment.likes.filter((id) => id !== currentUserId)
                  : [...comment.likes, currentUserId],
              };
            }
            return comment;
          }),
        };
      }
      return post;
    });
    savePosts(updatedPosts);
  };

  // Delete post
  const handleDeletePost = (postId: string) => {
    if (confirm(t.deleteConfirm)) {
      savePosts(posts.filter((post) => post.id !== postId));
      showNotification(t.delete);
    }
  };

  // Edit post
  const handleEditPost = (postId: string) => {
    const post = posts.find((p) => p.id === postId);
    if (post) {
      setEditingPostId(postId);
      setEditingContent(post.content);
      setShowMenuForPost('');
    }
  };

  const handleUpdatePost = () => {
    const updatedPosts = posts.map((post) => {
      if (post.id === editingPostId) {
        return { ...post, content: editingContent, isEdited: true };
      }
      return post;
    });
    savePosts(updatedPosts);
    setEditingPostId('');
    setEditingContent('');
    showNotification(t.update);
  };

  // Report post
  const handleReportPost = () => {
    if (!reportReason) return;

    const reports = JSON.parse(localStorage.getItem('healmate_post_reports') || '[]');
    const newReport = {
      postId: reportingPostId,
      reporterId: currentUserId,
      reason: reportReason,
      description: reportDescription,
      timestamp: new Date().toISOString(),
    };

    reports.push(newReport);
    localStorage.setItem('healmate_post_reports', JSON.stringify(reports));

    // Update report count
    const updatedPosts = posts.map((post) => {
      if (post.id === reportingPostId) {
        return { ...post, reports: (post.reports || 0) + 1 };
      }
      return post;
    });
    savePosts(updatedPosts);

    setShowReportModal(false);
    setReportingPostId('');
    setReportReason('');
    setReportDescription('');
    showNotification(t.reportSuccess);
  };

  // Share post
  const handleSharePost = (postId: string) => {
    const post = posts.find(p => p.id === postId);
    if (post) {
      setSharingPost(post);
      setShareModalOpen(true);
      
      // Increment share count
      const updatedPosts = posts.map((p) => {
        if (p.id === postId) {
          return { ...p, shares: p.shares + 1 };
        }
        return p;
      });
      savePosts(updatedPosts);
    }
  };

  // Add image URL
  const handleAddImage = () => {
    const imageUrl = prompt(
      language === 'ps' ? 'د عکس URL ولیکئ:' : language === 'fa' ? 'URL تصویر را وارد کنید:' : 'Enter image URL:'
    );
    if (imageUrl) {
      setNewPostImages([...newPostImages, imageUrl]);
    }
  };

  // Add video URL
  const handleAddVideo = () => {
    const videoUrl = prompt(
      language === 'ps' ? 'د ویدیو URL ولیکئ:' : language === 'fa' ? 'URL ویدیو را وارد کنید:' : 'Enter video URL:'
    );
    if (videoUrl) {
      setNewPostVideos([...newPostVideos, videoUrl]);
    }
  };

  // Show notification
  const showNotification = (msg: string) => {
    setNotification(msg);
    setTimeout(() => setNotification(''), 3000);
  };

  // Format timestamp
  const formatTimestamp = (timestamp: string) => {
    const now = new Date();
    const postTime = new Date(timestamp);
    const diffMs = now.getTime() - postTime.getTime();
    const diffMins = Math.floor(diffMs / 60000);
    const diffHours = Math.floor(diffMs / 3600000);
    const diffDays = Math.floor(diffMs / 86400000);

    if (diffMins < 1) return t.justNow;
    if (diffMins < 60) return `${diffMins} ${t.minutesAgo}`;
    if (diffHours < 24) return `${diffHours} ${t.hoursAgo}`;
    return `${diffDays} ${t.daysAgo}`;
  };

  // Get likes text
  const getLikesText = (likes: string[]) => {
    if (likes.length === 0) return '';
    
    const hasCurrentUserLiked = likes.includes(currentUserId);
    const otherLikesCount = hasCurrentUserLiked ? likes.length - 1 : likes.length;

    if (hasCurrentUserLiked && likes.length === 1) {
      return t.you;
    } else if (hasCurrentUserLiked && likes.length === 2) {
      return `${t.you} ${t.and} 1 ${t.others}`;
    } else if (hasCurrentUserLiked) {
      return `${t.you} ${t.and} ${otherLikesCount} ${t.others}`;
    } else if (likes.length === 1) {
      return '1 person';
    } else {
      return `${likes.length} people`;
    }
  };

  // Check if user is post owner
  const isPostOwner = (post: Post) => post.userId === currentUserId;

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-purple-50 to-pink-50 pb-28 md:pb-8">
      {/* Notification */}
      <AnimatePresence>
        {notification && (
          <motion.div
            initial={{ opacity: 0, y: -50 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -50 }}
            className="fixed top-20 left-1/2 -translate-x-1/2 z-50 bg-green-500 text-white px-6 py-3 rounded-2xl shadow-xl"
          >
            <div className="flex items-center gap-2">
              <Check className="w-5 h-5" />
              <span>{notification}</span>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <div className="container mx-auto px-4 py-6 max-w-2xl">
        {/* Create Post Card */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white/90 backdrop-blur-xl rounded-3xl p-6 shadow-xl mb-6 border border-white/50"
        >
          <div className="flex items-center gap-3 mb-4">
            <div className="w-12 h-12 rounded-full overflow-hidden border-2 border-purple-200">
              <ImageWithFallback
                src={currentUserImage}
                alt={currentUserName}
                className="w-full h-full object-cover"
              />
            </div>
            <button
              onClick={() => setShowCreatePost(true)}
              className="flex-1 bg-gray-100 hover:bg-gray-200 rounded-full px-4 py-3 text-left text-gray-600 transition-colors"
            >
              {t.whatsOnMind}
            </button>
          </div>

          <div className="grid grid-cols-3 gap-2">
            <Button
              variant="ghost"
              onClick={() => setShowCreatePost(true)}
              className="flex items-center justify-center gap-2 hover:bg-purple-50"
            >
              <ImageIcon className="w-5 h-5 text-purple-600" />
              <span className="text-sm">{t.addPhoto}</span>
            </Button>
            <Button
              variant="ghost"
              onClick={() => setShowCreatePost(true)}
              className="flex items-center justify-center gap-2 hover:bg-blue-50"
            >
              <Camera className="w-5 h-5 text-blue-600" />
              <span className="text-sm">{t.createPost}</span>
            </Button>
            <Button
              variant="ghost"
              onClick={() => setShowCreatePost(true)}
              className="flex items-center justify-center gap-2 hover:bg-green-50"
            >
              <Globe className="w-5 h-5 text-green-600" />
              <span className="text-sm">{t.share}</span>
            </Button>
          </div>
        </motion.div>

        {/* Posts Feed */}
        <AnimatePresence mode="popLayout">
          {posts.length === 0 ? (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="bg-white/90 backdrop-blur-xl rounded-3xl p-12 text-center shadow-xl border border-white/50"
            >
              <MessageCircle className="w-16 h-16 text-gray-400 mx-auto mb-4" />
              <h3 className="text-xl mb-2 text-gray-700">{t.noPostsYet}</h3>
              <p className="text-gray-600 mb-6">{t.startSharing}</p>
              <Button onClick={() => setShowCreatePost(true)} className="bg-gradient-to-r from-purple-500 to-pink-600">
                <Camera className="w-4 h-4 mr-2" />
                {t.createPost}
              </Button>
            </motion.div>
          ) : (
            posts.map((post) => (
              <motion.div
                key={post.id}
                layout
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                className="bg-white/90 backdrop-blur-xl rounded-3xl p-6 shadow-xl mb-6 border border-white/50"
              >
                {/* Post Header */}
                <div className="flex items-start justify-between mb-4">
                  <div 
                    className="flex items-center gap-3 flex-1 cursor-pointer"
                    onClick={() => onNavigateToProfile?.(post.userId)}
                  >
                    <div className="relative">
                      <div className="w-12 h-12 rounded-full overflow-hidden border-2 border-purple-200">
                        <ImageWithFallback
                          src={post.userImage}
                          alt={post.userName}
                          className="w-full h-full object-cover"
                        />
                      </div>
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center gap-2">
                        <h4 className="font-bold">{post.userName}</h4>
                        {isPostOwner(post) && (
                          <span className="bg-gradient-to-r from-blue-500 to-purple-600 text-white px-2 py-0.5 rounded-full text-xs flex items-center gap-1">
                            <Shield className="w-3 h-3" />
                            {t.owner}
                          </span>
                        )}
                        {isAdmin && post.userId === 'ibrahimkhaksar.it@gmail.com' && (
                          <span className="bg-gradient-to-r from-red-500 to-pink-600 text-white px-2 py-0.5 rounded-full text-xs flex items-center gap-1">
                            <Award className="w-3 h-3" />\n                            {t.admin}
                          </span>
                        )}
                      </div>
                      <div className="flex items-center gap-2 text-xs text-gray-600">
                        <span>{formatTimestamp(post.timestamp)}</span>
                        {post.isEdited && (
                          <>
                            <span>•</span>
                            <span>{t.edited}</span>
                          </>
                        )}
                        <span>•</span>
                        <div className="flex items-center gap-1">
                          {post.privacy === 'public' && <Globe className="w-3 h-3" />}
                          {post.privacy === 'friends' && <UsersIcon className="w-3 h-3" />}
                          {post.privacy === 'private' && <Lock className="w-3 h-3" />}
                          <span>{t[post.privacy]}</span>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Post Menu */}
                  <div className="relative">
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => setShowMenuForPost(showMenuForPost === post.id ? '' : post.id)}
                    >
                      <MoreVertical className="w-5 h-5" />
                    </Button>

                    <AnimatePresence>
                      {showMenuForPost === post.id && (
                        <motion.div
                          initial={{ opacity: 0, scale: 0.9 }}
                          animate={{ opacity: 1, scale: 1 }}
                          exit={{ opacity: 0, scale: 0.9 }}
                          className="absolute right-0 mt-2 w-48 bg-white rounded-2xl shadow-2xl border border-gray-200 py-2 z-10"
                        >
                          {isPostOwner(post) && (
                            <>
                              <button
                                onClick={() => handleEditPost(post.id)}
                                className="w-full px-4 py-2 text-left hover:bg-gray-100 flex items-center gap-2 text-sm"
                              >
                                <Edit2 className="w-4 h-4" />
                                {t.edit}
                              </button>
                              <button
                                onClick={() => handleDeletePost(post.id)}
                                className="w-full px-4 py-2 text-left hover:bg-red-50 text-red-600 flex items-center gap-2 text-sm"
                              >
                                <Trash2 className="w-4 h-4" />
                                {t.delete}
                              </button>
                            </>
                          )}
                          {!isPostOwner(post) && (
                            <button
                              onClick={() => {
                                setReportingPostId(post.id);
                                setShowReportModal(true);
                                setShowMenuForPost('');
                              }}
                              className="w-full px-4 py-2 text-left hover:bg-red-50 text-red-600 flex items-center gap-2 text-sm"
                            >
                              <Flag className="w-4 h-4" />
                              {t.report}
                            </button>
                          )}
                          <button
                            onClick={() => {
                              copyToClipboard(window.location.href + `?post=${post.id}`);
                              showNotification(t.linkCopied);
                              setShowMenuForPost('');
                            }}
                            className="w-full px-4 py-2 text-left hover:bg-gray-100 flex items-center gap-2 text-sm"
                          >
                            <Share2 className="w-4 h-4" />
                            {t.copyLink}
                          </button>
                        </motion.div>
                      )}
                    </AnimatePresence>
                  </div>
                </div>

                {/* Post Content */}
                {editingPostId === post.id ? (
                  <div className="mb-4">
                    <Textarea
                      value={editingContent}
                      onChange={(e) => setEditingContent(e.target.value)}
                      rows={4}
                      className="mb-2"
                      dir={language === 'en' ? 'ltr' : 'rtl'}
                    />
                    <div className="flex gap-2">
                      <Button onClick={handleUpdatePost} size="sm">
                        <Check className="w-4 h-4 mr-2" />
                        {t.update}
                      </Button>
                      <Button onClick={() => setEditingPostId('')} variant="outline" size="sm">
                        <X className="w-4 h-4 mr-2" />
                        {t.cancel}
                      </Button>
                    </div>
                  </div>
                ) : (
                  <div className="mb-4">
                    <p className="whitespace-pre-wrap" dir={language === 'en' ? 'ltr' : 'rtl'}>
                      {expandedPosts[post.id] || post.content.length <= 200
                        ? post.content
                        : `${post.content.substring(0, 200)}...`}
                    </p>
                    {post.content.length > 200 && (
                      <button
                        onClick={() =>
                          setExpandedPosts({ ...expandedPosts, [post.id]: !expandedPosts[post.id] })
                        }
                        className="text-purple-600 hover:text-purple-700 text-sm mt-1"
                      >
                        {expandedPosts[post.id] ? t.seeLess : t.seeMore}
                      </button>
                    )}
                  </div>
                )}

                {/* Post Images */}
                {post.images.length > 0 && (
                  <div className={`mb-4 grid gap-2 ${
                    post.images.length === 1 ? 'grid-cols-1' :
                    post.images.length === 2 ? 'grid-cols-2' :
                    post.images.length === 3 ? 'grid-cols-3' :
                    'grid-cols-2'
                  }`}>
                    {post.images.map((image, idx) => (
                      <div
                        key={idx}
                        className={`rounded-2xl overflow-hidden ${
                          post.images.length === 3 && idx === 0 ? 'col-span-3' : ''
                        }`}
                      >
                        <ImageWithFallback
                          src={image}
                          alt={`Post image ${idx + 1}`}
                          className="w-full h-full object-cover"
                        />
                      </div>
                    ))}
                  </div>
                )}

                {/* Post Videos */}
                {post.videos && post.videos.length > 0 && (
                  <div className="mb-4 grid gap-2 grid-cols-1">
                    {post.videos.map((video, idx) => (
                      <div key={idx} className="rounded-2xl overflow-hidden">
                        <video
                          src={video}
                          alt={`Post video ${idx + 1}`}
                          className="w-full h-full object-cover"
                          controls
                        />
                      </div>
                    ))}
                  </div>
                )}

                {/* Post Stats */}
                <div className="flex items-center justify-between py-3 border-t border-b border-gray-200 mb-3">
                  <div className="flex items-center gap-4 text-sm text-gray-600">
                    {post.likes.length > 0 && (
                      <div className="flex items-center gap-1">
                        <div className="flex -space-x-1">
                          <div className="w-5 h-5 bg-gradient-to-r from-red-500 to-pink-600 rounded-full flex items-center justify-center">
                            <Heart className="w-3 h-3 text-white fill-white" />
                          </div>
                        </div>
                        <span>{getLikesText(post.likes)}</span>
                      </div>
                    )}
                  </div>
                  <div className="flex items-center gap-3 text-sm text-gray-600">
                    {post.comments.length > 0 && (
                      <span>{post.comments.length} {t.comments}</span>
                    )}
                    {post.shares > 0 && <span>{post.shares} {t.shares}</span>}
                  </div>
                </div>

                {/* Post Actions */}
                <div className="grid grid-cols-3 gap-2 mb-4">
                  <Button
                    variant="ghost"
                    onClick={() => handleLikePost(post.id)}
                    className={`flex items-center justify-center gap-2 ${
                      post.likes.includes(currentUserId)
                        ? 'text-red-600 hover:text-red-700 hover:bg-red-50'
                        : 'hover:bg-gray-100'
                    }`}
                  >
                    <Heart
                      className={`w-5 h-5 ${post.likes.includes(currentUserId) ? 'fill-red-600' : ''}`}
                    />
                    <span className="text-sm">{t.like}</span>
                  </Button>
                  <Button
                    variant="ghost"
                    onClick={() => setShowComments({ ...showComments, [post.id]: !showComments[post.id] })}
                    className="flex items-center justify-center gap-2 hover:bg-gray-100"
                  >
                    <MessageCircle className="w-5 h-5" />
                    <span className="text-sm">{t.comment}</span>
                  </Button>
                  <Button
                    variant="ghost"
                    onClick={() => handleSharePost(post.id)}
                    className="flex items-center justify-center gap-2 hover:bg-gray-100"
                  >
                    <Share2 className="w-5 h-5" />
                    <span className="text-sm">{t.share}</span>
                  </Button>
                </div>

                {/* Comments Section */}
                <AnimatePresence>
                  {showComments[post.id] && (
                    <motion.div
                      initial={{ height: 0, opacity: 0 }}
                      animate={{ height: 'auto', opacity: 1 }}
                      exit={{ height: 0, opacity: 0 }}
                      className="space-y-3 pt-3 border-t border-gray-200"
                    >
                      {/* Comments List */}
                      {post.comments.map((comment) => (
                        <div key={comment.id} className="flex gap-2">
                          <div className="w-8 h-8 rounded-full overflow-hidden flex-shrink-0">
                            <ImageWithFallback
                              src={comment.userImage}
                              alt={comment.userName}
                              className="w-full h-full object-cover"
                            />
                          </div>
                          <div className="flex-1">
                            <div className="bg-gray-100 rounded-2xl px-4 py-2">
                              <div className="flex items-center gap-2 mb-1">
                                <span className="font-bold text-sm">{comment.userName}</span>
                                {comment.userId === currentUserId && (
                                  <span className="bg-blue-500 text-white px-2 py-0.5 rounded-full text-xs">
                                    {t.you}
                                  </span>
                                )}
                              </div>
                              <p className="text-sm" dir={language === 'en' ? 'ltr' : 'rtl'}>
                                {comment.content}
                              </p>
                            </div>
                            <div className="flex items-center gap-3 mt-1 px-2 text-xs text-gray-600">
                              <button
                                onClick={() => handleLikeComment(post.id, comment.id)}
                                className={`hover:text-red-600 ${
                                  comment.likes.includes(currentUserId) ? 'text-red-600 font-bold' : ''
                                }`}
                              >
                                {t.commentLike}
                              </button>
                              <span>{formatTimestamp(comment.timestamp)}</span>
                              {comment.likes.length > 0 && (
                                <span className="flex items-center gap-1">
                                  <Heart className="w-3 h-3 text-red-600 fill-red-600" />
                                  {comment.likes.length}
                                </span>
                              )}
                            </div>
                          </div>
                        </div>
                      ))}

                      {/* Add Comment */}
                      <div className="flex gap-2 pt-2">
                        <div className="w-8 h-8 rounded-full overflow-hidden flex-shrink-0">
                          <ImageWithFallback
                            src={currentUserImage}
                            alt={currentUserName}
                            className="w-full h-full object-cover"
                          />
                        </div>
                        <div className="flex-1 flex gap-2">
                          <Input
                            value={commentTexts[post.id] || ''}
                            onChange={(e) =>
                              setCommentTexts({ ...commentTexts, [post.id]: e.target.value })
                            }
                            placeholder={t.writeComment}
                            onKeyDown={(e) => {
                              if (e.key === 'Enter' && !e.shiftKey) {
                                e.preventDefault();
                                handleAddComment(post.id);
                              }
                            }}
                            dir={language === 'en' ? 'ltr' : 'rtl'}
                            className="flex-1"
                          />
                          <Button
                            onClick={() => handleAddComment(post.id)}
                            size="icon"
                            className="bg-gradient-to-r from-purple-500 to-pink-600"
                          >
                            <Send className="w-4 h-4" />
                          </Button>
                        </div>
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </motion.div>
            ))
          )}
        </AnimatePresence>
      </div>

      {/* Create Post Modal */}
      <AnimatePresence>
        {showCreatePost && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4"
            onClick={() => setShowCreatePost(false)}
          >
            <motion.div
              initial={{ scale: 0.9 }}
              animate={{ scale: 1 }}
              exit={{ scale: 0.9 }}
              onClick={(e) => e.stopPropagation()}
              className="bg-white rounded-3xl p-6 max-w-lg w-full max-h-[90vh] overflow-y-auto"
            >
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-xl font-bold">{t.createPost}</h3>
                <Button variant="ghost" size="icon" onClick={() => setShowCreatePost(false)}>
                  <X className="w-5 h-5" />
                </Button>
              </div>

              <div className="flex items-center gap-3 mb-4">
                <div className="w-12 h-12 rounded-full overflow-hidden">
                  <ImageWithFallback
                    src={currentUserImage}
                    alt={currentUserName}
                    className="w-full h-full object-cover"
                  />
                </div>
                <div>
                  <h4 className="font-bold">{currentUserName}</h4>
                  <select
                    value={postPrivacy}
                    onChange={(e) => setPostPrivacy(e.target.value as any)}
                    className="text-xs border border-gray-300 rounded-lg px-2 py-1"
                  >
                    <option value="public">{t.public}</option>
                    <option value="friends">{t.friends}</option>
                    <option value="private">{t.private}</option>
                  </select>
                </div>
              </div>

              <Textarea
                value={newPostContent}
                onChange={(e) => setNewPostContent(e.target.value)}
                placeholder={t.whatsOnMind}
                rows={6}
                className="mb-4"
                dir={language === 'en' ? 'ltr' : 'rtl'}
              />

              {/* MediaUploader Component */}
              <MediaUploader
                language={language}
                images={newPostImages}
                videos={newPostVideos}
                onImagesChange={setNewPostImages}
                onVideosChange={setNewPostVideos}
              />

              <div className="flex gap-2 mt-4">
                <Button
                  onClick={handleCreatePost}
                  disabled={!newPostContent.trim() && newPostImages.length === 0 && newPostVideos.length === 0}
                  className="flex-1 bg-gradient-to-r from-purple-500 to-pink-600"
                >
                  {t.post}
                </Button>
                <Button onClick={() => setShowCreatePost(false)} variant="outline">
                  {t.cancel}
                </Button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Report Modal */}
      <AnimatePresence>
        {showReportModal && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4"
            onClick={() => setShowReportModal(false)}
          >
            <motion.div
              initial={{ scale: 0.9 }}
              animate={{ scale: 1 }}
              exit={{ scale: 0.9 }}
              onClick={(e) => e.stopPropagation()}
              className="bg-white rounded-3xl p-6 max-w-md w-full"
            >
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-xl font-bold">{t.reportPost}</h3>
                <Button variant="ghost" size="icon" onClick={() => setShowReportModal(false)}>
                  <X className="w-5 h-5" />
                </Button>
              </div>

              <div className="space-y-4">
                <div>
                  <Label>{t.reportReason}</Label>
                  <select
                    value={reportReason}
                    onChange={(e) => setReportReason(e.target.value)}
                    className="w-full mt-2 border border-gray-300 rounded-lg px-3 py-2"
                  >
                    <option value="">
                      {language === 'ps' ? 'انتخاب کړئ' : language === 'fa' ? 'انتخاب کنید' : 'Select'}
                    </option>
                    {Object.entries(t.reportReasons).map(([key, value]) => (
                      <option key={key} value={key}>
                        {value}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <Label>{t.reportDescription}</Label>
                  <Textarea
                    value={reportDescription}
                    onChange={(e) => setReportDescription(e.target.value)}
                    placeholder={
                      language === 'ps'
                        ? 'تفصیل ولیکئ...'
                        : language === 'fa'
                        ? 'توضیحات بنویسید...'
                        : 'Write description...'
                    }
                    rows={4}
                    className="mt-2"
                    dir={language === 'en' ? 'ltr' : 'rtl'}
                  />
                </div>

                <Button
                  onClick={handleReportPost}
                  disabled={!reportReason}
                  className="w-full bg-gradient-to-r from-red-500 to-pink-600"
                >
                  <Flag className="w-4 h-4 mr-2" />
                  {t.reportSubmit}
                </Button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Share Modal */}
      <ShareModal
        isOpen={shareModalOpen}
        onClose={() => {
          setShareModalOpen(false);
          setSharingPost(null);
        }}
        language={language}
        shareContent={{
          title: sharingPost ? `${sharingPost.userName}: ${sharingPost.content.slice(0, 100)}...` : 'HealMate Post',
          description: sharingPost?.content || '',
          url: window.location.href
        }}
      />
    </div>
  );
}