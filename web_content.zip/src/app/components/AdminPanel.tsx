import React, { useState, useEffect } from 'react';
import { 
  ArrowLeft, BarChart3, Users, Stethoscope, FileText, DollarSign, 
  Settings as SettingsIcon, Crown, Pill, Hash, Shield, Flag,
  TrendingUp, UserCheck, CheckCircle, Clock, AlertTriangle, Activity,
  Search, Filter, RefreshCw, Download, Eye, UserX, Trash2, Plus,
  Check, Mail, Phone, Calendar, Heart, MessageCircle, Share2, X, Wallet
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Textarea } from './ui/textarea';
import { Switch } from './ui/switch';
import { copyToClipboard } from '../utils/clipboard';
import { AdminPremiumManagement } from './AdminPremiumManagement';
import { AdMobIDEditor } from './AdMobIDEditor';
import { AdminAdMobEditor } from './AdminAdMobEditor';
import { HealthCategoriesManagement } from './HealthCategoriesManagement';
import { RegisteredUsersPanel } from './RegisteredUsersPanel';
import { AdminUsersManagement } from './AdminUsersManagement';
import { healthCategories, getCategoriesByType, getPopularCategories } from '../data/healthCategories';
import { ImageWithFallback } from './figma/ImageWithFallback';
import { PaymentProcessor } from '../utils/PaymentProcessor';

interface AdminPanelProps {
  language: 'ps' | 'fa' | 'en';
  onBack: () => void;
}

type Tab = 'dashboard' | 'users' | 'doctors' | 'posts' | 'categories' | 'settings' | 'premium' | 'premium-users' | 'premium-content' | 'medicines' | 'admob' | 'security' | 'payments';

interface User {
  id: string;
  name: string;
  email: string;
  phone: string;
  verified: boolean;
  posts: number;
  followers: number;
  following: number;
  joinedDate: string;
  status: 'active' | 'suspended' | 'banned';
  profileImage: string;
}

interface Doctor {
  id: number;
  name: { ps: string; fa: string; en: string };
  specialty: { ps: string; fa: string; en: string };
  category: string;
  experience: number;
  rating: number;
  verified: boolean;
  available: boolean;
  phone: string;
  patients: number;
  consultationFee: number;
}

interface Post {
  id: string;
  userId: string;
  userName: string;
  content: string;
  images: string[];
  reactions: any[];
  comments: any[];
  timestamp: string;
  reported: boolean;
  reportCount: number;
}

export function AdminPanel({ language, onBack }: AdminPanelProps) {
  const [activeTab, setActiveTab] = useState<Tab>('dashboard');
  const [users, setUsers] = useState<User[]>([]);
  const [doctors, setDoctors] = useState<Doctor[]>([]);
  const [posts, setPosts] = useState<Post[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedUser, setSelectedUser] = useState<User | null>(null);
  const [selectedDoctor, setSelectedDoctor] = useState<Doctor | null>(null);
  const [selectedPost, setSelectedPost] = useState<Post | null>(null);
  const [showModal, setShowModal] = useState(false);
  const [stats, setStats] = useState({
    totalUsers: 0,
    totalDoctors: 0,
    totalPosts: 0,
    totalReports: 0,
    activeUsers: 0,
    verifiedDoctors: 0,
    todayPosts: 0,
    pendingReports: 0
  });

  // AdMob Configuration State
  const [admobConfig, setAdmobConfig] = useState({
    appId: 'ca-app-pub-3940256099942544~1458002511',
    bannerAdUnit: 'ca-app-pub-3940256099942544/6300978111',
    interstitialAdUnit: 'ca-app-pub-3940256099942544/1033173712',
    rewardedAdUnit: 'ca-app-pub-3940256099942544/5224354917',
    nativeAdUnit: 'ca-app-pub-3940256099942544/2247696110',
    testDeviceId: 'TEST_DEVICE_ID'
  });
  const [editingAdmob, setEditingAdmob] = useState<string | null>(null);
  const [tempAdmobValues, setTempAdmobValues] = useState({
    appId: '',
    bannerAdUnit: '',
    interstitialAdUnit: '',
    rewardedAdUnit: '',
    nativeAdUnit: '',
    testDeviceId: ''
  });

  const t = {
    ps: {
      title: 'د ادارې پینل',
      subtitle: 'د اپلیکیشن بشپړ مدیریت',
      dashboard: 'ډشبورډ',
      users: 'کاروونکي',
      doctors: 'دوکتوران',
      posts: 'پوستونه',
      categories: 'کټګورۍ',
      settings: 'تنظیمات',
      search: 'لټون...',
      totalUsers: 'ټول کاروونکي',
      totalDoctors: 'ټول دوکتوران',
      totalPosts: 'ټول پوستونه',
      totalReports: 'ټول ریپورټونه',
      activeUsers: 'فعال کاروونکي',
      verifiedDoctors: 'تایید شوي دوکتوران',
      todayPosts: 'نن پوستونه',
      pendingReports: 'په انتظار ریپورټونه',
      userManagement: 'د کاروونکو مدیریت',
      doctorManagement: 'د دوکتورانو مدیریت',
      postManagement: 'د پوستونو مدیریت',
      categoryManagement: 'د کټګورۍ مدیریت',
      appSettings: 'د اپلیکیشن تنظیمات',
      name: 'نوم',
      email: 'برېښنالیک',
      phone: 'نمبر',
      status: 'حالت',
      verified: 'تایید شوی',
      actions: 'کړنې',
      view: 'کتل',
      edit: 'سمون',
      delete: 'حذف',
      verify: 'تایید کول',
      unverify: 'تایید لرې کول',
      suspend: 'معطل کول',
      activate: 'فعال کول',
      ban: 'بند کول',
      addDoctor: 'دوکتور اضافه',
      addCategory: 'کټګوري اضافه',
      specialty: 'تخصص',
      experience: 'تجربه',
      rating: 'ریټنګ',
      available: 'شته',
      unavailable: 'نشته',
      consultationFee: 'د معاینې فیس',
      patients: 'ناروغان',
      reports: 'ریپورټونه',
      viewReports: 'ریپورټونه وګورئ',
      approvePost: 'پوست منظور',
      deletePost: 'پوست حذف',
      postContent: 'د پوست مینځپانګه',
      postedBy: 'د ... لخوا',
      postedAt: 'وخت',
      reactions: 'غبرګونونه',
      comments: 'تبصرې',
      shares: 'شریکونه',
      reported: 'ریپورټ شوی',
      notReported: 'ریپورټ نشوی',
      reportReason: 'د ریپورټ دلیل',
      save: 'خوندي',
      cancel: 'لغوه',
      close: 'تړل',
      confirmDelete: 'آیا تاسو ډاډه یاست؟',
      deleteSuccess: 'په بریالیتوب سره حذف شو',
      updateSuccess: 'په بریالیتوب سره تازه شو',
      error: 'تېروتنه رامینځته شوه',
      noData: 'هیڅ معلومات نشته',
      filter: 'فلټر',
      export: 'ایکسپورټ',
      import: 'امپورټ',
      refresh: 'تازه کول',
      all: 'ټول',
      active: 'فعال',
      suspended: 'معطل',
      banned: 'بند شوی',
      showingResults: 'نتیجې',
      of: 'د',
      adminSettings: 'د ادارې تنظیمات',
      appName: 'د اپلیکیشن نوم',
      appVersion: 'نسخه',
      maintenanceMode: 'د ساتنې حالت',
      allowRegistration: 'نوې راجستریشن',
      requireVerification: 'تایید اړین',
      maxPostsPerDay: 'په ورځ کې ډیر پوستونه',
      enableComments: 'تبصرې فعالې',
      enableReactions: 'غبرګونونه فعال',
      contactEmail: 'د اړیکې برېښنالیک',
      contactPhone: 'د اړیکې نمبر',
      socialLinks: 'ټولنیز لینکونه',
      facebook: 'فیسبوک',
      twitter: 'ټویټر',
      instagram: 'انسټاګرام',
      youtube: 'یوټیوب',
      premium: 'پریمیم',
      premiumManagement: 'د Premium مدیریت',
      premiumUsers: 'Premium کاروونکي',
      premiumContent: 'Premium مینځپانګه',
      medicines: 'درمل',
      admob: 'AdMob',
      admobManagement: 'د AdMob مدیریت',
      adUnits: 'د اعلان واحدونه',
      bannerAd: 'بینر اعلان',
      interstitialAd: 'Interstitial اعلان',
      rewardedAd: 'انعام اعلان',
      nativeAd: 'Native اعلان',
      copyAdUnit: 'Ad Unit کاپي کړه',
      testDevice: 'ټېسټ وسیله',
      adConfiguration: 'د اعلان تنظیمات',
      appId: 'App ID'
    },
    fa: {
      title: 'پنل مدیریت',
      subtitle: 'مدیریت کامل اپلیکیشن',
      dashboard: 'داشبورد',
      users: 'کاربران',
      doctors: 'دکتران',
      posts: 'پست‌ها',
      categories: 'دسته‌بندی‌ها',
      settings: 'تنظیمات',
      search: 'جستجو...',
      totalUsers: 'کل کاربران',
      totalDoctors: 'کل دکتران',
      totalPosts: 'کل پست‌ها',
      totalReports: 'کل گزارش‌ها',
      activeUsers: 'کاربران فعال',
      verifiedDoctors: 'دکتران تایید شده',
      todayPosts: 'پست‌های امروز',
      pendingReports: 'گزارش‌های در انتظار',
      userManagement: 'مدیریت کاربران',
      doctorManagement: 'مدیریت دکتران',
      postManagement: 'مدیریت پست‌ها',
      categoryManagement: 'مدیریت دسته‌بندی‌ها',
      appSettings: 'تنظیمات اپلیکیشن',
      name: 'نام',
      email: 'ایمیل',
      phone: 'شماره',
      status: 'وضعیت',
      verified: 'تایید شده',
      actions: 'عملیات',
      view: 'مشاهده',
      edit: 'ویرایش',
      delete: 'حذف',
      verify: 'تایید کرد',
      unverify: 'لغو تایید',
      suspend: 'تعلیق',
      activate: 'فعال کردن',
      ban: 'مسدود کردن',
      addDoctor: 'افزودن دکتر',
      addCategory: 'افزودن دسته',
      specialty: 'تخصص',
      experience: 'تجربه',
      rating: 'امتیاز',
      available: 'در دسترس',
      unavailable: 'غیر فعال',
      consultationFee: 'هزینه معاینه',
      patients: 'بیماران',
      reports: 'گزارش‌ها',
      viewReports: 'مشاهده گزارش‌ها',
      approvePost: 'تایید پست',
      deletePost: 'حذف پست',
      postContent: 'محتوای پست',
      postedBy: 'توسط',
      postedAt: 'زمان',
      reactions: 'واکنش‌ها',
      comments: 'نظرات',
      shares: 'اشتراک‌ها',
      reported: 'گزارش شده',
      notReported: 'گزارش نشده',
      reportReason: 'دلیل گزارش',
      save: 'ذخیره',
      cancel: 'لغو',
      close: 'بستن',
      confirmDelete: 'آیا مطمئن هستید؟',
      deleteSuccess: 'با موفقیت حذف شد',
      updateSuccess: 'با موفقیت بروز شد',
      error: 'خطا رخ داد',
      noData: 'داده‌ای وجود ندارد',
      filter: 'فیلتر',
      export: 'خروجی',
      import: 'ورودی',
      refresh: 'بروزرسانی',
      all: 'همه',
      active: 'فعال',
      suspended: 'تعلیق',
      banned: 'مسدود',
      showingResults: 'نتایج',
      of: 'از',
      adminSettings: 'تنظیمات مدیریت',
      appName: 'نام اپلیکیشن',
      appVersion: 'نسخه',
      maintenanceMode: 'حالت تعمیر',
      allowRegistration: 'ثبت‌نام جدید',
      requireVerification: 'نیاز به تایید',
      maxPostsPerDay: 'حداکثر پست در روز',
      enableComments: 'فعال‌سازی نظرات',
      enableReactions: 'فعال‌سازی واکنش‌ها',
      contactEmail: 'ایمیل تماس',
      contactPhone: 'شماره تماس',
      socialLinks: 'لینک‌های اجتماعی',
      facebook: 'فیسبوک',
      twitter: 'توییتر',
      instagram: 'اینستاگرام',
      youtube: 'یوتیوب',
      premium: 'پریمیم',
      premiumManagement: 'د Premium مدیرت',
      premiumUsers: 'Premium کاربران',
      premiumContent: 'Premium محتوا',
      medicines: 'داروها',
      admob: 'AdMob',
      admobManagement: 'د AdMob مدیریت',
      adUnits: 'د اعلان واحدونه',
      bannerAd: 'بینر اعلان',
      interstitialAd: 'Interstitial اعلان',
      rewardedAd: 'انعام اعلان',
      nativeAd: 'Native اعلان',
      copyAdUnit: 'Ad Unit کاپي کړه',
      testDevice: 'ټېسټ وسیله',
      adConfiguration: 'د اعلان تنظیمات',
      appId: 'App ID'
    },
    en: {
      title: 'Admin Panel',
      subtitle: 'Complete Application Management',
      dashboard: 'Dashboard',
      users: 'Users',
      doctors: 'Doctors',
      posts: 'Posts',
      categories: 'Categories',
      settings: 'Settings',
      search: 'Search...',
      totalUsers: 'Total Users',
      totalDoctors: 'Total Doctors',
      totalPosts: 'Total Posts',
      totalReports: 'Total Reports',
      activeUsers: 'Active Users',
      verifiedDoctors: 'Verified Doctors',
      todayPosts: 'Today Posts',
      pendingReports: 'Pending Reports',
      userManagement: 'User Management',
      doctorManagement: 'Doctor Management',
      postManagement: 'Post Management',
      categoryManagement: 'Category Management',
      appSettings: 'App Settings',
      name: 'Name',
      email: 'Email',
      phone: 'Phone',
      status: 'Status',
      verified: 'Verified',
      actions: 'Actions',
      view: 'View',
      edit: 'Edit',
      delete: 'Delete',
      verify: 'Verify',
      unverify: 'Unverify',
      suspend: 'Suspend',
      activate: 'Activate',
      ban: 'Ban',
      addDoctor: 'Add Doctor',
      addCategory: 'Add Category',
      specialty: 'Specialty',
      experience: 'Experience',
      rating: 'Rating',
      available: 'Available',
      unavailable: 'Unavailable',
      consultationFee: 'Consultation Fee',
      patients: 'Patients',
      reports: 'Reports',
      viewReports: 'View Reports',
      approvePost: 'Approve Post',
      deletePost: 'Delete Post',
      postContent: 'Post Content',
      postedBy: 'Posted By',
      postedAt: 'Posted At',
      reactions: 'Reactions',
      comments: 'Comments',
      shares: 'Shares',
      reported: 'Reported',
      notReported: 'Not Reported',
      reportReason: 'Report Reason',
      save: 'Save',
      cancel: 'Cancel',
      close: 'Close',
      confirmDelete: 'Are you sure?',
      deleteSuccess: 'Deleted successfully',
      updateSuccess: 'Updated successfully',
      error: 'An error occurred',
      noData: 'No data available',
      filter: 'Filter',
      export: 'Export',
      import: 'Import',
      refresh: 'Refresh',
      all: 'All',
      active: 'Active',
      suspended: 'Suspended',
      banned: 'Banned',
      showingResults: 'Showing',
      of: 'of',
      adminSettings: 'Admin Settings',
      appName: 'App Name',
      appVersion: 'Version',
      maintenanceMode: 'Maintenance Mode',
      allowRegistration: 'Allow Registration',
      requireVerification: 'Require Verification',
      maxPostsPerDay: 'Max Posts Per Day',
      enableComments: 'Enable Comments',
      enableReactions: 'Enable Reactions',
      contactEmail: 'Contact Email',
      contactPhone: 'Contact Phone',
      socialLinks: 'Social Links',
      facebook: 'Facebook',
      twitter: 'Twitter',
      instagram: 'Instagram',
      youtube: 'YouTube',
      premium: 'Premium',
      premiumManagement: 'Premium Management',
      premiumUsers: 'Premium Users',
      premiumContent: 'Premium Content',
      medicines: 'Medicines',
      admob: 'AdMob',
      admobManagement: 'AdMob Management',
      adUnits: 'Ad Units',
      bannerAd: 'Banner Ad',
      interstitialAd: 'Interstitial Ad',
      rewardedAd: 'Rewarded Ad',
      nativeAd: 'Native Ad',
      copyAdUnit: 'Copy Ad Unit',
      testDevice: 'Test Device',
      adConfiguration: 'Ad Configuration',
      appId: 'App ID'
    }
  };

  const text = t[language];

  useEffect(() => {
    loadData();
    // Load AdMob config from localStorage
    const savedAdmobConfig = localStorage.getItem('healmate_admob_config');
    if (savedAdmobConfig) {
      setAdmobConfig(JSON.parse(savedAdmobConfig));
    }
  }, []);

  const loadData = () => {
    // Load users
    const savedUsers = JSON.parse(localStorage.getItem('healmate_users_data') || '[]');
    setUsers(savedUsers);

    // Load posts
    const savedPosts = JSON.parse(localStorage.getItem('healmate_posts') || '[]');
    const reports = JSON.parse(localStorage.getItem('healmate_post_reports') || '[]');
    
    const postsWithReports = savedPosts.map((post: Post) => {
      const postReports = reports.filter((r: any) => r.postId === post.id);
      return {
        ...post,
        reported: postReports.length > 0,
        reportCount: postReports.length
      };
    });
    setPosts(postsWithReports);

    // Calculate stats
    setStats({
      totalUsers: savedUsers.length,
      totalDoctors: 250,
      totalPosts: savedPosts.length,
      totalReports: reports.length,
      activeUsers: savedUsers.filter((u: User) => u.status === 'active').length,
      verifiedDoctors: 125,
      todayPosts: savedPosts.filter((p: Post) => {
        const postDate = new Date(p.timestamp);
        const today = new Date();
        return postDate.toDateString() === today.toDateString();
      }).length,
      pendingReports: reports.length
    });
  };

  const handleDeleteUser = (userId: string) => {
    if (confirm(text.confirmDelete)) {
      const updatedUsers = users.filter(u => u.id !== userId);
      setUsers(updatedUsers);
      localStorage.setItem('healmate_users_data', JSON.stringify(updatedUsers));
      alert(text.deleteSuccess);
    }
  };

  const handleVerifyUser = (userId: string) => {
    const updatedUsers = users.map(u => 
      u.id === userId ? { ...u, verified: !u.verified } : u
    );
    setUsers(updatedUsers);
    localStorage.setItem('healmate_users_data', JSON.stringify(updatedUsers));
    alert(text.updateSuccess);
  };

  const handleChangeUserStatus = (userId: string, status: 'active' | 'suspended' | 'banned') => {
    const updatedUsers = users.map(u => 
      u.id === userId ? { ...u, status } : u
    );
    setUsers(updatedUsers);
    localStorage.setItem('healmate_users_data', JSON.stringify(updatedUsers));
    alert(text.updateSuccess);
  };

  const handleDeletePost = (postId: string) => {
    if (confirm(text.confirmDelete)) {
      const updatedPosts = posts.filter(p => p.id !== postId);
      setPosts(updatedPosts);
      
      // Update localStorage
      const savedPosts = JSON.parse(localStorage.getItem('healmate_posts') || '[]');
      const filtered = savedPosts.filter((p: Post) => p.id !== postId);
      localStorage.setItem('healmate_posts', JSON.stringify(filtered));
      
      alert(text.deleteSuccess);
      loadData();
    }
  };

  const tabs = [
    { id: 'dashboard' as Tab, icon: BarChart3, label: text.dashboard },
    { id: 'users' as Tab, icon: Users, label: text.users },
    { id: 'doctors' as Tab, icon: Stethoscope, label: text.doctors },
    { id: 'posts' as Tab, icon: FileText, label: text.posts },
    { id: 'premium' as Tab, icon: Crown, label: text.premium },
    { id: 'payments' as Tab, icon: Wallet, label: language === 'ps' ? 'پیسې' : language === 'fa' ? 'پرداخت‌ها' : 'Payments' },
    { id: 'admob' as Tab, icon: DollarSign, label: text.admob },
    { id: 'categories' as Tab, icon: Hash, label: text.categories },
    { id: 'settings' as Tab, icon: SettingsIcon, label: text.settings }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-gray-50 to-zinc-50 pb-28 md:pb-8">
      {/* Header */}
      <div className="sticky top-0 z-40 backdrop-blur-xl bg-white/80 border-b border-gray-200 shadow-lg">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center gap-4">
            <Button variant="ghost" size="icon" onClick={onBack}>
              <ArrowLeft className="w-5 h-5" />
            </Button>
            <div className="flex items-center gap-3">
              <div className="bg-gradient-to-br from-red-500 to-pink-600 p-2.5 rounded-2xl">
                <Shield className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-2xl bg-gradient-to-r from-red-600 to-pink-600 bg-clip-text text-transparent">
                  {text.title}
                </h1>
                <p className="text-sm text-gray-600">{text.subtitle}</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Navigation Tabs */}
      <div className="sticky top-[72px] z-30 bg-white border-b border-gray-200">
        <div className="container mx-auto px-4">
          <div className="flex gap-2 overflow-x-auto pb-2 pt-2 scrollbar-hide">
            {tabs.map(tab => {
              const Icon = tab.icon;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`flex items-center gap-2 px-4 py-2.5 rounded-xl whitespace-nowrap transition-all ${
                    activeTab === tab.id
                      ? 'bg-gradient-to-r from-red-500 to-pink-600 text-white shadow-lg'
                      : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                  }`}
                >
                  <Icon className="w-4 h-4" />
                  <span className="text-sm font-medium">{tab.label}</span>
                </button>
              );
            })}
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-6">
        {/* Dashboard */}
        {activeTab === 'dashboard' && (
          <div className="space-y-6">
            {/* Stats Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              {[
                { icon: Users, label: text.totalUsers, value: stats.totalUsers, color: 'from-blue-500 to-cyan-600', trend: '+12%' },
                { icon: Stethoscope, label: text.totalDoctors, value: stats.totalDoctors, color: 'from-purple-500 to-violet-600', trend: '+8%' },
                { icon: FileText, label: text.totalPosts, value: stats.totalPosts, color: 'from-green-500 to-emerald-600', trend: '+25%' },
                { icon: Flag, label: text.totalReports, value: stats.totalReports, color: 'from-red-500 to-pink-600', trend: '-5%' }
              ].map((stat, index) => {
                const Icon = stat.icon;
                return (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: index * 0.1 }}
                    className="bg-white rounded-2xl p-6 border border-gray-200 shadow-lg hover:shadow-xl transition-all"
                  >
                    <div className="flex items-center justify-between mb-4">
                      <div className={`bg-gradient-to-br ${stat.color} p-3 rounded-xl`}>
                        <Icon className="w-6 h-6 text-white" />
                      </div>
                      <span className="text-green-600 text-sm font-medium flex items-center gap-1">
                        <TrendingUp className="w-4 h-4" />
                        {stat.trend}
                      </span>
                    </div>
                    <h3 className="text-3xl font-bold mb-1">{stat.value}</h3>
                    <p className="text-sm text-gray-600">{stat.label}</p>
                  </motion.div>
                );
              })}
            </div>

            {/* Secondary Stats */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              {[
                { icon: UserCheck, label: text.activeUsers, value: stats.activeUsers, color: 'from-teal-500 to-cyan-600' },
                { icon: CheckCircle, label: text.verifiedDoctors, value: stats.verifiedDoctors, color: 'from-indigo-500 to-blue-600' },
                { icon: Clock, label: text.todayPosts, value: stats.todayPosts, color: 'from-orange-500 to-amber-600' },
                { icon: AlertTriangle, label: text.pendingReports, value: stats.pendingReports, color: 'from-rose-500 to-red-600' }
              ].map((stat, index) => {
                const Icon = stat.icon;
                return (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.4 + index * 0.1 }}
                    className="bg-white rounded-2xl p-5 border border-gray-200 shadow-md hover:shadow-lg transition-all"
                  >
                    <div className="flex items-center gap-3 mb-2">
                      <div className={`bg-gradient-to-br ${stat.color} p-2 rounded-lg`}>
                        <Icon className="w-5 h-5 text-white" />
                      </div>
                      <p className="text-sm text-gray-600">{stat.label}</p>
                    </div>
                    <h3 className="text-2xl font-bold">{stat.value}</h3>
                  </motion.div>
                );
              })}
            </div>

            {/* Quick Actions */}
            <div className="bg-white rounded-2xl p-6 border border-gray-200 shadow-lg">
              <h2 className="text-xl font-medium mb-4 flex items-center gap-2">
                <Activity className="w-5 h-5 text-red-600" />
                {language === 'ps' ? 'ګړندي کړنې' : language === 'fa' ? 'اقدامات سریع' : 'Quick Actions'}
              </h2>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                <Button
                  onClick={() => setActiveTab('users')}
                  variant="outline"
                  className="h-auto flex-col gap-2 py-4"
                >
                  <Users className="w-6 h-6 text-blue-600" />
                  <span className="text-sm">{text.userManagement}</span>
                </Button>
                <Button
                  onClick={() => setActiveTab('doctors')}
                  variant="outline"
                  className="h-auto flex-col gap-2 py-4"
                >
                  <Stethoscope className="w-6 h-6 text-purple-600" />
                  <span className="text-sm">{text.doctorManagement}</span>
                </Button>
                <Button
                  onClick={() => setActiveTab('posts')}
                  variant="outline"
                  className="h-auto flex-col gap-2 py-4"
                >
                  <FileText className="w-6 h-6 text-green-600" />
                  <span className="text-sm">{text.postManagement}</span>
                </Button>
                <Button
                  onClick={() => setActiveTab('settings')}
                  variant="outline"
                  className="h-auto flex-col gap-2 py-4"
                >
                  <SettingsIcon className="w-6 h-6 text-gray-600" />
                  <span className="text-sm">{text.appSettings}</span>
                </Button>
              </div>
            </div>
          </div>
        )}

        {/* Users Management */}
        {activeTab === 'users' && (
          <AdminUsersManagement language={language} darkMode={false} />
        )}

        {/* Doctors Management */}
        {activeTab === 'doctors' && (
          <div className="space-y-4">
            <div className="bg-white rounded-2xl p-6 border border-gray-200 shadow-lg text-center">
              <Stethoscope className="w-16 h-16 text-purple-500 mx-auto mb-4" />
              <h3 className="text-xl font-medium mb-2">{text.doctorManagement}</h3>
              <p className="text-gray-600 mb-4">
                {language === 'ps' ? '250+ دوکتوران په سیسټم کې شته' : 
                 language === 'fa' ? '250+ دکتر در سیستم موجود است' : 
                 '250+ doctors in the system'}
              </p>
              <Button className="bg-gradient-to-r from-purple-500 to-violet-600">
                <Plus className="w-4 h-4 mr-2" />
                {text.addDoctor}
              </Button>
            </div>
          </div>
        )}

        {/* Posts Management */}
        {activeTab === 'posts' && (
          <div className="space-y-4">
            {/* Search & Filter */}
            <div className="bg-white rounded-2xl p-4 border border-gray-200 shadow-lg">
              <div className="flex flex-col sm:flex-row gap-3">
                <div className="relative flex-1">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                  <Input
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder={text.search}
                    className="pl-10"
                  />
                </div>
                <Button variant="outline" onClick={loadData}>
                  <RefreshCw className="w-4 h-4 mr-2" />
                  {text.refresh}
                </Button>
              </div>
            </div>

            {/* Posts Grid */}
            <div className="grid grid-cols-1 gap-4">
              {posts.filter(p =>
                p.content.toLowerCase().includes(searchQuery.toLowerCase()) ||
                p.userName.toLowerCase().includes(searchQuery.toLowerCase())
              ).map((post) => (
                <div key={post.id} className="bg-white rounded-2xl p-5 border border-gray-200 shadow-lg">
                  <div className="flex items-start justify-between mb-3">
                    <div>
                      <h3 className="font-medium">{post.userName}</h3>
                      <p className="text-sm text-gray-500">
                        {new Date(post.timestamp).toLocaleDateString()}
                      </p>
                    </div>
                    <div className="flex items-center gap-2">
                      {post.reported && (
                        <span className="px-2 py-1 bg-red-100 text-red-700 rounded-full text-xs font-medium flex items-center gap-1">
                          <Flag className="w-3 h-3" />
                          {post.reportCount} {text.reports}
                        </span>
                      )}
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => handleDeletePost(post.id)}
                        className="text-red-600"
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                  
                  <p className="text-gray-700 mb-3">{post.content}</p>
                  
                  {post.images.length > 0 && (
                    <div className="grid grid-cols-2 gap-2 mb-3">
                      {post.images.slice(0, 4).map((img, idx) => (
                        <div key={idx} className="rounded-lg overflow-hidden aspect-square">
                          <ImageWithFallback
                            src={img}
                            alt={`Post image ${idx + 1}`}
                            className="w-full h-full object-cover"
                          />
                        </div>
                      ))}
                    </div>
                  )}
                  
                  <div className="flex items-center gap-4 text-sm text-gray-600">
                    <span className="flex items-center gap-1">
                      <Heart className="w-4 h-4" />
                      {post.reactions?.length || 0}
                    </span>
                    <span className="flex items-center gap-1">
                      <MessageCircle className="w-4 h-4" />
                      {post.comments?.length || 0}
                    </span>
                    <span className="flex items-center gap-1">
                      <Share2 className="w-4 h-4" />
                      0
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Premium Management */}
        {activeTab === 'premium' && (
          <AdminPremiumManagement language={language} />
        )}

        {/* Payments Management */}
        {activeTab === 'payments' && (
          <div className="space-y-6">
            <div className="bg-white rounded-2xl p-6 border border-gray-200 shadow-lg text-center">
              <Wallet className="w-16 h-16 text-blue-500 mx-auto mb-4" />
              <h3 className="text-xl font-medium mb-2">
                {language === 'ps' ? 'د پیسو مدیریت' : language === 'fa' ? 'مدیریت پرداخت' : 'Payment Management'}
              </h3>
              <p className="text-gray-600 mb-4">
                {language === 'ps' ? 'د ټولو Premium Subscriptions معلومات' : 
                 language === 'fa' ? 'اطلاعات تمام Subscriptions Premium' : 
                 'All Premium Subscriptions Information'}
              </p>
              <div className="bg-blue-50 rounded-xl p-4 mb-4">
                <p className="text-sm text-gray-600 mb-2">
                  {language === 'ps' ? 'ستاسو Hesab Pay نمبر:' : language === 'fa' ? 'شماره Hesab Pay شما:' : 'Your Hesab Pay Number:'}
                </p>
                <p className="text-2xl text-blue-600">+93 779 494 512</p>
              </div>
              <div className="grid grid-cols-3 gap-4">
                <div className="bg-green-50 rounded-xl p-4">
                  <p className="text-sm text-gray-600">
                    {language === 'ps' ? 'ټوله عاید' : language === 'fa' ? 'مجموع درآمد' : 'Total Revenue'}
                  </p>
                  <p className="text-xl text-green-600">0 AFN</p>
                </div>
                <div className="bg-purple-50 rounded-xl p-4">
                  <p className="text-sm text-gray-600">
                    {language === 'ps' ? 'لیږدونې' : language === 'fa' ? 'تراکنش‌ها' : 'Transactions'}
                  </p>
                  <p className="text-xl text-purple-600">0</p>
                </div>
                <div className="bg-orange-50 rounded-xl p-4">
                  <p className="text-sm text-gray-600">
                    {language === 'ps' ? 'مشتریان' : language === 'fa' ? 'مشتریان' : 'Customers'}
                  </p>
                  <p className="text-xl text-orange-600">0</p>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* AdMob Management */}
        {activeTab === 'admob' && (
          <AdminAdMobEditor language={language} />
        )}

        {/* Categories Management */}
        {activeTab === 'categories' && (
          <HealthCategoriesManagement language={language} />
        )}

        {/* Settings */}
        {activeTab === 'settings' && (
          <div className="space-y-6">
            {/* General Settings */}
            <div className="bg-white rounded-2xl p-6 border border-gray-200 shadow-lg">
              <h2 className="text-xl font-medium mb-6 flex items-center gap-2">
                <SettingsIcon className="w-5 h-5 text-gray-600" />
                {text.appSettings}
              </h2>
              
              <div className="space-y-4">
                <div>
                  <Label>{text.appName}</Label>
                  <Input defaultValue="HealMate" />
                </div>
                
                <div>
                  <Label>{text.appVersion}</Label>
                  <Input defaultValue="1.0.0" />
                </div>
                
                <div>
                  <Label>{text.contactEmail}</Label>
                  <Input defaultValue="ibrahimkhaksar.it@gmail.com" type="email" />
                </div>
                
                <div>
                  <Label>{text.contactPhone}</Label>
                  <Input defaultValue="+93 700 000 000" type="tel" />
                </div>

                <div className="pt-4 border-t">
                  <h3 className="font-medium mb-3">{text.socialLinks}</h3>
                  <div className="space-y-3">
                    <div>
                      <Label>{text.facebook}</Label>
                      <Input placeholder="https://facebook.com/healmate" />
                    </div>
                    <div>
                      <Label>{text.instagram}</Label>
                      <Input placeholder="https://instagram.com/healmate" />
                    </div>
                    <div>
                      <Label>{text.twitter}</Label>
                      <Input placeholder="https://twitter.com/healmate" />
                    </div>
                  </div>
                </div>

                <div className="pt-4">
                  <Button 
                    onClick={() => {
                      alert(language === 'ps' ? '✅ تنظیمات په بریالیتوب سره خوندي شول!' : 
                            language === 'fa' ? '✅ تنظیمات با موفقیت ذخیره شد!' : 
                            '✅ Settings saved successfully!');
                    }}
                    className="w-full bg-gradient-to-r from-red-500 to-pink-600 hover:from-red-600 hover:to-pink-700"
                  >
                    <Check className="w-4 h-4 mr-2" />
                    {text.save}
                  </Button>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* User Detail Modal */}
      <AnimatePresence>
        {selectedUser && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4"
            onClick={() => setSelectedUser(null)}
          >
            <motion.div
              initial={{ scale: 0.9 }}
              animate={{ scale: 1 }}
              exit={{ scale: 0.9 }}
              onClick={(e) => e.stopPropagation()}
              className="bg-white rounded-3xl p-6 max-w-md w-full"
            >
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-2xl font-medium">{text.view} {text.users}</h2>
                <Button variant="ghost" size="icon" onClick={() => setSelectedUser(null)}>
                  <X className="w-5 h-5" />
                </Button>
              </div>

              <div className="space-y-4">
                <div className="flex items-center gap-4">
                  <div className="w-20 h-20 rounded-full overflow-hidden bg-gray-200">
                    <ImageWithFallback
                      src={selectedUser.profileImage || 'https://images.unsplash.com/photo-1633332755192-727a05c4013d?w=400'}
                      alt={selectedUser.name}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <div>
                    <h3 className="font-medium text-lg">{selectedUser.name}</h3>
                    {selectedUser.verified && (
                      <span className="text-blue-600 text-sm flex items-center gap-1">
                        <CheckCircle className="w-4 h-4" />
                        {text.verified}
                      </span>
                    )}
                  </div>
                </div>

                <div className="grid grid-cols-3 gap-4 pt-4 border-t">
                  <div className="text-center">
                    <p className="text-2xl font-bold">{selectedUser.posts}</p>
                    <p className="text-xs text-gray-600">{text.posts}</p>
                  </div>
                  <div className="text-center">
                    <p className="text-2xl font-bold">{selectedUser.followers}</p>
                    <p className="text-xs text-gray-600">{language === 'ps' ? 'تعقیب کوونکي' : language === 'fa' ? 'دنبال‌کنندگان' : 'Followers'}</p>
                  </div>
                  <div className="text-center">
                    <p className="text-2xl font-bold">{selectedUser.following}</p>
                    <p className="text-xs text-gray-600">{language === 'ps' ? 'تعقیب کوي' : language === 'fa' ? 'دنبال شده' : 'Following'}</p>
                  </div>
                </div>

                <div className="space-y-2 pt-4 border-t">
                  <div className="flex items-center gap-2 text-sm">
                    <Mail className="w-4 h-4 text-gray-500" />
                    <span>{selectedUser.email}</span>
                  </div>
                  <div className="flex items-center gap-2 text-sm">
                    <Phone className="w-4 h-4 text-gray-500" />
                    <span>{selectedUser.phone}</span>
                  </div>
                  <div className="flex items-center gap-2 text-sm">
                    <Calendar className="w-4 h-4 text-gray-500" />
                    <span>{new Date(selectedUser.joinedDate).toLocaleDateString()}</span>
                  </div>
                </div>

                <div className="grid grid-cols-3 gap-2 pt-4">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => handleChangeUserStatus(selectedUser.id, 'active')}
                    className="text-green-600"
                  >
                    {text.activate}
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => handleChangeUserStatus(selectedUser.id, 'suspended')}
                    className="text-yellow-600"
                  >
                    {text.suspend}
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => handleChangeUserStatus(selectedUser.id, 'banned')}
                    className="text-red-600"
                  >
                    {text.ban}
                  </Button>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}