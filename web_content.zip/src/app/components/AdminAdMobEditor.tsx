import { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { DollarSign, Edit, Check, X, Copy, Save, Settings as SettingsIcon } from 'lucide-react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { copyToClipboard } from '../utils/clipboard';

interface AdminAdMobEditorProps {
  language: 'ps' | 'fa' | 'en';
}

interface AdMobConfig {
  appId: string;
  bannerAdUnit: string;
  interstitialAdUnit: string;
  rewardedAdUnit: string;
  nativeAdUnit: string;
  testDeviceId: string;
}

export function AdminAdMobEditor({ language }: AdminAdMobEditorProps) {
  const [admobConfig, setAdmobConfig] = useState<AdMobConfig>({
    appId: 'ca-app-pub-3940256099942544~1458002511',
    bannerAdUnit: 'ca-app-pub-3940256099942544/6300978111',
    interstitialAdUnit: 'ca-app-pub-3940256099942544/1033173712',
    rewardedAdUnit: 'ca-app-pub-3940256099942544/5224354917',
    nativeAdUnit: 'ca-app-pub-3940256099942544/2247696110',
    testDeviceId: 'TEST_DEVICE_ID'
  });

  const [editingField, setEditingField] = useState<keyof AdMobConfig | null>(null);
  const [tempValue, setTempValue] = useState('');

  const texts = {
    ps: {
      title: 'د AdMob مدیریت',
      subtitle: 'د اعلانونو ID مدیریت او تنظیمات',
      appId: 'App ID',
      bannerAd: 'بینر اعلان',
      interstitialAd: 'Interstitial اعلان',
      rewardedAd: 'انعام اعلان',
      nativeAd: 'Native اعلان',
      testDevice: 'ټېسټ وسیله',
      edit: 'سمون',
      save: 'خوندي',
      cancel: 'لغوه',
      copy: 'کاپي',
      copied: 'کاپي شو!',
      savedSuccess: '✅ په بریالیتوب سره خوندي شو!',
      instructions: 'لارښوونې',
      step1: '۱. د Google AdMob ته لاړشئ او خپل اپلیکیشن جوړ کړئ',
      step2: '۲. د هر اعلان ډول لپاره Ad Unit جوړ کړئ',
      step3: '۳. د Ad Unit IDs کاپي کړئ او دلته یې واچوئ',
      step4: '۴. د ټېسټ وسیلې ID واچوئ (اختیاري)',
      step5: '۵. خوندي کړئ او بریالی!',
      warningTitle: '⚠️ مهم یاداشت:',
      warningText: 'دا د Google Test Ad Unit IDs دي. د production لپاره خپل رښتینی Ad Unit IDs وکاروئ چې د Google AdMob Dashboard څخه ترلاسه کړئ.',
      howToGet: 'څنګه ترلاسه کړئ:',
      howToStep1: '۱. admob.google.com ته لاړشئ',
      howToStep2: '۲. خپل account کې ننوځئ',
      howToStep3: '۳. App جوړ کړئ یا غوره کړئ',
      howToStep4: '۴. Ad Units جوړ کړئ',
      howToStep5: '۵. Ad Unit IDs کاپي کړئ',
      currentValue: 'اوسنی ارزښت:',
      newValue: 'نوی ارزښت:',
      adUnitId: 'Ad Unit ID',
      description: 'تشریح'
    },
    fa: {
      title: 'مدیریت AdMob',
      subtitle: 'مدیریت و تنظیمات ID تبلیغات',
      appId: 'App ID',
      bannerAd: 'تبلیغ بنر',
      interstitialAd: 'تبلیغ Interstitial',
      rewardedAd: 'تبلیغ پاداش',
      nativeAd: 'تبلیغ بومی',
      testDevice: 'دستگاه تست',
      edit: 'ویرایش',
      save: 'ذخیره',
      cancel: 'لغو',
      copy: 'کپی',
      copied: 'کپی شد!',
      savedSuccess: '✅ با موفقیت ذخیره شد!',
      instructions: 'دستورالعمل‌ها',
      step1: '۱. به Google AdMob بروید و برنامه خود را ایجاد کنید',
      step2: '۲. برای هر نوع تبلیغ، Ad Unit ایجاد کنید',
      step3: '۳. ID های Ad Unit را کپی کرده و اینجا قرار دهید',
      step4: '۴. ID دستگاه تست را قرار دهید (اختیاری)',
      step5: '۵. ذخیره کنید و تمام!',
      warningTitle: '⚠️ نکته مهم:',
      warningText: 'اینها ID های واحد تبلیغات تست Google هستند. برای production از ID های واقعی Ad Unit خود که از Google AdMob Dashboard دریافت می‌کنید استفاده کنید.',
      howToGet: 'چگونه دریافت کنیم:',
      howToStep1: '۱. به admob.google.com بروید',
      howToStep2: '۲. وارد حساب خود شوید',
      howToStep3: '۳. App ایجاد یا انتخاب کنید',
      howToStep4: '۴. Ad Units ایجاد کنید',
      howToStep5: '۵. ID های Ad Unit را کپی کنید',
      currentValue: 'مقدار فعلی:',
      newValue: 'مقدار جدید:',
      adUnitId: 'شناسه واحد تبلیغات',
      description: 'توضیحات'
    },
    en: {
      title: 'AdMob Management',
      subtitle: 'Manage and configure ad unit IDs',
      appId: 'App ID',
      bannerAd: 'Banner Ad',
      interstitialAd: 'Interstitial Ad',
      rewardedAd: 'Rewarded Ad',
      nativeAd: 'Native Ad',
      testDevice: 'Test Device',
      edit: 'Edit',
      save: 'Save',
      cancel: 'Cancel',
      copy: 'Copy',
      copied: 'Copied!',
      savedSuccess: '✅ Saved successfully!',
      instructions: 'Instructions',
      step1: '1. Go to Google AdMob and create your app',
      step2: '2. Create Ad Units for each ad type',
      step3: '3. Copy the Ad Unit IDs and paste them here',
      step4: '4. Set Test Device ID (optional)',
      step5: '5. Save and you\'re done!',
      warningTitle: '⚠️ Important Note:',
      warningText: 'These are Google Test Ad Unit IDs. For production, use your real Ad Unit IDs obtained from Google AdMob Dashboard.',
      howToGet: 'How to get:',
      howToStep1: '1. Go to admob.google.com',
      howToStep2: '2. Sign in to your account',
      howToStep3: '3. Create or select your App',
      howToStep4: '4. Create Ad Units',
      howToStep5: '5. Copy Ad Unit IDs',
      currentValue: 'Current Value:',
      newValue: 'New Value:',
      adUnitId: 'Ad Unit ID',
      description: 'Description'
    }
  };

  const t = texts[language];

  const adUnits = [
    {
      key: 'appId' as keyof AdMobConfig,
      label: t.appId,
      color: 'from-green-500 to-teal-600',
      description: language === 'ps' ? 'د اپلیکیشن اصلي ID' : language === 'fa' ? 'شناسه اصلی برنامه' : 'Main application ID',
      icon: '📱'
    },
    {
      key: 'bannerAdUnit' as keyof AdMobConfig,
      label: t.bannerAd,
      color: 'from-blue-500 to-cyan-600',
      description: language === 'ps' ? 'په پاڼو کې ښودل کیږي' : language === 'fa' ? 'در صفحات نمایش داده می‌شود' : 'Displayed on pages',
      icon: '📊'
    },
    {
      key: 'interstitialAdUnit' as keyof AdMobConfig,
      label: t.interstitialAd,
      color: 'from-red-500 to-pink-600',
      description: language === 'ps' ? 'د بشپړ پاڼې اعلان' : language === 'fa' ? 'تبلیغ تمام صفحه' : 'Full-screen ad',
      icon: '🖼️'
    },
    {
      key: 'rewardedAdUnit' as keyof AdMobConfig,
      label: t.rewardedAd,
      color: 'from-purple-500 to-violet-600',
      description: language === 'ps' ? 'د انعام سره اعلان' : language === 'fa' ? 'تبلیغ با جایزه' : 'Ad with reward',
      icon: '🎁'
    },
    {
      key: 'nativeAdUnit' as keyof AdMobConfig,
      label: t.nativeAd,
      color: 'from-orange-500 to-amber-600',
      description: language === 'ps' ? 'په محتوا کې ځای په ځای شوی' : language === 'fa' ? 'در محتوا ادغام شده' : 'Integrated in content',
      icon: '📝'
    },
    {
      key: 'testDeviceId' as keyof AdMobConfig,
      label: t.testDevice,
      color: 'from-gray-500 to-slate-600',
      description: language === 'ps' ? 'د ټېسټ وسیلې ID' : language === 'fa' ? 'شناسه دستگاه تست' : 'Test device ID',
      icon: '🔧'
    }
  ];

  useEffect(() => {
    const savedConfig = localStorage.getItem('healmate_admob_config');
    if (savedConfig) {
      setAdmobConfig(JSON.parse(savedConfig));
    }
  }, []);

  const handleEdit = (field: keyof AdMobConfig) => {
    setEditingField(field);
    setTempValue(admobConfig[field]);
  };

  const handleSave = (field: keyof AdMobConfig) => {
    const updatedConfig = { ...admobConfig, [field]: tempValue };
    setAdmobConfig(updatedConfig);
    localStorage.setItem('healmate_admob_config', JSON.stringify(updatedConfig));
    setEditingField(null);
    alert(t.savedSuccess);
  };

  const handleCancel = () => {
    setEditingField(null);
    setTempValue('');
  };

  const handleCopy = async (value: string) => {
    const success = await copyToClipboard(value);
    if (success) {
      alert(t.copied);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-gradient-to-r from-green-500 to-teal-600 rounded-2xl p-6 text-white shadow-xl">
        <div className="flex items-center gap-3 mb-2">
          <DollarSign className="w-8 h-8" />
          <h2 className="text-2xl">{t.title}</h2>
        </div>
        <p className="text-white/90">{t.subtitle}</p>
      </div>

      {/* Warning */}
      <div className="bg-yellow-50 border-2 border-yellow-200 rounded-2xl p-6">
        <h3 className="text-lg mb-2 text-yellow-800 flex items-center gap-2">
          {t.warningTitle}
        </h3>
        <p className="text-yellow-700 mb-4">{t.warningText}</p>
        
        <div className="bg-white rounded-xl p-4 border border-yellow-200">
          <h4 className="font-medium mb-3 text-yellow-800">{t.howToGet}</h4>
          <ol className="space-y-2 text-sm text-gray-700">
            <li>{t.howToStep1}</li>
            <li>{t.howToStep2}</li>
            <li>{t.howToStep3}</li>
            <li>{t.howToStep4}</li>
            <li>{t.howToStep5}</li>
          </ol>
        </div>
      </div>

      {/* Ad Units */}
      <div className="grid grid-cols-1 gap-4">
        {adUnits.map((adUnit) => (
          <motion.div
            key={adUnit.key}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-white rounded-2xl p-6 border-2 border-gray-200 shadow-lg hover:shadow-xl transition-all"
          >
            {/* Header */}
            <div className="flex items-start justify-between mb-4">
              <div className="flex items-center gap-3">
                <div className={`bg-gradient-to-br ${adUnit.color} p-3 rounded-xl text-2xl`}>
                  {adUnit.icon}
                </div>
                <div>
                  <h3 className="text-lg">{adUnit.label}</h3>
                  <p className="text-sm text-gray-600">{adUnit.description}</p>
                </div>
              </div>
              {editingField !== adUnit.key && (
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => handleEdit(adUnit.key)}
                  className="border-2"
                >
                  <Edit className="w-4 h-4 mr-2" />
                  {t.edit}
                </Button>
              )}
            </div>

            {/* Value */}
            {editingField === adUnit.key ? (
              <div className="space-y-3">
                <div>
                  <Label className="text-sm text-gray-600 mb-2">{t.currentValue}</Label>
                  <div className="bg-gray-50 rounded-lg p-3 border border-gray-200">
                    <code className="text-xs text-gray-700 break-all">{admobConfig[adUnit.key]}</code>
                  </div>
                </div>

                <div>
                  <Label className="text-sm text-gray-600 mb-2">{t.newValue}</Label>
                  <Input
                    value={tempValue}
                    onChange={(e) => setTempValue(e.target.value)}
                    placeholder={`${language === 'ps' ? 'نوی ارزښت دلته ولیکئ' : language === 'fa' ? 'مقدار جدید را اینجا وارد کنید' : 'Enter new value here'}`}
                    className="font-mono text-sm border-2"
                  />
                </div>

                <div className="flex gap-2">
                  <Button
                    onClick={() => handleSave(adUnit.key)}
                    className="flex-1 bg-green-600 hover:bg-green-700"
                  >
                    <Check className="w-4 h-4 mr-2" />
                    {t.save}
                  </Button>
                  <Button
                    onClick={handleCancel}
                    variant="outline"
                    className="flex-1 border-2"
                  >
                    <X className="w-4 h-4 mr-2" />
                    {t.cancel}
                  </Button>
                </div>
              </div>
            ) : (
              <div className="space-y-3">
                <Label className="text-sm text-gray-600">{t.adUnitId}:</Label>
                <div className="flex gap-2">
                  <div className="flex-1 bg-gray-50 rounded-lg p-3 border-2 border-gray-200 overflow-x-auto">
                    <code className="text-xs text-gray-800 break-all">{admobConfig[adUnit.key]}</code>
                  </div>
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => handleCopy(admobConfig[adUnit.key])}
                    className="border-2"
                  >
                    <Copy className="w-4 h-4 mr-2" />
                    {t.copy}
                  </Button>
                </div>
              </div>
            )}
          </motion.div>
        ))}
      </div>

      {/* Instructions */}
      <div className="bg-blue-50 border-2 border-blue-200 rounded-2xl p-6">
        <h3 className="text-lg mb-4 text-blue-800 flex items-center gap-2">
          <SettingsIcon className="w-5 h-5" />
          {t.instructions}
        </h3>
        <ol className="space-y-3">
          <li className="flex items-start gap-3">
            <span className="bg-blue-600 text-white rounded-full w-6 h-6 flex items-center justify-center text-sm flex-shrink-0 mt-0.5">1</span>
            <span className="text-blue-900">{t.step1}</span>
          </li>
          <li className="flex items-start gap-3">
            <span className="bg-blue-600 text-white rounded-full w-6 h-6 flex items-center justify-center text-sm flex-shrink-0 mt-0.5">2</span>
            <span className="text-blue-900">{t.step2}</span>
          </li>
          <li className="flex items-start gap-3">
            <span className="bg-blue-600 text-white rounded-full w-6 h-6 flex items-center justify-center text-sm flex-shrink-0 mt-0.5">3</span>
            <span className="text-blue-900">{t.step3}</span>
          </li>
          <li className="flex items-start gap-3">
            <span className="bg-blue-600 text-white rounded-full w-6 h-6 flex items-center justify-center text-sm flex-shrink-0 mt-0.5">4</span>
            <span className="text-blue-900">{t.step4}</span>
          </li>
          <li className="flex items-start gap-3">
            <span className="bg-blue-600 text-white rounded-full w-6 h-6 flex items-center justify-center text-sm flex-shrink-0 mt-0.5">5</span>
            <span className="text-blue-900">{t.step5}</span>
          </li>
        </ol>
      </div>

      {/* Final Save Button */}
      <div className="bg-white rounded-2xl p-6 border-2 border-gray-200 shadow-lg">
        <Button
          onClick={() => {
            localStorage.setItem('healmate_admob_config', JSON.stringify(admobConfig));
            alert(t.savedSuccess);
          }}
          className="w-full bg-gradient-to-r from-green-500 to-teal-600 hover:from-green-600 hover:to-teal-700 text-lg py-6"
        >
          <Save className="w-5 h-5 mr-2" />
          {t.save} {language === 'ps' ? 'ټول تنظیمات' : language === 'fa' ? 'تمام تنظیمات' : 'All Settings'}
        </Button>
      </div>
    </div>
  );
}
