import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";
import { Input } from "./ui/input";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "./ui/dialog";
import { 
  Activity, 
  Calendar,
  Clock,
  MapPin,
  FileText,
  Download,
  CheckCircle,
  Droplets,
  Heart,
  Stethoscope,
  Sparkles,
  Search,
  Filter
} from "lucide-react";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select";
import { Separator } from "./ui/separator";

interface LabTest {
  id: number;
  name: string;
  nameDari: string;
  category: string;
  categoryDari: string;
  description: string;
  descriptionDari: string;
  price: string;
  duration: string;
  fasting: boolean;
  sampleType: string;
  icon: any;
  color: string;
}

const labTests: LabTest[] = [
  {
    id: 1,
    name: "Complete Blood Count (CBC)",
    nameDari: "بشپړ د وینې شمیرنه",
    category: "Blood Tests",
    categoryDari: "د وینې ازموینې",
    description: "Measures different components of blood including RBC, WBC, Hemoglobin, Platelets",
    descriptionDari: "د وینې بیلابیل اجزا اندازه کوي لکه سره شیلتونه، سپین شیلتونه، هیموګلوبین، پلیټلیټس",
    price: "300 AFN",
    duration: "2-4 hours",
    fasting: false,
    sampleType: "Blood",
    icon: Droplets,
    color: "from-red-500 to-pink-500"
  },
  {
    id: 2,
    name: "Blood Sugar (Fasting)",
    nameDari: "د وینې شکر (د خوړو مخکې)",
    category: "Diabetes",
    categoryDari: "شکري ناروغي",
    description: "Measures glucose level in blood after fasting to diagnose diabetes",
    descriptionDari: "د خوړو څخه وروسته د وینې کې د ګلوکوز کچه اندازه کوي چې شکري ناروغي تشخیص کړي",
    price: "150 AFN",
    duration: "1-2 hours",
    fasting: true,
    sampleType: "Blood",
    icon: Activity,
    color: "from-blue-500 to-cyan-500"
  },
  {
    id: 3,
    name: "HbA1c (Glycated Hemoglobin)",
    nameDari: "HbA1c (ګلایکیټ شوی هیموګلوبین)",
    category: "Diabetes",
    categoryDari: "شکري ناروغي",
    description: "Shows average blood sugar levels over past 2-3 months",
    descriptionDari: "د تیرو ۲-۳ میاشتو د وینې د شکر اوسط کچه ښیي",
    price: "500 AFN",
    duration: "4-6 hours",
    fasting: false,
    sampleType: "Blood",
    icon: Activity,
    color: "from-purple-500 to-violet-500"
  },
  {
    id: 4,
    name: "Lipid Profile",
    nameDari: "لیپیډ پروفایل",
    category: "Cardiac",
    categoryDari: "زړه",
    description: "Cholesterol and triglycerides test to assess heart disease risk",
    descriptionDari: "کولیسټرول او ټرایګلیسرایډ ازموینه د زړه ناروغۍ خطر ارزونې لپاره",
    price: "600 AFN",
    duration: "4-6 hours",
    fasting: true,
    sampleType: "Blood",
    icon: Heart,
    color: "from-red-500 to-rose-500"
  },
  {
    id: 5,
    name: "Kidney Function Test (KFT)",
    nameDari: "د پښتورګو فعالیت ازموینه",
    category: "Kidney",
    categoryDari: "پښتورګي",
    description: "Checks creatinine, urea, and other kidney function markers",
    descriptionDari: "کریاټینین، یوریا او د پښتورګو د فعالیت نور نښانې چیک کوي",
    price: "450 AFN",
    duration: "4-6 hours",
    fasting: true,
    sampleType: "Blood",
    icon: Stethoscope,
    color: "from-emerald-500 to-teal-500"
  },
  {
    id: 6,
    name: "Liver Function Test (LFT)",
    nameDari: "د ځیګر فعالیت ازموینه",
    category: "Liver",
    categoryDari: "ځیګر",
    description: "Evaluates liver enzymes and function",
    descriptionDari: "د ځیګر انزایمونه او فعالیت ارزوي",
    price: "500 AFN",
    duration: "4-6 hours",
    fasting: true,
    sampleType: "Blood",
    icon: Activity,
    color: "from-orange-500 to-amber-500"
  },
  {
    id: 7,
    name: "Thyroid Profile (T3, T4, TSH)",
    nameDari: "تایرویډ پروفایل",
    category: "Hormones",
    categoryDari: "هورمونونه",
    description: "Checks thyroid gland function",
    descriptionDari: "د تایرویډ غدې فعالیت چیک کوي",
    price: "800 AFN",
    duration: "6-8 hours",
    fasting: false,
    sampleType: "Blood",
    icon: Activity,
    color: "from-indigo-500 to-purple-500"
  },
  {
    id: 8,
    name: "COVID-19 RT-PCR",
    nameDari: "کوویډ-۱۹ ازموینه",
    category: "Infectious Disease",
    categoryDari: "ساري ناروغي",
    description: "Detects active COVID-19 infection",
    descriptionDari: "فعال کوویډ-۱۹ انتان کشف کوي",
    price: "1200 AFN",
    duration: "24 hours",
    fasting: false,
    sampleType: "Nasal Swab",
    icon: Activity,
    color: "from-red-500 to-orange-500"
  },
  {
    id: 9,
    name: "Vitamin D",
    nameDari: "ویټامین D",
    category: "Vitamins",
    categoryDari: "ویټامینونه",
    description: "Measures Vitamin D levels in blood",
    descriptionDari: "په وینه کې د ویټامین D کچه اندازه کوي",
    price: "700 AFN",
    duration: "6-8 hours",
    fasting: false,
    sampleType: "Blood",
    icon: Activity,
    color: "from-yellow-500 to-amber-500"
  },
  {
    id: 10,
    name: "Vitamin B12",
    nameDari: "ویټامین B12",
    category: "Vitamins",
    categoryDari: "ویټامینونه",
    description: "Measures Vitamin B12 levels for nerve and blood health",
    descriptionDari: "د عصب او وینې روغتیا لپاره د ویټامین B12 کچه اندازه کوي",
    price: "650 AFN",
    duration: "6-8 hours",
    fasting: false,
    sampleType: "Blood",
    icon: Activity,
    color: "from-pink-500 to-rose-500"
  },
  {
    id: 11,
    name: "Urine Routine & Microscopy",
    nameDari: "د ادرار معمولي ازموینه",
    category: "Urine Tests",
    categoryDari: "د ادرار ازموینې",
    description: "Checks for infections, kidney problems, and diabetes",
    descriptionDari: "د انتاناتو، پښتورګو ستونزو او شکري ناروغۍ لپاره چیک کوي",
    price: "200 AFN",
    duration: "2-4 hours",
    fasting: false,
    sampleType: "Urine",
    icon: Droplets,
    color: "from-cyan-500 to-blue-500"
  },
  {
    id: 12,
    name: "Dengue NS1 Antigen",
    nameDari: "ډینګي ازموینه",
    category: "Infectious Disease",
    categoryDari: "ساري ناروغي",
    description: "Detects dengue fever infection",
    descriptionDari: "د ډینګي تبې انتان کشف کوي",
    price: "800 AFN",
    duration: "4-6 hours",
    fasting: false,
    sampleType: "Blood",
    icon: Activity,
    color: "from-red-500 to-pink-500"
  }
];

interface TestResult {
  id: number;
  testName: string;
  testNameDari: string;
  date: string;
  status: "Ready" | "Pending" | "Processing";
  pdfUrl?: string;
}

interface DetailedResult {
  parameter: string;
  parameterDari: string;
  value: string;
  unit: string;
  normalRange: string;
  status: "normal" | "high" | "low";
}

const mockResults: TestResult[] = [
  {
    id: 1,
    testName: "Complete Blood Count (CBC)",
    testNameDari: "بشپړ د وینې شمیرنه",
    date: "2025-11-10",
    status: "Ready",
    pdfUrl: "#"
  },
  {
    id: 2,
    testName: "Blood Sugar (Fasting)",
    testNameDari: "د وینې شکر",
    date: "2025-11-12",
    status: "Ready",
    pdfUrl: "#"
  },
  {
    id: 3,
    testName: "Lipid Profile",
    testNameDari: "لیپیډ پروفایل",
    date: "2025-11-14",
    status: "Processing"
  }
];

const detailedResults: Record<number, DetailedResult[]> = {
  1: [ // CBC Results
    { parameter: "Hemoglobin", parameterDari: "هیموګلوبین", value: "14.5", unit: "g/dL", normalRange: "13.5-17.5", status: "normal" },
    { parameter: "WBC Count", parameterDari: "سپین شیلتونه", value: "7.2", unit: "×10³/μL", normalRange: "4.5-11.0", status: "normal" },
    { parameter: "RBC Count", parameterDari: "سره شیلتونه", value: "5.1", unit: "×10⁶/μL", normalRange: "4.5-5.9", status: "normal" },
    { parameter: "Platelets", parameterDari: "پلیټلیټس", value: "250", unit: "×10³/μL", normalRange: "150-400", status: "normal" },
    { parameter: "Hematocrit", parameterDari: "هماتوکریت", value: "42", unit: "%", normalRange: "38.8-50.0", status: "normal" },
    { parameter: "MCV", parameterDari: "MCV", value: "88", unit: "fL", normalRange: "80-100", status: "normal" },
  ],
  2: [ // Blood Sugar Results
    { parameter: "Fasting Glucose", parameterDari: "د خوړو مخکې ګلوکوز", value: "95", unit: "mg/dL", normalRange: "70-100", status: "normal" },
    { parameter: "HbA1c", parameterDari: "HbA1c", value: "5.4", unit: "%", normalRange: "4.0-5.6", status: "normal" },
  ]
};

export function LabTestBooking() {
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("all");
  const [selectedTest, setSelectedTest] = useState<LabTest | null>(null);
  const [modalOpen, setModalOpen] = useState(false);
  const [showResults, setShowResults] = useState(false);
  const [viewResultId, setViewResultId] = useState<number | null>(null);
  const [resultModalOpen, setResultModalOpen] = useState(false);

  const categories = [
    { value: "all", label: "All Tests", labelDari: "ټولې ازموینې" },
    { value: "Blood Tests", label: "Blood Tests", labelDari: "د وینې ازموینې" },
    { value: "Diabetes", label: "Diabetes", labelDari: "شکري ناروغي" },
    { value: "Cardiac", label: "Cardiac", labelDari: "زړه" },
    { value: "Kidney", label: "Kidney", labelDari: "پښتورګي" },
    { value: "Liver", label: "Liver", labelDari: "ځیګر" },
    { value: "Hormones", label: "Hormones", labelDari: "هورمونونه" },
    { value: "Vitamins", label: "Vitamins", labelDari: "ویټامینونه" },
  ];

  const filteredTests = labTests.filter(test => {
    const matchesSearch = 
      test.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      test.nameDari.includes(searchTerm);
    const matchesCategory = selectedCategory === "all" || test.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  const handleBookTest = (test: LabTest) => {
    setSelectedTest(test);
    setModalOpen(true);
  };

  const handleViewResult = (resultId: number) => {
    setViewResultId(resultId);
    setResultModalOpen(true);
  };

  const handleDownloadPDF = (resultId: number) => {
    // Simulate PDF download
    alert(`Downloading PDF for Result #${resultId}...`);
  };

  return (
    <section className="py-16 md:py-24 bg-gradient-to-b from-white via-cyan-50/30 to-white relative overflow-hidden min-h-screen">
      {/* Background decoration */}
      <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-gradient-to-bl from-cyan-100/50 to-blue-100/50 rounded-full blur-3xl animate-float"></div>
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        {/* Header */}
        <div className="text-center mb-12 md:mb-16 space-y-4">
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-cyan-100 to-blue-100 rounded-full">
            <Sparkles className="w-4 h-4 text-cyan-600 animate-pulse-glow" />
            <span className="text-cyan-700 text-sm uppercase tracking-wider">Laboratory</span>
          </div>
          <h2 className="text-4xl md:text-6xl">
            <span className="bg-gradient-to-r from-cyan-600 via-blue-600 to-indigo-600 bg-clip-text text-transparent">
              Lab Test Booking
            </span>
          </h2>
          <p className="text-gray-600 max-w-2xl mx-auto text-lg">
            لابراتواري ازموینې - Book lab tests and get results online
          </p>
        </div>

        {/* Tab Navigation */}
        <div className="flex gap-4 mb-8 justify-center">
          <Button
            variant={!showResults ? "default" : "outline"}
            className={!showResults ? "bg-gradient-to-r from-cyan-500 to-blue-600" : ""}
            onClick={() => setShowResults(false)}
          >
            <Activity className="w-4 h-4 mr-2" />
            Book Tests
          </Button>
          <Button
            variant={showResults ? "default" : "outline"}
            className={showResults ? "bg-gradient-to-r from-emerald-500 to-teal-600" : ""}
            onClick={() => setShowResults(true)}
          >
            <FileText className="w-4 h-4 mr-2" />
            My Results
          </Button>
        </div>

        {!showResults ? (
          <>
            {/* Search and Filter */}
            <div className="mb-8 flex flex-col md:flex-row gap-4">
              <div className="flex-1 relative">
                <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                <Input
                  placeholder="Search lab tests... | ازموینې ولټوئ..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-12 h-12 rounded-xl shadow-lg border-2 border-gray-200"
                />
              </div>
              <div className="md:w-64">
                <Select value={selectedCategory} onValueChange={setSelectedCategory}>
                  <SelectTrigger className="h-12 rounded-xl shadow-lg border-2 border-gray-200">
                    <Filter className="w-4 h-4 mr-2" />
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {categories.map(cat => (
                      <SelectItem key={cat.value} value={cat.value}>
                        {cat.label} - {cat.labelDari}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            {/* Tests Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredTests.map((test, index) => (
                <Card
                  key={test.id}
                  className="hover-lift border-0 shadow-lg overflow-hidden cursor-pointer"
                  style={{ animationDelay: `${index * 50}ms` }}
                  onClick={() => handleBookTest(test)}
                >
                  <div className={`h-2 bg-gradient-to-r ${test.color}`}></div>
                  <CardHeader className="pb-3">
                    <div className="flex items-start gap-3 mb-3">
                      <div className={`p-3 bg-gradient-to-br ${test.color} rounded-xl shadow-lg`}>
                        <test.icon className="w-6 h-6 text-white" />
                      </div>
                      <div className="flex-1">
                        <CardTitle className="text-base mb-1">{test.name}</CardTitle>
                        <p className="text-sm text-cyan-600">{test.nameDari}</p>
                      </div>
                    </div>
                    <Badge variant="outline" className="text-xs w-fit">
                      {test.category}
                    </Badge>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <p className="text-sm text-gray-600 line-clamp-2">{test.description}</p>
                    
                    <div className="flex items-center justify-between text-sm">
                      <div className="flex items-center gap-2">
                        <Clock className="w-4 h-4 text-gray-500" />
                        <span className="text-gray-600">{test.duration}</span>
                      </div>
                      <span className="text-cyan-600">{test.price}</span>
                    </div>

                    {test.fasting && (
                      <Badge className="bg-amber-100 text-amber-700 w-full justify-center">
                        Fasting Required
                      </Badge>
                    )}

                    <Button 
                      className="w-full bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-600 hover:to-blue-700"
                      onClick={(e) => {
                        e.stopPropagation();
                        handleBookTest(test);
                      }}
                    >
                      <Calendar className="w-4 h-4 mr-2" />
                      Book Now
                    </Button>
                  </CardContent>
                </Card>
              ))}
            </div>
          </>
        ) : (
          /* Test Results Section */
          <div className="max-w-4xl mx-auto">
            <div className="space-y-4">
              {mockResults.map((result) => (
                <Card key={result.id} className="hover-lift border-0 shadow-lg">
                  <CardContent className="p-6">
                    <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                      <div className="flex-1">
                        <h3 className="text-lg text-gray-900 mb-1">{result.testName}</h3>
                        <p className="text-sm text-cyan-600 mb-2">{result.testNameDari}</p>
                        <p className="text-sm text-gray-600">Date: {result.date}</p>
                      </div>
                      <div className="flex items-center gap-3">
                        <Badge className={
                          result.status === "Ready" ? "bg-green-100 text-green-700" :
                          result.status === "Processing" ? "bg-blue-100 text-blue-700" :
                          "bg-amber-100 text-amber-700"
                        }>
                          {result.status === "Ready" && <CheckCircle className="w-3 h-3 mr-1" />}
                          {result.status}
                        </Badge>
                        {result.status === "Ready" && (
                          <div className="flex gap-2">
                            <Button 
                              size="sm" 
                              className="bg-gradient-to-r from-blue-500 to-cyan-600"
                              onClick={() => handleViewResult(result.id)}
                            >
                              <FileText className="w-4 h-4 mr-2" />
                              View Results
                            </Button>
                            <Button 
                              size="sm" 
                              variant="outline"
                              onClick={() => handleDownloadPDF(result.id)}
                            >
                              <Download className="w-4 h-4" />
                            </Button>
                          </div>
                        )}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Result Viewer Modal */}
      <Dialog open={resultModalOpen} onOpenChange={setResultModalOpen}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <div className="flex items-center justify-between">
              <div>
                <DialogTitle className="text-2xl mb-2">
                  {mockResults.find(r => r.id === viewResultId)?.testName}
                </DialogTitle>
                <DialogDescription className="text-cyan-600">
                  {mockResults.find(r => r.id === viewResultId)?.testNameDari}
                </DialogDescription>
                <p className="text-cyan-600">
                  {mockResults.find(r => r.id === viewResultId)?.testNameDari}
                </p>
              </div>
              <Button 
                variant="outline"
                onClick={() => handleDownloadPDF(viewResultId || 0)}
              >
                <Download className="w-4 h-4 mr-2" />
                Download PDF
              </Button>
            </div>
          </DialogHeader>

          {viewResultId && detailedResults[viewResultId] && (
            <div className="space-y-6">
              {/* Patient Info Header */}
              <div className="p-4 bg-gradient-to-r from-cyan-50 to-blue-50 rounded-lg border border-cyan-200">
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                  <div>
                    <p className="text-gray-600 mb-1">Patient Name</p>
                    <p className="text-gray-900">User Profile</p>
                  </div>
                  <div>
                    <p className="text-gray-600 mb-1">Test Date</p>
                    <p className="text-gray-900">{mockResults.find(r => r.id === viewResultId)?.date}</p>
                  </div>
                  <div>
                    <p className="text-gray-600 mb-1">Report Date</p>
                    <p className="text-gray-900">{mockResults.find(r => r.id === viewResultId)?.date}</p>
                  </div>
                  <div>
                    <p className="text-gray-600 mb-1">Lab ID</p>
                    <p className="text-gray-900">KBL-{viewResultId}0{viewResultId}45</p>
                  </div>
                </div>
              </div>

              {/* Test Results Table */}
              <div className="border border-gray-200 rounded-lg overflow-hidden">
                <div className="bg-gradient-to-r from-cyan-600 to-blue-600 text-white p-4">
                  <h3 className="text-lg">Test Results - د ازموینې نتیجې</h3>
                </div>
                
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead className="bg-gray-50 border-b border-gray-200">
                      <tr>
                        <th className="text-left p-4 text-sm text-gray-700">Parameter</th>
                        <th className="text-left p-4 text-sm text-gray-700">پارامیټر</th>
                        <th className="text-center p-4 text-sm text-gray-700">Value</th>
                        <th className="text-center p-4 text-sm text-gray-700">Unit</th>
                        <th className="text-center p-4 text-sm text-gray-700">Normal Range</th>
                        <th className="text-center p-4 text-sm text-gray-700">Status</th>
                      </tr>
                    </thead>
                    <tbody>
                      {detailedResults[viewResultId].map((item, index) => (
                        <tr 
                          key={index} 
                          className={`border-b border-gray-100 hover:bg-gray-50 transition-colors ${
                            item.status === "high" ? "bg-red-50" :
                            item.status === "low" ? "bg-yellow-50" :
                            ""
                          }`}
                        >
                          <td className="p-4 text-gray-900">{item.parameter}</td>
                          <td className="p-4 text-cyan-600 text-sm">{item.parameterDari}</td>
                          <td className="p-4 text-center">
                            <span className={`${
                              item.status === "high" ? "text-red-600" :
                              item.status === "low" ? "text-yellow-600" :
                              "text-gray-900"
                            }`}>
                              {item.value}
                            </span>
                          </td>
                          <td className="p-4 text-center text-gray-600 text-sm">{item.unit}</td>
                          <td className="p-4 text-center text-gray-600 text-sm">{item.normalRange}</td>
                          <td className="p-4 text-center">
                            <Badge className={
                              item.status === "normal" ? "bg-green-100 text-green-700" :
                              item.status === "high" ? "bg-red-100 text-red-700" :
                              "bg-yellow-100 text-yellow-700"
                            }>
                              {item.status === "normal" && <CheckCircle className="w-3 h-3 mr-1" />}
                              {item.status === "high" && "↑"}
                              {item.status === "low" && "↓"}
                              {item.status === "normal" ? "Normal" : item.status.toUpperCase()}
                            </Badge>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>

              {/* Summary & Recommendations */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <Card className="border-0 shadow-lg bg-gradient-to-br from-green-50 to-emerald-50">
                  <CardHeader>
                    <CardTitle className="text-lg flex items-center gap-2">
                      <CheckCircle className="w-5 h-5 text-green-600" />
                      Summary
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm text-gray-700">
                      {detailedResults[viewResultId].filter(r => r.status === "normal").length} out of {detailedResults[viewResultId].length} parameters are within normal range.
                    </p>
                    <p className="text-sm text-green-600 mt-2">
                      Overall results are satisfactory.
                    </p>
                  </CardContent>
                </Card>

                <Card className="border-0 shadow-lg bg-gradient-to-br from-blue-50 to-cyan-50">
                  <CardHeader>
                    <CardTitle className="text-lg flex items-center gap-2">
                      <Stethoscope className="w-5 h-5 text-blue-600" />
                      Recommendations
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ul className="text-sm text-gray-700 space-y-1 list-disc list-inside">
                      <li>Maintain a healthy diet</li>
                      <li>Regular exercise recommended</li>
                      <li>Follow up with your doctor</li>
                      <li>Stay hydrated</li>
                    </ul>
                  </CardContent>
                </Card>
              </div>

              {/* Doctor's Notes */}
              <Card className="border-0 shadow-lg bg-gradient-to-r from-purple-50 to-pink-50">
                <CardHeader>
                  <CardTitle className="text-lg flex items-center gap-2">
                    <FileText className="w-5 h-5 text-purple-600" />
                    Doctor's Notes - د ډاکټر یادښتونه
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-gray-700 mb-2">
                    All parameters are within acceptable limits. Patient is advised to maintain current lifestyle and dietary habits. 
                  </p>
                  <p className="text-sm text-purple-600">
                    ټول پارامیټرونه د منلو وړ حدونو دننه دي. ناروغ ته سپارښتنه کیږي چې اوسنی ژوند او خوړو عادتونه وساتي.
                  </p>
                  <Separator className="my-3" />
                  <div className="flex items-center justify-between text-sm">
                    <div>
                      <p className="text-gray-600">Reviewed by:</p>
                      <p className="text-gray-900">Dr. Sarah Johnson, MD</p>
                    </div>
                    <div className="text-right">
                      <p className="text-gray-600">Date:</p>
                      <p className="text-gray-900">{mockResults.find(r => r.id === viewResultId)?.date}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Action Buttons */}
              <div className="flex gap-3">
                <Button 
                  className="flex-1 bg-gradient-to-r from-blue-500 to-cyan-600"
                  onClick={() => handleDownloadPDF(viewResultId)}
                >
                  <Download className="w-4 h-4 mr-2" />
                  Download Full Report (PDF)
                </Button>
                <Button 
                  variant="outline"
                  className="flex-1"
                  onClick={() => alert("Sharing report...")}
                >
                  Share with Doctor
                </Button>
              </div>
            </div>
          )}

          {viewResultId && !detailedResults[viewResultId] && (
            <div className="text-center py-12">
              <FileText className="w-16 h-16 text-gray-300 mx-auto mb-4" />
              <p className="text-gray-600 mb-2">Detailed results not available</p>
              <p className="text-sm text-gray-500">Please download the PDF report</p>
              <Button 
                className="mt-4 bg-gradient-to-r from-cyan-500 to-blue-600"
                onClick={() => handleDownloadPDF(viewResultId)}
              >
                <Download className="w-4 h-4 mr-2" />
                Download PDF Report
              </Button>
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Booking Modal */}
      <Dialog open={modalOpen} onOpenChange={setModalOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle className="text-2xl">Book Lab Test</DialogTitle>
            <DialogDescription>د لابراتوار ټیسټ بکینګ - Schedule your medical test</DialogDescription>
          </DialogHeader>
          {selectedTest && (
            <div className="space-y-6">
              <div className="flex items-start gap-4 p-4 bg-gradient-to-r from-cyan-50 to-blue-50 rounded-lg">
                <div className={`p-3 bg-gradient-to-br ${selectedTest.color} rounded-xl`}>
                  <selectedTest.icon className="w-8 h-8 text-white" />
                </div>
                <div className="flex-1">
                  <h3 className="text-lg mb-1">{selectedTest.name}</h3>
                  <p className="text-sm text-cyan-600 mb-2">{selectedTest.nameDari}</p>
                  <p className="text-sm text-gray-600">{selectedTest.description}</p>
                  <p className="text-sm text-gray-600 mt-1">{selectedTest.descriptionDari}</p>
                </div>
              </div>

              <Separator />

              <div className="grid grid-cols-2 gap-4">
                <div className="p-3 bg-blue-50 rounded-lg">
                  <p className="text-sm text-gray-600 mb-1">Price</p>
                  <p className="text-lg text-blue-600">{selectedTest.price}</p>
                </div>
                <div className="p-3 bg-purple-50 rounded-lg">
                  <p className="text-sm text-gray-600 mb-1">Duration</p>
                  <p className="text-lg text-purple-600">{selectedTest.duration}</p>
                </div>
                <div className="p-3 bg-emerald-50 rounded-lg">
                  <p className="text-sm text-gray-600 mb-1">Sample Type</p>
                  <p className="text-lg text-emerald-600">{selectedTest.sampleType}</p>
                </div>
                <div className="p-3 bg-amber-50 rounded-lg">
                  <p className="text-sm text-gray-600 mb-1">Fasting</p>
                  <p className="text-lg text-amber-600">{selectedTest.fasting ? "Required" : "Not Required"}</p>
                </div>
              </div>

              <Separator />

              <div className="space-y-3">
                <Input placeholder="Select Date" type="date" />
                <Select>
                  <SelectTrigger>
                    <SelectValue placeholder="Select Time Slot" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="9am">9:00 AM - 10:00 AM</SelectItem>
                    <SelectItem value="10am">10:00 AM - 11:00 AM</SelectItem>
                    <SelectItem value="11am">11:00 AM - 12:00 PM</SelectItem>
                    <SelectItem value="2pm">2:00 PM - 3:00 PM</SelectItem>
                    <SelectItem value="3pm">3:00 PM - 4:00 PM</SelectItem>
                  </SelectContent>
                </Select>
                <Select>
                  <SelectTrigger>
                    <SelectValue placeholder="Select Lab Location" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="kabul">Kabul Central Lab</SelectItem>
                    <SelectItem value="herat">Herat Medical Lab</SelectItem>
                    <SelectItem value="mazar">Mazar-i-Sharif Lab</SelectItem>
                    <SelectItem value="kandahar">Kandahar Diagnostic Center</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <Button className="w-full bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-600 hover:to-blue-700">
                <CheckCircle className="w-4 h-4 mr-2" />
                Confirm Booking
              </Button>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </section>
  );
}

export default LabTestBooking;
