import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Code, X, Stethoscope, Shield, Users, MessageCircle, Settings, Home, LogIn, LogOut } from 'lucide-react';
import { Button } from './ui/button';

interface QuickAccessPanelProps {
  currentPage: string;
  userEmail: string;
  isAuthenticated: boolean;
  onNavigate: (page: string) => void;
  onLogin: () => void;
  onLogout: () => void;
  language: 'ps' | 'fa' | 'en';
}

export function QuickAccessPanel({ 
  currentPage, 
  userEmail, 
  isAuthenticated, 
  onNavigate, 
  onLogin, 
  onLogout,
  language 
}: QuickAccessPanelProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [showDevMode, setShowDevMode] = useState(false);

  // Show panel with keyboard shortcut: Ctrl+Shift+D
  useEffect(() => {
    const handleKeyPress = (e: KeyboardEvent) => {
      if (e.ctrlKey && e.shiftKey && e.key === 'D') {
        e.preventDefault();
        setIsOpen(!isOpen);
      }
    };
    window.addEventListener('keydown', handleKeyPress);
    return () => window.removeEventListener('keydown', handleKeyPress);
  }, [isOpen]);

  const isAdmin = userEmail === 'ibrahimkhaksar.it@gmail.com';

  const quickActions = [
    { 
      id: 'home', 
      label: language === 'ps' ? 'کور' : language === 'fa' ? 'خانه' : 'Home', 
      icon: Home, 
      page: 'home',
      color: 'blue'
    },
    { 
      id: 'doctors', 
      label: language === 'ps' ? 'دوکتوران' : language === 'fa' ? 'دکتران' : 'Doctors', 
      icon: Stethoscope, 
      page: 'doctors',
      color: 'cyan'
    },
    { 
      id: 'community', 
      label: language === 'ps' ? 'ټولنه' : language === 'fa' ? 'انجمن' : 'Community', 
      icon: MessageCircle, 
      page: 'community',
      color: 'purple'
    },
    { 
      id: 'settings', 
      label: language === 'ps' ? 'تنظیمات' : language === 'fa' ? 'تنظیمات' : 'Settings', 
      icon: Settings, 
      page: 'settings',
      color: 'gray'
    },
  ];

  if (isAdmin) {
    quickActions.push({ 
      id: 'admin', 
      label: 'Admin Panel', 
      icon: Shield, 
      page: 'admin',
      color: 'red'
    });
  }

  const setupAdmin = () => {
    localStorage.setItem('healmate_userEmail', 'ibrahimkhaksar.it@gmail.com');
    localStorage.setItem('healmate_userName', 'Ibrahim Khaksar');
    localStorage.setItem('healmate_isAuthenticated', 'true');
    alert('✅ Admin setup complete! Refreshing...');
    window.location.reload();
  };

  const setupTestUser = () => {
    localStorage.setItem('healmate_userEmail', 'test@healmate.com');
    localStorage.setItem('healmate_userName', 'Test User');
    localStorage.setItem('healmate_isAuthenticated', 'true');
    alert('✅ Test user setup complete! Refreshing...');
    window.location.reload();
  };

  const clearStorage = () => {
    if (confirm('Clear all localStorage data?')) {
      localStorage.clear();
      alert('✅ Storage cleared! Refreshing...');
      window.location.reload();
    }
  };

  return (
    <>
      {/* Toggle Button */}
      <motion.button
        onClick={() => setIsOpen(!isOpen)}
        className="fixed bottom-24 right-4 z-50 bg-gradient-to-r from-purple-600 to-pink-600 text-white p-3 rounded-full shadow-lg hover:shadow-xl transition-all"
        whileHover={{ scale: 1.1 }}
        whileTap={{ scale: 0.95 }}
        title="Quick Access (Ctrl+Shift+D)"
      >
        <Code className="w-5 h-5" />
      </motion.button>

      {/* Panel */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, x: 300 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: 300 }}
            className="fixed right-4 bottom-24 z-50 w-80 bg-white rounded-3xl shadow-2xl border border-gray-200 overflow-hidden"
          >
            {/* Header */}
            <div className="bg-gradient-to-r from-purple-600 to-pink-600 text-white p-4 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Code className="w-5 h-5" />
                <h3 className="font-semibold">Quick Access</h3>
              </div>
              <button onClick={() => setIsOpen(false)} className="hover:bg-white/20 p-1 rounded-lg">
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Content */}
            <div className="p-4 max-h-[500px] overflow-y-auto space-y-4">
              {/* Status */}
              <div className="bg-gray-50 rounded-xl p-3 text-sm space-y-1">
                <div className="flex items-center justify-between">
                  <span className="text-gray-600">Status:</span>
                  <span className={`font-semibold ${isAuthenticated ? 'text-green-600' : 'text-gray-400'}`}>
                    {isAuthenticated ? '✅ Logged In' : '❌ Guest'}
                  </span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-gray-600">Email:</span>
                  <span className="font-mono text-xs">{userEmail || 'None'}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-gray-600">Page:</span>
                  <span className="font-semibold text-purple-600">{currentPage}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-gray-600">Admin:</span>
                  <span className={`font-semibold ${isAdmin ? 'text-red-600' : 'text-gray-400'}`}>
                    {isAdmin ? '✅ Yes' : '❌ No'}
                  </span>
                </div>
              </div>

              {/* Quick Navigation */}
              <div>
                <p className="text-xs text-gray-500 mb-2 font-semibold uppercase">Navigation</p>
                <div className="grid grid-cols-2 gap-2">
                  {quickActions.map((action) => {
                    const Icon = action.icon;
                    return (
                      <button
                        key={action.id}
                        onClick={() => {
                          onNavigate(action.page);
                          setIsOpen(false);
                        }}
                        className={`flex flex-col items-center gap-2 p-3 rounded-xl transition-all ${
                          currentPage === action.page
                            ? `bg-${action.color}-50 border-2 border-${action.color}-500`
                            : 'bg-gray-50 hover:bg-gray-100 border-2 border-transparent'
                        }`}
                      >
                        <Icon className={`w-6 h-6 text-${action.color}-600`} />
                        <span className="text-xs font-medium">{action.label}</span>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Auth Actions */}
              {!isAuthenticated && (
                <div>
                  <p className="text-xs text-gray-500 mb-2 font-semibold uppercase">Authentication</p>
                  <div className="space-y-2">
                    <Button 
                      onClick={setupAdmin} 
                      className="w-full bg-gradient-to-r from-red-500 to-pink-600 text-white"
                      size="sm"
                    >
                      <Shield className="w-4 h-4 mr-2" />
                      Login as Admin
                    </Button>
                    <Button 
                      onClick={setupTestUser} 
                      className="w-full bg-gradient-to-r from-blue-500 to-cyan-600 text-white"
                      size="sm"
                    >
                      <Users className="w-4 h-4 mr-2" />
                      Login as Test User
                    </Button>
                  </div>
                </div>
              )}

              {isAuthenticated && (
                <div>
                  <p className="text-xs text-gray-500 mb-2 font-semibold uppercase">Account</p>
                  <Button 
                    onClick={onLogout} 
                    variant="outline"
                    className="w-full border-red-200 text-red-600 hover:bg-red-50"
                    size="sm"
                  >
                    <LogOut className="w-4 h-4 mr-2" />
                    Logout
                  </Button>
                </div>
              )}

              {/* Dev Tools */}
              <div>
                <button
                  onClick={() => setShowDevMode(!showDevMode)}
                  className="text-xs text-gray-500 hover:text-gray-700 font-semibold uppercase mb-2 flex items-center gap-1"
                >
                  Developer Tools
                  <span className="text-[10px]">{showDevMode ? '▼' : '▶'}</span>
                </button>
                
                {showDevMode && (
                  <div className="space-y-2">
                    <Button 
                      onClick={clearStorage} 
                      variant="outline"
                      className="w-full text-xs"
                      size="sm"
                    >
                      Clear localStorage
                    </Button>
                    <Button 
                      onClick={() => {
                        const debug = {
                          email: localStorage.getItem('healmate_userEmail'),
                          name: localStorage.getItem('healmate_userName'),
                          authenticated: localStorage.getItem('healmate_isAuthenticated'),
                          posts: JSON.parse(localStorage.getItem('healmate_posts') || '[]').length,
                          users: JSON.parse(localStorage.getItem('healmate_users') || '[]').length
                        };
                        console.table(debug);
                        alert('Debug info logged to console (F12)');
                      }} 
                      variant="outline"
                      className="w-full text-xs"
                      size="sm"
                    >
                      Log Debug Info
                    </Button>
                  </div>
                )}
              </div>

              {/* Instructions */}
              <div className="bg-purple-50 rounded-xl p-3 text-xs text-gray-600 border border-purple-200">
                <p className="font-semibold mb-1 text-purple-800">💡 Tips:</p>
                <ul className="space-y-1 text-[11px]">
                  <li>• Press <kbd className="bg-white px-1 rounded">Ctrl+Shift+D</kbd> to toggle</li>
                  <li>• Click navigation buttons for quick access</li>
                  <li>• "Login as Admin" for full access</li>
                  <li>• "Clear localStorage" to reset app</li>
                </ul>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
