import { motion, AnimatePresence } from 'motion/react';
import { Heart, Sparkles, Activity, Shield, Users, Brain } from 'lucide-react';
import { useState, useEffect } from 'react';
import healmateLogoSrc from 'figma:asset/ba48654895779a4ce2efe10c107b371087cee470.png';

interface SplashScreenProps {
  onComplete: () => void;
}

export function SplashScreen({ onComplete }: SplashScreenProps) {
  const [progress, setProgress] = useState(0);
  const [phase, setPhase] = useState(0);

  useEffect(() => {
    // Progress animation
    const progressInterval = setInterval(() => {
      setProgress(prev => {
        if (prev >= 100) {
          clearInterval(progressInterval);
          return 100;
        }
        return prev + 2;
      });
    }, 30);

    // Phase transitions - Extended timing for better readability
    const phaseTimeout1 = setTimeout(() => setPhase(1), 1000);
    const phaseTimeout2 = setTimeout(() => setPhase(2), 2000);
    const completeTimeout = setTimeout(() => {
      onComplete();
    }, 4500); // Extended to 4.5 seconds for better app name readability

    return () => {
      clearInterval(progressInterval);
      clearTimeout(phaseTimeout1);
      clearTimeout(phaseTimeout2);
      clearTimeout(completeTimeout);
    };
  }, [onComplete]);

  return (
    <motion.div
      initial={{ opacity: 1 }}
      exit={{ opacity: 0, scale: 1.1 }}
      transition={{ duration: 0.6, ease: [0.43, 0.13, 0.23, 0.96] }}
      className="fixed inset-0 z-[9999] flex flex-col items-center justify-center overflow-hidden"
    >
      {/* Modern Gradient Background - Instagram/TikTok Style */}
      <div className="absolute inset-0">
        {/* Base Gradient */}
        <motion.div 
          animate={{
            backgroundPosition: ['0% 0%', '100% 100%', '0% 0%'],
          }}
          transition={{
            duration: 8,
            repeat: Infinity,
            ease: "linear"
          }}
          className="absolute inset-0 bg-gradient-to-br from-emerald-400 via-teal-500 to-cyan-600"
          style={{
            backgroundSize: '400% 400%'
          }}
        />

        {/* Mesh Gradient Overlays - Modern Style */}
        <div className="absolute inset-0 opacity-60">
          <motion.div
            animate={{
              scale: [1, 1.2, 1],
              x: [0, 100, 0],
              y: [0, -50, 0],
            }}
            transition={{
              duration: 8,
              repeat: Infinity,
              ease: "easeInOut"
            }}
            className="absolute -top-20 -left-20 w-96 h-96 bg-gradient-to-br from-pink-400 to-rose-500 rounded-full mix-blend-multiply filter blur-3xl opacity-70"
          />
          <motion.div
            animate={{
              scale: [1.2, 1, 1.2],
              x: [0, -80, 0],
              y: [0, 100, 0],
            }}
            transition={{
              duration: 10,
              repeat: Infinity,
              ease: "easeInOut"
            }}
            className="absolute -top-20 -right-20 w-96 h-96 bg-gradient-to-br from-purple-400 to-indigo-500 rounded-full mix-blend-multiply filter blur-3xl opacity-70"
          />
          <motion.div
            animate={{
              scale: [1, 1.3, 1],
              x: [0, 50, 0],
              y: [0, -100, 0],
            }}
            transition={{
              duration: 12,
              repeat: Infinity,
              ease: "easeInOut"
            }}
            className="absolute -bottom-20 left-1/2 -translate-x-1/2 w-96 h-96 bg-gradient-to-br from-orange-400 to-amber-500 rounded-full mix-blend-multiply filter blur-3xl opacity-70"
          />
        </div>

        {/* Subtle Grid Pattern */}
        <div className="absolute inset-0 opacity-[0.03]" style={{
          backgroundImage: `radial-gradient(circle at 2px 2px, white 1px, transparent 0)`,
          backgroundSize: '40px 40px'
        }} />
      </div>

      {/* Floating Particles - Instagram Style */}
      {[...Array(15)].map((_, i) => (
        <motion.div
          key={i}
          className="absolute"
          initial={{
            x: Math.random() * window.innerWidth,
            y: window.innerHeight + 50,
            scale: 0,
          }}
          animate={{
            y: -100,
            scale: [0, 1, 1, 0],
            opacity: [0, 0.6, 0.6, 0],
            x: Math.random() * window.innerWidth,
          }}
          transition={{
            duration: 3 + Math.random() * 2,
            repeat: Infinity,
            delay: Math.random() * 3,
            ease: "easeOut",
          }}
        >
          <div className="w-1 h-1 bg-white rounded-full" />
        </motion.div>
      ))}

      {/* Main Content Container */}
      <div className="relative z-10 flex flex-col items-center justify-center px-4 sm:px-8">
        
        {/* Logo Container - Facebook/Instagram Style */}
        <motion.div
          initial={{ scale: 0, opacity: 0 }}
          animate={{ 
            scale: 1, 
            opacity: 1,
          }}
          transition={{
            type: "spring",
            stiffness: 200,
            damping: 20,
            duration: 0.8,
          }}
          className="relative mb-6 sm:mb-8"
        >
          {/* Outer Glow Ring */}
          <motion.div
            animate={{
              scale: [1, 1.15, 1],
              opacity: [0.5, 0.8, 0.5],
            }}
            transition={{
              duration: 2,
              repeat: Infinity,
              ease: "easeInOut"
            }}
            className="absolute inset-0 -m-8 sm:-m-12 rounded-full bg-white/20 blur-2xl"
          />

          {/* Middle Ring */}
          <motion.div
            animate={{
              rotate: 360,
            }}
            transition={{
              duration: 20,
              repeat: Infinity,
              ease: "linear"
            }}
            className="absolute inset-0 -m-4 sm:-m-6"
          >
            <div className="w-full h-full rounded-full bg-gradient-to-tr from-white/30 via-transparent to-white/10 blur-sm" />
          </motion.div>

          {/* Logo Background - Glassmorphism */}
          <motion.div
            animate={{
              boxShadow: [
                "0 0 80px rgba(255,255,255,0.3)",
                "0 0 120px rgba(255,255,255,0.5)",
                "0 0 80px rgba(255,255,255,0.3)",
              ],
            }}
            transition={{
              duration: 2,
              repeat: Infinity,
              ease: "easeInOut"
            }}
            className="relative bg-white/25 backdrop-blur-2xl p-6 sm:p-8 md:p-10 rounded-[1.5rem] sm:rounded-[2rem] md:rounded-[2.5rem] border-2 sm:border-3 md:border-4 border-white/40 shadow-2xl"
          >
            {/* Animated Logo */}
            <motion.div
              animate={{
                scale: [1, 1.05, 1],
              }}
              transition={{
                duration: 1.5,
                repeat: Infinity,
                ease: "easeInOut"
              }}
              className="relative"
            >
              <div className="flex items-center justify-center bg-white/10 backdrop-blur-xl rounded-3xl p-6 border border-white/20">
                <img 
                  src={healmateLogoSrc} 
                  alt="HealMate Logo"
                  className="w-24 h-24 sm:w-28 sm:h-28 md:w-32 md:h-32 lg:w-36 lg:h-36 object-contain"
                  style={{
                    filter: 'drop-shadow(0 10px 40px rgba(255,255,255,0.5)) drop-shadow(0 0 20px rgba(255,255,255,0.7))',
                    imageRendering: '-webkit-optimize-contrast',
                    WebkitFontSmoothing: 'antialiased',
                    mixBlendMode: 'normal',
                    background: 'transparent'
                  }}
                />
              </div>
              
              {/* Pulse Effect */}
              <motion.div
                animate={{
                  scale: [1, 1.3, 1],
                  opacity: [0.6, 0, 0.6],
                }}
                transition={{
                  duration: 2.5,
                  repeat: Infinity,
                  ease: "easeOut"
                }}
                className="absolute inset-0 flex items-center justify-center pointer-events-none"
              >
                <div className="w-32 h-32 sm:w-36 sm:h-36 md:w-40 md:h-40 lg:w-44 lg:h-44 border-4 border-white/40 rounded-3xl" />
              </motion.div>
            </motion.div>

            {/* Orbiting Icons */}
            {[
              { Icon: Activity, angle: 0, delay: 0, color: 'from-pink-300 to-rose-300' },
              { Icon: Shield, angle: 90, delay: 0.2, color: 'from-purple-300 to-indigo-300' },
              { Icon: Users, angle: 180, delay: 0.4, color: 'from-cyan-300 to-blue-300' },
              { Icon: Brain, angle: 270, delay: 0.6, color: 'from-orange-300 to-amber-300' },
            ].map(({ Icon, angle, delay, color }, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, scale: 0 }}
                animate={{
                  opacity: phase >= 1 ? [0, 1, 1] : 0,
                  scale: phase >= 1 ? [0, 1, 1] : 0,
                  x: Math.cos((angle * Math.PI) / 180) * (window.innerWidth < 640 ? 55 : window.innerWidth < 768 ? 70 : 85),
                  y: Math.sin((angle * Math.PI) / 180) * (window.innerWidth < 640 ? 55 : window.innerWidth < 768 ? 70 : 85),
                  rotate: [0, 360],
                }}
                transition={{
                  opacity: { duration: 0.5, delay },
                  scale: { duration: 0.5, delay },
                  rotate: { duration: 20, repeat: Infinity, ease: "linear" },
                }}
                className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2"
              >
                <div className={`bg-gradient-to-br ${color} p-2 sm:p-2.5 md:p-3 rounded-xl sm:rounded-xl md:rounded-2xl shadow-lg backdrop-blur-sm border-2 border-white/50`}>
                  <Icon className="w-3 h-3 sm:w-4 sm:h-4 md:w-5 md:h-5 text-white" strokeWidth={2.5} />
                </div>
              </motion.div>
            ))}

            {/* Sparkles */}
            {[...Array(8)].map((_, i) => (
              <motion.div
                key={`sparkle-${i}`}
                initial={{ opacity: 0, scale: 0 }}
                animate={{
                  opacity: phase >= 2 ? [0, 1, 0] : 0,
                  scale: phase >= 2 ? [0, 1.5, 0] : 0,
                  x: Math.cos((i * 45 * Math.PI) / 180) * (window.innerWidth < 640 ? 45 : window.innerWidth < 768 ? 55 : 70),
                  y: Math.sin((i * 45 * Math.PI) / 180) * (window.innerWidth < 640 ? 45 : window.innerWidth < 768 ? 55 : 70),
                }}
                transition={{
                  duration: 1.5,
                  repeat: Infinity,
                  delay: i * 0.1,
                  ease: "easeOut",
                }}
                className="absolute top-1/2 left-1/2"
              >
                <Sparkles className="w-3 h-3 sm:w-4 sm:h-4 md:w-5 md:h-5 text-white drop-shadow-lg" fill="white" />
              </motion.div>
            ))}
          </motion.div>
        </motion.div>

        {/* App Name - Modern Typography - Optimized for Readability */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ 
            delay: 0.5, 
            duration: 1,
            ease: [0.43, 0.13, 0.23, 0.96]
          }}
          className="text-center mb-4 sm:mb-6"
        >
          <motion.h1
            animate={{
              textShadow: [
                '0 4px 30px rgba(0,0,0,0.4), 0 0 60px rgba(255,255,255,0.3)',
                '0 4px 40px rgba(0,0,0,0.5), 0 0 80px rgba(255,255,255,0.4)',
                '0 4px 30px rgba(0,0,0,0.4), 0 0 60px rgba(255,255,255,0.3)',
              ]
            }}
            transition={{
              duration: 2,
              repeat: Infinity,
              ease: "easeInOut"
            }}
            className="text-5xl sm:text-6xl md:text-7xl lg:text-8xl xl:text-9xl font-black text-white mb-3 sm:mb-4 tracking-tight drop-shadow-2xl leading-none"
            style={{
              textShadow: '0 4px 30px rgba(0,0,0,0.4), 0 0 60px rgba(255,255,255,0.3)',
              letterSpacing: '-0.02em'
            }}
          >
            HealMate
          </motion.h1>
          
          <motion.div
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.7 }}
            className="inline-flex items-center gap-2 sm:gap-3 bg-white/20 backdrop-blur-md px-4 sm:px-6 md:px-8 py-2 sm:py-3 md:py-4 rounded-full border border-white/30"
          >
            <div className="flex items-center gap-2 sm:gap-3">
              <div className="w-2 h-2 sm:w-2.5 sm:h-2.5 md:w-3 md:h-3 bg-green-400 rounded-full animate-pulse" />
              <span className="text-white/95 text-sm sm:text-base md:text-xl lg:text-2xl font-semibold tracking-wide">
                د افغانستان لومړنی روغتیا اپلیکیشن
              </span>
            </div>
          </motion.div>
        </motion.div>

        {/* Modern Progress Bar - TikTok/Instagram Style */}
        <motion.div
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.9 }}
          className="w-48 sm:w-64 md:w-80 mb-6 sm:mb-8 md:mb-10"
        >
          <div className="relative h-1.5 sm:h-2 bg-white/20 rounded-full overflow-hidden backdrop-blur-sm border border-white/20">
            <motion.div
              initial={{ width: '0%' }}
              animate={{ width: `${progress}%` }}
              transition={{ duration: 0.3, ease: "easeOut" }}
              className="h-full bg-gradient-to-r from-white via-white to-white/80 rounded-full relative"
            >
              {/* Shimmer Effect */}
              <motion.div
                animate={{
                  x: ['-100%', '200%'],
                }}
                transition={{
                  duration: 1.5,
                  repeat: Infinity,
                  ease: "linear"
                }}
                className="absolute inset-0 bg-gradient-to-r from-transparent via-white/50 to-transparent"
              />
            </motion.div>
          </div>
          
          {/* Loading Percentage */}
          <motion.p
            animate={{ opacity: [0.5, 1, 0.5] }}
            transition={{ duration: 1.5, repeat: Infinity }}
            className="text-white/70 text-base sm:text-lg md:text-xl text-center mt-2 sm:mt-3 md:mt-4 font-medium tracking-wider"
          >
            {Math.round(progress)}%
          </motion.p>
        </motion.div>

        {/* Tagline - Multilingual */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1.2 }}
          className="text-center space-y-2 sm:space-y-3 px-4"
        >
          <p className="text-white text-lg sm:text-xl md:text-2xl lg:text-3xl font-semibold tracking-wide drop-shadow-lg">
            Your Health, Our Priority
          </p>
          <p className="text-white/90 text-base sm:text-lg md:text-xl lg:text-2xl font-medium leading-relaxed">
            ستاسو روغتیا، زموږ لومړیتوب • سلامتی شما، اولویت ما
          </p>
        </motion.div>
      </div>

      {/* Decorative Wave - Bottom */}
      <div className="absolute bottom-0 left-0 right-0 overflow-hidden">
        <motion.svg
          initial={{ opacity: 0 }}
          animate={{ opacity: 0.1 }}
          transition={{ delay: 1 }}
          viewBox="0 0 1440 120"
          className="w-full h-auto"
          preserveAspectRatio="none"
        >
          <motion.path
            animate={{
              d: [
                "M0,64L48,69.3C96,75,192,85,288,80C384,75,480,53,576,48C672,43,768,53,864,58.7C960,64,1056,64,1152,58.7C1248,53,1344,43,1392,37.3L1440,32L1440,120L0,120Z",
                "M0,32L48,42.7C96,53,192,75,288,80C384,85,480,75,576,64C672,53,768,43,864,48C960,53,1056,75,1152,80C1248,85,1344,75,1392,69.3L1440,64L1440,120L0,120Z",
                "M0,64L48,69.3C96,75,192,85,288,80C384,75,480,53,576,48C672,43,768,53,864,58.7C960,64,1056,64,1152,58.7C1248,53,1344,43,1392,37.3L1440,32L1440,120L0,120Z",
              ]
            }}
            transition={{
              duration: 5,
              repeat: Infinity,
              ease: "easeInOut"
            }}
            fill="white"
          />
        </motion.svg>
      </div>
    </motion.div>
  );
}