import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "./ui/card";
import { Badge } from "./ui/badge";
import { Separator } from "./ui/separator";
import { 
  CheckCircle, 
  AlertCircle, 
  Smartphone, 
  DollarSign,
  Eye,
  Settings,
  Shield,
  Zap
} from "lucide-react";

export function AdMobQuickGuide() {
  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
      {/* Quick Steps */}
      <Card className="glass-effect border-emerald-200">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <CheckCircle className="w-5 h-5 text-emerald-600" />
            چټک لارښود / Quick Guide
          </CardTitle>
          <CardDescription>د Setup لپاره ساده قدمونه</CardDescription>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="flex gap-3">
            <div className="flex-shrink-0 w-6 h-6 bg-emerald-100 rounded-full flex items-center justify-center text-emerald-600 text-sm">
              1
            </div>
            <div>
              <p className="text-sm">د Google AdMob Console کې Sign in کړئ</p>
              <p className="text-xs text-gray-500">https://admob.google.com</p>
            </div>
          </div>
          
          <Separator />
          
          <div className="flex gap-3">
            <div className="flex-shrink-0 w-6 h-6 bg-emerald-100 rounded-full flex items-center justify-center text-emerald-600 text-sm">
              2
            </div>
            <div>
              <p className="text-sm">نوی App اضافه کړئ (Android او iOS)</p>
              <p className="text-xs text-gray-500">HealMate نوم ورکړئ</p>
            </div>
          </div>
          
          <Separator />
          
          <div className="flex gap-3">
            <div className="flex-shrink-0 w-6 h-6 bg-emerald-100 rounded-full flex items-center justify-center text-emerald-600 text-sm">
              3
            </div>
            <div>
              <p className="text-sm">Ad Units جوړ کړئ</p>
              <p className="text-xs text-gray-500">Banner, Interstitial, Rewarded</p>
            </div>
          </div>
          
          <Separator />
          
          <div className="flex gap-3">
            <div className="flex-shrink-0 w-6 h-6 bg-emerald-100 rounded-full flex items-center justify-center text-emerald-600 text-sm">
              4
            </div>
            <div>
              <p className="text-sm">IDs کاپي او دلته پیسټ کړئ</p>
              <p className="text-xs text-gray-500">Android او iOS tabs کې</p>
            </div>
          </div>
          
          <Separator />
          
          <div className="flex gap-3">
            <div className="flex-shrink-0 w-6 h-6 bg-emerald-100 rounded-full flex items-center justify-center text-emerald-600 text-sm">
              5
            </div>
            <div>
              <p className="text-sm">Save Changes کلیک کړئ</p>
              <p className="text-xs text-gray-500">تنظیمات خوندي کیږي</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* ID Format Info */}
      <Card className="glass-effect border-blue-200">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <AlertCircle className="w-5 h-5 text-blue-600" />
            د IDs فارمټ / ID Format
          </CardTitle>
          <CardDescription>د AdMob IDs ښکارندویی</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="p-3 bg-blue-50 rounded-lg">
            <p className="text-xs text-blue-700 mb-2">App ID Format:</p>
            <code className="text-xs font-mono bg-white p-2 rounded block break-all">
              ca-app-pub-XXXXXXXXXXXXXXXX~XXXXXXXXXX
            </code>
            <Badge variant="secondary" className="mt-2">
              ~ (tilde) کاروي
            </Badge>
          </div>

          <div className="p-3 bg-purple-50 rounded-lg">
            <p className="text-xs text-purple-700 mb-2">Ad Unit ID Format:</p>
            <code className="text-xs font-mono bg-white p-2 rounded block break-all">
              ca-app-pub-XXXXXXXXXXXXXXXX/XXXXXXXXXX
            </code>
            <Badge variant="secondary" className="mt-2">
              / (slash) کاروي
            </Badge>
          </div>

          <div className="p-3 bg-amber-50 rounded-lg border border-amber-200">
            <div className="flex items-start gap-2">
              <AlertCircle className="w-4 h-4 text-amber-600 flex-shrink-0 mt-0.5" />
              <div>
                <p className="text-xs text-amber-900">
                  <strong>یادښت:</strong> د App ID په آخر کې ~ او د Ad Unit IDs په آخر کې / وي.
                </p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Test vs Production */}
      <Card className="glass-effect border-purple-200">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Settings className="w-5 h-5 text-purple-600" />
            Test vs Production
          </CardTitle>
          <CardDescription>د حالت توپیر</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="p-3 bg-green-50 border border-green-200 rounded-lg">
            <div className="flex items-center gap-2 mb-2">
              <Eye className="w-4 h-4 text-green-600" />
              <p className="text-sm text-green-900">Test Mode</p>
            </div>
            <ul className="space-y-1 text-xs text-green-800">
              <li>✓ د Google Test IDs کاروي</li>
              <li>✓ د Development لپاره</li>
              <li>✓ هیڅ ریښتیني پیسې نه</li>
              <li>✓ د ټیسټ لپاره خوندي</li>
            </ul>
          </div>

          <div className="p-3 bg-blue-50 border border-blue-200 rounded-lg">
            <div className="flex items-center gap-2 mb-2">
              <DollarSign className="w-4 h-4 text-blue-600" />
              <p className="text-sm text-blue-900">Production Mode</p>
            </div>
            <ul className="space-y-1 text-xs text-blue-800">
              <li>✓ خپل اصلي IDs کاروي</li>
              <li>✓ د Published اپ لپاره</li>
              <li>✓ ریښتیني عواید راځي</li>
              <li>✓ Google AdMob Account ته اړتیا</li>
            </ul>
          </div>
        </CardContent>
      </Card>

      {/* Ad Types */}
      <Card className="glass-effect border-amber-200">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Zap className="w-5 h-5 text-amber-600" />
            د اعلاناتو ډولونه / Ad Types
          </CardTitle>
          <CardDescription>د هر ډول ښکارندویی</CardDescription>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="flex items-start gap-3">
            <Smartphone className="w-5 h-5 text-emerald-600 flex-shrink-0 mt-0.5" />
            <div>
              <p className="text-sm">Banner Ads</p>
              <p className="text-xs text-gray-500">320×50 او 320×250 سایز</p>
              <p className="text-xs text-gray-500">د صفحې په لاندې برخه</p>
            </div>
          </div>

          <Separator />

          <div className="flex items-start gap-3">
            <Smartphone className="w-5 h-5 text-blue-600 flex-shrink-0 mt-0.5" />
            <div>
              <p className="text-sm">Interstitial Ads</p>
              <p className="text-xs text-gray-500">Full-screen تبلیغات</p>
              <p className="text-xs text-gray-500">د صفحو تر منځ ښکاره</p>
            </div>
          </div>

          <Separator />

          <div className="flex items-start gap-3">
            <Smartphone className="w-5 h-5 text-purple-600 flex-shrink-0 mt-0.5" />
            <div>
              <p className="text-sm">Rewarded Ads</p>
              <p className="text-xs text-gray-500">د انعام سره ویډیو</p>
              <p className="text-xs text-gray-500">کاروونکي ګوري = انعام</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Security Tips */}
      <Card className="glass-effect border-red-200 lg:col-span-2">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Shield className="w-5 h-5 text-red-600" />
            د امنیت لارښودونه / Security Tips
          </CardTitle>
          <CardDescription>خپل AdMob IDs خوندي وساتئ</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid md:grid-cols-2 gap-4">
            <div className="p-3 bg-red-50 border border-red-200 rounded-lg">
              <div className="flex items-start gap-2">
                <AlertCircle className="w-4 h-4 text-red-600 flex-shrink-0 mt-0.5" />
                <div className="space-y-1">
                  <p className="text-sm text-red-900">مه کوئ / DON'T:</p>
                  <ul className="text-xs text-red-800 space-y-0.5">
                    <li>• د خپلو IDs هیچا ته مه ورکوئ</li>
                    <li>• په Public repos کې commit مه کوئ</li>
                    <li>• په خپلو ads باندې کلیک مه کوئ</li>
                    <li>• د Production کې Test IDs مه کاروئ</li>
                  </ul>
                </div>
              </div>
            </div>

            <div className="p-3 bg-green-50 border border-green-200 rounded-lg">
              <div className="flex items-start gap-2">
                <CheckCircle className="w-4 h-4 text-green-600 flex-shrink-0 mt-0.5" />
                <div className="space-y-1">
                  <p className="text-sm text-green-900">وکړئ / DO:</p>
                  <ul className="text-xs text-green-800 space-y-0.5">
                    <li>• پاسورډ بدله کړئ</li>
                    <li>• د Google Policies تعقیب کړئ</li>
                    <li>• د Performance څارنه وکړئ</li>
                    <li>• د User Experience پام وکړئ</li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
