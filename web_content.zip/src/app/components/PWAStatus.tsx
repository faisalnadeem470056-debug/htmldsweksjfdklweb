import { useState, useEffect } from 'react';
import { Wifi, WifiOff, Download, CheckCircle, AlertCircle } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { pwaManager } from '../utils/pwaManager';

interface PWAStatusProps {
  language: 'ps' | 'fa' | 'en';
}

export function PWAStatus({ language }: PWAStatusProps) {
  const [isOnline, setIsOnline] = useState(navigator.onLine);
  const [isInstalled, setIsInstalled] = useState(false);
  const [showStatus, setShowStatus] = useState(false);

  useEffect(() => {
    // د Install status check کول
    const installed = window.matchMedia('(display-mode: standalone)').matches;
    setIsInstalled(installed);

    // د Network status monitoring
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  const translations = {
    ps: {
      online: 'آنلاین',
      offline: 'آفلاین',
      installed: 'نصب شوی',
      notInstalled: 'نصب نه دی'
    },
    fa: {
      online: 'آنلاین',
      offline: 'آفلاین',
      installed: 'نصب شده',
      notInstalled: 'نصب نشده'
    },
    en: {
      online: 'Online',
      offline: 'Offline',
      installed: 'Installed',
      notInstalled: 'Not Installed'
    }
  };

  const t = translations[language];

  // یوازې په development کې وښایئ (یا که offline وي)
  const shouldShow = !isOnline || process.env.NODE_ENV === 'development';

  if (!shouldShow && !showStatus) return null;

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        exit={{ opacity: 0, y: -20 }}
        className="fixed top-2 right-2 z-[99] flex gap-2"
      >
        {/* Network Status */}
        {!isOnline && (
          <div className="bg-red-500 text-white px-3 py-1.5 rounded-full text-xs font-bold flex items-center gap-2 shadow-lg">
            <WifiOff className="w-3 h-3" />
            {t.offline}
          </div>
        )}

        {/* Install Status - فقط په development کې */}
        {process.env.NODE_ENV === 'development' && (
          <div 
            className={`${
              isInstalled ? 'bg-green-500' : 'bg-orange-500'
            } text-white px-3 py-1.5 rounded-full text-xs font-bold flex items-center gap-2 shadow-lg cursor-pointer`}
            onClick={() => setShowStatus(!showStatus)}
          >
            {isInstalled ? (
              <>
                <CheckCircle className="w-3 h-3" />
                PWA {t.installed}
              </>
            ) : (
              <>
                <Download className="w-3 h-3" />
                PWA {t.notInstalled}
              </>
            )}
          </div>
        )}
      </motion.div>
    </AnimatePresence>
  );
}
