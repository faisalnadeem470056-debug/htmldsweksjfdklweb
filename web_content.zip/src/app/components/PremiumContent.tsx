import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Crown, Lock, Download, BookOpen, FileText, Video, 
  Headphones, Star, Heart, Share2, Bookmark, Eye,
  CheckCircle, Play, Pause, Volume2, VolumeX, ArrowLeft,
  Filter, Search, X, ChevronRight, Sparkles, Award, Trophy
} from 'lucide-react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { PremiumBadge, PremiumLock } from './PremiumBadge';
import { usePremium } from '../hooks/usePremium';
import { ImageWithFallback } from './figma/ImageWithFallback';
import { ShareModal } from './ShareModal';

interface PremiumContentProps {
  language: 'ps' | 'fa' | 'en';
  currentUser: any;
  onBack: () => void;
  onUpgrade: () => void;
}

interface PremiumPost {
  id: string;
  userId: string;
  userName: string;
  userAvatar: string;
  isPremiumUser: boolean;
  content: string;
  images: string[];
  isPremiumContent: boolean;
  category: string;
  views: number;
  likes: number;
  bookmarks: number;
  timestamp: string;
}

interface PremiumHealthContent {
  id: string;
  title: { ps: string; fa: string; en: string };
  description: { ps: string; fa: string; en: string };
  category: string;
  type: 'article' | 'video' | 'audio';
  duration?: string;
  author: string;
  image: string;
  isPremium: boolean;
  views: number;
  likes: number;
  downloadUrl?: string;
}

interface PremiumBook {
  id: string;
  title: { ps: string; fa: string; en: string };
  author: { ps: string; fa: string; en: string };
  description: { ps: string; fa: string; en: string };
  category: string;
  pages: number;
  size: string;
  language: string;
  cover: string;
  isPremium: boolean;
  downloads: number;
  rating: number;
  downloadUrl: string;
}

export function PremiumContent({ language, currentUser, onBack, onUpgrade }: PremiumContentProps) {
  const [activeTab, setActiveTab] = useState<'posts' | 'health' | 'books'>('posts');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [selectedContent, setSelectedContent] = useState<any>(null);
  const [showDetail, setShowDetail] = useState(false);
  const [shareModalOpen, setShareModalOpen] = useState(false);
  const [sharingContent, setSharingContent] = useState<any>(null);

  const { isPremium } = usePremium(currentUser?.id);

  const t = {
    ps: {
      title: 'Premium مینځپانګه',
      subtitle: 'د ځانګړو مینځپانګو ته لاسرسی ومومئ',
      posts: 'پوستونه',
      health: 'روغتیا مینځپانګه',
      books: 'کتابونه',
      search: 'لټون...',
      filter: 'فلټر',
      all: 'ټول',
      locked: 'بند شوی',
      unlocked: 'خلاص شوی',
      viewDetails: 'تفصیلات وګورئ',
      download: 'ډاونلوډ',
      play: 'غږول',
      read: 'لوستل',
      watch: 'کتل',
      listen: 'اورېدل',
      bookmark: 'نښه ایښودل',
      share: 'شریکول',
      like: 'خوښول',
      views: 'لیدونه',
      likes: 'خوښونه',
      downloads: 'ډاونلوډونه',
      bookmarks: 'نښې',
      pages: 'مخونه',
      size: 'اندازه',
      rating: 'ریټنګ',
      author: 'لیکوال',
      duration: 'موده',
      category: 'کټګوري',
      premiumOnly: 'یوازې Premium',
      upgradeToUnlock: 'د خلاصولو لپاره Premium ته لوړ کړئ',
      downloading: 'ډاونلوډیږي...',
      downloaded: 'ډاونلوډ شو',
      noContent: 'هیڅ مینځپانګه و نه موندل شوه',
      featuredContent: 'ځانګړې مینځپانګه',
      exclusiveContent: 'ځانګړي مینځپانګه',
      categories: {
        all: 'ټول',
        cardiology: 'زړه',
        pediatrics: 'ماشومان',
        surgery: 'جراحي',
        nutrition: 'خوراک',
        fitness: 'فټنس',
        mental: 'رواني روغتیا',
        emergency: 'اسعافي',
        medicine: 'درمل'
      }
    },
    fa: {
      title: 'محتوای Premium',
      subtitle: 'به محتوای اختصاصی دسترسی پیدا کنید',
      posts: 'پست‌ها',
      health: 'محتوای سلامت',
      books: 'کتاب‌ها',
      search: 'جستجو...',
      filter: 'فیلتر',
      all: 'همه',
      locked: 'قفل شده',
      unlocked: 'باز شده',
      viewDetails: 'مشاهده جزئیات',
      download: 'دانلود',
      play: 'پخش',
      read: 'خواندن',
      watch: 'تماشا',
      listen: 'گوش دادن',
      bookmark: 'نشانه‌گذاری',
      share: 'اشتراک',
      like: 'پسندیدن',
      views: 'بازدید',
      likes: 'پسندیده‌ها',
      downloads: 'دانلودها',
      bookmarks: 'نشانه‌ها',
      pages: 'صفحات',
      size: 'حجم',
      rating: 'امتیاز',
      author: 'نویسنده',
      duration: 'مدت زمان',
      category: 'دسته',
      premiumOnly: 'فقط Premium',
      upgradeToUnlock: 'برای باز کردن به Premium ارتقا دهید',
      downloading: 'در حال دانلود...',
      downloaded: 'دانلود شد',
      noContent: 'محتوایی پیدا نشد',
      featuredContent: 'محتوای ویژه',
      exclusiveContent: 'محتوای اختصاصی',
      categories: {
        all: 'همه',
        cardiology: 'قلب',
        pediatrics: 'اطفال',
        surgery: 'جراحی',
        nutrition: 'تغذیه',
        fitness: 'تناسب اندام',
        mental: 'سلامت روان',
        emergency: 'اورژانس',
        medicine: 'دارو'
      }
    },
    en: {
      title: 'Premium Content',
      subtitle: 'Access exclusive content',
      posts: 'Posts',
      health: 'Health Content',
      books: 'Books',
      search: 'Search...',
      filter: 'Filter',
      all: 'All',
      locked: 'Locked',
      unlocked: 'Unlocked',
      viewDetails: 'View Details',
      download: 'Download',
      play: 'Play',
      read: 'Read',
      watch: 'Watch',
      listen: 'Listen',
      bookmark: 'Bookmark',
      share: 'Share',
      like: 'Like',
      views: 'Views',
      likes: 'Likes',
      downloads: 'Downloads',
      bookmarks: 'Bookmarks',
      pages: 'Pages',
      size: 'Size',
      rating: 'Rating',
      author: 'Author',
      duration: 'Duration',
      category: 'Category',
      premiumOnly: 'Premium Only',
      upgradeToUnlock: 'Upgrade to Premium to unlock',
      downloading: 'Downloading...',
      downloaded: 'Downloaded',
      noContent: 'No content found',
      featuredContent: 'Featured Content',
      exclusiveContent: 'Exclusive Content',
      categories: {
        all: 'All',
        cardiology: 'Cardiology',
        pediatrics: 'Pediatrics',
        surgery: 'Surgery',
        nutrition: 'Nutrition',
        fitness: 'Fitness',
        mental: 'Mental Health',
        emergency: 'Emergency',
        medicine: 'Medicine'
      }
    }
  };

  const text = t[language];

  // Premium Posts Data
  const premiumPosts: PremiumPost[] = [
    {
      id: '1',
      userId: 'user1',
      userName: 'Dr. Ahmad Shah',
      userAvatar: 'https://images.unsplash.com/photo-1612349317150-e413f6a5b16d?w=400',
      isPremiumUser: true,
      content: language === 'ps' 
        ? 'د زړه د روغتیا په اړه ځانګړي معلومات - څنګه خپل زړه ساتلی شو'
        : language === 'fa'
        ? 'اطلاعات ویژه درباره سلامت قلب - چگونه از قلب خود مراقبت کنیم'
        : 'Exclusive information about heart health - How to take care of your heart',
      images: ['https://images.unsplash.com/photo-1628348068343-c6a848d2b6dd?w=800'],
      isPremiumContent: true,
      category: 'cardiology',
      views: 1250,
      likes: 340,
      bookmarks: 89,
      timestamp: new Date().toISOString()
    },
    {
      id: '2',
      userId: 'user2',
      userName: 'Dr. Fatima Ahmadi',
      userAvatar: 'https://images.unsplash.com/photo-1632054226752-b1b40867f7a5?w=400',
      isPremiumUser: true,
      content: language === 'ps'
        ? 'د ماشومانو خوراک - د ماشومانو لپاره ښه خوراک'
        : language === 'fa'
        ? 'تغذیه کودکان - غذای مناسب برای کودکان'
        : 'Child Nutrition - Proper food for children',
      images: ['https://images.unsplash.com/photo-1476703993599-0035a21b17a9?w=800'],
      isPremiumContent: true,
      category: 'pediatrics',
      views: 980,
      likes: 267,
      bookmarks: 124,
      timestamp: new Date().toISOString()
    }
  ];

  // Premium Health Content Data
  const healthContent: PremiumHealthContent[] = [
    {
      id: '1',
      title: {
        ps: 'د زړه د ناروغیو مخنیوی',
        fa: 'پیشگیری از بیماری‌های قلبی',
        en: 'Heart Disease Prevention'
      },
      description: {
        ps: 'د زړه د ناروغیو د مخنیوي بشپړ لارښود',
        fa: 'راهنمای کامل پیشگیری از بیماری‌های قلبی',
        en: 'Complete guide to preventing heart diseases'
      },
      category: 'cardiology',
      type: 'video',
      duration: '45:30',
      author: 'Dr. Ahmad Shah',
      image: 'https://images.unsplash.com/photo-1628348068343-c6a848d2b6dd?w=800',
      isPremium: true,
      views: 5420,
      likes: 892,
      downloadUrl: 'https://example.com/video1.mp4'
    },
    {
      id: '2',
      title: {
        ps: 'د ماشومانو روغتیا او پاملرنه',
        fa: 'سلامت و مراقبت از کودکان',
        en: 'Child Health and Care'
      },
      description: {
        ps: 'د ماشومانو روغتیا او پاملرنې بشپړ لارښود',
        fa: 'راهنمای کامل سلامت و مراقبت از کودکان',
        en: 'Complete guide to child health and care'
      },
      category: 'pediatrics',
      type: 'article',
      author: 'Dr. Fatima Ahmadi',
      image: 'https://images.unsplash.com/photo-1476703993599-0035a21b17a9?w=800',
      isPremium: true,
      views: 3890,
      likes: 654,
      downloadUrl: 'https://example.com/article1.pdf'
    },
    {
      id: '3',
      title: {
        ps: 'د غذایي اړتیاوو بشپړ لارښود',
        fa: 'راهنمای کامل نیازهای تغذیه‌ای',
        en: 'Complete Nutrition Guide'
      },
      description: {
        ps: 'ستاسو د بدن د غذایي اړتیاوو بشپړ معلومات',
        fa: 'اطلاعات کامل درباره نیازهای تغذیه‌ای بدن شما',
        en: 'Complete information about your body nutritional needs'
      },
      category: 'nutrition',
      type: 'audio',
      duration: '32:15',
      author: 'Dr. Hassan Karimi',
      image: 'https://images.unsplash.com/photo-1490645935967-10de6ba17061?w=800',
      isPremium: true,
      views: 2340,
      likes: 421,
      downloadUrl: 'https://example.com/audio1.mp3'
    }
  ];

  // Premium Books Data
  const premiumBooks: PremiumBook[] = [
    {
      id: '1',
      title: {
        ps: 'د زړه ناروغۍ او درملنه',
        fa: 'بیماری‌های قلبی و درمان',
        en: 'Heart Diseases and Treatment'
      },
      author: {
        ps: 'ډاکټر احمد شاه',
        fa: 'دکتر احمد شاه',
        en: 'Dr. Ahmad Shah'
      },
      description: {
        ps: 'د زړه د ناروغیو د تشخیص او درملنې بشپړ کتاب',
        fa: 'کتاب کامل تشخیص و درمان بیماری‌های قلبی',
        en: 'Complete book on diagnosis and treatment of heart diseases'
      },
      category: 'cardiology',
      pages: 450,
      size: '15 MB',
      language: 'English/Dari',
      cover: 'https://images.unsplash.com/photo-1532012197267-da84d127e765?w=400',
      isPremium: true,
      downloads: 1240,
      rating: 4.8,
      downloadUrl: 'https://example.com/book1.pdf'
    },
    {
      id: '2',
      title: {
        ps: 'د ماشومانو روغتیا',
        fa: 'سلامت کودکان',
        en: 'Child Health'
      },
      author: {
        ps: 'ډاکټره فاطمه احمدي',
        fa: 'دکتر فاطمه احمدی',
        en: 'Dr. Fatima Ahmadi'
      },
      description: {
        ps: 'د ماشومانو روغتیا او پاملرنې بشپړ لارښود',
        fa: 'راهنمای کامل سلامت و مراقبت از کودکان',
        en: 'Complete guide to child health and care'
      },
      category: 'pediatrics',
      pages: 380,
      size: '12 MB',
      language: 'Pashto/Dari',
      cover: 'https://images.unsplash.com/photo-1512820790803-83ca734da794?w=400',
      isPremium: true,
      downloads: 980,
      rating: 4.9,
      downloadUrl: 'https://example.com/book2.pdf'
    },
    {
      id: '3',
      title: {
        ps: 'د خوراک او روغتیا',
        fa: 'تغذیه و سلامت',
        en: 'Nutrition and Health'
      },
      author: {
        ps: 'ډاکټر حسن کریمي',
        fa: 'دکتر حسن کریمی',
        en: 'Dr. Hassan Karimi'
      },
      description: {
        ps: 'د سالم خوراک او د بدن اړتیاوو بشپړ کتاب',
        fa: 'کتاب کامل تغذیه سالم و نیازهای بدن',
        en: 'Complete book on healthy nutrition and body needs'
      },
      category: 'nutrition',
      pages: 320,
      size: '10 MB',
      language: 'English/Dari/Pashto',
      cover: 'https://images.unsplash.com/photo-1544947950-fa07a98d237f?w=400',
      isPremium: true,
      downloads: 1560,
      rating: 4.7,
      downloadUrl: 'https://example.com/book3.pdf'
    },
    {
      id: '4',
      title: {
        ps: 'جراحي لارښود',
        fa: 'راهنمای جراحی',
        en: 'Surgery Guide'
      },
      author: {
        ps: 'ډاکټر محمد رحیم',
        fa: 'دکتر محمد رحیم',
        en: 'Dr. Mohammad Rahim'
      },
      description: {
        ps: 'د مختلفو جراحي عملیاتو بشپړ لارښود',
        fa: 'راهنمای کامل انواع عمل‌های جراحی',
        en: 'Complete guide to various surgical procedures'
      },
      category: 'surgery',
      pages: 520,
      size: '18 MB',
      language: 'English',
      cover: 'https://images.unsplash.com/photo-1589998059171-988d887df646?w=400',
      isPremium: true,
      downloads: 2340,
      rating: 4.9,
      downloadUrl: 'https://example.com/book4.pdf'
    }
  ];

  const handleDownload = (item: any) => {
    if (!isPremium) {
      onUpgrade();
      return;
    }

    // Simulate download
    alert(`${text.downloading}\n${item.title?.[language] || item.content}`);
    
    // In production, trigger actual download
    // window.open(item.downloadUrl, '_blank');
  };

  const categories = [
    { id: 'all', label: text.categories.all },
    { id: 'cardiology', label: text.categories.cardiology },
    { id: 'pediatrics', label: text.categories.pediatrics },
    { id: 'surgery', label: text.categories.surgery },
    { id: 'nutrition', label: text.categories.nutrition },
    { id: 'fitness', label: text.categories.fitness },
    { id: 'mental', label: text.categories.mental },
    { id: 'emergency', label: text.categories.emergency },
    { id: 'medicine', label: text.categories.medicine }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-pink-50 to-orange-50 pb-20">
      {/* Header */}
      <div className="sticky top-0 z-40 backdrop-blur-xl bg-white/80 border-b border-white/20 shadow-lg">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center gap-4">
            <Button variant="ghost" size="icon" onClick={onBack}>
              <ArrowLeft className="w-5 h-5" />
            </Button>
            <div className="flex items-center gap-3">
              <div className="bg-gradient-to-br from-purple-500 to-pink-600 p-2.5 rounded-2xl">
                <Crown className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-2xl bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent">
                  {text.title}
                </h1>
                <p className="text-sm text-gray-600">{text.subtitle}</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="sticky top-[72px] z-30 bg-white border-b border-gray-200">
        <div className="container mx-auto px-4">
          <div className="flex gap-2 overflow-x-auto pb-2 pt-2 scrollbar-hide">
            {[
              { id: 'posts' as const, label: text.posts, icon: FileText },
              { id: 'health' as const, label: text.health, icon: Heart },
              { id: 'books' as const, label: text.books, icon: BookOpen }
            ].map(tab => {
              const Icon = tab.icon;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`flex items-center gap-2 px-4 py-2.5 rounded-xl whitespace-nowrap transition-all ${
                    activeTab === tab.id
                      ? 'bg-gradient-to-r from-purple-500 to-pink-600 text-white shadow-lg'
                      : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                  }`}
                >
                  <Icon className="w-4 h-4" />
                  <span className="text-sm font-medium">{tab.label}</span>
                </button>
              );
            })}
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-6">
        {/* Search & Filter */}
        <div className="mb-6 flex gap-3">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
            <Input
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder={text.search}
              className="pl-10 pr-4"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute right-3 top-1/2 -translate-y-1/2"
              >
                <X className="w-5 h-5 text-gray-400" />
              </button>
            )}
          </div>
          <Button variant="outline" size="icon">
            <Filter className="w-5 h-5" />
          </Button>
        </div>

        {/* Categories */}
        <div className="mb-6 overflow-x-auto pb-2 scrollbar-hide">
          <div className="flex gap-2">
            {categories.map(cat => (
              <button
                key={cat.id}
                onClick={() => setSelectedCategory(cat.id)}
                className={`px-4 py-2 rounded-xl whitespace-nowrap text-sm transition-all ${
                  selectedCategory === cat.id
                    ? 'bg-gradient-to-r from-purple-500 to-pink-600 text-white shadow-lg'
                    : 'bg-white text-gray-700 border border-gray-200 hover:border-gray-300'
                }`}
              >
                {cat.label}
              </button>
            ))}
          </div>
        </div>

        {/* Premium Posts */}
        {activeTab === 'posts' && (
          <div className="space-y-4">
            {premiumPosts.map((post) => (
              <motion.div
                key={post.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="bg-white rounded-3xl overflow-hidden border border-gray-200 shadow-lg"
              >
                {/* Post Header */}
                <div className="p-5 flex items-start gap-3">
                  <div className="relative">
                    <div className="w-12 h-12 rounded-full overflow-hidden">
                      <ImageWithFallback
                        src={post.userAvatar}
                        alt={post.userName}
                        className="w-full h-full object-cover"
                      />
                    </div>
                    {post.isPremiumUser && (
                      <div className="absolute -bottom-1 -right-1">
                        <PremiumBadge size="sm" animate={false} />
                      </div>
                    )}
                  </div>
                  <div className="flex-1">
                    <h3 className="font-medium">{post.userName}</h3>
                    <p className="text-sm text-gray-600">
                      {new Date(post.timestamp).toLocaleDateString()}
                    </p>
                  </div>
                  <div className="bg-gradient-to-r from-yellow-400 to-orange-500 text-white px-3 py-1 rounded-full text-xs font-medium flex items-center gap-1">
                    <Crown className="w-3 h-3" />
                    {text.premiumOnly}
                  </div>
                </div>

                {/* Post Content */}
                {isPremium ? (
                  <>
                    <div className="px-5 pb-3">
                      <p className="text-gray-800">{post.content}</p>
                    </div>

                    {/* Post Images */}
                    {post.images.length > 0 && (
                      <div className="px-5 pb-4">
                        <div className="rounded-2xl overflow-hidden">
                          <ImageWithFallback
                            src={post.images[0]}
                            alt="Post image"
                            className="w-full h-64 object-cover"
                          />
                        </div>
                      </div>
                    )}

                    {/* Post Stats & Actions */}
                    <div className="px-5 pb-5 flex items-center justify-between">
                      <div className="flex items-center gap-4 text-sm text-gray-600">
                        <span className="flex items-center gap-1">
                          <Eye className="w-4 h-4" />
                          {post.views}
                        </span>
                        <span className="flex items-center gap-1">
                          <Heart className="w-4 h-4" />
                          {post.likes}
                        </span>
                        <span className="flex items-center gap-1">
                          <Bookmark className="w-4 h-4" />
                          {post.bookmarks}
                        </span>
                      </div>
                      <Button 
                        variant="outline" 
                        size="sm"
                        onClick={() => {
                          setSharingContent(post);
                          setShareModalOpen(true);
                        }}
                      >
                        <Share2 className="w-4 h-4 mr-2" />
                        {text.share}
                      </Button>
                    </div>
                  </>
                ) : (
                  <div className="px-5 pb-5">
                    <div className="relative">
                      <div className="blur-sm">
                        <p className="text-gray-400">{post.content.substring(0, 50)}...</p>
                        {post.images.length > 0 && (
                          <div className="mt-3 rounded-2xl overflow-hidden opacity-30">
                            <ImageWithFallback
                              src={post.images[0]}
                              alt="Locked"
                              className="w-full h-64 object-cover"
                            />
                          </div>
                        )}
                      </div>
                      <div className="absolute inset-0 flex items-center justify-center bg-white/80 backdrop-blur-sm rounded-2xl">
                        <div className="text-center p-6">
                          <Lock className="w-12 h-12 text-gray-400 mx-auto mb-3" />
                          <p className="text-gray-600 mb-4">{text.upgradeToUnlock}</p>
                          <PremiumLock onClick={onUpgrade} />
                        </div>
                      </div>
                    </div>
                  </div>
                )}
              </motion.div>
            ))}
          </div>
        )}

        {/* Health Content */}
        {activeTab === 'health' && (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {healthContent.map((content) => (
              <motion.div
                key={content.id}
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                className="bg-white rounded-3xl overflow-hidden border border-gray-200 shadow-lg"
              >
                {/* Content Image */}
                <div className="relative h-48">
                  <ImageWithFallback
                    src={content.image}
                    alt={content.title[language]}
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
                  
                  {/* Type Badge */}
                  <div className="absolute top-3 left-3 bg-white/90 backdrop-blur-xl px-3 py-1 rounded-full text-xs font-medium flex items-center gap-1">
                    {content.type === 'video' && <Video className="w-3 h-3" />}
                    {content.type === 'audio' && <Headphones className="w-3 h-3" />}
                    {content.type === 'article' && <FileText className="w-3 h-3" />}
                    {content.type}
                  </div>

                  {/* Premium Badge */}
                  <div className="absolute top-3 right-3">
                    <PremiumBadge size="sm" showLabel />
                  </div>

                  {/* Duration */}
                  {content.duration && (
                    <div className="absolute bottom-3 right-3 bg-black/70 text-white px-2 py-1 rounded-lg text-xs">
                      {content.duration}
                    </div>
                  )}

                  {/* Lock Overlay */}
                  {!isPremium && (
                    <div className="absolute inset-0 flex items-center justify-center bg-black/50 backdrop-blur-sm">
                      <Lock className="w-12 h-12 text-white" />
                    </div>
                  )}
                </div>

                {/* Content Info */}
                <div className="p-5">
                  <h3 className="font-medium text-lg mb-2">{content.title[language]}</h3>
                  <p className="text-sm text-gray-600 mb-3">{content.description[language]}</p>
                  
                  <div className="flex items-center gap-4 text-sm text-gray-600 mb-4">
                    <span className="flex items-center gap-1">
                      <Eye className="w-4 h-4" />
                      {content.views}
                    </span>
                    <span className="flex items-center gap-1">
                      <Heart className="w-4 h-4" />
                      {content.likes}
                    </span>
                  </div>

                  <div className="flex gap-2">
                    {isPremium ? (
                      <>
                        <Button
                          onClick={() => handleDownload(content)}
                          className="flex-1 bg-gradient-to-r from-purple-500 to-pink-600"
                        >
                          {content.type === 'video' && <Play className="w-4 h-4 mr-2" />}
                          {content.type === 'audio' && <Headphones className="w-4 h-4 mr-2" />}
                          {content.type === 'article' && <BookOpen className="w-4 h-4 mr-2" />}
                          {content.type === 'video' ? text.watch : content.type === 'audio' ? text.listen : text.read}
                        </Button>
                        <Button variant="outline" size="icon">
                          <Download className="w-4 h-4" />
                        </Button>
                      </>
                    ) : (
                      <Button onClick={onUpgrade} className="flex-1 bg-gradient-to-r from-yellow-400 to-orange-500">
                        <Lock className="w-4 h-4 mr-2" />
                        {text.upgradeToUnlock}
                      </Button>
                    )}
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        )}

        {/* Premium Books */}
        {activeTab === 'books' && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {premiumBooks.map((book) => (
              <motion.div
                key={book.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="bg-white rounded-3xl overflow-hidden border border-gray-200 shadow-lg hover:shadow-xl transition-all"
              >
                {/* Book Cover */}
                <div className="relative h-64">
                  <ImageWithFallback
                    src={book.cover}
                    alt={book.title[language]}
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent" />
                  
                  {/* Premium Badge */}
                  <div className="absolute top-3 right-3">
                    <PremiumBadge size="sm" />
                  </div>

                  {/* Rating */}
                  <div className="absolute top-3 left-3 bg-white/90 backdrop-blur-xl px-3 py-1 rounded-full flex items-center gap-1">
                    <Star className="w-4 h-4 text-yellow-500 fill-yellow-500" />
                    <span className="text-sm font-medium">{book.rating}</span>
                  </div>

                  {/* Lock Overlay */}
                  {!isPremium && (
                    <div className="absolute inset-0 flex items-center justify-center bg-black/60 backdrop-blur-sm">
                      <div className="text-center text-white">
                        <Lock className="w-12 h-12 mx-auto mb-2" />
                        <p className="text-sm">{text.premiumOnly}</p>
                      </div>
                    </div>
                  )}
                </div>

                {/* Book Info */}
                <div className="p-5">
                  <h3 className="font-medium text-lg mb-1">{book.title[language]}</h3>
                  <p className="text-sm text-gray-600 mb-3">{book.author[language]}</p>
                  
                  <div className="space-y-2 mb-4 text-sm text-gray-600">
                    <div className="flex justify-between">
                      <span>{text.pages}:</span>
                      <span className="font-medium">{book.pages}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>{text.size}:</span>
                      <span className="font-medium">{book.size}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>{text.downloads}:</span>
                      <span className="font-medium">{book.downloads}</span>
                    </div>
                  </div>

                  {isPremium ? (
                    <Button
                      onClick={() => handleDownload(book)}
                      className="w-full bg-gradient-to-r from-purple-500 to-pink-600"
                    >
                      <Download className="w-4 h-4 mr-2" />
                      {text.download}
                    </Button>
                  ) : (
                    <Button onClick={onUpgrade} className="w-full bg-gradient-to-r from-yellow-400 to-orange-500">
                      <Crown className="w-4 h-4 mr-2" />
                      {text.upgradeToUnlock}
                    </Button>
                  )}
                </div>
              </motion.div>
            ))}
          </div>
        )}
      </div>

      {/* Share Modal */}
      <ShareModal
        isOpen={shareModalOpen}
        onClose={() => {
          setShareModalOpen(false);
          setSharingContent(null);
        }}
        language={language}
        shareContent={{
          title: sharingContent?.title || 'HealMate Premium',
          description: sharingContent?.excerpt || sharingContent?.summary || '',
          url: window.location.href
        }}
      />
    </div>
  );
}
