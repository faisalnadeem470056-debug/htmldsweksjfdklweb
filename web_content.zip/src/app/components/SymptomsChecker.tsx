import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Search, AlertCircle, ArrowLeft, Heart, Brain, Bone, Ear, Eye, Stethoscope, Activity, Thermometer, Droplet, Users } from 'lucide-react';
import { Button } from './ui/button';
import { AdBanner } from './AdBanner';

interface SymptomsCheckerProps {
  language: 'ps' | 'fa' | 'en';
  onBack: () => void;
}

interface Symptom {
  id: string;
  name: { ps: string; fa: string; en: string };
  bodyPart: string;
  icon: any;
}

interface Condition {
  name: { ps: string; fa: string; en: string };
  severity: 'low' | 'medium' | 'high';
  description: { ps: string; fa: string; en: string };
  recommendation: { ps: string; fa: string; en: string };
}

export function SymptomsChecker({ language, onBack }: SymptomsCheckerProps) {
  const [selectedSymptoms, setSelectedSymptoms] = useState<string[]>([]);
  const [results, setResults] = useState<Condition[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [showResults, setShowResults] = useState(false);

  const t = {
    title: {
      ps: 'د نښو معاینه کوونکی',
      fa: 'بررسی علائم',
      en: 'Symptoms Checker'
    },
    subtitle: {
      ps: 'خپلې نښې انتخاب کړئ او ممکنه تشخیص وګورئ',
      fa: 'علائم خود را انتخاب کنید و تشخیص احتمالی را ببینید',
      en: 'Select your symptoms and see possible diagnosis'
    },
    searchPlaceholder: {
      ps: 'د نښو لټون...',
      fa: 'جستجوی علائم...',
      en: 'Search symptoms...'
    },
    selectedSymptoms: {
      ps: 'غوره شوې نښې',
      fa: 'علائم انتخاب شده',
      en: 'Selected Symptoms'
    },
    checkSymptoms: {
      ps: 'معاینه کړئ',
      fa: 'بررسی کنید',
      en: 'Check Symptoms'
    },
    possibleConditions: {
      ps: 'ممکنه حالتونه',
      fa: 'وضعیت‌های احتمالی',
      en: 'Possible Conditions'
    },
    severity: {
      low: { ps: 'کم خطر', fa: 'خطر کم', en: 'Low Risk' },
      medium: { ps: 'منځنی خطر', fa: 'خطر متوسط', en: 'Medium Risk' },
      high: { ps: 'لوړ خطر', fa: 'خطر بالا', en: 'High Risk' }
    },
    disclaimer: {
      ps: '⚠️ یادونه: دا یوازې معلوماتي لارښود دی او د طبي تشخیص بدیل نه دی. د جدي نښو په صورت کې له دوکتور سره مشوره وکړئ.',
      fa: '⚠️ تذکر: این فقط یک راهنمای اطلاعاتی است و جایگزین تشخیص پزشکی نیست. در صورت علائم جدی با پزشک مشورت کنید.',
      en: '⚠️ Disclaimer: This is only an informational guide and not a substitute for medical diagnosis. Consult a doctor for serious symptoms.'
    },
    clear: {
      ps: 'پاکول',
      fa: 'پاک کردن',
      en: 'Clear All'
    },
    noSymptoms: {
      ps: 'مهرباني وکړئ لږترلږه یوه نښه انتخاب کړئ',
      fa: 'لطفاً حداقل یک علامت را انتخاب کنید',
      en: 'Please select at least one symptom'
    },
    noResults: {
      ps: 'د غوره شوو نښو لپاره هیڅ حالت ونه موندل شو. مهرباني وکړئ نورې نښې هم زیاتې کړئ یا له دوکتور سره مشوره وکړئ.',
      fa: 'هیچ وضعیتی برای علائم انتخاب شده یافت نشد. لطفاً علائم بیشتری اضافه کنید یا با پزشک مشورت کنید.',
      en: 'No conditions found for selected symptoms. Please add more symptoms or consult a doctor.'
    }
  };

  const symptoms: Symptom[] = [
    // Head & Brain
    { id: 'headache', name: { ps: 'سر درد', fa: 'سردرد', en: 'Headache' }, bodyPart: 'head', icon: Brain },
    { id: 'dizziness', name: { ps: 'سر خوځېدل', fa: 'سرگیجه', en: 'Dizziness' }, bodyPart: 'head', icon: Brain },
    { id: 'confusion', name: { ps: 'ګډوډي', fa: 'سردرگمی', en: 'Confusion' }, bodyPart: 'head', icon: Brain },
    
    // Eyes
    { id: 'blurred-vision', name: { ps: 'تیاره لید', fa: 'تاری دید', en: 'Blurred Vision' }, bodyPart: 'eyes', icon: Eye },
    { id: 'eye-pain', name: { ps: 'د سترګو درد', fa: 'درد چشم', en: 'Eye Pain' }, bodyPart: 'eyes', icon: Eye },
    
    // Ears
    { id: 'ear-pain', name: { ps: 'د غوږ درد', fa: 'درد گوش', en: 'Ear Pain' }, bodyPart: 'ears', icon: Ear },
    { id: 'hearing-loss', name: { ps: 'د اوریدلو کمښت', fa: 'کاهش شنوایی', en: 'Hearing Loss' }, bodyPart: 'ears', icon: Ear },
    
    // Chest & Heart
    { id: 'chest-pain', name: { ps: 'د سینې درد', fa: 'درد قفسه سینه', en: 'Chest Pain' }, bodyPart: 'chest', icon: Heart },
    { id: 'shortness-breath', name: { ps: 'د ساه تنګي', fa: 'تنگی نفس', en: 'Shortness of Breath' }, bodyPart: 'chest', icon: Stethoscope },
    { id: 'palpitations', name: { ps: 'د زړه ټکان', fa: 'تپش قلب', en: 'Palpitations' }, bodyPart: 'chest', icon: Heart },
    { id: 'cough', name: { ps: 'ټوخی', fa: 'سرفه', en: 'Cough' }, bodyPart: 'chest', icon: Stethoscope },
    
    // Body General
    { id: 'fever', name: { ps: 'تبه', fa: 'تب', en: 'Fever' }, bodyPart: 'body', icon: Thermometer },
    { id: 'fatigue', name: { ps: 'ستړیا', fa: 'خستگی', en: 'Fatigue' }, bodyPart: 'body', icon: Activity },
    { id: 'muscle-pain', name: { ps: 'د عضلاتو درد', fa: 'درد عضلانی', en: 'Muscle Pain' }, bodyPart: 'body', icon: Bone },
    { id: 'joint-pain', name: { ps: 'د بندونو درد', fa: 'درد مفاصل', en: 'Joint Pain' }, bodyPart: 'body', icon: Bone },
    { id: 'nausea', name: { ps: 'زړه بدوالی', fa: 'حالت تهوع', en: 'Nausea' }, bodyPart: 'body', icon: AlertCircle },
    { id: 'vomiting', name: { ps: 'کانګې', fa: 'استفراغ', en: 'Vomiting' }, bodyPart: 'body', icon: Droplet },
    { id: 'diarrhea', name: { ps: 'نس ناستي', fa: 'اسهال', en: 'Diarrhea' }, bodyPart: 'body', icon: Droplet },
    { id: 'abdominal-pain', name: { ps: 'د خېټې درد', fa: 'درد شکم', en: 'Abdominal Pain' }, bodyPart: 'body', icon: AlertCircle },
    { id: 'chills', name: { ps: 'یخوالی', fa: 'لرز', en: 'Chills' }, bodyPart: 'body', icon: Thermometer },
    { id: 'sweating', name: { ps: 'خوله کیدل', fa: 'تعریق', en: 'Sweating' }, bodyPart: 'body', icon: Droplet }
  ];

  const conditions: Record<string, Condition> = {
    'common-cold': {
      name: { ps: 'عام ټوخی', fa: 'سرماخوردگی', en: 'Common Cold' },
      severity: 'low',
      description: {
        ps: 'یو وایرسي انتخاب چې د پوزې او ستوني اغیزمن کوي',
        fa: 'یک عفونت ویروسی که بینی و گلو را تحت تاثیر قرار می‌دهد',
        en: 'A viral infection affecting the nose and throat'
      },
      recommendation: {
        ps: 'استراحت، مایعات، او د درد کموونکي',
        fa: 'استراحت، نوشیدنی‌ها، و مسکن‌ها',
        en: 'Rest, fluids, and pain relievers'
      }
    },
    'flu': {
      name: { ps: 'انفلونزا', fa: 'آنفولانزا', en: 'Influenza (Flu)' },
      severity: 'medium',
      description: {
        ps: 'د تنفسي سیستم یو سخته وایرسي انتخاب',
        fa: 'یک عفونت ویروسی شدید سیستم تنفسی',
        en: 'A severe viral infection of the respiratory system'
      },
      recommendation: {
        ps: 'استراحت، مایعات، او له دوکتور سره مشوره',
        fa: 'استراحت، نوشیدنی‌ها، و مشورت با پزشک',
        en: 'Rest, fluids, and consult a doctor'
      }
    },
    'migraine': {
      name: { ps: 'میګرین', fa: 'میگرن', en: 'Migraine' },
      severity: 'medium',
      description: {
        ps: 'سخت سر درد چې ډیری وختونه د نورو نښو سره',
        fa: 'سردرد شدید که اغلب با علائم دیگر همراه است',
        en: 'Severe headache often accompanied by other symptoms'
      },
      recommendation: {
        ps: 'تیاره خونه، استراحت، او د میګرین درمل',
        fa: 'اتاق تاریک، استراحت، و داروی میگرن',
        en: 'Dark room, rest, and migraine medication'
      }
    },
    'gastroenteritis': {
      name: { ps: 'د کولمو التهاب', fa: 'التهاب معده و روده', en: 'Gastroenteritis' },
      severity: 'medium',
      description: {
        ps: 'د معدې او کولمو انتخاب',
        fa: 'عفونت معده و روده',
        en: 'Infection of the stomach and intestines'
      },
      recommendation: {
        ps: 'مایعات، د الکترولایټ حل، او استراحت',
        fa: 'مایعات، محلول الکترولیت، و استراحت',
        en: 'Fluids, electrolyte solution, and rest'
      }
    },
    'hypertension': {
      name: { ps: 'لوړ فشار', fa: 'فشار خون بالا', en: 'High Blood Pressure' },
      severity: 'high',
      description: {
        ps: 'د وینې فشار چې د نورمال سطحې څخه لوړ وي',
        fa: 'فشار خون که از سطح نرمال بالاتر است',
        en: 'Blood pressure above normal levels'
      },
      recommendation: {
        ps: 'فوري له دوکتور سره مشوره، د طرز ژوند بدلون',
        fa: 'مشورت فوری با پزشک، تغییر سبک زندگی',
        en: 'Urgent doctor consultation, lifestyle changes'
      }
    },
    'heart-attack': {
      name: { ps: 'د زړه حمله', fa: 'حمله قلبی', en: 'Heart Attack' },
      severity: 'high',
      description: {
        ps: 'د زړه ته د وینې رسولو کمښت',
        fa: 'کاهش جریان خون به قلب',
        en: 'Reduced blood flow to the heart'
      },
      recommendation: {
        ps: '🚨 فوري بیړنۍ خدمات ته زنګ ووهئ!',
        fa: '🚨 فوراً با اورژانس تماس بگیرید!',
        en: '🚨 Call emergency services immediately!'
      }
    },
    'ear-infection': {
      name: { ps: 'د غوږ انتخاب', fa: 'عفونت گوش', en: 'Ear Infection' },
      severity: 'low',
      description: {
        ps: 'د غوږ باکټریایي یا وایرسي انتخاب',
        fa: 'عفونت باکتریایی یا ویروسی گوش',
        en: 'Bacterial or viral infection of the ear'
      },
      recommendation: {
        ps: 'له دوکتور سره مشوره، ممکن انټي بایوټیکونه',
        fa: 'مشورت با پزشک، ممکن است آنتی‌بیوتیک',
        en: 'Consult doctor, possible antibiotics'
      }
    },
    'eye-strain': {
      name: { ps: 'د سترګو فشار', fa: 'خستگی چشم', en: 'Eye Strain' },
      severity: 'low',
      description: {
        ps: 'د ډیر کار له امله د سترګو ستړیا',
        fa: 'خستگی چشم به دلیل استفاده زیاد',
        en: 'Eye fatigue from overuse'
      },
      recommendation: {
        ps: 'استراحت، د سکرین وخت کمول',
        fa: 'استراحت، کاهش زمان صفحه',
        en: 'Rest, reduce screen time'
      }
    }
  };

  const toggleSymptom = (symptomId: string) => {
    setSelectedSymptoms(prev => {
      const newSelection = prev.includes(symptomId)
        ? prev.filter(id => id !== symptomId)
        : [...prev, symptomId];
      
      // Reset results when symptoms change
      if (showResults) {
        setShowResults(false);
      }
      
      return newSelection;
    });
  };

  const clearAllSymptoms = () => {
    setSelectedSymptoms([]);
    setResults([]);
    setShowResults(false);
  };

  const analyzeSymptoms = () => {
    if (selectedSymptoms.length === 0) {
      alert(t.noSymptoms[language]);
      return;
    }

    const possibleConditions: Condition[] = [];

    // Simple symptom matching logic
    if (selectedSymptoms.includes('cough') && selectedSymptoms.includes('fever') && selectedSymptoms.includes('fatigue')) {
      if (selectedSymptoms.includes('muscle-pain') || selectedSymptoms.includes('chills')) {
        possibleConditions.push(conditions['flu']);
      } else {
        possibleConditions.push(conditions['common-cold']);
      }
    } else if (selectedSymptoms.includes('cough') && selectedSymptoms.includes('fatigue')) {
      possibleConditions.push(conditions['common-cold']);
    }

    if (selectedSymptoms.includes('headache') && (selectedSymptoms.includes('dizziness') || selectedSymptoms.includes('blurred-vision'))) {
      possibleConditions.push(conditions['migraine']);
    }

    if (selectedSymptoms.includes('nausea') && selectedSymptoms.includes('vomiting') && selectedSymptoms.includes('diarrhea')) {
      possibleConditions.push(conditions['gastroenteritis']);
    } else if (selectedSymptoms.includes('abdominal-pain') && (selectedSymptoms.includes('nausea') || selectedSymptoms.includes('diarrhea'))) {
      possibleConditions.push(conditions['gastroenteritis']);
    }

    if (selectedSymptoms.includes('chest-pain') && selectedSymptoms.includes('shortness-breath')) {
      possibleConditions.push(conditions['heart-attack']);
    }

    if (selectedSymptoms.includes('headache') && selectedSymptoms.includes('chest-pain')) {
      possibleConditions.push(conditions['hypertension']);
    } else if (selectedSymptoms.includes('dizziness') && selectedSymptoms.includes('palpitations')) {
      possibleConditions.push(conditions['hypertension']);
    }

    if (selectedSymptoms.includes('ear-pain')) {
      possibleConditions.push(conditions['ear-infection']);
    }

    if (selectedSymptoms.includes('eye-pain') || selectedSymptoms.includes('blurred-vision')) {
      possibleConditions.push(conditions['eye-strain']);
    }

    setResults(possibleConditions);
    setShowResults(true);

    // Scroll to results
    setTimeout(() => {
      const resultsElement = document.getElementById('results-section');
      if (resultsElement) {
        resultsElement.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }
    }, 100);
  };

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'low':
        return 'from-green-500 to-emerald-500';
      case 'medium':
        return 'from-yellow-500 to-orange-500';
      case 'high':
        return 'from-red-500 to-pink-500';
      default:
        return 'from-gray-500 to-gray-600';
    }
  };

  const getSeverityBorderColor = (severity: string) => {
    switch (severity) {
      case 'low':
        return 'border-green-300';
      case 'medium':
        return 'border-orange-300';
      case 'high':
        return 'border-red-300';
      default:
        return 'border-gray-300';
    }
  };

  const filteredSymptoms = symptoms.filter(symptom =>
    symptom.name[language].toLowerCase().includes(searchTerm.toLowerCase()) ||
    symptom.name.en.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-50 via-purple-50 to-pink-50 pb-28 md:pb-8">
      {/* Header */}
      <div className="sticky top-0 z-40 backdrop-blur-xl bg-white/70 border-b border-white/20 shadow-lg">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center gap-4">
            <Button variant="ghost" size="icon" onClick={onBack} className="flex-shrink-0">
              <ArrowLeft className="w-6 h-6" />
            </Button>
            <div className="flex items-center gap-3 flex-1">
              <div className="bg-gradient-to-br from-indigo-500 to-purple-600 p-3 rounded-2xl flex-shrink-0">
                <Brain className="w-6 h-6 text-white" />
              </div>
              <div className="flex-1 min-w-0">
                <h1 className="text-xl bg-gradient-to-r from-indigo-600 to-purple-600 bg-clip-text text-transparent truncate">
                  {t.title[language]}
                </h1>
                <p className="text-xs text-gray-600 truncate">{t.subtitle[language]}</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-6 space-y-6">
        <AdBanner type="medium" />

        {/* Disclaimer */}
        <motion.div 
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-yellow-50 border-2 border-yellow-200 rounded-2xl p-4 flex gap-3"
        >
          <AlertCircle className="w-6 h-6 text-yellow-600 flex-shrink-0" />
          <p className="text-sm text-gray-700" dir={language === 'en' ? 'ltr' : 'rtl'}>
            {t.disclaimer[language]}
          </p>
        </motion.div>

        {/* Search */}
        <motion.div 
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="relative"
        >
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400 pointer-events-none z-10" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder={t.searchPlaceholder[language]}
            className="w-full pl-12 pr-4 py-4 rounded-2xl border-2 border-gray-200 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent bg-white/90 backdrop-blur-sm transition-all"
            style={{ fontSize: '16px' }}
          />
        </motion.div>

        {/* Symptoms Grid */}
        <motion.div 
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="bg-white/90 backdrop-blur-xl rounded-3xl p-6 shadow-xl border-2 border-white/50"
        >
          <div className="flex items-center justify-between mb-5">
            <h2 className="text-xl font-bold">
              {t.selectedSymptoms[language]} ({selectedSymptoms.length})
            </h2>
            {selectedSymptoms.length > 0 && (
              <Button
                variant="ghost"
                size="sm"
                onClick={clearAllSymptoms}
                className="text-red-600 hover:text-red-700 hover:bg-red-50"
              >
                {t.clear[language]}
              </Button>
            )}
          </div>
          
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3 mb-6">
            {filteredSymptoms.map((symptom) => {
              const Icon = symptom.icon;
              const isSelected = selectedSymptoms.includes(symptom.id);
              
              return (
                <motion.button
                  key={symptom.id}
                  onClick={() => toggleSymptom(symptom.id)}
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  className={`p-4 rounded-2xl border-2 transition-all duration-200 ${
                    isSelected
                      ? 'bg-gradient-to-br from-indigo-500 to-purple-600 text-white border-indigo-600 shadow-lg'
                      : 'bg-white border-gray-200 hover:border-indigo-300 hover:shadow-md'
                  }`}
                >
                  <Icon className={`w-6 h-6 mx-auto mb-2 ${isSelected ? 'text-white' : 'text-gray-600'}`} />
                  <div className={`text-sm ${isSelected ? 'text-white font-medium' : 'text-gray-700'}`}>
                    {symptom.name[language]}
                  </div>
                </motion.button>
              );
            })}
          </div>

          <Button
            onClick={analyzeSymptoms}
            disabled={selectedSymptoms.length === 0}
            className="w-full bg-gradient-to-r from-indigo-500 to-purple-600 hover:from-indigo-600 hover:to-purple-700 text-white py-6 text-lg disabled:opacity-50 disabled:cursor-not-allowed shadow-lg"
          >
            <Search className="w-5 h-5 mr-2" />
            {t.checkSymptoms[language]}
          </Button>
        </motion.div>

        {/* Results */}
        <AnimatePresence>
          {showResults && (
            <motion.div
              id="results-section"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="bg-white/90 backdrop-blur-xl rounded-3xl p-6 shadow-xl border-2 border-white/50"
            >
              <h2 className="text-2xl font-bold mb-6 bg-gradient-to-r from-indigo-600 to-purple-600 bg-clip-text text-transparent">
                {t.possibleConditions[language]}
              </h2>
              
              {results.length > 0 ? (
                <div className="space-y-4">
                  {results.map((condition, index) => (
                    <motion.div
                      key={index}
                      initial={{ opacity: 0, x: -20 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: index * 0.1 }}
                      className={`p-6 rounded-2xl border-2 ${getSeverityBorderColor(condition.severity)} bg-gradient-to-br from-white to-gray-50 shadow-md`}
                    >
                      <div className="flex items-center gap-3 mb-4">
                        <div className={`px-4 py-2 rounded-full bg-gradient-to-r ${getSeverityColor(condition.severity)} text-white text-sm font-bold shadow-md`}>
                          {t.severity[condition.severity][language]}
                        </div>
                      </div>
                      
                      <h3 className="text-xl font-bold text-gray-800 mb-3">
                        {condition.name[language]}
                      </h3>
                      
                      <p className="text-gray-600 mb-4 leading-relaxed" dir={language === 'en' ? 'ltr' : 'rtl'}>
                        {condition.description[language]}
                      </p>
                      
                      <div className={`rounded-xl p-4 ${
                        condition.severity === 'high' 
                          ? 'bg-red-50 border-2 border-red-200' 
                          : 'bg-blue-50 border-2 border-blue-200'
                      }`}>
                        <div className={`font-bold text-sm mb-2 ${
                          condition.severity === 'high' ? 'text-red-800' : 'text-blue-800'
                        }`}>
                          {language === 'ps' ? '💊 سپارښتنه:' : language === 'fa' ? '💊 توصیه:' : '💊 Recommendation:'}
                        </div>
                        <div className="text-sm text-gray-700 leading-relaxed" dir={language === 'en' ? 'ltr' : 'rtl'}>
                          {condition.recommendation[language]}
                        </div>
                      </div>
                    </motion.div>
                  ))}
                </div>
              ) : (
                <motion.div
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  className="text-center py-8 text-gray-600"
                >
                  <AlertCircle className="w-16 h-16 mx-auto mb-4 text-gray-400" />
                  <p className="text-lg" dir={language === 'en' ? 'ltr' : 'rtl'}>
                    {t.noResults[language]}
                  </p>
                </motion.div>
              )}
            </motion.div>
          )}
        </AnimatePresence>

        <AdBanner type="large" />
      </div>
    </div>
  );
}
