import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  ArrowLeft, Settings, Edit2, Heart, Download, Globe, MapPin,
  CreditCard, Monitor, Trash2, Clock, LogOut, ChevronRight,
  Camera, Lock, User, Mail, Phone, Calendar, Users2
} from 'lucide-react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Card } from './ui/card';
import { ImageWithFallback } from './figma/ImageWithFallback';
import { ProfileManagement } from './ProfileManagement';

interface ModernProfilePageProps {
  language: 'ps' | 'fa' | 'en';
  onBack: () => void;
  onLogout: () => void;
  onLanguageChange?: (lang: 'ps' | 'fa' | 'en') => void;
}

export function ModernProfilePage({ language, onBack, onLogout, onLanguageChange }: ModernProfilePageProps) {
  const [activeView, setActiveView] = useState<'profile' | 'edit' | 'settings'>('profile');
  const [showModal, setShowModal] = useState<'location' | 'subscription' | 'display' | 'history' | 'favourites' | 'downloads' | 'language' | null>(null);
  const [profileData, setProfileData] = useState({
    firstName: '',
    lastName: '',
    username: '',
    email: '',
    phone: '',
    birth: '',
    gender: '',
    password: '', // د password لپاره
    profileImage: 'https://images.unsplash.com/photo-1633332755192-727a05c4013d?w=400'
  });

  const texts = {
    ps: {
      myProfile: 'زما پروفایل',
      editProfile: 'پروفایل سمول',
      firstName: 'لومړی نوم',
      lastName: 'ټولنام',
      username: 'کاروونکی نوم',
      email: 'برېښنالیک',
      phoneNumber: 'تلیفون نمبر',
      birth: 'د زیږون نیټه',
      gender: 'جنسیت',
      male: 'نارینه',
      female: 'ښځینه',
      other: 'بل',
      changePassword: 'پټنوم بدل کړه',
      favourites: 'خوښې شوي',
      downloads: 'ډاونلوډونه',
      languages: 'ژبې',
      location: 'موقعیت',
      subscription: 'ګډون',
      display: 'ښودنه',
      clearCache: 'کیش پاک کړه',
      clearHistory: 'تاریخچه پاک کړه',
      logOut: 'وتل',
      appVersion: 'د اپلیکیشن نسخه',
      save: 'خوندي کول',
      cancel: 'لغوه',
      settings: 'تنظیمات',
      backToProfile: 'پروفایل ته بیرته',
      selectGender: 'جنسیت غوره کړئ',
      selectBirth: 'د زیږون نیټه غوره کړئ'
    },
    fa: {
      myProfile: 'پروفایل من',
      editProfile: 'ویرایش پروفایل',
      firstName: 'نام',
      lastName: 'نام خانوادگی',
      username: 'نام کاربری',
      email: 'ایمیل',
      phoneNumber: 'شماره تلفن',
      birth: 'تاریخ تولد',
      gender: 'جنسیت',
      male: 'مرد',
      female: 'زن',
      other: 'دیگر',
      changePassword: 'تغییر رمز عبور',
      favourites: 'علاقه‌مندی‌ها',
      downloads: 'دانلودها',
      languages: 'زبان‌ها',
      location: 'موقعیت',
      subscription: 'اشتراک',
      display: 'نمایش',
      clearCache: 'پاک کردن کش',
      clearHistory: 'پاک کردن تاریخچه',
      logOut: 'خروج',
      appVersion: 'نسخه برنامه',
      save: 'ذخیره',
      cancel: 'لغو',
      settings: 'تنظیمات',
      backToProfile: 'بازگشت به پروفایل',
      selectGender: 'جنسیت را انتخاب کنید',
      selectBirth: 'تاریخ تولد را انتخاب کنید'
    },
    en: {
      myProfile: 'My Profile',
      editProfile: 'Edit Profile',
      firstName: 'First Name',
      lastName: 'Last Name',
      username: 'Username',
      email: 'Email',
      phoneNumber: 'Phone Number',
      birth: 'Birth Date',
      gender: 'Gender',
      male: 'Male',
      female: 'Female',
      other: 'Other',
      changePassword: 'Change Password',
      favourites: 'Favourites',
      downloads: 'Downloads',
      languages: 'Languages',
      location: 'Location',
      subscription: 'Subscription',
      display: 'Display',
      clearCache: 'Clear Cache',
      clearHistory: 'Clear History',
      logOut: 'Log Out',
      appVersion: 'App Version',
      save: 'Save',
      cancel: 'Cancel',
      settings: 'Settings',
      backToProfile: 'Back to Profile',
      selectGender: 'Select Gender',
      selectBirth: 'Select Birth Date'
    }
  };

  const t = texts[language];

  useEffect(() => {
    // Load user data from localStorage
    const userEmail = localStorage.getItem('healmate_userEmail');
    const userName = localStorage.getItem('healmate_userName');
    const users = JSON.parse(localStorage.getItem('healmate_users') || '[]');
    const currentUser = users.find((u: any) => u.email === userEmail);

    if (currentUser) {
      setProfileData({
        firstName: currentUser.name?.split(' ')[0] || '',
        lastName: currentUser.name?.split(' ').slice(1).join(' ') || '',
        username: currentUser.email?.split('@')[0] || '',
        email: currentUser.email || '',
        phone: currentUser.phone || '',
        birth: currentUser.birth || '',
        gender: currentUser.gender || '',
        password: currentUser.password || '', // د password لپاره
        profileImage: currentUser.profileImage || 'https://images.unsplash.com/photo-1633332755192-727a05c4013d?w=400'
      });
    } else if (userName && userEmail) {
      setProfileData({
        ...profileData,
        firstName: userName.split(' ')[0] || '',
        lastName: userName.split(' ').slice(1).join(' ') || '',
        email: userEmail,
        username: userEmail.split('@')[0] || ''
      });
    }
  }, []);

  const handleSave = () => {
    // Update user data in localStorage
    const userEmail = localStorage.getItem('healmate_userEmail');
    const users = JSON.parse(localStorage.getItem('healmate_users') || '[]');
    const updatedUsers = users.map((u: any) => {
      if (u.email === userEmail) {
        return {
          ...u,
          name: `${profileData.firstName} ${profileData.lastName}`.trim(),
          phone: profileData.phone,
          birth: profileData.birth,
          gender: profileData.gender,
          password: profileData.password, // د password لپاره
          profileImage: profileData.profileImage
        };
      }
      return u;
    });
    
    localStorage.setItem('healmate_users', JSON.stringify(updatedUsers));
    localStorage.setItem('healmate_userName', `${profileData.firstName} ${profileData.lastName}`.trim());
    
    setActiveView('profile');
    alert(language === 'ps' ? '✅ پروفایل بریالۍ وسپارل شو!' : 
          language === 'fa' ? '✅ پروفایل با موفقیت ذخیره شد!' : 
          '✅ Profile saved successfully!');
  };

  const handleImageChange = () => {
    const imageUrl = prompt(
      language === 'ps' ? 'د عکس URL دلته ولیکئ:' :
      language === 'fa' ? 'آدرس تصویر را وارد کنید:' :
      'Enter image URL:'
    );
    if (imageUrl) {
      setProfileData({ ...profileData, profileImage: imageUrl });
    }
  };

  const menuItems = [
    { icon: Heart, label: t.favourites, action: () => setShowModal('favourites') },
    { icon: Download, label: t.downloads, action: () => setShowModal('downloads') },
    { 
      icon: Globe, 
      label: t.languages, 
      action: () => setShowModal('language')
    },
    { icon: MapPin, label: t.location, action: () => setShowModal('location') },
    { icon: CreditCard, label: t.subscription, action: () => setShowModal('subscription') },
    { icon: Monitor, label: t.display, action: () => setShowModal('display') },
    { icon: Trash2, label: t.clearCache, action: () => {
      if (confirm(language === 'ps' ? 'کیش پاک کړو؟' : language === 'fa' ? 'کش پاک شود؟' : 'Clear cache?')) {
        // Clear cache but keep authentication
        const keysToKeep = ['healmate_userEmail', 'healmate_userName', 'healmate_isAuthenticated'];
        const allKeys = Object.keys(localStorage);
        allKeys.forEach(key => {
          if (key.startsWith('healmate_') && !keysToKeep.includes(key)) {
            localStorage.removeItem(key);
          }
        });
        alert(language === 'ps' ? '✅ کیش پاک شو!' : language === 'fa' ? '✅ کش پاک شد!' : '✅ Cache cleared!');
      }
    }},
    { icon: Clock, label: t.clearHistory, action: () => setShowModal('history') },
    { icon: LogOut, label: t.logOut, action: onLogout, danger: true }
  ];

  // Profile View
  const ProfileView = () => (
    <div className="max-w-4xl mx-auto px-4 py-6">
      {/* Profile Header Card */}
      <Card className="bg-white rounded-3xl shadow-lg border-0 overflow-hidden mb-6">
        <div className="relative">
          {/* Cover gradient */}
          <div className="h-32 bg-gradient-to-br from-pink-400 via-purple-400 to-indigo-400" />
          
          {/* Profile Picture */}
          <div className="absolute -bottom-16 left-1/2 -translate-x-1/2">
            <div className="relative">
              <div className="w-32 h-32 rounded-full border-4 border-white shadow-xl overflow-hidden bg-gray-100">
                <ImageWithFallback
                  src={profileData.profileImage}
                  alt="Profile"
                  className="w-full h-full object-cover"
                />
              </div>
              <button
                onClick={() => setActiveView('edit')}
                className="absolute bottom-0 right-0 w-10 h-10 bg-blue-500 rounded-full flex items-center justify-center text-white shadow-lg hover:bg-blue-600 transition-colors"
              >
                <Edit2 className="w-5 h-5" />
              </button>
            </div>
          </div>
        </div>

        {/* Profile Info */}
        <div className="pt-20 pb-6 px-6 text-center">
          <h2 className="text-2xl mb-1">
            {profileData.firstName} {profileData.lastName}
          </h2>
          <p className="text-gray-600 mb-4">
            {profileData.email}
          </p>
          <Button
            onClick={() => setActiveView('edit')}
            className="bg-blue-500 hover:bg-blue-600 text-white rounded-full px-6"
          >
            {t.editProfile}
          </Button>
        </div>
      </Card>

      {/* Menu Items */}
      <Card className="bg-white rounded-3xl shadow-lg border-0 overflow-hidden mb-4">
        <div className="divide-y divide-gray-100">
          {menuItems.slice(0, 2).map((item, index) => {
            const Icon = item.icon;
            return (
              <button
                key={index}
                onClick={item.action}
                className="w-full flex items-center justify-between px-6 py-4 hover:bg-gray-50 transition-colors"
              >
                <div className="flex items-center gap-4">
                  <Icon className="w-6 h-6 text-gray-700" />
                  <span className="text-gray-900">{item.label}</span>
                </div>
                <ChevronRight className="w-5 h-5 text-gray-400" />
              </button>
            );
          })}
        </div>
      </Card>

      <div className="h-2" />

      <Card className="bg-white rounded-3xl shadow-lg border-0 overflow-hidden mb-4">
        <div className="divide-y divide-gray-100">
          {menuItems.slice(2, 6).map((item, index) => {
            const Icon = item.icon;
            return (
              <button
                key={index}
                onClick={item.action}
                className="w-full flex items-center justify-between px-6 py-4 hover:bg-gray-50 transition-colors"
              >
                <div className="flex items-center gap-4">
                  <Icon className="w-6 h-6 text-gray-700" />
                  <span className="text-gray-900">{item.label}</span>
                </div>
                <ChevronRight className="w-5 h-5 text-gray-400" />
              </button>
            );
          })}
        </div>
      </Card>

      <div className="h-2" />

      <Card className="bg-white rounded-3xl shadow-lg border-0 overflow-hidden mb-4">
        <div className="divide-y divide-gray-100">
          {menuItems.slice(6).map((item, index) => {
            const Icon = item.icon;
            return (
              <button
                key={index}
                onClick={item.action}
                className={`w-full flex items-center justify-between px-6 py-4 hover:bg-gray-50 transition-colors ${
                  item.danger ? 'text-red-600' : ''
                }`}
              >
                <div className="flex items-center gap-4">
                  <Icon className={`w-6 h-6 ${item.danger ? 'text-red-600' : 'text-gray-700'}`} />
                  <span className={item.danger ? 'text-red-600' : 'text-gray-900'}>{item.label}</span>
                </div>
                <ChevronRight className={`w-5 h-5 ${item.danger ? 'text-red-400' : 'text-gray-400'}`} />
              </button>
            );
          })}
        </div>
      </Card>

      {/* App Version */}
      <p className="text-center text-gray-500 text-sm mt-6">
        {t.appVersion} 2.3
      </p>
    </div>
  );

  // Edit Profile View
  const EditProfileView = () => (
    <div className="max-w-2xl mx-auto px-4 py-6">
      <Card className="bg-white rounded-3xl shadow-lg border-0 overflow-hidden">
        <div className="p-6">
          {/* Profile Picture Editor */}
          <div className="flex flex-col items-center mb-8">
            <div className="relative mb-4">
              <div className="w-28 h-28 rounded-full overflow-hidden bg-gray-100 shadow-lg">
                <ImageWithFallback
                  src={profileData.profileImage}
                  alt="Profile"
                  className="w-full h-full object-cover"
                />
              </div>
              <button
                onClick={handleImageChange}
                className="absolute bottom-0 right-0 w-10 h-10 bg-blue-500 rounded-full flex items-center justify-center text-white shadow-lg hover:bg-blue-600 transition-colors"
              >
                <Camera className="w-5 h-5" />
              </button>
            </div>
            <h2 className="text-2xl mb-2">{t.editProfile}</h2>
          </div>

          {/* Form Fields */}
          <div className="space-y-4">
            {/* First Name */}
            <div>
              <Label className="text-gray-600 text-sm mb-2">{t.firstName}</Label>
              <Input
                value={profileData.firstName}
                onChange={(e) => setProfileData({ ...profileData, firstName: e.target.value })}
                placeholder={t.firstName}
                className="rounded-xl border-2 border-gray-200 focus:border-blue-500"
              />
            </div>

            {/* Last Name */}
            <div>
              <Label className="text-gray-600 text-sm mb-2">{t.lastName}</Label>
              <Input
                value={profileData.lastName}
                onChange={(e) => setProfileData({ ...profileData, lastName: e.target.value })}
                placeholder={t.lastName}
                className="rounded-xl border-2 border-gray-200 focus:border-blue-500"
              />
            </div>

            {/* Username */}
            <div>
              <Label className="text-gray-600 text-sm mb-2">{t.username}</Label>
              <Input
                value={profileData.username}
                onChange={(e) => setProfileData({ ...profileData, username: e.target.value })}
                placeholder={t.username}
                className="rounded-xl border-2 border-gray-200 focus:border-blue-500"
              />
            </div>

            {/* Email */}
            <div>
              <Label className="text-gray-600 text-sm mb-2">{t.email}</Label>
              <Input
                type="email"
                value={profileData.email}
                onChange={(e) => setProfileData({ ...profileData, email: e.target.value })}
                placeholder={t.email}
                className="rounded-xl border-2 border-gray-200 focus:border-blue-500"
              />
            </div>

            {/* Phone Number */}
            <div>
              <Label className="text-gray-600 text-sm mb-2">{t.phoneNumber}</Label>
              <div className="flex gap-2">
                <select className="px-3 py-2 border-2 border-gray-200 rounded-xl bg-white">
                  <option>+93</option>
                  <option>+1</option>
                  <option>+44</option>
                </select>
                <Input
                  type="tel"
                  value={profileData.phone}
                  onChange={(e) => setProfileData({ ...profileData, phone: e.target.value })}
                  placeholder="700 000 000"
                  className="flex-1 rounded-xl border-2 border-gray-200 focus:border-blue-500"
                />
              </div>
            </div>

            {/* Birth Date */}
            <div>
              <Label className="text-gray-600 text-sm mb-2">{t.birth}</Label>
              <Input
                type="date"
                value={profileData.birth}
                onChange={(e) => setProfileData({ ...profileData, birth: e.target.value })}
                className="rounded-xl border-2 border-gray-200 focus:border-blue-500"
              />
            </div>

            {/* Gender */}
            <div>
              <Label className="text-gray-600 text-sm mb-2">{t.gender}</Label>
              <select
                value={profileData.gender}
                onChange={(e) => setProfileData({ ...profileData, gender: e.target.value })}
                className="w-full px-4 py-2 border-2 border-gray-200 rounded-xl bg-white focus:border-blue-500 focus:outline-none"
              >
                <option value="">{t.selectGender}</option>
                <option value="male">{t.male}</option>
                <option value="female">{t.female}</option>
                <option value="other">{t.other}</option>
              </select>
            </div>

            {/* Change Password Button */}
            <Button
              className="w-full bg-gradient-to-r from-blue-600 to-indigo-600 text-white rounded-xl py-6 flex items-center justify-center gap-2"
              onClick={() => alert(language === 'ps' ? 'د پټنوم بدلول ډیر ژر!' : 
                                    language === 'fa' ? 'تغییر رمز عبور به زودی!' : 
                                    'Change password coming soon!')}
            >
              <Lock className="w-5 h-5" />
              {t.changePassword}
            </Button>
          </div>
        </div>
      </Card>
    </div>
  );

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 via-blue-50 to-purple-50 overflow-y-auto pb-24">
      {/* Header */}
      <div className="sticky top-0 z-40 bg-white/90 backdrop-blur-lg border-b border-gray-200 shadow-sm">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Button
                variant="ghost"
                size="icon"
                onClick={() => {
                  if (activeView === 'edit') {
                    setActiveView('profile');
                  } else {
                    onBack();
                  }
                }}
                className="rounded-full"
              >
                <ArrowLeft className="w-5 h-5" />
              </Button>
              <h1 className="text-xl">
                {activeView === 'profile' ? t.myProfile : t.editProfile}
              </h1>
            </div>
            {activeView === 'profile' && (
              <Button 
                variant="ghost" 
                size="icon" 
                className="rounded-full"
                onClick={() => setActiveView('settings')}
              >
                <Settings className="w-5 h-5" />
              </Button>
            )}
          </div>
        </div>
      </div>

      {/* Content */}
      <AnimatePresence mode="wait">
        {activeView === 'profile' ? (
          <motion.div
            key="profile"
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: 20 }}
          >
            <ProfileView />
          </motion.div>
        ) : activeView === 'settings' ? (
          <motion.div
            key="settings"
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
          >
            <ProfileManagement
              language={language}
              onBack={() => setActiveView('profile')}
              currentEmail={profileData.email}
              currentPassword={profileData.password || 'healmate123'}
            />
          </motion.div>
        ) : (
          <motion.div
            key="edit"
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
          >
            <EditProfileView />
            
            {/* Save/Cancel Buttons - Fixed at bottom on mobile */}
            <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 p-4 md:relative md:max-w-2xl md:mx-auto md:mt-4 md:bg-transparent md:border-0">
              <div className="flex gap-3 max-w-2xl mx-auto">
                <Button
                  onClick={() => setActiveView('profile')}
                  variant="outline"
                  className="flex-1 rounded-xl py-6 border-2"
                >
                  {t.cancel}
                </Button>
                <Button
                  onClick={handleSave}
                  className="flex-1 bg-gradient-to-r from-blue-600 to-indigo-600 text-white rounded-xl py-6"
                >
                  {t.save}
                </Button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Modals - د modal ټولو لپاره */}
      <AnimatePresence>
        {showModal && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4"
            onClick={() => setShowModal(null)}
          >
            <motion.div
              initial={{ scale: 0.9, y: 20 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.9, y: 20 }}
              onClick={(e) => e.stopPropagation()}
              className="bg-white rounded-3xl shadow-2xl max-w-md w-full p-6"
            >
              {/* Language Modal */}
              {showModal === 'language' && (
                <div>
                  <div className="flex items-center gap-3 mb-4">
                    <div className="w-12 h-12 bg-gradient-to-br from-green-500 to-emerald-600 rounded-xl flex items-center justify-center">
                      <Globe className="w-6 h-6 text-white" />
                    </div>
                    <h3 className="text-xl font-bold text-gray-900">
                      {language === 'ps' ? 'ژبه غوره کړئ' : language === 'fa' ? 'انتخاب زبان' : 'Select Language'}
                    </h3>
                  </div>
                  <p className="text-gray-600 mb-4">
                    {language === 'ps' 
                      ? 'د اپلیکیشن ژبه غوره کړئ'
                      : language === 'fa'
                      ? 'زبان برنامه را انتخاب کنید'
                      : 'Choose your preferred app language'
                    }
                  </p>
                  <div className="space-y-2">
                    {[
                      { code: 'ps' as const, name: 'پښتو', flag: '🇦🇫' },
                      { code: 'fa' as const, name: 'دری', flag: '🇦🇫' },
                      { code: 'en' as const, name: 'English', flag: '🇬🇧' }
                    ].map((lang) => (
                      <button
                        key={lang.code}
                        onClick={() => {
                          if (onLanguageChange) {
                            onLanguageChange(lang.code);
                          }
                          setShowModal(null);
                        }}
                        className={`w-full p-4 rounded-xl border-2 transition-all flex items-center gap-3 ${
                          language === lang.code
                            ? 'border-green-500 bg-green-50'
                            : 'border-gray-200 hover:border-green-300 hover:bg-gray-50'
                        }`}
                      >
                        <span className="text-3xl">{lang.flag}</span>
                        <span className="font-bold text-gray-900">{lang.name}</span>
                        {language === lang.code && (
                          <span className="ml-auto text-green-600">✓</span>
                        )}
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {/* Location Modal */}
              {showModal === 'location' && (
                <div>
                  <div className="flex items-center gap-3 mb-4">
                    <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-cyan-600 rounded-xl flex items-center justify-center">
                      <MapPin className="w-6 h-6 text-white" />
                    </div>
                    <h3 className="text-xl font-bold text-gray-900">
                      {language === 'ps' ? 'موقعیت' : language === 'fa' ? 'موقعیت' : 'Location'}
                    </h3>
                  </div>
                  <p className="text-gray-600 mb-4">
                    {language === 'ps' 
                      ? 'د موقعیت تنظیمات اوس فعال شوي. تاسو کولی شئ خپل موقعیت تنظیم کړئ.'
                      : language === 'fa'
                      ? 'تنظیمات موقعیت اکنون فعال شده است. می‌توانید موقعیت خود را تنظیم کنید.'
                      : 'Location settings are now active. You can set your location.'
                    }
                  </p>
                  <div className="space-y-3">
                    <input
                      type="text"
                      placeholder={language === 'ps' ? 'خپل موقعیت ولیکئ' : language === 'fa' ? 'موقعیت خود را وارد کنید' : 'Enter your location'}
                      className="w-full px-4 py-3 border-2 border-gray-200 rounded-xl focus:border-blue-500 focus:outline-none"
                    />
                    <Button
                      className="w-full bg-gradient-to-r from-blue-600 to-cyan-600 text-white rounded-xl py-3"
                      onClick={() => {
                        alert(language === 'ps' ? '✅ موقعیت خوندي شو!' : language === 'fa' ? '✅ موقعیت ذخیره شد!' : '✅ Location saved!');
                        setShowModal(null);
                      }}
                    >
                      {language === 'ps' ? 'خوندي کول' : language === 'fa' ? 'ذخیره' : 'Save'}
                    </Button>
                  </div>
                </div>
              )}

              {/* Subscription Modal */}
              {showModal === 'subscription' && (
                <div>
                  <div className="flex items-center gap-3 mb-4">
                    <div className="w-12 h-12 bg-gradient-to-br from-yellow-500 to-amber-600 rounded-xl flex items-center justify-center">
                      <CreditCard className="w-6 h-6 text-white" />
                    </div>
                    <h3 className="text-xl font-bold text-gray-900">
                      {language === 'ps' ? 'ګډون' : language === 'fa' ? 'اشتراک' : 'Subscription'}
                    </h3>
                  </div>
                  <div className="mb-4 p-4 rounded-xl bg-gradient-to-br from-yellow-50 to-amber-50 border-2 border-yellow-200">
                    <p className="font-bold text-yellow-700 mb-2">
                      {language === 'ps' ? '🌟 پریمیم فیچرونه' : language === 'fa' ? '🌟 ویژگی‌های پریمیوم' : '🌟 Premium Features'}
                    </p>
                    <ul className="text-sm text-yellow-600 space-y-1">
                      <li>• {language === 'ps' ? 'بې حده AI مشورې' : language === 'fa' ? 'مشاوره‌های نامحدود AI' : 'Unlimited AI consultations'}</li>
                      <li>• {language === 'ps' ? 'پرته له اعلاناتو' : language === 'fa' ? 'بدون تبلیغات' : 'Ad-free experience'}</li>
                      <li>• {language === 'ps' ? 'د ډاکټرانو ځانګړي لاسرسی' : language === 'fa' ? 'دسترسی ویژه به پزشکان' : 'Priority doctor access'}</li>
                    </ul>
                  </div>
                  <Button
                    className="w-full bg-gradient-to-r from-yellow-600 to-amber-600 text-white rounded-xl py-3"
                    onClick={() => {
                      alert(language === 'ps' ? '💎 پریمیم ډیر ژر!' : language === 'fa' ? '💎 پریمیوم به زودی!' : '💎 Premium coming soon!');
                      setShowModal(null);
                    }}
                  >
                    {language === 'ps' ? 'پریمیم واخلئ' : language === 'fa' ? 'دریافت پریمیوم' : 'Get Premium'}
                  </Button>
                </div>
              )}

              {/* Display Modal */}
              {showModal === 'display' && (
                <div>
                  <div className="flex items-center gap-3 mb-4">
                    <div className="w-12 h-12 bg-gradient-to-br from-purple-500 to-indigo-600 rounded-xl flex items-center justify-center">
                      <Monitor className="w-6 h-6 text-white" />
                    </div>
                    <h3 className="text-xl font-bold text-gray-900">
                      {language === 'ps' ? 'ښودنه' : language === 'fa' ? 'نمایش' : 'Display'}
                    </h3>
                  </div>
                  <div className="space-y-4">
                    <div className="p-4 rounded-xl bg-gray-50 border border-gray-200">
                      <div className="flex items-center justify-between mb-2">
                        <p className="font-medium text-gray-900">
                          {language === 'ps' ? 'تیاره حالت' : language === 'fa' ? 'حالت تاریک' : 'Dark Mode'}
                        </p>
                        <input type="checkbox" className="w-5 h-5 rounded accent-purple-600" />
                      </div>
                      <p className="text-sm text-gray-600">
                        {language === 'ps' ? 'د شپې لپاره غوره' : language === 'fa' ? 'بهتر برای شب' : 'Better for night'}
                      </p>
                    </div>
                    <div className="p-4 rounded-xl bg-gray-50 border border-gray-200">
                      <div className="flex items-center justify-between mb-2">
                        <p className="font-medium text-gray-900">
                          {language === 'ps' ? 'لوی متن' : language === 'fa' ? 'متن بزرگ' : 'Large Text'}
                        </p>
                        <input type="checkbox" className="w-5 h-5 rounded accent-purple-600" />
                      </div>
                      <p className="text-sm text-gray-600">
                        {language === 'ps' ? 'د لوستلو اسانتیا' : language === 'fa' ? 'راحتی خواندن' : 'Easy reading'}
                      </p>
                    </div>
                    <Button
                      className="w-full bg-gradient-to-r from-purple-600 to-indigo-600 text-white rounded-xl py-3"
                      onClick={() => {
                        alert(language === 'ps' ? '✅ ښودنه خوندي شو!' : language === 'fa' ? '✅ نمایش ذخیره شد!' : '✅ Display saved!');
                        setShowModal(null);
                      }}
                    >
                      {language === 'ps' ? 'خوندي کول' : language === 'fa' ? 'ذخیره' : 'Save'}
                    </Button>
                  </div>
                </div>
              )}

              {/* History Modal */}
              {showModal === 'history' && (
                <div>
                  <div className="flex items-center gap-3 mb-4">
                    <div className="w-12 h-12 bg-gradient-to-br from-red-500 to-pink-600 rounded-xl flex items-center justify-center">
                      <Clock className="w-6 h-6 text-white" />
                    </div>
                    <h3 className="text-xl font-bold text-gray-900">
                      {language === 'ps' ? 'تاریخچه پاک کول' : language === 'fa' ? 'پاک کردن تاریخچه' : 'Clear History'}
                    </h3>
                  </div>
                  <p className="text-gray-600 mb-4">
                    {language === 'ps' 
                      ? 'ایا تاسو غواړئ ټوله تاریخچه پاک کړئ؟ دا کار د بیرته راګرځیدو وړ نه دی.'
                      : language === 'fa'
                      ? 'آیا می‌خواهید تمام تاریخچه را پاک کنید؟ این عمل قابل بازگشت نیست.'
                      : 'Do you want to clear all history? This action cannot be undone.'
                    }
                  </p>
                  <div className="flex gap-3">
                    <Button
                      variant="outline"
                      className="flex-1 rounded-xl py-3"
                      onClick={() => setShowModal(null)}
                    >
                      {language === 'ps' ? 'لغوه' : language === 'fa' ? 'لغو' : 'Cancel'}
                    </Button>
                    <Button
                      className="flex-1 bg-gradient-to-r from-red-600 to-pink-600 text-white rounded-xl py-3"
                      onClick={() => {
                        alert(language === 'ps' ? '✅ تاریخچه پاک شو!' : language === 'fa' ? '✅ تاریخچه پاک شد!' : '✅ History cleared!');
                        setShowModal(null);
                      }}
                    >
                      {language === 'ps' ? 'پاک کول' : language === 'fa' ? 'پاک کردن' : 'Clear'}
                    </Button>
                  </div>
                </div>
              )}

              {/* Favourites Modal */}
              {showModal === 'favourites' && (
                <div>
                  <div className="flex items-center gap-3 mb-4">
                    <div className="w-12 h-12 bg-gradient-to-br from-pink-500 to-rose-600 rounded-xl flex items-center justify-center">
                      <Heart className="w-6 h-6 text-white" />
                    </div>
                    <h3 className="text-xl font-bold text-gray-900">
                      {language === 'ps' ? 'خوښې شوي' : language === 'fa' ? 'علاقه‌مندی‌ها' : 'Favourites'}
                    </h3>
                  </div>
                  <p className="text-gray-600 mb-4">
                    {language === 'ps' 
                      ? 'ستاسو خوښې شوي پوستونه او معلومات دلته ښودل کیږي.'
                      : language === 'fa'
                      ? 'پست‌ها و اطلاعات مورد علاقه شما اینجا نمایش داده می‌شود.'
                      : 'Your favourite posts and content will be shown here.'
                    }
                  </p>
                  <div className="p-4 rounded-xl bg-gray-50 border border-gray-200 text-center">
                    <Heart className="w-12 h-12 text-gray-400 mx-auto mb-2" />
                    <p className="text-sm text-gray-500">
                      {language === 'ps' ? 'هیڅ خوښې شوي نشته' : language === 'fa' ? 'علاقه‌مندی وجود ندارد' : 'No favourites yet'}
                    </p>
                  </div>
                  <Button
                    variant="outline"
                    className="w-full rounded-xl py-3 mt-4"
                    onClick={() => setShowModal(null)}
                  >
                    {language === 'ps' ? 'بندول' : language === 'fa' ? 'بستن' : 'Close'}
                  </Button>
                </div>
              )}

              {/* Downloads Modal */}
              {showModal === 'downloads' && (
                <div>
                  <div className="flex items-center gap-3 mb-4">
                    <div className="w-12 h-12 bg-gradient-to-br from-green-500 to-emerald-600 rounded-xl flex items-center justify-center">
                      <Download className="w-6 h-6 text-white" />
                    </div>
                    <h3 className="text-xl font-bold text-gray-900">
                      {language === 'ps' ? 'ډاونلوډونه' : language === 'fa' ? 'دانلودها' : 'Downloads'}
                    </h3>
                  </div>
                  <p className="text-gray-600 mb-4">
                    {language === 'ps' 
                      ? 'ستاسو ډاونلوډ شوي فایلونه او کتابونه دلته ښودل کیږي.'
                      : language === 'fa'
                      ? 'فایل‌ها و کتاب‌های دانلود شده شما اینجا نمایش داده می‌شود.'
                      : 'Your downloaded files and books will be shown here.'
                    }
                  </p>
                  <div className="p-4 rounded-xl bg-gray-50 border border-gray-200 text-center">
                    <Download className="w-12 h-12 text-gray-400 mx-auto mb-2" />
                    <p className="text-sm text-gray-500">
                      {language === 'ps' ? 'هیڅ ډاونلوډ نشته' : language === 'fa' ? 'دانلودی وجود ندارد' : 'No downloads yet'}
                    </p>
                  </div>
                  <Button
                    variant="outline"
                    className="w-full rounded-xl py-3 mt-4"
                    onClick={() => setShowModal(null)}
                  >
                    {language === 'ps' ? 'بندول' : language === 'fa' ? 'بستن' : 'Close'}
                  </Button>
                </div>
              )}

              {/* Close Button (X) */}
              <button
                onClick={() => setShowModal(null)}
                className="absolute top-4 right-4 w-8 h-8 rounded-full bg-gray-100 hover:bg-gray-200 flex items-center justify-center transition-colors"
              >
                <span className="text-gray-600 text-xl">×</span>
              </button>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}