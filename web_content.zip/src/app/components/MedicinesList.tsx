import { useState, useMemo } from "react";
import { Card, CardContent, CardHeader } from "./ui/card";
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";
import { Input } from "./ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select";
import { 
  Pill, 
  Search, 
  Filter,
  Package,
  CheckCircle,
  AlertCircle,
  Sparkles,
  Building2
} from "lucide-react";
import { MedicineDetailModal } from "./MedicineDetailModal";
import { getAllMedicines, getMedicinesByCategory, searchMedicines, medicineCategories, type Medicine } from "../data/medicines-database";
import { AdBanner } from "./AdBanner";

export function MedicinesList() {
  const [selectedCategory, setSelectedCategory] = useState("all");
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedMedicine, setSelectedMedicine] = useState<Medicine | null>(null);
  const [modalOpen, setModalOpen] = useState(false);

  // Get filtered medicines
  const filteredMedicines = useMemo(() => {
    let medicines = selectedCategory === "all" 
      ? getAllMedicines() 
      : getMedicinesByCategory(selectedCategory);
    
    if (searchQuery.trim()) {
      medicines = searchMedicines(searchQuery);
    }
    
    return medicines;
  }, [selectedCategory, searchQuery]);

  const handleMedicineClick = (medicine: Medicine) => {
    setSelectedMedicine(medicine);
    setModalOpen(true);
  };

  return (
    <section className="py-16 md:py-24 bg-gradient-to-b from-white via-emerald-50/30 to-white relative overflow-hidden">
      {/* Background Decoration */}
      <div className="absolute top-0 left-0 w-[600px] h-[600px] bg-gradient-to-br from-emerald-100/50 to-teal-100/50 rounded-full blur-3xl animate-float"></div>
      <div className="absolute bottom-0 right-0 w-[500px] h-[500px] bg-gradient-to-br from-cyan-100/50 to-blue-100/50 rounded-full blur-3xl animate-float-delayed"></div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        {/* Header */}
        <div className="text-center mb-12 md:mb-16 space-y-4">
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-emerald-100 to-teal-100 rounded-full">
            <Pill className="w-4 h-4 text-emerald-600 animate-pulse-glow" />
            <span className="text-emerald-700 text-sm uppercase tracking-wider">Medicines Database</span>
          </div>
          <h2 className="text-4xl md:text-6xl">
            <span className="bg-gradient-to-r from-emerald-600 via-teal-600 to-cyan-600 bg-clip-text text-transparent">
              1500+ Medicines
            </span>
          </h2>
          <p className="text-gray-600 max-w-2xl mx-auto text-lg">
            د درملو بشپړ ډیټابیس - Complete pharmaceutical database with full details
          </p>
        </div>

        {/* Search and Filter */}
        <div className="mb-8 space-y-4">
          <div className="flex flex-col md:flex-row gap-4">
            {/* Search */}
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
              <Input
                type="text"
                placeholder="Search medicines..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10 h-12"
              />
            </div>

            {/* Category Filter */}
            <div className="md:w-64">
              <Select value={selectedCategory} onValueChange={setSelectedCategory}>
                <SelectTrigger className="h-12">
                  <Filter className="w-4 h-4 mr-2" />
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {medicineCategories.map((category) => (
                    <SelectItem key={category.id} value={category.id}>
                      {category.name} - {category.dari}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          {/* Results count */}
          <div className="flex items-center justify-between">
            <p className="text-sm text-gray-600">
              Showing <span className="text-emerald-600">{filteredMedicines.length}</span> medicines
            </p>
            {searchQuery && (
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setSearchQuery("")}
                className="text-emerald-600 hover:text-emerald-700"
              >
                Clear search
              </Button>
            )}
          </div>
        </div>

        {/* Medicines Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {filteredMedicines.map((medicine, index) => (
            <div key={`medicine-${medicine.id}-${index}`} className="contents">
              {/* Show Ad after every 6 medicines */}
              {index > 0 && index % 6 === 0 && (
                <div className="col-span-1 md:col-span-2 lg:col-span-3 xl:col-span-4">
                  <AdBanner size="large" position="middle" />
                </div>
              )}
              
            <Card
              className="group hover:shadow-xl transition-all duration-300 hover:-translate-y-1 cursor-pointer border-0"
              onClick={() => handleMedicineClick(medicine)}
            >
              <CardHeader className="pb-3">
                <div className="relative w-full h-40 rounded-lg overflow-hidden mb-3 bg-gradient-to-br from-emerald-50 to-teal-50">
                  <img
                    src={medicine.image}
                    alt={medicine.name}
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                  />
                  {medicine.prescriptionRequired && (
                    <Badge className="absolute top-2 right-2 bg-red-500 text-white">
                      Rx
                    </Badge>
                  )}
                  {medicine.inStock ? (
                    <Badge className="absolute top-2 left-2 bg-green-500 text-white">
                      <CheckCircle className="w-3 h-3 mr-1" />
                      In Stock
                    </Badge>
                  ) : (
                    <Badge className="absolute top-2 left-2 bg-gray-500 text-white">
                      <AlertCircle className="w-3 h-3 mr-1" />
                      Out of Stock
                    </Badge>
                  )}
                </div>

                <div className="space-y-2">
                  <h3 className="text-lg group-hover:text-emerald-600 transition-colors line-clamp-1">
                    {medicine.name}
                  </h3>
                  <p className="text-sm text-gray-600 line-clamp-1">{medicine.nameDari}</p>
                  
                  <div className="flex items-center gap-2">
                    <Badge variant="outline" className="text-xs">
                      {medicine.genericName}
                    </Badge>
                  </div>
                </div>
              </CardHeader>

              <CardContent className="space-y-3 pt-0">
                {/* Manufacturer */}
                <div className="flex items-center gap-2 text-sm text-gray-600">
                  <Building2 className="w-4 h-4 text-emerald-500" />
                  <span className="line-clamp-1">{medicine.manufacturer}</span>
                </div>

                {/* Type & Dosage */}
                <div className="flex items-center justify-between text-sm">
                  <div className="flex items-center gap-1">
                    <Package className="w-4 h-4 text-teal-500" />
                    <span className="text-gray-600">{medicine.type}</span>
                  </div>
                  <Badge className="bg-gradient-to-r from-emerald-500 to-teal-600 text-white">
                    {medicine.strength}
                  </Badge>
                </div>

                {/* Price */}
                <div className="flex items-center justify-between pt-2 border-t">
                  <span className="text-xl text-emerald-600">{medicine.price}</span>
                  <Button
                    size="sm"
                    className="bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-600 hover:to-teal-700"
                    onClick={(e) => {
                      e.stopPropagation();
                      handleMedicineClick(medicine);
                    }}
                  >
                    View Details
                  </Button>
                </div>
              </CardContent>
            </Card>
            </div>
          ))}
        </div>

        {/* No results message */}
        {filteredMedicines.length === 0 && (
          <div className="text-center py-16">
            <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-gray-100 mb-4">
              <AlertCircle className="w-8 h-8 text-gray-400" />
            </div>
            <h3 className="text-xl text-gray-900 mb-2">No medicines found</h3>
            <p className="text-gray-600 mb-4">
              Try adjusting your search or filter to find what you're looking for
            </p>
            <Button
              onClick={() => {
                setSearchQuery("");
                setSelectedCategory("all");
              }}
              className="bg-gradient-to-r from-emerald-500 to-teal-600"
            >
              Reset Filters
            </Button>
          </div>
        )}

        {/* Stats Bar */}
        <div className="mt-12 grid grid-cols-1 md:grid-cols-4 gap-4">
          <Card className="border-0 bg-gradient-to-br from-emerald-50 to-teal-50">
            <CardContent className="p-6 text-center">
              <div className="text-3xl text-emerald-600 mb-2">1500+</div>
              <div className="text-sm text-gray-600">Total Medicines</div>
            </CardContent>
          </Card>
          <Card className="border-0 bg-gradient-to-br from-blue-50 to-cyan-50">
            <CardContent className="p-6 text-center">
              <div className="text-3xl text-blue-600 mb-2">16</div>
              <div className="text-sm text-gray-600">Categories</div>
            </CardContent>
          </Card>
          <Card className="border-0 bg-gradient-to-br from-purple-50 to-pink-50">
            <CardContent className="p-6 text-center">
              <div className="text-3xl text-purple-600 mb-2">50+</div>
              <div className="text-sm text-gray-600">Manufacturers</div>
            </CardContent>
          </Card>
          <Card className="border-0 bg-gradient-to-br from-amber-50 to-yellow-50">
            <CardContent className="p-6 text-center">
              <div className="text-3xl text-amber-600 mb-2">100%</div>
              <div className="text-sm text-gray-600">Verified</div>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Medicine Detail Modal */}
      <MedicineDetailModal
        medicine={selectedMedicine}
        open={modalOpen}
        onClose={() => {
          setModalOpen(false);
          setSelectedMedicine(null);
        }}
      />
    </section>
  );
}

export default MedicinesList;
