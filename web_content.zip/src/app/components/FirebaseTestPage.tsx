// Firebase Test Page - د Firebase ټیسټ پاڼه
// د Firebase او AdminUsersManagement ټیسټولو لپاره

import { useState } from 'react';
import { motion } from 'motion/react';
import { ArrowLeft, Database, Users, Cloud, CheckCircle } from 'lucide-react';
import { SimpleButton as Button } from './SimpleButton';
import { AdminUsersManagement } from './AdminUsersManagement';
import { FirebaseSettings } from './FirebaseSettings';

interface FirebaseTestPageProps {
  language: 'ps' | 'fa' | 'en';
  onBack: () => void;
}

export function FirebaseTestPage({ language, onBack }: FirebaseTestPageProps) {
  const [activeView, setActiveView] = useState<'menu' | 'users' | 'firebase'>('menu');
  const [darkMode, setDarkMode] = useState(false);

  const translations = {
    ps: {
      title: 'د Firebase ټیسټ پاڼه',
      subtitle: 'د Firebase او Users Management ټیسټول',
      viewUsers: 'د کاروونکو لیست وګورئ',
      viewUsersDesc: 'د Firestore څخه ټول کاروونکي واخلئ او وښایئ',
      firebaseSettings: 'د Firebase ترتیبات',
      firebaseSettingsDesc: 'د Cloud Sync ترتیبات او حالت',
      darkMode: 'د شپې حالت',
      back: 'بیرته'
    },
    fa: {
      title: 'صفحه تست Firebase',
      subtitle: 'تست Firebase و مدیریت کاربران',
      viewUsers: 'مشاهده لیست کاربران',
      viewUsersDesc: 'دریافت و نمایش تمام کاربران از Firestore',
      firebaseSettings: 'تنظیمات Firebase',
      firebaseSettingsDesc: 'تنظیمات و وضعیت همگام‌سازی ابری',
      darkMode: 'حالت شب',
      back: 'بازگشت'
    },
    en: {
      title: 'Firebase Test Page',
      subtitle: 'Test Firebase and Users Management',
      viewUsers: 'View Users List',
      viewUsersDesc: 'Fetch and display all users from Firestore',
      firebaseSettings: 'Firebase Settings',
      firebaseSettingsDesc: 'Cloud Sync settings and status',
      darkMode: 'Dark Mode',
      back: 'Back'
    }
  };

  const txt = translations[language];

  if (activeView === 'users') {
    return <AdminUsersManagement language={language} darkMode={darkMode} onClose={() => setActiveView('menu')} />;
  }

  if (activeView === 'firebase') {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 via-purple-50 to-pink-50 dark:from-gray-900 dark:via-slate-900 dark:to-zinc-900">
        <div className="container mx-auto p-6">
          <div className="mb-6">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setActiveView('menu')}
              className="mb-4"
            >
              <ArrowLeft className="w-4 h-4 mr-2" />
              {txt.back}
            </Button>
          </div>
          <FirebaseSettings language={language} darkMode={darkMode} />
        </div>
      </div>
    );
  }

  return (
    <div className={`min-h-screen pb-20 ${
      darkMode 
        ? 'bg-gradient-to-br from-gray-900 via-slate-900 to-zinc-900'
        : 'bg-gradient-to-br from-blue-50 via-purple-50 to-pink-50'
    }`}>
      {/* Animated Background Mesh */}
      <div className="fixed inset-0 pointer-events-none overflow-hidden">
        <div className={`absolute top-0 left-0 w-96 h-96 rounded-full blur-3xl opacity-20 animate-pulse ${
          darkMode ? 'bg-blue-600' : 'bg-blue-400'
        }`} style={{ animationDuration: '4s' }} />
        <div className={`absolute bottom-0 right-0 w-96 h-96 rounded-full blur-3xl opacity-20 animate-pulse ${
          darkMode ? 'bg-purple-600' : 'bg-purple-400'
        }`} style={{ animationDuration: '6s', animationDelay: '1s' }} />
      </div>

      <div className="container mx-auto px-4 py-8 relative z-10">
        {/* Header */}
        <div className="mb-8">
          <Button
            variant="ghost"
            size="sm"
            onClick={onBack}
            className={`mb-4 ${darkMode ? 'text-white' : ''}`}
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            {txt.back}
          </Button>

          <div className="text-center">
            <motion.h1
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              className={`text-4xl font-bold mb-2 bg-gradient-to-r bg-clip-text text-transparent ${
                darkMode
                  ? 'from-blue-400 via-purple-400 to-pink-400'
                  : 'from-blue-600 via-purple-600 to-pink-600'
              }`}
            >
              {txt.title}
            </motion.h1>
            <p className={`text-sm ${darkMode ? 'text-gray-400' : 'text-gray-600'}`}>
              {txt.subtitle}
            </p>
          </div>

          {/* Dark Mode Toggle */}
          <div className="flex justify-center mt-6">
            <button
              onClick={() => setDarkMode(!darkMode)}
              className={`px-6 py-3 rounded-2xl font-medium transition-all ${
                darkMode
                  ? 'bg-gray-700 text-white hover:bg-gray-600'
                  : 'bg-white text-gray-900 hover:bg-gray-100 shadow-lg'
              }`}
            >
              🌓 {txt.darkMode}
            </button>
          </div>
        </div>

        {/* Test Cards */}
        <div className="max-w-4xl mx-auto grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Users Management Card */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="relative group"
          >
            <div className="absolute inset-0 bg-gradient-to-br from-blue-500 to-cyan-600 opacity-0 group-hover:opacity-10 rounded-3xl blur-xl transition-all duration-500" />
            <div className={`relative backdrop-blur-xl rounded-3xl p-8 border shadow-xl hover:shadow-2xl transition-all duration-300 hover:scale-[1.02] ${
              darkMode
                ? 'bg-gray-800/70 border-gray-700/50'
                : 'bg-white/70 border-white/50'
            }`}>
              <div className="mb-6">
                <div className="w-16 h-16 bg-gradient-to-br from-blue-500 to-cyan-600 rounded-2xl flex items-center justify-center mb-4 shadow-lg">
                  <Users className="w-8 h-8 text-white" />
                </div>
                <h3 className={`text-2xl font-bold mb-2 ${darkMode ? 'text-white' : 'text-gray-900'}`}>
                  {txt.viewUsers}
                </h3>
                <p className={`text-sm ${darkMode ? 'text-gray-400' : 'text-gray-600'}`}>
                  {txt.viewUsersDesc}
                </p>
              </div>

              <div className="space-y-3 mb-6">
                <div className="flex items-center gap-2">
                  <CheckCircle className="w-4 h-4 text-green-500" />
                  <span className={`text-sm ${darkMode ? 'text-gray-300' : 'text-gray-700'}`}>
                    {language === 'ps' ? 'د Firestore Integration' : language === 'fa' ? 'یکپارچه‌سازی Firestore' : 'Firestore Integration'}
                  </span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle className="w-4 h-4 text-green-500" />
                  <span className={`text-sm ${darkMode ? 'text-gray-300' : 'text-gray-700'}`}>
                    {language === 'ps' ? 'Live Search او Filter' : language === 'fa' ? 'جستجو و فیلتر زنده' : 'Live Search & Filter'}
                  </span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle className="w-4 h-4 text-green-500" />
                  <span className={`text-sm ${darkMode ? 'text-gray-300' : 'text-gray-700'}`}>
                    {language === 'ps' ? 'د کاروونکو تفصیلات' : language === 'fa' ? 'جزئیات کاربران' : 'User Details'}
                  </span>
                </div>
              </div>

              <Button
                onClick={() => setActiveView('users')}
                className="w-full bg-gradient-to-r from-blue-600 to-cyan-600 hover:from-blue-700 hover:to-cyan-700 text-white font-bold py-3 rounded-xl"
              >
                <Users className="w-5 h-5 mr-2" />
                {language === 'ps' ? 'لیست خلاصول' : language === 'fa' ? 'باز کردن لیست' : 'Open List'}
              </Button>
            </div>
          </motion.div>

          {/* Firebase Settings Card */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="relative group"
          >
            <div className="absolute inset-0 bg-gradient-to-br from-purple-500 to-indigo-600 opacity-0 group-hover:opacity-10 rounded-3xl blur-xl transition-all duration-500" />
            <div className={`relative backdrop-blur-xl rounded-3xl p-8 border shadow-xl hover:shadow-2xl transition-all duration-300 hover:scale-[1.02] ${
              darkMode
                ? 'bg-gray-800/70 border-gray-700/50'
                : 'bg-white/70 border-white/50'
            }`}>
              <div className="mb-6">
                <div className="w-16 h-16 bg-gradient-to-br from-purple-500 to-indigo-600 rounded-2xl flex items-center justify-center mb-4 shadow-lg">
                  <Cloud className="w-8 h-8 text-white" />
                </div>
                <h3 className={`text-2xl font-bold mb-2 ${darkMode ? 'text-white' : 'text-gray-900'}`}>
                  {txt.firebaseSettings}
                </h3>
                <p className={`text-sm ${darkMode ? 'text-gray-400' : 'text-gray-600'}`}>
                  {txt.firebaseSettingsDesc}
                </p>
              </div>

              <div className="space-y-3 mb-6">
                <div className="flex items-center gap-2">
                  <CheckCircle className="w-4 h-4 text-green-500" />
                  <span className={`text-sm ${darkMode ? 'text-gray-300' : 'text-gray-700'}`}>
                    {language === 'ps' ? 'Connection Status' : language === 'fa' ? 'وضعیت اتصال' : 'Connection Status'}
                  </span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle className="w-4 h-4 text-green-500" />
                  <span className={`text-sm ${darkMode ? 'text-gray-300' : 'text-gray-700'}`}>
                    {language === 'ps' ? 'Cloud Sync کنټرول' : language === 'fa' ? 'کنترل همگام‌سازی' : 'Cloud Sync Controls'}
                  </span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle className="w-4 h-4 text-green-500" />
                  <span className={`text-sm ${darkMode ? 'text-gray-300' : 'text-gray-700'}`}>
                    {language === 'ps' ? 'Dual Mode Support' : language === 'fa' ? 'پشتیبانی دو حالته' : 'Dual Mode Support'}
                  </span>
                </div>
              </div>

              <Button
                onClick={() => setActiveView('firebase')}
                className="w-full bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700 text-white font-bold py-3 rounded-xl"
              >
                <Cloud className="w-5 h-5 mr-2" />
                {language === 'ps' ? 'ترتیبات خلاصول' : language === 'fa' ? 'باز کردن تنظیمات' : 'Open Settings'}
              </Button>
            </div>
          </motion.div>
        </div>

        {/* Info Section */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="max-w-4xl mx-auto mt-8"
        >
          <div className={`backdrop-blur-xl rounded-3xl p-6 border shadow-xl ${
            darkMode
              ? 'bg-gray-800/70 border-gray-700/50'
              : 'bg-white/70 border-white/50'
          }`}>
            <div className="flex items-start gap-4">
              <div className="w-12 h-12 bg-gradient-to-br from-green-500 to-emerald-600 rounded-xl flex items-center justify-center flex-shrink-0">
                <Database className="w-6 h-6 text-white" />
              </div>
              <div>
                <h4 className={`font-bold mb-2 ${darkMode ? 'text-white' : 'text-gray-900'}`}>
                  {language === 'ps' ? 'د Firebase Integration معلومات' : 
                   language === 'fa' ? 'اطلاعات یکپارچه‌سازی Firebase' : 
                   'Firebase Integration Info'}
                </h4>
                <p className={`text-sm ${darkMode ? 'text-gray-300' : 'text-gray-700'}`}>
                  {language === 'ps' 
                    ? 'دا ټیسټ پاڼه ستاسو د Firebase Firestore integration ټیسټوي. تاسو کولی شئ د کاروونکو لیست وګورئ، د Firebase سره sync وکړئ، او د cloud storage حالت معلوم کړئ.'
                    : language === 'fa' 
                    ? 'این صفحه تست، یکپارچه‌سازی Firebase Firestore شما را آزمایش می‌کند. می‌توانید لیست کاربران را مشاهده کنید، با Firebase همگام‌سازی کنید و وضعیت ذخیره‌سازی ابری را بررسی کنید.'
                    : 'This test page tests your Firebase Firestore integration. You can view users list, sync with Firebase, and check cloud storage status.'
                  }
                </p>
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </div>
  );
}
