import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { AlertCircle, Phone, Ambulance, Hospital, MapPin } from "lucide-react";
import { ImageWithFallback } from "./figma/ImageWithFallback";
import { useLanguage } from "../contexts/LanguageContext";

export function EmergencySection() {
  const { language } = useLanguage();

  const translations = {
    en: {
      badge: "Emergency",
      title: "Emergency Services",
      subtitle: "Quick access to emergency services and contacts. In case of medical emergency, contact these numbers immediately.",
      contacts: [
        {
          name: "Emergency Ambulance",
          description: "24/7 Emergency ambulance services"
        },
        {
          name: "Red Crescent",
          description: "Afghan Red Crescent Society"
        },
        {
          name: "Nearest Hospital",
          description: "Locate nearest emergency hospital"
        }
      ],
      callButton: "Call",
      findButton: "Find Location",
      firstAidTitle: "First Aid Tips",
      firstAidTips: [
        "Stay calm and assess the situation",
        "Call emergency services immediately",
        "Provide clear location information",
        "Do not move seriously injured persons"
      ]
    },
    dari: {
      badge: "اورژانس",
      title: "خدمات اورژانسی",
      subtitle: "دسترسی سریع به خدمات و تماس های اورژانسی. در صورت اورژانس طبی، فوراً با این شماره ها تماس بگیرید.",
      contacts: [
        {
          name: "آمبولانس اورژانسی",
          description: "خدمات آمبولانس اورژانسی ۲۴/۷"
        },
        {
          name: "هلال احمر",
          description: "جمعیت هلال احمر افغانی"
        },
        {
          name: "نزدیکترین شفاخانه",
          description: "یافتن نزدیکترین شفاخانه اورژانسی"
        }
      ],
      callButton: "تماس",
      findButton: "یافتن موقعیت",
      firstAidTitle: "نکات کمک های اولیه",
      firstAidTips: [
        "آرام باشید و وضعیت را ارزیابی کنید",
        "فوراً با خدمات اورژانسی تماس بگیرید",
        "معلومات واضح موقعیت را ارائه دهید",
        "افراد به شدت مجروح را جابجا نکنید"
      ]
    },
    pashto: {
      badge: "بیړنی",
      title: "بیړني خدمتونه",
      subtitle: "د بیړني خدماتو او اړیکو ته ګړندی لاسرسی. د طبي بیړني حالت په صورت کې، سمدستي د دې شمیرو سره اړیکه ونیسئ.",
      contacts: [
        {
          name: "بیړنۍ امبولانس",
          description: "۲۴/۷ د بیړنۍ امبولانس خدمتونه"
        },
        {
          name: "سره میاشت",
          description: "د افغان سرې میاشتې ټولنه"
        },
        {
          name: "نږدې روغتون",
          description: "د بیړني روغتون موندل"
        }
      ],
      callButton: "زنګ ووهئ",
      findButton: "موقعیت ومومئ",
      firstAidTitle: "د لومړنیو مرستو لارښوونې",
      firstAidTips: [
        "آرام اوسئ او وضعیت وارزوئ",
        "سمدستي د بیړني خدماتو سره اړیکه ونیسئ",
        "د موقعیت روښانه معلومات ورکړئ",
        "په جدي ډول ټپیان کسان مه حرکت ورکوئ"
      ]
    }
  };

  const t = translations[language as keyof typeof translations] || translations.en;

  const emergencyNumbers = [
    { number: "102", icon: Ambulance },
    { number: "+93 (0) 799 333 888", icon: AlertCircle },
    { number: "Find Location", icon: Hospital }
  ];

  return (
    <section id="emergency" className="py-16 md:py-24 bg-gradient-to-b from-red-50 via-rose-50 to-white relative overflow-hidden">
      {/* Background decoration */}
      <div className="absolute top-0 right-0 w-[400px] h-[400px] bg-gradient-to-bl from-red-100/50 to-pink-100/50 rounded-full blur-3xl animate-pulse-glow"></div>
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid md:grid-cols-2 gap-8 md:gap-12 items-center">
          <div>
            <div className="inline-flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-red-100 to-pink-100 rounded-full mb-6">
              <AlertCircle className="w-4 h-4 text-red-600 animate-pulse-glow" />
              <span className="text-red-700 text-sm uppercase tracking-wider">{t.badge}</span>
            </div>
            <h2 className="text-4xl md:text-6xl mb-4">
              <span className="bg-gradient-to-r from-red-600 via-rose-600 to-pink-600 bg-clip-text text-transparent">
                {t.title}
              </span>
            </h2>
            <p className="text-gray-600 mb-8 text-lg leading-relaxed">
              {t.subtitle}
            </p>

            <div className="space-y-4">
              {t.contacts.map((contact, index) => {
                const ContactIcon = emergencyNumbers[index].icon;
                const contactNumber = emergencyNumbers[index].number;
                const isLocationButton = contactNumber === "Find Location";

                return (
                  <Card key={index} className="border-0 shadow-lg hover-lift bg-white" style={{ animationDelay: `${index * 100}ms` }}>
                    <CardHeader className="pb-3 p-5">
                      <div className="flex items-center gap-4">
                        <div className="bg-gradient-to-br from-red-100 to-pink-100 p-3 rounded-xl shadow-md">
                          <ContactIcon className="w-6 h-6 text-red-600" />
                        </div>
                        <div className="flex-1">
                          <CardTitle className="text-base md:text-lg">{contact.name}</CardTitle>
                          <CardDescription className="text-xs md:text-sm">{contact.description}</CardDescription>
                        </div>
                      </div>
                    </CardHeader>
                    <CardContent className="pt-0 p-4">
                      <Button 
                        className="w-full bg-red-600 hover:bg-red-700 active:bg-red-800 text-sm md:text-base"
                        size="lg"
                      >
                        {isLocationButton ? (
                          <>
                            <MapPin className="w-4 h-4 mr-2" />
                            {t.findButton}
                          </>
                        ) : (
                          <>
                            <Phone className="w-4 h-4 mr-2" />
                            {contactNumber}
                          </>
                        )}
                      </Button>
                    </CardContent>
                  </Card>
                );
              })}
            </div>

            <div className="mt-4 md:mt-6 p-4 bg-white rounded-lg border border-red-200">
              <h3 className="text-red-600 mb-2 text-base md:text-lg">{t.firstAidTitle}</h3>
              <ul className="text-xs md:text-sm text-gray-600 space-y-1">
                {t.firstAidTips.map((tip, index) => (
                  <li key={index}>• {tip}</li>
                ))}
              </ul>
            </div>
          </div>

          <div className="relative hidden md:block">
            <div className="rounded-2xl overflow-hidden shadow-xl">
              <ImageWithFallback
                src="https://images.unsplash.com/photo-1697952431905-9c8d169d9d2b?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtZWRpY2FsJTIwZW1lcmdlbmN5JTIwYW1idWxhbmNlfGVufDF8fHx8MTc2MzE1NzEwNXww&ixlib=rb-4.1.0&q=80&w=1080"
                alt="Emergency medical services"
                className="w-full h-[500px] object-cover"
              />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

export default EmergencySection;
