import { useState, useEffect } from "react";
import { 
  Search, Calendar, FileText, Building2, Phone, Clock, MapPin, Star, 
  ChevronRight, Heart, Activity, Brain, Stethoscope, Pill, Users, 
  Bell, TrendingUp, AlertCircle, CheckCircle, ArrowRight, Zap,
  Video, MessageSquare, Shield, Award, Sparkles, Target, Plus,
  Microscope, Syringe, Thermometer, HeartPulse, UserCheck, Timer,
  BookOpen, Download, Eye
} from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "./ui/card";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Badge } from "./ui/badge";
import { ImageWithFallback } from "./figma/ImageWithFallback";
import { AdBanner } from "./AdBanner";
import { CategoryDetailModal } from "./CategoryDetailModal";
import { useLanguage } from "../contexts/LanguageContext";
import { useAuth } from "../contexts/AuthContext";

interface HomeScreenProps {
  setActivePage?: (page: string) => void;
}

export function HomeScreen({ setActivePage }: HomeScreenProps) {
  const { language, t } = useLanguage();
  const { user } = useAuth();
  const [currentTime, setCurrentTime] = useState(new Date().getHours());
  const [selectedCategory, setSelectedCategory] = useState<any>(null);
  const [isCategoryModalOpen, setIsCategoryModalOpen] = useState(false);
  const [scrollY, setScrollY] = useState(0);
  const [currentImageIndex, setCurrentImageIndex] = useState(0);
  const [activeTabsByCategory, setActiveTabsByCategory] = useState<{[key: number]: 'doctors' | 'books'}>({});

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date().getHours());
    }, 60000);
    
    const handleScroll = () => {
      setScrollY(window.scrollY);
    };
    
    // د عکسونو اتوماتیک بدلون هره 30 ثانیې
    const imageTimer = setInterval(() => {
      setCurrentImageIndex((prevIndex) => (prevIndex + 1) % 30);
    }, 30000); // 30 ثانیې
    
    window.addEventListener('scroll', handleScroll);
    
    return () => {
      clearInterval(timer);
      clearInterval(imageTimer);
      window.removeEventListener('scroll', handleScroll);
    };
  }, []);

  // د HD Medical Images array
  const medicalImages = [
      "https://images.unsplash.com/photo-1758691463626-0ab959babe00?w=1920&q=80",
      "https://images.unsplash.com/photo-1576669801945-7a346954da5a?w=1920&q=80",
      "https://images.unsplash.com/photo-1587557983735-f05198060b52?w=1920&q=80",
      "https://images.unsplash.com/photo-1758691462126-2ee47c8bf9e7?w=1920&q=80",
      "https://images.unsplash.com/photo-1584982751601-97dcc096659c?w=1920&q=80",
      "https://images.unsplash.com/photo-1738191360020-e03e1c8914fb?w=1920&q=80",
      "https://images.unsplash.com/photo-1633488781325-d36e6818d0c8?w=1920&q=80",
      "https://images.unsplash.com/photo-1755189118414-14c8dacdb082?w=1920&q=80",
      "https://images.unsplash.com/photo-1739285452629-2672b13fa42d?w=1920&q=80",
      "https://images.unsplash.com/photo-1648224394432-8830fec15349?w=1920&q=80",
      "https://images.unsplash.com/photo-1739298061768-41a8a7d8b38f?w=1920&q=80",
      "https://images.unsplash.com/photo-1628348070889-cb656235b4eb?w=1920&q=80",
      "https://images.unsplash.com/photo-1758691463331-2ac00e6f676f?w=1920&q=80",
      "https://images.unsplash.com/photo-1758204055017-1f83b2c256a9?w=1920&q=80",
      "https://images.unsplash.com/photo-1758691463087-43ac1462410f?w=1920&q=80",
      "https://images.unsplash.com/photo-1758691461935-202e2ef6b69f?w=1920&q=80",
      "https://images.unsplash.com/photo-1758574437870-f83c160efd82?w=1920&q=80",
      "https://images.unsplash.com/photo-1738191360020-e03e1c8914fb?w=1920&q=80",
      "https://images.unsplash.com/photo-1676285885390-486f6cc426a3?w=1920&q=80",
      "https://images.unsplash.com/photo-1633488781325-d36e6818d0c8?w=1920&q=80",
      "https://images.unsplash.com/photo-1638202993928-7267aad84c31?w=1920&q=80",
      "https://images.unsplash.com/photo-1758691461990-03b49d969495?w=1920&q=80",
      "https://images.unsplash.com/photo-1721114989769-0423619f03d2?w=1920&q=80",
      "https://images.unsplash.com/photo-1761106082516-61d4c6883f59?w=1920&q=80",
      "https://images.unsplash.com/photo-1594567743551-ee026bb6f223?w=1920&q=80",
      "https://images.unsplash.com/photo-1758691461516-7e716e0ca135?w=1920&q=80",
      "https://images.unsplash.com/photo-1758691463610-3c2ecf5fb3fa?w=1920&q=80",
      "https://images.unsplash.com/photo-1587557983735-f05198060b52?w=1920&q=80",
      "https://images.unsplash.com/photo-1643297653753-2d3f459edc6b?w=1920&q=80",
      "https://images.unsplash.com/photo-1758204055017-1f83b2c256a9?w=1920&q=80",
    ];

  // د وخت په اساس greeting او background
  const getTimeBasedGreeting = () => {
    const now = new Date();
    const hour = now.getHours();

    if (hour >= 5 && hour < 12) {
      return {
        greeting: t("good_morning"),
        subtitle: t("start_day_health"),
        icon: "🌅",
        gradient: "from-amber-400 via-orange-500 to-rose-600",
        bgGradient: "from-amber-50 via-orange-50 to-rose-50",
        image: medicalImages[currentImageIndex]
      };
    } else if (hour >= 12 && hour < 17) {
      return {
        greeting: t("good_afternoon"),
        subtitle: t("take_care_health"),
        icon: "☀️",
        gradient: "from-yellow-400 via-amber-500 to-orange-600",
        bgGradient: "from-yellow-50 via-amber-50 to-orange-50",
        image: medicalImages[currentImageIndex]
      };
    } else if (hour >= 17 && hour < 21) {
      return {
        greeting: t("good_evening"),
        subtitle: t("your_health_companion"),
        icon: "🌆",
        gradient: "from-indigo-500 via-purple-600 to-pink-600",
        bgGradient: "from-indigo-50 via-purple-50 to-pink-50",
        image: medicalImages[currentImageIndex]
      };
    } else {
      return {
        greeting: t("good_night"),
        subtitle: t("rest_well_healthy"),
        icon: "🌙",
        gradient: "from-blue-900 via-indigo-900 to-purple-900",
        bgGradient: "from-blue-50 via-indigo-50 to-purple-50",
        image: medicalImages[currentImageIndex]
      };
    }
  };

  const greeting = getTimeBasedGreeting();

  const quickActions = [
    { 
      icon: Video, 
      label: t("video_call"),
      gradient: "from-purple-500 to-pink-600", 
      bgColor: "bg-purple-50",
      page: "video",
      description: t("online_consultation"),
      iconBg: "bg-gradient-to-br from-purple-400 to-pink-500"
    },
    { 
      icon: Stethoscope, 
      label: t("find_doctors"),
      gradient: "from-blue-500 to-cyan-600", 
      bgColor: "bg-blue-50",
      page: "doctors",
      description: t("find_doctor_desc"),
      iconBg: "bg-gradient-to-br from-blue-400 to-cyan-500"
    },
    { 
      icon: Pill, 
      label: t("medicines"),
      gradient: "from-emerald-500 to-teal-600", 
      bgColor: "bg-emerald-50",
      page: "medicines",
      description: t("browse_pharmacy"),
      iconBg: "bg-gradient-to-br from-emerald-400 to-teal-500"
    },
    { 
      icon: Calendar, 
      label: t("book_appointment"),
      gradient: "from-orange-500 to-red-600", 
      bgColor: "bg-orange-50",
      page: "appointments",
      description: t("schedule_visits"),
      iconBg: "bg-gradient-to-br from-orange-400 to-red-500"
    },
  ];

  const healthMetrics = [
    {
      icon: HeartPulse,
      label: t("appointments_stat"),
      value: "12",
      change: "+2",
      changeText: t("this_week_change"),
      gradient: "from-rose-500 to-pink-600",
      bgGradient: "from-rose-50 to-pink-50",
      progress: 75
    },
    {
      icon: FileText,
      label: t("prescriptions_stat"),
      value: "8",
      change: "3",
      changeText: t("active_status"),
      gradient: "from-emerald-500 to-teal-600",
      bgGradient: "from-emerald-50 to-teal-50",
      progress: 60
    },
    {
      icon: Activity,
      label: t("health_score"),
      value: "85%",
      change: t("excellent_status"),
      changeText: "",
      gradient: "from-purple-500 to-indigo-600",
      bgGradient: "from-purple-50 to-indigo-50",
      progress: 85
    },
  ];

  const featuredDoctors = [
    {
      name: "Dr. Sarah Ahmad",
      specialty: t("cardiologist"),
      rating: 4.9,
      reviews: 324,
      patients: "500+",
      image: "https://images.unsplash.com/photo-1638202993928-7267aad84c31?w=400&h=400&fit=crop",
      online: true,
      experience: `15 ${t("years_exp")}`,
      nextAvailable: "Today, 2:00 PM",
      verified: true
    },
    {
      name: "Dr. Hassan Karimi",
      specialty: t("pediatrician"),
      rating: 4.8,
      reviews: 289,
      patients: "400+",
      image: "https://images.unsplash.com/photo-1755189118414-14c8dacdb082?w=400&h=400&fit=crop",
      online: true,
      experience: `12 ${t("years_exp")}`,
      nextAvailable: "Today, 3:30 PM",
      verified: true
    },
    {
      name: "Dr. Fatima Noori",
      specialty: t("dermatologist"),
      rating: 4.9,
      reviews: 412,
      patients: "600+",
      image: "https://images.unsplash.com/photo-1576669801945-7a346954da5a?w=400&h=400&fit=crop",
      online: true,
      experience: `10 ${t("years_exp")}`,
      nextAvailable: "Tomorrow, 10:00 AM",
      verified: true
    },
  ];

  const healthTips = [
    {
      title: t("stay_hydrated"),
      description: t("drink_water_daily"),
      icon: "💧",
      gradient: "from-blue-400 via-cyan-500 to-teal-600",
      image: "https://images.unsplash.com/photo-1559827260-dc66d52bef19?w=600&h=400&fit=crop"
    },
    {
      title: t("regular_exercise"),
      description: t("minutes_daily"),
      icon: "🏃",
      gradient: "from-emerald-400 via-green-500 to-lime-600",
      image: "https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?w=600&h=400&fit=crop"
    },
    {
      title: t("healthy_diet"),
      description: t("eat_fruits_vegetables"),
      icon: "🥗",
      gradient: "from-orange-400 via-amber-500 to-yellow-600",
      image: "https://images.unsplash.com/photo-1512621776951-a57141f2eefd?w=600&h=400&fit=crop"
    },
  ];

  const healthCategories = [
    {
      id: "cardiology",
      icon: Heart,
      label: t("cardiology"),
      labelPashto: "زړه",
      labelDari: "قلب",
      gradient: "from-red-500 to-rose-600",
      bgColor: "from-red-50 to-rose-50",
      doctors: [
        { name: "Dr. احمد کریمي", specialty: "Heart Surgeon", experience: "18 years", rating: 4.9, patients: "800+" },
        { name: "Dr. Sara Ahmadi", specialty: "Cardiologist", experience: "15 years", rating: 4.8, patients: "650+" },
        { name: "Dr. محمد نوري", specialty: "Heart Specialist", experience: "20 years", rating: 4.9, patients: "900+" },
      ],
      books: [
        { 
          title: "Heart Health Guide", 
          titlePs: "د زړه روغتیا لارښود", 
          titleFa: "راهنمای سلامت قلب", 
          author: "Dr. Michael Davis", 
          pages: 320, 
          language: "Multi", 
          rating: 4.8,
          downloads: 15420,
          views: 45320,
          summary: "Complete guide to maintaining a healthy heart through diet, exercise, and lifestyle changes. Learn about common heart conditions and prevention strategies.",
          summaryPs: "د روغ زړه د ساتلو بشپړ لارښود د خوړو، ورزش، او ژوند طرز له لارې. د زړه د عامو ناروغیو او د مخنیوي ستراتیژیو په اړه زده کړئ.",
          summaryFa: "راهنمای کامل برای حفظ قلب سالم از طریق رژیم غذایی، ورزش و تغییرات سبک زندگی. در مورد بیماری‌های رایج قلبی و استراتژی‌های پیشگیری بیاموزید."
        },
        { 
          title: "Cardiac Care Manual", 
          titlePs: "د زړه پاملرنې لارښود", 
          titleFa: "کتابچه مراقبت قلبی", 
          author: "Dr. Sarah Johnson", 
          pages: 285, 
          language: "Multi", 
          rating: 4.7,
          downloads: 12850,
          views: 38920,
          summary: "Comprehensive manual for cardiac care including emergency response, medications, and post-surgery recovery guidelines.",
          summaryPs: "د زړه د پاملرنې بشپړ لارښود د بیړني ځواب، درملو، او د جراحۍ وروسته روغیدو لارښودونو په شمول.",
          summaryFa: "کتابچه جامع مراقبت قلبی شامل پاسخ اضطراری، داروها و دستورالعمل‌های بهبودی پس از جراحی."
        },
        { 
          title: "Prevent Heart Disease", 
          titlePs: "د زړه ناروغۍ مخنیوی", 
          titleFa: "پیشگیری از بیماری قلبی", 
          author: "Dr. احمد رحیمي", 
          pages: 240, 
          language: "Multi", 
          rating: 4.9,
          downloads: 18920,
          views: 52100,
          summary: "Evidence-based strategies to prevent heart disease through nutrition, stress management, and regular check-ups.",
          summaryPs: "د زړه د ناروغۍ د مخنیوي لپاره د ثبوت پر بنسټ ستراتیژۍ د تغذیې، فشار اداره کولو، او منظمو معاینو له لارې.",
          summaryFa: "استراتژی‌های مبتنی بر شواهد برای پیشگیری از بیماری قلبی از طریق تغذیه، مدیریت استرس و معاینات منظم."
        },
        { 
          title: "Cardiology Essentials", 
          titlePs: "د زړه اړین معلومات", 
          titleFa: "اصول قلب و عروق", 
          author: "Dr. Emily Chen", 
          pages: 395, 
          language: "Multi", 
          rating: 4.6,
          downloads: 10250,
          views: 31400,
          summary: "Essential cardiology concepts for medical students and healthcare professionals. Covers anatomy, physiology, and common cardiovascular conditions.",
          summaryPs: "د طبي زده کوونکو او روغتیا پاملرنې مسلکیانو لپاره د زړه اړین مفکورې. اناتومي، فزیولوژي، او عام زړه ناروغۍ په پام کې نیسي.",
          summaryFa: "مفاهیم اساسی قلب و عروق برای دانشجویان پزشکی و متخصصان بهداشت. شامل آناتومی، فیزیولوژی و شرایط رایج قلبی عروقی."
        },
        { 
          title: "Heart Attack Prevention", 
          titlePs: "د زړه حملې مخنیوی", 
          titleFa: "پیشگیری از سکته قلبی", 
          author: "Dr. فریده نوري", 
          pages: 210, 
          language: "Multi", 
          rating: 4.8,
          downloads: 16780,
          views: 48650,
          summary: "Learn to recognize early warning signs of heart attack and implement preventive measures to protect your heart health.",
          summaryPs: "د زړه حملې لومړني خبرداری نښې وپیژنئ او د خپل زړه روغتیا ساتلو لپاره مخنیوي اقدامات پلي کړئ.",
          summaryFa: "نشانه‌های هشدار اولیه سکته قلبی را بشناسید و اقدامات پیشگیرانه برای محافظت از سلامت قلب خود اجرا کنید."
        },
      ]
    },
    {
      id: "neurology",
      icon: Brain,
      label: t("neurology"),
      labelPashto: "اعصاب",
      labelDari: "اعصاب",
      gradient: "from-purple-500 to-indigo-600",
      bgColor: "from-purple-50 to-indigo-50",
      doctors: [
        { name: "Dr. فاطمه رحیمي", specialty: "Neurologist", experience: "16 years", rating: 4.8, patients: "700+" },
        { name: "Dr. Hassan Khan", specialty: "Brain Surgeon", experience: "22 years", rating: 4.9, patients: "850+" },
        { name: "Dr. زینب احمدي", specialty: "Neuro Specialist", experience: "14 years", rating: 4.7, patients: "600+" },
      ],
      books: [
        { 
          title: "Brain Health Guide", 
          titlePs: "د دماغ روغتیا لارښود", 
          titleFa: "راهنمای سلامت مغز", 
          author: "Dr. James Wilson", 
          pages: 350, 
          language: "Multi", 
          rating: 4.9,
          downloads: 14200,
          views: 42800,
          summary: "Comprehensive guide to brain health covering cognitive function, memory improvement, and neurological disease prevention.",
          summaryPs: "د دماغ روغتیا بشپړ لارښود چې د ادراکي فعالیت، حافظې ښه والي، او د اعصابي ناروغیو مخنیوی په پام کې نیسي.",
          summaryFa: "راهنمای جامع سلامت مغز شامل عملکرد شناختی، بهبود حافظه و پیشگیری از بیماری‌های عصبی."
        },
        { 
          title: "Neurology Basics", 
          titlePs: "د اعصابو بنیادی معلومات", 
          titleFa: "مبانی عصب‌شناسی", 
          author: "Dr. رحمان احمدي", 
          pages: 290, 
          language: "Multi", 
          rating: 4.7,
          downloads: 11850,
          views: 36200,
          summary: "Foundational neurology concepts for understanding brain structure, nervous system function, and common neurological disorders.",
          summaryPs: "د دماغ جوړښت، عصبي سیسټم فعالیت، او عام اعصابي اختلالاتو پوهیدو لپاره د اعصابو بنیادي مفکورې.",
          summaryFa: "مفاهیم پایه عصب‌شناسی برای درک ساختار مغز، عملکرد سیستم عصبی و اختلالات عصبی رایج."
        },
        { 
          title: "Memory & Brain", 
          titlePs: "حافظه او دماغ", 
          titleFa: "حافظه و مغز", 
          author: "Dr. Lisa Anderson", 
          pages: 265, 
          language: "Multi", 
          rating: 4.8,
          downloads: 13420,
          views: 39800,
          summary: "Explore how memory works, techniques to improve recall, and methods to protect cognitive function as you age.",
          summaryPs: "معلومه کړئ چې حافظه څنګه کار کوي، د یادولو ښه والي تخنیکونه، او د عمر سره د ادراکي فعالیت ساتلو میتودونه.",
          summaryFa: "کشف کنید که حافظه چگونه کار می‌کند، تکنیک‌های بهبود یادآوری و روش‌های محافظت از عملکرد شناختی با افزایش سن."
        },
        { 
          title: "Stroke Prevention", 
          titlePs: "د فالج مخنیوی", 
          titleFa: "پیشگیری از سکته مغزی", 
          author: "Dr. محمد کریمي", 
          pages: 310, 
          language: "Multi", 
          rating: 4.6,
          downloads: 10980,
          views: 33500,
          summary: "Learn risk factors, warning signs, and evidence-based strategies to prevent stroke and protect brain health.",
          summaryPs: "د خطر فکتورونه، خبرداری نښې، او د فالج د مخنیوي او د دماغ روغتیا ساتلو لپاره د ثبوت پر بنسټ ستراتیژۍ زده کړئ.",
          summaryFa: "عوامل خطر، علائم هشدار دهنده و استراتژی‌های مبتنی بر شواهد برای پیشگیری از سکته مغزی و محافظت از سلامت مغز را بیاموزید."
        },
        { 
          title: "Headache Solutions", 
          titlePs: "د سر درد حلونه", 
          titleFa: "راه‌حل‌های سردرد", 
          author: "Dr. زهره نوري", 
          pages: 195, 
          language: "Multi", 
          rating: 4.7,
          downloads: 15600,
          views: 46200,
          summary: "Identify headache types, triggers, and effective treatment options including natural remedies and medical interventions.",
          summaryPs: "د سر درد ډولونه، تحریکونه، او مؤثره درملنې انتخابونه پیژنئ د طبیعي درملو او طبي مداخلو په شمول.",
          summaryFa: "انواع سردرد، محرک‌ها و گزینه‌های درمانی مؤثر شامل درمان‌های طبیعی و مداخلات پزشکی را شناسایی کنید."
        },
      ]
    },
    {
      id: "orthopedics",
      icon: Activity,
      label: t("orthopedics"),
      labelPashto: "هډوکي",
      labelDari: "استخوان",
      gradient: "from-blue-500 to-cyan-600",
      bgColor: "from-blue-50 to-cyan-50",
      doctors: [
        { name: "Dr. علي رحماني", specialty: "Orthopedic Surgeon", experience: "19 years", rating: 4.9, patients: "950+" },
        { name: "Dr. Nadia Karimi", specialty: "Bone Specialist", experience: "13 years", rating: 4.7, patients: "550+" },
        { name: "Dr. عمر خان", specialty: "Joint Surgeon", experience: "17 years", rating: 4.8, patients: "720+" },
      ],
      books: [
        { title: "Bone Health Manual", titlePs: "د هډوکو روغتیا لارښود", titleFa: "کتابچه سلامت استخوان", author: "Dr. Robert Miller", pages: 340, language: "Multi", rating: 4.8 },
        { title: "Joint Care Guide", titlePs: "د مفصلونو پاملرنې لارښود", titleFa: "راهنمای مراقبت از مفاصل", author: "Dr. سمیرا احمدي", pages: 275, language: "Multi", rating: 4.7 },
        { title: "Sports Injuries", titlePs: "د سپورت ټپونه", titleFa: "آسیب‌های ورزشی", author: "Dr. Thomas Brown", pages: 295, language: "Multi", rating: 4.9 },
        { title: "Back Pain Solutions", titlePs: "د ملا درد حلونه", titleFa: "راه‌حل‌های کمردرد", author: "Dr. احسان کریمي", pages: 250, language: "Multi", rating: 4.6 },
        { title: "Osteoporosis Guide", titlePs: "د هډوکو نری لارښود", titleFa: "راهنمای پوکی استخوان", author: "Dr. فاطمه رحیمي", pages: 280, language: "Multi", rating: 4.8 },
      ]
    },
    {
      id: "dermatology",
      icon: Sparkles,
      label: t("dermatologist"),
      labelPashto: "پوستکي",
      labelDari: "پوست",
      gradient: "from-pink-500 to-rose-600",
      bgColor: "from-pink-50 to-rose-50",
      doctors: [
        { name: "Dr. مریم نوري", specialty: "Skin Specialist", experience: "12 years", rating: 4.8, patients: "680+" },
        { name: "Dr. Reza Ahmadi", specialty: "Dermatologist", experience: "15 years", rating: 4.9, patients: "750+" },
        { name: "Dr. لیلا کریمي", specialty: "Cosmetic Dermatology", experience: "10 years", rating: 4.7, patients: "520+" },
      ],
      books: [
        { title: "Skin Care Essentials", titlePs: "د پوست پاملرنې اړینې معلومات", titleFa: "اصول مراقبت از پوست", author: "Dr. Jennifer Lee", pages: 310, language: "Multi", rating: 4.9 },
        { title: "Dermatology Guide", titlePs: "د پوستکي لارښود", titleFa: "راهنمای پوست‌شناسی", author: "Dr. یاسر احمدي", pages: 285, language: "Multi", rating: 4.7 },
        { title: "Acne Treatment", titlePs: "د مخ دانو درملنه", titleFa: "درمان جوش صورت", author: "Dr. Maria Garcia", pages: 240, language: "Multi", rating: 4.8 },
        { title: "Eczema Solutions", titlePs: "د اکزیما حلونه", titleFa: "راه‌حل‌های اگزما", author: "Dr. حامد نوري", pages: 220, language: "Multi", rating: 4.6 },
        { title: "Beauty & Skin Health", titlePs: "ښکلا او د پوست روغتیا", titleFa: "زیبایی و سلامت پوست", author: "Dr. شکریه کریمي", pages: 295, language: "Multi", rating: 4.8 },
      ]
    },
    {
      id: "pediatrics",
      icon: Users,
      label: t("pediatrician"),
      labelPashto: "ماشومان",
      labelDari: "اطفال",
      gradient: "from-emerald-500 to-teal-600",
      bgColor: "from-emerald-50 to-teal-50",
      doctors: [
        { name: "Dr. سمیرا احمدي", specialty: "Child Specialist", experience: "14 years", rating: 4.9, patients: "1200+" },
        { name: "Dr. Ahmad Rahimi", specialty: "Pediatrician", experience: "16 years", rating: 4.8, patients: "980+" },
        { name: "Dr. زهره نوري", specialty: "Baby Care Expert", experience: "11 years", rating: 4.8, patients: "850+" },
      ],
      books: [
        { 
          title: "Child Health Guide", 
          titlePs: "د ماشوم روغتیا لارښود", 
          titleFa: "راهنمای سلامت کودک", 
          author: "Dr. Amanda White", 
          pages: 360, 
          language: "Multi", 
          rating: 4.9,
          downloads: 18500,
          views: 52000,
          summary: "Complete guide to child health from birth to adolescence, covering growth milestones, common illnesses, and development.",
          summaryPs: "د زیږون څخه تر لویوالي پورې د ماشوم روغتیا بشپړ لارښود، د ودې نښلونه، عامې ناروغۍ، او پراختیا په پام کې نیسي.",
          summaryFa: "راهنمای کامل سلامت کودک از تولد تا نوجوانی، شامل مراحل رشد، بیماری‌های رایج و توسعه."
        },
        { 
          title: "Baby Care Manual", 
          titlePs: "د ماشوم پاملرنې لارښود", 
          titleFa: "کتابچه مراقبت از نوزاد", 
          author: "Dr. نرګس احمدي", 
          pages: 325, 
          language: "Multi", 
          rating: 4.8,
          downloads: 16800,
          views: 48300,
          summary: "Essential baby care guide for new parents covering feeding, sleep, hygiene, and early development stages.",
          summaryPs: "د نویو مور او پلرونو لپاره د ماشوم د پاملرنې اړین لارښود چې خواړه، خوب، صفايي، او لومړني پراختیا مراحل په پام کې نیسي.",
          summaryFa: "راهنمای ضروری مراقبت از نوزاد برای والدین جدید شامل تغذیه، خواب، بهداشت و مراحل اولیه رشد."
        },
        { 
          title: "Vaccination Guide", 
          titlePs: "د واکسین لارښود", 
          titleFa: "راهنمای واکسیناسیون", 
          author: "Dr. Benjamin Clark", 
          pages: 260, 
          language: "Multi", 
          rating: 4.7,
          downloads: 14200,
          views: 41500,
          summary: "Comprehensive vaccination schedule and information about immunizations to protect children from preventable diseases.",
          summaryPs: "د واکسین بشپړ مهال ویش او د مصونیت په اړه معلومات چې ماشومان د مخنیوي وړ ناروغیو څخه خوندي کړي.",
          summaryFa: "برنامه جامع واکسیناسیون و اطلاعات در مورد ایمن‌سازی برای محافظت از کودکان در برابر بیماری‌های قابل پیشگیری."
        },
        { 
          title: "Child Nutrition", 
          titlePs: "د ماشوم تغذیه", 
          titleFa: "تغذیه کودک", 
          author: "Dr. لیلا رحیمي", 
          pages: 290, 
          language: "Multi", 
          rating: 4.8,
          downloads: 15900,
          views: 44700,
          summary: "Essential nutrition guide for children including healthy meal plans, dietary requirements, and feeding strategies.",
          summaryPs: "د ماشومانو لپاره د تغذیې اړین لارښود چې روغ خواړه پلانونه، غذایي اړتیاوې، او د خواړه کولو ستراتیژۍ په پام کې نیسي.",
          summaryFa: "راهنمای تغذیه ضروری برای کودکان شامل برنامه‌های غذایی سالم، نیازهای رژیمی و استراتژی‌های تغذیه."
        },
        { 
          title: "Common Child Diseases", 
          titlePs: "د ماشومانو عامې ناروغۍ", 
          titleFa: "بیماری‌های شایع کودکان", 
          author: "Dr. عارف نوري", 
          pages: 310, 
          language: "Multi", 
          rating: 4.6,
          downloads: 13600,
          views: 39800,
          summary: "Guide to recognizing, treating, and preventing common childhood illnesses and when to seek medical care.",
          summaryPs: "د ماشومانو عامو ناروغیو پیژندلو، درملنې، او مخنیوي لارښود او دا چې کله طبي پاملرنې ته اړتیا ده.",
          summaryFa: "راهنمای شناخت، درمان و پیشگیری از بیماری‌های رایج کودکان و زمان مراجعه به مراقبت پزشکی."
        },
      ]
    },
    {
      id: "gynecology",
      icon: Heart,
      label: t("gynecologist"),
      labelPashto: "ښځینه",
      labelDari: "زنان",
      gradient: "from-fuchsia-500 to-pink-600",
      bgColor: "from-fuchsia-50 to-pink-50",
      doctors: [
        { name: "Dr. فریده کریمي", specialty: "Gynecologist", experience: "17 years", rating: 4.9, patients: "880+" },
        { name: "Dr. Nargis Ahmadi", specialty: "Pregnancy Specialist", experience: "15 years", rating: 4.8, patients: "750+" },
        { name: "Dr. شکریه نوري", specialty: "Women Health", experience: "13 years", rating: 4.8, patients: "690+" },
      ],
      books: [
        { title: "Women's Health Guide", titlePs: "د ښځو روغتیا لارښود", titleFa: "راهنمای سلامت زنان", author: "Dr. Rachel Martinez", pages: 380, language: "Multi", rating: 4.9 },
        { title: "Pregnancy Manual", titlePs: "د حمل لارښود", titleFa: "کتابچه بارداری", author: "Dr. هدیه احمدي", pages: 340, language: "Multi", rating: 4.8 },
        { title: "Maternal Care", titlePs: "د مور پاملرنه", titleFa: "مراقبت مادری", author: "Dr. Susan Taylor", pages: 295, language: "Multi", rating: 4.7 },
        { title: "PCOS Management", titlePs: "د PCOS اداره", titleFa: "مدیریت PCOS", author: "Dr. زینب کریمي", pages: 270, language: "Multi", rating: 4.8 },
        { title: "Fertility Guide", titlePs: "د زیږون وړتیا لارښود", titleFa: "راهنمای باروری", author: "Dr. مریم نوري", pages: 315, language: "Multi", rating: 4.6 },
      ]
    },
    {
      id: "dentistry",
      icon: Sparkles,
      label: t("dentist"),
      labelPashto: "غاښونه",
      labelDari: "دندان",
      gradient: "from-cyan-500 to-blue-600",
      bgColor: "from-cyan-50 to-blue-50",
      doctors: [
        { name: "Dr. حامد احمدي", specialty: "Dentist", experience: "14 years", rating: 4.8, patients: "920+" },
        { name: "Dr. Laila Karimi", specialty: "Orthodontist", experience: "12 years", rating: 4.7, patients: "650+" },
        { name: "Dr. کریم نوري", specialty: "Dental Surgeon", experience: "16 years", rating: 4.9, patients: "780+" },
      ],
      books: [
        { title: "Dental Care Guide", titlePs: "د غاښونو پاملرنې لارښود", titleFa: "راهنمای مراقبت دندانی", author: "Dr. David Johnson", pages: 300, language: "Multi", rating: 4.8 },
        { title: "Oral Hygiene Manual", titlePs: "د خولې پاکوالی لارښود", titleFa: "کتابچه بهداشت دهان", author: "Dr. ثریا احمدي", pages: 245, language: "Multi", rating: 4.7 },
        { title: "Teeth Whitening", titlePs: "د غاښونو سپین کول", titleFa: "سفید کردن دندان", author: "Dr. Michelle Wong", pages: 220, language: "Multi", rating: 4.9 },
        { title: "Orthodontics Guide", titlePs: "د غاښونو سم کولو لارښود", titleFa: "راهنمای ارتودنسی", author: "Dr. فرید کریمي", pages: 285, language: "Multi", rating: 4.6 },
        { title: "Gum Disease Prevention", titlePs: "د مسوڼو ناروغۍ مخنیوی", titleFa: "پیشگیری از بیماری لثه", author: "Dr. سارا نوري", pages: 265, language: "Multi", rating: 4.8 },
      ]
    },
    {
      id: "ophthalmology",
      icon: Eye,
      label: language === "ps" ? "سترګې" : language === "fa" ? "چشم" : "Ophthalmology",
      labelPashto: "سترګې",
      labelDari: "چشم",
      gradient: "from-amber-500 to-orange-600",
      bgColor: "from-amber-50 to-orange-50",
      doctors: [
        { name: "Dr. احسان کریمي", specialty: "Eye Specialist", experience: "18 years", rating: 4.9, patients: "850+" },
        { name: "Dr. Zainab Rahimi", specialty: "Ophthalmologist", experience: "14 years", rating: 4.8, patients: "720+" },
        { name: "Dr. نبیل احمدي", specialty: "Eye Surgeon", experience: "20 years", rating: 4.9, patients: "960+" },
      ],
      books: [
        { title: "Eye Health Guide", titlePs: "د سترګو روغتیا لارښود", titleFa: "راهنمای سلامت چشم", author: "Dr. William Harris", pages: 320, language: "Multi", rating: 4.9 },
        { title: "Vision Care Manual", titlePs: "د لید پاملرنې لارښود", titleFa: "کتابچه مراقبت از بینایی", author: "Dr. هدیه رحیمي", pages: 280, language: "Multi", rating: 4.7 },
        { title: "Cataract Prevention", titlePs: "د موتیا مخنیوی", titleFa: "پیشگیری از آب مروارید", author: "Dr. Richard Lee", pages: 255, language: "Multi", rating: 4.8 },
        { title: "Laser Eye Surgery", titlePs: "د سترګو لیزر جراحي", titleFa: "جراحی لیزر چشم", author: "Dr. جمیل احمدي", pages: 295, language: "Multi", rating: 4.6 },
        { title: "Eye Diseases Guide", titlePs: "د سترګو ناروغیو لارښود", titleFa: "راهنمای بیماری‌های چشم", author: "Dr. فاطمه کریمي", pages: 310, language: "Multi", rating: 4.8 },
      ]
    },
    {
      id: "ent",
      icon: Bell,
      label: language === "ps" ? "غوږ، پوزه، ستوني" : language === "fa" ? "گوش، حلق، بینی" : "ENT Specialist",
      labelPashto: "غوږ، پوزه",
      labelDari: "گوش، حلق",
      gradient: "from-lime-500 to-green-600",
      bgColor: "from-lime-50 to-green-50",
      doctors: [
        { name: "Dr. یاسر نوري", specialty: "ENT Specialist", experience: "15 years", rating: 4.8, patients: "680+" },
        { name: "Dr. Fatima Khan", specialty: "Throat Specialist", experience: "13 years", rating: 4.7, patients: "590+" },
        { name: "Dr. عارف احمدي", specialty: "Ear Surgeon", experience: "17 years", rating: 4.8, patients: "720+" },
      ],
      books: [
        { title: "ENT Care Guide", titlePs: "د غوږ، پوزه، ستوني پاملرنې لارښود", titleFa: "راهنمای مراقبت گوش، حلق، بینی", author: "Dr. Christopher Adams", pages: 290, language: "Multi", rating: 4.8 },
        { title: "Hearing Health", titlePs: "د اوریدلو روغتیا", titleFa: "سلامت شنوایی", author: "Dr. نادیه احمدي", pages: 260, language: "Multi", rating: 4.7 },
        { title: "Sinus Treatment", titlePs: "د سینوس درملنه", titleFa: "درمان سینوزیت", author: "Dr. Steven Parker", pages: 235, language: "Multi", rating: 4.9 },
        { title: "Tonsil Care", titlePs: "د اللوز پاملرنه", titleFa: "مراقبت از لوزه", author: "Dr. رضا کریمي", pages: 215, language: "Multi", rating: 4.6 },
        { title: "Voice Disorders", titlePs: "د غږ اختلالات", titleFa: "اختلالات صدا", author: "Dr. سمیه نوري", pages: 270, language: "Multi", rating: 4.8 },
      ]
    },
    {
      id: "psychiatry",
      icon: Brain,
      label: language === "ps" ? "رواني روغتیا" : language === "fa" ? "روانپزشکی" : "Psychiatry",
      labelPashto: "رواني",
      labelDari: "روانی",
      gradient: "from-violet-500 to-purple-600",
      bgColor: "from-violet-50 to-purple-50",
      doctors: [
        { name: "Dr. سلمی کریمي", specialty: "Psychiatrist", experience: "16 years", rating: 4.9, patients: "720+" },
        { name: "Dr. Arif Rahimi", specialty: "Mental Health", experience: "14 years", rating: 4.8, patients: "650+" },
        { name: "Dr. هدیه احمدي", specialty: "Psychologist", experience: "12 years", rating: 4.7, patients: "580+" },
      ],
      books: [
        { title: "Mental Health Guide", titlePs: "د رواني روغتیا لارښود", titleFa: "راهنمای سلامت روان", author: "Dr. Patricia Wilson", pages: 350, language: "Multi", rating: 4.9 },
        { title: "Depression Treatment", titlePs: "د خپګان درملنه", titleFa: "درمان افسردگی", author: "Dr. احمد رحیمي", pages: 305, language: "Multi", rating: 4.8 },
        { title: "Anxiety Solutions", titlePs: "د اضطراب حلونه", titleFa: "راه‌حل‌های اضطراب", author: "Dr. Laura Martinez", pages: 280, language: "Multi", rating: 4.7 },
        { title: "Stress Management", titlePs: "د فشار اداره", titleFa: "مدیریت استرس", author: "Dr. نبیله کریمي", pages: 265, language: "Multi", rating: 4.8 },
        { title: "Psychology Basics", titlePs: "د ارواپوهنې بنیادونه", titleFa: "مبانی روانشناسی", author: "Dr. یوسف احمدي", pages: 330, language: "Multi", rating: 4.6 },
      ]
    },
    {
      id: "general",
      icon: Stethoscope,
      label: t("general_physician"),
      labelPashto: "عمومي",
      labelDari: "عمومی",
      gradient: "from-emerald-500 to-teal-600",
      bgColor: "from-emerald-50 to-teal-50",
      doctors: [
        { name: "Dr. جمیل نوري", specialty: "General Physician", experience: "20 years", rating: 4.9, patients: "1500+" },
        { name: "Dr. Shabana Karimi", specialty: "Family Doctor", experience: "18 years", rating: 4.8, patients: "1200+" },
        { name: "Dr. رحیم احمدي", specialty: "GP Specialist", experience: "22 years", rating: 4.9, patients: "1600+" },
      ],
      books: [
        { title: "Family Health Guide", titlePs: "د کورنۍ روغتیا لارښود", titleFa: "راهنمای سلامت خانواده", author: "Dr. James Anderson", pages: 420, language: "Multi", rating: 4.9 },
        { title: "Home Remedies", titlePs: "د کور درمل", titleFa: "درمان‌های خانگی", author: "Dr. شبانه احمدي", pages: 340, language: "Multi", rating: 4.8 },
        { title: "Preventive Medicine", titlePs: "د مخنیوي درمل", titleFa: "پزشکی پیشگیرانه", author: "Dr. Robert Brown", pages: 380, language: "Multi", rating: 4.7 },
        { title: "First Aid Manual", titlePs: "د لومړنیو مرستو لارښود", titleFa: "کتابچه کمک‌های اولیه", author: "Dr. زهره کریمي", pages: 295, language: "Multi", rating: 4.8 },
        { title: "Common Diseases", titlePs: "عامې ناروغۍ", titleFa: "بیماری‌های شایع", author: "Dr. عمر نوري", pages: 360, language: "Multi", rating: 4.6 },
      ]
    },
    {
      id: "charity",
      icon: Heart,
      label: language === "ps" ? "مرسته وکړئ" : language === "fa" ? "کمک کنید" : "Help & Support",
      labelPashto: "مرسته وکړئ",
      labelDari: "کمک کنید",
      gradient: "from-pink-500 to-rose-600",
      bgColor: "from-pink-50 to-rose-50",
      doctors: [
        { name: "Dr. ابراهیم خاکسار", specialty: "Charity Director", experience: "Founder", rating: 5.0, patients: "All" },
        { name: "Social Worker Team", specialty: "Case Verification", experience: "24/7", rating: 4.9, patients: "Community" },
        { name: "Volunteer Network", specialty: "Support Services", experience: "Active", rating: 4.8, patients: "Nationwide" },
      ],
      books: [
        { title: "Charity & Giving", titlePs: "خیرات او ورکول", titleFa: "خیریه و بخشش", author: "Dr. Ibrahim Khaksar", pages: 250, language: "Multi", rating: 5.0, downloads: 8500, views: 25000 },
        { title: "Helping Communities", titlePs: "د ټولنې سره مرسته", titleFa: "کمک به جامعه", author: "Social Team", pages: 180, language: "Multi", rating: 4.9, downloads: 6200, views: 18500 },
        { title: "Fundraising Guide", titlePs: "د پیسو راټولولو لارښود", titleFa: "راهنمای جمع‌آوری کمک", author: "NGO Network", pages: 220, language: "Multi", rating: 4.8, downloads: 5400, views: 16800 },
        { title: "Impact Stories", titlePs: "د اغیزې کیسې", titleFa: "داستان‌های تاثیرگذار", author: "Community", pages: 195, language: "Multi", rating: 4.7, downloads: 4800, views: 14200 },
        { title: "Volunteer Handbook", titlePs: "د رضاکارانو لارښود", titleFa: "کتابچه داوطلبان", author: "Volunteer Team", pages: 165, language: "Multi", rating: 4.6, downloads: 3900, views: 11700 },
      ]
    },
    {
      id: "emergency",
      icon: AlertCircle,
      label: language === "ps" ? "بیړني" : language === "fa" ? "اورژانس" : "Emergency",
      labelPashto: "بیړني",
      labelDari: "اورژانس",
      gradient: "from-red-600 to-orange-600",
      bgColor: "from-red-50 to-orange-50",
      doctors: [
        { name: "Dr. فرید کریمي", specialty: "Emergency Medicine", experience: "19 years", rating: 4.9, patients: "24/7" },
        { name: "Dr. Nasir Ahmadi", specialty: "ER Specialist", experience: "17 years", rating: 4.8, patients: "24/7" },
        { name: "Dr. ثریا نوري", specialty: "Trauma Care", experience: "15 years", rating: 4.9, patients: "24/7" },
      ],
      books: [
        { title: "Emergency Care Guide", titlePs: "د بیړني پاملرنې لارښود", titleFa: "راهنمای مراقبت اورژانسی", author: "Dr. Daniel White", pages: 385, language: "Multi", rating: 4.9 },
        { title: "Trauma Management", titlePs: "د ټپونو اداره", titleFa: "مدیریت تروما", author: "Dr. حسین احمدي", pages: 360, language: "Multi", rating: 4.8 },
        { title: "Life Support Manual", titlePs: "د ژوند ملاتړ لارښود", titleFa: "کتابچه حمایت حیاتی", author: "Dr. Karen Smith", pages: 320, language: "Multi", rating: 4.7 },
        { title: "Crisis Response", titlePs: "د بحران ځواب", titleFa: "پاسخ به بحران", author: "Dr. فرزانه کریمي", pages: 295, language: "Multi", rating: 4.8 },
        { title: "Emergency Protocols", titlePs: "د بیړني پروتوکولونه", titleFa: "پروتکل‌های اورژانس", author: "Dr. نصیر نوري", pages: 340, language: "Multi", rating: 4.6 },
      ]
    },
  ];

  return (
    <div className={`min-h-screen bg-gradient-to-br ${greeting.bgGradient} pb-24 transition-all duration-1000`}>
      {/* 🎨 Animated Hero Section */}
      <div className="relative overflow-hidden">
        {/* Background Pattern */}
        <div className="absolute inset-0 opacity-5">
          <div className="absolute inset-0" style={{
            backgroundImage: `radial-gradient(circle at 2px 2px, currentColor 1px, transparent 0)`,
            backgroundSize: '40px 40px'
          }}></div>
        </div>

        {/* Hero Content */}
        <div className={`relative text-white overflow-hidden`}>
          {/* Animated Background Image - اتوماتیک بدلیږي هره 30 ثانیې */}
          <div className="absolute inset-0 transition-opacity duration-1000" style={{ transform: `translateY(${scrollY * 0.5}px)` }}>
            <ImageWithFallback 
              key={currentImageIndex}
              src={greeting.image}
              alt="Medical Background"
              className="w-full h-full object-cover scale-110 animate-fade-in"
            />
            {/* Light dark overlay for text readability */}
            <div className="absolute inset-0 bg-gradient-to-b from-black/40 via-black/30 to-black/50"></div>
          </div>

          {/* Floating Shapes */}
          <div className="absolute inset-0 overflow-hidden pointer-events-none">
            <div className="absolute top-10 left-10 w-64 h-64 bg-white/5 rounded-full blur-3xl animate-pulse"></div>
            <div className="absolute bottom-10 right-10 w-96 h-96 bg-white/5 rounded-full blur-3xl animate-pulse" style={{ animationDelay: '1s' }}></div>
          </div>

          <div className="relative px-4 py-10 md:py-16">
            <div className="max-w-6xl mx-auto">
              {/* Greeting with Animation */}
              <div className="flex items-start gap-4 mb-8 animate-fade-in">
                <div className="text-6xl md:text-7xl animate-bounce-slow">{greeting.icon}</div>
                <div className="flex-1">
                  <h1 className="text-4xl md:text-5xl lg:text-6xl mb-3 animate-slide-up">
                    {greeting.greeting}
                    <span className="block md:inline md:ml-3 mt-2 md:mt-0 text-3xl md:text-5xl lg:text-6xl opacity-90">
                      HealMate!
                    </span>
                  </h1>
                  <p className="text-xl md:text-2xl text-white/90 mb-6 animate-slide-up" style={{ animationDelay: '0.1s' }}>
                    {greeting.subtitle}
                  </p>

                  {/* Search Bar with Glass Effect */}
                  <div className="relative max-w-2xl animate-slide-up" style={{ animationDelay: '0.2s' }}>
                    <div className="absolute inset-0 bg-white/10 backdrop-blur-md rounded-2xl"></div>
                    <div className="relative flex items-center gap-3 p-2 bg-white/20 backdrop-blur-xl rounded-2xl border border-white/30 shadow-2xl hover:bg-white/25 transition-all">
                      <Search className="w-6 h-6 text-white ml-3" />
                      <Input 
                        placeholder={t("search_doctors_medicines")}
                        className="flex-1 border-0 bg-transparent text-white placeholder:text-white/70 text-lg focus:outline-none focus:ring-0"
                      />
                      <Button size="lg" className="bg-white text-gray-900 hover:bg-white/90 rounded-xl px-6 shadow-lg">
                        <Search className="w-5 h-5" />
                      </Button>
                    </div>
                  </div>
                </div>
              </div>

              {/* Quick Stats Pills */}
              <div className="flex flex-wrap gap-3 animate-slide-up" style={{ animationDelay: '0.3s' }}>
                <div className="bg-white/20 backdrop-blur-xl px-5 py-2 rounded-full border border-white/30 flex items-center gap-2">
                  <UserCheck className="w-4 h-4" />
                  <span className="text-sm">500+ {t("top_doctors")}</span>
                </div>
                <div className="bg-white/20 backdrop-blur-xl px-5 py-2 rounded-full border border-white/30 flex items-center gap-2">
                  <Timer className="w-4 h-4" />
                  <span className="text-sm">24/7 Available</span>
                </div>
                <div className="bg-white/20 backdrop-blur-xl px-5 py-2 rounded-full border border-white/30 flex items-center gap-2">
                  <Shield className="w-4 h-4" />
                  <span className="text-sm">Verified Doctors</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-4 -mt-16 relative z-10">
        {/* 📊 Health Metrics - Floating Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          {healthMetrics.map((metric, index) => (
            <div 
              key={index} 
              className="group animate-slide-up"
              style={{ animationDelay: `${index * 0.1}s` }}
            >
              <div className={`relative bg-gradient-to-br ${metric.bgGradient} p-6 rounded-3xl shadow-2xl hover:shadow-3xl transition-all duration-500 hover:-translate-y-2 border border-white/50 overflow-hidden`}>
                {/* Animated Background */}
                <div className="absolute inset-0 bg-gradient-to-br from-white/50 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
                
                <div className="relative">
                  <div className="flex items-start justify-between mb-4">
                    <div className={`p-4 rounded-2xl bg-gradient-to-br ${metric.gradient} shadow-lg`}>
                      <metric.icon className="w-8 h-8 text-white" />
                    </div>
                    <div className="text-right">
                      <div className="text-3xl md:text-4xl mb-1">{metric.value}</div>
                      <div className="text-sm text-gray-600">{metric.label}</div>
                    </div>
                  </div>

                  {/* Progress Bar */}
                  <div className="space-y-2">
                    <div className="h-2 bg-white/50 rounded-full overflow-hidden">
                      <div 
                        className={`h-full bg-gradient-to-r ${metric.gradient} rounded-full transition-all duration-1000`}
                        style={{ width: `${metric.progress}%` }}
                      ></div>
                    </div>
                    <div className="flex items-center justify-between text-xs">
                      <span className={`px-3 py-1 rounded-full bg-gradient-to-r ${metric.gradient} text-white font-medium`}>
                        {metric.change} {metric.changeText}
                      </span>
                      <span className="text-gray-600">{metric.progress}%</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* 🎯 Quick Actions - Modern Cards */}
        <Card className="border-0 shadow-2xl rounded-3xl mb-8 overflow-hidden bg-white/80 backdrop-blur-xl">
          <CardHeader className="border-b border-gray-100">
            <div className="flex items-center justify-between">
              <div>
                <CardTitle className="flex items-center gap-3 text-2xl">
                  <div className="p-2 rounded-xl bg-gradient-to-br from-yellow-400 to-orange-500">
                    <Zap className="w-6 h-6 text-white" />
                  </div>
                  {t("quick_actions")}
                </CardTitle>
                <CardDescription className="text-base mt-2">{t("access_health_instantly")}</CardDescription>
              </div>
            </div>
          </CardHeader>
          <CardContent className="p-8">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {quickActions.map((action, index) => (
                <button
                  key={index}
                  onClick={() => setActivePage?.(action.page)}
                  className={`group relative ${action.bgColor} rounded-3xl p-6 text-left transition-all duration-500 hover:scale-105 hover:shadow-2xl border-2 border-transparent hover:border-white overflow-hidden`}
                >
                  {/* Animated Background */}
                  <div className={`absolute inset-0 bg-gradient-to-br ${action.gradient} opacity-0 group-hover:opacity-100 transition-all duration-500`}></div>
                  
                  <div className="relative">
                    <div className={`w-16 h-16 mb-4 rounded-2xl ${action.iconBg} p-4 shadow-lg group-hover:shadow-xl transition-all duration-500 group-hover:scale-110`}>
                      <action.icon className="w-full h-full text-white" />
                    </div>
                    <h3 className="text-lg mb-2 group-hover:text-white transition-colors">{action.label}</h3>
                    <p className="text-sm text-gray-600 group-hover:text-white/90 transition-colors">{action.description}</p>
                    <div className="mt-4 flex items-center gap-2 text-sm font-medium opacity-0 group-hover:opacity-100 transition-opacity text-white">
                      <span>{t("explore")}</span>
                      <ArrowRight className="w-4 h-4" />
                    </div>
                  </div>
                </button>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* 🏥 Health Categories - د Quick Actions وروسته */}
        <Card className="border-0 shadow-2xl rounded-3xl mb-8 overflow-hidden bg-white/80 backdrop-blur-xl">
          <CardHeader className="border-b border-gray-100">
            <div className="flex items-center justify-between">
              <div>
                <CardTitle className="flex items-center gap-3 text-2xl">
                  <div className="p-2 rounded-xl bg-gradient-to-br from-blue-500 to-cyan-600">
                    <Target className="w-6 h-6 text-white" />
                  </div>
                  {t("health_categories")}
                </CardTitle>
                <CardDescription className="text-base mt-2">
                  {language === "ps" ? "د روغتیا ټولې کټګورۍ او متخصصین" :
                   language === "fa" ? "تمام دسته‌بندی‌های سلامتی و متخصصان" :
                   "All health categories and specialists"}
                </CardDescription>
              </div>
            </div>
          </CardHeader>
          <CardContent className="p-8">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {healthCategories.map((category, catIndex) => (
                <div
                  key={catIndex}
                  className="group relative bg-white rounded-2xl overflow-hidden border-2 border-gray-100 hover:border-transparent hover:shadow-2xl transition-all duration-500 cursor-pointer"
                  onClick={() => {
                    if (category.id === 'charity' && setActivePage) {
                      setActivePage('charity');
                    } else {
                      setSelectedCategory(category);
                      setIsCategoryModalOpen(true);
                    }
                  }}
                >
                  {/* Header با gradient */}
                  <div className={`relative bg-gradient-to-br ${category.gradient} p-6 text-white overflow-hidden`}>
                    {/* Background pattern */}
                    <div className="absolute inset-0 opacity-10">
                      <div className="absolute inset-0" style={{
                        backgroundImage: `radial-gradient(circle at 2px 2px, currentColor 1px, transparent 0)`,
                        backgroundSize: '30px 30px'
                      }}></div>
                    </div>
                    
                    <div className="relative">
                      <div className="flex items-center justify-between mb-4">
                        <div className="w-14 h-14 bg-white/20 backdrop-blur-xl rounded-2xl flex items-center justify-center">
                          <category.icon className="w-8 h-8" />
                        </div>
                        <Badge variant="secondary" className="bg-white/20 text-white border-0">
                          {category.doctors.length} {language === "ps" ? "ډاکټران" : language === "fa" ? "دکتر" : "Doctors"}
                        </Badge>
                      </div>
                      <h3 className="text-xl mb-1">
                        {language === "ps" ? category.labelPashto : 
                         language === "fa" ? category.labelDari : 
                         category.label}
                      </h3>
                      <p className="text-white/80 text-sm">
                        {language === "ps" ? "د متخصصینو لیست" :
                         language === "fa" ? "لیست متخصصان" :
                         "Specialist List"}
                      </p>
                    </div>
                  </div>

                  {/* Doctors & Books Tabs */}
                  <div className="p-4">
                    {/* Mini Tabs */}
                    <div className="flex gap-2 mb-3">
                      <button
                        onClick={() => {
                          setActiveTabsByCategory({...activeTabsByCategory, [catIndex]: 'doctors'});
                        }}
                        className={`flex-1 py-2 px-3 rounded-lg text-xs font-semibold transition-all ${
                          (!activeTabsByCategory[catIndex] || activeTabsByCategory[catIndex] === 'doctors')
                            ? `bg-gradient-to-r ${category.gradient} text-white shadow-md`
                            : 'bg-white border-2 border-gray-200 text-gray-600 hover:bg-gray-50'
                        }`}
                      >
                        <Stethoscope className="w-3 h-3 inline mr-1" />
                        {language === "ps" ? "ډاکټران" : language === "fa" ? "دکتران" : "Doctors"}
                      </button>
                      <button
                        onClick={() => {
                          setActiveTabsByCategory({...activeTabsByCategory, [catIndex]: 'books'});
                        }}
                        className={`flex-1 py-2 px-3 rounded-lg text-xs font-semibold transition-all ${
                          activeTabsByCategory[catIndex] === 'books'
                            ? `bg-gradient-to-r ${category.gradient} text-white shadow-md`
                            : 'bg-white border-2 border-gray-200 text-gray-600 hover:bg-gray-50'
                        }`}
                      >
                        <BookOpen className="w-3 h-3 inline mr-1" />
                        {language === "ps" ? "کتابونه" : language === "fa" ? "کتاب‌ها" : "Books"}
                      </button>
                    </div>

                    {/* Doctors List */}
                    <div className={`space-y-3 ${activeTabsByCategory[catIndex] === 'books' ? 'hidden' : ''}`}>
                      {category.doctors.map((doctor, docIndex) => (
                        <div
                          key={docIndex}
                          className={`p-3 rounded-xl bg-gradient-to-br ${category.bgColor} border border-gray-100 hover:shadow-lg transition-all duration-300 cursor-pointer`}
                          onClick={() => setActivePage?.("doctors")}
                        >
                          <div className="flex items-start justify-between mb-2">
                            <div className="flex-1">
                              <h4 className="text-sm mb-1">{doctor.name}</h4>
                              <p className="text-xs text-gray-600 mb-1">{doctor.specialty}</p>
                            </div>
                            <div className="flex items-center gap-1 bg-white px-2 py-1 rounded-lg">
                              <Star className="w-3 h-3 fill-yellow-400 text-yellow-400" />
                              <span className="text-xs">{doctor.rating}</span>
                            </div>
                          </div>
                          <div className="flex items-center justify-between text-xs text-gray-600">
                            <div className="flex items-center gap-1">
                              <Clock className="w-3 h-3" />
                              <span>{doctor.experience}</span>
                            </div>
                            <div className="flex items-center gap-1">
                              <Users className="w-3 h-3" />
                              <span>{doctor.patients}</span>
                            </div>
                          </div>
                        </div>
                      ))}
                      
                      <Button 
                        onClick={() => setActivePage?.("doctors")}
                        className={`w-full bg-gradient-to-r ${category.gradient} hover:opacity-90 text-white h-10 text-sm`}
                      >
                        {language === "ps" ? "ټول ډاکټران" : language === "fa" ? "همه دکترها" : "All Doctors"}
                        <ChevronRight className="w-4 h-4 ml-1" />
                      </Button>
                    </div>

                    {/* Books List - Show all 5 books */}
                    <div className={`space-y-3 ${activeTabsByCategory[catIndex] === 'books' ? '' : 'hidden'}`}>
                      {category.books.map((book, bookIndex) => (
                        <div
                          key={bookIndex}
                          className={`p-3 rounded-xl bg-gradient-to-br ${category.bgColor} border border-gray-100 hover:shadow-lg transition-all duration-300`}
                        >
                          <div className="flex items-start gap-2 mb-2">
                            <div className={`w-10 h-12 rounded bg-gradient-to-br ${category.gradient} flex items-center justify-center text-white`}>
                              <BookOpen className="w-5 h-5" />
                            </div>
                            <div className="flex-1">
                              <h4 className="text-xs mb-1 line-clamp-2">
                                {language === "ps" ? book.titlePs : language === "fa" ? book.titleFa : book.title}
                              </h4>
                              <p className="text-xs text-gray-600">{book.author}</p>
                            </div>
                          </div>
                          <div className="flex items-center justify-between text-xs">
                            <div className="flex items-center gap-2 text-gray-600">
                              <span>{book.pages}p</span>
                              <div className="flex items-center gap-1">
                                <Star className="w-3 h-3 fill-yellow-400 text-yellow-400" />
                                <span>{book.rating}</span>
                              </div>
                            </div>
                            <Button
                              size="sm"
                              variant="ghost"
                              onClick={() => setActivePage?.("books")}
                              className={`w-full mt-2 h-8 text-xs bg-gradient-to-r ${category.gradient} hover:opacity-90 text-white`}
                            >
                              <Download className="w-3 h-3 mr-1" />
                              {language === "ps" ? "ډاونلوډ" : language === "fa" ? "دانلود" : "Download"}
                            </Button>
                          </div>
                        </div>
                      ))}

                      <Button
                        onClick={() => setActivePage?.("books")}
                        className={`w-full bg-white border-2 border-gray-200 hover:bg-gray-50 text-gray-700 h-10 text-sm`}
                      >
                        {language === "ps" ? "ټول کتابونه" : language === "fa" ? "همه کتاب‌ها" : "All Books"}
                        <ChevronRight className="w-4 h-4 ml-1" />
                      </Button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* AdMob Banner */}
        <div className="mb-8">
          <AdBanner adSlot="homescreen-top" format="horizontal" />
        </div>

        {/* 👨‍⚕️ Featured Doctors - Premium Cards */}
        <Card className="border-0 shadow-2xl rounded-3xl mb-8 overflow-hidden bg-gradient-to-br from-white via-emerald-50/30 to-teal-50/30 backdrop-blur-xl">
          <CardHeader className="border-b border-emerald-100">
            <div className="flex items-center justify-between">
              <div>
                <CardTitle className="flex items-center gap-3 text-2xl">
                  <div className="p-2 rounded-xl bg-gradient-to-br from-emerald-500 to-teal-600">
                    <Award className="w-6 h-6 text-white" />
                  </div>
                  {t("top_doctors")}
                </CardTitle>
                <CardDescription className="text-base mt-2">{t("connect_specialists")}</CardDescription>
              </div>
              <Button 
                variant="ghost" 
                onClick={() => setActivePage?.("doctors")}
                className="text-emerald-600 hover:text-emerald-700 hover:bg-emerald-50"
              >
                {t("view_all")}
                <ChevronRight className="w-5 h-5 ml-1" />
              </Button>
            </div>
          </CardHeader>
          <CardContent className="p-8">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {featuredDoctors.map((doctor, index) => (
                <div 
                  key={index} 
                  className="group bg-white rounded-3xl p-6 shadow-xl hover:shadow-2xl transition-all duration-500 hover:-translate-y-2 border border-emerald-100 hover:border-emerald-300 cursor-pointer"
                  onClick={() => setActivePage?.("doctors")}
                >
                  {/* Doctor Image with Status */}
                  <div className="relative mb-6">
                    <div className="relative w-24 h-24 mx-auto">
                      <div className="absolute inset-0 bg-gradient-to-br from-emerald-400 to-teal-500 rounded-full animate-pulse"></div>
                      <div className="relative w-full h-full rounded-full overflow-hidden border-4 border-white shadow-xl">
                        <ImageWithFallback 
                          src={doctor.image}
                          alt={doctor.name}
                          className="w-full h-full object-cover"
                        />
                      </div>
                      {doctor.online && (
                        <div className="absolute -bottom-1 -right-1 w-7 h-7 bg-green-500 rounded-full border-4 border-white shadow-lg flex items-center justify-center">
                          <div className="w-2 h-2 bg-white rounded-full animate-pulse"></div>
                        </div>
                      )}
                      {doctor.verified && (
                        <div className="absolute -top-1 -right-1 w-7 h-7 bg-blue-500 rounded-full border-4 border-white shadow-lg flex items-center justify-center">
                          <CheckCircle className="w-4 h-4 text-white" />
                        </div>
                      )}
                    </div>
                  </div>

                  {/* Doctor Info */}
                  <div className="text-center mb-6">
                    <h3 className="text-xl mb-2">{doctor.name}</h3>
                    <p className="text-emerald-600 text-sm mb-3">{doctor.specialty}</p>
                    
                    {/* Rating */}
                    <div className="flex items-center justify-center gap-2 mb-3">
                      <div className="flex items-center gap-1 bg-amber-50 px-3 py-1 rounded-full">
                        <Star className="w-4 h-4 fill-amber-400 text-amber-400" />
                        <span className="text-sm">{doctor.rating}</span>
                      </div>
                      <span className="text-sm text-gray-500">({doctor.reviews} reviews)</span>
                    </div>

                    {/* Stats */}
                    <div className="flex items-center justify-center gap-4 text-xs text-gray-600 mb-4">
                      <div className="flex items-center gap-1">
                        <Users className="w-4 h-4" />
                        <span>{doctor.patients}</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <Clock className="w-4 h-4" />
                        <span>{doctor.experience}</span>
                      </div>
                    </div>

                    {/* Next Available */}
                    <div className="bg-emerald-50 rounded-xl px-4 py-2 text-sm text-emerald-700 mb-4">
                      <Clock className="w-4 h-4 inline mr-2" />
                      {doctor.nextAvailable}
                    </div>
                  </div>

                  {/* Book Button */}
                  <Button 
                    className="w-full bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-600 hover:to-teal-700 text-white shadow-lg hover:shadow-xl transition-all duration-300 rounded-2xl h-12"
                  >
                    <Video className="w-5 h-5 mr-2" />
                    {t("book_now")}
                  </Button>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* 💡 Health Tips - Image Cards */}
        <Card className="border-0 shadow-2xl rounded-3xl mb-8 overflow-hidden bg-white/80 backdrop-blur-xl">
          <CardHeader className="border-b border-purple-100">
            <CardTitle className="flex items-center gap-3 text-2xl">
              <div className="p-2 rounded-xl bg-gradient-to-br from-purple-500 to-pink-600">
                <Sparkles className="w-6 h-6 text-white" />
              </div>
              {t("daily_health_tips")}
            </CardTitle>
          </CardHeader>
          <CardContent className="p-8">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {healthTips.map((tip, index) => (
                <div 
                  key={index} 
                  className="group relative h-72 rounded-3xl overflow-hidden shadow-xl hover:shadow-2xl transition-all duration-500 hover:scale-105 cursor-pointer"
                >
                  {/* Background Image */}
                  <ImageWithFallback 
                    src={tip.image}
                    alt={tip.title}
                    className="absolute inset-0 w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
                  />
                  
                  {/* Gradient Overlay */}
                  <div className={`absolute inset-0 bg-gradient-to-t ${tip.gradient} opacity-80 group-hover:opacity-90 transition-opacity`}></div>
                  
                  {/* Content */}
                  <div className="absolute inset-0 p-6 flex flex-col justify-end text-white">
                    <div className="text-5xl mb-4 group-hover:scale-110 transition-transform">{tip.icon}</div>
                    <h3 className="text-2xl mb-2">{tip.title}</h3>
                    <p className="text-white/90 text-sm mb-4">{tip.description}</p>
                    <div className="flex items-center gap-2 text-sm font-medium">
                      <span>{t("learn_more")}</span>
                      <ArrowRight className="w-4 h-4 group-hover:translate-x-2 transition-transform" />
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* 📊 HealMate Statistics - د افغانستان د روغتیا ملي پلیټ فارم */}
        <Card className="border-0 shadow-2xl rounded-3xl mb-8 overflow-hidden">
          <div className="relative">
            {/* Animated gradient background */}
            <div className="absolute inset-0 bg-gradient-to-br from-blue-600 via-purple-600 to-pink-600 opacity-90" />
            <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHZpZXdCb3g9IjAgMCA2MCA2MCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyBmaWxsPSJub25lIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiPjxnIGZpbGw9IiNmZmYiIGZpbGwtb3BhY2l0eT0iMC4xIj48cGF0aCBkPSJNMzYgMzRjMC0yLjIxIDEuNzktNCA0LTRzNCAxLjc5IDQgNC0xLjc5IDQtNCA0LTQtMS43OS00LTR6bTAgMTBjMC0yLjIxIDEuNzktNCA0LTRzNCAxLjc5IDQgNC0xLjc5IDQtNCA0LTQtMS43OS00LTR6bTEwIDBjMC0yLjIxIDEuNzktNCA0LTRzNCAxLjc5IDQgNC0xLjc5IDQtNCA0LTQtMS43OS00LTR6Ii8+PC9nPjwvZz48L3N2Zz4=')] opacity-20" />
            
            <div className="relative p-8">
              {/* Header */}
              <div className="text-center mb-8">
                <div className="inline-flex items-center gap-3 bg-white/20 backdrop-blur-xl px-6 py-3 rounded-full border border-white/30 mb-4">
                  <TrendingUp className="w-6 h-6 text-white" />
                  <span className="font-bold text-white text-lg">
                    {language === 'ps' ? 'زموږ لاسته راوړنې' : language === 'fa' ? 'دستاوردهای ما' : 'Our Achievements'}
                  </span>
                </div>
                <h2 className="text-3xl md:text-4xl font-bold text-white mb-2">
                  {language === 'ps' ? 'د افغانستان #1 روغتیا پلیټ فارم' : language === 'fa' ? 'پلتفرم شماره 1 سلامت افغانستان' : 'Afghanistan\'s #1 Health Platform'}
                </h2>
                <p className="text-white/90 text-lg">
                  {language === 'ps' ? 'هر ورځ زرګونه کاروونکو سره خدمت کوو' : language === 'fa' ? 'هر روز به هزاران کاربر خدمت می‌کنیم' : 'Serving thousands of users daily'}
                </p>
              </div>

              {/* Statistics Grid */}
              <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
                {/* Stat 1: Users */}
                <div className="bg-white/20 backdrop-blur-xl rounded-2xl p-6 border border-white/30 hover:bg-white/30 transition-all duration-300 hover:scale-105">
                  <div className="flex flex-col items-center text-center">
                    <div className="w-16 h-16 bg-white/30 rounded-full flex items-center justify-center mb-4">
                      <Users className="w-8 h-8 text-white" />
                    </div>
                    <div className="text-4xl font-bold text-white mb-2">25,000+</div>
                    <p className="text-white/90 text-sm">
                      {language === 'ps' ? 'فعال کاروونکي' : language === 'fa' ? 'کاربران فعال' : 'Active Users'}
                    </p>
                  </div>
                </div>

                {/* Stat 2: Doctors */}
                <div className="bg-white/20 backdrop-blur-xl rounded-2xl p-6 border border-white/30 hover:bg-white/30 transition-all duration-300 hover:scale-105">
                  <div className="flex flex-col items-center text-center">
                    <div className="w-16 h-16 bg-white/30 rounded-full flex items-center justify-center mb-4">
                      <Stethoscope className="w-8 h-8 text-white" />
                    </div>
                    <div className="text-4xl font-bold text-white mb-2">500+</div>
                    <p className="text-white/90 text-sm">
                      {language === 'ps' ? 'تصدیق شوي ډاکټران' : language === 'fa' ? 'پزشکان تایید شده' : 'Verified Doctors'}
                    </p>
                  </div>
                </div>

                {/* Stat 3: Hospitals */}
                <div className="bg-white/20 backdrop-blur-xl rounded-2xl p-6 border border-white/30 hover:bg-white/30 transition-all duration-300 hover:scale-105">
                  <div className="flex flex-col items-center text-center">
                    <div className="w-16 h-16 bg-white/30 rounded-full flex items-center justify-center mb-4">
                      <Building2 className="w-8 h-8 text-white" />
                    </div>
                    <div className="text-4xl font-bold text-white mb-2">50+</div>
                    <p className="text-white/90 text-sm">
                      {language === 'ps' ? 'روغتونونه او کلینیکونه' : language === 'fa' ? 'بیمارستان‌ها و کلینیک‌ها' : 'Hospitals & Clinics'}
                    </p>
                  </div>
                </div>

                {/* Stat 4: Consultations */}
                <div className="bg-white/20 backdrop-blur-xl rounded-2xl p-6 border border-white/30 hover:bg-white/30 transition-all duration-300 hover:scale-105">
                  <div className="flex flex-col items-center text-center">
                    <div className="w-16 h-16 bg-white/30 rounded-full flex items-center justify-center mb-4">
                      <MessageSquare className="w-8 h-8 text-white" />
                    </div>
                    <div className="text-4xl font-bold text-white mb-2">100K+</div>
                    <p className="text-white/90 text-sm">
                      {language === 'ps' ? 'AI مشورې' : language === 'fa' ? 'مشاوره‌های AI' : 'AI Consultations'}
                    </p>
                  </div>
                </div>
              </div>

              {/* Success Stories */}
              <div className="mt-8 grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="bg-white/20 backdrop-blur-xl rounded-xl p-4 border border-white/30">
                  <div className="flex items-center gap-3">
                    <CheckCircle className="w-6 h-6 text-green-300" />
                    <div>
                      <div className="text-2xl font-bold text-white">99%</div>
                      <p className="text-white/80 text-xs">
                        {language === 'ps' ? 'د کاروونکو رضایت' : language === 'fa' ? 'رضایت کاربران' : 'User Satisfaction'}
                      </p>
                    </div>
                  </div>
                </div>

                <div className="bg-white/20 backdrop-blur-xl rounded-xl p-4 border border-white/30">
                  <div className="flex items-center gap-3">
                    <Shield className="w-6 h-6 text-blue-300" />
                    <div>
                      <div className="text-2xl font-bold text-white">100%</div>
                      <p className="text-white/80 text-xs">
                        {language === 'ps' ? 'خوندي او محرم' : language === 'fa' ? 'امن و محرمانه' : 'Secure & Private'}
                      </p>
                    </div>
                  </div>
                </div>

                <div className="bg-white/20 backdrop-blur-xl rounded-xl p-4 border border-white/30">
                  <div className="flex items-center gap-3">
                    <Clock className="w-6 h-6 text-amber-300" />
                    <div>
                      <div className="text-2xl font-bold text-white">24/7</div>
                      <p className="text-white/80 text-xs">
                        {language === 'ps' ? 'لاسرسی ته چمتو' : language === 'fa' ? 'آماده دسترسی' : 'Available'}
                      </p>
                    </div>
                  </div>
                </div>
              </div>

              {/* CTA Button */}
              <div className="mt-8 text-center">
                <Button
                  size="lg"
                  onClick={() => setActivePage?.('community')}
                  className="bg-white text-purple-600 hover:bg-white/90 shadow-2xl rounded-2xl px-8 h-14 text-lg font-bold"
                >
                  <Users className="w-6 h-6 mr-3" />
                  {language === 'ps' ? 'زموږ ټولنې سره یوځای شئ' : language === 'fa' ? 'به جامعه ما بپیوندید' : 'Join Our Community'}
                </Button>
              </div>
            </div>
          </div>
        </Card>

        {/* 🚨 Emergency Card */}
        <div className="relative mb-8 rounded-3xl overflow-hidden shadow-2xl">
          <div className="absolute inset-0 bg-gradient-to-r from-red-600 via-orange-600 to-red-600 animate-gradient"></div>
          <div className="relative p-8 text-white">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-6">
                <div className="w-20 h-20 rounded-full bg-white/20 backdrop-blur-xl flex items-center justify-center animate-pulse">
                  <Phone className="w-10 h-10" />
                </div>
                <div>
                  <h3 className="text-2xl mb-2">{t("emergency_helpline")}</h3>
                  <p className="text-5xl tracking-wider">119</p>
                </div>
              </div>
              <Button 
                size="lg"
                className="bg-white text-red-600 hover:bg-white/90 shadow-2xl rounded-2xl px-8 h-14 text-lg"
                onClick={() => setActivePage?.("emergency")}
              >
                <Phone className="w-6 h-6 mr-3" />
                {t("call_now")}
              </Button>
            </div>
          </div>
        </div>

        {/* Bottom AdMob */}
        <div className="mb-8">
          <AdBanner adSlot="homescreen-bottom" format="horizontal" />
        </div>
      </div>

      {/* Category Detail Modal */}
      <CategoryDetailModal
        isOpen={isCategoryModalOpen}
        onClose={() => setIsCategoryModalOpen(false)}
        category={selectedCategory}
        setActivePage={setActivePage}
      />
    </div>
  );
}
