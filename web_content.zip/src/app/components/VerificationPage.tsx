import { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { Mail, Phone, ArrowLeft, Check, AlertCircle, Send, RefreshCw } from 'lucide-react';
import { Button } from './ui/button';
import { Input } from './ui/input';

interface VerificationPageProps {
  language: 'ps' | 'fa' | 'en';
  email: string;
  phone: string;
  onVerified: () => void;
  onBack: () => void;
}

export function VerificationPage({ language, email, phone, onVerified, onBack }: VerificationPageProps) {
  const [verificationMethod, setVerificationMethod] = useState<'email' | 'phone'>('email');
  const [otp, setOtp] = useState(['', '', '', '', '', '']);
  const [generatedOTP, setGeneratedOTP] = useState('');
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [countdown, setCountdown] = useState(0);
  const [canResend, setCanResend] = useState(true);

  const t = {
    ps: {
      title: 'تایید',
      subtitle: 'د خپل حساب د فعالولو لپاره کوډ دننه کړئ',
      emailVerification: 'د برېښنالیک تایید',
      phoneVerification: 'د نمبر تایید',
      sentTo: 'کوډ واستول شو',
      enterCode: '۶ رقمي کوډ دننه کړئ',
      verify: 'تایید',
      resendCode: 'کوډ بیرته واستوئ',
      resendIn: 'بیرته استول په',
      seconds: 'ثانیې',
      invalidCode: 'کوډ غلط دی',
      verificationSuccess: 'ستاسو حساب تایید شو!',
      verificationFailed: 'تایید ناکام شو',
      codeSent: 'نوی کوډ واستول شو',
      switchMethod: 'د تایید میتود بدل کړئ'
    },
    fa: {
      title: 'تایید',
      subtitle: 'برای فعال‌سازی حساب، کد را وارد کنید',
      emailVerification: 'تایید ایمیل',
      phoneVerification: 'تایید شماره',
      sentTo: 'کد ارسال شد به',
      enterCode: 'کد ۶ رقمی را وارد کنید',
      verify: 'تایید',
      resendCode: 'ارسال مجدد کد',
      resendIn: 'ارسال مجدد در',
      seconds: 'ثانیه',
      invalidCode: 'کد نامعتبر است',
      verificationSuccess: 'حساب شما تایید شد!',
      verificationFailed: 'تایید ناموفق',
      codeSent: 'کد جدید ارسال شد',
      switchMethod: 'تغییر روش تایید'
    },
    en: {
      title: 'Verification',
      subtitle: 'Enter the code to activate your account',
      emailVerification: 'Email Verification',
      phoneVerification: 'Phone Verification',
      sentTo: 'Code sent to',
      enterCode: 'Enter 6-digit code',
      verify: 'Verify',
      resendCode: 'Resend Code',
      resendIn: 'Resend in',
      seconds: 'seconds',
      invalidCode: 'Invalid code',
      verificationSuccess: 'Your account has been verified!',
      verificationFailed: 'Verification failed',
      codeSent: 'New code sent',
      switchMethod: 'Switch verification method'
    }
  };

  const text = t[language];

  useEffect(() => {
    generateAndSendOTP();
  }, [verificationMethod]);

  useEffect(() => {
    if (countdown > 0) {
      const timer = setTimeout(() => setCountdown(countdown - 1), 1000);
      return () => clearTimeout(timer);
    } else {
      setCanResend(true);
    }
  }, [countdown]);

  const generateAndSendOTP = () => {
    // Generate random 6-digit OTP
    const otp = Math.floor(100000 + Math.random() * 900000).toString();
    setGeneratedOTP(otp);
    
    // In production, send via SMS/Email API
    console.log(`OTP sent to ${verificationMethod === 'email' ? email : phone}: ${otp}`);
    
    // Show OTP in alert for testing (remove in production)
    alert(`Your verification code is: ${otp}`);
    
    setCountdown(60);
    setCanResend(false);
  };

  const handleOTPChange = (index: number, value: string) => {
    if (value.length > 1) return;
    if (value && !/^\d+$/.test(value)) return;

    const newOTP = [...otp];
    newOTP[index] = value;
    setOtp(newOTP);

    // Auto-focus next input
    if (value && index < 5) {
      const nextInput = document.getElementById(`otp-${index + 1}`);
      nextInput?.focus();
    }

    // Auto-verify when all digits entered
    if (newOTP.every(digit => digit !== '') && newOTP.join('').length === 6) {
      setTimeout(() => handleVerify(newOTP.join('')), 100);
    }
  };

  const handleKeyDown = (index: number, e: React.KeyboardEvent) => {
    if (e.key === 'Backspace' && !otp[index] && index > 0) {
      const prevInput = document.getElementById(`otp-${index - 1}`);
      prevInput?.focus();
    }
  };

  const handleVerify = (code?: string) => {
    const otpCode = code || otp.join('');
    
    if (otpCode.length !== 6) {
      setError(text.enterCode);
      return;
    }

    if (otpCode === generatedOTP) {
      setSuccess(text.verificationSuccess);
      setError('');
      
      // Save verification status
      localStorage.setItem('healmate_verified', 'true');
      localStorage.setItem('healmate_verifiedMethod', verificationMethod);
      localStorage.setItem('healmate_verifiedAt', new Date().toISOString());
      
      setTimeout(() => {
        onVerified();
      }, 1500);
    } else {
      setError(text.invalidCode);
      setOtp(['', '', '', '', '', '']);
      document.getElementById('otp-0')?.focus();
    }
  };

  const handleResend = () => {
    if (!canResend) return;
    
    setOtp(['', '', '', '', '', '']);
    setError('');
    setSuccess('');
    generateAndSendOTP();
    
    // Show success message
    setSuccess(text.codeSent);
    setTimeout(() => setSuccess(''), 3000);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-red-500 via-pink-500 to-purple-600 relative overflow-hidden">
      {/* Animated Background */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute top-20 left-10 w-72 h-72 bg-white/10 rounded-full blur-3xl animate-pulse" />
        <div className="absolute bottom-20 right-10 w-96 h-96 bg-white/10 rounded-full blur-3xl animate-pulse" style={{ animationDelay: '1s' }} />
      </div>

      {/* Back Button */}
      <div className="absolute top-6 left-6 z-50">
        <Button
          variant="ghost"
          size="icon"
          onClick={onBack}
          className="bg-white/20 backdrop-blur-xl border border-white/30 hover:bg-white/30 text-white"
        >
          <ArrowLeft className="w-5 h-5" />
        </Button>
      </div>

      {/* Main Content */}
      <div className="relative z-10 min-h-screen flex items-center justify-center p-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white/95 backdrop-blur-3xl rounded-3xl shadow-2xl p-8 w-full max-w-md border border-white/50"
        >
          {/* Icon */}
          <div className="w-20 h-20 bg-gradient-to-br from-red-500 to-pink-600 rounded-3xl flex items-center justify-center mx-auto mb-6">
            {verificationMethod === 'email' ? (
              <Mail className="w-10 h-10 text-white" />
            ) : (
              <Phone className="w-10 h-10 text-white" />
            )}
          </div>

          {/* Title */}
          <h1 className="text-3xl text-center mb-2">{text.title}</h1>
          <p className="text-center text-gray-600 mb-8">{text.subtitle}</p>

          {/* Verification Method Tabs */}
          <div className="flex gap-2 mb-6 bg-gray-100 rounded-2xl p-1">
            <button
              onClick={() => setVerificationMethod('email')}
              className={`flex-1 flex items-center justify-center gap-2 py-3 rounded-xl transition-all ${
                verificationMethod === 'email'
                  ? 'bg-white shadow-md'
                  : 'text-gray-600'
              }`}
            >
              <Mail className="w-4 h-4" />
              <span className="text-sm">{text.emailVerification}</span>
            </button>
            <button
              onClick={() => setVerificationMethod('phone')}
              className={`flex-1 flex items-center justify-center gap-2 py-3 rounded-xl transition-all ${
                verificationMethod === 'phone'
                  ? 'bg-white shadow-md'
                  : 'text-gray-600'
              }`}
            >
              <Phone className="w-4 h-4" />
              <span className="text-sm">{text.phoneVerification}</span>
            </button>
          </div>

          {/* Sent To Info */}
          <div className="text-center mb-6">
            <p className="text-sm text-gray-600 mb-1">{text.sentTo}</p>
            <p className="font-medium">
              {verificationMethod === 'email' ? email : phone}
            </p>
          </div>

          {/* Error/Success Messages */}
          {error && (
            <motion.div
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              className="mb-4 p-4 bg-red-50 border border-red-200 rounded-xl flex items-center gap-2 text-red-700"
            >
              <AlertCircle className="w-5 h-5" />
              <span className="text-sm">{error}</span>
            </motion.div>
          )}
          {success && (
            <motion.div
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              className="mb-4 p-4 bg-green-50 border border-green-200 rounded-xl flex items-center gap-2 text-green-700"
            >
              <Check className="w-5 h-5" />
              <span className="text-sm">{success}</span>
            </motion.div>
          )}

          {/* OTP Input */}
          <div className="mb-6">
            <label className="block text-sm text-gray-600 mb-3 text-center">
              {text.enterCode}
            </label>
            <div className="flex gap-2 justify-center" dir="ltr">
              {otp.map((digit, index) => (
                <input
                  key={index}
                  id={`otp-${index}`}
                  type="text"
                  maxLength={1}
                  value={digit}
                  onChange={(e) => handleOTPChange(index, e.target.value)}
                  onKeyDown={(e) => handleKeyDown(index, e)}
                  className="w-12 h-14 text-center text-2xl border-2 border-gray-300 rounded-xl focus:border-red-500 focus:outline-none transition-all"
                  autoFocus={index === 0}
                />
              ))}
            </div>
          </div>

          {/* Verify Button */}
          <Button
            onClick={() => handleVerify()}
            disabled={otp.some(digit => digit === '')}
            className="w-full bg-gradient-to-r from-red-600 to-pink-600 hover:from-red-700 hover:to-pink-700 text-white h-12 mb-4"
          >
            <Check className="w-5 h-5 mr-2" />
            {text.verify}
          </Button>

          {/* Resend Code */}
          <div className="text-center">
            {canResend ? (
              <button
                onClick={handleResend}
                className="text-red-600 hover:text-red-700 text-sm flex items-center gap-2 mx-auto"
              >
                <RefreshCw className="w-4 h-4" />
                {text.resendCode}
              </button>
            ) : (
              <p className="text-sm text-gray-600">
                {text.resendIn} {countdown} {text.seconds}
              </p>
            )}
          </div>

          {/* Info Box */}
          <div className="mt-6 p-4 bg-blue-50 border border-blue-200 rounded-xl">
            <p className="text-sm text-blue-800">
              {language === 'ps' ? (
                <>💡 ستاسو د امنیت لپاره، موږ ستاسو {verificationMethod === 'email' ? 'برېښنالیک' : 'نمبر'} ته یو کوډ واستولو. دا کوډ ۶۰ ثانیې پورې د کار وړ دی.</>
              ) : language === 'fa' ? (
                <>💡 برای امنیت شما، ما یک کد به {verificationMethod === 'email' ? 'ایمیل' : 'شماره'} شما ارسال کردیم. این کد تا ۶۰ ثانیه معتبر است.</>
              ) : (
                <>💡 For your security, we sent a code to your {verificationMethod === 'email' ? 'email' : 'phone'}. This code is valid for 60 seconds.</>
              )}
            </p>
          </div>

          {/* Testing Info (Remove in production) */}
          <div className="mt-4 p-3 bg-yellow-50 border border-yellow-200 rounded-xl">
            <p className="text-xs text-yellow-800">
              🧪 <strong>Testing Mode:</strong> Check console or alert for OTP code
            </p>
          </div>
        </motion.div>
      </div>
    </div>
  );
}
