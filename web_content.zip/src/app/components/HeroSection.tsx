import { motion } from 'motion/react';
import { Heart, Stethoscope, Pill, Activity, Shield, Sparkles, ArrowRight, Building2, Menu } from 'lucide-react';
import { Button } from './ui/button';
import React from 'react';
import { ImageWithFallback } from './figma/ImageWithFallback';

interface HeroSectionProps {
  language: 'ps' | 'fa' | 'en';
  onGetStarted: () => void;
}

export function HeroSection({ language, onGetStarted }: HeroSectionProps) {
  const [currentImageIndex, setCurrentImageIndex] = React.useState(0);

  // د نامحدود عکسونو array - 30 مختلف روغتیا او ډاکټرانو عکسونه
  const healthImages = [
    'https://images.unsplash.com/photo-1576669801945-7a346954da5a?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmZW1hbGUlMjBkb2N0b3IlMjBwYXRpZW50JTIwY29uc3VsdGF0aW9ufGVufDF8fHx8MTc2NDA3OTc5M3ww&ixlib=rb-4.1.0&q=80&w=1080',
    'https://images.unsplash.com/photo-1575654402720-0af3480d1fad?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtYWxlJTIwZG9jdG9yJTIwaG9zcGl0YWwlMjBwcm9mZXNzaW9uYWx8ZW58MXx8fHwxNzY0MTA4ODM1fDA&ixlib=rb-4.1.0&q=80&w=1080',
    'https://images.unsplash.com/photo-1762190102324-116a615896da?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxoZWFsdGhjYXJlJTIwbWVkaWNhbCUyMHRlYW18ZW58MXx8fHwxNzY0MTA4ODM2fDA&ixlib=rb-4.1.0&q=80&w=1080',
    'https://images.unsplash.com/photo-1633488781325-d36e6818d0c8?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxudXJzZSUyMHBhdGllbnQlMjBjYXJlfGVufDF8fHx8MTc2NDA0NDE1NHww&ixlib=rb-4.1.0&q=80&w=1080',
    'https://images.unsplash.com/photo-1606685622133-ed6fbaaf445c?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzdXJnZXJ5JTIwbWVkaWNhbCUyMG9wZXJhdGlvbnxlbnwxfHx8fDE3NjQxMDg4MzZ8MA&ixlib=rb-4.1.0&q=80&w=1080',
    'https://images.unsplash.com/photo-1633488781325-d36e6818d0c8?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxkb2N0b3IlMjBwYXRpZW50JTIwaG9zcGl0YWx8ZW58MXx8fHwxNzY0MDUwMjgxfDA&ixlib=rb-4.1.0&q=80&w=1080',
    'https://images.unsplash.com/photo-1551601651-3c989866fe70?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzdXJnZW9uJTIwb3BlcmF0aW9uJTIwcm9vbXxlbnwxfHx8fDE3NjQxMDg5NjN8MA&ixlib=rb-4.1.0&q=80&w=1080',
    'https://images.unsplash.com/photo-1567745566980-4378a3db17fc?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwZWRpYXRyaWNpYW4lMjBjaGlsZCUyMGNhcmV8ZW58MXx8fHwxNzY0MTA4OTYzfDA&ixlib=rb-4.1.0&q=80&w=1080',
    'https://images.unsplash.com/photo-1697033803887-b1a061290569?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxkZW50aXN0JTIwZGVudGFsJTIwY2xpbmljfGVufDF8fHx8MTc2NDEwODk2NHww&ixlib=rb-4.1.0&q=80&w=1080',
    'https://images.unsplash.com/photo-1646392206581-2527b1cae5cb?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwaGFybWFjeSUyMG1lZGljaW5lJTIwcGlsbHN8ZW58MXx8fHwxNzY0MDIxMDgwfDA&ixlib=rb-4.1.0&q=80&w=1080',
    'https://images.unsplash.com/photo-1721114989769-0423619f03d2?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxob3NwaXRhbCUyMGVtZXJnZW5jeSUyMHJvb218ZW58MXx8fHwxNzY0MDcwNDUzfDA&ixlib=rb-4.1.0&q=80&w=1080',
    'https://images.unsplash.com/photo-1663354863388-9ced5806543a?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtZWRpY2FsJTIwbGFib3JhdG9yeSUyMHRlc3R8ZW58MXx8fHwxNzY0MDgyOTM2fDA&ixlib=rb-4.1.0&q=80&w=1080',
    'https://images.unsplash.com/photo-1666886572860-64254ee2ce77?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxkb2N0b3IlMjBzdGV0aG9zY29wZSUyMGNoZWNrdXB8ZW58MXx8fHwxNzY0MTA4OTY1fDA&ixlib=rb-4.1.0&q=80&w=1080',
    'https://images.unsplash.com/photo-1611689102192-1f6e0e52df0a?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxudXJzZSUyMGluamVjdGlvbiUyMHZhY2NpbmV8ZW58MXx8fHwxNzY0MTA4OTY2fDA&ixlib=rb-4.1.0&q=80&w=1080',
    'https://images.unsplash.com/photo-1628348070889-cb656235b4eb?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjYXJkaW9sb2d5JTIwaGVhcnQlMjBkb2N0b3J8ZW58MXx8fHwxNzY0MTA4OTY2fDA&ixlib=rb-4.1.0&q=80&w=1080',
    'https://images.unsplash.com/photo-1612836696857-bf3d0eab59a9?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx4LXJheSUyMG1lZGljYWwlMjBpbWFnaW5nfGVufDF8fHx8MTc2NDEwODk2Nnww&ixlib=rb-4.1.0&q=80&w=1080',
    'https://images.unsplash.com/photo-1545463913-5083aa7359a6?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwaHlzaWNhbCUyMHRoZXJhcHklMjByZWhhYmlsaXRhdGlvbnxlbnwxfHx8fDE3NjQwNzI2MjV8MA&ixlib=rb-4.1.0&q=80&w=1080',
    'https://images.unsplash.com/photo-1584636633449-6135be6c4169?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtZW50YWwlMjBoZWFsdGglMjBjb3Vuc2VsaW5nfGVufDF8fHx8MTc2NDAzMjQxMHww&ixlib=rb-4.1.0&q=80&w=1080',
    'https://images.unsplash.com/photo-1583882191652-ee19c94b9e95?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwcmVnbmFudCUyMHdvbWFuJTIwdWx0cmFzb3VuZHxlbnwxfHx8fDE3NjQwMDIwMjB8MA&ixlib=rb-4.1.0&q=80&w=1080',
    'https://images.unsplash.com/photo-1615486511484-92e172cc4fe0?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxibG9vZCUyMHByZXNzdXJlJTIwbWVhc3VyZW1lbnR8ZW58MXx8fHwxNzY0MTA4OTY3fDA&ixlib=rb-4.1.0&q=80&w=1080',
    'https://images.unsplash.com/photo-1710074213379-2a9c2653046a?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtZWRpY2FsJTIwZXF1aXBtZW50JTIwaG9zcGl0YWx8ZW58MXx8fHwxNzY0MTA4OTY4fDA&ixlib=rb-4.1.0&q=80&w=1080',
    'https://images.unsplash.com/photo-1721411480070-fcb558776d54?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxhbWJ1bGFuY2UlMjBlbWVyZ2VuY3klMjBtZWRpY2FsfGVufDF8fHx8MTc2NDEwODk2OHww&ixlib=rb-4.1.0&q=80&w=1080',
    'https://images.unsplash.com/photo-1663151064065-cb334788f77d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxleWUlMjBkb2N0b3IlMjBvcGh0aGFsbW9sb2d5fGVufDF8fHx8MTc2NDEwODk2OXww&ixlib=rb-4.1.0&q=80&w=1080',
    'https://images.unsplash.com/photo-1645005512827-48ff6f97848a?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxyZWhhYmlsaXRhdGlvbiUyMHBoeXNpb3RoZXJhcHl8ZW58MXx8fHwxNzY0MTA4OTY5fDA&ixlib=rb-4.1.0&q=80&w=1080',
    'https://images.unsplash.com/photo-1758691462126-2ee47c8bf9e7?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtZWRpY2FsJTIwY29uc3VsdGF0aW9uJTIwY2xpbmljfGVufDF8fHx8MTc2NDEwODk3NHww&ixlib=rb-4.1.0&q=80&w=1080',
    'https://images.unsplash.com/photo-1737792837727-fd46ff71acf2?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxoZWFsdGhjYXJlJTIwd29ya2VyJTIwbWFza3xlbnwxfHx8fDE3NjQxMDg5NzV8MA&ixlib=rb-4.1.0&q=80&w=1080',
    'https://images.unsplash.com/photo-1650174378624-c9ab2c99e512?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxob3NwaXRhbCUyMGJlZCUyMHBhdGllbnR8ZW58MXx8fHwxNzY0MDQ0MTUyfDA&ixlib=rb-4.1.0&q=80&w=1080',
    'https://images.unsplash.com/photo-1581056771392-8a90ddb76831?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxkb2N0b3IlMjBtZWRpY2FsJTIwZXhhbXxlbnwxfHx8fDE3NjQxMDg5NzV8MA&ixlib=rb-4.1.0&q=80&w=1080',
    'https://images.unsplash.com/photo-1708461859488-2a0c081ff826?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxudXJzZSUyMGNhcmluZyUyMGVsZGVybHl8ZW58MXx8fHwxNzY0MTA4OTc2fDA&ixlib=rb-4.1.0&q=80&w=1080',
    'https://images.unsplash.com/photo-1761106082516-61d4c6883f59?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtZWRpY2FsJTIwcmVzZWFyY2glMjBsYWJvcmF0b3J5fGVufDF8fHx8MTc2NDA1MDQ5Nnww&ixlib=rb-4.1.0&q=80&w=1080',
  ];

  // د عکس په اتومات ډول بدل کړئ هر 1 دقیقه
  React.useEffect(() => {
    const interval = setInterval(() => {
      setCurrentImageIndex((prev) => (prev + 1) % healthImages.length);
    }, 60000); // هر 1 دقیقه (60 ثانیې)

    return () => clearInterval(interval);
  }, []);

  const titles = {
    ps: 'مسلکي طبي مشوره',
    fa: 'مشاوره طبی حرفه‌ای',
    en: 'Professional Medical Advice'
  };

  const stats = [
    {
      count: '250+',
      label: { ps: 'ډاکټران', fa: 'دکتران', en: 'Doctors' }
    },
    {
      count: '150+',
      label: { ps: 'روغتونونه', fa: 'بیمارستان', en: 'Hospitals' }
    },
    {
      count: '10K+',
      label: { ps: 'کاروونکي', fa: 'کاربران', en: 'Users' }
    },
    {
      count: '1500+',
      label: { ps: 'درمل', fa: 'دارو', en: 'Medicines' }
    }
  ];

  return (
    <div className="relative w-full min-h-screen bg-gradient-to-br from-emerald-50 via-white to-red-50">
      {/* اسلامي او کلتوري Background Patterns */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        {/* د افغانستان بیرغ رنګونه - سور، شین، زرغون */}
        <div className="absolute top-0 left-0 w-full h-full opacity-20">
          <div className="absolute top-0 left-1/4 w-96 h-96 bg-gradient-to-br from-red-200 to-red-300 rounded-full blur-3xl animate-pulse" />
          <div className="absolute top-1/3 right-1/4 w-80 h-80 bg-gradient-to-br from-emerald-200 to-green-300 rounded-full blur-3xl animate-pulse" style={{ animationDelay: '1s' }} />
          <div className="absolute bottom-1/4 left-1/3 w-72 h-72 bg-gradient-to-br from-gray-800/20 to-gray-900/20 rounded-full blur-3xl animate-pulse" style={{ animationDelay: '2s' }} />
        </div>

        {/* اسلامي Geometric Pattern Decorations */}
        <div className="absolute inset-0 opacity-10">
          {/* Top Right Corner - اسلامي نمونه */}
          <div className="absolute top-10 right-10 w-32 h-32 border-4 border-emerald-600 rotate-45 rounded-lg" />
          <div className="absolute top-16 right-16 w-20 h-20 border-2 border-red-600 rotate-45 rounded-lg" />
          
          {/* Bottom Left Corner - کلتوري نمونه */}
          <div className="absolute bottom-10 left-10 w-32 h-32 border-4 border-red-600 rotate-45 rounded-lg" />
          <div className="absolute bottom-16 left-16 w-20 h-20 border-2 border-emerald-600 rotate-45 rounded-lg" />
          
          {/* Center Decorative Pattern */}
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2">
            <div className="w-64 h-64 border-2 border-dashed border-emerald-400 rounded-full opacity-30" />
            <div className="absolute inset-8 border-2 border-dashed border-red-400 rounded-full opacity-30" />
          </div>
        </div>

        {/* اسلامي Stars Pattern */}
        <div className="absolute inset-0 opacity-20">
          {[...Array(8)].map((_, i) => (
            <div
              key={i}
              className="absolute w-4 h-4 text-emerald-600"
              style={{
                top: `${15 + i * 12}%`,
                left: `${10 + (i % 2) * 70}%`,
              }}
            >
              ✦
            </div>
          ))}
        </div>
      </div>

      {/* Main Content Container */}
      <div className="relative z-10 w-full min-h-screen flex flex-col items-center pt-20 pb-24 px-4">
        
        {/* Hero Image Card - د اسلامي او کلتوري ډیزاین سره */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, ease: "easeOut" }}
          className="w-full max-w-sm mx-auto"
        >
          {/* Decorative Islamic Top Border */}
          <div className="flex justify-center mb-3">
            <div className="flex items-center gap-2">
              <div className="w-16 h-1 bg-gradient-to-r from-transparent via-emerald-600 to-emerald-600 rounded-full" />
              <div className="text-emerald-700 text-xl">✦</div>
              <div className="w-4 h-4 bg-gradient-to-br from-red-600 to-red-700 rotate-45 rounded-sm" />
              <div className="text-red-700 text-xl">❋</div>
              <div className="w-4 h-4 bg-gradient-to-br from-emerald-600 to-emerald-700 rotate-45 rounded-sm" />
              <div className="text-emerald-700 text-xl">✦</div>
              <div className="w-16 h-1 bg-gradient-to-l from-transparent via-red-600 to-red-600 rounded-full" />
            </div>
          </div>

          {/* Image Card د کلتوري Border سره */}
          <div className="relative bg-gradient-to-br from-white via-emerald-50/30 to-white rounded-2xl shadow-2xl overflow-hidden border-4 border-double border-emerald-600/30" style={{ aspectRatio: '210/297' }}>
            
            {/* Corner Decorative Elements - اسلامي نمونې */}
            <div className="absolute top-2 left-2 z-10 w-8 h-8 border-l-4 border-t-4 border-emerald-600/40 rounded-tl-lg" />
            <div className="absolute top-2 right-2 z-10 w-8 h-8 border-r-4 border-t-4 border-red-600/40 rounded-tr-lg" />
            <div className="absolute bottom-2 left-2 z-10 w-8 h-8 border-l-4 border-b-4 border-red-600/40 rounded-bl-lg" />
            <div className="absolute bottom-2 right-2 z-10 w-8 h-8 border-r-4 border-b-4 border-emerald-600/40 rounded-br-lg" />

            {/* Image Counter Badge - کلتوري ډیزاین */}
            <div className="absolute top-4 right-4 z-20 bg-gradient-to-r from-emerald-600 to-emerald-700 backdrop-blur-sm px-3 py-1.5 rounded-full shadow-lg border-2 border-white/50">
              <span className="text-white text-xs font-semibold">
                {currentImageIndex + 1} / {healthImages.length}
              </span>
            </div>

            {/* Image Container with Smooth Transitions */}
            <div className="relative w-full h-full">
              {healthImages.map((image, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0 }}
                  animate={{ opacity: currentImageIndex === index ? 1 : 0 }}
                  transition={{ duration: 1.2, ease: "easeInOut" }}
                  className="absolute inset-0"
                >
                  <ImageWithFallback
                    src={image}
                    alt={`Health image ${index + 1}`}
                    className="w-full h-full object-cover"
                  />
                  
                  {/* د افغانستان رنګونو Gradient Overlay */}
                  <div className="absolute inset-0 bg-gradient-to-t from-gray-900/70 via-emerald-900/10 to-transparent" />
                </motion.div>
              ))}

              {/* Title - د اسلامي Style سره */}
              <div className="absolute inset-x-0 top-1/2 -translate-y-1/2 px-6">
                <div className="bg-gradient-to-r from-transparent via-emerald-900/40 to-transparent backdrop-blur-sm py-4 rounded-lg border-y-2 border-emerald-500/30">
                  <motion.h1
                    key={currentImageIndex}
                    initial={{ opacity: 0, y: 15 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.8, ease: "easeOut" }}
                    className="text-white text-center text-2xl drop-shadow-2xl"
                    style={{
                      textShadow: '0 0 20px rgba(0,0,0,0.8), 0 4px 12px rgba(0,0,0,0.5)'
                    }}
                  >
                    {titles[language]}
                  </motion.h1>
                  {/* اسلامي Decorative Line */}
                  <div className="flex justify-center mt-2 gap-1">
                    <div className="w-2 h-2 bg-emerald-400 rotate-45 rounded-sm" />
                    <div className="w-12 h-0.5 bg-gradient-to-r from-emerald-400 via-white to-red-400 mt-1" />
                    <div className="w-2 h-2 bg-red-400 rotate-45 rounded-sm" />
                  </div>
                </div>
              </div>

              {/* Stats Grid - د افغانستان رنګونو سره */}
              <div className="absolute bottom-4 left-4 right-4">
                <div className="grid grid-cols-2 gap-2">
                  {stats.map((stat, index) => (
                    <motion.div
                      key={index}
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: 0.2 + index * 0.1, duration: 0.6 }}
                      className="relative bg-white/95 backdrop-blur-sm rounded-xl p-3 text-center shadow-lg border-2 overflow-hidden"
                      style={{
                        borderColor: index % 2 === 0 ? 'rgba(5, 150, 105, 0.3)' : 'rgba(220, 38, 38, 0.3)'
                      }}
                    >
                      {/* کلتوري Corner Decoration */}
                      <div 
                        className="absolute top-0 right-0 w-6 h-6 opacity-20"
                        style={{
                          background: index % 2 === 0 
                            ? 'linear-gradient(135deg, transparent 50%, rgba(5, 150, 105, 0.5) 50%)'
                            : 'linear-gradient(135deg, transparent 50%, rgba(220, 38, 38, 0.5) 50%)'
                        }}
                      />
                      
                      <div className="text-gray-900 text-lg font-bold">
                        {stat.count}
                      </div>
                      <div 
                        className="text-xs mt-0.5 font-semibold"
                        style={{
                          color: index % 2 === 0 ? 'rgb(5, 150, 105)' : 'rgb(220, 38, 38)'
                        }}
                      >
                        {stat.label[language]}
                      </div>
                    </motion.div>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* Decorative Islamic Bottom Border */}
          <div className="flex justify-center mt-3">
            <div className="flex items-center gap-2">
              <div className="w-16 h-1 bg-gradient-to-r from-transparent via-red-600 to-red-600 rounded-full" />
              <div className="text-red-700 text-xl">✦</div>
              <div className="w-4 h-4 bg-gradient-to-br from-emerald-600 to-emerald-700 rotate-45 rounded-sm" />
              <div className="text-emerald-700 text-xl">❋</div>
              <div className="w-4 h-4 bg-gradient-to-br from-red-600 to-red-700 rotate-45 rounded-sm" />
              <div className="text-red-700 text-xl">✦</div>
              <div className="w-16 h-1 bg-gradient-to-l from-transparent via-emerald-600 to-emerald-600 rounded-full" />
            </div>
          </div>
        </motion.div>

        {/* Call to Action Button - د افغانستان رنګونو سره */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5, duration: 0.6 }}
          className="mt-6"
        >
          <Button
            onClick={onGetStarted}
            size="lg"
            className="relative bg-gradient-to-r from-red-600 via-emerald-600 to-red-600 hover:from-red-700 hover:via-emerald-700 hover:to-red-700 text-white shadow-xl hover:shadow-2xl transition-all duration-300 px-12 py-6 rounded-xl group overflow-hidden border-2 border-white/30"
          >
            {/* اسلامي Decorative Pattern په Button کې */}
            <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/10 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
            
            <span className="text-base font-bold relative z-10">
              {language === 'ps' ? 'پیل کړئ' : language === 'fa' ? 'شروع کنید' : 'Get Started'}
            </span>
            <ArrowRight className="w-5 h-5 ml-2 group-hover:translate-x-1 transition-transform relative z-10" />
            
            {/* Corner Decorations */}
            <div className="absolute top-0 left-0 w-2 h-2 bg-white/50 rounded-full" />
            <div className="absolute bottom-0 right-0 w-2 h-2 bg-white/50 rounded-full" />
          </Button>
        </motion.div>

      </div>
    </div>
  );
}