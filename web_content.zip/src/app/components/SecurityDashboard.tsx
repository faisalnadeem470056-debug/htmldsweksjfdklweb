import { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { 
  Shield, Lock, Key, AlertTriangle, CheckCircle, Eye, EyeOff,
  Activity, Clock, Users, Ban, Unlock, Download, RefreshCw,
  FileText, Database, Server, Wifi, WifiOff
} from 'lucide-react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { 
  auditLogger, 
  AuditAction, 
  sessionManager,
  loginAttemptTracker,
  rateLimiter,
  secureRetrieve,
  blockIP,
  unblockIP,
  isIPBlocked
} from '../utils/security';

interface SecurityDashboardProps {
  language: 'ps' | 'fa' | 'en';
}

export function SecurityDashboard({ language }: SecurityDashboardProps) {
  const [auditLogs, setAuditLogs] = useState<any[]>([]);
  const [blockedIPs, setBlockedIPs] = useState<string[]>([]);
  const [showLogs, setShowLogs] = useState(false);
  const [newIPToBlock, setNewIPToBlock] = useState('');

  const text = {
    ps: {
      title: 'د امنیت ډشبورډ',
      subtitle: 'د اپلیکیشن بشپړ امنیتي څارنه',
      auditLogs: 'د پلټنې ثبتونه',
      blockedIPs: 'بند شوي IP پتې',
      activeSessions: 'فعال غونډې',
      loginAttempts: 'د ننوتلو هڅې',
      securityAlerts: 'امنیتي خبرتیاوې',
      dataEncryption: 'د معلوماتو کوډ',
      accessControl: 'د لاسرسي کنټرول',
      twoFactorAuth: '2FA فعال',
      rateLimit: 'د درخواست حد',
      sessionTimeout: 'د غونډې وخت',
      passwordPolicy: 'د پاسورډ پالیسي',
      viewLogs: 'ثبتونه وګورئ',
      hideLogs: 'ثبتونه پټ کړئ',
      blockIP: 'IP بند کړئ',
      unblockIP: 'IP خلاص کړئ',
      downloadLogs: 'ثبتونه ډاونلوډ',
      clearLogs: 'ثبتونه پاک کړئ',
      refresh: 'تازه کول',
      enabled: 'فعال',
      disabled: 'غیر فعال',
      minutes: 'دقیقې',
      characters: 'توري',
      attempts: 'هڅې',
      high: 'لوړ',
      medium: 'منځنی',
      low: 'ټیټ',
      secure: 'خوندي',
      encrypted: 'کوډ شوی',
      protected: 'محافظت شوی',
      active: 'فعال',
      actions: 'کړنې',
      timestamp: 'وخت',
      action: 'عمل',
      details: 'تفصیلات',
      ipAddress: 'IP پته',
      userAgent: 'کاروونکی وسیله',
      success: 'بریالی',
      failed: 'ناکام'
    },
    fa: {
      title: 'داشبورد امنیتی',
      subtitle: 'نظارت کامل امنیت اپلیکیشن',
      auditLogs: 'گزارش‌های حسابرسی',
      blockedIPs: 'آدرس‌های IP مسدود',
      activeSessions: 'نشست‌های فعال',
      loginAttempts: 'تلاش‌های ورود',
      securityAlerts: 'هشدارهای امنیتی',
      dataEncryption: 'رمزگذاری داده',
      accessControl: 'کنترل دسترسی',
      twoFactorAuth: '2FA فعال',
      rateLimit: 'محدودیت درخواست',
      sessionTimeout: 'زمان نشست',
      passwordPolicy: 'سیاست رمز عبور',
      viewLogs: 'مشاهده گزارش‌ها',
      hideLogs: 'پنهان کردن گزارش‌ها',
      blockIP: 'مسدود کردن IP',
      unblockIP: 'رفع انسداد IP',
      downloadLogs: 'دانلود گزارش‌ها',
      clearLogs: 'پاک کردن گزارش‌ها',
      refresh: 'بروزرسانی',
      enabled: 'فعال',
      disabled: 'غیرفعال',
      minutes: 'دقیقه',
      characters: 'کاراکتر',
      attempts: 'تلاش',
      high: 'بالا',
      medium: 'متوسط',
      low: 'پایین',
      secure: 'امن',
      encrypted: 'رمزگذاری شده',
      protected: 'محافظت شده',
      active: 'فعال',
      actions: 'عملیات',
      timestamp: 'زمان',
      action: 'عمل',
      details: 'جزئیات',
      ipAddress: 'آدرس IP',
      userAgent: 'دستگاه کاربر',
      success: 'موفق',
      failed: 'ناموفق'
    },
    en: {
      title: 'Security Dashboard',
      subtitle: 'Complete application security monitoring',
      auditLogs: 'Audit Logs',
      blockedIPs: 'Blocked IP Addresses',
      activeSessions: 'Active Sessions',
      loginAttempts: 'Login Attempts',
      securityAlerts: 'Security Alerts',
      dataEncryption: 'Data Encryption',
      accessControl: 'Access Control',
      twoFactorAuth: '2FA Enabled',
      rateLimit: 'Rate Limiting',
      sessionTimeout: 'Session Timeout',
      passwordPolicy: 'Password Policy',
      viewLogs: 'View Logs',
      hideLogs: 'Hide Logs',
      blockIP: 'Block IP',
      unblockIP: 'Unblock IP',
      downloadLogs: 'Download Logs',
      clearLogs: 'Clear Logs',
      refresh: 'Refresh',
      enabled: 'Enabled',
      disabled: 'Disabled',
      minutes: 'minutes',
      characters: 'characters',
      attempts: 'attempts',
      high: 'High',
      medium: 'Medium',
      low: 'Low',
      secure: 'Secure',
      encrypted: 'Encrypted',
      protected: 'Protected',
      active: 'Active',
      actions: 'Actions',
      timestamp: 'Timestamp',
      action: 'Action',
      details: 'Details',
      ipAddress: 'IP Address',
      userAgent: 'User Agent',
      success: 'Success',
      failed: 'Failed'
    }
  };

  const t = text[language];

  useEffect(() => {
    loadData();
  }, []);

  const loadData = () => {
    const logs = auditLogger.getLogs();
    setAuditLogs(logs.slice(0, 50)); // Show last 50 logs

    const blocked = secureRetrieve<string[]>('blocked_ips') || [];
    setBlockedIPs(blocked);
  };

  const handleBlockIP = () => {
    if (newIPToBlock.trim()) {
      blockIP(newIPToBlock, 'Manually blocked by admin');
      setNewIPToBlock('');
      loadData();
      alert(language === 'ps' ? '✅ IP بریالیتوب سره بند شو!' : 
            language === 'fa' ? '✅ IP با موفقیت مسدود شد!' :
            '✅ IP blocked successfully!');
    }
  };

  const handleUnblockIP = (ip: string) => {
    unblockIP(ip);
    loadData();
    alert(language === 'ps' ? '✅ IP بریالیتوب سره خلاص شو!' : 
          language === 'fa' ? '✅ IP با موفقیت رفع انسداد شد!' :
          '✅ IP unblocked successfully!');
  };

  const downloadLogs = () => {
    const data = JSON.stringify(auditLogs, null, 2);
    const blob = new Blob([data], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `security-logs-${Date.now()}.json`;
    a.click();
  };

  const clearAllLogs = () => {
    if (confirm(language === 'ps' ? 'آیا تاسو ډاډه یاست چې ټول ثبتونه پاک کړئ?' :
                language === 'fa' ? 'آیا مطمئن هستید که همه گزارش‌ها را پاک کنید?' :
                'Are you sure you want to clear all logs?')) {
      auditLogger.clearLogs();
      loadData();
    }
  };

  const securityFeatures = [
    {
      icon: Lock,
      label: t.dataEncryption,
      value: 'AES-256',
      status: t.enabled,
      color: 'from-green-500 to-emerald-600',
      level: t.high
    },
    {
      icon: Key,
      label: t.twoFactorAuth,
      value: 'OTP',
      status: t.enabled,
      color: 'from-blue-500 to-cyan-600',
      level: t.high
    },
    {
      icon: Activity,
      label: t.rateLimit,
      value: '100/15min',
      status: t.active,
      color: 'from-purple-500 to-violet-600',
      level: t.medium
    },
    {
      icon: Clock,
      label: t.sessionTimeout,
      value: `30 ${t.minutes}`,
      status: t.active,
      color: 'from-orange-500 to-amber-600',
      level: t.medium
    },
    {
      icon: Shield,
      label: t.passwordPolicy,
      value: `8+ ${t.characters}`,
      status: t.enabled,
      color: 'from-red-500 to-pink-600',
      level: t.high
    },
    {
      icon: Users,
      label: t.accessControl,
      value: 'RBAC',
      status: t.enabled,
      color: 'from-teal-500 to-cyan-600',
      level: t.high
    }
  ];

  const stats = [
    { label: t.auditLogs, value: auditLogs.length, icon: FileText, color: 'from-blue-500 to-cyan-600' },
    { label: t.blockedIPs, value: blockedIPs.length, icon: Ban, color: 'from-red-500 to-pink-600' },
    { label: t.activeSessions, value: 0, icon: Activity, color: 'from-green-500 to-emerald-600' },
    { label: t.loginAttempts, value: 0, icon: Unlock, color: 'from-purple-500 to-violet-600' }
  ];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-gradient-to-r from-indigo-500 via-purple-500 to-pink-500 rounded-2xl p-6 text-white shadow-lg">
        <div className="flex items-center gap-3 mb-2">
          <Shield className="w-8 h-8" />
          <h2 className="text-2xl font-bold">{t.title}</h2>
        </div>
        <p className="text-white/90">{t.subtitle}</p>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {stats.map((stat, idx) => {
          const Icon = stat.icon;
          return (
            <motion.div
              key={idx}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: idx * 0.1 }}
              className="bg-white rounded-2xl p-5 border border-gray-200 shadow-lg"
            >
              <div className={`bg-gradient-to-br ${stat.color} p-3 rounded-xl w-12 h-12 flex items-center justify-center mb-3`}>
                <Icon className="w-6 h-6 text-white" />
              </div>
              <h3 className="text-3xl font-bold mb-1">{stat.value}</h3>
              <p className="text-sm text-gray-600">{stat.label}</p>
            </motion.div>
          );
        })}
      </div>

      {/* Security Features */}
      <div className="bg-white rounded-2xl p-6 border border-gray-200 shadow-lg">
        <h3 className="text-lg font-semibold mb-4">{t.securityAlerts}</h3>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {securityFeatures.map((feature, idx) => {
            const Icon = feature.icon;
            return (
              <div key={idx} className="border border-gray-200 rounded-xl p-4 hover:shadow-md transition-all">
                <div className="flex items-center justify-between mb-3">
                  <div className={`bg-gradient-to-br ${feature.color} p-2 rounded-lg`}>
                    <Icon className="w-5 h-5 text-white" />
                  </div>
                  <span className={`text-xs px-2 py-1 rounded-full ${
                    feature.level === t.high ? 'bg-green-100 text-green-700' :
                    feature.level === t.medium ? 'bg-yellow-100 text-yellow-700' :
                    'bg-gray-100 text-gray-700'
                  }`}>
                    {feature.level}
                  </span>
                </div>
                <h4 className="font-medium mb-1">{feature.label}</h4>
                <p className="text-sm text-gray-600 mb-2">{feature.value}</p>
                <span className="text-xs px-2 py-1 bg-green-100 text-green-700 rounded-full">
                  ✓ {feature.status}
                </span>
              </div>
            );
          })}
        </div>
      </div>

      {/* Blocked IPs */}
      <div className="bg-white rounded-2xl p-6 border border-gray-200 shadow-lg">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-semibold flex items-center gap-2">
            <Ban className="w-5 h-5 text-red-600" />
            {t.blockedIPs} ({blockedIPs.length})
          </h3>
          <Button onClick={loadData} variant="outline" size="sm">
            <RefreshCw className="w-4 h-4 mr-2" />
            {t.refresh}
          </Button>
        </div>

        {/* Block IP Form */}
        <div className="flex gap-2 mb-4">
          <Input
            value={newIPToBlock}
            onChange={(e) => setNewIPToBlock(e.target.value)}
            placeholder="192.168.1.1"
            className="flex-1"
          />
          <Button onClick={handleBlockIP} className="bg-gradient-to-r from-red-500 to-pink-600">
            <Ban className="w-4 h-4 mr-2" />
            {t.blockIP}
          </Button>
        </div>

        {/* Blocked IPs List */}
        {blockedIPs.length > 0 ? (
          <div className="space-y-2">
            {blockedIPs.map((ip, idx) => (
              <div key={idx} className="flex items-center justify-between p-3 bg-red-50 rounded-lg border border-red-200">
                <div className="flex items-center gap-2">
                  <WifiOff className="w-4 h-4 text-red-600" />
                  <span className="font-mono text-sm">{ip}</span>
                </div>
                <Button
                  onClick={() => handleUnblockIP(ip)}
                  variant="outline"
                  size="sm"
                  className="text-green-600 hover:bg-green-50"
                >
                  <Unlock className="w-3 h-3 mr-1" />
                  {t.unblockIP}
                </Button>
              </div>
            ))}
          </div>
        ) : (
          <div className="text-center py-8 text-gray-500">
            <Wifi className="w-12 h-12 mx-auto mb-2 opacity-50" />
            <p>{language === 'ps' ? 'هیڅ بند شوی IP نشته' : language === 'fa' ? 'IP مسدودی وجود ندارد' : 'No blocked IPs'}</p>
          </div>
        )}
      </div>

      {/* Audit Logs */}
      <div className="bg-white rounded-2xl p-6 border border-gray-200 shadow-lg">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-semibold flex items-center gap-2">
            <FileText className="w-5 h-5 text-blue-600" />
            {t.auditLogs} ({auditLogs.length})
          </h3>
          <div className="flex gap-2">
            <Button onClick={() => setShowLogs(!showLogs)} variant="outline" size="sm">
              {showLogs ? <EyeOff className="w-4 h-4 mr-2" /> : <Eye className="w-4 h-4 mr-2" />}
              {showLogs ? t.hideLogs : t.viewLogs}
            </Button>
            <Button onClick={downloadLogs} variant="outline" size="sm">
              <Download className="w-4 h-4 mr-2" />
              {t.downloadLogs}
            </Button>
            <Button onClick={clearAllLogs} variant="outline" size="sm" className="text-red-600">
              {t.clearLogs}
            </Button>
          </div>
        </div>

        {showLogs && auditLogs.length > 0 && (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-gray-50 border-b border-gray-200">
                <tr>
                  <th className="px-4 py-2 text-left">{t.timestamp}</th>
                  <th className="px-4 py-2 text-left">{t.action}</th>
                  <th className="px-4 py-2 text-left">{t.details}</th>
                  <th className="px-4 py-2 text-left">{t.ipAddress}</th>
                  <th className="px-4 py-2 text-left">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-200">
                {auditLogs.map((log) => (
                  <tr key={log.id} className="hover:bg-gray-50">
                    <td className="px-4 py-2">
                      {new Date(log.timestamp).toLocaleString()}
                    </td>
                    <td className="px-4 py-2">
                      <span className="px-2 py-1 bg-blue-100 text-blue-700 rounded text-xs">
                        {log.action}
                      </span>
                    </td>
                    <td className="px-4 py-2 text-gray-600">{log.details}</td>
                    <td className="px-4 py-2 font-mono text-xs">{log.ipAddress}</td>
                    <td className="px-4 py-2">
                      {log.success ? (
                        <CheckCircle className="w-4 h-4 text-green-600" />
                      ) : (
                        <AlertTriangle className="w-4 h-4 text-red-600" />
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        {showLogs && auditLogs.length === 0 && (
          <div className="text-center py-8 text-gray-500">
            <FileText className="w-12 h-12 mx-auto mb-2 opacity-50" />
            <p>{language === 'ps' ? 'هیڅ ثبت نشته' : language === 'fa' ? 'گزارشی وجود ندارد' : 'No logs available'}</p>
          </div>
        )}
      </div>
    </div>
  );
}
