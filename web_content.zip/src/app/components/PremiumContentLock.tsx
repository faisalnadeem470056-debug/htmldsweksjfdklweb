import { motion } from 'motion/react';
import { Lock, Crown, Sparkles, Zap, Star } from 'lucide-react';
import { Button } from './ui/button';

interface PremiumContentLockProps {
  language: 'ps' | 'fa' | 'en';
  onUpgrade: () => void;
  contentType?: 'post' | 'book' | 'article' | 'video' | 'chat';
  isLocked: boolean;
  children: React.ReactNode;
}

const translations = {
  ps: {
    locked: 'بند شوی',
    premiumOnly: '👑 یوازې د Premium لپاره',
    upgrade: 'اپګریډ کړئ',
    unlockContent: 'دا مینځپانګه خلاصه کړئ',
    getPremium: 'Premium ترلاسه کړئ',
    unlockAll: 'ټول خلاص کړئ',
    post: 'پوست',
    book: 'کتاب',
    article: 'مقاله',
    video: 'ویډیو',
    chat: 'چټ',
  },
  fa: {
    locked: 'قفل شده',
    premiumOnly: '👑 فقط برای پریمیوم',
    upgrade: 'ارتقا دهید',
    unlockContent: 'این محتوا را باز کنید',
    getPremium: 'پریمیوم دریافت کنید',
    unlockAll: 'همه را باز کنید',
    post: 'پست',
    book: 'کتاب',
    article: 'مقاله',
    video: 'ویدیو',
    chat: 'چت',
  },
  en: {
    locked: 'Locked',
    premiumOnly: '👑 Premium Only',
    upgrade: 'Upgrade',
    unlockContent: 'Unlock This Content',
    getPremium: 'Get Premium',
    unlockAll: 'Unlock All',
    post: 'Post',
    book: 'Book',
    article: 'Article',
    video: 'Video',
    chat: 'Chat',
  },
};

export function PremiumContentLock({ 
  language, 
  onUpgrade, 
  contentType = 'post',
  isLocked,
  children 
}: PremiumContentLockProps) {
  const t = translations[language];

  if (!isLocked) {
    // Content is unlocked - show normally
    return <>{children}</>;
  }

  // Content is locked - show with blur and overlay
  return (
    <div className="relative group">
      {/* Blurred Content */}
      <div className="blur-sm pointer-events-none select-none opacity-50">
        {children}
      </div>

      {/* Lock Overlay */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        className="absolute inset-0 flex items-center justify-center bg-gradient-to-br from-purple-500/10 via-pink-500/10 to-orange-500/10 backdrop-blur-sm rounded-2xl"
      >
        <motion.div
          initial={{ scale: 0.8, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ delay: 0.1 }}
          className="bg-white/95 backdrop-blur-xl rounded-3xl p-6 max-w-sm mx-4 shadow-2xl border-4 border-transparent"
          style={{
            background: 'linear-gradient(white, white) padding-box, linear-gradient(135deg, #fbbf24, #f97316, #ec4899) border-box',
          }}
        >
          {/* Lock Icon with Animation */}
          <motion.div
            animate={{
              rotate: [0, -10, 10, -10, 0],
              scale: [1, 1.1, 1, 1.1, 1],
            }}
            transition={{
              duration: 2,
              repeat: Infinity,
              repeatDelay: 1,
            }}
            className="relative mx-auto w-20 h-20 mb-4"
          >
            {/* Glow Effect */}
            <div className="absolute inset-0 bg-gradient-to-r from-yellow-400 via-orange-500 to-pink-600 rounded-full blur-xl opacity-50 animate-pulse" />
            
            {/* Lock Icon */}
            <div className="relative bg-gradient-to-r from-yellow-400 via-orange-500 to-pink-600 rounded-full w-20 h-20 flex items-center justify-center">
              <Lock className="w-10 h-10 text-white" />
            </div>

            {/* Sparkles */}
            <Sparkles className="absolute -top-2 -right-2 w-6 h-6 text-yellow-400 animate-pulse" />
            <Sparkles className="absolute -bottom-2 -left-2 w-6 h-6 text-pink-400 animate-pulse" />
          </motion.div>

          {/* Text */}
          <div className="text-center mb-4">
            <h3 className="text-xl font-bold mb-2 bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent">
              {t.premiumOnly}
            </h3>
            <p className="text-sm text-gray-600">
              {t.unlockContent}
            </p>
          </div>

          {/* Features Preview */}
          <div className="bg-gradient-to-br from-purple-50 to-pink-50 rounded-2xl p-4 mb-4 border border-purple-200">
            <div className="space-y-2">
              {[
                { icon: '🔓', text: language === 'ps' ? 'بشپړ لاسرسی' : language === 'fa' ? 'دسترسی کامل' : 'Full Access' },
                { icon: '⚡', text: language === 'ps' ? 'بې اعلاناتو' : language === 'fa' ? 'بدون اعلانات' : 'Ad-Free' },
                { icon: '📚', text: language === 'ps' ? 'ټول Premium مینځپانګه' : language === 'fa' ? 'همه محتوای پریمیوم' : 'All Premium Content' },
              ].map((item, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.2 + index * 0.1 }}
                  className="flex items-center gap-2 text-sm"
                >
                  <span className="text-xl">{item.icon}</span>
                  <span className="text-gray-700">{item.text}</span>
                </motion.div>
              ))}
            </div>
          </div>

          {/* CTA Button */}
          <Button
            onClick={onUpgrade}
            className="w-full bg-gradient-to-r from-yellow-400 via-orange-500 to-pink-600 text-white py-6 rounded-2xl font-bold shadow-lg hover:shadow-xl transition-all flex items-center justify-center gap-2 group"
          >
            <Crown className="w-5 h-5 group-hover:animate-bounce" />
            {t.upgrade}
            <Star className="w-5 h-5 group-hover:animate-spin" fill="white" />
          </Button>

          {/* Small Text */}
          <p className="text-center text-xs text-gray-500 mt-3">
            {language === 'ps' ? '200 افغانۍ/میاشت یا 2000 افغانۍ/کال' : 
             language === 'fa' ? '200 افغانی/ماه یا 2000 افغانی/سال' : 
             '200 AFN/month or 2000 AFN/year'}
          </p>
        </motion.div>
      </motion.div>

      {/* Premium Badge on Corner */}
      <div className="absolute top-4 right-4 z-10">
        <motion.div
          animate={{ rotate: [0, 5, 0, -5, 0] }}
          transition={{ duration: 2, repeat: Infinity }}
          className="bg-gradient-to-r from-yellow-400 to-orange-500 text-white px-3 py-1 rounded-full text-xs font-bold flex items-center gap-1 shadow-lg"
        >
          <Crown className="w-3 h-3" />
          {t.locked}
        </motion.div>
      </div>
    </div>
  );
}

// Compact Lock Badge Component (د cards او list items لپاره)
export function PremiumBadge({ 
  language,
  size = 'sm' 
}: { 
  language: 'ps' | 'fa' | 'en';
  size?: 'xs' | 'sm' | 'md';
}) {
  const t = translations[language];
  
  const sizes = {
    xs: 'text-xs px-2 py-0.5',
    sm: 'text-xs px-3 py-1',
    md: 'text-sm px-4 py-2',
  };

  return (
    <motion.div
      animate={{ scale: [1, 1.05, 1] }}
      transition={{ duration: 2, repeat: Infinity }}
      className={`inline-flex items-center gap-1 bg-gradient-to-r from-yellow-400 to-orange-500 text-white rounded-full font-bold shadow-md ${sizes[size]}`}
    >
      <Crown className="w-3 h-3" />
      <span>Premium</span>
    </motion.div>
  );
}

// Lock Icon Button (د quick actions لپاره)
export function PremiumLockIcon({ onClick }: { onClick: () => void }) {
  return (
    <motion.button
      whileHover={{ scale: 1.1 }}
      whileTap={{ scale: 0.9 }}
      onClick={onClick}
      className="inline-flex items-center justify-center w-8 h-8 bg-gradient-to-r from-yellow-400 to-orange-500 rounded-full shadow-lg hover:shadow-xl transition-all"
    >
      <Lock className="w-4 h-4 text-white" />
    </motion.button>
  );
}
