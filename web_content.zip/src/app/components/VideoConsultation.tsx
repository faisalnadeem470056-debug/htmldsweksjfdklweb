import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "./ui/avatar";
import { Separator } from "./ui/separator";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "./ui/dialog";
import { Input } from "./ui/input";
import { Textarea } from "./ui/textarea";
import { 
  Video, 
  VideoOff,
  Mic,
  MicOff,
  Phone,
  PhoneOff,
  Share2,
  MessageSquare,
  Calendar,
  Clock,
  User,
  FileText,
  Upload,
  Camera,
  Monitor,
  Settings,
  Maximize2,
  Minimize2,
  Users,
  Sparkles,
  CheckCircle,
  AlertCircle,
  ArrowRight
} from "lucide-react";
import { ScrollArea } from "./ui/scroll-area";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select";
import { Alert, AlertDescription } from "./ui/alert";

interface Doctor {
  id: number;
  name: string;
  nameDari: string;
  specialty: string;
  specialtyDari: string;
  image: string;
  available: boolean;
  consultationFee: number;
  rating: number;
  experience: string;
}

interface Appointment {
  id: number;
  doctor: Doctor;
  date: string;
  time: string;
  status: "scheduled" | "ongoing" | "completed";
  duration: number;
}

interface ChatMessage {
  id: number;
  sender: "doctor" | "patient";
  message: string;
  timestamp: string;
}

const mockDoctors: Doctor[] = [
  {
    id: 1,
    name: "Dr. Sarah Johnson",
    nameDari: "ډاکټره ساره جانسن",
    specialty: "Cardiologist",
    specialtyDari: "زړه متخصص",
    image: "https://images.unsplash.com/photo-1755189118414-14c8dacdb082?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxkb2N0b3IlMjBwb3J0cmFpdCUyMHByb2Zlc3Npb25hbHxlbnwxfHx8fDE3NjMxMjU5OTZ8MA&ixlib=rb-4.1.0&q=80&w=1080",
    available: true,
    consultationFee: 500,
    rating: 4.9,
    experience: "15 years"
  },
  {
    id: 2,
    name: "Dr. Noor Ahmadi",
    nameDari: "ډاکټر نور احمدي",
    specialty: "Pediatrician",
    specialtyDari: "د ماشومانو متخصص",
    image: "https://images.unsplash.com/photo-1585842378054-ee2e52f94ba2?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmZW1hbGUlMjBkb2N0b3IlMjBtZWRpY2FsfGVufDF8fHx8MTc2MzA5OTUxNnww&ixlib=rb-4.1.0&q=80&w=1080",
    available: true,
    consultationFee: 450,
    rating: 4.8,
    experience: "12 years"
  },
  {
    id: 3,
    name: "Dr. Hassan Karimi",
    nameDari: "ډاکټر حسن کریمي",
    specialty: "Neurologist",
    specialtyDari: "د اعصابو متخصص",
    image: "https://images.unsplash.com/photo-1690306816872-91063f6de36b?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjYXJkaW9sb2dpc3QlMjBkb2N0b3J8ZW58MXx8fHwxNzYzMTY1OTM5fDA&ixlib=rb-4.1.0&q=80&w=1080",
    available: false,
    consultationFee: 600,
    rating: 4.7,
    experience: "18 years"
  },
  {
    id: 4,
    name: "Dr. Maryam Haidari",
    nameDari: "ډاکټره مریم حیدري",
    specialty: "Dermatologist",
    specialtyDari: "پوستکي متخصص",
    image: "https://images.unsplash.com/photo-1567745566980-4378a3db17fc?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwZWRpYXRyaWNpYW4lMjBkb2N0b3J8ZW58MXx8fHwxNzYzMTUxNzQ4fDA&ixlib=rb-4.1.0&q=80&w=1080",
    available: true,
    consultationFee: 400,
    rating: 5.0,
    experience: "10 years"
  }
];

const mockAppointments: Appointment[] = [
  {
    id: 1,
    doctor: mockDoctors[0],
    date: "2025-11-16",
    time: "10:00 AM",
    status: "scheduled",
    duration: 30
  },
  {
    id: 2,
    doctor: mockDoctors[1],
    date: "2025-11-15",
    time: "3:00 PM",
    status: "completed",
    duration: 30
  }
];

export function VideoConsultation() {
  const [isInCall, setIsInCall] = useState(false);
  const [selectedDoctor, setSelectedDoctor] = useState<Doctor | null>(null);
  const [bookingModalOpen, setBookingModalOpen] = useState(false);
  const [cameraOn, setCameraOn] = useState(true);
  const [micOn, setMicOn] = useState(true);
  const [isFullScreen, setIsFullScreen] = useState(false);
  const [showChat, setShowChat] = useState(false);
  const [callDuration, setCallDuration] = useState(0);
  const [chatMessages, setChatMessages] = useState<ChatMessage[]>([]);
  const [chatInput, setChatInput] = useState("");
  const [prescriptionModalOpen, setPrescriptionModalOpen] = useState(false);

  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (isInCall) {
      interval = setInterval(() => {
        setCallDuration(prev => prev + 1);
      }, 1000);
    } else {
      setCallDuration(0);
    }
    return () => clearInterval(interval);
  }, [isInCall]);

  const formatCallDuration = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const handleStartCall = (doctor: Doctor) => {
    setSelectedDoctor(doctor);
    setIsInCall(true);
  };

  const handleEndCall = () => {
    setIsInCall(false);
    setSelectedDoctor(null);
    setCameraOn(true);
    setMicOn(true);
    setShowChat(false);
    setChatMessages([]);
    setPrescriptionModalOpen(true);
  };

  const handleSendChatMessage = () => {
    if (!chatInput.trim()) return;

    const newMessage: ChatMessage = {
      id: chatMessages.length + 1,
      sender: "patient",
      message: chatInput,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    setChatMessages([...chatMessages, newMessage]);
    setChatInput("");

    // Simulate doctor response
    setTimeout(() => {
      const doctorMessage: ChatMessage = {
        id: chatMessages.length + 2,
        sender: "doctor",
        message: "I understand. Let me check that for you.",
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      };
      setChatMessages(prev => [...prev, doctorMessage]);
    }, 2000);
  };

  if (isInCall && selectedDoctor) {
    return (
      <div className="fixed inset-0 bg-gray-900 z-50 flex flex-col">
        {/* Video Call Interface */}
        <div className="flex-1 relative">
          {/* Doctor's Video (Main) */}
          <div className="absolute inset-0 bg-gradient-to-br from-blue-900 to-purple-900 flex items-center justify-center">
            <div className="text-center">
              <Avatar className="w-32 h-32 mx-auto mb-4 ring-4 ring-blue-400">
                <AvatarImage src={selectedDoctor.image} />
                <AvatarFallback>{selectedDoctor.name[0]}</AvatarFallback>
              </Avatar>
              <h2 className="text-2xl text-white mb-2">{selectedDoctor.name}</h2>
              <p className="text-blue-300">{selectedDoctor.specialty}</p>
              <div className="mt-4 px-4 py-2 bg-white/10 backdrop-blur-sm rounded-full inline-block">
                <span className="text-white">{formatCallDuration(callDuration)}</span>
              </div>
            </div>
          </div>

          {/* Patient's Video (Picture-in-Picture) */}
          <div className="absolute top-4 right-4 w-48 h-36 bg-gray-800 rounded-lg overflow-hidden shadow-2xl border-2 border-white/20">
            {cameraOn ? (
              <div className="w-full h-full bg-gradient-to-br from-cyan-600 to-blue-700 flex items-center justify-center">
                <User className="w-12 h-12 text-white" />
              </div>
            ) : (
              <div className="w-full h-full bg-gray-900 flex items-center justify-center">
                <VideoOff className="w-8 h-8 text-gray-400" />
              </div>
            )}
          </div>

          {/* Call Duration Badge */}
          <div className="absolute top-4 left-4 px-4 py-2 bg-red-500/90 backdrop-blur-sm rounded-full flex items-center gap-2 animate-pulse-glow">
            <div className="w-2 h-2 bg-white rounded-full animate-pulse"></div>
            <span className="text-white text-sm">Recording</span>
          </div>

          {/* Connection Quality */}
          <div className="absolute top-4 left-1/2 -translate-x-1/2 px-4 py-2 bg-green-500/90 backdrop-blur-sm rounded-full">
            <span className="text-white text-sm">● Excellent Connection</span>
          </div>

          {/* Chat Sidebar */}
          {showChat && (
            <div className="absolute right-0 top-0 bottom-0 w-80 bg-white shadow-2xl flex flex-col">
              <div className="p-4 bg-gradient-to-r from-blue-600 to-cyan-600 text-white flex items-center justify-between">
                <h3 className="text-lg">Chat</h3>
                <Button size="sm" variant="ghost" onClick={() => setShowChat(false)}>
                  <Minimize2 className="w-4 h-4" />
                </Button>
              </div>
              <ScrollArea className="flex-1 p-4">
                <div className="space-y-3">
                  {chatMessages.map(msg => (
                    <div
                      key={msg.id}
                      className={`flex ${msg.sender === "patient" ? "justify-end" : "justify-start"}`}
                    >
                      <div
                        className={`max-w-[80%] rounded-lg p-3 ${
                          msg.sender === "patient"
                            ? "bg-blue-500 text-white"
                            : "bg-gray-100 text-gray-900"
                        }`}
                      >
                        <p className="text-sm">{msg.message}</p>
                        <p className={`text-xs mt-1 ${msg.sender === "patient" ? "text-blue-100" : "text-gray-500"}`}>
                          {msg.timestamp}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              </ScrollArea>
              <div className="p-4 border-t">
                <div className="flex gap-2">
                  <Input
                    placeholder="Type a message..."
                    value={chatInput}
                    onChange={(e) => setChatInput(e.target.value)}
                    onKeyPress={(e) => e.key === "Enter" && handleSendChatMessage()}
                  />
                  <Button size="icon" onClick={handleSendChatMessage}>
                    <MessageSquare className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Control Bar */}
        <div className="h-24 bg-gray-800 flex items-center justify-center gap-4 px-4">
          <Button
            size="lg"
            variant={micOn ? "outline" : "destructive"}
            onClick={() => setMicOn(!micOn)}
            className="rounded-full w-14 h-14"
          >
            {micOn ? <Mic className="w-6 h-6" /> : <MicOff className="w-6 h-6" />}
          </Button>

          <Button
            size="lg"
            variant={cameraOn ? "outline" : "destructive"}
            onClick={() => setCameraOn(!cameraOn)}
            className="rounded-full w-14 h-14"
          >
            {cameraOn ? <Video className="w-6 h-6" /> : <VideoOff className="w-6 h-6" />}
          </Button>

          <Button
            size="lg"
            className="bg-red-600 hover:bg-red-700 rounded-full w-16 h-16"
            onClick={handleEndCall}
          >
            <PhoneOff className="w-6 h-6" />
          </Button>

          <Button
            size="lg"
            variant="outline"
            onClick={() => setShowChat(!showChat)}
            className="rounded-full w-14 h-14"
          >
            <MessageSquare className="w-6 h-6" />
          </Button>

          <Button
            size="lg"
            variant="outline"
            className="rounded-full w-14 h-14"
          >
            <Share2 className="w-6 h-6" />
          </Button>

          <Button
            size="lg"
            variant="outline"
            onClick={() => setIsFullScreen(!isFullScreen)}
            className="rounded-full w-14 h-14"
          >
            {isFullScreen ? <Minimize2 className="w-6 h-6" /> : <Maximize2 className="w-6 h-6" />}
          </Button>

          <Button
            size="lg"
            variant="outline"
            className="rounded-full w-14 h-14"
          >
            <Settings className="w-6 h-6" />
          </Button>
        </div>

        {/* Prescription Modal */}
        <Dialog open={prescriptionModalOpen} onOpenChange={setPrescriptionModalOpen}>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle className="text-2xl flex items-center gap-2">
                <CheckCircle className="w-6 h-6 text-green-600" />
                Consultation Completed
              </DialogTitle>
              <DialogDescription>Your video consultation session has ended</DialogDescription>
            </DialogHeader>
            <div className="space-y-6">
              <Alert className="bg-green-50 border-green-200">
                <CheckCircle className="h-4 w-4 text-green-600" />
                <AlertDescription className="text-green-800">
                  Your video consultation with {selectedDoctor.name} has ended. Duration: {formatCallDuration(callDuration)}
                </AlertDescription>
              </Alert>

              <Card className="border-0 shadow-lg">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <FileText className="w-5 h-5 text-blue-600" />
                    Digital Prescription - ډیجیټل نسخه
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="p-4 bg-gradient-to-r from-blue-50 to-cyan-50 rounded-lg">
                    <div className="flex items-start gap-4 mb-4">
                      <Avatar className="w-16 h-16">
                        <AvatarImage src={selectedDoctor.image} />
                        <AvatarFallback>{selectedDoctor.name[0]}</AvatarFallback>
                      </Avatar>
                      <div className="flex-1">
                        <h3 className="text-lg text-gray-900">{selectedDoctor.name}</h3>
                        <p className="text-sm text-blue-600">{selectedDoctor.specialty}</p>
                        <p className="text-xs text-gray-600">{selectedDoctor.experience} experience</p>
                      </div>
                      <Badge className="bg-green-100 text-green-700">Verified</Badge>
                    </div>

                    <Separator className="my-4" />

                    <div className="space-y-3">
                      <div>
                        <p className="text-sm text-gray-600 mb-2">Diagnosis:</p>
                        <p className="text-gray-900">Mild hypertension - increased blood pressure</p>
                      </div>

                      <div>
                        <p className="text-sm text-gray-600 mb-2">Prescribed Medicines:</p>
                        <ul className="space-y-2">
                          <li className="p-2 bg-white rounded border">
                            <p className="text-gray-900">Amlodipine 5mg</p>
                            <p className="text-sm text-gray-600">1 tablet daily after breakfast - 30 days</p>
                          </li>
                          <li className="p-2 bg-white rounded border">
                            <p className="text-gray-900">Aspirin 75mg</p>
                            <p className="text-sm text-gray-600">1 tablet daily at night - 30 days</p>
                          </li>
                        </ul>
                      </div>

                      <div>
                        <p className="text-sm text-gray-600 mb-2">Instructions:</p>
                        <ul className="text-sm text-gray-700 space-y-1 list-disc list-inside">
                          <li>Take medicines regularly as prescribed</li>
                          <li>Monitor blood pressure daily</li>
                          <li>Reduce salt intake</li>
                          <li>Regular exercise recommended</li>
                          <li>Follow-up after 2 weeks</li>
                        </ul>
                      </div>

                      <div>
                        <p className="text-sm text-gray-600 mb-2">Next Appointment:</p>
                        <p className="text-gray-900">Follow-up on November 30, 2025</p>
                      </div>
                    </div>
                  </div>

                  <div className="flex gap-3">
                    <Button className="flex-1 bg-gradient-to-r from-blue-500 to-cyan-600">
                      <FileText className="w-4 h-4 mr-2" />
                      Download Prescription
                    </Button>
                    <Button variant="outline" className="flex-1">
                      <Share2 className="w-4 h-4 mr-2" />
                      Share
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>
          </DialogContent>
        </Dialog>
      </div>
    );
  }

  return (
    <section className="py-16 md:py-24 bg-gradient-to-b from-white via-purple-50/30 to-white relative overflow-hidden min-h-screen">
      {/* Background decoration */}
      <div className="absolute top-0 left-0 w-[500px] h-[500px] bg-gradient-to-br from-purple-100/50 to-pink-100/50 rounded-full blur-3xl animate-float"></div>
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        {/* Header */}
        <div className="text-center mb-12 md:mb-16 space-y-4">
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-purple-100 to-pink-100 rounded-full">
            <Sparkles className="w-4 h-4 text-purple-600 animate-pulse-glow" />
            <span className="text-purple-700 text-sm uppercase tracking-wider">Video Call</span>
          </div>
          <h2 className="text-4xl md:text-6xl">
            <span className="bg-gradient-to-r from-purple-600 via-pink-600 to-red-600 bg-clip-text text-transparent">
              Video Consultation
            </span>
          </h2>
          <p className="text-gray-600 max-w-2xl mx-auto text-lg">
            ویډیو مشوره - Consult with doctors via video call
          </p>
        </div>

        {/* My Appointments */}
        <div className="max-w-4xl mx-auto mb-12">
          <h3 className="text-2xl mb-6 flex items-center gap-2">
            <Calendar className="w-6 h-6 text-purple-600" />
            My Appointments - زما ملاقاتونه
          </h3>

          <div className="space-y-4">
            {mockAppointments.map((appointment) => (
              <Card key={appointment.id} className="hover-lift border-0 shadow-lg">
                <CardContent className="p-6">
                  <div className="flex items-center gap-4">
                    <Avatar className="w-16 h-16">
                      <AvatarImage src={appointment.doctor.image} />
                      <AvatarFallback>{appointment.doctor.name[0]}</AvatarFallback>
                    </Avatar>
                    <div className="flex-1">
                      <h4 className="text-lg text-gray-900 mb-1">{appointment.doctor.name}</h4>
                      <p className="text-sm text-purple-600 mb-2">{appointment.doctor.specialty}</p>
                      <div className="flex items-center gap-4 text-sm text-gray-600">
                        <span className="flex items-center gap-1">
                          <Calendar className="w-4 h-4" />
                          {appointment.date}
                        </span>
                        <span className="flex items-center gap-1">
                          <Clock className="w-4 h-4" />
                          {appointment.time}
                        </span>
                        <Badge className={
                          appointment.status === "scheduled" ? "bg-blue-100 text-blue-700" :
                          appointment.status === "ongoing" ? "bg-green-100 text-green-700" :
                          "bg-gray-100 text-gray-700"
                        }>
                          {appointment.status}
                        </Badge>
                      </div>
                    </div>
                    {appointment.status === "scheduled" && (
                      <Button
                        className="bg-gradient-to-r from-purple-500 to-pink-600 hover:from-purple-600 hover:to-pink-700"
                        onClick={() => handleStartCall(appointment.doctor)}
                      >
                        <Video className="w-4 h-4 mr-2" />
                        Join Call
                      </Button>
                    )}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* Available Doctors */}
        <div className="max-w-6xl mx-auto">
          <h3 className="text-2xl mb-6 flex items-center gap-2">
            <Users className="w-6 h-6 text-purple-600" />
            Available Doctors - شته ډاکټران
          </h3>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {mockDoctors.map((doctor, index) => (
              <Card
                key={doctor.id}
                className="hover-lift border-0 shadow-lg"
                style={{ animationDelay: `${index * 50}ms` }}
              >
                <CardContent className="p-6">
                  <div className="flex items-start gap-4 mb-4">
                    <div className="relative">
                      <Avatar className="w-20 h-20">
                        <AvatarImage src={doctor.image} />
                        <AvatarFallback>{doctor.name[0]}</AvatarFallback>
                      </Avatar>
                      {doctor.available && (
                        <div className="absolute bottom-0 right-0 w-4 h-4 bg-green-500 rounded-full border-2 border-white"></div>
                      )}
                    </div>
                    <div className="flex-1">
                      <h4 className="text-lg text-gray-900 mb-1">{doctor.name}</h4>
                      <p className="text-sm text-purple-600 mb-1">{doctor.nameDari}</p>
                      <p className="text-sm text-gray-600 mb-2">{doctor.specialty}</p>
                      <div className="flex items-center gap-3 text-xs text-gray-600">
                        <span>⭐ {doctor.rating}</span>
                        <span>•</span>
                        <span>{doctor.experience}</span>
                      </div>
                    </div>
                    <Badge className={doctor.available ? "bg-green-100 text-green-700" : "bg-gray-100 text-gray-700"}>
                      {doctor.available ? "Available" : "Busy"}
                    </Badge>
                  </div>

                  <Separator className="my-4" />

                  <div className="flex items-center justify-between mb-4">
                    <div>
                      <p className="text-sm text-gray-600">Consultation Fee</p>
                      <p className="text-xl text-purple-600">{doctor.consultationFee} AFN</p>
                    </div>
                    <div className="text-right">
                      <p className="text-sm text-gray-600">Duration</p>
                      <p className="text-gray-900">30 minutes</p>
                    </div>
                  </div>

                  <div className="flex gap-2">
                    <Button
                      className="flex-1 bg-gradient-to-r from-purple-500 to-pink-600 hover:from-purple-600 hover:to-pink-700"
                      disabled={!doctor.available}
                      onClick={() => handleStartCall(doctor)}
                    >
                      <Video className="w-4 h-4 mr-2" />
                      Start Video Call
                    </Button>
                    <Button
                      variant="outline"
                      onClick={() => {
                        setSelectedDoctor(doctor);
                        setBookingModalOpen(true);
                      }}
                    >
                      <Calendar className="w-4 h-4" />
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </div>

      {/* Booking Modal */}
      <Dialog open={bookingModalOpen} onOpenChange={setBookingModalOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Book Video Consultation</DialogTitle>
            <DialogDescription>د ویډیو مشورې بکینګ - Schedule your online consultation</DialogDescription>
          </DialogHeader>
          {selectedDoctor && (
            <div className="space-y-4">
              <div className="flex items-center gap-3 p-4 bg-gradient-to-r from-purple-50 to-pink-50 rounded-lg">
                <Avatar className="w-12 h-12">
                  <AvatarImage src={selectedDoctor.image} />
                  <AvatarFallback>{selectedDoctor.name[0]}</AvatarFallback>
                </Avatar>
                <div>
                  <p className="text-gray-900">{selectedDoctor.name}</p>
                  <p className="text-sm text-purple-600">{selectedDoctor.specialty}</p>
                </div>
              </div>

              <div>
                <label className="text-sm text-gray-700 mb-2 block">Select Date</label>
                <Input type="date" />
              </div>

              <div>
                <label className="text-sm text-gray-700 mb-2 block">Select Time</label>
                <Select>
                  <SelectTrigger>
                    <SelectValue placeholder="Choose time slot" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="10:00">10:00 AM</SelectItem>
                    <SelectItem value="11:00">11:00 AM</SelectItem>
                    <SelectItem value="14:00">2:00 PM</SelectItem>
                    <SelectItem value="15:00">3:00 PM</SelectItem>
                    <SelectItem value="16:00">4:00 PM</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <label className="text-sm text-gray-700 mb-2 block">Reason for Consultation</label>
                <Textarea placeholder="Describe your symptoms..." className="min-h-[100px]" />
              </div>

              <Separator />

              <div className="p-4 bg-gradient-to-r from-purple-50 to-pink-50 rounded-lg">
                <div className="flex justify-between mb-2">
                  <span className="text-gray-600">Consultation Fee:</span>
                  <span className="text-gray-900">{selectedDoctor.consultationFee} AFN</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Duration:</span>
                  <span className="text-gray-900">30 minutes</span>
                </div>
              </div>

              <Button className="w-full bg-gradient-to-r from-purple-500 to-pink-600 hover:from-purple-600 hover:to-pink-700">
                <CheckCircle className="w-4 h-4 mr-2" />
                Confirm Booking
              </Button>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </section>
  );
}

export default VideoConsultation;
