import React from 'react';
import healmateLogoSrc from 'figma:asset/ba48654895779a4ce2efe10c107b371087cee470.png';

interface LogoProps {
  size?: 'xs' | 'sm' | 'md' | 'lg' | 'xl' | '2xl';
  className?: string;
  showText?: boolean;
  onClick?: () => void;
}

const Logo: React.FC<LogoProps> = ({ 
  size = 'md', 
  className = '', 
  showText = true,
  onClick 
}) => {
  const sizes = {
    xs: { img: 'h-8 w-8', text: 'text-base' },
    sm: { img: 'h-10 w-10', text: 'text-lg' },
    md: { img: 'h-12 w-12', text: 'text-xl' },
    lg: { img: 'h-14 w-14', text: 'text-2xl' },
    xl: { img: 'h-20 w-20', text: 'text-3xl' },
    '2xl': { img: 'h-24 w-24', text: 'text-4xl' }
  };

  const sizeClasses = sizes[size];

  return (
    <div 
      className={`flex items-center gap-3 ${onClick ? 'cursor-pointer' : ''} ${className}`}
      onClick={onClick}
    >
      <img 
        src={healmateLogoSrc} 
        alt="HealMate Logo" 
        className={`${sizeClasses.img} object-contain flex-shrink-0`}
        style={{
          imageRendering: 'crisp-edges',
          WebkitFontSmoothing: 'antialiased'
        }}
      />
      {showText && (
        <div className="flex flex-col justify-center">
          <span className={`font-black bg-gradient-to-r from-emerald-600 via-teal-600 to-cyan-600 bg-clip-text text-transparent ${sizeClasses.text} leading-tight tracking-tight`}>
            HealMate
          </span>
          <span className="text-xs text-gray-600 -mt-0.5">د افغانستان روغتیا</span>
        </div>
      )}
    </div>
  );
};

export default Logo;
