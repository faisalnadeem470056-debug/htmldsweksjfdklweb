import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ChevronLeft, ChevronRight, Pause, Play } from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';

interface AutoImageCarouselProps {
  images: string[];
  interval?: number; // milliseconds
  showControls?: boolean;
  showDots?: boolean;
  className?: string;
  flat?: boolean;
}

export function AutoImageCarousel({
  images,
  interval = 1200000, // 20 minutes = 1200000 milliseconds
  showControls = true,
  showDots = true,
  className = '',
  flat = false,
}: AutoImageCarouselProps) {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isPaused, setIsPaused] = useState(false);

  useEffect(() => {
    if (isPaused || images.length <= 1) return;

    const timer = setInterval(() => {
      setCurrentIndex((prev) => (prev + 1) % images.length);
    }, interval);

    return () => clearInterval(timer);
  }, [currentIndex, interval, isPaused, images.length]);

  const goToNext = () => {
    setCurrentIndex((prev) => (prev + 1) % images.length);
  };

  const goToPrevious = () => {
    setCurrentIndex((prev) => (prev - 1 + images.length) % images.length);
  };

  const goToSlide = (index: number) => {
    setCurrentIndex(index);
  };

  if (images.length === 0) {
    return null;
  }

  if (flat) {
    return (
      <div className={`relative overflow-hidden ${className}`}>
        {/* Flat Modern Design */}
        <div className="relative aspect-[16/9] bg-gray-100 rounded-2xl overflow-hidden">
          <AnimatePresence mode="wait">
            <motion.div
              key={currentIndex}
              initial={{ opacity: 0, x: 100 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -100 }}
              transition={{ duration: 0.5, ease: 'easeInOut' }}
              className="absolute inset-0"
            >
              <ImageWithFallback
                src={images[currentIndex]}
                alt={`Slide ${currentIndex + 1}`}
                className="w-full h-full object-cover"
              />
              
              {/* Subtle gradient overlay for text readability */}
              <div className="absolute inset-0 bg-gradient-to-t from-black/40 via-transparent to-transparent" />
            </motion.div>
          </AnimatePresence>

          {/* Minimal Controls */}
          {showControls && images.length > 1 && (
            <>
              <button
                onClick={goToPrevious}
                className="absolute left-4 top-1/2 -translate-y-1/2 z-30 bg-white/90 hover:bg-white p-2.5 rounded-full transition-all shadow-lg hover:scale-110"
                aria-label="Previous"
              >
                <ChevronLeft className="w-5 h-5 text-gray-800" />
              </button>
              <button
                onClick={goToNext}
                className="absolute right-4 top-1/2 -translate-y-1/2 z-30 bg-white/90 hover:bg-white p-2.5 rounded-full transition-all shadow-lg hover:scale-110"
                aria-label="Next"
              >
                <ChevronRight className="w-5 h-5 text-gray-800" />
              </button>
            </>
          )}

          {/* Clean Dots Indicator */}
          {showDots && images.length > 1 && (
            <div className="absolute bottom-6 left-1/2 -translate-x-1/2 z-30 flex items-center gap-2 bg-white/90 px-4 py-2 rounded-full shadow-lg">
              {images.map((_, index) => (
                <button
                  key={index}
                  onClick={() => goToSlide(index)}
                  className={`transition-all rounded-full ${
                    index === currentIndex
                      ? 'w-8 h-2 bg-gradient-to-r from-green-600 to-teal-600'
                      : 'w-2 h-2 bg-gray-300 hover:bg-gray-400'
                  }`}
                  aria-label={`Go to slide ${index + 1}`}
                />
              ))}
            </div>
          )}

          {/* Counter Badge */}
          <div className="absolute top-6 right-6 z-30 bg-white/90 backdrop-blur-sm px-3 py-1.5 rounded-full shadow-lg">
            <span className="text-sm font-medium text-gray-800">
              {currentIndex + 1} / {images.length}
            </span>
          </div>

          {/* Pause/Play Button */}
          <button
            onClick={() => setIsPaused(!isPaused)}
            className="absolute top-6 left-6 z-30 bg-white/90 backdrop-blur-sm p-2 rounded-full shadow-lg hover:bg-white transition-all"
            aria-label={isPaused ? 'Play' : 'Pause'}
          >
            {isPaused ? (
              <Play className="w-4 h-4 text-gray-800" />
            ) : (
              <Pause className="w-4 h-4 text-gray-800" />
            )}
          </button>
        </div>

        {/* Swipe Touch Support */}
        <div
          className="absolute inset-0 z-20"
          onTouchStart={(e) => {
            const touchStart = e.touches[0].clientX;
            const handleTouchEnd = (endEvent: TouchEvent) => {
              const touchEnd = endEvent.changedTouches[0].clientX;
              const diff = touchStart - touchEnd;
              if (Math.abs(diff) > 50) {
                if (diff > 0) {
                  goToNext();
                } else {
                  goToPrevious();
                }
              }
              document.removeEventListener('touchend', handleTouchEnd);
            };
            document.addEventListener('touchend', handleTouchEnd);
          }}
        />
      </div>
    );
  }

  return (
    <div
      className={`relative overflow-hidden rounded-3xl ${className}`}
      onMouseEnter={() => setIsPaused(true)}
      onMouseLeave={() => setIsPaused(false)}
    >
      {/* Images */}
      <div className="relative aspect-[4/3] lg:aspect-[16/9]">
        <AnimatePresence mode="wait">
          <motion.div
            key={currentIndex}
            initial={{ opacity: 0, scale: 1.1 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.9 }}
            transition={{ duration: 0.7, ease: 'easeInOut' }}
            className="absolute inset-0"
          >
            {/* Gradient Overlay */}
            <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-black/20 to-transparent z-10" />
            
            {/* Image */}
            <ImageWithFallback
              src={images[currentIndex]}
              alt={`Slide ${currentIndex + 1}`}
              className="w-full h-full object-cover"
            />

            {/* Decorative Elements */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3 }}
              className="absolute bottom-0 left-0 right-0 z-20 p-8"
            >
              <div className="max-w-2xl">
                <motion.div
                  initial={{ width: 0 }}
                  animate={{ width: '100%' }}
                  transition={{ duration: interval / 1000, ease: 'linear' }}
                  className="h-1 bg-gradient-to-r from-green-500 via-teal-500 to-cyan-500 rounded-full mb-4"
                />
                <h3 className="text-2xl lg:text-4xl font-bold text-white mb-2">
                  {currentIndex === 0 && 'Professional Healthcare'}
                  {currentIndex === 1 && 'Your Wellness Journey'}
                  {currentIndex === 2 && 'Medicine Database'}
                  {currentIndex === 3 && 'Modern Healthcare'}
                  {currentIndex === 4 && 'Patient Care Excellence'}
                </h3>
                <p className="text-white/90 text-sm lg:text-base">
                  {currentIndex === 0 && 'Expert doctors and medical professionals'}
                  {currentIndex === 1 && 'Complete health and fitness solutions'}
                  {currentIndex === 2 && 'Over 1500+ medicines in our database'}
                  {currentIndex === 3 && 'State-of-the-art medical facilities'}
                  {currentIndex === 4 && 'Compassionate and quality patient care'}
                </p>
              </div>
            </motion.div>
          </motion.div>
        </AnimatePresence>

        {/* Left/Right Gradient Overlays for depth */}
        <div className="absolute inset-y-0 left-0 w-32 bg-gradient-to-r from-black/30 to-transparent z-10 pointer-events-none" />
        <div className="absolute inset-y-0 right-0 w-32 bg-gradient-to-l from-black/30 to-transparent z-10 pointer-events-none" />
      </div>

      {/* Navigation Controls */}
      {showControls && images.length > 1 && (
        <>
          <button
            onClick={goToPrevious}
            className="absolute left-4 top-1/2 -translate-y-1/2 z-30 bg-white/20 hover:bg-white/30 backdrop-blur-md p-3 rounded-full transition-all shadow-lg hover:scale-110 group"
          >
            <ChevronLeft className="w-6 h-6 text-white" />
          </button>
          <button
            onClick={goToNext}
            className="absolute right-4 top-1/2 -translate-y-1/2 z-30 bg-white/20 hover:bg-white/30 backdrop-blur-md p-3 rounded-full transition-all shadow-lg hover:scale-110 group"
          >
            <ChevronRight className="w-6 h-6 text-white" />
          </button>
        </>
      )}

      {/* Dots Indicator */}
      {showDots && images.length > 1 && (
        <div className="absolute bottom-4 left-1/2 -translate-x-1/2 z-30 flex items-center gap-2">
          {images.map((_, index) => (
            <button
              key={index}
              onClick={() => goToSlide(index)}
              className={`transition-all rounded-full ${
                index === currentIndex
                  ? 'w-8 h-2 bg-white'
                  : 'w-2 h-2 bg-white/50 hover:bg-white/75'
              }`}
            >
              <span className="sr-only">Go to slide {index + 1}</span>
            </button>
          ))}
        </div>
      )}

      {/* Slide Counter */}
      <div className="absolute top-4 right-4 z-30 bg-black/40 backdrop-blur-md px-3 py-1.5 rounded-full">
        <span className="text-white text-sm font-medium">
          {currentIndex + 1} / {images.length}
        </span>
      </div>

      {/* Pause Indicator */}
      {isPaused && (
        <motion.div
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          exit={{ opacity: 0, scale: 0.8 }}
          className="absolute top-4 left-4 z-30 bg-black/40 backdrop-blur-md px-3 py-1.5 rounded-full"
        >
          <span className="text-white text-sm">⏸️ Paused</span>
        </motion.div>
      )}

      {/* Swipe Touch Support */}
      <div
        className="absolute inset-0 z-20"
        onTouchStart={(e) => {
          const touchStart = e.touches[0].clientX;
          const handleTouchEnd = (endEvent: TouchEvent) => {
            const touchEnd = endEvent.changedTouches[0].clientX;
            const diff = touchStart - touchEnd;
            if (Math.abs(diff) > 50) {
              if (diff > 0) {
                goToNext();
              } else {
                goToPrevious();
              }
            }
            document.removeEventListener('touchend', handleTouchEnd);
          };
          document.addEventListener('touchend', handleTouchEnd);
        }}
      />
    </div>
  );
}

// Preset configurations for common use cases
export function HealthHeroCarousel() {
  const images = [
    'https://images.unsplash.com/photo-1623668164261-6dd8555b661b?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtZWRpY2FsJTIwZG9jdG9ycyUyMGhvc3BpdGFsfGVufDF8fHx8MTc2NDEwMzY0M3ww&ixlib=rb-4.1.0&q=80&w=1080',
    'https://images.unsplash.com/photo-1759476532819-e37ac3d05cff?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxoZWFsdGglMjBmaXRuZXNzJTIwd2VsbG5lc3N8ZW58MXx8fHwxNzY0MDExNDkyfDA&ixlib=rb-4.1.0&q=80&w=1080',
    'https://images.unsplash.com/photo-1646392206581-2527b1cae5cb?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtZWRpY2luZSUyMHBpbGxzJTIwcGhhcm1hY3l8ZW58MXx8fHwxNzY0MDIxNzc2fDA&ixlib=rb-4.1.0&q=80&w=1080',
    'https://images.unsplash.com/photo-1563233269-7e86880558a7?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxob3NwaXRhbCUyMGhlYWx0aGNhcmV8ZW58MXx8fHwxNzY0MDY1NDU2fDA&ixlib=rb-4.1.0&q=80&w=1080',
    'https://images.unsplash.com/photo-1633488781325-d36e6818d0c8?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxkb2N0b3IlMjBwYXRpZW50JTIwY2FyZXxlbnwxfHx8fDE3NjQwOTMxNTV8MA&ixlib=rb-4.1.0&q=80&w=1080',
  ];

  return (
    <AutoImageCarousel
      images={images}
      interval={1200000} // 20 minutes
      showControls={true}
      showDots={true}
      flat={true}
      className="w-full"
    />
  );
}
