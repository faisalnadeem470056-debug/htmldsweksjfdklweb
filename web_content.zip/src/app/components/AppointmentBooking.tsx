import { motion } from 'motion/react';
import { Calendar, Clock, User, MapPin, Check, ChevronRight, Stethoscope, Phone, Video, ArrowLeft } from 'lucide-react';
import { useState } from 'react';

interface AppointmentBookingProps {
  language: 'ps' | 'fa' | 'en';
  onBack?: () => void;
}

export function AppointmentBooking({ language, onBack }: AppointmentBookingProps) {
  const [selectedDate, setSelectedDate] = useState<string | null>(null);
  const [selectedTime, setSelectedTime] = useState<string | null>(null);
  const [selectedDoctor, setSelectedDoctor] = useState<number | null>(null);
  const [appointmentType, setAppointmentType] = useState<'clinic' | 'video'>('clinic');

  const translations = {
    ps: {
      title: 'د ملاقات وخت ټاکل',
      subtitle: 'د ډاکټر سره د ملاقات وخت ټاکئ',
      selectDoctor: 'ډاکټر انتخاب کړئ',
      selectDate: 'نیټه انتخاب کړئ',
      selectTime: 'وخت انتخاب کړئ',
      confirmBooking: 'د ملاقات تایید',
      clinic: 'کلینیک',
      video: 'ویډیو کال',
      available: 'موجود',
      experience: 'تجربه',
      years: 'کاله',
      morning: 'سهار',
      afternoon: 'مازدیګر',
      evening: 'ماښام',
      booked: 'مصروف',
      specialty: 'تخصص'
    },
    fa: {
      title: 'نوبت دهی',
      subtitle: 'نوبت ملاقات با پزشک را تنظیم کنید',
      selectDoctor: 'انتخاب پزشک',
      selectDate: 'انتخاب تاریخ',
      selectTime: 'انتخاب زمان',
      confirmBooking: 'تایید نوبت',
      clinic: 'کلینیک',
      video: 'تماس ویدیویی',
      available: 'موجود',
      experience: 'تجربه',
      years: 'سال',
      morning: 'صبح',
      afternoon: 'بعدازظهر',
      evening: 'عصر',
      booked: 'رزرو شده',
      specialty: 'تخصص'
    },
    en: {
      title: 'Book Appointment',
      subtitle: 'Schedule a visit with your doctor',
      selectDoctor: 'Select Doctor',
      selectDate: 'Select Date',
      selectTime: 'Select Time',
      confirmBooking: 'Confirm Booking',
      clinic: 'Clinic Visit',
      video: 'Video Call',
      available: 'Available',
      experience: 'Experience',
      years: 'years',
      morning: 'Morning',
      afternoon: 'Afternoon',
      evening: 'Evening',
      booked: 'Booked',
      specialty: 'Specialty'
    }
  };

  const t = translations[language];

  const doctors = [
    {
      id: 1,
      name: language === 'ps' ? 'ډاکټر احمد علي' : language === 'fa' ? 'دکتر احمد علی' : 'Dr. Ahmad Ali',
      specialty: language === 'ps' ? 'د زړه متخصص' : language === 'fa' ? 'متخصص قلب' : 'Cardiologist',
      experience: 15,
      image: '👨‍⚕️',
      color: 'from-blue-500 to-cyan-600',
      available: true
    },
    {
      id: 2,
      name: language === 'ps' ? 'ډاکټره فاطمه حسيني' : language === 'fa' ? 'دکتر فاطمه حسینی' : 'Dr. Fatima Husseini',
      specialty: language === 'ps' ? 'د ماشومانو ډاکټره' : language === 'fa' ? 'متخصص اطفال' : 'Pediatrician',
      experience: 12,
      image: '👩‍⚕️',
      color: 'from-pink-500 to-rose-600',
      available: true
    },
    {
      id: 3,
      name: language === 'ps' ? 'ډاکټر محمد کريمي' : language === 'fa' ? 'دکتر محمد کریمی' : 'Dr. Mohammad Karimi',
      specialty: language === 'ps' ? 'عمومي جراح' : language === 'fa' ? 'جراح عمومی' : 'General Surgeon',
      experience: 18,
      image: '👨‍⚕️',
      color: 'from-purple-500 to-violet-600',
      available: true
    }
  ];

  const dates = Array.from({ length: 7 }, (_, i) => {
    const date = new Date();
    date.setDate(date.getDate() + i);
    return {
      day: date.toLocaleDateString('en-US', { weekday: 'short' }),
      date: date.getDate(),
      month: date.toLocaleDateString('en-US', { month: 'short' }),
      full: date.toISOString().split('T')[0]
    };
  });

  const timeSlots = {
    morning: ['09:00', '09:30', '10:00', '10:30', '11:00', '11:30'],
    afternoon: ['13:00', '13:30', '14:00', '14:30', '15:00', '15:30'],
    evening: ['17:00', '17:30', '18:00', '18:30', '19:00', '19:30']
  };

  const canConfirm = selectedDoctor && selectedDate && selectedTime;

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-pink-50 to-rose-50 p-4 md:p-8">
      <div className="container mx-auto max-w-6xl">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-8"
        >
          <div className="inline-flex items-center justify-center w-16 h-16 bg-gradient-to-br from-purple-500 to-pink-600 rounded-2xl mb-4">
            <Calendar className="w-8 h-8 text-white" />
          </div>
          <h1 className="text-3xl font-bold text-gray-900 mb-2">{t.title}</h1>
          <p className="text-gray-600">{t.subtitle}</p>
        </motion.div>

        {/* Appointment Type */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex gap-4 mb-8"
        >
          <button
            onClick={() => setAppointmentType('clinic')}
            className={`flex-1 p-4 rounded-2xl border-2 transition-all ${
              appointmentType === 'clinic'
                ? 'border-purple-500 bg-purple-50 shadow-lg'
                : 'border-gray-200 bg-white'
            }`}
          >
            <Stethoscope className={`w-6 h-6 mx-auto mb-2 ${appointmentType === 'clinic' ? 'text-purple-600' : 'text-gray-400'}`} />
            <p className={`font-semibold ${appointmentType === 'clinic' ? 'text-purple-900' : 'text-gray-600'}`}>
              {t.clinic}
            </p>
          </button>
          <button
            onClick={() => setAppointmentType('video')}
            className={`flex-1 p-4 rounded-2xl border-2 transition-all ${
              appointmentType === 'video'
                ? 'border-pink-500 bg-pink-50 shadow-lg'
                : 'border-gray-200 bg-white'
            }`}
          >
            <Video className={`w-6 h-6 mx-auto mb-2 ${appointmentType === 'video' ? 'text-pink-600' : 'text-gray-400'}`} />
            <p className={`font-semibold ${appointmentType === 'video' ? 'text-pink-900' : 'text-gray-600'}`}>
              {t.video}
            </p>
          </button>
        </motion.div>

        {/* Select Doctor */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="mb-8"
        >
          <h2 className="text-xl font-bold text-gray-900 mb-4">{t.selectDoctor}</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {doctors.map((doctor) => (
              <motion.button
                key={doctor.id}
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                onClick={() => setSelectedDoctor(doctor.id)}
                className={`bg-white rounded-2xl p-6 border-2 transition-all text-left ${
                  selectedDoctor === doctor.id
                    ? 'border-purple-500 shadow-xl'
                    : 'border-gray-200 hover:border-purple-200'
                }`}
              >
                <div className="flex items-start gap-3 mb-4">
                  <div className={`text-4xl w-16 h-16 flex items-center justify-center bg-gradient-to-br ${doctor.color} rounded-2xl`}>
                    {doctor.image}
                  </div>
                  <div className="flex-1">
                    <h3 className="font-bold text-gray-900 mb-1">{doctor.name}</h3>
                    <p className="text-sm text-gray-600">{doctor.specialty}</p>
                  </div>
                  {selectedDoctor === doctor.id && (
                    <div className="w-6 h-6 bg-purple-600 rounded-full flex items-center justify-center">
                      <Check className="w-4 h-4 text-white" />
                    </div>
                  )}
                </div>
                <div className="flex items-center gap-2 text-sm text-gray-600">
                  <Stethoscope className="w-4 h-4" />
                  <span>{doctor.experience} {t.years} {t.experience}</span>
                </div>
                <div className="flex items-center gap-2 text-sm text-green-600 mt-2">
                  <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                  <span>{t.available}</span>
                </div>
              </motion.button>
            ))}
          </div>
        </motion.div>

        {/* Select Date */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="mb-8"
        >
          <h2 className="text-xl font-bold text-gray-900 mb-4">{t.selectDate}</h2>
          <div className="grid grid-cols-3 md:grid-cols-7 gap-3">
            {dates.map((date) => (
              <motion.button
                key={date.full}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={() => setSelectedDate(date.full)}
                className={`bg-white rounded-2xl p-4 border-2 transition-all ${
                  selectedDate === date.full
                    ? 'border-purple-500 bg-purple-50 shadow-lg'
                    : 'border-gray-200 hover:border-purple-200'
                }`}
              >
                <p className="text-xs text-gray-600 mb-1">{date.day}</p>
                <p className={`text-2xl font-bold mb-1 ${selectedDate === date.full ? 'text-purple-600' : 'text-gray-900'}`}>
                  {date.date}
                </p>
                <p className="text-xs text-gray-600">{date.month}</p>
              </motion.button>
            ))}
          </div>
        </motion.div>

        {/* Select Time */}
        {selectedDate && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
            className="mb-8"
          >
            <h2 className="text-xl font-bold text-gray-900 mb-4">{t.selectTime}</h2>
            
            {/* Morning */}
            <div className="mb-6">
              <h3 className="text-sm font-semibold text-gray-700 mb-3">{t.morning}</h3>
              <div className="grid grid-cols-3 md:grid-cols-6 gap-3">
                {timeSlots.morning.map((time) => (
                  <motion.button
                    key={time}
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                    onClick={() => setSelectedTime(time)}
                    className={`py-3 px-4 rounded-xl border-2 font-semibold transition-all ${
                      selectedTime === time
                        ? 'border-purple-500 bg-purple-600 text-white shadow-lg'
                        : 'border-gray-200 bg-white text-gray-700 hover:border-purple-200'
                    }`}
                  >
                    {time}
                  </motion.button>
                ))}
              </div>
            </div>

            {/* Afternoon */}
            <div className="mb-6">
              <h3 className="text-sm font-semibold text-gray-700 mb-3">{t.afternoon}</h3>
              <div className="grid grid-cols-3 md:grid-cols-6 gap-3">
                {timeSlots.afternoon.map((time) => (
                  <motion.button
                    key={time}
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                    onClick={() => setSelectedTime(time)}
                    className={`py-3 px-4 rounded-xl border-2 font-semibold transition-all ${
                      selectedTime === time
                        ? 'border-purple-500 bg-purple-600 text-white shadow-lg'
                        : 'border-gray-200 bg-white text-gray-700 hover:border-purple-200'
                    }`}
                  >
                    {time}
                  </motion.button>
                ))}
              </div>
            </div>

            {/* Evening */}
            <div>
              <h3 className="text-sm font-semibold text-gray-700 mb-3">{t.evening}</h3>
              <div className="grid grid-cols-3 md:grid-cols-6 gap-3">
                {timeSlots.evening.map((time) => (
                  <motion.button
                    key={time}
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                    onClick={() => setSelectedTime(time)}
                    className={`py-3 px-4 rounded-xl border-2 font-semibold transition-all ${
                      selectedTime === time
                        ? 'border-purple-500 bg-purple-600 text-white shadow-lg'
                        : 'border-gray-200 bg-white text-gray-700 hover:border-purple-200'
                    }`}
                  >
                    {time}
                  </motion.button>
                ))}
              </div>
            </div>
          </motion.div>
        )}

        {/* Confirm Button */}
        <motion.button
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          disabled={!canConfirm}
          className={`w-full py-4 rounded-2xl font-semibold text-lg transition-all flex items-center justify-center gap-2 ${
            canConfirm
              ? 'bg-gradient-to-r from-purple-600 to-pink-600 text-white hover:shadow-xl'
              : 'bg-gray-200 text-gray-400 cursor-not-allowed'
          }`}
        >
          <Check className="w-6 h-6" />
          {t.confirmBooking}
          <ChevronRight className="w-5 h-5" />
        </motion.button>

        {/* Back Button */}
        {onBack && (
          <motion.button
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.5 }}
            className="w-full py-4 rounded-2xl font-semibold text-lg transition-all flex items-center justify-center gap-2 bg-gray-200 text-gray-400 hover:bg-gray-300 hover:text-gray-500"
            onClick={onBack}
          >
            <ArrowLeft className="w-6 h-6" />
            {language === 'ps' ? 'واپس' : language === 'fa' ? 'بازگشت' : 'Back'}
          </motion.button>
        )}
      </div>
    </div>
  );
}