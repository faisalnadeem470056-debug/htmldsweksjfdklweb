// Signup Page - د نوي حساب جوړولو پاڼه
// Firebase Authentication signup with email and password

import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Mail, 
  Lock, 
  User as UserIcon, 
  Phone, 
  Eye, 
  EyeOff, 
  CheckCircle2,
  AlertCircle,
  ArrowRight,
  Sparkles,
  Shield,
  Heart,
  Stethoscope
} from 'lucide-react';
import { firebaseManager } from '../utils/FirebaseManager';
import { SimpleButton as Button } from './SimpleButton';
import { SimpleInput as Input } from './SimpleInput';
import { toast } from 'sonner@2.0.3';

interface SignupPageProps {
  language: 'ps' | 'fa' | 'en';
  onSignupSuccess?: () => void;
  onSwitchToLogin?: () => void;
  onClose?: () => void;
}

export function SignupPage({ 
  language, 
  onSignupSuccess,
  onSwitchToLogin,
  onClose 
}: SignupPageProps) {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    password: '',
    confirmPassword: ''
  });
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});

  const translations = {
    en: {
      title: 'Create Account',
      subtitle: 'Join HealMate and start your health journey',
      name: 'Full Name',
      namePlaceholder: 'Enter your full name',
      email: 'Email Address',
      emailPlaceholder: 'Enter your email',
      phone: 'Phone Number',
      phonePlaceholder: 'Enter phone number (optional)',
      password: 'Password',
      passwordPlaceholder: 'Create a strong password',
      confirmPassword: 'Confirm Password',
      confirmPasswordPlaceholder: 'Re-enter your password',
      signup: 'Sign Up',
      signingUp: 'Creating Account...',
      haveAccount: 'Already have an account?',
      login: 'Login',
      
      // Validation
      nameRequired: 'Name is required',
      emailRequired: 'Email is required',
      emailInvalid: 'Invalid email address',
      passwordRequired: 'Password is required',
      passwordShort: 'Password must be at least 6 characters',
      passwordMismatch: 'Passwords do not match',
      
      // Success
      signupSuccess: 'Account created successfully! Welcome to HealMate! 🎉',
      
      // Features
      feature1: 'Free Health Consultations',
      feature2: 'AI Health Assistant',
      feature3: 'Medicine Reminders',
      feature4: 'Emergency Services',
      
      // Privacy
      privacyNote: 'By signing up, you agree to our Terms & Privacy Policy',
      secureNote: 'Your data is encrypted and secure'
    },
    ps: {
      title: 'نوی حساب جوړ کړئ',
      subtitle: 'د HealMate سره یوځای شئ او خپله روغتیایي سفر پیل کړئ',
      name: 'بشپړ نوم',
      namePlaceholder: 'خپل بشپړ نوم ولیکئ',
      email: 'برېښنالیک پته',
      emailPlaceholder: 'خپل برېښنالیک ولیکئ',
      phone: 'د تلیفون نمبر',
      phonePlaceholder: 'د تلیفون نمبر ولیکئ (اختیاري)',
      password: 'پټنوم',
      passwordPlaceholder: 'یو قوي پټنوم جوړ کړئ',
      confirmPassword: 'پټنوم تایید کړئ',
      confirmPasswordPlaceholder: 'بیا خپل پټنوم ولیکئ',
      signup: 'حساب جوړ کړئ',
      signingUp: 'حساب جوړیږي...',
      haveAccount: 'ایا مخکې حساب لرئ؟',
      login: 'ننوتل',
      
      // Validation
      nameRequired: 'نوم اړین دی',
      emailRequired: 'برېښنالیک اړین دی',
      emailInvalid: 'برېښنالیک سم نه دی',
      passwordRequired: 'پټنوم اړین دی',
      passwordShort: 'پټنوم باید لږ تر لږه ۶ توري ولري',
      passwordMismatch: 'پټنومونه سره سمون نه لري',
      
      // Success
      signupSuccess: 'حساب بریالیتوب سره جوړ شو! د HealMate کې ښه راغلاست! 🎉',
      
      // Features
      feature1: 'وړیا روغتیایي مشورې',
      feature2: 'د AI روغتیا مرستیال',
      feature3: 'د درملو یادښتونه',
      feature4: 'بیړني خدمتونه',
      
      // Privacy
      privacyNote: 'د حساب جوړولو سره، تاسو زموږ د شرایطو او محرمیت پالیسۍ سره موافق یاست',
      secureNote: 'ستاسو معلومات خوندي او encrypted دي'
    },
    fa: {
      title: 'ایجاد حساب کاربری',
      subtitle: 'به HealMate بپیوندید و سفر سلامتی خود را شروع کنید',
      name: 'نام کامل',
      namePlaceholder: 'نام کامل خود را وارد کنید',
      email: 'آدرس ایمیل',
      emailPlaceholder: 'ایمیل خود را وارد کنید',
      phone: 'شماره تلفن',
      phonePlaceholder: 'شماره تلفن را وارد کنید (اختیاری)',
      password: 'رمز عبور',
      passwordPlaceholder: 'یک رمز عبور قوی ایجاد کنید',
      confirmPassword: 'تایید رمز عبور',
      confirmPasswordPlaceholder: 'رمز عبور خود را دوباره وارد کنید',
      signup: 'ثبت نام',
      signingUp: 'در حال ایجاد حساب...',
      haveAccount: 'قبلاً حساب دارید؟',
      login: 'ورود',
      
      // Validation
      nameRequired: 'نام الزامی است',
      emailRequired: 'ایمیل الزامی است',
      emailInvalid: 'آدرس ایمیل نامعتبر است',
      passwordRequired: 'رمز عبور الزامی است',
      passwordShort: 'رمز عبور باید حداقل ۶ کاراکتر باشد',
      passwordMismatch: 'رمزهای عبور مطابقت ندارند',
      
      // Success
      signupSuccess: 'حساب کاربری با موفقیت ایجاد شد! به HealMate خوش آمدید! 🎉',
      
      // Features
      feature1: 'مشاوره‌های رایگان سلامت',
      feature2: 'دستیار هوش مصنوعی سلامت',
      feature3: 'یادآوری دارو',
      feature4: 'خدمات اورژانسی',
      
      // Privacy
      privacyNote: 'با ثبت نام، شما با شرایط و سیاست حریم خصوصی ما موافقت می‌کنید',
      secureNote: 'اطلاعات شما رمزگذاری شده و امن است'
    }
  };

  const txt = translations[language];

  // Validation
  const validateForm = (): boolean => {
    const newErrors: Record<string, string> = {};

    if (!formData.name.trim()) {
      newErrors.name = txt.nameRequired;
    }

    if (!formData.email.trim()) {
      newErrors.email = txt.emailRequired;
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
      newErrors.email = txt.emailInvalid;
    }

    if (!formData.password) {
      newErrors.password = txt.passwordRequired;
    } else if (formData.password.length < 6) {
      newErrors.password = txt.passwordShort;
    }

    if (formData.password !== formData.confirmPassword) {
      newErrors.confirmPassword = txt.passwordMismatch;
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  // Signup Handler
  const handleSignup = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!validateForm()) {
      return;
    }

    setIsLoading(true);
    
    try {
      // د localStorage څخه موجوده کاروونکي واخلئ
      const users = JSON.parse(localStorage.getItem('healmate_users') || '[]');
      
      // وګورئ چې email مخکې موجود دی یا نه
      const emailExists = users.find((u: any) => 
        u.email.toLowerCase() === formData.email.toLowerCase()
      );
      
      if (emailExists) {
        const errorMsg = language === 'ps' 
          ? 'دا بریښنالیک مخکې کارول شوی دی'
          : language === 'fa'
          ? 'این ایمیل قبلاً استفاده شده است'
          : 'This email is already in use';
        
        toast.error(errorMsg);
        setIsLoading(false);
        return;
      }
      
      // نوی کاروونکی جوړ کړئ
      const newUser = {
        id: Date.now().toString(),
        email: formData.email.toLowerCase(),
        password: formData.password,
        name: formData.name,
        phone: formData.phone || '',
        createdAt: new Date().toISOString(),
        isPremium: false,
        profileImage: 'https://images.unsplash.com/photo-1633332755192-727a05c4013d?w=400'
      };
      
      // په کاروونکو لیست کې اضافه کړئ
      users.push(newUser);
      
      // په localStorage کې save کړئ
      localStorage.setItem('healmate_users', JSON.stringify(users));
      
      // همدارنګه په healmate_userEmail او healmate_userName کې هم save کړئ (auto login)
      localStorage.setItem('healmate_userEmail', formData.email);
      localStorage.setItem('healmate_userName', formData.name);
      localStorage.setItem('healmate_isAuthenticated', 'true');

      toast.success(txt.signupSuccess);
      
      // Reset form
      setFormData({
        name: '',
        email: '',
        phone: '',
        password: '',
        confirmPassword: ''
      });

      // Call success callback
      if (onSignupSuccess) {
        onSignupSuccess();
      }
    } catch (error: any) {
      console.error('Signup error:', error);
      
      const errorMessage = error.message || 'Signup failed';
      let displayMessage = errorMessage;
      
      // Handle common Firebase errors
      if (errorMessage.includes('email-already-in-use')) {
        displayMessage = language === 'ps' 
          ? 'دا بریښنالیک مخکې کارول شوی دی'
          : language === 'fa'
          ? 'این ایمیل قبلاً استفاده شده است'
          : 'This email is already in use';
      } else if (errorMessage.includes('weak-password')) {
        displayMessage = language === 'ps'
          ? 'پټنوم ډیر ضعیف دی'
          : language === 'fa'
          ? 'رمز عبور بسیار ضعیف است'
          : 'Password is too weak';
      } else if (errorMessage.includes('invalid-email')) {
        displayMessage = language === 'ps'
          ? 'بریښنالیک سم نه دی'
          : language === 'fa'
          ? 'ایمیل نامعتبر است'
          : 'Invalid email address';
      }
      
      toast.error(displayMessage);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-purple-50 to-pink-50 flex items-center justify-center p-4 relative overflow-hidden">
      {/* Animated Background Mesh */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden">
        <motion.div 
          animate={{
            scale: [1, 1.2, 1],
            rotate: [0, 90, 0],
          }}
          transition={{
            duration: 20,
            repeat: Infinity,
            ease: "linear"
          }}
          className="absolute -top-1/4 -left-1/4 w-1/2 h-1/2 bg-blue-400 rounded-full blur-3xl opacity-20" 
        />
        <motion.div 
          animate={{
            scale: [1, 1.3, 1],
            rotate: [0, -90, 0],
          }}
          transition={{
            duration: 25,
            repeat: Infinity,
            ease: "linear"
          }}
          className="absolute -bottom-1/4 -right-1/4 w-1/2 h-1/2 bg-purple-400 rounded-full blur-3xl opacity-20" 
        />
        <motion.div 
          animate={{
            scale: [1, 1.15, 1],
            x: [0, 50, 0],
            y: [0, 30, 0],
          }}
          transition={{
            duration: 15,
            repeat: Infinity,
            ease: "easeInOut"
          }}
          className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-1/3 h-1/3 bg-pink-400 rounded-full blur-3xl opacity-20" 
        />
      </div>

      <div className="w-full max-w-6xl relative z-10">
        <div className="grid md:grid-cols-2 gap-8 items-center">
          {/* Left Side - Features */}
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6 }}
            className="hidden md:block"
          >
            <div className="backdrop-blur-xl bg-white/30 rounded-3xl p-8 border border-white/50 shadow-2xl">
              {/* Logo & Title */}
              <div className="mb-8">
                <motion.div
                  animate={{
                    scale: [1, 1.1, 1]
                  }}
                  transition={{
                    duration: 2,
                    repeat: Infinity,
                    ease: "easeInOut"
                  }}
                  className="w-20 h-20 bg-gradient-to-br from-blue-600 via-purple-600 to-pink-600 rounded-3xl flex items-center justify-center mb-4 shadow-2xl"
                >
                  <Heart className="w-10 h-10 text-white" />
                </motion.div>
                <h1 className="text-4xl font-bold bg-gradient-to-r from-blue-600 via-purple-600 to-pink-600 bg-clip-text text-transparent mb-2">
                  HealMate
                </h1>
                <p className="text-gray-600">
                  {language === 'ps' 
                    ? 'ستاسو د روغتیا ملګری'
                    : language === 'fa'
                    ? 'همراه سلامتی شما'
                    : 'Your Health Companion'
                  }
                </p>
              </div>

              {/* Features */}
              <div className="space-y-4">
                {[
                  { icon: Stethoscope, text: txt.feature1, color: 'from-blue-500 to-cyan-600' },
                  { icon: Sparkles, text: txt.feature2, color: 'from-purple-500 to-indigo-600' },
                  { icon: Heart, text: txt.feature3, color: 'from-pink-500 to-rose-600' },
                  { icon: Shield, text: txt.feature4, color: 'from-green-500 to-emerald-600' }
                ].map((feature, index) => (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: 0.2 + index * 0.1 }}
                    className="flex items-center gap-4 p-4 rounded-2xl bg-white/50 border border-white/50 shadow-lg hover:shadow-xl transition-all"
                  >
                    <div className={`w-12 h-12 bg-gradient-to-br ${feature.color} rounded-xl flex items-center justify-center shadow-lg`}>
                      <feature.icon className="w-6 h-6 text-white" />
                    </div>
                    <p className="font-medium text-gray-700">{feature.text}</p>
                  </motion.div>
                ))}
              </div>

              {/* Trust Badge */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.8 }}
                className="mt-8 p-4 rounded-2xl bg-gradient-to-br from-green-50 to-emerald-50 border border-green-200"
              >
                <div className="flex items-center gap-3">
                  <Shield className="w-8 h-8 text-green-600" />
                  <div>
                    <p className="font-bold text-green-700">{txt.secureNote}</p>
                    <p className="text-sm text-green-600">
                      {language === 'ps' 
                        ? 'د 256-bit SSL encryption سره خوندي'
                        : language === 'fa'
                        ? 'ایمن با رمزگذاری SSL 256 بیتی'
                        : 'Secured with 256-bit SSL encryption'
                      }
                    </p>
                  </div>
                </div>
              </motion.div>
            </div>
          </motion.div>

          {/* Right Side - Signup Form */}
          <motion.div
            initial={{ opacity: 0, x: 50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6 }}
          >
            <div className="backdrop-blur-xl bg-white/70 rounded-3xl p-8 border border-white/50 shadow-2xl">
              {/* Header */}
              <div className="mb-8 text-center">
                <motion.div
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  transition={{ type: "spring", duration: 0.6 }}
                  className="inline-block mb-4"
                >
                  <div className="w-16 h-16 bg-gradient-to-br from-blue-600 to-purple-600 rounded-2xl flex items-center justify-center shadow-2xl">
                    <UserIcon className="w-8 h-8 text-white" />
                  </div>
                </motion.div>
                <h2 className="text-3xl font-bold text-gray-900 mb-2">
                  {txt.title}
                </h2>
                <p className="text-gray-600">
                  {txt.subtitle}
                </p>
              </div>

              {/* Form */}
              <form onSubmit={handleSignup} className="space-y-4">
                {/* Name Input */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    {txt.name} *
                  </label>
                  <div className="relative">
                    <UserIcon className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                    <Input
                      type="text"
                      value={formData.name}
                      onChange={(e) => {
                        setFormData({ ...formData, name: e.target.value });
                        if (errors.name) setErrors({ ...errors, name: '' });
                      }}
                      placeholder={txt.namePlaceholder}
                      className={`pl-10 ${errors.name ? 'border-red-500' : ''}`}
                      disabled={isLoading}
                    />
                  </div>
                  {errors.name && (
                    <motion.p
                      initial={{ opacity: 0, y: -10 }}
                      animate={{ opacity: 1, y: 0 }}
                      className="text-red-500 text-sm mt-1 flex items-center gap-1"
                    >
                      <AlertCircle className="w-4 h-4" />
                      {errors.name}
                    </motion.p>
                  )}
                </div>

                {/* Email Input */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    {txt.email} *
                  </label>
                  <div className="relative">
                    <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                    <Input
                      type="email"
                      value={formData.email}
                      onChange={(e) => {
                        setFormData({ ...formData, email: e.target.value });
                        if (errors.email) setErrors({ ...errors, email: '' });
                      }}
                      placeholder={txt.emailPlaceholder}
                      className={`pl-10 ${errors.email ? 'border-red-500' : ''}`}
                      disabled={isLoading}
                    />
                  </div>
                  {errors.email && (
                    <motion.p
                      initial={{ opacity: 0, y: -10 }}
                      animate={{ opacity: 1, y: 0 }}
                      className="text-red-500 text-sm mt-1 flex items-center gap-1"
                    >
                      <AlertCircle className="w-4 h-4" />
                      {errors.email}
                    </motion.p>
                  )}
                </div>

                {/* Phone Input */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    {txt.phone}
                  </label>
                  <div className="relative">
                    <Phone className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                    <Input
                      type="tel"
                      value={formData.phone}
                      onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                      placeholder={txt.phonePlaceholder}
                      className="pl-10"
                      disabled={isLoading}
                    />
                  </div>
                </div>

                {/* Password Input */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    {txt.password} *
                  </label>
                  <div className="relative">
                    <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                    <Input
                      type={showPassword ? 'text' : 'password'}
                      value={formData.password}
                      onChange={(e) => {
                        setFormData({ ...formData, password: e.target.value });
                        if (errors.password) setErrors({ ...errors, password: '' });
                      }}
                      placeholder={txt.passwordPlaceholder}
                      className={`pl-10 pr-10 ${errors.password ? 'border-red-500' : ''}`}
                      disabled={isLoading}
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600"
                    >
                      {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                    </button>
                  </div>
                  {errors.password && (
                    <motion.p
                      initial={{ opacity: 0, y: -10 }}
                      animate={{ opacity: 1, y: 0 }}
                      className="text-red-500 text-sm mt-1 flex items-center gap-1"
                    >
                      <AlertCircle className="w-4 h-4" />
                      {errors.password}
                    </motion.p>
                  )}
                </div>

                {/* Confirm Password Input */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    {txt.confirmPassword} *
                  </label>
                  <div className="relative">
                    <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                    <Input
                      type={showConfirmPassword ? 'text' : 'password'}
                      value={formData.confirmPassword}
                      onChange={(e) => {
                        setFormData({ ...formData, confirmPassword: e.target.value });
                        if (errors.confirmPassword) setErrors({ ...errors, confirmPassword: '' });
                      }}
                      placeholder={txt.confirmPasswordPlaceholder}
                      className={`pl-10 pr-10 ${errors.confirmPassword ? 'border-red-500' : ''}`}
                      disabled={isLoading}
                    />
                    <button
                      type="button"
                      onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600"
                    >
                      {showConfirmPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                    </button>
                  </div>
                  {errors.confirmPassword && (
                    <motion.p
                      initial={{ opacity: 0, y: -10 }}
                      animate={{ opacity: 1, y: 0 }}
                      className="text-red-500 text-sm mt-1 flex items-center gap-1"
                    >
                      <AlertCircle className="w-4 h-4" />
                      {errors.confirmPassword}
                    </motion.p>
                  )}
                </div>

                {/* Submit Button */}
                <motion.div
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                >
                  <Button
                    type="submit"
                    disabled={isLoading}
                    className="w-full bg-gradient-to-r from-blue-600 via-purple-600 to-pink-600 hover:from-blue-700 hover:via-purple-700 hover:to-pink-700 text-white py-3 rounded-xl font-bold shadow-xl border-0"
                  >
                    {isLoading ? (
                      <span className="flex items-center justify-center gap-2">
                        <motion.div
                          animate={{ rotate: 360 }}
                          transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
                        >
                          <CheckCircle2 className="w-5 h-5" />
                        </motion.div>
                        {txt.signingUp}
                      </span>
                    ) : (
                      <span className="flex items-center justify-center gap-2">
                        {txt.signup}
                        <ArrowRight className="w-5 h-5" />
                      </span>
                    )}
                  </Button>
                </motion.div>

                {/* Privacy Note */}
                <p className="text-xs text-gray-500 text-center mt-4">
                  {txt.privacyNote}
                </p>

                {/* Login Link */}
                <div className="text-center pt-4 border-t border-gray-200">
                  <p className="text-gray-600">
                    {txt.haveAccount}{' '}
                    <button
                      type="button"
                      onClick={onSwitchToLogin}
                      className="text-blue-600 hover:text-blue-700 font-bold"
                    >
                      {txt.login}
                    </button>
                  </p>
                </div>
              </form>
            </div>
          </motion.div>
        </div>
      </div>
    </div>
  );
}
