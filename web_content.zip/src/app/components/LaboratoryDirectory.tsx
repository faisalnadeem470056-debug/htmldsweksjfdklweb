import { useState, useEffect } from 'react';
import {
  Search, Star, MapPin, Phone, Calendar, ArrowLeft, TestTube, Award,
  Clock, Check, Filter, X, Heart, MessageCircle, Mail, Users,
  Shield, Crown, Briefcase, Activity, Plus, Edit2, Trash2
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { AdBanner } from './AdBanner';
import { ImageWithFallback } from './figma/ImageWithFallback';

interface LaboratoryDirectoryProps {
  language: 'ps' | 'fa' | 'en';
  onBack: () => void;
  isAdmin?: boolean;
  adminEmail?: string;
}

interface Laboratory {
  id: number;
  name: { ps: string; fa: string; en: string };
  type: { ps: string; fa: string; en: string };
  category: string;
  rating: number;
  reviews: number;
  location: { ps: string; fa: string; en: string };
  phone: string;
  available: boolean;
  verified: boolean;
  image: string;
  tests: number;
  priceRange: string;
  services: { ps: string[]; fa: string[]; en: string[] };
  workingHours: { ps: string; fa: string; en: string };
  about: { ps: string; fa: string; en: string };
  isPremium?: boolean;
}

const translations = {
  ps: {
    title: 'آزمایښتونه',
    subtitle: 'د معتبرو آزمایښتونو لابراتوارونه',
    search: 'د لابراتوار نوم یا ټسټ لټون...',
    allCategories: 'ټول کټګورۍ',
    filter: 'فلټر',
    sortBy: 'ترتیب کول',
    rating: 'ریټنګ',
    tests: 'ټسټونه',
    verified: 'تایید شوی',
    premium: 'پریمیم',
    available: 'شتون لري',
    unavailable: 'شتون نلري',
    viewDetails: 'تفصیل وګورئ',
    bookTest: 'ټسټ بک کړئ',
    call: 'زنګ ووهئ',
    location: 'موقعیت',
    workingHours: 'د کار وختونه',
    services: 'خدمتونه',
    priceRange: 'قیمت',
    reviews: 'بیاکتنې',
    about: 'په اړه',
    closeDetails: 'تړل',
    noResults: 'هیڅ پایله ونه موندل شوه',
    addNew: 'نوی اضافه کړئ',
    edit: 'تغیر',
    delete: 'حذف',
    categories: {
      blood: 'د وینې ټسټونه',
      urine: 'د ادرار ټسټونه',
      xray: 'ایکس رې',
      ultrasound: 'الټراسونډ',
      ct: 'سي ټي سکین',
      mri: 'ایم آر آی',
      ecg: 'ای سي جي',
      general: 'عمومي'
    }
  },
  fa: {
    title: 'آزمایشگاه',
    subtitle: 'آزمایشگاه‌های معتبر',
    search: 'نام آزمایشگاه یا تست را جستجو کنید...',
    allCategories: 'همه دسته‌ها',
    filter: 'فیلتر',
    sortBy: 'مرتب‌سازی',
    rating: 'امتیاز',
    tests: 'تست‌ها',
    verified: 'تایید شده',
    premium: 'پریمیم',
    available: 'موجود',
    unavailable: 'ناموجود',
    viewDetails: 'مشاهده جزئیات',
    bookTest: 'رزرو تست',
    call: 'تماس',
    location: 'موقعیت',
    workingHours: 'ساعات کاری',
    services: 'خدمات',
    priceRange: 'محدوده قیمت',
    reviews: 'نظرات',
    about: 'درباره',
    closeDetails: 'بستن',
    noResults: 'نتیجه‌ای یافت نشد',
    addNew: 'اضافه کردن جدید',
    edit: 'ویرایش',
    delete: 'حذف',
    categories: {
      blood: 'آزمایش خون',
      urine: 'آزمایش ادرار',
      xray: 'اشعه ایکس',
      ultrasound: 'سونوگرافی',
      ct: 'سی‌تی اسکن',
      mri: 'ام‌آر‌آی',
      ecg: 'نوار قلب',
      general: 'عمومی'
    }
  },
  en: {
    title: 'Laboratory',
    subtitle: 'Certified Medical Laboratories',
    search: 'Search lab name or test...',
    allCategories: 'All Categories',
    filter: 'Filter',
    sortBy: 'Sort By',
    rating: 'Rating',
    tests: 'Tests',
    verified: 'Verified',
    premium: 'Premium',
    available: 'Available',
    unavailable: 'Unavailable',
    viewDetails: 'View Details',
    bookTest: 'Book Test',
    call: 'Call',
    location: 'Location',
    workingHours: 'Working Hours',
    services: 'Services',
    priceRange: 'Price Range',
    reviews: 'Reviews',
    about: 'About',
    closeDetails: 'Close',
    noResults: 'No results found',
    addNew: 'Add New',
    edit: 'Edit',
    delete: 'Delete',
    categories: {
      blood: 'Blood Tests',
      urine: 'Urine Tests',
      xray: 'X-Ray',
      ultrasound: 'Ultrasound',
      ct: 'CT Scan',
      mri: 'MRI',
      ecg: 'ECG',
      general: 'General'
    }
  }
};

const initialLaboratories: Laboratory[] = [
  {
    id: 1,
    name: { ps: 'کابل ډایګنوستیک سنټر', fa: 'مرکز تشخیصی کابل', en: 'Kabul Diagnostic Center' },
    type: { ps: 'بشپړ آزمایښت', fa: 'آزمایشگاه کامل', en: 'Full Service Lab' },
    category: 'general',
    rating: 4.8,
    reviews: 156,
    location: { ps: 'شهر نو، کابل', fa: 'شهر نو، کابل', en: 'Shar-e-Naw, Kabul' },
    phone: '+93 700 123 456',
    available: true,
    verified: true,
    image: 'https://images.unsplash.com/photo-1579684385127-1ef15d508118?w=400',
    tests: 250,
    priceRange: '100-5000 AFN',
    services: {
      ps: ['د وینې ټسټونه', 'ایکس رې', 'الټراسونډ', 'سي ټي سکین'],
      fa: ['آزمایش خون', 'اشعه ایکس', 'سونوگرافی', 'سی‌تی اسکن'],
      en: ['Blood Tests', 'X-Ray', 'Ultrasound', 'CT Scan']
    },
    workingHours: { ps: '۸ سهار - ۸ شپه', fa: '۸ صبح - ۸ شب', en: '8 AM - 8 PM' },
    about: { 
      ps: 'د افغانستان تر ټولو پرمختللی آزمایښتونو لابراتوار، د عصري وسایلو او ماهر ټیم سره.',
      fa: 'پیشرفته‌ترین آزمایشگاه افغانستان با تجهیزات مدرن و تیم متخصص.',
      en: 'Most advanced laboratory in Afghanistan with modern equipment and expert team.'
    },
    isPremium: true
  },
  {
    id: 2,
    name: { ps: 'مزار شریف لابراتوار', fa: 'آزمایشگاه مزار شریف', en: 'Mazar-e-Sharif Laboratory' },
    type: { ps: 'د وینې ټسټونه', fa: 'آزمایش خون', en: 'Blood Testing' },
    category: 'blood',
    rating: 4.5,
    reviews: 89,
    location: { ps: 'مزار شریف', fa: 'مزار شریف', en: 'Mazar-e-Sharif' },
    phone: '+93 701 234 567',
    available: true,
    verified: true,
    image: 'https://images.unsplash.com/photo-1631815588090-d4bfec5b1ccb?w=400',
    tests: 120,
    priceRange: '50-2000 AFN',
    services: {
      ps: ['CBC', 'د وینې شکر', 'کولیسټرول', 'د ځګر فنکشن'],
      fa: ['CBC', 'قند خون', 'کلسترول', 'تست کبد'],
      en: ['CBC', 'Blood Sugar', 'Cholesterol', 'Liver Function']
    },
    workingHours: { ps: '۷ سهار - ۶ ماسپښین', fa: '۷ صبح - ۶ عصر', en: '7 AM - 6 PM' },
    about: {
      ps: 'د وینې ټسټونو کې مسلکي خدمتونه.',
      fa: 'خدمات حرفه‌ای در آزمایش خون.',
      en: 'Professional blood testing services.'
    },
    isPremium: false
  },
  {
    id: 3,
    name: { ps: 'هرات امیجنګ سنټر', fa: 'مرکز تصویربرداری هرات', en: 'Herat Imaging Center' },
    type: { ps: 'امیجنګ', fa: 'تصویربرداری', en: 'Imaging' },
    category: 'xray',
    rating: 4.7,
    reviews: 124,
    location: { ps: 'هرات ښار', fa: 'شهر هرات', en: 'Herat City' },
    phone: '+93 702 345 678',
    available: true,
    verified: true,
    image: 'https://images.unsplash.com/photo-1516549655169-df83a0774514?w=400',
    tests: 80,
    priceRange: '200-8000 AFN',
    services: {
      ps: ['ایکس رې', 'الټراسونډ', 'سي ټي سکین', 'ایم آر آی'],
      fa: ['اشعه ایکس', 'سونوگرافی', 'سی‌تی اسکن', 'ام‌آر‌آی'],
      en: ['X-Ray', 'Ultrasound', 'CT Scan', 'MRI']
    },
    workingHours: { ps: '۲۴ ساعته', fa: '۲۴ ساعته', en: '24 Hours' },
    about: {
      ps: 'د عصري امیجنګ تخنالوژۍ سره بشپړ خدمتونه.',
      fa: 'خدمات کامل با تکنولوژی تصویربرداری پیشرفته.',
      en: 'Complete services with advanced imaging technology.'
    },
    isPremium: true
  }
];

export function LaboratoryDirectory({ language, onBack, isAdmin, adminEmail }: LaboratoryDirectoryProps) {
  const [laboratories, setLaboratories] = useState<Laboratory[]>(initialLaboratories);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [sortBy, setSortBy] = useState<'rating' | 'tests'>('rating');
  const [selectedLab, setSelectedLab] = useState<Laboratory | null>(null);
  const [showFilters, setShowFilters] = useState(false);

  const t = translations[language];

  // Check if user is admin
  const isOwner = isAdmin && adminEmail === 'ibrahimkhaksar.it@gmail.com';

  const filteredLaboratories = laboratories
    .filter(lab => {
      const matchesSearch = 
        lab.name[language].toLowerCase().includes(searchQuery.toLowerCase()) ||
        lab.type[language].toLowerCase().includes(searchQuery.toLowerCase()) ||
        lab.location[language].toLowerCase().includes(searchQuery.toLowerCase());
      const matchesCategory = selectedCategory === 'all' || lab.category === selectedCategory;
      return matchesSearch && matchesCategory;
    })
    .sort((a, b) => {
      if (sortBy === 'rating') return b.rating - a.rating;
      return b.tests - a.tests;
    });

  const handleAddNew = () => {
    const newLab: Laboratory = {
      id: Date.now(),
      name: { ps: 'نوی لابراتوار', fa: 'آزمایشگاه جدید', en: 'New Laboratory' },
      type: { ps: 'عمومي', fa: 'عمومی', en: 'General' },
      category: 'general',
      rating: 0,
      reviews: 0,
      location: { ps: 'کابل', fa: 'کابل', en: 'Kabul' },
      phone: '+93 700 000 000',
      available: true,
      verified: false,
      image: 'https://images.unsplash.com/photo-1579684385127-1ef15d508118?w=400',
      tests: 0,
      priceRange: '100-1000 AFN',
      services: { ps: [], fa: [], en: [] },
      workingHours: { ps: '۸ سهار - ۶ ماسپښین', fa: '۸ صبح - ۶ عصر', en: '8 AM - 6 PM' },
      about: { ps: 'معلومات اضافه کړئ', fa: 'اطلاعات اضافه کنید', en: 'Add information' },
      isPremium: false
    };
    setLaboratories([...laboratories, newLab]);
    alert(language === 'ps' ? '✅ نوی لابراتوار اضافه شو!' : language === 'fa' ? '✅ آزمایشگاه جدید اضافه شد!' : '✅ New laboratory added!');
  };

  const handleDelete = (id: number) => {
    if (confirm(language === 'ps' ? 'ایا تاسو ډاډه یاست؟' : language === 'fa' ? 'آیا مطمئن هستید؟' : 'Are you sure?')) {
      setLaboratories(laboratories.filter(lab => lab.id !== id));
      setSelectedLab(null);
      alert(language === 'ps' ? '✅ حذف شو!' : language === 'fa' ? '✅ حذف شد!' : '✅ Deleted!');
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-50 via-purple-50 to-pink-50 pb-28 md:pb-8">
      {/* Header */}
      <div className="sticky top-0 z-40 bg-white/80 backdrop-blur-lg border-b border-purple-200">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between mb-4">
            <button
              onClick={onBack}
              className="flex items-center gap-2 text-gray-700 hover:text-purple-600 transition-colors"
            >
              <ArrowLeft className="w-5 h-5" />
              <span>{language === 'ps' ? 'شاته' : language === 'fa' ? 'بازگشت' : 'Back'}</span>
            </button>
            {isOwner && (
              <Button
                onClick={handleAddNew}
                className="bg-gradient-to-r from-purple-600 to-pink-600 text-white hover:shadow-lg"
              >
                <Plus className="w-4 h-4 mr-2" />
                {t.addNew}
              </Button>
            )}
          </div>

          <div className="text-center mb-4">
            <h1 className="text-3xl font-bold bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent mb-2">
              {t.title}
            </h1>
            <p className="text-gray-600">{t.subtitle}</p>
          </div>

          {/* Search */}
          <div className="relative">
            <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
            <Input
              type="text"
              placeholder={t.search}
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-12 pr-4 py-3 w-full rounded-2xl border-2 border-purple-200 focus:border-purple-400"
            />
          </div>

          {/* Filters */}
          <div className="flex items-center gap-2 mt-4 overflow-x-auto pb-2">
            <button
              onClick={() => setShowFilters(!showFilters)}
              className="flex items-center gap-2 px-4 py-2 bg-purple-100 text-purple-700 rounded-xl whitespace-nowrap"
            >
              <Filter className="w-4 h-4" />
              {t.filter}
            </button>
            
            {Object.entries(t.categories).map(([key, label]) => (
              <button
                key={key}
                onClick={() => setSelectedCategory(key)}
                className={`px-4 py-2 rounded-xl whitespace-nowrap transition-all ${
                  selectedCategory === key
                    ? 'bg-gradient-to-r from-purple-600 to-pink-600 text-white'
                    : 'bg-white text-gray-700 hover:bg-purple-50'
                }`}
              >
                {label}
              </button>
            ))}
            
            <button
              onClick={() => setSelectedCategory('all')}
              className={`px-4 py-2 rounded-xl whitespace-nowrap transition-all ${
                selectedCategory === 'all'
                  ? 'bg-gradient-to-r from-purple-600 to-pink-600 text-white'
                  : 'bg-white text-gray-700 hover:bg-purple-50'
              }`}
            >
              {t.allCategories}
            </button>
          </div>
        </div>
      </div>

      {/* AdBanner */}
      <div className="container mx-auto px-4 py-4">
        <AdBanner variant="horizontal" />
      </div>

      {/* Laboratories Grid */}
      <div className="container mx-auto px-4 pb-8">
        {filteredLaboratories.length === 0 ? (
          <div className="text-center py-12">
            <TestTube className="w-16 h-16 mx-auto text-gray-400 mb-4" />
            <p className="text-gray-600 text-lg">{t.noResults}</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredLaboratories.map((lab, index) => (
              <motion.div
                key={lab.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                className="bg-white rounded-3xl overflow-hidden shadow-lg hover:shadow-2xl transition-all group cursor-pointer"
                onClick={() => setSelectedLab(lab)}
              >
                {/* Image */}
                <div className="relative h-48 overflow-hidden">
                  <ImageWithFallback
                    src={lab.image}
                    alt={lab.name[language]}
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                  />
                  {lab.isPremium && (
                    <div className="absolute top-3 right-3 bg-gradient-to-r from-yellow-400 to-orange-500 text-white px-3 py-1 rounded-full text-xs font-bold flex items-center gap-1">
                      <Crown className="w-3 h-3" />
                      {t.premium}
                    </div>
                  )}
                  {lab.verified && (
                    <div className="absolute top-3 left-3 bg-blue-500 text-white px-3 py-1 rounded-full text-xs font-bold flex items-center gap-1">
                      <Shield className="w-3 h-3" />
                      {t.verified}
                    </div>
                  )}
                </div>

                {/* Content */}
                <div className="p-6">
                  <h3 className="text-xl font-bold text-gray-900 mb-2">{lab.name[language]}</h3>
                  <p className="text-purple-600 text-sm mb-3">{lab.type[language]}</p>

                  <div className="flex items-center gap-4 mb-3 text-sm">
                    <div className="flex items-center gap-1">
                      <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                      <span className="font-bold">{lab.rating}</span>
                      <span className="text-gray-500">({lab.reviews})</span>
                    </div>
                    <div className="flex items-center gap-1 text-gray-600">
                      <TestTube className="w-4 h-4" />
                      <span>{lab.tests} {t.tests}</span>
                    </div>
                  </div>

                  <div className="flex items-start gap-2 text-sm text-gray-600 mb-3">
                    <MapPin className="w-4 h-4 flex-shrink-0 mt-0.5" />
                    <span>{lab.location[language]}</span>
                  </div>

                  <div className="flex items-center gap-2 text-sm mb-4">
                    <Clock className="w-4 h-4 text-gray-500" />
                    <span className="text-gray-600">{lab.workingHours[language]}</span>
                  </div>

                  {/* Admin Actions */}
                  {isOwner && (
                    <div className="flex gap-2 mb-4">
                      <Button
                        onClick={(e) => {
                          e.stopPropagation();
                          alert(language === 'ps' ? 'د تغیر فیچر ډېر ژر!' : language === 'fa' ? 'ویرایش بزودی!' : 'Edit feature coming soon!');
                        }}
                        className="flex-1 bg-blue-500 text-white hover:bg-blue-600"
                      >
                        <Edit2 className="w-3 h-3 mr-1" />
                        {t.edit}
                      </Button>
                      <Button
                        onClick={(e) => {
                          e.stopPropagation();
                          handleDelete(lab.id);
                        }}
                        className="flex-1 bg-red-500 text-white hover:bg-red-600"
                      >
                        <Trash2 className="w-3 h-3 mr-1" />
                        {t.delete}
                      </Button>
                    </div>
                  )}

                  <div className="flex gap-2">
                    <Button
                      onClick={(e) => {
                        e.stopPropagation();
                        window.location.href = `tel:${lab.phone}`;
                      }}
                      className="flex-1 bg-gradient-to-r from-green-500 to-emerald-600 text-white"
                    >
                      <Phone className="w-4 h-4 mr-2" />
                      {t.call}
                    </Button>
                    <Button
                      onClick={(e) => {
                        e.stopPropagation();
                        setSelectedLab(lab);
                      }}
                      className="flex-1 bg-gradient-to-r from-purple-600 to-pink-600 text-white"
                    >
                      {t.viewDetails}
                    </Button>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        )}
      </div>

      {/* Details Modal */}
      <AnimatePresence>
        {selectedLab && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/70 backdrop-blur-sm z-50 flex items-center justify-center p-4 overflow-y-auto"
            onClick={() => setSelectedLab(null)}
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="bg-white rounded-3xl max-w-2xl w-full my-8"
              onClick={(e) => e.stopPropagation()}
            >
              {/* Modal Header */}
              <div className="relative h-64">
                <ImageWithFallback
                  src={selectedLab.image}
                  alt={selectedLab.name[language]}
                  className="w-full h-full object-cover"
                />
                <button
                  onClick={() => setSelectedLab(null)}
                  className="absolute top-4 right-4 bg-white/90 backdrop-blur-sm rounded-full p-2 hover:bg-white transition-colors"
                >
                  <X className="w-5 h-5" />
                </button>
                {selectedLab.isPremium && (
                  <div className="absolute top-4 left-4 bg-gradient-to-r from-yellow-400 to-orange-500 text-white px-4 py-2 rounded-full font-bold flex items-center gap-2">
                    <Crown className="w-4 h-4" />
                    {t.premium}
                  </div>
                )}
              </div>

              {/* Modal Content */}
              <div className="p-6">
                <h2 className="text-2xl font-bold text-gray-900 mb-2">{selectedLab.name[language]}</h2>
                <p className="text-purple-600 mb-4">{selectedLab.type[language]}</p>

                <div className="grid grid-cols-2 gap-4 mb-6">
                  <div className="flex items-center gap-2">
                    <Star className="w-5 h-5 fill-yellow-400 text-yellow-400" />
                    <span className="font-bold">{selectedLab.rating}</span>
                    <span className="text-gray-500">({selectedLab.reviews} {t.reviews})</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <TestTube className="w-5 h-5 text-purple-600" />
                    <span>{selectedLab.tests} {t.tests}</span>
                  </div>
                </div>

                <div className="space-y-4 mb-6">
                  <div className="flex items-start gap-3">
                    <MapPin className="w-5 h-5 text-gray-500 flex-shrink-0 mt-0.5" />
                    <div>
                      <p className="font-semibold text-gray-900">{t.location}</p>
                      <p className="text-gray-600">{selectedLab.location[language]}</p>
                    </div>
                  </div>

                  <div className="flex items-start gap-3">
                    <Phone className="w-5 h-5 text-gray-500 flex-shrink-0 mt-0.5" />
                    <div>
                      <p className="font-semibold text-gray-900">{language === 'ps' ? 'تلیفون' : language === 'fa' ? 'تلفن' : 'Phone'}</p>
                      <a href={`tel:${selectedLab.phone}`} className="text-purple-600 hover:underline">
                        {selectedLab.phone}
                      </a>
                    </div>
                  </div>

                  <div className="flex items-start gap-3">
                    <Clock className="w-5 h-5 text-gray-500 flex-shrink-0 mt-0.5" />
                    <div>
                      <p className="font-semibold text-gray-900">{t.workingHours}</p>
                      <p className="text-gray-600">{selectedLab.workingHours[language]}</p>
                    </div>
                  </div>

                  <div className="flex items-start gap-3">
                    <Activity className="w-5 h-5 text-gray-500 flex-shrink-0 mt-0.5" />
                    <div>
                      <p className="font-semibold text-gray-900">{t.priceRange}</p>
                      <p className="text-gray-600">{selectedLab.priceRange}</p>
                    </div>
                  </div>
                </div>

                {/* Services */}
                <div className="mb-6">
                  <h3 className="font-bold text-gray-900 mb-3 flex items-center gap-2">
                    <Briefcase className="w-5 h-5 text-purple-600" />
                    {t.services}
                  </h3>
                  <div className="flex flex-wrap gap-2">
                    {selectedLab.services[language].map((service, index) => (
                      <span
                        key={index}
                        className="px-3 py-1 bg-purple-100 text-purple-700 rounded-full text-sm"
                      >
                        {service}
                      </span>
                    ))}
                  </div>
                </div>

                {/* About */}
                <div className="mb-6">
                  <h3 className="font-bold text-gray-900 mb-2">{t.about}</h3>
                  <p className="text-gray-600 leading-relaxed">{selectedLab.about[language]}</p>
                </div>

                {/* Actions */}
                <div className="flex gap-3">
                  <Button
                    onClick={() => window.location.href = `tel:${selectedLab.phone}`}
                    className="flex-1 bg-gradient-to-r from-green-500 to-emerald-600 text-white py-3 text-lg"
                  >
                    <Phone className="w-5 h-5 mr-2" />
                    {t.call}
                  </Button>
                  <Button
                    onClick={() => alert(language === 'ps' ? 'بکنګ فیچر ډېر ژر!' : language === 'fa' ? 'رزرو بزودی!' : 'Booking coming soon!')}
                    className="flex-1 bg-gradient-to-r from-purple-600 to-pink-600 text-white py-3 text-lg"
                  >
                    <Calendar className="w-5 h-5 mr-2" />
                    {t.bookTest}
                  </Button>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
