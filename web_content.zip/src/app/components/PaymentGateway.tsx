import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  CreditCard, Smartphone, CheckCircle, XCircle, AlertCircle,
  Lock, ArrowLeft, DollarSign, Clock, Star, Zap, Shield, Mail, FileText
} from 'lucide-react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Card } from './ui/card';
import { ImageWithFallback } from './figma/ImageWithFallback';
import { PaymentProcessor, PaymentData } from '../utils/PaymentProcessor';

interface PaymentGatewayProps {
  language: 'ps' | 'fa' | 'en';
  plan: {
    name: string;
    price: number;
    duration: string;
    features: string[];
  };
  onBack: () => void;
  onSuccess: () => void;
}

export function PaymentGateway({ language, plan, onBack, onSuccess }: PaymentGatewayProps) {
  const [paymentStep, setPaymentStep] = useState<'method' | 'details' | 'processing' | 'success' | 'failed'>('method');
  const [paymentMethod, setPaymentMethod] = useState<'hesabpay' | 'card'>('hesabpay');
  const [paymentData, setPaymentData] = useState({
    customerName: '',
    customerEmail: '',
    phoneNumber: '',
    accountNumber: '',
    pin: '',
    transactionId: ''
  });

  const texts = {
    ps: {
      payment: 'پیسې ورکول',
      selectPaymentMethod: 'د پیسو ورکولو طریقه غوره کړئ',
      hesabPay: 'Hesab Pay',
      bankCard: 'بانکي کارت',
      phoneNumber: 'د موبایل نمبر',
      accountNumber: 'د حساب نمبر',
      pin: 'PIN کوډ',
      payNow: 'اوس پیسې ورکړه',
      processing: 'پروسس کیږي...',
      verifyingPayment: 'د پیسو تصدیق کیږي...',
      paymentSuccessful: 'پیسې په بریالیتوب سره ورکړل شوې!',
      paymentFailed: 'پیسې ورکول ناکام شول!',
      premiumActivated: 'Premium فعال شو!',
      tryAgain: 'بیا هڅه وکړه',
      backToPlans: 'پلانونو ته بیرته',
      orderSummary: 'د آرډر خلاصه',
      plan: 'پلان',
      duration: 'موده',
      total: 'ټولټال',
      securePayment: 'خوندي پیسې ورکول',
      encryptedConnection: 'رمز شوی اړیکه',
      moneyBackGuarantee: '۳۰ ورځې پیسې بیرته تضمین',
      enterPhone: 'خپل Hesab Pay نمبر دلته ولیکئ',
      enterAccount: 'خپل حساب نمبر دلته ولیکئ',
      enterPin: 'خپل PIN کوډ دلته ولیکئ',
      invalidPhone: 'غلط موبایل نمبر!',
      invalidAccount: 'غلط حساب نمبر!',
      invalidPin: 'غلط PIN کوډ!',
      paymentInstructions: 'د پیسو ورکولو لارښوونې',
      step1: '۱. خپل Hesab Pay اکاونټ ته ننوځئ',
      step2: '۲. خپل موبایل نمبر او PIN دلته ولیکئ',
      step3: '۳. د پیسو ورکولو تایید وکړئ',
      step4: '۴. ستاسو Premium سمدلاسه فعال کیږي',
      ownerReceives: 'پیسې بشپړ Dr. Ibrahim Khaksar ته رسیږي',
      transactionId: 'د لیږد ID',
      afn: 'افغانی',
      helpSupport: 'مرسته او ملاتړ',
      contactSupport: 'د مسلې په صورت کې ibrahimkhaksar.it@gmail.com سره اړیکه ونیسئ'
    },
    fa: {
      payment: 'پرداخت',
      selectPaymentMethod: 'روش پرداخت را انتخاب کنید',
      hesabPay: 'Hesab Pay',
      bankCard: 'کارت بانکی',
      phoneNumber: 'شماره موبایل',
      accountNumber: 'شماره حساب',
      pin: 'کد PIN',
      payNow: 'پرداخت کنید',
      processing: 'در حال پردازش...',
      verifyingPayment: 'تایید پرداخت...',
      paymentSuccessful: 'پرداخت موفقیت‌آمیز بود!',
      paymentFailed: 'پرداخت ناموفق بود!',
      premiumActivated: 'Premium فعال شد!',
      tryAgain: 'دوباره تلاش کنید',
      backToPlans: 'بازگشت به پلان‌ها',
      orderSummary: 'خلاصه سفارش',
      plan: 'پلان',
      duration: 'مدت',
      total: 'مجموع',
      securePayment: 'پرداخت امن',
      encryptedConnection: 'اتصال رمزگذاری شده',
      moneyBackGuarantee: 'ضمانت بازگشت پول ۳۰ روزه',
      enterPhone: 'شماره Hesab Pay خود را وارد کنید',
      enterAccount: 'شماره حساب خود را وارد کنید',
      enterPin: 'کد PIN خود را وارد کنید',
      invalidPhone: 'شماره موبایل نامعتبر!',
      invalidAccount: 'شماره حساب نامعتبر!',
      invalidPin: 'کد PIN نامعتبر!',
      paymentInstructions: 'دستورالعمل پرداخت',
      step1: '۱. وارد اکانت Hesab Pay خود شوید',
      step2: '۲. شماره موبایل و PIN خود را وارد کنید',
      step3: '۳. پرداخت را تایید کنید',
      step4: '۴. Premium شما فوراً فعال می‌شود',
      ownerReceives: 'پول مستقیماً به Dr. Ibrahim Khaksar می‌رسد',
      transactionId: 'شناسه تراکنش',
      afn: 'افغانی',
      helpSupport: 'راهنما و پشتیبانی',
      contactSupport: 'در صورت مشکل با ibrahimkhaksar.it@gmail.com تماس بگیرید'
    },
    en: {
      payment: 'Payment',
      selectPaymentMethod: 'Select Payment Method',
      hesabPay: 'Hesab Pay',
      bankCard: 'Bank Card',
      phoneNumber: 'Phone Number',
      accountNumber: 'Account Number',
      pin: 'PIN Code',
      payNow: 'Pay Now',
      processing: 'Processing...',
      verifyingPayment: 'Verifying Payment...',
      paymentSuccessful: 'Payment Successful!',
      paymentFailed: 'Payment Failed!',
      premiumActivated: 'Premium Activated!',
      tryAgain: 'Try Again',
      backToPlans: 'Back to Plans',
      orderSummary: 'Order Summary',
      plan: 'Plan',
      duration: 'Duration',
      total: 'Total',
      securePayment: 'Secure Payment',
      encryptedConnection: 'Encrypted Connection',
      moneyBackGuarantee: '30-Day Money Back Guarantee',
      enterPhone: 'Enter your Hesab Pay number',
      enterAccount: 'Enter your account number',
      enterPin: 'Enter your PIN code',
      invalidPhone: 'Invalid phone number!',
      invalidAccount: 'Invalid account number!',
      invalidPin: 'Invalid PIN code!',
      paymentInstructions: 'Payment Instructions',
      step1: '1. Login to your Hesab Pay account',
      step2: '2. Enter your phone number and PIN',
      step3: '3. Confirm the payment',
      step4: '4. Your Premium will be activated instantly',
      ownerReceives: 'Payment goes directly to Dr. Ibrahim Khaksar',
      transactionId: 'Transaction ID',
      afn: 'AFN',
      helpSupport: 'Help & Support',
      contactSupport: 'Contact ibrahimkhaksar.it@gmail.com for issues'
    }
  };

  const t = texts[language];

  // Validate phone number (Afghanistan format)
  const validatePhone = (phone: string): boolean => {
    // Afghanistan phone numbers: +93 followed by 9 digits
    const phoneRegex = /^(\+93|0)?[7][0-9]{8}$/;
    return phoneRegex.test(phone);
  };

  // Validate account number
  const validateAccount = (account: string): boolean => {
    return account.length >= 8 && /^[0-9]+$/.test(account);
  };

  // Validate PIN
  const validatePin = (pin: string): boolean => {
    return pin.length >= 4 && pin.length <= 6 && /^[0-9]+$/.test(pin);
  };

  // Handle Payment Process
  const processPayment = async () => {
    // Validation
    if (paymentMethod === 'hesabpay') {
      if (!validatePhone(paymentData.phoneNumber)) {
        alert(t.invalidPhone);
        return;
      }
      if (!validatePin(paymentData.pin)) {
        alert(t.invalidPin);
        return;
      }
    }

    if (!paymentData.customerName) {
      alert(language === 'ps' ? 'مهرباني وکړئ خپل نوم ولیکئ' : 
            language === 'fa' ? 'لطفاً نام خود را وارد کنید' : 
            'Please enter your name');
      return;
    }

    if (!paymentData.customerEmail) {
      alert(language === 'ps' ? 'مهرباني وکړئ خپل ایمیل ولیکئ' : 
            language === 'fa' ? 'لطفاً ایمیل خود را وارد کنید' : 
            'Please enter your email');
      return;
    }

    // Start processing
    setPaymentStep('processing');

    // Get current user info
    const userEmail = localStorage.getItem('healmate_userEmail') || paymentData.customerEmail;
    const userName = localStorage.getItem('healmate_userName') || paymentData.customerName;
    const userId = localStorage.getItem('healmate_userId') || 'user_' + Date.now();

    // Generate transaction ID
    const transactionId = 'HP' + Date.now() + Math.floor(Math.random() * 10000);
    setPaymentData({ ...paymentData, transactionId });

    // Create payment data for PaymentProcessor
    const paymentInfo: PaymentData = {
      transactionId,
      customerId: userId,
      customerName: userName,
      customerEmail: userEmail,
      customerPhone: paymentData.phoneNumber,
      amount: plan.price,
      currency: 'AFN',
      plan: plan.name,
      timestamp: Date.now(),
      status: 'pending',
      ownerPhone: '+93779494512',
      paymentMethod: 'hesab_pay'
    };

    // Process payment using PaymentProcessor
    const paymentSuccess = await PaymentProcessor.processPayment(paymentInfo);

    if (paymentSuccess) {
      // Activate Premium
      const users = JSON.parse(localStorage.getItem('healmate_users') || '[]');
      const updatedUsers = users.map((u: any) => {
        if (u.email === userEmail) {
          return {
            ...u,
            isPremium: true,
            premiumPlan: plan.name,
            premiumExpiry: calculateExpiryDate(plan.duration),
            transactionId: transactionId,
            paymentMethod: paymentMethod,
            paymentDate: new Date().toISOString()
          };
        }
        return u;
      });
      
      localStorage.setItem('healmate_users', JSON.stringify(updatedUsers));
      localStorage.setItem('healmate_isPremium', 'true');
      localStorage.setItem('healmate_premiumPlan', plan.name);
      localStorage.setItem('healmate_transactionId', transactionId);

      setPaymentStep('success');
      
      // Call success callback after 2 seconds
      setTimeout(() => {
        onSuccess();
      }, 2000);
    } else {
      setPaymentStep('failed');
    }
  };

  // Calculate expiry date based on duration
  const calculateExpiryDate = (duration: string): string => {
    const now = new Date();
    if (duration.includes('Month') || duration.includes('میاشت') || duration.includes('ماه')) {
      const months = parseInt(duration.match(/\d+/)?.[0] || '1');
      now.setMonth(now.getMonth() + months);
    } else if (duration.includes('Year') || duration.includes('کال') || duration.includes('سال')) {
      now.setFullYear(now.getFullYear() + 1);
    }
    return now.toISOString();
  };

  // Payment Method Selection
  const PaymentMethodScreen = () => (
    <div className="max-w-2xl mx-auto px-4 py-6">
      <Card className="bg-white rounded-3xl shadow-2xl border-0 overflow-hidden">
        <div className="p-6">
          <h2 className="text-2xl mb-6 text-center">{t.selectPaymentMethod}</h2>
          
          {/* Order Summary */}
          <div className="bg-gradient-to-br from-blue-50 to-purple-50 rounded-2xl p-6 mb-6">
            <p className="text-sm text-gray-600 mb-4">{t.orderSummary}</p>
            <div className="space-y-2">
              <div className="flex justify-between">
                <span className="text-gray-700">{t.plan}:</span>
                <span className="text-gray-900">{plan.name}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-700">{t.duration}:</span>
                <span className="text-gray-900">{plan.duration}</span>
              </div>
              <div className="border-t border-gray-300 my-3"></div>
              <div className="flex justify-between">
                <span className="text-lg text-gray-900">{t.total}:</span>
                <span className="text-2xl text-blue-600">{plan.price} {t.afn}</span>
              </div>
            </div>
          </div>

          {/* Payment Methods */}
          <div className="space-y-4 mb-6">
            {/* Hesab Pay */}
            <button
              onClick={() => setPaymentMethod('hesabpay')}
              className={`w-full p-6 rounded-2xl border-2 transition-all ${
                paymentMethod === 'hesabpay'
                  ? 'border-blue-500 bg-blue-50'
                  : 'border-gray-200 hover:border-gray-300'
              }`}
            >
              <div className="flex items-center gap-4">
                <div className={`w-12 h-12 rounded-full flex items-center justify-center ${
                  paymentMethod === 'hesabpay' ? 'bg-blue-600' : 'bg-gray-200'
                }`}>
                  <Smartphone className={`w-6 h-6 ${
                    paymentMethod === 'hesabpay' ? 'text-white' : 'text-gray-600'
                  }`} />
                </div>
                <div className="flex-1 text-left">
                  <p className="text-lg">{t.hesabPay}</p>
                  <p className="text-sm text-gray-500">
                    {language === 'ps' ? 'د افغانستان نمبر ۱ ډیجیټل پیسه' : 
                     language === 'fa' ? 'شماره ۱ پول دیجیتال افغانستان' : 
                     'Afghanistan\'s #1 Digital Money'}
                  </p>
                </div>
                {paymentMethod === 'hesabpay' && (
                  <CheckCircle className="w-6 h-6 text-blue-600" />
                )}
              </div>
            </button>

            {/* Bank Card - Coming Soon */}
            <div className="w-full p-6 rounded-2xl border-2 border-gray-200 bg-gray-50 opacity-50">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-full flex items-center justify-center bg-gray-300">
                  <CreditCard className="w-6 h-6 text-gray-600" />
                </div>
                <div className="flex-1 text-left">
                  <p className="text-lg text-gray-600">{t.bankCard}</p>
                  <p className="text-sm text-gray-500">
                    {language === 'ps' ? 'ډیر ژر راځي' : language === 'fa' ? 'به زودی' : 'Coming Soon'}
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* Security Badges */}
          <div className="grid grid-cols-3 gap-3 mb-6">
            <div className="flex flex-col items-center gap-2 p-3 bg-gray-50 rounded-xl">
              <Shield className="w-6 h-6 text-green-600" />
              <span className="text-xs text-center text-gray-600">{t.securePayment}</span>
            </div>
            <div className="flex flex-col items-center gap-2 p-3 bg-gray-50 rounded-xl">
              <Lock className="w-6 h-6 text-blue-600" />
              <span className="text-xs text-center text-gray-600">{t.encryptedConnection}</span>
            </div>
            <div className="flex flex-col items-center gap-2 p-3 bg-gray-50 rounded-xl">
              <CheckCircle className="w-6 h-6 text-purple-600" />
              <span className="text-xs text-center text-gray-600">{t.moneyBackGuarantee}</span>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex gap-3">
            <Button
              onClick={onBack}
              variant="outline"
              className="flex-1 rounded-xl py-6 border-2"
            >
              {t.backToPlans}
            </Button>
            <Button
              onClick={() => setPaymentStep('details')}
              className="flex-1 bg-gradient-to-r from-blue-600 to-indigo-600 text-white rounded-xl py-6"
            >
              {language === 'ps' ? 'دوام ورکړه' : language === 'fa' ? 'ادامه' : 'Continue'}
            </Button>
          </div>
        </div>
      </Card>
    </div>
  );

  // Payment Details Screen
  const PaymentDetailsScreen = () => (
    <div className="max-w-2xl mx-auto px-4 py-6">
      <Card className="bg-white rounded-3xl shadow-2xl border-0 overflow-hidden">
        <div className="p-6">
          <div className="flex items-center justify-center mb-6">
            <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center">
              <Smartphone className="w-8 h-8 text-blue-600" />
            </div>
          </div>
          
          <h2 className="text-2xl mb-2 text-center">{t.hesabPay}</h2>
          <p className="text-gray-600 text-center mb-6">{t.ownerReceives}</p>

          {/* Payment Instructions */}
          <div className="bg-blue-50 rounded-2xl p-6 mb-6">
            <p className="mb-3 text-blue-900">{t.paymentInstructions}</p>
            <div className="space-y-2 text-sm text-blue-800">
              <p>{t.step1}</p>
              <p>{t.step2}</p>
              <p>{t.step3}</p>
              <p>{t.step4}</p>
            </div>
          </div>

          {/* Payment Form */}
          <div className="space-y-4 mb-6">
            <div>
              <Label className="text-gray-700 mb-2">
                {language === 'ps' ? 'نوم' : language === 'fa' ? 'نام' : 'Name'}
              </Label>
              <Input
                type="text"
                value={paymentData.customerName}
                onChange={(e) => setPaymentData({ ...paymentData, customerName: e.target.value })}
                placeholder={language === 'ps' ? 'ستاسو بشپړ نوم' : language === 'fa' ? 'نام کامل شما' : 'Your full name'}
                className="rounded-xl border-2 border-gray-200 focus:border-blue-500 py-4"
                autoComplete="name"
                inputMode="text"
                enterKeyHint="next"
                autoFocus={false}
                style={{ fontSize: '16px' }}
              />
            </div>

            <div>
              <Label className="text-gray-700 mb-2">
                {language === 'ps' ? 'ایمیل' : language === 'fa' ? 'ایمیل' : 'Email'}
              </Label>
              <Input
                type="email"
                value={paymentData.customerEmail}
                onChange={(e) => setPaymentData({ ...paymentData, customerEmail: e.target.value })}
                placeholder={language === 'ps' ? 'name@example.com' : language === 'fa' ? 'name@example.com' : 'name@example.com'}
                className="rounded-xl border-2 border-gray-200 focus:border-blue-500 py-4"
                autoComplete="email"
                inputMode="email"
                enterKeyHint="next"
                autoFocus={false}
                style={{ fontSize: '16px' }}
              />
            </div>

            <div>
              <Label className="text-gray-700 mb-2">{t.phoneNumber}</Label>
              <div className="flex gap-2">
                <div className="px-4 py-3 border-2 border-gray-200 rounded-xl bg-gray-50 text-gray-700">
                  +93
                </div>
                <Input
                  type="tel"
                  value={paymentData.phoneNumber}
                  onChange={(e) => setPaymentData({ ...paymentData, phoneNumber: e.target.value })}
                  placeholder="700 000 000"
                  className="flex-1 rounded-xl border-2 border-gray-200 focus:border-blue-500 py-4"
                  maxLength={9}
                  autoComplete="tel"
                  inputMode="tel"
                  enterKeyHint="next"
                  autoFocus={false}
                  style={{ fontSize: '16px' }}
                />
              </div>
            </div>

            <div>
              <Label className="text-gray-700 mb-2">{t.pin}</Label>
              <Input
                type="password"
                value={paymentData.pin}
                onChange={(e) => setPaymentData({ ...paymentData, pin: e.target.value })}
                placeholder="••••"
                className="rounded-xl border-2 border-gray-200 focus:border-blue-500 py-4"
                maxLength={6}
                autoComplete="off"
                inputMode="numeric"
                enterKeyHint="done"
                autoFocus={false}
                style={{ fontSize: '16px' }}
              />
            </div>
          </div>

          {/* Amount Display */}
          <div className="bg-gradient-to-r from-blue-600 to-indigo-600 rounded-2xl p-6 text-white mb-6">
            <div className="flex items-center justify-between">
              <span className="text-lg">{t.total}</span>
              <span className="text-3xl">{plan.price} {t.afn}</span>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex gap-3">
            <Button
              onClick={() => setPaymentStep('method')}
              variant="outline"
              className="flex-1 rounded-xl py-6 border-2"
            >
              <ArrowLeft className="w-5 h-5 mr-2" />
              {language === 'ps' ? 'بیرته' : language === 'fa' ? 'بازگشت' : 'Back'}
            </Button>
            <Button
              onClick={processPayment}
              className="flex-1 bg-gradient-to-r from-green-600 to-emerald-600 text-white rounded-xl py-6"
            >
              <DollarSign className="w-5 h-5 mr-2" />
              {t.payNow}
            </Button>
          </div>

          {/* Support */}
          <div className="mt-6 text-center">
            <p className="text-sm text-gray-500">{t.helpSupport}</p>
            <p className="text-sm text-blue-600">ibrahimkhaksar.it@gmail.com</p>
          </div>
        </div>
      </Card>
    </div>
  );

  // Processing Screen
  const ProcessingScreen = () => (
    <div className="max-w-2xl mx-auto px-4 py-6">
      <Card className="bg-white rounded-3xl shadow-2xl border-0 overflow-hidden">
        <div className="p-12 text-center">
          <motion.div
            animate={{ rotate: 360 }}
            transition={{ duration: 2, repeat: Infinity, ease: 'linear' }}
            className="w-24 h-24 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-6"
          >
            <Clock className="w-12 h-12 text-blue-600" />
          </motion.div>
          
          <h2 className="text-2xl mb-3">{t.processing}</h2>
          <p className="text-gray-600 mb-6">{t.verifyingPayment}</p>
          
          <div className="flex items-center justify-center gap-2">
            <motion.div
              animate={{ scale: [1, 1.2, 1] }}
              transition={{ duration: 1, repeat: Infinity }}
              className="w-3 h-3 bg-blue-600 rounded-full"
            />
            <motion.div
              animate={{ scale: [1, 1.2, 1] }}
              transition={{ duration: 1, repeat: Infinity, delay: 0.2 }}
              className="w-3 h-3 bg-blue-600 rounded-full"
            />
            <motion.div
              animate={{ scale: [1, 1.2, 1] }}
              transition={{ duration: 1, repeat: Infinity, delay: 0.4 }}
              className="w-3 h-3 bg-blue-600 rounded-full"
            />
          </div>
        </div>
      </Card>
    </div>
  );

  // Success Screen
  const SuccessScreen = () => (
    <div className="max-w-2xl mx-auto px-4 py-6">
      <Card className="bg-white rounded-3xl shadow-2xl border-0 overflow-hidden">
        <div className="p-12 text-center">
          <motion.div
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ duration: 0.5, type: 'spring' }}
            className="w-24 h-24 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-6"
          >
            <CheckCircle className="w-12 h-12 text-green-600" />
          </motion.div>
          
          <h2 className="text-2xl mb-3 text-green-600">{t.paymentSuccessful}</h2>
          <p className="text-xl mb-6">{t.premiumActivated}</p>
          
          <div className="bg-gray-50 rounded-2xl p-6 mb-6">
            <p className="text-sm text-gray-600 mb-2">{t.transactionId}</p>
            <p className="text-lg text-gray-900 font-mono">{paymentData.transactionId}</p>
          </div>

          <div className="flex items-center justify-center gap-2 text-sm text-gray-600 mb-6">
            <CheckCircle className="w-4 h-4 text-green-600" />
            <span>{t.ownerReceives}</span>
          </div>
          
          <Button
            onClick={onSuccess}
            className="bg-gradient-to-r from-blue-600 to-indigo-600 text-white rounded-xl py-6 px-8"
          >
            <Star className="w-5 h-5 mr-2" />
            {language === 'ps' ? 'Premium وګورئ' : language === 'fa' ? 'مشاهده Premium' : 'View Premium'}
          </Button>
        </div>
      </Card>
    </div>
  );

  // Failed Screen
  const FailedScreen = () => (
    <div className="max-w-2xl mx-auto px-4 py-6">
      <Card className="bg-white rounded-3xl shadow-2xl border-0 overflow-hidden">
        <div className="p-12 text-center">
          <motion.div
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ duration: 0.5, type: 'spring' }}
            className="w-24 h-24 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-6"
          >
            <XCircle className="w-12 h-12 text-red-600" />
          </motion.div>
          
          <h2 className="text-2xl mb-3 text-red-600">{t.paymentFailed}</h2>
          <p className="text-gray-600 mb-6">
            {language === 'ps' ? 'د پیسو ورکولو په وخت کې مسله رامنځته شوه. مهرباني وکړئ بیا هڅه وکړئ.' : 
             language === 'fa' ? 'در هنگام پرداخت مشکلی پیش آمد. لطفاً دوباره تلاش کنید.' : 
             'There was an issue processing your payment. Please try again.'}
          </p>
          
          <div className="bg-yellow-50 border-2 border-yellow-200 rounded-2xl p-4 mb-6">
            <div className="flex items-start gap-3">
              <AlertCircle className="w-5 h-5 text-yellow-600 mt-0.5" />
              <div className="text-left text-sm text-yellow-800">
                <p>{t.contactSupport}</p>
              </div>
            </div>
          </div>
          
          <div className="flex gap-3">
            <Button
              onClick={onBack}
              variant="outline"
              className="flex-1 rounded-xl py-6 border-2"
            >
              {t.backToPlans}
            </Button>
            <Button
              onClick={() => setPaymentStep('details')}
              className="flex-1 bg-gradient-to-r from-blue-600 to-indigo-600 text-white rounded-xl py-6"
            >
              {t.tryAgain}
            </Button>
          </div>
        </div>
      </Card>
    </div>
  );

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 via-blue-50 to-purple-50 overflow-y-auto pb-24 absolute inset-0" style={{ WebkitUserSelect: 'none', WebkitTouchCallout: 'none' }}>
      {/* Header */}
      <div className="sticky top-0 z-40 bg-white/90 backdrop-blur-lg border-b border-gray-200 shadow-sm">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center gap-4">
            <Button
              variant="ghost"
              size="icon"
              onClick={paymentStep === 'success' ? onSuccess : onBack}
              className="rounded-full"
            >
              <ArrowLeft className="w-5 h-5" />
            </Button>
            <h1 className="text-xl">{t.payment}</h1>
          </div>
        </div>
      </div>

      {/* Content */}
      <AnimatePresence mode="wait">
        <motion.div
          key={paymentStep}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -20 }}
          transition={{ duration: 0.3 }}
        >
          {paymentStep === 'method' && <PaymentMethodScreen />}
          {paymentStep === 'details' && <PaymentDetailsScreen />}
          {paymentStep === 'processing' && <ProcessingScreen />}
          {paymentStep === 'success' && <SuccessScreen />}
          {paymentStep === 'failed' && <FailedScreen />}
        </motion.div>
      </AnimatePresence>
    </div>
  );
}