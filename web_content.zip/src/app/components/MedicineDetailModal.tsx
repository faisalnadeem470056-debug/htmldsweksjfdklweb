import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "./ui/dialog";
import { Badge } from "./ui/badge";
import { Button } from "./ui/button";
import { 
  Pill, 
  AlertTriangle, 
  Clock, 
  Droplets,
  Thermometer,
  Info,
  CheckCircle,
  XCircle,
  Heart,
  Baby,
  Activity,
  Syringe,
  ShieldAlert,
  Package
} from "lucide-react";
import { Separator } from "./ui/separator";

interface Medicine {
  id: number;
  name: string;
  nameDari: string;
  genericName: string;
  category: string;
  categoryDari: string;
  manufacturer: string;
  form: string;
  formDari: string;
  strength: string;
  price: string;
  inStock: boolean;
}

interface MedicineDetailModalProps {
  medicine: Medicine | null;
  open: boolean;
  onClose: () => void;
}

const medicineDetails: { [key: string]: any } = {
  "Paracetamol": {
    description: "Paracetamol is a widely used over-the-counter pain reliever and fever reducer. It works by blocking the production of certain chemicals in the brain that signal pain and cause fever.",
    descriptionDari: "پاراسیتامول یو پراخ کارول شوی د درد کموونکی او د تبې کموونکی دوا دی. دا د دماغ په داخل کې د ځانګړو کیمیکالونو تولید مخنیوی کوي چې د درد نښه کوي او تبه رامنځته کوي.",
    uses: [
      "Pain relief (headaches, toothaches, muscle aches)",
      "Fever reduction",
      "Cold and flu symptoms",
      "Post-operative pain",
      "Arthritis pain management"
    ],
    usesDari: [
      "د درد کموونه (د سر درد، د غاښونو درد، د عضلاتو درد)",
      "د تبې کموونه",
      "د زکام او انفلونزا علایم",
      "د عملیاتو وروسته درد",
      "د ګاټو د درد مدیریت"
    ],
    dosage: {
      adults: "500-1000mg every 4-6 hours, maximum 4000mg per day",
      children: "10-15mg/kg every 4-6 hours, consult pediatrician",
      elderly: "Same as adults, but start with lower doses"
    },
    dosageDari: {
      adults: "۵۰۰-۱۰۰۰ ملی ګرام هر ۴-۶ ساعته، په ورځ کې تر ۴۰۰۰ ملی ګرام",
      children: "۱۰-۱۵ ملی ګرام/کیلوګرام هر ۴-۶ ساعته، د ماشوم د ډاکټر سره مشوره وکړئ",
      elderly: "د لویانو په څیر، خو د لږې مقدار سره پیل وکړئ"
    },
    sideEffects: [
      "Nausea (rare)",
      "Skin rash or allergic reactions (rare)",
      "Liver damage with overdose",
      "Blood disorders (very rare)"
    ],
    sideEffectsDari: [
      "زړه بدوالی (نادر)",
      "د پوستکي خارښت یا الرجي غبرګون (نادر)",
      "د ډیر مقدار سره د ځیګر زیان",
      "د وینې اختلالات (خورا نادر)"
    ],
    warnings: [
      "Do not exceed recommended dosage",
      "Avoid alcohol consumption",
      "Consult doctor if you have liver disease",
      "Not suitable for severe liver problems",
      "Check for paracetamol in other medications to avoid overdose"
    ],
    warningsDari: [
      "د سپارښتل شوي مقدار څخه تیر نه شئ",
      "د الکول څښلو څخه ډډه وکړئ",
      "که د ځیګر ناروغي لرئ د ډاکټر سره مشوره وکړئ",
      "د ځیګر د جدي ستونزو لپاره مناسب نه دی",
      "د نورو درملو کې د پاراسیتامول شتون وګورئ چې د ډیر مقدار څخه ډډه وکړئ"
    ],
    pregnancy: "Category B - Generally safe during pregnancy when used as directed",
    pregnancyDari: "کټګوري B - په عمومي توګه د امیندوارۍ پر مهال د لارښودونو له مخې خوندي دی",
    breastfeeding: "Safe - Small amounts pass into breast milk",
    breastfeedingDari: "خوندي - لږ مقدار د شيدو څخه تیریږي",
    storage: "Store at room temperature (15-30°C), away from moisture and heat",
    storageDari: "د خونې په تودوخه (۱۵-۳۰ درجې) کې وساتئ، له لندبل او تودوخې لرې"
  },
  "Amoxicillin": {
    description: "Amoxicillin is a penicillin-type antibiotic used to treat bacterial infections. It works by stopping the growth of bacteria and is commonly prescribed for various infections.",
    descriptionDari: "اموکسیسیلین د پنسلین ډول انټي بیوټیک دی چې د بکتریایي انتاناتو درملنې لپاره کارول کیږي. دا د بکتریا د ودې مخنیوی کوي.",
    uses: [
      "Respiratory tract infections",
      "Ear infections (otitis media)",
      "Urinary tract infections",
      "Skin and soft tissue infections",
      "Dental infections",
      "H. pylori eradication"
    ],
    usesDari: [
      "د تنفسي لارو انتانات",
      "د غوږ انتانات",
      "د ادرار د لارو انتانات",
      "د پوستکي او نرم نسجونو انتانات",
      "د غاښونو انتانات",
      "د H. pylori له منځه وړل"
    ],
    dosage: {
      adults: "250-500mg three times daily or 500-875mg twice daily",
      children: "20-50mg/kg/day divided into 2-3 doses",
      severe: "Up to 3g daily in divided doses for severe infections"
    },
    dosageDari: {
      adults: "۲۵۰-۵۰۰ ملی ګرام ورځې کې درې ځله یا ۵۰۰-۸۷۵ ملی ګرام ورځې کې دوه ځله",
      children: "۲۰-۵۰ ملی ګرام/کیلوګرام/ورځ په ۲-۳ برخو کې ویشل شوی",
      severe: "د جدي انتاناتو لپاره تر ۳ ګرام پورې په ورځ کې په برخو کې ویشل شوی"
    },
    sideEffects: [
      "Diarrhea",
      "Nausea and vomiting",
      "Skin rash",
      "Allergic reactions (rare but serious)",
      "Yeast infections"
    ],
    sideEffectsDari: [
      "نس ګیری",
      "زړه بدوالی او کانګې",
      "د پوستکي خارښت",
      "الرجي غبرګون (نادر خو جدي)",
      "د خمیرې انتانات"
    ],
    warnings: [
      "Complete full course even if feeling better",
      "Inform doctor of any allergies, especially to penicillin",
      "May reduce effectiveness of birth control pills",
      "Not for viral infections like cold or flu",
      "Can cause severe allergic reactions - seek immediate help if difficulty breathing"
    ],
    warningsDari: [
      "بشپړ کورس بشپړ کړئ که څه هم ښه احساسوئ",
      "ډاکټر ته د هر ډول الرجي خبر ورکړئ، په ځانګړې توګه د پنسلین",
      "د زیږون د کنټرول ګولیو اغیزمنتیا کمولی شي",
      "د ویروسي انتاناتو لکه زکام یا انفلونزا لپاره نه دی",
      "کولی شي جدي الرجي غبرګون رامنځته کړي - که د تنفس ستونزې ولرئ سمدستي مرسته وغواړئ"
    ],
    pregnancy: "Category B - Generally considered safe during pregnancy",
    pregnancyDari: "کټګوري B - په عمومي توګه د امیندوارۍ پر مهال خوندي ګڼل کیږي",
    breastfeeding: "Safe - Low levels pass into breast milk",
    breastfeedingDari: "خوندي - د لږې کچې څخه د شيدو څخه تیریږي",
    storage: "Store at room temperature, protect from moisture",
    storageDari: "د خونې په تودوخه کې وساتئ، له لندبل څخه محافظت وکړئ"
  },
  "Ibuprofen": {
    description: "Ibuprofen is a nonsteroidal anti-inflammatory drug (NSAID) used to reduce pain, fever, and inflammation. It works by blocking the production of prostaglandins.",
    descriptionDari: "ایبوپروفین یو غیر سټیرویډي ضد التهابي دوا دی چې د درد، تبې او التهاب کمولو لپاره کارول کیږي.",
    uses: [
      "Pain relief (mild to moderate)",
      "Fever reduction",
      "Inflammation from arthritis",
      "Menstrual cramps",
      "Headaches and migraines",
      "Muscle and joint pain"
    ],
    usesDari: [
      "د درد کموونه (معتدل تر معتدل)",
      "د تبې کموونه",
      "د ګاټو څخه التهاب",
      "د میاشتنۍ درد",
      "د سر درد او میګرین",
      "د عضلاتو او ګډوډونو درد"
    ],
    dosage: {
      adults: "200-400mg every 4-6 hours, maximum 1200mg per day (OTC) or 3200mg (prescription)",
      children: "5-10mg/kg every 6-8 hours, consult pediatrician",
      elderly: "Start with lowest dose, may need reduced doses"
    },
    dosageDari: {
      adults: "۲۰۰-۴۰۰ ملی ګرام هر ۴-۶ ساعته، تر ۱۲۰۰ ملی ګرام پورې په ورځ کې",
      children: "۵-۱۰ ملی ګرام/کیلوګرام هر ۶-۸ ساعته، د ماشوم د ډاکټر سره مشوره وکړئ",
      elderly: "د ټیټې مقدار سره پیل وکړئ، ښایي کم مقدار ته اړتیا ولري"
    },
    sideEffects: [
      "Stomach upset or pain",
      "Heartburn",
      "Nausea",
      "Dizziness",
      "Increased risk of stomach ulcers and bleeding"
    ],
    sideEffectsDari: [
      "د معدې ناراحتي یا درد",
      "د زړه سوځیدنه",
      "زړه بدوالی",
      "سر چکر",
      "د معدې زخمونو او وینې خطر زیاتوالی"
    ],
    warnings: [
      "Take with food or milk to reduce stomach upset",
      "Avoid if you have history of stomach ulcers",
      "May increase risk of heart attack or stroke with long-term use",
      "Avoid during last trimester of pregnancy",
      "Can interact with blood thinners and other medications"
    ],
    warningsDari: [
      "د خوراک یا شيدو سره واخلئ چې د معدې ناراحتي کم کړي",
      "که د معدې زخمونو تاریخچه لرئ ډډه وکړئ",
      "د اوږدې مودې کارونې سره د زړه د حملې یا سټروک خطر زیاتولی شي",
      "د امیندوارۍ د وروستۍ درې میاشتو په جریان کې ډډه وکړئ",
      "کولی شي د وینې پتلی کوونکو او نورو درملو سره تعامل وکړي"
    ],
    pregnancy: "Category C/D - Avoid in third trimester",
    pregnancyDari: "کټګوري C/D - په دریمه میاشت کې ډډه وکړئ",
    breastfeeding: "Generally safe - Small amounts in breast milk",
    breastfeedingDari: "په عمومي توګه خوندي - د شيدو کې لږ مقدار",
    storage: "Store at room temperature, away from moisture and heat",
    storageDari: "د خونې په تودوخه کې وساتئ، له لندبل او تودوخې لرې"
  }
};

export function MedicineDetailModal({ medicine, open, onClose }: MedicineDetailModalProps) {
  if (!medicine) return null;

  const details = medicineDetails[medicine.name] || medicineDetails["Paracetamol"];

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <div className="flex items-start gap-4 mb-4">
            <div className="relative">
              <div className="absolute inset-0 bg-gradient-to-r from-emerald-500 to-teal-600 rounded-2xl blur-lg opacity-30"></div>
              <div className="relative w-20 h-20 bg-gradient-to-br from-emerald-500 to-teal-600 rounded-2xl flex items-center justify-center shadow-lg">
                <Pill className="w-10 h-10 text-white" />
              </div>
            </div>
            <div className="flex-1">
              <DialogTitle className="text-2xl mb-1">{medicine.name}</DialogTitle>
              <DialogDescription className="text-lg text-emerald-600">
                {medicine.nameDari} - {medicine.genericName}
              </DialogDescription>
              <p className="text-lg text-emerald-600 mb-2">{medicine.nameDari}</p>
              <div className="flex flex-wrap gap-2 mb-2">
                <Badge className="bg-gradient-to-r from-blue-500 to-cyan-600 text-white">
                  {medicine.genericName}
                </Badge>
                <Badge variant="outline" className="text-emerald-600 border-emerald-300">
                  {medicine.category}
                </Badge>
                <Badge variant="outline" className="text-gray-600 border-gray-300">
                  {medicine.form} - {medicine.strength}
                </Badge>
              </div>
              <div className="flex items-center gap-4 text-sm">
                <span className="text-gray-600">Price: <span className="text-emerald-600">{medicine.price}</span></span>
                <Badge className={medicine.inStock ? "bg-green-100 text-green-700" : "bg-red-100 text-red-700"}>
                  {medicine.inStock ? "In Stock" : "Out of Stock"}
                </Badge>
              </div>
            </div>
          </div>
        </DialogHeader>

        <div className="space-y-6 mt-6">
          {/* Description */}
          <div>
            <div className="flex items-center gap-2 mb-3">
              <Info className="w-5 h-5 text-emerald-600" />
              <h3 className="text-lg">Description | توضیحات</h3>
            </div>
            <p className="text-sm text-gray-700 leading-relaxed mb-2">{details.description}</p>
            <p className="text-sm text-gray-600 leading-relaxed">{details.descriptionDari}</p>
          </div>

          <Separator />

          {/* Uses */}
          <div>
            <div className="flex items-center gap-2 mb-3">
              <CheckCircle className="w-5 h-5 text-blue-600" />
              <h3 className="text-lg">Uses | استعمالات</h3>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
              {details.uses.map((use: string, index: number) => (
                <div key={index} className="flex items-start gap-2 p-3 bg-blue-50 rounded-lg">
                  <Activity className="w-4 h-4 text-blue-600 mt-0.5 flex-shrink-0" />
                  <div>
                    <p className="text-sm text-gray-800">{use}</p>
                    <p className="text-sm text-blue-700">{details.usesDari[index]}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <Separator />

          {/* Dosage */}
          <div>
            <div className="flex items-center gap-2 mb-3">
              <Syringe className="w-5 h-5 text-purple-600" />
              <h3 className="text-lg">Dosage | مقدار</h3>
            </div>
            <div className="space-y-3">
              <div className="p-4 bg-purple-50 rounded-lg">
                <div className="flex items-center gap-2 mb-2">
                  <Activity className="w-4 h-4 text-purple-600" />
                  <h4 className="text-sm">Adults | لویان</h4>
                </div>
                <p className="text-sm text-gray-800">{details.dosage.adults}</p>
                <p className="text-sm text-purple-700">{details.dosageDari.adults}</p>
              </div>
              <div className="p-4 bg-pink-50 rounded-lg">
                <div className="flex items-center gap-2 mb-2">
                  <Baby className="w-4 h-4 text-pink-600" />
                  <h4 className="text-sm">Children | ماشومان</h4>
                </div>
                <p className="text-sm text-gray-800">{details.dosage.children}</p>
                <p className="text-sm text-pink-700">{details.dosageDari.children}</p>
              </div>
              {details.dosage.elderly && (
                <div className="p-4 bg-indigo-50 rounded-lg">
                  <div className="flex items-center gap-2 mb-2">
                    <Clock className="w-4 h-4 text-indigo-600" />
                    <h4 className="text-sm">Elderly | زاړه</h4>
                  </div>
                  <p className="text-sm text-gray-800">{details.dosage.elderly}</p>
                  <p className="text-sm text-indigo-700">{details.dosageDari.elderly}</p>
                </div>
              )}
            </div>
          </div>

          <Separator />

          {/* Side Effects */}
          <div>
            <div className="flex items-center gap-2 mb-3">
              <XCircle className="w-5 h-5 text-orange-600" />
              <h3 className="text-lg">Side Effects | ضمني اغیزې</h3>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
              {details.sideEffects.map((effect: string, index: number) => (
                <div key={index} className="flex items-start gap-2 p-3 bg-orange-50 rounded-lg">
                  <AlertTriangle className="w-4 h-4 text-orange-600 mt-0.5 flex-shrink-0" />
                  <div>
                    <p className="text-sm text-gray-800">{effect}</p>
                    <p className="text-sm text-orange-700">{details.sideEffectsDari[index]}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <Separator />

          {/* Warnings */}
          <div>
            <div className="flex items-center gap-2 mb-3">
              <ShieldAlert className="w-5 h-5 text-red-600" />
              <h3 className="text-lg">Warnings | خبرداری</h3>
            </div>
            <div className="space-y-2">
              {details.warnings.map((warning: string, index: number) => (
                <div key={index} className="flex items-start gap-2 p-3 bg-red-50 border border-red-200 rounded-lg">
                  <AlertTriangle className="w-4 h-4 text-red-600 mt-0.5 flex-shrink-0" />
                  <div>
                    <p className="text-sm text-gray-800">{warning}</p>
                    <p className="text-sm text-red-700">{details.warningsDari[index]}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <Separator />

          {/* Pregnancy & Breastfeeding */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="p-4 bg-gradient-to-br from-pink-50 to-rose-50 rounded-lg border border-pink-200">
              <div className="flex items-center gap-2 mb-2">
                <Heart className="w-5 h-5 text-pink-600" />
                <h4 className="text-sm">Pregnancy | امیندواری</h4>
              </div>
              <p className="text-sm text-gray-800">{details.pregnancy}</p>
              <p className="text-sm text-pink-700">{details.pregnancyDari}</p>
            </div>
            <div className="p-4 bg-gradient-to-br from-blue-50 to-cyan-50 rounded-lg border border-blue-200">
              <div className="flex items-center gap-2 mb-2">
                <Droplets className="w-5 h-5 text-blue-600" />
                <h4 className="text-sm">Breastfeeding | شيدې ورکول</h4>
              </div>
              <p className="text-sm text-gray-800">{details.breastfeeding}</p>
              <p className="text-sm text-blue-700">{details.breastfeedingDari}</p>
            </div>
          </div>

          {/* Storage */}
          <div className="p-4 bg-gradient-to-r from-gray-50 to-slate-50 rounded-lg border border-gray-200">
            <div className="flex items-center gap-2 mb-2">
              <Package className="w-5 h-5 text-gray-600" />
              <h4 className="text-sm">Storage | ذخیره کول</h4>
            </div>
            <p className="text-sm text-gray-800">{details.storage}</p>
            <p className="text-sm text-gray-600">{details.storageDari}</p>
          </div>

          {/* Manufacturer */}
          <div className="p-4 bg-emerald-50 rounded-lg">
            <p className="text-sm text-gray-700">
              <strong>Manufacturer:</strong> {medicine.manufacturer}
            </p>
            <p className="text-xs text-emerald-700 mt-1">
              Always consult with a healthcare professional before starting any new medication.
              • د هر نوي درملو پیلولو څخه مخکې تل د روغتیا پاملرنې متخصص سره مشوره وکړئ.
            </p>
          </div>

          {/* Action Buttons */}
          <div className="grid grid-cols-2 gap-3 pt-4">
            <Button
              className="bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-600 hover:to-teal-700"
              disabled={!medicine.inStock}
            >
              <Package className="w-4 h-4 mr-2" />
              Order Now
            </Button>
            <Button
              variant="outline"
              className="border-emerald-300 text-emerald-700 hover:bg-emerald-50"
            >
              <Info className="w-4 h-4 mr-2" />
              Ask Pharmacist
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
