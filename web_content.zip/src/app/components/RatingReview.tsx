import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  ArrowLeft, Star, Send, ThumbsUp, MessageCircle, TrendingUp,
  Award, Users, CheckCircle, Edit, Trash2, X
} from 'lucide-react';
import { toast } from 'sonner@2.0.3';
import Logo from './Logo';

interface RatingReviewProps {
  language: 'ps' | 'fa' | 'en';
  onBack: () => void;
  currentUserEmail?: string;
  currentUserName?: string;
}

interface Review {
  id: string;
  userName: string;
  userEmail: string;
  rating: number;
  comment: string;
  date: string;
  likes: number;
  likedBy: string[];
}

export function RatingReview({ 
  language, 
  onBack,
  currentUserEmail = '',
  currentUserName = ''
}: RatingReviewProps) {
  const [userRating, setUserRating] = useState(0);
  const [hoverRating, setHoverRating] = useState(0);
  const [comment, setComment] = useState('');
  const [reviews, setReviews] = useState<Review[]>([]);
  const [hasReviewed, setHasReviewed] = useState(false);
  const [editingReview, setEditingReview] = useState<Review | null>(null);
  const [showSubmitModal, setShowSubmitModal] = useState(false);

  const isRTL = language === 'ps' || language === 'fa';

  // Translations
  const translations = {
    en: {
      title: 'Rate HealMate',
      subtitle: 'Share your experience with us',
      yourRating: 'Your Rating',
      tapToRate: 'Tap to rate',
      writeReview: 'Write a Review',
      reviewPlaceholder: 'Tell us what you think about HealMate...',
      submit: 'Submit Review',
      update: 'Update Review',
      cancel: 'Cancel',
      statistics: 'Rating Statistics',
      avgRating: 'Average Rating',
      totalReviews: 'Total Reviews',
      excellent: 'Excellent',
      veryGood: 'Very Good',
      good: 'Good',
      fair: 'Fair',
      poor: 'Poor',
      recentReviews: 'Recent Reviews',
      noReviews: 'No reviews yet. Be the first to review!',
      thankYou: 'Thank you for your feedback!',
      reviewSubmitted: 'Review submitted successfully',
      reviewUpdated: 'Review updated successfully',
      reviewDeleted: 'Review deleted successfully',
      loginRequired: 'Please login to submit a review',
      ratingRequired: 'Please select a rating',
      commentRequired: 'Please write a comment',
      helpful: 'Helpful',
      edit: 'Edit',
      delete: 'Delete',
      confirmDelete: 'Are you sure you want to delete your review?',
      yourReview: 'Your Review'
    },
    ps: {
      title: 'د HealMate ارزونه',
      subtitle: 'زموږ سره خپله تجربه شریکه کړئ',
      yourRating: 'ستاسو ارزونه',
      tapToRate: 'د ارزونې لپاره کلیک وکړئ',
      writeReview: 'نظر ولیکئ',
      reviewPlaceholder: 'موږ ته ووایاست چې تاسو د HealMate په اړه څه فکر کوئ...',
      submit: 'نظر واستوئ',
      update: 'نظر تازه کړئ',
      cancel: 'لغوه',
      statistics: 'د ارزونې احصائیې',
      avgRating: 'اوسط ارزونه',
      totalReviews: 'ټول نظرونه',
      excellent: 'غوره',
      veryGood: 'ډیر ښه',
      good: 'ښه',
      fair: 'منځنی',
      poor: 'خراب',
      recentReviews: 'وروستي نظرونه',
      noReviews: 'تر اوسه هیڅ نظر نشته. لومړی نظر ورکوونکی شئ!',
      thankYou: 'ستاسو د نظر لپاره مننه!',
      reviewSubmitted: 'نظر بریالیتوب سره واستول شو',
      reviewUpdated: 'نظر بریالیتوب سره تازه شو',
      reviewDeleted: 'نظر بریالیتوب سره ړنګ شو',
      loginRequired: 'مهرباني وکړئ لومړی Login وکړئ',
      ratingRequired: 'مهرباني وکړئ ستوري غوره کړئ',
      commentRequired: 'مهرباني وکړئ نظر ولیکئ',
      helpful: 'ګټور',
      edit: 'تعدیل',
      delete: 'ړنګول',
      confirmDelete: 'آیا تاسو ډاډه یاست چې خپل نظر ړنګ کړئ؟',
      yourReview: 'ستاسو نظر'
    },
    fa: {
      title: 'امتیاز به HealMate',
      subtitle: 'تجربه خود را با ما به اشتراک بگذارید',
      yourRating: 'امتیاز شما',
      tapToRate: 'برای امتیاز کلیک کنید',
      writeReview: 'نظر بنویسید',
      reviewPlaceholder: 'به ما بگویید که درباره HealMate چه فکر می‌کنید...',
      submit: 'ارسال نظر',
      update: 'به‌روزرسانی نظر',
      cancel: 'لغو',
      statistics: 'آمار امتیازدهی',
      avgRating: 'میانگین امتیاز',
      totalReviews: 'کل نظرات',
      excellent: 'عالی',
      veryGood: 'خیلی خوب',
      good: 'خوب',
      fair: 'متوسط',
      poor: 'ضعیف',
      recentReviews: 'نظرات اخیر',
      noReviews: 'هنوز نظری ثبت نشده. اولین نظر را شما بنویسید!',
      thankYou: 'از نظر شما متشکریم!',
      reviewSubmitted: 'نظر با موفقیت ارسال شد',
      reviewUpdated: 'نظر با موفقیت به‌روز شد',
      reviewDeleted: 'نظر با موفقیت حذف شد',
      loginRequired: 'لطفاً ابتدا وارد شوید',
      ratingRequired: 'لطفاً امتیاز انتخاب کنید',
      commentRequired: 'لطفاً نظر بنویسید',
      helpful: 'مفید',
      edit: 'ویرایش',
      delete: 'حذف',
      confirmDelete: 'آیا مطمئن هستید که می‌خواهید نظر خود را حذف کنید؟',
      yourReview: 'نظر شما'
    }
  };

  const t = translations[language];

  // Load reviews from localStorage
  useEffect(() => {
    const savedReviews = localStorage.getItem('healmate_reviews');
    if (savedReviews) {
      setReviews(JSON.parse(savedReviews));
    }
    
    // Check if user has already reviewed
    if (currentUserEmail) {
      const existingReview = JSON.parse(savedReviews || '[]').find(
        (r: Review) => r.userEmail === currentUserEmail
      );
      if (existingReview) {
        setHasReviewed(true);
        setUserRating(existingReview.rating);
        setComment(existingReview.comment);
      }
    }
  }, [currentUserEmail]);

  // Calculate average rating
  const avgRating = reviews.length > 0
    ? reviews.reduce((acc, r) => acc + r.rating, 0) / reviews.length
    : 0;

  // Calculate rating distribution
  const ratingDistribution = [5, 4, 3, 2, 1].map(rating => ({
    rating,
    count: reviews.filter(r => r.rating === rating).length,
    percentage: reviews.length > 0 
      ? (reviews.filter(r => r.rating === rating).length / reviews.length) * 100 
      : 0
  }));

  // Handle submit review
  const handleSubmitReview = () => {
    if (!currentUserEmail) {
      toast.error(t.loginRequired);
      return;
    }

    if (userRating === 0) {
      toast.error(t.ratingRequired);
      return;
    }

    if (!comment.trim()) {
      toast.error(t.commentRequired);
      return;
    }

    const newReview: Review = {
      id: `review_${Date.now()}`,
      userName: currentUserName || 'User',
      userEmail: currentUserEmail,
      rating: userRating,
      comment: comment.trim(),
      date: new Date().toISOString(),
      likes: 0,
      likedBy: []
    };

    // Check if user already reviewed
    const existingReviewIndex = reviews.findIndex(r => r.userEmail === currentUserEmail);
    
    let updatedReviews;
    if (existingReviewIndex !== -1) {
      // Update existing review
      updatedReviews = [...reviews];
      updatedReviews[existingReviewIndex] = {
        ...updatedReviews[existingReviewIndex],
        rating: userRating,
        comment: comment.trim(),
        date: new Date().toISOString()
      };
      toast.success(t.reviewUpdated);
    } else {
      // Add new review
      updatedReviews = [newReview, ...reviews];
      toast.success(t.reviewSubmitted);
    }

    setReviews(updatedReviews);
    localStorage.setItem('healmate_reviews', JSON.stringify(updatedReviews));
    setHasReviewed(true);
    setShowSubmitModal(true);
    
    // Reset form
    setComment('');
    setUserRating(0);
    
    // Hide modal after 2 seconds
    setTimeout(() => {
      setShowSubmitModal(false);
    }, 2000);
  };

  // Handle delete review
  const handleDeleteReview = () => {
    if (!confirm(t.confirmDelete)) return;

    const updatedReviews = reviews.filter(r => r.userEmail !== currentUserEmail);
    setReviews(updatedReviews);
    localStorage.setItem('healmate_reviews', JSON.stringify(updatedReviews));
    setHasReviewed(false);
    setUserRating(0);
    setComment('');
    toast.success(t.reviewDeleted);
  };

  // Handle like review
  const handleLikeReview = (reviewId: string) => {
    if (!currentUserEmail) {
      toast.error(t.loginRequired);
      return;
    }

    const updatedReviews = reviews.map(review => {
      if (review.id === reviewId) {
        const hasLiked = review.likedBy.includes(currentUserEmail);
        return {
          ...review,
          likes: hasLiked ? review.likes - 1 : review.likes + 1,
          likedBy: hasLiked 
            ? review.likedBy.filter(email => email !== currentUserEmail)
            : [...review.likedBy, currentUserEmail]
        };
      }
      return review;
    });

    setReviews(updatedReviews);
    localStorage.setItem('healmate_reviews', JSON.stringify(updatedReviews));
  };

  // Get rating label
  const getRatingLabel = (rating: number) => {
    if (rating === 5) return t.excellent;
    if (rating === 4) return t.veryGood;
    if (rating === 3) return t.good;
    if (rating === 2) return t.fair;
    return t.poor;
  };

  // Get user's review
  const userReview = reviews.find(r => r.userEmail === currentUserEmail);

  return (
    <div className={`min-h-screen bg-gradient-to-br from-purple-50 via-pink-50 to-orange-50 ${isRTL ? 'rtl' : 'ltr'}`}>
      {/* Header */}
      <header className="sticky top-0 z-40 backdrop-blur-xl bg-white/80 border-b border-white/20 shadow-lg">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <button
              onClick={onBack}
              className={`p-2 rounded-xl bg-gradient-to-br from-purple-100 to-pink-100 hover:from-purple-200 hover:to-pink-200 transition-all ${isRTL ? 'rotate-180' : ''}`}
            >
              <ArrowLeft className="w-5 h-5 text-purple-700" />
            </button>
            <div className="flex items-center gap-3">
              <Logo size="sm" showText={false} />
              <h1 className="text-xl font-bold bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent">
                {t.title}
              </h1>
            </div>
            <div className="w-9" /> {/* Spacer */}
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-6 space-y-6">
        {/* Statistics Card */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white rounded-3xl shadow-xl p-6 border border-purple-100"
        >
          <div className="flex items-center gap-3 mb-6">
            <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-yellow-400 to-orange-500 flex items-center justify-center">
              <Award className="w-6 h-6 text-white" />
            </div>
            <div>
              <h2 className="font-bold text-gray-800">{t.statistics}</h2>
              <p className="text-sm text-gray-500">{t.subtitle}</p>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4 mb-6">
            {/* Average Rating */}
            <div className="text-center p-4 bg-gradient-to-br from-yellow-50 to-orange-50 rounded-2xl">
              <div className="text-4xl font-bold text-orange-600 mb-2">
                {avgRating.toFixed(1)}
              </div>
              <div className="flex items-center justify-center gap-1 mb-2">
                {[1, 2, 3, 4, 5].map((star) => (
                  <Star
                    key={star}
                    className={`w-5 h-5 ${
                      star <= Math.round(avgRating)
                        ? 'fill-yellow-400 text-yellow-400'
                        : 'text-gray-300'
                    }`}
                  />
                ))}
              </div>
              <div className="text-sm text-gray-600">{t.avgRating}</div>
            </div>

            {/* Total Reviews */}
            <div className="text-center p-4 bg-gradient-to-br from-purple-50 to-pink-50 rounded-2xl">
              <div className="text-4xl font-bold text-purple-600 mb-2">
                {reviews.length}
              </div>
              <div className="flex items-center justify-center gap-1 mb-2">
                <Users className="w-5 h-5 text-purple-500" />
              </div>
              <div className="text-sm text-gray-600">{t.totalReviews}</div>
            </div>
          </div>

          {/* Rating Distribution */}
          <div className="space-y-2">
            {ratingDistribution.map(({ rating, count, percentage }) => (
              <div key={rating} className="flex items-center gap-3">
                <div className="flex items-center gap-1 w-20">
                  <span className="text-sm font-bold text-gray-700">{rating}</span>
                  <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                </div>
                <div className="flex-1 h-3 bg-gray-100 rounded-full overflow-hidden">
                  <motion.div
                    initial={{ width: 0 }}
                    animate={{ width: `${percentage}%` }}
                    transition={{ duration: 1, delay: 0.2 }}
                    className="h-full bg-gradient-to-r from-yellow-400 to-orange-500"
                  />
                </div>
                <span className="text-sm text-gray-600 w-12 text-right">{count}</span>
              </div>
            ))}
          </div>
        </motion.div>

        {/* Your Review Section */}
        {userReview && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-gradient-to-br from-green-50 to-emerald-50 rounded-3xl shadow-xl p-6 border-2 border-green-200"
          >
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-3">
                <CheckCircle className="w-6 h-6 text-green-600" />
                <h3 className="font-bold text-green-800">{t.yourReview}</h3>
              </div>
              <div className="flex gap-2">
                <button
                  onClick={handleDeleteReview}
                  className="p-2 rounded-xl bg-red-100 hover:bg-red-200 transition-all"
                >
                  <Trash2 className="w-4 h-4 text-red-600" />
                </button>
              </div>
            </div>

            <div className="flex items-center gap-2 mb-3">
              {[1, 2, 3, 4, 5].map((star) => (
                <Star
                  key={star}
                  className={`w-6 h-6 ${
                    star <= userReview.rating
                      ? 'fill-yellow-400 text-yellow-400'
                      : 'text-gray-300'
                  }`}
                />
              ))}
              <span className="text-sm font-bold text-gray-700 mr-2">
                {getRatingLabel(userReview.rating)}
              </span>
            </div>

            <p className="text-gray-700 mb-3">{userReview.comment}</p>
            <p className="text-sm text-gray-500">
              {new Date(userReview.date).toLocaleDateString(
                language === 'ps' || language === 'fa' ? 'fa-AF' : 'en-US',
                { year: 'numeric', month: 'long', day: 'numeric' }
              )}
            </p>
          </motion.div>
        )}

        {/* Rate & Review Form */}
        {!userReview && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-white rounded-3xl shadow-xl p-6 border border-purple-100"
          >
            <div className="flex items-center gap-3 mb-6">
              <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-purple-500 to-pink-500 flex items-center justify-center">
                <Star className="w-6 h-6 text-white" />
              </div>
              <div>
                <h2 className="font-bold text-gray-800">{t.yourRating}</h2>
                <p className="text-sm text-gray-500">{t.tapToRate}</p>
              </div>
            </div>

            {/* Star Rating */}
            <div className="flex items-center justify-center gap-3 mb-4">
              {[1, 2, 3, 4, 5].map((star) => (
                <motion.button
                  key={star}
                  whileHover={{ scale: 1.2 }}
                  whileTap={{ scale: 0.9 }}
                  onMouseEnter={() => setHoverRating(star)}
                  onMouseLeave={() => setHoverRating(0)}
                  onClick={() => setUserRating(star)}
                  className="focus:outline-none"
                >
                  <Star
                    className={`w-12 h-12 transition-all ${
                      star <= (hoverRating || userRating)
                        ? 'fill-yellow-400 text-yellow-400 drop-shadow-lg'
                        : 'text-gray-300'
                    }`}
                  />
                </motion.button>
              ))}
            </div>

            {userRating > 0 && (
              <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                className="text-center mb-6"
              >
                <span className="inline-block px-4 py-2 bg-gradient-to-r from-purple-100 to-pink-100 text-purple-700 rounded-full font-bold">
                  {getRatingLabel(userRating)}
                </span>
              </motion.div>
            )}

            {/* Comment Input */}
            <div className="mb-6">
              <label className="block text-sm font-bold text-gray-700 mb-2">
                {t.writeReview}
              </label>
              <textarea
                value={comment}
                onChange={(e) => setComment(e.target.value)}
                placeholder={t.reviewPlaceholder}
                rows={5}
                className="w-full px-4 py-3 border-2 border-purple-100 rounded-2xl focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent resize-none"
              />
            </div>

            {/* Submit Button */}
            <motion.button
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              onClick={handleSubmitReview}
              disabled={userRating === 0 || !comment.trim()}
              className="w-full py-4 rounded-2xl bg-gradient-to-r from-purple-500 via-pink-500 to-orange-500 text-white font-bold flex items-center justify-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed hover:shadow-xl transition-all"
            >
              <Send className="w-5 h-5" />
              {t.submit}
            </motion.button>
          </motion.div>
        )}

        {/* Recent Reviews */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white rounded-3xl shadow-xl p-6 border border-purple-100"
        >
          <div className="flex items-center gap-3 mb-6">
            <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-blue-500 to-cyan-500 flex items-center justify-center">
              <MessageCircle className="w-6 h-6 text-white" />
            </div>
            <div>
              <h2 className="font-bold text-gray-800">{t.recentReviews}</h2>
              <p className="text-sm text-gray-500">{reviews.length} {t.totalReviews}</p>
            </div>
          </div>

          {reviews.length === 0 ? (
            <div className="text-center py-12">
              <div className="w-24 h-24 mx-auto mb-4 rounded-full bg-gradient-to-br from-gray-100 to-gray-200 flex items-center justify-center">
                <Star className="w-12 h-12 text-gray-400" />
              </div>
              <p className="text-gray-500">{t.noReviews}</p>
            </div>
          ) : (
            <div className="space-y-4">
              {reviews
                .filter(r => r.userEmail !== currentUserEmail)
                .map((review) => (
                <motion.div
                  key={review.id}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  className="p-4 bg-gradient-to-br from-gray-50 to-white rounded-2xl border border-gray-100"
                >
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-full bg-gradient-to-br from-purple-400 to-pink-500 flex items-center justify-center text-white font-bold">
                        {review.userName.charAt(0)}
                      </div>
                      <div>
                        <h4 className="font-bold text-gray-800">{review.userName}</h4>
                        <p className="text-xs text-gray-500">
                          {new Date(review.date).toLocaleDateString(
                            language === 'ps' || language === 'fa' ? 'fa-AF' : 'en-US',
                            { year: 'numeric', month: 'short', day: 'numeric' }
                          )}
                        </p>
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-1 mb-3">
                    {[1, 2, 3, 4, 5].map((star) => (
                      <Star
                        key={star}
                        className={`w-4 h-4 ${
                          star <= review.rating
                            ? 'fill-yellow-400 text-yellow-400'
                            : 'text-gray-300'
                        }`}
                      />
                    ))}
                    <span className="text-sm font-bold text-gray-600 ml-2">
                      {getRatingLabel(review.rating)}
                    </span>
                  </div>

                  <p className="text-gray-700 mb-3">{review.comment}</p>

                  <div className="flex items-center gap-4">
                    <button
                      onClick={() => handleLikeReview(review.id)}
                      className={`flex items-center gap-2 px-3 py-1 rounded-full transition-all ${
                        review.likedBy.includes(currentUserEmail)
                          ? 'bg-purple-100 text-purple-600'
                          : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                      }`}
                    >
                      <ThumbsUp className="w-4 h-4" />
                      <span className="text-sm font-bold">{review.likes}</span>
                    </button>
                  </div>
                </motion.div>
              ))}
            </div>
          )}
        </motion.div>
      </div>

      {/* Success Modal */}
      <AnimatePresence>
        {showSubmitModal && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4"
          >
            <motion.div
              initial={{ scale: 0.5, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.5, opacity: 0 }}
              className="bg-white rounded-3xl p-8 max-w-sm w-full text-center shadow-2xl"
            >
              <div className="w-20 h-20 mx-auto mb-4 rounded-full bg-gradient-to-br from-green-400 to-emerald-500 flex items-center justify-center">
                <CheckCircle className="w-10 h-10 text-white" />
              </div>
              <h3 className="text-2xl font-bold text-gray-800 mb-2">{t.thankYou}</h3>
              <p className="text-gray-600">{t.reviewSubmitted}</p>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
