import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Leaf, Book, Sparkles, Heart, Coffee, Star, 
  Sun, Moon, Wind, Droplet, Flame, ChevronRight
} from 'lucide-react';
import { Button } from './ui/button';
import { Card } from './ui/card';

interface TraditionalMedicineHubProps {
  language: 'ps' | 'fa' | 'en';
}

interface TraditionalRemedy {
  id: string;
  name: { ps: string; fa: string; en: string };
  description: { ps: string; fa: string; en: string };
  benefits: { ps: string[]; fa: string[]; en: string[] };
  howToUse: { ps: string; fa: string; en: string };
  icon: string;
  color: string;
  category: 'herb' | 'food' | 'therapy';
}

export function TraditionalMedicineHub({ language }: TraditionalMedicineHubProps) {
  const [selectedRemedy, setSelectedRemedy] = useState<TraditionalRemedy | null>(null);
  const [activeCategory, setActiveCategory] = useState<'all' | 'herb' | 'food' | 'therapy'>('all');

  const texts = {
    ps: {
      title: '🌿 د افغان دودیز طب',
      subtitle: 'د زړو او ازموده شوو طبي درملو په اړه معلومات',
      categories: {
        all: 'ټول',
        herb: 'بوټي',
        food: 'خوراکي توکي',
        therapy: 'درملنې'
      },
      benefits: 'ګټې:',
      howToUse: 'څنګه وکاروئ:',
      closeBtn: 'بندول',
      learnMore: 'نور معلومات'
    },
    fa: {
      title: '🌿 طب سنتی افغانی',
      subtitle: 'اطلاعات درباره داروهای قدیمی و آزمایش شده',
      categories: {
        all: 'همه',
        herb: 'گیاهان',
        food: 'مواد غذایی',
        therapy: 'درمان‌ها'
      },
      benefits: 'فواید:',
      howToUse: 'نحوه استفاده:',
      closeBtn: 'بستن',
      learnMore: 'اطلاعات بیشتر'
    },
    en: {
      title: '🌿 Traditional Afghan Medicine',
      subtitle: 'Information about ancient and tested remedies',
      categories: {
        all: 'All',
        herb: 'Herbs',
        food: 'Foods',
        therapy: 'Therapies'
      },
      benefits: 'Benefits:',
      howToUse: 'How to Use:',
      closeBtn: 'Close',
      learnMore: 'Learn More'
    }
  };

  const t = texts[language];

  const remedies: TraditionalRemedy[] = [
    {
      id: '1',
      name: {
        ps: 'سپین زیره',
        fa: 'زیره سفید',
        en: 'Cumin'
      },
      description: {
        ps: 'سپین زیره د هضم لپاره ډیر ګټور دی او د ډډ درد، ګاز، او بدهضمۍ لپاره کارول کیږي.',
        fa: 'زیره سفید برای گوارش بسیار مفید است و برای درد معده، نفخ و سوء هاضمه استفاده می‌شود.',
        en: 'Cumin is very beneficial for digestion and is used for stomach pain, gas, and indigestion.'
      },
      benefits: {
        ps: ['هضم ښه کوي', 'د ډډ درد کموي', 'د ګاز مخنیوی کوي', 'بھوک ډیروي'],
        fa: ['گوارش را بهبود می‌دهد', 'درد معده را کاهش می‌دهد', 'از نفخ جلوگیری می‌کند', 'اشتها را افزایش می‌دهد'],
        en: ['Improves digestion', 'Reduces stomach pain', 'Prevents gas', 'Increases appetite']
      },
      howToUse: {
        ps: 'یوه چمچ سپین زیره په یو ګیلاس ګرمو اوبو کې واچوئ او د خوړو وروسته یې وڅښئ.',
        fa: 'یک قاشق زیره سفید را در یک لیوان آب گرم بریزید و بعد از غذا بنوشید.',
        en: 'Add one teaspoon of cumin to a glass of hot water and drink after meals.'
      },
      icon: '🌾',
      color: 'from-green-500 to-emerald-500',
      category: 'herb'
    },
    {
      id: '2',
      name: {
        ps: 'شات',
        fa: 'عسل',
        en: 'Honey'
      },
      description: {
        ps: 'شات د طبیعي انټي بایوټیک په توګه کار کوي او د ټوخي، زکام، او د ځیګر روغتیا لپاره ګټور دی.',
        fa: 'عسل به عنوان آنتی‌بیوتیک طبیعی عمل می‌کند و برای سرفه، سرماخوردگی و سلامت کبد مفید است.',
        en: 'Honey acts as a natural antibiotic and is beneficial for cough, cold, and liver health.'
      },
      benefits: {
        ps: ['انټي بایوټیک دی', 'ټوخی کموي', 'انرژي ورکوي', 'ځیګر پیاوړی کوي'],
        fa: ['آنتی‌بیوتیک است', 'سرفه را کاهش می‌دهد', 'انرژی می‌دهد', 'کبد را تقویت می‌کند'],
        en: ['Antibiotic', 'Reduces cough', 'Gives energy', 'Strengthens liver']
      },
      howToUse: {
        ps: 'سهار په خالي ډډ یوه چمچ شات د ګرمو اوبو سره وڅښئ یا د چای سره ورزیات کړئ.',
        fa: 'صبح ناشتا یک قاشق عسل با آب گرم بنوشید یا با چای اضافه کنید.',
        en: 'Drink one spoon of honey with warm water on empty stomach in the morning or add to tea.'
      },
      icon: '🍯',
      color: 'from-yellow-500 to-orange-500',
      category: 'food'
    },
    {
      id: '3',
      name: {
        ps: 'سره مرچ',
        fa: 'فلفل قرمز',
        en: 'Red Pepper'
      },
      description: {
        ps: 'سره مرچ د وینې جریان ښه کوي، د دماغ فعالیت ډیروي، او د وزن کمولو کې مرسته کوي.',
        fa: 'فلفل قرمز جریان خون را بهبود می‌دهد، فعالیت مغز را افزایش می‌دهد و به کاهش وزن کمک می‌کند.',
        en: 'Red pepper improves blood circulation, increases brain activity, and helps in weight loss.'
      },
      benefits: {
        ps: ['د وینې جریان ښه کوي', 'میټابولیزم ډیروي', 'د دماغ لپاره ګټور', 'د دردونو کمښت'],
        fa: ['گردش خون را بهبود می‌دهد', 'متابولیسم را افزایش می‌دهد', 'برای مغز مفید', 'کاهش دردها'],
        en: ['Improves blood flow', 'Increases metabolism', 'Good for brain', 'Pain reduction']
      },
      howToUse: {
        ps: 'تازه مرچ د خوړو سره وخورئ یا د چای سره لږ مقدار ورزیات کړئ.',
        fa: 'فلفل تازه را با غذا بخورید یا مقدار کمی با چای اضافه کنید.',
        en: 'Eat fresh pepper with food or add small amount to tea.'
      },
      icon: '🌶️',
      color: 'from-red-500 to-pink-500',
      category: 'food'
    },
    {
      id: '4',
      name: {
        ps: 'کالونجي',
        fa: 'سیاه‌دانه',
        en: 'Black Seed'
      },
      description: {
        ps: 'کالونجي د ډیرو ناروغیو لپاره درملنه ده او د ایمیون سیسټم پیاوړی کوي.',
        fa: 'سیاه‌دانه درمان بسیاری از بیماری‌هاست و سیستم ایمنی را تقویت می‌کند.',
        en: 'Black seed is a cure for many diseases and strengthens the immune system.'
      },
      benefits: {
        ps: ['ایمیون سیسټم پیاوړی کوي', 'د شوګر کنترول', 'د وینې فشار تنظیموي', 'د سر درد درملنه'],
        fa: ['سیستم ایمنی را تقویت می‌کند', 'کنترل قند', 'فشار خون را تنظیم می‌کند', 'درمان سردرد'],
        en: ['Strengthens immune system', 'Sugar control', 'Regulates blood pressure', 'Headache treatment']
      },
      howToUse: {
        ps: 'سهار او شپه یو څو دانې د شاتو سره وخورئ یا د تیلو څخه یې استعمال وکړئ.',
        fa: 'صبح و شب چند دانه با عسل بخورید یا از روغن آن استفاده کنید.',
        en: 'Eat a few seeds with honey morning and evening or use its oil.'
      },
      icon: '⚫',
      color: 'from-gray-700 to-gray-900',
      category: 'herb'
    },
    {
      id: '5',
      name: {
        ps: 'د لمر وړانګې',
        fa: 'نور خورشید',
        en: 'Sunlight'
      },
      description: {
        ps: 'د لمر وړانګې د ویټامین D د ترلاسه کولو لپاره ډیرې ګټورې دي او د هډوکو روغتیا ښه کوي.',
        fa: 'نور خورشید برای دریافت ویتامین D بسیار مفید است و سلامت استخوان را بهبود می‌بخشد.',
        en: 'Sunlight is very beneficial for getting Vitamin D and improves bone health.'
      },
      benefits: {
        ps: ['ویټامین D ورکوي', 'هډوکي پیاوړي کوي', 'د مزاج ښه کوي', 'د خوب ښه کوي'],
        fa: ['ویتامین D می‌دهد', 'استخوان را تقویت می‌کند', 'خلق را بهبود می‌بخشد', 'خواب را بهتر می‌کند'],
        en: ['Gives Vitamin D', 'Strengthens bones', 'Improves mood', 'Better sleep']
      },
      howToUse: {
        ps: 'هره ورځ سهار 15-20 دقیقې د لمر وړانګو کې ناست شئ (د 10 بجې څخه مخکې).',
        fa: 'هر روز صبح 15-20 دقیقه در نور خورشید بنشینید (قبل از ساعت 10).',
        en: 'Sit in sunlight for 15-20 minutes every morning (before 10 AM).'
      },
      icon: '☀️',
      color: 'from-yellow-400 to-orange-400',
      category: 'therapy'
    },
    {
      id: '6',
      name: {
        ps: 'د اوبو درملنه',
        fa: 'آب‌درمانی',
        en: 'Water Therapy'
      },
      description: {
        ps: 'د سهار په خالي ډډ ګرمې اوبې څښل ډیرې روغتیايي ګټې لري.',
        fa: 'نوشیدن آب گرم ناشتا صبح فواید سلامتی زیادی دارد.',
        en: 'Drinking warm water on empty stomach in morning has many health benefits.'
      },
      benefits: {
        ps: ['هضم ښه کوي', 'بدن پاکوي', 'وزن کموي', 'پوستکي ښکلا زیاتوي'],
        fa: ['گوارش را بهبود می‌دهد', 'بدن را پاک می‌کند', 'وزن را کاهش می‌دهد', 'زیبایی پوست را افزایش می‌دهد'],
        en: ['Improves digestion', 'Cleanses body', 'Reduces weight', 'Increases skin beauty']
      },
      howToUse: {
        ps: 'هره ورځ سهار د بستر څخه د پاڅیدو څخه وروسته 2-3 ګیلاسه ګرمې اوبې وڅښئ.',
        fa: 'هر روز صبح بعد از بیدار شدن 2-3 لیوان آب گرم بنوشید.',
        en: 'Drink 2-3 glasses of warm water every morning after waking up.'
      },
      icon: '💧',
      color: 'from-blue-400 to-cyan-400',
      category: 'therapy'
    }
  ];

  const filteredRemedies = activeCategory === 'all' 
    ? remedies 
    : remedies.filter(r => r.category === activeCategory);

  return (
    <div className="w-full">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="mb-6"
      >
        <div className="text-center mb-6">
          <h2 className="text-3xl mb-2 bg-gradient-to-r from-green-600 via-emerald-600 to-teal-600 bg-clip-text text-transparent">
            {t.title}
          </h2>
          <p className="text-gray-600">{t.subtitle}</p>
        </div>

        {/* Category Filter */}
        <div className="flex justify-center gap-2 mb-8 flex-wrap">
          {(['all', 'herb', 'food', 'therapy'] as const).map((cat) => (
            <Button
              key={cat}
              onClick={() => setActiveCategory(cat)}
              variant={activeCategory === cat ? 'default' : 'outline'}
              size="sm"
              className={activeCategory === cat 
                ? 'bg-gradient-to-r from-green-500 to-emerald-500 text-white' 
                : 'border-green-200 text-green-700 hover:bg-green-50'}
            >
              {t.categories[cat]}
            </Button>
          ))}
        </div>

        {/* Remedies Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
          <AnimatePresence mode="popLayout">
            {filteredRemedies.map((remedy, index) => (
              <motion.div
                key={remedy.id}
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.9 }}
                transition={{ delay: index * 0.1 }}
                layout
              >
                <Card 
                  onClick={() => setSelectedRemedy(remedy)}
                  className="cursor-pointer hover:shadow-xl transition-all bg-white/80 backdrop-blur-lg border-2 overflow-hidden"
                >
                  <div className={`bg-gradient-to-r ${remedy.color} p-4`}>
                    <div className="flex items-center justify-between text-white">
                      <div className="flex items-center gap-3">
                        <div className="text-4xl">{remedy.icon}</div>
                        <div>
                          <h3 className="text-xl">{remedy.name[language]}</h3>
                          <div className="text-sm opacity-90">
                            {remedy.category === 'herb' && (
                              language === 'ps' ? 'بوټی' : language === 'fa' ? 'گیاه' : 'Herb'
                            )}
                            {remedy.category === 'food' && (
                              language === 'ps' ? 'خوراکي' : language === 'fa' ? 'غذایی' : 'Food'
                            )}
                            {remedy.category === 'therapy' && (
                              language === 'ps' ? 'درملنه' : language === 'fa' ? 'درمان' : 'Therapy'
                            )}
                          </div>
                        </div>
                      </div>
                      <ChevronRight className="w-6 h-6" />
                    </div>
                  </div>
                  <div className="p-4">
                    <p className="text-sm text-gray-700 line-clamp-3">
                      {remedy.description[language]}
                    </p>
                  </div>
                </Card>
              </motion.div>
            ))}
          </AnimatePresence>
        </div>
      </motion.div>

      {/* Detail Modal */}
      <AnimatePresence>
        {selectedRemedy && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setSelectedRemedy(null)}
            className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4"
          >
            <motion.div
              initial={{ scale: 0.9, y: 20 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.9, y: 20 }}
              onClick={(e) => e.stopPropagation()}
              className="bg-white rounded-3xl shadow-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto"
            >
              {/* Header */}
              <div className={`bg-gradient-to-r ${selectedRemedy.color} p-8 rounded-t-3xl text-white`}>
                <div className="flex items-center gap-4 mb-4">
                  <div className="text-6xl">{selectedRemedy.icon}</div>
                  <div>
                    <h2 className="text-3xl">{selectedRemedy.name[language]}</h2>
                    <div className="text-sm opacity-90 mt-1">
                      {selectedRemedy.category === 'herb' && (
                        language === 'ps' ? 'بوټی' : language === 'fa' ? 'گیاه' : 'Herb'
                      )}
                      {selectedRemedy.category === 'food' && (
                        language === 'ps' ? 'خوراکي توکی' : language === 'fa' ? 'ماده غذایی' : 'Food'
                      )}
                      {selectedRemedy.category === 'therapy' && (
                        language === 'ps' ? 'درملنه' : language === 'fa' ? 'درمان' : 'Therapy'
                      )}
                    </div>
                  </div>
                </div>
              </div>

              {/* Content */}
              <div className="p-8 space-y-6">
                {/* Description */}
                <div>
                  <p className="text-gray-700 text-lg leading-relaxed">
                    {selectedRemedy.description[language]}
                  </p>
                </div>

                {/* Benefits */}
                <div>
                  <h3 className="text-xl mb-3 flex items-center gap-2">
                    <Sparkles className="w-5 h-5 text-yellow-500" />
                    {t.benefits}
                  </h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                    {selectedRemedy.benefits[language].map((benefit, index) => (
                      <motion.div
                        key={index}
                        initial={{ opacity: 0, x: -10 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ delay: index * 0.1 }}
                        className="flex items-center gap-2 p-3 bg-green-50 rounded-xl"
                      >
                        <Star className="w-4 h-4 text-green-600 fill-green-600 flex-shrink-0" />
                        <span className="text-sm text-gray-700">{benefit}</span>
                      </motion.div>
                    ))}
                  </div>
                </div>

                {/* How to Use */}
                <div className="bg-gradient-to-br from-blue-50 to-cyan-50 rounded-2xl p-6">
                  <h3 className="text-xl mb-3 flex items-center gap-2">
                    <Book className="w-5 h-5 text-blue-600" />
                    {t.howToUse}
                  </h3>
                  <p className="text-gray-700 leading-relaxed">
                    {selectedRemedy.howToUse[language]}
                  </p>
                </div>

                {/* Close Button */}
                <Button
                  onClick={() => setSelectedRemedy(null)}
                  className="w-full bg-gradient-to-r from-green-500 to-emerald-500 text-white text-lg py-6"
                >
                  {t.closeBtn}
                </Button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}