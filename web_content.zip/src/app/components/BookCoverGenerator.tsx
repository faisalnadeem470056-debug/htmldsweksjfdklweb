import { BookOpen } from 'lucide-react';

interface BookCoverGeneratorProps {
  title: string;
  author: string;
  category?: string;
}

// د اتومات ډول د کتاب عکس جوړونکی
// Automatic book cover generator
export function BookCoverGenerator({ title, author, category }: BookCoverGeneratorProps) {
  // د کټګوري له مخې رنګونه
  const categoryColors: Record<string, string> = {
    anatomy: 'from-red-500 to-pink-600',
    surgery: 'from-blue-500 to-cyan-600',
    cardiology: 'from-red-600 to-rose-700',
    neurology: 'from-purple-500 to-indigo-600',
    pediatrics: 'from-yellow-400 to-orange-500',
    psychiatry: 'from-violet-500 to-purple-600',
    radiology: 'from-gray-500 to-slate-600',
    pharmacy: 'from-green-500 to-emerald-600',
    nursing: 'from-pink-500 to-rose-600',
    public_health: 'from-teal-500 to-cyan-600',
    emergency: 'from-red-600 to-orange-600',
    internal_medicine: 'from-blue-600 to-indigo-600',
    default: 'from-amber-500 to-orange-600',
  };

  const gradientClass = category ? (categoryColors[category] || categoryColors.default) : categoryColors.default;

  return (
    <div className={`relative w-full h-full bg-gradient-to-br ${gradientClass} rounded-xl flex flex-col items-center justify-center p-6 text-white shadow-2xl overflow-hidden`}>
      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-10">
        <div className="absolute top-0 left-0 w-40 h-40 bg-white rounded-full -translate-x-20 -translate-y-20"></div>
        <div className="absolute bottom-0 right-0 w-60 h-60 bg-white rounded-full translate-x-30 translate-y-30"></div>
        <div className="absolute top-1/2 left-1/2 w-32 h-32 bg-white rounded-full -translate-x-16 -translate-y-16"></div>
      </div>

      {/* Content */}
      <div className="relative z-10 text-center w-full">
        <div className="mb-4">
          <BookOpen className="w-16 h-16 mx-auto opacity-90" />
        </div>
        
        <h3 className="text-2xl font-bold mb-4 line-clamp-3 leading-tight">
          {title || 'کتاب'}
        </h3>
        
        <div className="w-16 h-1 bg-white/50 mx-auto mb-4"></div>
        
        <p className="text-lg opacity-90 line-clamp-2">
          {author || 'نامعلوم لیکوال'}
        </p>
      </div>

      {/* Decorative Corner */}
      <div className="absolute bottom-0 right-0 w-24 h-24 opacity-20">
        <div className="absolute bottom-0 right-0 w-full h-1 bg-white"></div>
        <div className="absolute bottom-0 right-0 w-1 h-full bg-white"></div>
      </div>
    </div>
  );
}
