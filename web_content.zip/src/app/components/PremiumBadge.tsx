import { Crown, Sparkles, Zap } from 'lucide-react';
import { motion } from 'motion/react';

interface PremiumBadgeProps {
  size?: 'sm' | 'md' | 'lg';
  showLabel?: boolean;
  animate?: boolean;
  className?: string;
}

export function PremiumBadge({ size = 'md', showLabel = false, animate = true, className = '' }: PremiumBadgeProps) {
  const sizes = {
    sm: 'w-4 h-4',
    md: 'w-5 h-5',
    lg: 'w-6 h-6'
  };

  const containerSizes = {
    sm: 'px-2 py-0.5 text-xs',
    md: 'px-3 py-1 text-sm',
    lg: 'px-4 py-1.5 text-base'
  };

  if (showLabel) {
    return (
      <motion.div
        initial={animate ? { scale: 0 } : undefined}
        animate={animate ? { scale: 1 } : undefined}
        className={`inline-flex items-center gap-1.5 bg-gradient-to-r from-yellow-400 to-orange-500 text-white rounded-full font-medium ${containerSizes[size]} ${className}`}
      >
        <Crown className={sizes[size]} />
        <span>Premium</span>
        {animate && <Sparkles className={`${sizes[size]} animate-pulse`} />}
      </motion.div>
    );
  }

  return (
    <motion.div
      initial={animate ? { scale: 0, rotate: -180 } : undefined}
      animate={animate ? { scale: 1, rotate: 0 } : undefined}
      transition={{ type: 'spring', stiffness: 200 }}
      className={`inline-flex items-center justify-center bg-gradient-to-br from-yellow-400 to-orange-500 rounded-full p-1 ${className}`}
      title="Premium Member"
    >
      <Crown className={`${sizes[size]} text-white`} />
    </motion.div>
  );
}

export function PremiumIndicator({ children, isPremium }: { children: React.ReactNode; isPremium: boolean }) {
  if (!isPremium) return <>{children}</>;

  return (
    <div className="relative inline-block">
      {children}
      <div className="absolute -top-1 -right-1">
        <PremiumBadge size="sm" animate={false} />
      </div>
    </div>
  );
}

export function PremiumLock({ onClick }: { onClick?: () => void }) {
  return (
    <motion.button
      onClick={onClick}
      whileHover={{ scale: 1.05 }}
      whileTap={{ scale: 0.95 }}
      className="inline-flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-yellow-400 to-orange-500 text-white rounded-xl font-medium shadow-lg hover:shadow-xl transition-shadow"
    >
      <Crown className="w-5 h-5" />
      <span>Unlock with Premium</span>
      <Zap className="w-4 h-4 animate-pulse" />
    </motion.button>
  );
}
