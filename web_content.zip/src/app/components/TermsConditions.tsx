import { ArrowLeft, FileText, Shield, AlertTriangle, Scale, UserX, RefreshCw } from 'lucide-react';
import { motion } from 'motion/react';
import { Button } from './ui/button';
import { Card, CardContent } from './ui/card';

interface TermsConditionsProps {
  language: 'ps' | 'fa' | 'en';
  onBack: () => void;
}

export function TermsConditions({ language, onBack }: TermsConditionsProps) {
  return (
    <div className="min-h-screen bg-gradient-to-br from-violet-50 via-purple-50 to-fuchsia-50 pb-28 md:pb-8">
      {/* Header */}
      <div className="sticky top-0 z-40 backdrop-blur-xl bg-white/80 border-b border-white/20 shadow-lg">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center gap-4">
            <Button variant="ghost" size="icon" onClick={onBack}>
              <ArrowLeft className="w-5 h-5" />
            </Button>
            <div className="flex-1">
              <h1 className="text-2xl bg-gradient-to-r from-violet-600 to-fuchsia-600 bg-clip-text text-transparent">
                {language === 'ps' && 'شرطونه او ضوابط'}
                {language === 'fa' && 'شرایط و ضوابط'}
                {language === 'en' && 'Terms & Conditions'}
              </h1>
              <p className="text-sm text-gray-600">
                {language === 'ps' && 'د اپلیکیشن د کارولو قواعد او مقررات'}
                {language === 'fa' && 'قوانین و مقررات استفاده از برنامه'}
                {language === 'en' && 'App usage rules and regulations'}
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="container mx-auto px-4 py-8 max-w-4xl">
        {/* Last Updated */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-8"
        >
          <div className="inline-flex items-center gap-2 bg-white/80 backdrop-blur-sm px-6 py-3 rounded-full shadow-lg">
            <FileText className="w-5 h-5 text-violet-600" />
            <span className="text-sm">
              {language === 'ps' && 'نافذ: 25 نومبر 2025'}
              {language === 'fa' && 'لازم الاجرا: 25 نوامبر 2025'}
              {language === 'en' && 'Effective: November 25, 2025'}
            </span>
          </div>
        </motion.div>

        {/* Introduction */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
        >
          <Card className="mb-6 border-0 shadow-xl hover-lift bg-gradient-to-br from-violet-50 to-purple-50">
            <CardContent className="p-8">
              <div className="flex items-center gap-4 mb-4">
                <div className="w-16 h-16 bg-gradient-to-br from-violet-500 to-purple-600 rounded-2xl flex items-center justify-center shadow-lg">
                  <FileText className="w-8 h-8 text-white" />
                </div>
                <h2 className="text-2xl">
                  {language === 'ps' && 'موافقت نامه'}
                  {language === 'fa' && 'توافقنامه'}
                  {language === 'en' && 'Agreement'}
                </h2>
              </div>
              
              <div className="space-y-4 text-gray-700 leading-relaxed" dir={language === 'en' ? 'ltr' : 'rtl'}>
                {language === 'ps' && (
                  <>
                    <p>
                      د HealMate موبایل اپلیکیشن لاسرسي او کارولو سره، تاسو د دې تړون شرطونو او احکامو پابندۍ منئ او موافق یاست. که تاسو د دې شرطونو او شرطونو سره موافق نه یاست، مهرباني وکړئ زموږ خدمتونه مه کاروئ.
                    </p>
                    <p className="font-medium text-violet-700">
                      دا شرطونه او ضوابط تاسو او HealMate ترمنځ یو قانوني تړون جوړوي.
                    </p>
                  </>
                )}
                {language === 'fa' && (
                  <>
                    <p>
                      با دسترسی و استفاده از برنامه موبایل HealMate، شما پابندی به شرایط و احکام این قرارداد را می‌پذیرید و موافق هستید. اگر با این شرایط و ضوابط موافق نیستید، لطفاً از خدمات ما استفاده نکنید.
                    </p>
                    <p className="font-medium text-violet-700">
                      این شرایط و ضوابط یک قرارداد قانونی بین شما و HealMate ایجاد می‌کند.
                    </p>
                  </>
                )}
                {language === 'en' && (
                  <>
                    <p>
                      By accessing and using the HealMate mobile application, you accept and agree to be bound by the terms and provisions of this agreement. If you do not agree with these terms and conditions, please do not use our services.
                    </p>
                    <p className="font-medium text-violet-700">
                      These Terms & Conditions constitute a legal agreement between you and HealMate.
                    </p>
                  </>
                )}
              </div>
            </CardContent>
          </Card>
        </motion.div>

        {/* Acceptable Use */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
        >
          <Card className="mb-6 border-0 shadow-xl hover-lift bg-gradient-to-br from-blue-50 to-cyan-50">
            <CardContent className="p-8">
              <div className="flex items-center gap-4 mb-4">
                <div className="w-16 h-16 bg-gradient-to-br from-blue-500 to-cyan-600 rounded-2xl flex items-center justify-center shadow-lg">
                  <Shield className="w-8 h-8 text-white" />
                </div>
                <h2 className="text-2xl">
                  {language === 'ps' && 'د منلو وړ کارونه'}
                  {language === 'fa' && 'استفاده قابل قبول'}
                  {language === 'en' && 'Acceptable Use'}
                </h2>
              </div>

              <div className="space-y-4 text-gray-700" dir={language === 'en' ? 'ltr' : 'rtl'}>
                <p className="font-medium">
                  {language === 'ps' && 'تاسو موافقه کوئ چې اپلیکیشن به:'}
                  {language === 'fa' && 'شما موافقت می‌کنید که برنامه را:'}
                  {language === 'en' && 'You agree to use the app:'}
                </p>
                <ul className="space-y-2">
                  {language === 'ps' && (
                    <>
                      <li className="flex items-start gap-2">
                        <span className="text-blue-600 mt-1">✓</span>
                        <span>یوازې د قانوني موخو لپاره وکاروئ</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <span className="text-blue-600 mt-1">✓</span>
                        <span>د نورو حقونو او محرمیت سره احترام وکړئ</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <span className="text-blue-600 mt-1">✓</span>
                        <span>د لاسرسي معلوماتو سمون او دقت یقیني کړئ</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <span className="text-blue-600 mt-1">✓</span>
                        <span>د افغانستان قوانینو او مقرراتو پیروي وکړئ</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <span className="text-blue-600 mt-1">✓</span>
                        <span>د خپل حساب امنیت وساتئ</span>
                      </li>
                    </>
                  )}
                  {language === 'fa' && (
                    <>
                      <li className="flex items-start gap-2">
                        <span className="text-blue-600 mt-1">✓</span>
                        <span>فقط برای اهداف قانونی استفاده کنید</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <span className="text-blue-600 mt-1">✓</span>
                        <span>حقوق و حریم خصوصی دیگران را احترام کنید</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <span className="text-blue-600 mt-1">✓</span>
                        <span>اطلاعات ارائه شده صحیح و دقیق باشد</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <span className="text-blue-600 mt-1">✓</span>
                        <span>از قوانین و مقررات افغانستان پیروی کنید</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <span className="text-blue-600 mt-1">✓</span>
                        <span>امنیت حساب خود را حفظ کنید</span>
                      </li>
                    </>
                  )}
                  {language === 'en' && (
                    <>
                      <li className="flex items-start gap-2">
                        <span className="text-blue-600 mt-1">✓</span>
                        <span>Only for lawful purposes</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <span className="text-blue-600 mt-1">✓</span>
                        <span>Respect others' rights and privacy</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <span className="text-blue-600 mt-1">✓</span>
                        <span>Provide accurate and truthful information</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <span className="text-blue-600 mt-1">✓</span>
                        <span>Comply with Afghan laws and regulations</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <span className="text-blue-600 mt-1">✓</span>
                        <span>Maintain account security</span>
                      </li>
                    </>
                  )}
                </ul>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        {/* Prohibited Activities */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
        >
          <Card className="mb-6 border-0 shadow-xl hover-lift bg-gradient-to-br from-red-50 to-orange-50">
            <CardContent className="p-8">
              <div className="flex items-center gap-4 mb-4">
                <div className="w-16 h-16 bg-gradient-to-br from-red-500 to-orange-600 rounded-2xl flex items-center justify-center shadow-lg">
                  <UserX className="w-8 h-8 text-white" />
                </div>
                <h2 className="text-2xl">
                  {language === 'ps' && 'منع شوي فعالیتونه'}
                  {language === 'fa' && 'فعالیت‌های ممنوع'}
                  {language === 'en' && 'Prohibited Activities'}
                </h2>
              </div>

              <div className="space-y-4 text-gray-700" dir={language === 'en' ? 'ltr' : 'rtl'}>
                <p className="font-medium">
                  {language === 'ps' && 'تاسو نشئ کولی:'}
                  {language === 'fa' && 'شما نمی‌توانید:'}
                  {language === 'en' && 'You may not:'}
                </p>
                <ul className="space-y-2">
                  {language === 'ps' && (
                    <>
                      <li className="flex items-start gap-2">
                        <span className="text-red-600 mt-1">✗</span>
                        <span>غلط یا ګمراه کوونکي معلومات وړاندې کړئ</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <span className="text-red-600 mt-1">✗</span>
                        <span>د نورو هویت غلا یا جعلي حسابونه جوړ کړئ</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <span className="text-red-600 mt-1">✗</span>
                        <span>بې ادبه، تیري کوونکی یا غیر قانوني مواد شریک کړئ</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <span className="text-red-600 mt-1">✗</span>
                        <span>اپلیکیشن ته زیان رسوي یا د خدماتو د قطع کولو هڅه وکړئ</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <span className="text-red-600 mt-1">✗</span>
                        <span>د نورو کاروونکو شخصي معلومات پرته له اجازې راټول کړئ</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <span className="text-red-600 mt-1">✗</span>
                        <span>د اپلیکیشن کوډ کاپي، بدلون یا reverse engineer وکړئ</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <span className="text-red-600 mt-1">✗</span>
                        <span>سپام یا غیر غوښتل شوي تبلیغات واستوئ</span>
                      </li>
                    </>
                  )}
                  {language === 'fa' && (
                    <>
                      <li className="flex items-start gap-2">
                        <span className="text-red-600 mt-1">✗</span>
                        <span>اطلاعات نادرست یا گمراه‌کننده ارائه دهید</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <span className="text-red-600 mt-1">✗</span>
                        <span>هویت دیگران را سرقت یا حساب‌های جعلی ایجاد کنید</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <span className="text-red-600 mt-1">✗</span>
                        <span>محتوای توهین‌آمیز، آزاردهنده یا غیرقانونی به اشتراک بگذارید</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <span className="text-red-600 mt-1">✗</span>
                        <span>به برنامه آسیب رسانده یا سعی در قطع خدمات کنید</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <span className="text-red-600 mt-1">✗</span>
                        <span>اطلاعات شخصی کاربران دیگر را بدون اجازه جمع‌آوری کنید</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <span className="text-red-600 mt-1">✗</span>
                        <span>کد برنامه را کپی، تغییر یا مهندسی معکوس کنید</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <span className="text-red-600 mt-1">✗</span>
                        <span>اسپم یا تبلیغات ناخواسته ارسال کنید</span>
                      </li>
                    </>
                  )}
                  {language === 'en' && (
                    <>
                      <li className="flex items-start gap-2">
                        <span className="text-red-600 mt-1">✗</span>
                        <span>Provide false or misleading information</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <span className="text-red-600 mt-1">✗</span>
                        <span>Impersonate others or create fake accounts</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <span className="text-red-600 mt-1">✗</span>
                        <span>Share abusive, harassing, or illegal content</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <span className="text-red-600 mt-1">✗</span>
                        <span>Damage the app or attempt service disruption</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <span className="text-red-600 mt-1">✗</span>
                        <span>Collect other users' personal information without permission</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <span className="text-red-600 mt-1">✗</span>
                        <span>Copy, modify, or reverse engineer the app code</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <span className="text-red-600 mt-1">✗</span>
                        <span>Send spam or unsolicited advertisements</span>
                      </li>
                    </>
                  )}
                </ul>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        {/* Medical Disclaimer */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
        >
          <Card className="mb-6 border-0 shadow-xl hover-lift bg-gradient-to-br from-amber-50 to-yellow-50">
            <CardContent className="p-8">
              <div className="flex items-center gap-4 mb-4">
                <div className="w-16 h-16 bg-gradient-to-br from-amber-500 to-yellow-600 rounded-2xl flex items-center justify-center shadow-lg">
                  <AlertTriangle className="w-8 h-8 text-white" />
                </div>
                <h2 className="text-2xl">
                  {language === 'ps' && 'د طبي مسؤولیت رد'}
                  {language === 'fa' && 'سلب مسئولیت پزشکی'}
                  {language === 'en' && 'Medical Disclaimer'}
                </h2>
              </div>

              <div className="space-y-4 text-gray-700 leading-relaxed" dir={language === 'en' ? 'ltr' : 'rtl'}>
                {language === 'ps' && (
                  <>
                    <div className="bg-amber-100 border-l-4 border-amber-500 p-4 rounded-r-lg">
                      <p className="font-semibold mb-2">⚠️ مهم خبرتیا:</p>
                      <p>
                        HealMate یو معلوماتي اپلیکیشن دی او د مسلکي طبي مشورې، تشخیص، یا درملنې بدیل نه دی. دا اپلیکیشن کې چمتو شوي معلومات یوازې د عمومي معلوماتو لپاره دي او نباید د طبي مشورې په توګه وګڼل شي.
                      </p>
                    </div>
                    <p>
                      تاسو تصدیق کوئ او موافقه کوئ چې:
                    </p>
                    <ul className="space-y-2">
                      <li>• ټول معلومات یوازې تعلیمي او معلوماتي موخو لپاره دي</li>
                      <li>• د کومې روغتیا ستونزې لپاره، تاسو به د مسلکي طبي متخصص سره مشوره وکړئ</li>
                      <li>• د اپلیکیشن معلومات د طبي مشورې بدیل نه دی</li>
                      <li>• HealMate د معلوماتو د کارولو له امله د کومې زیان مسؤولیت نه لري</li>
                      <li>• هیڅکله د روغتیا ستونزې لپاره د مسلکي مشورې نه غفلت مه کوئ</li>
                    </ul>
                  </>
                )}
                {language === 'fa' && (
                  <>
                    <div className="bg-amber-100 border-l-4 border-amber-500 p-4 rounded-r-lg">
                      <p className="font-semibold mb-2">⚠️ اطلاعیه مهم:</p>
                      <p>
                        HealMate یک برنامه اطلاعاتی است و جایگزین مشاوره، تشخیص یا درمان پزشکی حرفه‌ای نیست. اطلاعات ارائه شده در این برنامه فقط برای اطلاعات عمومی است و نباید به عنوان مشاوره پزشکی در نظر گرفته شود.
                      </p>
                    </div>
                    <p>
                      شما تأیید و موافقت می‌کنید که:
                    </p>
                    <ul className="space-y-2">
                      <li>• تمام اطلاعات فقط برای اهداف آموزشی و اطلاعاتی است</li>
                      <li>• برای هر مشکل سلامتی، با یک متخصص پزشکی حرفه‌ای مشورت خواهید کرد</li>
                      <li>• اطلاعات برنامه جایگزین مشاوره پزشکی نیست</li>
                      <li>• HealMate مسئولیتی برای هرگونه خسارت ناشی از استفاده از اطلاعات ندارد</li>
                      <li>• هرگز مشاوره حرفه‌ای را برای مشکلات سلامتی نادیده نگیرید</li>
                    </ul>
                  </>
                )}
                {language === 'en' && (
                  <>
                    <div className="bg-amber-100 border-l-4 border-amber-500 p-4 rounded-lg">
                      <p className="font-semibold mb-2">⚠️ Important Notice:</p>
                      <p>
                        HealMate is an informational application and not a substitute for professional medical advice, diagnosis, or treatment. The information provided in this app is for general information purposes only and should not be considered medical advice.
                      </p>
                    </div>
                    <p>
                      You acknowledge and agree that:
                    </p>
                    <ul className="space-y-2">
                      <li>• All information is for educational and informational purposes only</li>
                      <li>• For any health concerns, you will consult a professional medical specialist</li>
                      <li>• App information is not a substitute for medical advice</li>
                      <li>• HealMate has no liability for any damages from using the information</li>
                      <li>• Never disregard professional advice for health problems</li>
                    </ul>
                  </>
                )}
              </div>
            </CardContent>
          </Card>
        </motion.div>

        {/* Intellectual Property */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5 }}
        >
          <Card className="mb-6 border-0 shadow-xl hover-lift bg-gradient-to-br from-indigo-50 to-blue-50">
            <CardContent className="p-8">
              <div className="flex items-center gap-4 mb-4">
                <div className="w-16 h-16 bg-gradient-to-br from-indigo-500 to-blue-600 rounded-2xl flex items-center justify-center shadow-lg">
                  <Scale className="w-8 h-8 text-white" />
                </div>
                <h2 className="text-2xl">
                  {language === 'ps' && 'فکري ملکیت'}
                  {language === 'fa' && 'مالکیت فکری'}
                  {language === 'en' && 'Intellectual Property'}
                </h2>
              </div>

              <div className="space-y-4 text-gray-700" dir={language === 'en' ? 'ltr' : 'rtl'}>
                {language === 'ps' && (
                  <>
                    <p>
                      د HealMate اپلیکیشن او د هغې ټول مواد، په شمول مګر محدود ندي متن، ګرافیک، لوګو، عکسونه، او سافټویر، د HealMate ملکیت دی یا د هغې د جواز ورکوونکو ملکیت دی او د کاپي حق او نورو فکري ملکیت قوانینو لخوا خوندي دي.
                    </p>
                    <p className="font-medium">
                      تاسو موافقه کوئ چې نه به:
                    </p>
                    <ul className="space-y-2">
                      <li>• د اپلیکیشن کومه برخه کاپي، بدلون، یا توزیع کړئ</li>
                      <li>• د تجارتي موخو لپاره پرته له اجازې کارول</li>
                      <li>• د HealMate ټریډمارک یا لوګو بې اجازې کارول</li>
                      <li>• د اپلیکیشن سورس کوډ استخراج یا reverse engineer کول</li>
                    </ul>
                  </>
                )}
                {language === 'fa' && (
                  <>
                    <p>
                      برنامه HealMate و تمام محتوای آن، از جمله اما نه محدود به متن، گرافیک، لوگو، تصاویر و نرم‌افزار، متعلق به HealMate یا دارندگان مجوز آن است و توسط حق نسخه‌برداری و سایر قوانین مالکیت فکری محافظت می‌شود.
                    </p>
                    <p className="font-medium">
                      شما موافقت می‌کنید که:
                    </p>
                    <ul className="space-y-2">
                      <li>• هیچ بخشی از برنامه را کپی، تغییر یا توزیع نکنید</li>
                      <li>• برای اهداف تجاری بدون اجازه استفاده نکنید</li>
                      <li>• علامت تجاری یا لوگوی HealMate را بدون اجازه استفاده نکنید</li>
                      <li>• کد منبع برنامه را استخراج یا مهندسی معکوس نکنید</li>
                    </ul>
                  </>
                )}
                {language === 'en' && (
                  <>
                    <p>
                      The HealMate application and all its content, including but not limited to text, graphics, logos, images, and software, are the property of HealMate or its licensors and are protected by copyright and other intellectual property laws.
                    </p>
                    <p className="font-medium">
                      You agree that you will not:
                    </p>
                    <ul className="space-y-2">
                      <li>• Copy, modify, or distribute any part of the app</li>
                      <li>• Use for commercial purposes without permission</li>
                      <li>• Use HealMate trademarks or logos without authorization</li>
                      <li>• Extract or reverse engineer the app source code</li>
                    </ul>
                  </>
                )}
              </div>
            </CardContent>
          </Card>
        </motion.div>

        {/* Updates & Changes */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.6 }}
        >
          <Card className="mb-6 border-0 shadow-xl hover-lift bg-gradient-to-br from-teal-50 to-green-50">
            <CardContent className="p-8">
              <div className="flex items-center gap-4 mb-4">
                <div className="w-16 h-16 bg-gradient-to-br from-teal-500 to-green-600 rounded-2xl flex items-center justify-center shadow-lg">
                  <RefreshCw className="w-8 h-8 text-white" />
                </div>
                <h2 className="text-2xl">
                  {language === 'ps' && 'تازه معلومات او بدلونونه'}
                  {language === 'fa' && 'به‌روزرسانی‌ها و تغییرات'}
                  {language === 'en' && 'Updates & Changes'}
                </h2>
              </div>

              <div className="space-y-4 text-gray-700" dir={language === 'en' ? 'ltr' : 'rtl'}>
                {language === 'ps' && (
                  <>
                    <p>
                      HealMate د دې حق ساتي چې په هر وخت کې دا شرطونه او ضوابط تازه یا بدل کړي. تاسو مسؤول یاست چې دا صفحه منظم وګورئ ترڅو د بدلونونو څخه خبر شئ.
                    </p>
                    <p>
                      د دې شرطونو او ضوابط د بدلون وروسته د اپلیکیشن کارول د نویو شرطونو منل بلل کیږي.
                    </p>
                    <div className="bg-teal-100 p-4 rounded-lg">
                      <p className="font-medium">موږ به په لاندې طریقو سره تاسو ته د مهمو بدلونونو خبر درکړو:</p>
                      <ul className="mt-2 space-y-1">
                        <li>• د اپلیکیشن په منځ کې خبرتیاوې</li>
                        <li>• د بریښنالیک له لارې اطلاع</li>
                        <li>• د تازه معلوماتو نیټه په دې صفحه کې</li>
                      </ul>
                    </div>
                  </>
                )}
                {language === 'fa' && (
                  <>
                    <p>
                      HealMate این حق را دارد که این شرایط و ضوابط را در هر زمان به‌روزرسانی یا تغییر دهد. شما مسئول هستید که این صفحه را به طور منظم بررسی کنید تا از تغییرات مطلع شوید.
                    </p>
                    <p>
                      استفاده از برنامه پس از تغییر این شرایط و ضوابط به معنی پذیرش شرایط جدید است.
                    </p>
                    <div className="bg-teal-100 p-4 rounded-lg">
                      <p className="font-medium">ما شما را از تغییرات مهم از طریق:</p>
                      <ul className="mt-2 space-y-1">
                        <li>• اطلاعیه‌های درون برنامه</li>
                        <li>• اطلاع از طریق ایمیل</li>
                        <li>• تاریخ به‌روزرسانی در این صفحه</li>
                      </ul>
                    </div>
                  </>
                )}
                {language === 'en' && (
                  <>
                    <p>
                      HealMate reserves the right to update or change these Terms & Conditions at any time. You are responsible for reviewing this page regularly to stay informed of changes.
                    </p>
                    <p>
                      Using the app after changes to these Terms & Conditions constitutes acceptance of the new terms.
                    </p>
                    <div className="bg-teal-100 p-4 rounded-lg">
                      <p className="font-medium">We will notify you of important changes through:</p>
                      <ul className="mt-2 space-y-1">
                        <li>• In-app notifications</li>
                        <li>• Email notification</li>
                        <li>• Update date on this page</li>
                      </ul>
                    </div>
                  </>
                )}
              </div>
            </CardContent>
          </Card>
        </motion.div>

        {/* Contact Section */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.7 }}
        >
          <Card className="mb-6 border-0 shadow-xl hover-lift bg-gradient-to-br from-emerald-50 to-teal-50">
            <CardContent className="p-6">
              <h3 className="text-lg mb-4 text-center">
                {language === 'ps' && 'مونږ سره اړیکه'}
                {language === 'fa' && 'تماس با ما'}
                {language === 'en' && 'Contact Us'}
              </h3>
              <p className="text-sm text-gray-700 text-center mb-4" dir={language === 'en' ? 'ltr' : 'rtl'}>
                {language === 'ps' && 'که د دې شرطونو او شرطونو په اړه پوښتنې لرئ:'}
                {language === 'fa' && 'اگر سوالاتی در مورد این شرایط و ضوابط دارید:'}
                {language === 'en' && 'If you have questions about these Terms & Conditions:'}
              </p>
              <div className="flex flex-col items-center gap-2">
                <p className="text-sm text-gray-800">📧 ibrahimkhaksar.it@gmail.com</p>
                <p className="text-sm text-gray-800">📞 +93 783 040 441</p>
                <p className="text-sm text-gray-800">📞 +93 779 494 512</p>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        {/* Footer */}
        <div className="text-center text-sm text-gray-500 mt-8">
          <p>© 2025 HealMate. All rights reserved.</p>
          <p dir={language === 'en' ? 'ltr' : 'rtl'}>
            {language === 'ps' && 'د ټولو حقونه ساتل شوي'}
            {language === 'fa' && 'تمامی حقوق محفوظ است'}
            {language === 'en' && 'د ټولو حقونه ساتل شوي'}
          </p>
        </div>

        {/* Bottom Spacing */}
        <div className="h-20" />
      </div>
    </div>
  );
}
