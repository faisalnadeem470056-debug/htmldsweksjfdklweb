import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "./ui/dialog";
import { Badge } from "./ui/badge";
import { Button } from "./ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "./ui/avatar";
import { 
  Star, 
  MapPin, 
  Clock, 
  Phone, 
  Mail, 
  GraduationCap, 
  Award, 
  Calendar,
  MessageCircle,
  Video,
  CheckCircle,
  Languages
} from "lucide-react";

interface Doctor {
  name: string;
  nameDari: string;
  specialty: string;
  specialtyDari: string;
  experience: string;
  rating: number;
  patients: string;
  image: string;
  available: string;
  hospital: string;
  hospitalDari: string;
  location: string;
  locationDari: string;
}

interface DoctorDetailModalProps {
  doctor: Doctor | null;
  open: boolean;
  onClose: () => void;
}

const doctorDetails: { [key: string]: any } = {
  "Dr. Sarah Johnson": {
    email: "sarah.johnson@healmate.af",
    phone: "+93 783 040 441",
    education: [
      { degree: "MBBS", institution: "Kabul Medical University", year: "2008" },
      { degree: "MD Cardiology", institution: "Tehran University of Medical Sciences", year: "2012" },
      { degree: "Fellowship in Interventional Cardiology", institution: "India", year: "2015" }
    ],
    languages: ["Dari", "Pashto", "English", "Farsi"],
    languagesDari: ["دري", "پښتو", "انګلیسي", "فارسي"],
    specializations: [
      "Heart Disease Treatment",
      "Cardiac Surgery",
      "ECG & Echocardiography",
      "Angioplasty & Stenting",
      "Preventive Cardiology"
    ],
    specializationsDari: [
      "د زړه ناروغیو درملنه",
      "د زړه جراحي",
      "ECG او ایکوکارډیوګرافي",
      "انجیوپلاسټي او سټینټینګ",
      "د زړه مخنیوی"
    ],
    about: "Dr. Sarah Johnson is a highly experienced cardiologist with over 15 years of practice. She specializes in treating heart diseases and has performed numerous successful cardiac procedures. Dr. Johnson is known for her patient-centered approach and dedication to preventive cardiology.",
    aboutDari: "ډاکټره ساره جانسن د ۱۵ کلونو تجربې سره یوه خورا تجربه لرونکې زړه متخصصه ده. هغې د زړه ناروغیو درملنه کې تخصص لري او ډیری بریالي زړه پروسیجرونه یې ترسره کړي دي. ډاکټره جانسن د ناروغ متمرکز چلند او د زړه مخنیوي ته وقف کولو لپاره پیژندل کیږي.",
    availability: {
      days: ["Monday", "Tuesday", "Wednesday", "Thursday", "Saturday"],
      daysDari: ["دوشنبه", "سه‌شنبه", "چهارشنبه", "پنج‌شنبه", "شنبه"],
      hours: "9:00 AM - 5:00 PM",
      hoursDari: "۹:۰۰ سهار - ۵:۰۰ ماسپښین"
    },
    consultationFee: "1500 AFN",
    awards: [
      "Best Cardiologist Award 2022",
      "Excellence in Patient Care 2020",
      "Medical Innovation Award 2019"
    ]
  },
  "Dr. Noor Ahmadi": {
    email: "noor.ahmadi@healmate.af",
    phone: "+93 779 494 512",
    education: [
      { degree: "MBBS", institution: "Kabul Medical University", year: "2010" },
      { degree: "MD Pediatrics", institution: "Pakistan Institute of Medical Sciences", year: "2014" },
      { degree: "Fellowship in Neonatology", institution: "Turkey", year: "2017" }
    ],
    languages: ["Dari", "Pashto", "English", "Urdu"],
    languagesDari: ["دري", "پښتو", "انګلیسي", "اردو"],
    specializations: [
      "Child Healthcare",
      "Newborn Care",
      "Vaccination & Immunization",
      "Growth & Development",
      "Pediatric Emergency"
    ],
    specializationsDari: [
      "د ماشومانو روغتیا پاملرنه",
      "د نوي زیږیدلو پاملرنه",
      "واکسین او معافیت",
      "ودې او پرمختګ",
      "د ماشومانو بیړني"
    ],
    about: "Dr. Noor Ahmadi is a dedicated pediatrician with extensive experience in child healthcare. They are passionate about preventive medicine and ensuring healthy development of children. Dr. Ahmadi is known for their gentle approach with children and excellent communication with parents.",
    aboutDari: "ډاکټر نور احمدي د ماشومانو یو وقف شوی متخصص دی چې د ماشومانو روغتیا پاملرنه کې پراخه تجربه لري. هغه د مخنیوي طب او د ماشومانو صحي ودې ډاډمن کولو ته لیواله دی. ډاکټر احمدي د ماشومانو سره د نرم چلند او د والدینو سره غوره اړیکې لپاره پیژندل کیږي.",
    availability: {
      days: ["Sunday", "Monday", "Tuesday", "Thursday", "Friday"],
      daysDari: ["یکشنبه", "دوشنبه", "سه‌شنبه", "پنج‌شنبه", "جمعه"],
      hours: "10:00 AM - 6:00 PM",
      hoursDari: "۱۰:۰۰ سهار - ۶:۰۰ ماسپښین"
    },
    consultationFee: "1200 AFN",
    awards: [
      "Best Pediatrician Award 2023",
      "Child Health Champion 2021",
      "Community Service Award 2020"
    ]
  },
  "Dr. Hassan Karimi": {
    email: "hassan.karimi@healmate.af",
    phone: "+93 783 040 441",
    education: [
      { degree: "MBBS", institution: "Kabul Medical University", year: "2009" },
      { degree: "MD Psychiatry", institution: "India", year: "2013" },
      { degree: "Certificate in CBT", institution: "UK", year: "2016" }
    ],
    languages: ["Dari", "Pashto", "English", "Hindi"],
    languagesDari: ["دري", "پښتو", "انګلیسي", "هندي"],
    specializations: [
      "Mental Health Disorders",
      "Depression & Anxiety",
      "PTSD Treatment",
      "Cognitive Behavioral Therapy",
      "Family Counseling"
    ],
    specializationsDari: [
      "رواني روغتیا اختلالات",
      "خپګان او اضطراب",
      "PTSD درملنه",
      "علمي چلند درملنه",
      "د کورنۍ مشوره"
    ],
    about: "Dr. Hassan Karimi is a compassionate psychiatrist specializing in mental health disorders. With expertise in CBT and trauma therapy, he helps patients overcome anxiety, depression, and PTSD. Dr. Karimi believes in holistic healing and patient empowerment.",
    aboutDari: "ډاکټر حسن کریمي یو زړه سواند رواني متخصص دی چې په رواني روغتیا اختلالاتو کې تخصص لري. د CBT او صدمې درملنې کې د مهارت سره، هغه ناروغانو سره د اضطراب، خپګان او PTSD بریالي کولو کې م��سته کوي.",
    availability: {
      days: ["Monday", "Wednesday", "Thursday", "Saturday", "Sunday"],
      daysDari: ["دوشنبه", "چهارشنبه", "پنج‌شنبه", "شنبه", "یکشنبه"],
      hours: "11:00 AM - 7:00 PM",
      hoursDari: "۱۱:۰۰ سهار - ۷:۰۰ ماسپښین"
    },
    consultationFee: "1800 AFN",
    awards: [
      "Mental Health Advocate Award 2022",
      "Excellence in Therapy 2021",
      "Community Mental Health Award 2019"
    ]
  }
};

export function DoctorDetailModal({ doctor, open, onClose }: DoctorDetailModalProps) {
  if (!doctor) return null;

  const details = doctorDetails[doctor.name] || {};

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-2xl mb-1">{doctor.name}</DialogTitle>
          <DialogDescription className="text-lg text-emerald-600">
            {doctor.nameDari} - {doctor.specialty}
          </DialogDescription>
          <div className="flex items-start gap-4">
            <Avatar className="w-20 h-20 border-4 border-emerald-200">
              <AvatarImage src={doctor.image} />
              <AvatarFallback>{doctor.name[0]}</AvatarFallback>
            </Avatar>
            <div className="flex-1">
              <div className="flex items-start justify-between">
                <div>
                  <p className="text-lg text-emerald-600 mb-2">{doctor.nameDari}</p>
                  <div className="flex flex-wrap gap-2 mb-3">
                    <Badge className="bg-gradient-to-r from-emerald-500 to-teal-600 text-white">
                      {doctor.specialty}
                    </Badge>
                    <Badge variant="outline" className="text-emerald-600 border-emerald-300">
                      {doctor.specialtyDari}
                    </Badge>
                  </div>
                </div>
                <div className="text-right">
                  <div className="flex items-center gap-1 mb-1">
                    <Star className="w-5 h-5 fill-amber-400 text-amber-400" />
                    <span className="text-lg">{doctor.rating}</span>
                  </div>
                  <p className="text-sm text-gray-500">{doctor.patients} patients</p>
                </div>
              </div>
              
              <div className="flex flex-wrap gap-4 text-sm text-gray-600 mb-3">
                <div className="flex items-center gap-1">
                  <Clock className="w-4 h-4 text-emerald-600" />
                  <span>{doctor.experience}</span>
                </div>
                <div className="flex items-center gap-1">
                  <MapPin className="w-4 h-4 text-emerald-600" />
                  <span>{doctor.location}</span>
                </div>
              </div>
            </div>
          </div>
        </DialogHeader>

        <div className="space-y-6 mt-6">
          {/* About */}
          <div>
            <h3 className="text-lg mb-3 flex items-center gap-2">
              <CheckCircle className="w-5 h-5 text-emerald-600" />
              About Doctor
            </h3>
            <p className="text-sm text-gray-700 leading-relaxed mb-2">{details.about}</p>
            <p className="text-sm text-gray-600 leading-relaxed">{details.aboutDari}</p>
          </div>

          {/* Specializations */}
          <div>
            <h3 className="text-lg mb-3 flex items-center gap-2">
              <Award className="w-5 h-5 text-emerald-600" />
              Specializations | تخصصونه
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
              {details.specializations?.map((spec: string, index: number) => (
                <div key={index} className="flex items-start gap-2 p-3 bg-emerald-50 rounded-lg">
                  <CheckCircle className="w-4 h-4 text-emerald-600 mt-0.5 flex-shrink-0" />
                  <div>
                    <p className="text-sm text-gray-800">{spec}</p>
                    <p className="text-sm text-emerald-700">{details.specializationsDari?.[index]}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Education */}
          <div>
            <h3 className="text-lg mb-3 flex items-center gap-2">
              <GraduationCap className="w-5 h-5 text-emerald-600" />
              Education & Training
            </h3>
            <div className="space-y-3">
              {details.education?.map((edu: any, index: number) => (
                <div key={index} className="flex items-start gap-3 p-3 bg-blue-50 rounded-lg">
                  <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center flex-shrink-0">
                    <span className="text-blue-600">{edu.year}</span>
                  </div>
                  <div>
                    <p className="text-sm text-gray-900">{edu.degree}</p>
                    <p className="text-sm text-gray-600">{edu.institution}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Languages */}
          <div>
            <h3 className="text-lg mb-3 flex items-center gap-2">
              <Languages className="w-5 h-5 text-emerald-600" />
              Languages Spoken
            </h3>
            <div className="flex flex-wrap gap-2">
              {details.languages?.map((lang: string, index: number) => (
                <Badge key={index} variant="outline" className="text-gray-700">
                  {lang} / {details.languagesDari?.[index]}
                </Badge>
              ))}
            </div>
          </div>

          {/* Availability */}
          <div>
            <h3 className="text-lg mb-3 flex items-center gap-2">
              <Calendar className="w-5 h-5 text-emerald-600" />
              Availability | د کار وختونه
            </h3>
            <div className="p-4 bg-gradient-to-r from-emerald-50 to-teal-50 rounded-lg">
              <div className="flex flex-wrap gap-2 mb-3">
                {details.availability?.days.map((day: string, index: number) => (
                  <Badge key={index} className="bg-emerald-600">
                    {day} / {details.availability?.daysDari[index]}
                  </Badge>
                ))}
              </div>
              <p className="text-sm text-gray-700">
                <Clock className="w-4 h-4 inline mr-1 text-emerald-600" />
                {details.availability?.hours} / {details.availability?.hoursDari}
              </p>
            </div>
          </div>

          {/* Contact */}
          <div>
            <h3 className="text-lg mb-3 flex items-center gap-2">
              <Phone className="w-5 h-5 text-emerald-600" />
              Contact Information
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              <div className="flex items-center gap-3 p-3 bg-gray-50 rounded-lg">
                <Phone className="w-5 h-5 text-emerald-600" />
                <div>
                  <p className="text-xs text-gray-500">Phone</p>
                  <p className="text-sm text-gray-900">{details.phone}</p>
                </div>
              </div>
              <div className="flex items-center gap-3 p-3 bg-gray-50 rounded-lg">
                <Mail className="w-5 h-5 text-emerald-600" />
                <div>
                  <p className="text-xs text-gray-500">Email</p>
                  <p className="text-sm text-gray-900">{details.email}</p>
                </div>
              </div>
            </div>
          </div>

          {/* Consultation Fee */}
          <div className="p-4 bg-amber-50 border border-amber-200 rounded-lg">
            <p className="text-sm text-amber-900">
              <strong>Consultation Fee:</strong> {details.consultationFee}
            </p>
            <p className="text-xs text-amber-700 mt-1">
              د معاینې فیس - Emergency consultations may have different rates
            </p>
          </div>

          {/* Action Buttons */}
          <div className="grid grid-cols-3 gap-3 pt-4">
            <Button className="bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-600 hover:to-teal-700">
              <Calendar className="w-4 h-4 mr-2" />
              Book
            </Button>
            <Button variant="outline" className="border-emerald-300 text-emerald-700 hover:bg-emerald-50">
              <MessageCircle className="w-4 h-4 mr-2" />
              Chat
            </Button>
            <Button variant="outline" className="border-blue-300 text-blue-700 hover:bg-blue-50">
              <Video className="w-4 h-4 mr-2" />
              Video Call
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
