import React, { useState, useEffect } from "react";
import { Card } from "./ui/card";
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";
import { ImageWithFallback } from "./figma/ImageWithFallback";
import { Star, MapPin, Calendar, Award, CheckCircle2, Sparkles, Video, MessageCircle, Plus } from "lucide-react";
import { DoctorDetailModal } from "./DoctorDetailModal";
import { AdBanner } from "./AdBanner";
import { AddDoctorDialog } from "./AddDoctorDialog";
import { useLanguage } from "../contexts/LanguageContext";

const defaultDoctors = [
  {
    name: "Dr. Sarah Johnson",
    nameDari: "ډاکټره ساره جانسن",
    specialty: "Cardiologist",
    specialtyDari: "زړه متخصص",
    experience: "15 years",
    rating: 4.8,
    patients: "500+",
    location: "Kabul Medical Center",
    locationDari: "د کابل طبي مرکز",
    hospital: "Kabul Medical Center",
    hospitalDari: "د کابل طبي مرکز",
    available: "Available Now",
    image: "https://images.unsplash.com/photo-1632054224659-280be3239aff?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtYWxlJTIwZG9jdG9yJTIwcHJvZmVzc2lvbmFsfGVufDF8fHx8MTc2MzEwNjQ0MXww&ixlib=rb-4.1.0&q=80&w=1080",
  },
  {
    name: "Dr. Noor Ahmadi",
    nameDari: "ډاکټر نور احمدي",
    specialty: "Pediatrician",
    specialtyDari: "د ماشومانو متخصص",
    experience: "12 years",
    rating: 4.9,
    patients: "420+",
    location: "Herat Hospital",
    locationDari: "د هرات روغتون",
    hospital: "Herat Hospital",
    hospitalDari: "د هرات روغتون",
    available: "Available Tomorrow",
    image: "https://images.unsplash.com/photo-1676552055618-22ec8cde399a?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmZW1hbGUlMjBkb2N0b3IlMjBzbWlsaW5nfGVufDF8fHx8MTc2MzE2NDc0NXww&ixlib=rb-4.1.0&q=80&w=1080",
  },
  {
    name: "Dr. Hassan Karimi",
    nameDari: "ډاکټر حسن کریمي",
    specialty: "Mental Health Specialist",
    specialtyDari: "د رواني روغتیا متخصص",
    experience: "20 years",
    rating: 4.7,
    patients: "650+",
    location: "Mazar Psychiatric Clinic",
    locationDari: "د مزار رواني کلینک",
    hospital: "Mazar Psychiatric Clinic",
    hospitalDari: "د مزار رواني کلینک",
    available: "Available Now",
    image: "https://images.unsplash.com/photo-1758691461935-202e2ef6b69f?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtZWRpY2FsJTIwY29uc3VsdGF0aW9uJTIwZG9jdG9yJTIwcGF0aWVudHxlbnwxfHx8fDE3NjMxNjQ3NTV8MA&ixlib=rb-4.1.0&q=80&w=1080",
  },
  {
    name: "Dr. Mariam Hassan",
    nameDari: "ډاکټره مریم حسن",
    specialty: "Gynecologist",
    specialtyDari: "د ښځو ډاکټره",
    experience: "10 years",
    rating: 4.9,
    patients: "380+",
    location: "Kandahar Women's Hospital",
    locationDari: "د کندهار د ښځو روغتون",
    hospital: "Kandahar Women's Hospital",
    hospitalDari: "د کندهار د ښځو روغتون",
    available: "Available Now",
    image: "https://images.unsplash.com/photo-1758691463198-dc663b8a64e4?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxkb2N0b3IlMjBtZWRpY2FsJTIwY29uc3VsdGF0aW9ufGVufDF8fHx8MTc2MzExNTI4M3ww&ixlib=rb-4.1.0&q=80&w=1080",
  },
];

export function DoctorsList() {
  const { t, language } = useLanguage();
  const [selectedDoctor, setSelectedDoctor] = useState<typeof defaultDoctors[0] | null>(null);
  const [modalOpen, setModalOpen] = useState(false);
  const [addDoctorDialogOpen, setAddDoctorDialogOpen] = useState(false);
  const [customDoctors, setCustomDoctors] = useState<any[]>([]);

  // Load custom doctors from localStorage
  useEffect(() => {
    const saved = localStorage.getItem("customDoctors");
    if (saved) {
      try {
        setCustomDoctors(JSON.parse(saved));
      } catch (e) {
        console.error("Error loading custom doctors:", e);
      }
    }
  }, []);

  // Combine default and custom doctors
  const allDoctors = [...defaultDoctors, ...customDoctors];

  const handleDoctorClick = (doctor: typeof defaultDoctors[0]) => {
    setSelectedDoctor(doctor);
    setModalOpen(true);
  };

  const handleDoctorAdded = (newDoctor: any) => {
    setCustomDoctors(prev => [...prev, newDoctor]);
  };

  return (
    <>
      <section id="doctors" className="py-16 md:py-24 bg-gradient-to-b from-white via-emerald-50/30 to-white relative overflow-hidden">
        {/* Background Decoration */}
        <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-gradient-to-bl from-emerald-100/50 to-teal-100/50 rounded-full blur-3xl animate-float"></div>
        
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="text-center mb-12 md:mb-16 space-y-4">
            <div className="inline-flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-emerald-100 to-teal-100 rounded-full">
              <Sparkles className="w-4 h-4 text-emerald-600 animate-pulse-glow" />
              <span className="text-emerald-700 text-sm uppercase tracking-wider">
                {language === "ps" ? "تخصصي ټیم" :
                 language === "fa" ? "تیم متخصص" :
                 "Expert Team"}
              </span>
            </div>
            <h2 className="text-4xl md:text-6xl">
              <span className="gradient-text">
                {language === "ps" ? "زمونږ ډاکټران" :
                 language === "fa" ? "دکتران ما" :
                 "Meet Our Doctors"}
              </span>
            </h2>
            <p className="text-gray-600 max-w-2xl mx-auto text-lg">
              {language === "ps" ? "تصدیق شوي طبي متخصصین چې تاسو ته خدمت کولو لپاره چمتو دي" :
               language === "fa" ? "متخصصان پزشکی معتبر آماده خدمت به شما" :
               "Certified medical professionals ready to serve you"}
            </p>

            {/* Add Doctor Button */}
            <div className="flex justify-center pt-4">
              <Button
                onClick={() => setAddDoctorDialogOpen(true)}
                className="bg-gradient-to-r from-emerald-500 via-teal-600 to-cyan-600 hover:from-emerald-600 hover:via-teal-700 hover:to-cyan-700 text-white shadow-lg hover-scale flex items-center gap-2"
                size="lg"
              >
                <Plus className="w-5 h-5" />
                {language === "ps" ? "نوی ډاکټر اضافه کړئ" :
                 language === "fa" ? "افزودن دکتر جدید" :
                 "Add New Doctor"}
              </Button>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 md:gap-8">
            {allDoctors.map((doctor, index) => (
              <React.Fragment key={`doctor-wrapper-${doctor.name}-${index}`}>
                {/* Show Ad after every 4 doctors */}
                {index > 0 && index % 4 === 0 && (
                  <div className="col-span-1 md:col-span-2">
                    <AdBanner size="large" position="middle" />
                  </div>
                )}
                
              <Card 
                className="group hover-lift border-0 overflow-hidden bg-white shadow-lg relative cursor-pointer"
                style={{ animationDelay: `${index * 100}ms` }}
                onClick={() => handleDoctorClick(doctor)}
              >
                {/* Top Gradient Bar */}
                <div className="absolute top-0 left-0 right-0 h-2 bg-gradient-to-r from-emerald-500 via-teal-500 to-cyan-500 animate-gradient"></div>
                
                <div className="p-6 md:p-8">
                  {/* Header Section */}
                  <div className="flex items-start gap-4 mb-6">
                    {/* Avatar */}
                    <div className="relative">
                      <div className="w-20 h-20 rounded-2xl overflow-hidden shadow-lg group-hover:scale-110 transition-transform">
                        <ImageWithFallback
                          src={doctor.image}
                          alt={doctor.name}
                          className="w-full h-full object-cover"
                        />
                      </div>
                      <div className="absolute -bottom-2 -right-2 w-8 h-8 bg-emerald-500 rounded-full flex items-center justify-center shadow-lg border-4 border-white">
                        <CheckCircle2 className="w-5 h-5 text-white" />
                      </div>
                    </div>
                    
                    {/* Name & Specialty */}
                    <div className="flex-1">
                      <h3 className="text-xl text-gray-900 group-hover:text-emerald-600 transition-colors mb-1">
                        {doctor.name}
                      </h3>
                      <p className="text-gray-700 mb-1">{doctor.specialty}</p>
                      <p className="text-sm text-emerald-600">{doctor.specialtyDari}</p>
                    </div>
                    
                    {/* Availability Badge */}
                    <Badge 
                      className={`${
                        doctor.available.includes("Now") 
                          ? "bg-green-100 text-green-700 border-green-200 animate-pulse-glow" 
                          : "bg-blue-100 text-blue-700 border-blue-200"
                      } border shadow-sm`}
                    >
                      {doctor.available}
                    </Badge>
                  </div>

                  {/* Rating & Stats */}
                  <div className="flex items-center gap-4 mb-6 pb-6 border-b border-gray-100">
                    <div className="flex items-center gap-2 px-3 py-2 bg-gradient-to-r from-amber-50 to-orange-50 rounded-xl">
                      <Star className="w-5 h-5 text-amber-500 fill-amber-500" />
                      <span className="text-lg text-gray-900">{doctor.rating}</span>
                    </div>
                    <span className="text-sm text-gray-600">{doctor.patients} patients</span>
                  </div>

                  {/* Details Grid */}
                  <div className="space-y-3 mb-6">
                    <div className="flex items-center justify-between text-sm">
                      <div className="flex items-center gap-2 text-gray-600">
                        <MapPin className="w-4 h-4 text-emerald-600" />
                        <span>{doctor.location}</span>
                      </div>
                      <span className="text-gray-600">{doctor.experience}</span>
                    </div>
                  </div>

                  {/* Action Buttons */}
                  <div className="flex gap-3">
                    <Button 
                      className="flex-1 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 text-white shadow-lg shadow-emerald-600/30 hover-lift neon-glow"
                      onClick={(e) => {
                        e.stopPropagation();
                        handleDoctorClick(doctor);
                      }}
                    >
                      <Video className="w-4 h-4 mr-2" />
                      View Details
                    </Button>
                    <Button 
                      variant="outline" 
                      className="flex-1 border-2 border-emerald-600 text-emerald-600 hover:bg-emerald-50"
                      onClick={(e) => {
                        e.stopPropagation();
                        alert("Chat feature coming soon!");
                      }}
                    >
                      <MessageCircle className="w-4 h-4 mr-2" />
                      Chat
                    </Button>
                  </div>
                </div>
              </Card>
              </React.Fragment>
            ))}
          </div>
        </div>
      </section>

      {/* Doctor Detail Modal */}
      <DoctorDetailModal
        doctor={selectedDoctor}
        open={modalOpen}
        onClose={() => setModalOpen(false)}
      />

      {/* Add Doctor Dialog */}
      <AddDoctorDialog
        open={addDoctorDialogOpen}
        onOpenChange={setAddDoctorDialogOpen}
        onDoctorAdded={handleDoctorAdded}
      />
    </>
  );
}

export default DoctorsList;
