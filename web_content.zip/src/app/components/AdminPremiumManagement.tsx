import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Crown, Plus, Edit2, Trash2, Users, DollarSign, Calendar, 
  Check, X, Search, Filter, Download, Upload, Eye, Lock,
  Sparkles, Star, Zap, TrendingUp, Award, Gift, Package,
  FileText, Image as ImageIcon, BookOpen, MessageCircle
} from 'lucide-react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Textarea } from './ui/textarea';
import { premiumManager } from '../utils/PremiumManager';

interface AdminPremiumManagementProps {
  language: 'ps' | 'fa' | 'en';
}

interface PremiumPlan {
  id: string;
  name: { ps: string; fa: string; en: string };
  price: number;
  duration: 'monthly' | 'yearly';
  features: { ps: string[]; fa: string[]; en: string[] };
  discount?: number;
  popular?: boolean;
  color: string;
  icon: string;
}

interface PremiumUser {
  userId: string;
  userEmail: string;
  userName: string;
  plan: 'monthly' | 'yearly';
  startDate: string;
  endDate: string;
  status: 'active' | 'expired' | 'cancelled';
  autoRenew: boolean;
  totalPaid: number;
  joinedDate: string;
}

interface PremiumContent {
  id: string;
  type: 'post' | 'book' | 'article' | 'video';
  title: { ps: string; fa: string; en: string };
  description: { ps: string; fa: string; en: string };
  author: string;
  thumbnail?: string;
  content?: string;
  fileUrl?: string;
  publishDate: string;
  views: number;
  likes: number;
  status: 'published' | 'draft' | 'archived';
}

type SubTab = 'plans' | 'users' | 'content' | 'stats';

const translations = {
  ps: {
    title: 'د Premium مدیریت',
    subtitle: 'د Premium Plans، کاروونکو او مینځپانګې اداره',
    plans: 'Plans',
    users: 'کاروونکي',
    content: 'مینځپانګه',
    stats: 'احصائیې',
    addPlan: 'نوی Plan',
    editPlan: 'Plan سم کړئ',
    deletePlan: 'Plan حذف',
    planName: 'د Plan نوم',
    price: 'بیه (افغانۍ)',
    duration: 'موده',
    monthly: 'میاشتنۍ',
    yearly: 'کلنۍ',
    features: 'ځانګړتیاوې',
    addFeature: 'ځانګړتیا اضافه کړئ',
    discount: 'تخفیف (%)',
    popular: 'مشهور',
    color: 'رنګ',
    save: 'خوندي کړئ',
    cancel: 'لغوه',
    search: 'لټون...',
    activeUsers: 'فعال کاروونکي',
    expiredUsers: 'ختم شوي',
    totalRevenue: 'ټول عاید',
    monthlyRevenue: 'میاشتني عاید',
    yearlyRevenue: 'کلني عاید',
    userName: 'نوم',
    userEmail: 'ایمیل',
    plan: 'Plan',
    status: 'حالت',
    startDate: 'پیل نېټه',
    endDate: 'ختم نېټه',
    autoRenew: 'اوتوماتیک نوي',
    actions: 'عملونه',
    active: 'فعال',
    expired: 'ختم شوی',
    cancelled: 'لغوه شوی',
    extend: 'وده ورکړئ',
    suspend: 'تعلیق',
    delete: 'حذف',
    addContent: 'مینځپانګه اضافه',
    contentType: 'ډول',
    contentTitle: 'سرلیک',
    contentDescription: 'تفصیل',
    author: 'لیکوال',
    thumbnail: 'انځور',
    fileUrl: 'د فایل لینک',
    publishDate: 'خپرونې نېټه',
    views: 'لیدونه',
    likes: 'خوښونه',
    published: 'خپور شوی',
    draft: 'مسوده',
    archived: 'آرشیف شوی',
    post: 'پوست',
    book: 'کتاب',
    article: 'مقاله',
    video: 'ویډیو',
    totalPlans: 'ټول Plans',
    totalPremiumUsers: 'Premium کاروونکي',
    activePremiumUsers: 'فعال Premium',
    totalContent: 'ټوله مینځپانګه',
    export: 'ایکسپورټ',
    import: 'امپورټ',
    refresh: 'تازه کړئ',
    viewDetails: 'تفصیل وګورئ',
    noData: 'معلومات نشته',
  },
  fa: {
    title: 'مدیریت پریمیوم',
    subtitle: 'مدیریت پلان‌ها، کاربران و محتوای پریمیوم',
    plans: 'پلان‌ها',
    users: 'کاربران',
    content: 'محتوا',
    stats: 'آمار',
    addPlan: 'پلان جدید',
    editPlan: 'ویرایش پلان',
    deletePlan: 'حذف پلان',
    planName: 'نام پلان',
    price: 'قیمت (افغانی)',
    duration: 'مدت',
    monthly: 'ماهانه',
    yearly: 'سالانه',
    features: 'ویژگی‌ها',
    addFeature: 'افزودن ویژگی',
    discount: 'تخفیف (%)',
    popular: 'محبوب',
    color: 'رنگ',
    save: 'ذخیره',
    cancel: 'لغو',
    search: 'جستجو...',
    activeUsers: 'کاربران فعال',
    expiredUsers: 'منقضی شده',
    totalRevenue: 'درآمد کل',
    monthlyRevenue: 'درآمد ماهانه',
    yearlyRevenue: 'درآمد سالانه',
    userName: 'نام',
    userEmail: 'ایمیل',
    plan: 'پلان',
    status: 'وضعیت',
    startDate: 'تاریخ شروع',
    endDate: 'تاریخ پایان',
    autoRenew: 'تمدید خودکار',
    actions: 'اقدامات',
    active: 'فعال',
    expired: 'منقضی شده',
    cancelled: 'لغو شده',
    extend: 'تمدید',
    suspend: 'تعلیق',
    delete: 'حذف',
    addContent: 'افزودن محتوا',
    contentType: 'نوع',
    contentTitle: 'عنوان',
    contentDescription: 'توضیحات',
    author: 'نویسنده',
    thumbnail: 'تصویر',
    fileUrl: 'لینک فایل',
    publishDate: 'تاریخ انتشار',
    views: 'بازدید',
    likes: 'پسند',
    published: 'منتشر شده',
    draft: 'پیش‌نویس',
    archived: 'آرشیو شده',
    post: 'پست',
    book: 'کتاب',
    article: 'مقاله',
    video: 'ویدیو',
    totalPlans: 'کل پلان‌ها',
    totalPremiumUsers: 'کاربران پریمیوم',
    activePremiumUsers: 'پریمیوم فعال',
    totalContent: 'کل محتوا',
    export: 'خروجی',
    import: 'ورودی',
    refresh: 'به‌روزرسانی',
    viewDetails: 'مشاهده جزئیات',
    noData: 'داده‌ای وجود ندارد',
  },
  en: {
    title: 'Premium Management',
    subtitle: 'Manage Premium Plans, Users and Content',
    plans: 'Plans',
    users: 'Users',
    content: 'Content',
    stats: 'Statistics',
    addPlan: 'Add Plan',
    editPlan: 'Edit Plan',
    deletePlan: 'Delete Plan',
    planName: 'Plan Name',
    price: 'Price (AFN)',
    duration: 'Duration',
    monthly: 'Monthly',
    yearly: 'Yearly',
    features: 'Features',
    addFeature: 'Add Feature',
    discount: 'Discount (%)',
    popular: 'Popular',
    color: 'Color',
    save: 'Save',
    cancel: 'Cancel',
    search: 'Search...',
    activeUsers: 'Active Users',
    expiredUsers: 'Expired',
    totalRevenue: 'Total Revenue',
    monthlyRevenue: 'Monthly Revenue',
    yearlyRevenue: 'Yearly Revenue',
    userName: 'Name',
    userEmail: 'Email',
    plan: 'Plan',
    status: 'Status',
    startDate: 'Start Date',
    endDate: 'End Date',
    autoRenew: 'Auto Renew',
    actions: 'Actions',
    active: 'Active',
    expired: 'Expired',
    cancelled: 'Cancelled',
    extend: 'Extend',
    suspend: 'Suspend',
    delete: 'Delete',
    addContent: 'Add Content',
    contentType: 'Type',
    contentTitle: 'Title',
    contentDescription: 'Description',
    author: 'Author',
    thumbnail: 'Thumbnail',
    fileUrl: 'File URL',
    publishDate: 'Publish Date',
    views: 'Views',
    likes: 'Likes',
    published: 'Published',
    draft: 'Draft',
    archived: 'Archived',
    post: 'Post',
    book: 'Book',
    article: 'Article',
    video: 'Video',
    totalPlans: 'Total Plans',
    totalPremiumUsers: 'Premium Users',
    activePremiumUsers: 'Active Premium',
    totalContent: 'Total Content',
    export: 'Export',
    import: 'Import',
    refresh: 'Refresh',
    viewDetails: 'View Details',
    noData: 'No data available',
  },
};

export function AdminPremiumManagement({ language }: AdminPremiumManagementProps) {
  const [activeTab, setActiveTab] = useState<SubTab>('plans');
  const [premiumPlans, setPremiumPlans] = useState<PremiumPlan[]>([]);
  const [premiumUsers, setPremiumUsers] = useState<PremiumUser[]>([]);
  const [premiumContent, setPremiumContent] = useState<PremiumContent[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [showPlanModal, setShowPlanModal] = useState(false);
  const [showContentModal, setShowContentModal] = useState(false);
  const [editingPlan, setEditingPlan] = useState<PremiumPlan | null>(null);
  const [editingContent, setEditingContent] = useState<PremiumContent | null>(null);

  const t = translations[language];

  // Load data from localStorage
  useEffect(() => {
    loadPremiumData();
  }, []);

  const loadPremiumData = () => {
    // Load Premium Plans
    const savedPlans = localStorage.getItem('healmate_premium_plans');
    if (savedPlans) {
      setPremiumPlans(JSON.parse(savedPlans));
    } else {
      // د default plans
      const defaultPlans: PremiumPlan[] = [
        {
          id: 'monthly-basic',
          name: {
            ps: 'میاشتنۍ Premium',
            fa: 'پریمیوم ماهانه',
            en: 'Monthly Premium',
          },
          price: 200,
          duration: 'monthly',
          features: {
            ps: ['نامحدود AI پوښتنې', 'Premium مینځپانګه', 'بې اعلاناتو', 'د لومړي مرستې'],
            fa: ['سوالات نامحدود AI', 'محتوای پریمیوم', 'بدون اعلانات', 'پشتیبانی اولویت'],
            en: ['Unlimited AI Questions', 'Premium Content', 'Ad-Free', 'Priority Support'],
          },
          popular: true,
          color: 'from-blue-500 to-purple-600',
          icon: '👑',
        },
        {
          id: 'yearly-pro',
          name: {
            ps: 'کلنۍ Premium',
            fa: 'پریمیوم سالانه',
            en: 'Yearly Premium',
          },
          price: 2000,
          duration: 'yearly',
          features: {
            ps: ['د ټولو میاشتنو ځانګړتیاوې', '2 میاشتې وړیا', 'ویډیو مشورې', 'روغتیا تحلیل'],
            fa: ['همه ویژگی‌های ماهانه', '2 ماه رایگان', 'مشاوره ویدیویی', 'تحلیل سلامت'],
            en: ['All Monthly Features', '2 Months Free', 'Video Consultations', 'Health Analytics'],
          },
          discount: 17,
          popular: false,
          color: 'from-yellow-400 to-orange-500',
          icon: '💎',
        },
      ];
      setPremiumPlans(defaultPlans);
      localStorage.setItem('healmate_premium_plans', JSON.stringify(defaultPlans));
    }

    // Load Premium Users
    const savedUsers = localStorage.getItem('healmate_premium_users_admin');
    if (savedUsers) {
      setPremiumUsers(JSON.parse(savedUsers));
    }

    // Load Premium Content
    const savedContent = localStorage.getItem('healmate_premium_content');
    if (savedContent) {
      setPremiumContent(JSON.parse(savedContent));
    }
  };

  // Save Plans
  const savePremiumPlans = (plans: PremiumPlan[]) => {
    setPremiumPlans(plans);
    localStorage.setItem('healmate_premium_plans', JSON.stringify(plans));
  };

  // Save Premium Content
  const savePremiumContent = (content: PremiumContent[]) => {
    setPremiumContent(content);
    localStorage.setItem('healmate_premium_content', JSON.stringify(content));
  };

  // Add/Edit Plan
  const handleSavePlan = (plan: PremiumPlan) => {
    if (editingPlan) {
      // Update existing
      const updated = premiumPlans.map(p => p.id === plan.id ? plan : p);
      savePremiumPlans(updated);
    } else {
      // Add new
      savePremiumPlans([...premiumPlans, { ...plan, id: `plan-${Date.now()}` }]);
    }
    setShowPlanModal(false);
    setEditingPlan(null);
  };

  // Delete Plan
  const handleDeletePlan = (id: string) => {
    if (confirm(language === 'ps' ? 'ایا تاسو غواړئ دا Plan حذف کړئ؟' : 
                language === 'fa' ? 'آیا می‌خواهید این پلان را حذف کنید؟' : 
                'Do you want to delete this plan?')) {
      savePremiumPlans(premiumPlans.filter(p => p.id !== id));
    }
  };

  // Add/Edit Content
  const handleSaveContent = (content: PremiumContent) => {
    if (editingContent) {
      const updated = premiumContent.map(c => c.id === content.id ? content : c);
      savePremiumContent(updated);
    } else {
      savePremiumContent([...premiumContent, { ...content, id: `content-${Date.now()}`, publishDate: new Date().toISOString(), views: 0, likes: 0 }]);
    }
    setShowContentModal(false);
    setEditingContent(null);
  };

  // Delete Content
  const handleDeleteContent = (id: string) => {
    if (confirm(language === 'ps' ? 'ایا تاسو غواړئ دا مینځپانګه حذف کړئ؟' : 
                language === 'fa' ? 'آیا می‌خواهید این محتوا را حذف کنید؟' : 
                'Do you want to delete this content?')) {
      savePremiumContent(premiumContent.filter(c => c.id !== id));
    }
  };

  // Stats calculations
  const stats = {
    totalPlans: premiumPlans.length,
    totalUsers: premiumUsers.length,
    activeUsers: premiumUsers.filter(u => u.status === 'active').length,
    expiredUsers: premiumUsers.filter(u => u.status === 'expired').length,
    monthlyRevenue: premiumUsers.filter(u => u.plan === 'monthly' && u.status === 'active').length * 200,
    yearlyRevenue: premiumUsers.filter(u => u.plan === 'yearly' && u.status === 'active').length * 2000,
    totalContent: premiumContent.length,
    publishedContent: premiumContent.filter(c => c.status === 'published').length,
  };

  const tabs = [
    { id: 'plans' as SubTab, icon: Crown, label: t.plans },
    { id: 'users' as SubTab, icon: Users, label: t.users },
    { id: 'content' as SubTab, icon: FileText, label: t.content },
    { id: 'stats' as SubTab, icon: TrendingUp, label: t.stats },
  ];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold flex items-center gap-2">
            <Crown className="w-6 h-6 text-yellow-500" />
            {t.title}
          </h2>
          <p className="text-sm text-gray-600">{t.subtitle}</p>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm" onClick={loadPremiumData}>
            <Download className="w-4 h-4 mr-2" />
            {t.refresh}
          </Button>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex items-center gap-2 bg-white rounded-2xl p-2 shadow-lg overflow-x-auto">
        {tabs.map((tab) => {
          const Icon = tab.icon;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex items-center gap-2 px-4 py-2 rounded-xl transition-all whitespace-nowrap ${
                activeTab === tab.id
                  ? 'bg-gradient-to-r from-yellow-400 to-orange-500 text-white shadow-md'
                  : 'text-gray-600 hover:bg-gray-100'
              }`}
            >
              <Icon className="w-4 h-4" />
              <span className="text-sm">{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* Content */}
      <AnimatePresence mode="wait">
        {/* Plans Tab */}
        {activeTab === 'plans' && (
          <motion.div
            key="plans"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="space-y-4"
          >
            <div className="flex items-center justify-between">
              <h3 className="text-xl font-bold">{t.plans}</h3>
              <Button onClick={() => { setEditingPlan(null); setShowPlanModal(true); }}>
                <Plus className="w-4 h-4 mr-2" />
                {t.addPlan}
              </Button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {premiumPlans.map((plan) => (
                <motion.div
                  key={plan.id}
                  whileHover={{ scale: 1.02 }}
                  className={`bg-gradient-to-br ${plan.color} rounded-3xl p-6 text-white shadow-xl`}
                >
                  <div className="flex items-start justify-between mb-4">
                    <div>
                      <div className="text-4xl mb-2">{plan.icon}</div>
                      <h4 className="text-xl font-bold">{plan.name[language]}</h4>
                      <p className="text-sm opacity-90">{plan.duration === 'monthly' ? t.monthly : t.yearly}</p>
                    </div>
                    {plan.popular && (
                      <span className="bg-white/20 backdrop-blur px-3 py-1 rounded-full text-xs">
                        {t.popular}
                      </span>
                    )}
                  </div>

                  <div className="mb-4">
                    <div className="text-3xl font-bold">
                      {plan.price} <span className="text-lg">AFN</span>
                    </div>
                    {plan.discount && (
                      <div className="text-sm opacity-90">
                        {plan.discount}% {t.discount}
                      </div>
                    )}
                  </div>

                  <div className="space-y-2 mb-6">
                    {plan.features[language].map((feature, idx) => (
                      <div key={idx} className="flex items-center gap-2 text-sm">
                        <Check className="w-4 h-4" />
                        <span>{feature}</span>
                      </div>
                    ))}
                  </div>

                  <div className="flex items-center gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => { setEditingPlan(plan); setShowPlanModal(true); }}
                      className="flex-1 bg-white/20 border-white/30 text-white hover:bg-white/30"
                    >
                      <Edit2 className="w-3 h-3 mr-2" />
                      {t.editPlan}
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => handleDeletePlan(plan.id)}
                      className="bg-white/20 border-white/30 text-white hover:bg-red-500/50"
                    >
                      <Trash2 className="w-3 h-3" />
                    </Button>
                  </div>
                </motion.div>
              ))}
            </div>
          </motion.div>
        )}

        {/* Users Tab */}
        {activeTab === 'users' && (
          <motion.div
            key="users"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="space-y-4"
          >
            <div className="flex items-center justify-between">
              <h3 className="text-xl font-bold">{t.users}</h3>
              <div className="flex items-center gap-2">
                <Input
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder={t.search}
                  className="w-64"
                />
                <Button variant="outline" size="icon">
                  <Search className="w-4 h-4" />
                </Button>
              </div>
            </div>

            {premiumUsers.length === 0 ? (
              <div className="bg-white rounded-2xl p-12 text-center shadow-lg">
                <Users className="w-16 h-16 text-gray-400 mx-auto mb-4" />
                <p className="text-gray-600">{t.noData}</p>
              </div>
            ) : (
              <div className="bg-white rounded-2xl shadow-lg overflow-hidden">
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead className="bg-gray-50 border-b">
                      <tr>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">{t.userName}</th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">{t.userEmail}</th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">{t.plan}</th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">{t.status}</th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">{t.endDate}</th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">{t.actions}</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-200">
                      {premiumUsers
                        .filter(user => 
                          searchQuery === '' || 
                          user.userName.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          user.userEmail.toLowerCase().includes(searchQuery.toLowerCase())
                        )
                        .map((user) => (
                          <tr key={user.userId} className="hover:bg-gray-50">
                            <td className="px-6 py-4 whitespace-nowrap">
                              <div className="flex items-center gap-2">
                                <Crown className="w-4 h-4 text-yellow-500" />
                                <span className="font-medium">{user.userName}</span>
                              </div>
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-600">
                              {user.userEmail}
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap">
                              <span className={`px-3 py-1 rounded-full text-xs font-medium ${
                                user.plan === 'monthly' ? 'bg-blue-100 text-blue-700' : 'bg-yellow-100 text-yellow-700'
                              }`}>
                                {user.plan === 'monthly' ? t.monthly : t.yearly}
                              </span>
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap">
                              <span className={`px-3 py-1 rounded-full text-xs font-medium ${
                                user.status === 'active' ? 'bg-green-100 text-green-700' :
                                user.status === 'expired' ? 'bg-red-100 text-red-700' :
                                'bg-gray-100 text-gray-700'
                              }`}>
                                {user.status === 'active' ? t.active : user.status === 'expired' ? t.expired : t.cancelled}
                              </span>
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-600">
                              {new Date(user.endDate).toLocaleDateString()}
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap">
                              <div className="flex items-center gap-2">
                                <Button variant="outline" size="sm">
                                  <Eye className="w-3 h-3" />
                                </Button>
                                <Button variant="outline" size="sm">
                                  <Edit2 className="w-3 h-3" />
                                </Button>
                              </div>
                            </td>
                          </tr>
                        ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}
          </motion.div>
        )}

        {/* Content Tab */}
        {activeTab === 'content' && (
          <motion.div
            key="content"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="space-y-4"
          >
            <div className="flex items-center justify-between">
              <h3 className="text-xl font-bold">{t.content}</h3>
              <Button onClick={() => { setEditingContent(null); setShowContentModal(true); }}>
                <Plus className="w-4 h-4 mr-2" />
                {t.addContent}
              </Button>
            </div>

            {premiumContent.length === 0 ? (
              <div className="bg-white rounded-2xl p-12 text-center shadow-lg">
                <FileText className="w-16 h-16 text-gray-400 mx-auto mb-4" />
                <p className="text-gray-600">{t.noData}</p>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {premiumContent.map((content) => (
                  <motion.div
                    key={content.id}
                    whileHover={{ scale: 1.02 }}
                    className="bg-white rounded-2xl p-4 shadow-lg border border-gray-200"
                  >
                    {content.thumbnail && (
                      <div className="w-full h-40 bg-gray-200 rounded-xl mb-3 overflow-hidden">
                        <img src={content.thumbnail} alt={content.title[language]} className="w-full h-full object-cover" />
                      </div>
                    )}
                    
                    <div className="flex items-center gap-2 mb-2">
                      <span className={`px-2 py-1 rounded-lg text-xs font-medium ${
                        content.type === 'post' ? 'bg-blue-100 text-blue-700' :
                        content.type === 'book' ? 'bg-green-100 text-green-700' :
                        content.type === 'article' ? 'bg-purple-100 text-purple-700' :
                        'bg-red-100 text-red-700'
                      }`}>
                        {content.type === 'post' ? t.post : content.type === 'book' ? t.book : content.type === 'article' ? t.article : t.video}
                      </span>
                      <span className={`px-2 py-1 rounded-lg text-xs font-medium ${
                        content.status === 'published' ? 'bg-green-100 text-green-700' :
                        content.status === 'draft' ? 'bg-gray-100 text-gray-700' :
                        'bg-yellow-100 text-yellow-700'
                      }`}>
                        {content.status === 'published' ? t.published : content.status === 'draft' ? t.draft : t.archived}
                      </span>
                    </div>

                    <h4 className="font-bold mb-2">{content.title[language]}</h4>
                    <p className="text-sm text-gray-600 mb-3 line-clamp-2">{content.description[language]}</p>

                    <div className="flex items-center justify-between text-xs text-gray-500 mb-3">
                      <span>{content.author}</span>
                      <span>{new Date(content.publishDate).toLocaleDateString()}</span>
                    </div>

                    <div className="flex items-center gap-4 text-xs text-gray-500 mb-3">
                      <span className="flex items-center gap-1">
                        <Eye className="w-3 h-3" />
                        {content.views}
                      </span>
                      <span className="flex items-center gap-1">
                        <Star className="w-3 h-3" />
                        {content.likes}
                      </span>
                    </div>

                    <div className="flex items-center gap-2">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => { setEditingContent(content); setShowContentModal(true); }}
                        className="flex-1"
                      >
                        <Edit2 className="w-3 h-3 mr-2" />
                        {t.editPlan}
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => handleDeleteContent(content.id)}
                        className="text-red-600 hover:bg-red-50"
                      >
                        <Trash2 className="w-3 h-3" />
                      </Button>
                    </div>
                  </motion.div>
                ))}
              </div>
            )}
          </motion.div>
        )}

        {/* Stats Tab */}
        {activeTab === 'stats' && (
          <motion.div
            key="stats"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="space-y-4"
          >
            <h3 className="text-xl font-bold">{t.stats}</h3>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              {[
                { label: t.totalPlans, value: stats.totalPlans, icon: Crown, gradient: 'from-yellow-400 to-orange-500' },
                { label: t.totalPremiumUsers, value: stats.totalUsers, icon: Users, gradient: 'from-blue-500 to-purple-600' },
                { label: t.activePremiumUsers, value: stats.activeUsers, icon: Award, gradient: 'from-green-500 to-emerald-600' },
                { label: t.totalContent, value: stats.totalContent, icon: FileText, gradient: 'from-pink-500 to-red-600' },
              ].map((stat, idx) => {
                const Icon = stat.icon;
                return (
                  <motion.div
                    key={idx}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: idx * 0.1 }}
                    className={`bg-gradient-to-br ${stat.gradient} rounded-2xl p-6 text-white shadow-xl`}
                  >
                    <Icon className="w-8 h-8 mb-3 opacity-80" />
                    <div className="text-3xl font-bold mb-1">{stat.value}</div>
                    <div className="text-sm opacity-90">{stat.label}</div>
                  </motion.div>
                );
              })}
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="bg-white rounded-2xl p-6 shadow-lg">
                <div className="flex items-center gap-2 mb-3">
                  <DollarSign className="w-5 h-5 text-green-600" />
                  <h4 className="font-bold">{t.totalRevenue}</h4>
                </div>
                <div className="text-3xl font-bold text-green-600">
                  {stats.monthlyRevenue + stats.yearlyRevenue} <span className="text-lg">AFN</span>
                </div>
              </div>

              <div className="bg-white rounded-2xl p-6 shadow-lg">
                <div className="flex items-center gap-2 mb-3">
                  <Calendar className="w-5 h-5 text-blue-600" />
                  <h4 className="font-bold">{t.monthlyRevenue}</h4>
                </div>
                <div className="text-3xl font-bold text-blue-600">
                  {stats.monthlyRevenue} <span className="text-lg">AFN</span>
                </div>
              </div>

              <div className="bg-white rounded-2xl p-6 shadow-lg">
                <div className="flex items-center gap-2 mb-3">
                  <Calendar className="w-5 h-5 text-purple-600" />
                  <h4 className="font-bold">{t.yearlyRevenue}</h4>
                </div>
                <div className="text-3xl font-bold text-purple-600">
                  {stats.yearlyRevenue} <span className="text-lg">AFN</span>
                </div>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Plan Modal */}
      {showPlanModal && (
        <PlanModal
          language={language}
          plan={editingPlan}
          onSave={handleSavePlan}
          onClose={() => { setShowPlanModal(false); setEditingPlan(null); }}
        />
      )}

      {/* Content Modal */}
      {showContentModal && (
        <ContentModal
          language={language}
          content={editingContent}
          onSave={handleSaveContent}
          onClose={() => { setShowContentModal(false); setEditingContent(null); }}
        />
      )}
    </div>
  );
}

// Plan Modal Component
function PlanModal({ 
  language, 
  plan, 
  onSave, 
  onClose 
}: { 
  language: 'ps' | 'fa' | 'en';
  plan: PremiumPlan | null;
  onSave: (plan: PremiumPlan) => void;
  onClose: () => void;
}) {
  const t = translations[language];
  const [formData, setFormData] = useState<PremiumPlan>(
    plan || {
      id: '',
      name: { ps: '', fa: '', en: '' },
      price: 0,
      duration: 'monthly',
      features: { ps: [], fa: [], en: [] },
      color: 'from-blue-500 to-purple-600',
      icon: '👑',
    }
  );

  const [newFeature, setNewFeature] = useState({ ps: '', fa: '', en: '' });

  const handleAddFeature = () => {
    if (newFeature.ps && newFeature.fa && newFeature.en) {
      setFormData({
        ...formData,
        features: {
          ps: [...formData.features.ps, newFeature.ps],
          fa: [...formData.features.fa, newFeature.fa],
          en: [...formData.features.en, newFeature.en],
        },
      });
      setNewFeature({ ps: '', fa: '', en: '' });
    }
  };

  const handleSubmit = () => {
    if (formData.name.ps && formData.name.fa && formData.name.en && formData.price > 0) {
      onSave(formData);
    }
  };

  return (
    <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
      <motion.div
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        className="bg-white rounded-3xl p-6 max-w-2xl w-full max-h-[90vh] overflow-y-auto"
      >
        <h3 className="text-xl font-bold mb-4">{plan ? t.editPlan : t.addPlan}</h3>

        <div className="space-y-4">
          <div className="grid grid-cols-3 gap-4">
            <div>
              <Label>{t.planName} (پښتو)</Label>
              <Input
                value={formData.name.ps}
                onChange={(e) => setFormData({ ...formData, name: { ...formData.name, ps: e.target.value } })}
              />
            </div>
            <div>
              <Label>{t.planName} (دری)</Label>
              <Input
                value={formData.name.fa}
                onChange={(e) => setFormData({ ...formData, name: { ...formData.name, fa: e.target.value } })}
              />
            </div>
            <div>
              <Label>{t.planName} (EN)</Label>
              <Input
                value={formData.name.en}
                onChange={(e) => setFormData({ ...formData, name: { ...formData.name, en: e.target.value } })}
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label>{t.price}</Label>
              <Input
                type="number"
                value={formData.price}
                onChange={(e) => setFormData({ ...formData, price: parseInt(e.target.value) })}
              />
            </div>
            <div>
              <Label>{t.duration}</Label>
              <select
                value={formData.duration}
                onChange={(e) => setFormData({ ...formData, duration: e.target.value as 'monthly' | 'yearly' })}
                className="w-full border border-gray-300 rounded-lg px-3 py-2"
              >
                <option value="monthly">{t.monthly}</option>
                <option value="yearly">{t.yearly}</option>
              </select>
            </div>
          </div>

          <div>
            <Label>{t.features}</Label>
            <div className="space-y-2 mb-2">
              {formData.features.ps.map((_, idx) => (
                <div key={idx} className="grid grid-cols-3 gap-2">
                  <Input value={formData.features.ps[idx]} readOnly />
                  <Input value={formData.features.fa[idx]} readOnly />
                  <Input value={formData.features.en[idx]} readOnly />
                </div>
              ))}
            </div>
            <div className="grid grid-cols-3 gap-2 mb-2">
              <Input
                placeholder="پښتو"
                value={newFeature.ps}
                onChange={(e) => setNewFeature({ ...newFeature, ps: e.target.value })}
              />
              <Input
                placeholder="دری"
                value={newFeature.fa}
                onChange={(e) => setNewFeature({ ...newFeature, fa: e.target.value })}
              />
              <Input
                placeholder="English"
                value={newFeature.en}
                onChange={(e) => setNewFeature({ ...newFeature, en: e.target.value })}
              />
            </div>
            <Button onClick={handleAddFeature} size="sm">
              <Plus className="w-3 h-3 mr-2" />
              {t.addFeature}
            </Button>
          </div>

          <div className="flex items-center gap-4 pt-4 border-t">
            <Button onClick={handleSubmit} className="flex-1">
              <Check className="w-4 h-4 mr-2" />
              {t.save}
            </Button>
            <Button onClick={onClose} variant="outline" className="flex-1">
              <X className="w-4 h-4 mr-2" />
              {t.cancel}
            </Button>
          </div>
        </div>
      </motion.div>
    </div>
  );
}

// Content Modal Component
function ContentModal({ 
  language, 
  content, 
  onSave, 
  onClose 
}: { 
  language: 'ps' | 'fa' | 'en';
  content: PremiumContent | null;
  onSave: (content: PremiumContent) => void;
  onClose: () => void;
}) {
  const t = translations[language];
  const [formData, setFormData] = useState<PremiumContent>(
    content || {
      id: '',
      type: 'post',
      title: { ps: '', fa: '', en: '' },
      description: { ps: '', fa: '', en: '' },
      author: '',
      thumbnail: '',
      content: '',
      fileUrl: '',
      publishDate: new Date().toISOString(),
      views: 0,
      likes: 0,
      status: 'draft',
    }
  );

  const handleSubmit = () => {
    if (formData.title.ps && formData.title.fa && formData.title.en && formData.author) {
      onSave(formData);
    }
  };

  return (
    <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
      <motion.div
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        className="bg-white rounded-3xl p-6 max-w-3xl w-full max-h-[90vh] overflow-y-auto"
      >
        <h3 className="text-xl font-bold mb-4">{content ? 'Edit Content' : t.addContent}</h3>

        <div className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label>{t.contentType}</Label>
              <select
                value={formData.type}
                onChange={(e) => setFormData({ ...formData, type: e.target.value as any })}
                className="w-full border border-gray-300 rounded-lg px-3 py-2"
              >
                <option value="post">{t.post}</option>
                <option value="book">{t.book}</option>
                <option value="article">{t.article}</option>
                <option value="video">{t.video}</option>
              </select>
            </div>
            <div>
              <Label>{t.status}</Label>
              <select
                value={formData.status}
                onChange={(e) => setFormData({ ...formData, status: e.target.value as any })}
                className="w-full border border-gray-300 rounded-lg px-3 py-2"
              >
                <option value="draft">{t.draft}</option>
                <option value="published">{t.published}</option>
                <option value="archived">{t.archived}</option>
              </select>
            </div>
          </div>

          <div className="grid grid-cols-3 gap-4">
            <div>
              <Label>{t.contentTitle} (پښتو)</Label>
              <Input
                value={formData.title.ps}
                onChange={(e) => setFormData({ ...formData, title: { ...formData.title, ps: e.target.value } })}
              />
            </div>
            <div>
              <Label>{t.contentTitle} (دری)</Label>
              <Input
                value={formData.title.fa}
                onChange={(e) => setFormData({ ...formData, title: { ...formData.title, fa: e.target.value } })}
              />
            </div>
            <div>
              <Label>{t.contentTitle} (EN)</Label>
              <Input
                value={formData.title.en}
                onChange={(e) => setFormData({ ...formData, title: { ...formData.title, en: e.target.value } })}
              />
            </div>
          </div>

          <div className="grid grid-cols-3 gap-4">
            <div>
              <Label>{t.contentDescription} (پښتو)</Label>
              <Textarea
                value={formData.description.ps}
                onChange={(e) => setFormData({ ...formData, description: { ...formData.description, ps: e.target.value } })}
              />
            </div>
            <div>
              <Label>{t.contentDescription} (دری)</Label>
              <Textarea
                value={formData.description.fa}
                onChange={(e) => setFormData({ ...formData, description: { ...formData.description, fa: e.target.value } })}
              />
            </div>
            <div>
              <Label>{t.contentDescription} (EN)</Label>
              <Textarea
                value={formData.description.en}
                onChange={(e) => setFormData({ ...formData, description: { ...formData.description, en: e.target.value } })}
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label>{t.author}</Label>
              <Input
                value={formData.author}
                onChange={(e) => setFormData({ ...formData, author: e.target.value })}
              />
            </div>
            <div>
              <Label>{t.thumbnail} (URL)</Label>
              <Input
                value={formData.thumbnail}
                onChange={(e) => setFormData({ ...formData, thumbnail: e.target.value })}
              />
            </div>
          </div>

          <div>
            <Label>{t.fileUrl}</Label>
            <Input
              value={formData.fileUrl}
              onChange={(e) => setFormData({ ...formData, fileUrl: e.target.value })}
            />
          </div>

          <div className="flex items-center gap-4 pt-4 border-t">
            <Button onClick={handleSubmit} className="flex-1">
              <Check className="w-4 h-4 mr-2" />
              {t.save}
            </Button>
            <Button onClick={onClose} variant="outline" className="flex-1">
              <X className="w-4 h-4 mr-2" />
              {t.cancel}
            </Button>
          </div>
        </div>
      </motion.div>
    </div>
  );
}
