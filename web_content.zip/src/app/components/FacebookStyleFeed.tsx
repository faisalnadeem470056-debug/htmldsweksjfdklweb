import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Heart, MessageCircle, Share2, Flag, MoreVertical, X, Send, Image as ImageIcon, Smile, MapPin, Users, Check, Edit2, Trash2, Eye, Camera, Globe, Lock, ChevronDown, ThumbsUp, Laugh, Angry, Sad } from 'lucide-react';
import { Button } from './ui/button';
import { Textarea } from './ui/textarea';
import { Input } from './ui/input';
import { ImageWithFallback } from './figma/ImageWithFallback';
import { ShareModal } from './ShareModal';

interface FacebookStyleFeedProps {
  language: 'ps' | 'fa' | 'en';
  currentUserId: string;
  currentUserName: string;
  currentUserImage: string;
  onViewProfile: (userId: string) => void;
}

type ReactionType = 'like' | 'love' | 'haha' | 'wow' | 'sad' | 'angry';

interface Reaction {
  userId: string;
  type: ReactionType;
}

interface Post {
  id: string;
  userId: string;
  userName: string;
  userImage: string;
  verified: boolean;
  isOwner: boolean;
  content: string;
  images: string[];
  reactions: Reaction[];
  comments: Comment[];
  shares: number;
  timestamp: string;
  location?: string;
  privacy: 'public' | 'friends' | 'private';
  edited: boolean;
}

interface Comment {
  id: string;
  userId: string;
  userName: string;
  userImage: string;
  content: string;
  timestamp: string;
  likes: string[];
  replies: Comment[];
}

export function FacebookStyleFeed({ language, currentUserId, currentUserName, currentUserImage, onViewProfile }: FacebookStyleFeedProps) {
  const [posts, setPosts] = useState<Post[]>([]);
  const [newPostContent, setNewPostContent] = useState('');
  const [newPostImages, setNewPostImages] = useState<string[]>([]);
  const [showCreatePost, setShowCreatePost] = useState(false);
  const [selectedPost, setSelectedPost] = useState<Post | null>(null);
  const [commentText, setCommentText] = useState('');
  const [showReportModal, setShowReportModal] = useState(false);
  const [reportPostId, setReportPostId] = useState('');
  const [showPostMenu, setShowPostMenu] = useState<string | null>(null);
  const [editingPost, setEditingPost] = useState<Post | null>(null);
  const [showReactions, setShowReactions] = useState<string | null>(null);
  const [postPrivacy, setPostPrivacy] = useState<'public' | 'friends' | 'private'>('public');
  const [imagePreviewUrls, setImagePreviewUrls] = useState<string[]>([]);
  const [shareModalOpen, setShareModalOpen] = useState(false);
  const [sharingPost, setSharingPost] = useState<Post | null>(null);

  const t = {
    ps: {
      whatsOnMind: 'تاسو څه فکر کوئ، {name}؟',
      createPost: 'پوست جوړ کړئ',
      post: 'خپور کړئ',
      update: 'تازه کړئ',
      cancel: 'لغوه',
      addPhotos: 'عکسونه',
      location: 'موقعیت',
      feeling: 'احساس',
      tagPeople: 'خلک ټګ کړئ',
      like: 'خوښ',
      love: 'مینه',
      haha: 'خندا',
      wow: 'عجیب',
      sad: 'خفه',
      angry: 'قهر',
      comment: 'تبصره',
      share: 'شریک کړئ',
      reactions: 'غبرګونونه',
      comments: 'تبصرې',
      shares: 'شریکونه',
      writeComment: 'تبصره ولیکئ...',
      writeReply: 'ځواب ولیکئ...',
      send: 'واستوئ',
      report: 'ریپورټ',
      delete: 'حذف',
      edit: 'سمون',
      save: 'خوندي',
      view: 'کتل',
      hide: 'پټول',
      justNow: 'اوس',
      minutesAgo: 'منټې مخکې',
      hoursAgo: 'ساعتونه مخکې',
      daysAgo: 'ورځې مخکې',
      weeksAgo: 'اونۍ مخکې',
      verified: 'تایید شوی',
      owner: 'مالک',
      reportPost: 'پوست ریپورټ کړئ',
      reportReason: 'د ریپورټ دلیل',
      submitReport: 'ریپورټ واستوئ',
      spam: 'سپم',
      harassment: 'ځورول',
      inappropriate: 'نامناسب',
      fake: 'جعلي',
      violence: 'تاوتریخوالی',
      hateSpeech: 'نفرت خبرې',
      noPostsYet: 'تراوسه هیڅ پوست نشته',
      startSharing: 'خپل فکرونه شریک کړئ!',
      edited: 'سم شوی',
      deleteConfirm: 'آیا تاسو ډاډه یاست چې غواړئ حذف کړئ؟',
      public: 'عامه',
      friends: 'ملګري',
      private: 'شخصي',
      addImage: 'عکس اضافه کړئ',
      removeImage: 'عکس لرې کړئ',
      viewAllComments: 'ټول تبصرې وګورئ',
      viewProfile: 'پروفایل وګورئ',
      reply: 'ځواب',
      replies: 'ځوابونه',
      seeMore: 'نور وګورئ',
      seeLess: 'لږ وګورئ',
      andOthers: 'او نور',
      reactedTo: 'غبرګون وښود',
      commentedOn: 'تبصره وکړه',
      sharedPost: 'پوست شریک کړ'
    },
    fa: {
      whatsOnMind: 'به چه فکر می‌کنید، {name}؟',
      createPost: 'ایجاد پست',
      post: 'انتشار',
      update: 'بروزرسانی',
      cancel: 'لغو',
      addPhotos: 'عکس‌ها',
      location: 'موقعیت',
      feeling: 'احساس',
      tagPeople: 'تگ کردن افراد',
      like: 'پسند',
      love: 'عشق',
      haha: 'خنده',
      wow: 'عجیب',
      sad: 'غمگین',
      angry: 'عصبانی',
      comment: 'نظر',
      share: 'اشتراک',
      reactions: 'واکنش‌ها',
      comments: 'نظرات',
      shares: 'اشتراک‌ها',
      writeComment: 'نظر بنویسید...',
      writeReply: 'پاسخ بنویسید...',
      send: 'ارسال',
      report: 'گزارش',
      delete: 'حذف',
      edit: 'ویرایش',
      save: 'ذخیره',
      view: 'مشاهده',
      hide: 'پنهان',
      justNow: 'الان',
      minutesAgo: 'دقیقه پیش',
      hoursAgo: 'ساعت پیش',
      daysAgo: 'روز پیش',
      weeksAgo: 'هفته پیش',
      verified: 'تایید شده',
      owner: 'مالک',
      reportPost: 'گزارش پست',
      reportReason: 'دلیل گزارش',
      submitReport: 'ارسال گزارش',
      spam: 'اسپم',
      harassment: 'آزار',
      inappropriate: 'نامناسب',
      fake: 'جعلی',
      violence: 'خشونت',
      hateSpeech: 'سخنان نفرت‌انگیز',
      noPostsYet: 'هنوز پستی نیست',
      startSharing: 'افکار خود را به اشتراک بگذارید!',
      edited: 'ویرایش شده',
      deleteConfirm: 'آیا مطمئن هستید که می‌خواهید حذف کنید؟',
      public: 'عمومی',
      friends: 'دوستان',
      private: 'خصوصی',
      addImage: 'افزودن عکس',
      removeImage: 'حذف عکس',
      viewAllComments: 'مشاهده همه نظرات',
      viewProfile: 'مشاهده پروفایل',
      reply: 'پاسخ',
      replies: 'پاسخ‌ها',
      seeMore: 'بیشتر',
      seeLess: 'کمتر',
      andOthers: 'و دیگران',
      reactedTo: 'واکنش نشان داد',
      commentedOn: 'نظر داد',
      sharedPost: 'پست را به اشتراک گذاشت'
    },
    en: {
      whatsOnMind: "What's on your mind, {name}?",
      createPost: 'Create Post',
      post: 'Post',
      update: 'Update',
      cancel: 'Cancel',
      addPhotos: 'Photos',
      location: 'Location',
      feeling: 'Feeling',
      tagPeople: 'Tag People',
      like: 'Like',
      love: 'Love',
      haha: 'Haha',
      wow: 'Wow',
      sad: 'Sad',
      angry: 'Angry',
      comment: 'Comment',
      share: 'Share',
      reactions: 'Reactions',
      comments: 'Comments',
      shares: 'Shares',
      writeComment: 'Write a comment...',
      writeReply: 'Write a reply...',
      send: 'Send',
      report: 'Report',
      delete: 'Delete',
      edit: 'Edit',
      save: 'Save',
      view: 'View',
      hide: 'Hide',
      justNow: 'Just now',
      minutesAgo: 'minutes ago',
      hoursAgo: 'hours ago',
      daysAgo: 'days ago',
      weeksAgo: 'weeks ago',
      verified: 'Verified',
      owner: 'Owner',
      reportPost: 'Report Post',
      reportReason: 'Report Reason',
      submitReport: 'Submit Report',
      spam: 'Spam',
      harassment: 'Harassment',
      inappropriate: 'Inappropriate',
      fake: 'Fake',
      violence: 'Violence',
      hateSpeech: 'Hate Speech',
      noPostsYet: 'No posts yet',
      startSharing: 'Start sharing your thoughts!',
      edited: 'Edited',
      deleteConfirm: 'Are you sure you want to delete?',
      public: 'Public',
      friends: 'Friends',
      private: 'Private',
      addImage: 'Add Image',
      removeImage: 'Remove Image',
      viewAllComments: 'View all comments',
      viewProfile: 'View Profile',
      reply: 'Reply',
      replies: 'Replies',
      seeMore: 'See more',
      seeLess: 'See less',
      andOthers: 'and others',
      reactedTo: 'reacted to this',
      commentedOn: 'commented on this',
      sharedPost: 'shared this post'
    }
  };

  const text = t[language];

  const reactionEmojis: Record<ReactionType, string> = {
    like: '👍',
    love: '❤️',
    haha: '😂',
    wow: '😮',
    sad: '😢',
    angry: '😠'
  };

  useEffect(() => {
    loadPosts();
  }, []);

  const loadPosts = () => {
    const savedPosts = JSON.parse(localStorage.getItem('healmate_posts') || '[]');
    setPosts(savedPosts.sort((a: Post, b: Post) => 
      new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()
    ));
  };

  const handleCreatePost = () => {
    if (!newPostContent.trim() && newPostImages.length === 0) return;

    const isOwnerPost = currentUserName.includes('Ibrahim') || currentUserName.includes('ابراهیم');

    const newPost: Post = {
      id: Date.now().toString(),
      userId: currentUserId,
      userName: currentUserName,
      userImage: currentUserImage,
      verified: isOwnerPost,
      isOwner: isOwnerPost,
      content: newPostContent,
      images: newPostImages,
      reactions: [],
      comments: [],
      shares: 0,
      timestamp: new Date().toISOString(),
      privacy: postPrivacy,
      edited: false
    };

    const updatedPosts = [newPost, ...posts];
    setPosts(updatedPosts);
    localStorage.setItem('healmate_posts', JSON.stringify(updatedPosts));

    // Update user's post count
    const users = JSON.parse(localStorage.getItem('healmate_users_data') || '[]');
    const userIndex = users.findIndex((u: any) => u.id === currentUserId);
    if (userIndex !== -1) {
      users[userIndex].posts = (users[userIndex].posts || 0) + 1;
      localStorage.setItem('healmate_users_data', JSON.stringify(users));
    }

    setNewPostContent('');
    setNewPostImages([]);
    setImagePreviewUrls([]);
    setShowCreatePost(false);
  };

  const handleReaction = (postId: string, type: ReactionType) => {
    const updatedPosts = posts.map(post => {
      if (post.id === postId) {
        const existingReaction = post.reactions.find(r => r.userId === currentUserId);
        
        if (existingReaction) {
          if (existingReaction.type === type) {
            // Remove reaction
            return {
              ...post,
              reactions: post.reactions.filter(r => r.userId !== currentUserId)
            };
          } else {
            // Change reaction
            return {
              ...post,
              reactions: post.reactions.map(r => 
                r.userId === currentUserId ? { ...r, type } : r
              )
            };
          }
        } else {
          // Add reaction
          return {
            ...post,
            reactions: [...post.reactions, { userId: currentUserId, type }]
          };
        }
      }
      return post;
    });
    
    setPosts(updatedPosts);
    localStorage.setItem('healmate_posts', JSON.stringify(updatedPosts));
    setShowReactions(null);
  };

  const handleComment = (postId: string, replyToId?: string) => {
    if (!commentText.trim()) return;

    const newComment: Comment = {
      id: Date.now().toString(),
      userId: currentUserId,
      userName: currentUserName,
      userImage: currentUserImage,
      content: commentText,
      timestamp: new Date().toISOString(),
      likes: [],
      replies: []
    };

    const updatedPosts = posts.map(post => {
      if (post.id === postId) {
        if (replyToId) {
          // Add reply to comment
          const addReply = (comments: Comment[]): Comment[] => {
            return comments.map(c => {
              if (c.id === replyToId) {
                return { ...c, replies: [...c.replies, newComment] };
              }
              if (c.replies.length > 0) {
                return { ...c, replies: addReply(c.replies) };
              }
              return c;
            });
          };
          return { ...post, comments: addReply(post.comments) };
        } else {
          return { ...post, comments: [...post.comments, newComment] };
        }
      }
      return post;
    });

    setPosts(updatedPosts);
    localStorage.setItem('healmate_posts', JSON.stringify(updatedPosts));
    setCommentText('');
  };

  const handleDeletePost = (postId: string) => {
    if (confirm(text.deleteConfirm)) {
      const updatedPosts = posts.filter(post => post.id !== postId);
      setPosts(updatedPosts);
      localStorage.setItem('healmate_posts', JSON.stringify(updatedPosts));
      setShowPostMenu(null);
    }
  };

  const handleEditPost = (post: Post) => {
    setEditingPost(post);
    setNewPostContent(post.content);
    setNewPostImages(post.images);
    setShowCreatePost(true);
    setShowPostMenu(null);
  };

  const handleUpdatePost = () => {
    if (!editingPost) return;

    const updatedPosts = posts.map(post => {
      if (post.id === editingPost.id) {
        return {
          ...post,
          content: newPostContent,
          images: newPostImages,
          edited: true
        };
      }
      return post;
    });

    setPosts(updatedPosts);
    localStorage.setItem('healmate_posts', JSON.stringify(updatedPosts));
    
    setEditingPost(null);
    setNewPostContent('');
    setNewPostImages([]);
    setImagePreviewUrls([]);
    setShowCreatePost(false);
  };

  const handleReportPost = (postId: string, reason: string) => {
    const reports = JSON.parse(localStorage.getItem('healmate_post_reports') || '[]');
    reports.push({
      reporterId: currentUserId,
      postId,
      reason,
      timestamp: new Date().toISOString()
    });
    localStorage.setItem('healmate_post_reports', JSON.stringify(reports));
    setShowReportModal(false);
    alert(language === 'ps' ? 'ریپورټ واستول شو' : language === 'fa' ? 'گزارش ارسال شد' : 'Report submitted');
  };

  const handleImageAdd = () => {
    const url = prompt(language === 'ps' ? 'د عکس URL دننه کړئ' : language === 'fa' ? 'URL تصویر را وارد کنید' : 'Enter image URL');
    if (url) {
      setNewPostImages([...newPostImages, url]);
      setImagePreviewUrls([...imagePreviewUrls, url]);
    }
  };

  const handleImageRemove = (index: number) => {
    setNewPostImages(newPostImages.filter((_, i) => i !== index));
    setImagePreviewUrls(imagePreviewUrls.filter((_, i) => i !== index));
  };

  const getTimeAgo = (timestamp: string) => {
    const now = new Date();
    const postTime = new Date(timestamp);
    const diffMs = now.getTime() - postTime.getTime();
    const diffMins = Math.floor(diffMs / 60000);
    const diffHours = Math.floor(diffMs / 3600000);
    const diffDays = Math.floor(diffMs / 86400000);
    const diffWeeks = Math.floor(diffMs / 604800000);

    if (diffMins < 1) return text.justNow;
    if (diffMins < 60) return `${diffMins} ${text.minutesAgo}`;
    if (diffHours < 24) return `${diffHours} ${text.hoursAgo}`;
    if (diffDays < 7) return `${diffDays} ${text.daysAgo}`;
    return `${diffWeeks} ${text.weeksAgo}`;
  };

  const getReactionCounts = (reactions: Reaction[]) => {
    const counts: Record<ReactionType, number> = {
      like: 0,
      love: 0,
      haha: 0,
      wow: 0,
      sad: 0,
      angry: 0
    };
    reactions.forEach(r => counts[r.type]++);
    return counts;
  };

  const getTopReactions = (reactions: Reaction[]) => {
    const counts = getReactionCounts(reactions);
    return Object.entries(counts)
      .filter(([_, count]) => count > 0)
      .sort(([_, a], [__, b]) => b - a)
      .slice(0, 3)
      .map(([type]) => type as ReactionType);
  };

  const hasUserReacted = (reactions: Reaction[]) => {
    return reactions.find(r => r.userId === currentUserId);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 via-blue-50 to-purple-50 pb-28 md:pb-8">
      <div className="container mx-auto px-4 py-6 max-w-2xl">
        {/* Create Post Card */}
        <div className="bg-white rounded-2xl shadow-md p-4 mb-4">
          <div className="flex gap-3 mb-3">
            <div className="w-10 h-10 rounded-full overflow-hidden flex-shrink-0">
              <ImageWithFallback
                src={currentUserImage}
                alt={currentUserName}
                className="w-full h-full object-cover"
              />
            </div>
            <button
              onClick={() => setShowCreatePost(true)}
              className="flex-1 text-left px-4 py-2.5 bg-gray-100 hover:bg-gray-200 rounded-full transition-all"
            >
              <span className="text-gray-500">
                {text.whatsOnMind.replace('{name}', currentUserName.split(' ')[0])}
              </span>
            </button>
          </div>

          <div className="flex gap-1 pt-2 border-t border-gray-200">
            <button className="flex-1 flex items-center justify-center gap-2 p-2 hover:bg-gray-100 rounded-lg transition-all">
              <ImageIcon className="w-5 h-5 text-green-500" />
              <span className="text-sm text-gray-600">{text.addPhotos}</span>
            </button>
            <button className="flex-1 flex items-center justify-center gap-2 p-2 hover:bg-gray-100 rounded-lg transition-all">
              <Smile className="w-5 h-5 text-yellow-500" />
              <span className="text-sm text-gray-600">{text.feeling}</span>
            </button>
            <button className="flex-1 flex items-center justify-center gap-2 p-2 hover:bg-gray-100 rounded-lg transition-all">
              <MapPin className="w-5 h-5 text-red-500" />
              <span className="text-sm text-gray-600">{text.location}</span>
            </button>
          </div>
        </div>

        {/* Posts Feed */}
        <AnimatePresence>
          {posts.length === 0 ? (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="bg-white rounded-2xl shadow-md p-12 text-center"
            >
              <MessageCircle className="w-16 h-16 text-gray-300 mx-auto mb-4" />
              <h3 className="text-xl mb-2 text-gray-700">{text.noPostsYet}</h3>
              <p className="text-gray-500">{text.startSharing}</p>
            </motion.div>
          ) : (
            posts.map((post, index) => {
              const userReaction = hasUserReacted(post.reactions);
              const topReactions = getTopReactions(post.reactions);
              
              return (
                <motion.div
                  key={post.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.05 }}
                  className="bg-white rounded-2xl shadow-md p-4 mb-4"
                >
                  {/* Post Header */}
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex items-center gap-3">
                      <div
                        onClick={() => onViewProfile(post.userId)}
                        className="w-10 h-10 rounded-full overflow-hidden cursor-pointer"
                      >
                        <ImageWithFallback
                          src={post.userImage}
                          alt={post.userName}
                          className="w-full h-full object-cover"
                        />
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                          <span
                            onClick={() => onViewProfile(post.userId)}
                            className="font-medium hover:underline cursor-pointer"
                          >
                            {post.userName}
                          </span>
                          {post.verified && (
                            <div className="bg-blue-500 text-white p-0.5 rounded-full">
                              <Check className="w-3 h-3" />
                            </div>
                          )}
                          {post.isOwner && (
                            <span className="px-2 py-0.5 bg-gradient-to-r from-red-500 to-pink-500 text-white text-xs rounded-full">
                              {text.owner}
                            </span>
                          )}
                        </div>
                        <div className="flex items-center gap-2 text-xs text-gray-500">
                          <span>{getTimeAgo(post.timestamp)}</span>
                          {post.edited && <span>• {text.edited}</span>}
                          <span>•</span>
                          {post.privacy === 'public' ? (
                            <Globe className="w-3 h-3" />
                          ) : post.privacy === 'friends' ? (
                            <Users className="w-3 h-3" />
                          ) : (
                            <Lock className="w-3 h-3" />
                          )}
                        </div>
                      </div>
                    </div>

                    {/* Post Menu */}
                    <div className="relative">
                      <button
                        onClick={() => setShowPostMenu(showPostMenu === post.id ? null : post.id)}
                        className="p-2 hover:bg-gray-100 rounded-full transition-all"
                      >
                        <MoreVertical className="w-5 h-5 text-gray-600" />
                      </button>
                      
                      {showPostMenu === post.id && (
                        <div className="absolute right-0 mt-2 w-48 bg-white rounded-xl shadow-xl border border-gray-200 py-2 z-10">
                          {post.userId === currentUserId && (
                            <>
                              <button
                                onClick={() => handleEditPost(post)}
                                className="w-full px-4 py-2 text-left hover:bg-gray-100 flex items-center gap-3"
                              >
                                <Edit2 className="w-4 h-4" />
                                {text.edit}
                              </button>
                              <button
                                onClick={() => handleDeletePost(post.id)}
                                className="w-full px-4 py-2 text-left hover:bg-gray-100 flex items-center gap-3 text-red-600"
                              >
                                <Trash2 className="w-4 h-4" />
                                {text.delete}
                              </button>
                            </>
                          )}
                          <button
                            onClick={() => {
                              setReportPostId(post.id);
                              setShowReportModal(true);
                              setShowPostMenu(null);
                            }}
                            className="w-full px-4 py-2 text-left hover:bg-gray-100 flex items-center gap-3"
                          >
                            <Flag className="w-4 h-4" />
                            {text.report}
                          </button>
                        </div>
                      )}
                    </div>
                  </div>

                  {/* Post Content */}
                  {post.content && (
                    <p className="mb-3 whitespace-pre-wrap">{post.content}</p>
                  )}

                  {/* Post Images */}
                  {post.images.length > 0 && (
                    <div className={`grid gap-1 mb-3 ${
                      post.images.length === 1 ? 'grid-cols-1' :
                      post.images.length === 2 ? 'grid-cols-2' :
                      post.images.length === 3 ? 'grid-cols-3' :
                      'grid-cols-2'
                    }`}>
                      {post.images.slice(0, 4).map((img, idx) => (
                        <div
                          key={idx}
                          className={`relative rounded-lg overflow-hidden ${
                            post.images.length === 3 && idx === 0 ? 'col-span-2' : ''
                          }`}
                        >
                          <ImageWithFallback
                            src={img}
                            alt={`Post image ${idx + 1}`}
                            className="w-full h-64 object-cover"
                          />
                          {idx === 3 && post.images.length > 4 && (
                            <div className="absolute inset-0 bg-black/50 flex items-center justify-center">
                              <span className="text-white text-2xl">+{post.images.length - 4}</span>
                            </div>
                          )}
                        </div>
                      ))}
                    </div>
                  )}

                  {/* Reactions & Counts Bar */}
                  {(post.reactions.length > 0 || post.comments.length > 0 || post.shares > 0) && (
                    <div className="flex items-center justify-between py-2 text-sm text-gray-600 border-t border-b border-gray-200">
                      <div className="flex items-center gap-2">
                        {topReactions.length > 0 && (
                          <div className="flex -space-x-1">
                            {topReactions.map(type => (
                              <span key={type} className="text-lg">{reactionEmojis[type]}</span>
                            ))}
                          </div>
                        )}
                        {post.reactions.length > 0 && (
                          <span>{post.reactions.length}</span>
                        )}
                      </div>
                      <div className="flex gap-4">
                        {post.comments.length > 0 && (
                          <button
                            onClick={() => setSelectedPost(post)}
                            className="hover:underline"
                          >
                            {post.comments.length} {text.comments}
                          </button>
                        )}
                        {post.shares > 0 && (
                          <span>{post.shares} {text.shares}</span>
                        )}
                      </div>
                    </div>
                  )}

                  {/* Action Buttons */}
                  <div className="flex gap-1 mt-2">
                    <div className="relative flex-1">
                      <button
                        onMouseEnter={() => setShowReactions(post.id)}
                        onMouseLeave={() => setShowReactions(null)}
                        onClick={() => handleReaction(post.id, 'like')}
                        className={`w-full flex items-center justify-center gap-2 p-2 rounded-lg transition-all ${
                          userReaction
                            ? 'text-blue-600 font-medium'
                            : 'hover:bg-gray-100'
                        }`}
                      >
                        {userReaction ? (
                          <>
                            <span className="text-lg">{reactionEmojis[userReaction.type]}</span>
                            <span className="text-sm">{text[userReaction.type]}</span>
                          </>
                        ) : (
                          <>
                            <ThumbsUp className="w-5 h-5" />
                            <span className="text-sm">{text.like}</span>
                          </>
                        )}
                      </button>
                      
                      {/* Reactions Popup */}
                      {showReactions === post.id && (
                        <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-2 bg-white rounded-full shadow-xl border border-gray-200 px-2 py-2 flex gap-1">
                          {(Object.keys(reactionEmojis) as ReactionType[]).map(type => (
                            <button
                              key={type}
                              onClick={() => handleReaction(post.id, type)}
                              className="text-2xl hover:scale-125 transition-transform"
                            >
                              {reactionEmojis[type]}
                            </button>
                          ))}
                        </div>
                      )}
                    </div>
                    
                    <button
                      onClick={() => setSelectedPost(post)}
                      className="flex-1 flex items-center justify-center gap-2 p-2 hover:bg-gray-100 rounded-lg transition-all"
                    >
                      <MessageCircle className="w-5 h-5" />
                      <span className="text-sm">{text.comment}</span>
                    </button>
                    
                    <button 
                      onClick={() => {
                        setSharingPost(post);
                        setShareModalOpen(true);
                        setPosts(posts.map(p => p.id === post.id ? {...p, shares: p.shares + 1} : p));
                      }}
                      className="flex-1 flex items-center justify-center gap-2 p-2 hover:bg-gray-100 rounded-lg transition-all"
                    >
                      <Share2 className="w-5 h-5" />
                      <span className="text-sm">{text.share}</span>
                    </button>
                  </div>

                  {/* Quick Comments Preview */}
                  {post.comments.length > 0 && (
                    <div className="mt-3 space-y-2">
                      {post.comments.slice(0, 2).map((comment) => (
                        <div key={comment.id} className="flex gap-2">
                          <div className="w-8 h-8 rounded-full overflow-hidden flex-shrink-0">
                            <ImageWithFallback
                              src={comment.userImage}
                              alt={comment.userName}
                              className="w-full h-full object-cover"
                            />
                          </div>
                          <div className="flex-1">
                            <div className="bg-gray-100 rounded-2xl px-3 py-2">
                              <div className="font-medium text-sm">{comment.userName}</div>
                              <p className="text-sm">{comment.content}</p>
                            </div>
                            <div className="flex items-center gap-3 px-3 mt-1">
                              <button className="text-xs text-gray-500 hover:underline">
                                {text.like}
                              </button>
                              <button className="text-xs text-gray-500 hover:underline">
                                {text.reply}
                              </button>
                              <span className="text-xs text-gray-500">{getTimeAgo(comment.timestamp)}</span>
                            </div>
                          </div>
                        </div>
                      ))}
                      {post.comments.length > 2 && (
                        <button
                          onClick={() => setSelectedPost(post)}
                          className="text-sm text-gray-600 hover:underline pl-10"
                        >
                          {text.viewAllComments} ({post.comments.length})
                        </button>
                      )}
                    </div>
                  )}
                </motion.div>
              );
            })
          )}
        </AnimatePresence>
      </div>

      {/* Create/Edit Post Modal */}
      <AnimatePresence>
        {showCreatePost && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4"
            onClick={() => {
              setShowCreatePost(false);
              setEditingPost(null);
              setNewPostContent('');
              setNewPostImages([]);
              setImagePreviewUrls([]);
            }}
          >
            <motion.div
              initial={{ scale: 0.9, y: 20 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.9, y: 20 }}
              onClick={(e) => e.stopPropagation()}
              className="bg-white rounded-2xl w-full max-w-xl max-h-[90vh] overflow-y-auto"
            >
              {/* Header */}
              <div className="flex items-center justify-between p-4 border-b border-gray-200">
                <h2 className="text-xl">{editingPost ? text.update : text.createPost}</h2>
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => {
                    setShowCreatePost(false);
                    setEditingPost(null);
                    setNewPostContent('');
                    setNewPostImages([]);
                  }}
                >
                  <X className="w-5 h-5" />
                </Button>
              </div>

              {/* User Info */}
              <div className="flex items-center gap-3 p-4">
                <div className="w-10 h-10 rounded-full overflow-hidden">
                  <ImageWithFallback
                    src={currentUserImage}
                    alt={currentUserName}
                    className="w-full h-full object-cover"
                  />
                </div>
                <div>
                  <div className="font-medium">{currentUserName}</div>
                  <button className="flex items-center gap-1 text-xs text-gray-600 bg-gray-100 px-2 py-1 rounded">
                    {postPrivacy === 'public' ? <Globe className="w-3 h-3" /> : 
                     postPrivacy === 'friends' ? <Users className="w-3 h-3" /> : 
                     <Lock className="w-3 h-3" />}
                    <span>{text[postPrivacy]}</span>
                    <ChevronDown className="w-3 h-3" />
                  </button>
                </div>
              </div>

              {/* Content */}
              <div className="p-4">
                <Textarea
                  placeholder={text.whatsOnMind.replace('{name}', currentUserName.split(' ')[0])}
                  value={newPostContent}
                  onChange={(e) => setNewPostContent(e.target.value)}
                  className="min-h-32 border-none shadow-none focus-visible:ring-0 text-lg resize-none"
                  dir={language === 'en' ? 'ltr' : 'rtl'}
                  autoFocus
                />

                {/* Image Previews */}
                {imagePreviewUrls.length > 0 && (
                  <div className="grid grid-cols-2 gap-2 mt-4">
                    {imagePreviewUrls.map((url, index) => (
                      <div key={index} className="relative rounded-lg overflow-hidden">
                        <ImageWithFallback
                          src={url}
                          alt={`Preview ${index + 1}`}
                          className="w-full h-40 object-cover"
                        />
                        <button
                          onClick={() => handleImageRemove(index)}
                          className="absolute top-2 right-2 bg-white/90 p-1.5 rounded-full hover:bg-white"
                        >
                          <X className="w-4 h-4" />
                        </button>
                      </div>
                    ))}
                  </div>
                )}

                {/* Add to Post */}
                <div className="mt-4 p-3 border border-gray-200 rounded-lg">
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium">{language === 'ps' ? 'پوست ته اضافه کړئ' : language === 'fa' ? 'افزودن به پست' : 'Add to post'}</span>
                    <div className="flex gap-2">
                      <button
                        onClick={handleImageAdd}
                        className="p-2 hover:bg-gray-100 rounded-full"
                      >
                        <ImageIcon className="w-5 h-5 text-green-500" />
                      </button>
                      <button className="p-2 hover:bg-gray-100 rounded-full">
                        <Smile className="w-5 h-5 text-yellow-500" />
                      </button>
                      <button className="p-2 hover:bg-gray-100 rounded-full">
                        <MapPin className="w-5 h-5 text-red-500" />
                      </button>
                      <button className="p-2 hover:bg-gray-100 rounded-full">
                        <Users className="w-5 h-5 text-blue-500" />
                      </button>
                    </div>
                  </div>
                </div>
              </div>

              {/* Footer */}
              <div className="p-4 border-t border-gray-200">
                <Button
                  onClick={editingPost ? handleUpdatePost : handleCreatePost}
                  disabled={!newPostContent.trim() && newPostImages.length === 0}
                  className="w-full bg-blue-500 hover:bg-blue-600 text-white"
                >
                  {editingPost ? text.update : text.post}
                </Button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Comments Modal */}
      <AnimatePresence>
        {selectedPost && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4"
            onClick={() => setSelectedPost(null)}
          >
            <motion.div
              initial={{ scale: 0.9, y: 50 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.9, y: 50 }}
              onClick={(e) => e.stopPropagation()}
              className="bg-white rounded-2xl w-full max-w-2xl max-h-[90vh] overflow-y-auto"
            >
              {/* Header */}
              <div className="flex items-center justify-between p-4 border-b border-gray-200 sticky top-0 bg-white">
                <h3 className="text-xl">{selectedPost.userName}{language === 'ps' ? ' پوست' : language === 'fa' ? ' پست ' : "'s post"}</h3>
                <Button variant="ghost" size="icon" onClick={() => setSelectedPost(null)}>
                  <X className="w-5 h-5" />
                </Button>
              </div>

              {/* All Comments */}
              <div className="p-4 space-y-4">
                {selectedPost.comments.map((comment) => (
                  <div key={comment.id} className="flex gap-3">
                    <div className="w-10 h-10 rounded-full overflow-hidden flex-shrink-0">
                      <ImageWithFallback
                        src={comment.userImage}
                        alt={comment.userName}
                        className="w-full h-full object-cover"
                      />
                    </div>
                    <div className="flex-1">
                      <div className="bg-gray-100 rounded-2xl px-4 py-3">
                        <div className="font-medium mb-1">{comment.userName}</div>
                        <p className="text-sm">{comment.content}</p>
                      </div>
                      <div className="flex items-center gap-4 px-4 mt-2">
                        <button className="text-xs text-gray-600 hover:underline font-medium">
                          {text.like}
                        </button>
                        <button className="text-xs text-gray-600 hover:underline font-medium">
                          {text.reply}
                        </button>
                        <span className="text-xs text-gray-500">{getTimeAgo(comment.timestamp)}</span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>

              {/* Comment Input */}
              <div className="flex gap-3 p-4 border-t border-gray-200 sticky bottom-0 bg-white">
                <div className="w-8 h-8 rounded-full overflow-hidden flex-shrink-0">
                  <ImageWithFallback
                    src={currentUserImage}
                    alt={currentUserName}
                    className="w-full h-full object-cover"
                  />
                </div>
                <div className="flex-1 flex gap-2">
                  <Input
                    placeholder={text.writeComment}
                    value={commentText}
                    onChange={(e) => setCommentText(e.target.value)}
                    className="flex-1 rounded-full"
                    dir={language === 'en' ? 'ltr' : 'rtl'}
                    onKeyPress={(e) => {
                      if (e.key === 'Enter' && !e.shiftKey) {
                        e.preventDefault();
                        handleComment(selectedPost.id);
                      }
                    }}
                  />
                  <Button
                    onClick={() => handleComment(selectedPost.id)}
                    disabled={!commentText.trim()}
                    size="icon"
                    className="rounded-full bg-blue-500 hover:bg-blue-600"
                  >
                    <Send className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Report Modal */}
      <AnimatePresence>
        {showReportModal && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4"
            onClick={() => setShowReportModal(false)}
          >
            <motion.div
              initial={{ scale: 0.9 }}
              animate={{ scale: 1 }}
              exit={{ scale: 0.9 }}
              onClick={(e) => e.stopPropagation()}
              className="bg-white rounded-2xl p-6 max-w-md w-full"
            >
              <h3 className="text-2xl mb-4">{text.reportPost}</h3>
              <p className="text-gray-600 mb-4">{text.reportReason}</p>
              
              <div className="space-y-2">
                {[
                  { key: 'spam', label: text.spam },
                  { key: 'harassment', label: text.harassment },
                  { key: 'inappropriate', label: text.inappropriate },
                  { key: 'fake', label: text.fake },
                  { key: 'violence', label: text.violence },
                  { key: 'hateSpeech', label: text.hateSpeech }
                ].map((reason) => (
                  <button
                    key={reason.key}
                    onClick={() => handleReportPost(reportPostId, reason.key)}
                    className="w-full p-4 text-left border border-gray-200 rounded-xl hover:bg-gray-50 transition-all"
                  >
                    {reason.label}
                  </button>
                ))}
              </div>
              
              <Button
                variant="outline"
                className="w-full mt-4"
                onClick={() => setShowReportModal(false)}
              >
                {text.cancel}
              </Button>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Share Modal */}
      <ShareModal
        isOpen={shareModalOpen}
        onClose={() => {
          setShareModalOpen(false);
          setSharingPost(null);
        }}
        language={language}
        shareContent={{
          title: sharingPost ? `${sharingPost.userName}: ${sharingPost.content.slice(0, 100)}...` : 'HealMate Post',
          description: sharingPost?.content || '',
          url: window.location.href
        }}
      />
    </div>
  );
}
