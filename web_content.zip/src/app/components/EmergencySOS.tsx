import { motion } from 'motion/react';
import { AlertCircle, Phone, MapPin, Users, Heart, Ambulance, Shield, X, Activity, MessageCircle } from 'lucide-react';
import { useState } from 'react';

interface EmergencySOSProps {
  language: 'ps' | 'fa' | 'en';
  onBack?: () => void;
}

export function EmergencySOS({ language, onBack }: EmergencySOSProps) {
  const [isEmergency, setIsEmergency] = useState(false);
  const [countdown, setCountdown] = useState(5);
  const [sharingLocation, setSharingLocation] = useState(false);

  const translations = {
    ps: {
      title: 'بیړني طبي مرسته',
      subtitle: 'د بیړني حالت په وخت کې مرسته ترلاسه کړئ',
      emergency: 'بیړنی حالت',
      ambulance: 'امبولانس وغواړئ',
      hospital: 'نږدې روغتون',
      police: 'پولیس',
      fire: 'اور وژونکي',
      helpline: 'د مرستې شمیره',
      warning: '⚠️ یوازې د ریښتیني بیړني حالت لپاره استعمال کړئ',
      calling: 'بیړني شمیره ته زنګ کیږي...',
      cancel: 'لغوه کول',
      confirm: 'تایید کړئ',
      location: 'ستاسو موقعیت شریک کیږي',
      contacts: 'د بیړني اړیکې',
      myInfo: 'زما طبي معلومات'
    },
    fa: {
      title: 'کمک پزشکی اضطراری',
      subtitle: 'در مواقع اضطراری کمک دریافت کنید',
      emergency: 'اضطراری',
      ambulance: 'درخواست آمبولانس',
      hospital: 'بیمارستان نزدیک',
      police: 'پولیس',
      fire: 'آتش نشانی',
      helpline: 'شماره کمک',
      warning: '⚠️ فقط برای موارد اضطراری واقعی استفاده کنید',
      calling: 'در حال تماس با شماره اضطراری...',
      cancel: 'لغو',
      confirm: 'تایید',
      location: 'موقعیت شما به اشتراک گذاشته می‌شود',
      contacts: 'مخاطبین اضطراری',
      myInfo: 'اطلاعات پزشکی من'
    },
    en: {
      title: 'Emergency Medical Help',
      subtitle: 'Get help in emergency situations',
      emergency: 'Emergency',
      ambulance: 'Call Ambulance',
      hospital: 'Nearest Hospital',
      police: 'Police',
      fire: 'Fire Department',
      helpline: 'Helpline',
      warning: '⚠️ Use only for real emergencies',
      calling: 'Calling emergency number...',
      cancel: 'Cancel',
      confirm: 'Confirm',
      location: 'Your location will be shared',
      contacts: 'Emergency Contacts',
      myInfo: 'My Medical Info'
    }
  };

  const t = translations[language];

  const emergencyNumbers = [
    {
      id: 'ambulance',
      icon: Ambulance,
      label: t.ambulance,
      number: '102',
      color: 'from-red-500 to-rose-600',
      bgColor: 'bg-red-50',
      borderColor: 'border-red-200'
    },
    {
      id: 'whatsapp',
      icon: MessageCircle,
      label: language === 'ps' ? 'واتساپ مرسته' : language === 'fa' ? 'کمک واتساپ' : 'WhatsApp Help',
      number: '+93779494512',
      color: 'from-green-500 to-emerald-600',
      bgColor: 'bg-green-50',
      borderColor: 'border-green-200',
      isWhatsApp: true
    },
    {
      id: 'police',
      icon: Shield,
      label: t.police,
      number: '100',
      color: 'from-blue-500 to-cyan-600',
      bgColor: 'bg-blue-50',
      borderColor: 'border-blue-200'
    },
    {
      id: 'fire',
      icon: AlertCircle,
      label: t.fire,
      number: '101',
      color: 'from-orange-500 to-amber-600',
      bgColor: 'bg-orange-50',
      borderColor: 'border-orange-200'
    },
    {
      id: 'hospital',
      icon: Heart,
      label: t.hospital,
      number: language === 'ps' ? 'موندل' : language === 'fa' ? 'یافتن' : 'Find',
      color: 'from-purple-500 to-violet-600',
      bgColor: 'bg-purple-50',
      borderColor: 'border-purple-200'
    }
  ];

  const handleEmergencyCall = (number: string, isWhatsApp?: boolean) => {
    if (number === 'موندل' || number === 'یافتن' || number === 'Find') {
      // Find nearest hospital logic
      alert(language === 'ps' ? 'د نږدې روغتون موندل...' : language === 'fa' ? 'یافتن بیمارستان نزدیک...' : 'Finding nearest hospital...');
      return;
    }
    if (isWhatsApp) {
      window.open('https://wa.me/93779494512?text=Emergency! I need medical help!', '_blank');
      return;
    }
    setIsEmergency(true);
    let count = 5;
    const interval = setInterval(() => {
      count--;
      setCountdown(count);
      if (count === 0) {
        clearInterval(interval);
        window.location.href = `tel:${number}`;
        setIsEmergency(false);
        setCountdown(5);
      }
    }, 1000);
  };

  const handleShareLocation = () => {
    setSharingLocation(true);
    
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          const lat = position.coords.latitude;
          const lng = position.coords.longitude;
          const locationUrl = `https://www.google.com/maps?q=${lat},${lng}`;
          
          // Copy to clipboard
          navigator.clipboard.writeText(locationUrl).then(() => {
            alert(language === 'ps' 
              ? `✅ موقعیت کاپي شو!\n\nد شریک کولو لپاره WhatsApp ته لاړ شئ:\n${locationUrl}` 
              : language === 'fa' 
              ? `✅ موقعیت کپی شد!\n\nبرای اشتراک گذاری به واتساپ بروید:\n${locationUrl}`
              : `✅ Location copied!\n\nGo to WhatsApp to share:\n${locationUrl}`);
            
            // Open WhatsApp with location
            const message = language === 'ps' 
              ? `🚨 بیړنی حالت! زما موقعیت: ${locationUrl}`
              : language === 'fa'
              ? `🚨 اضطراری! موقعیت من: ${locationUrl}`
              : `🚨 Emergency! My location: ${locationUrl}`;
            window.open(`https://wa.me/93779494512?text=${encodeURIComponent(message)}`, '_blank');
          });
          setSharingLocation(false);
        },
        (error) => {
          alert(language === 'ps' 
            ? '❌ موقعیت ترلاسه نشو! مهرباني وکړئ د location اجازه ورکړئ.' 
            : language === 'fa'
            ? '❌ موقعیت دریافت نشد! لطفا اجازه موقعیت را بدهید.'
            : '❌ Could not get location! Please enable location permission.');
          setSharingLocation(false);
        },
        {
          enableHighAccuracy: true,
          timeout: 10000,
          maximumAge: 0
        }
      );
    } else {
      alert(language === 'ps' 
        ? '❌ ستاسو موبایل د موقعیت فیچر نه لري!' 
        : language === 'fa'
        ? '❌ موبایل شما قابلیت موقعیت ندارد!'
        : '❌ Your device does not support geolocation!');
      setSharingLocation(false);
    }
  };

  const handleEmergencyContacts = () => {
    alert(language === 'ps' 
      ? '📞 د بیړني اړیکې:\n\n1. امبولانس: 102\n2. پولیس: 100\n3. اور وژونکي: 101\n4. WhatsApp: +93779494512'
      : language === 'fa'
      ? '📞 مخاطبین اضطراری:\n\n1. آمبولانس: 102\n2. پولیس: 100\n3. آتش نشانی: 101\n4. واتساپ: +93779494512'
      : '📞 Emergency Contacts:\n\n1. Ambulance: 102\n2. Police: 100\n3. Fire: 101\n4. WhatsApp: +93779494512');
  };

  const handleMedicalInfo = () => {
    alert(language === 'ps' 
      ? '🏥 د طبي معلوماتو feature ډېر ژر راځي!\n\nتاسو به وکولای شئ:\n✅ د وینې ډول ثبت کړئ\n✅ الرجي معلومات\n✅ درملو لیست\n✅ د بیړني تماس شمېرې'
      : language === 'fa'
      ? '🏥 فیچر اطلاعات پزشکی بزودی!\n\nشما می‌توانید:\n✅ نوع خون ثبت کنید\n✅ اطلاعات آلرژی\n✅ لیست داروها\n✅ شماره‌های تماس اضطراری'
      : '🏥 Medical Info feature coming soon!\n\nYou will be able to:\n✅ Save blood type\n✅ Allergy information\n✅ Medication list\n✅ Emergency contact numbers');
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-red-50 via-orange-50 to-amber-50 pb-28 md:pb-8">
      {/* Close Button */}
      {onBack && (
        <div className="sticky top-0 z-50 bg-white/80 backdrop-blur-lg border-b border-red-200 p-4">
          <button
            onClick={onBack}
            className="flex items-center gap-2 text-gray-700 hover:text-red-600 transition-colors"
          >
            <X className="w-5 h-5" />
            <span>{t.cancel}</span>
          </button>
        </div>
      )}

      {/* Emergency Modal */}
      {isEmergency && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="fixed inset-0 bg-black/70 backdrop-blur-sm z-[100] flex items-center justify-center p-4"
        >
          <motion.div
            initial={{ scale: 0.8, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            className="bg-white rounded-3xl p-8 max-w-md w-full text-center"
          >
            <motion.div
              animate={{ scale: [1, 1.2, 1] }}
              transition={{ duration: 1, repeat: Infinity }}
              className="w-24 h-24 mx-auto mb-6 bg-gradient-to-br from-red-500 to-rose-600 rounded-full flex items-center justify-center"
            >
              <Phone className="w-12 h-12 text-white" />
            </motion.div>

            <h3 className="text-2xl font-bold text-gray-900 mb-2">{t.calling}</h3>
            <p className="text-gray-600 mb-6">{t.location}</p>

            <div className="text-6xl font-bold text-red-600 mb-8">{countdown}</div>

            <button
              onClick={() => {
                setIsEmergency(false);
                setCountdown(5);
              }}
              className="w-full bg-gradient-to-r from-gray-600 to-gray-700 text-white py-4 rounded-2xl font-semibold hover:shadow-lg transition-all"
            >
              {t.cancel}
            </button>
          </motion.div>
        </motion.div>
      )}

      <div className="container mx-auto px-4 py-8 max-w-4xl">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-8"
        >
          <div className="inline-flex items-center justify-center w-20 h-20 bg-gradient-to-br from-red-500 to-rose-600 rounded-3xl mb-4 shadow-lg">
            <AlertCircle className="w-10 h-10 text-white" />
          </div>
          <h1 className="text-3xl font-bold text-gray-900 mb-2">{t.title}</h1>
          <p className="text-gray-600">{t.subtitle}</p>
        </motion.div>

        {/* Warning Banner */}
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          className="bg-yellow-50 border-2 border-yellow-300 rounded-2xl p-4 mb-8 flex items-start gap-3"
        >
          <AlertCircle className="w-6 h-6 text-yellow-600 flex-shrink-0 mt-0.5" />
          <p className="text-yellow-800 font-medium">{t.warning}</p>
        </motion.div>

        {/* Emergency Buttons Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-8">
          {emergencyNumbers.map((item, index) => {
            const Icon = item.icon;
            return (
              <motion.button
                key={item.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                onClick={() => handleEmergencyCall(item.number, 'isWhatsApp' in item && item.isWhatsApp)}
                className={`${item.bgColor} border-2 ${item.borderColor} rounded-3xl p-6 text-left hover:shadow-xl transition-all group ${'isWhatsApp' in item && item.isWhatsApp ? 'animate-pulse' : ''}`}
              >
                <div className="flex items-start justify-between mb-4">
                  <div className={`p-4 bg-gradient-to-br ${item.color} rounded-2xl group-hover:scale-110 transition-transform`}>
                    <Icon className="w-8 h-8 text-white" />
                  </div>
                  <Phone className="w-6 h-6 text-gray-400 group-hover:text-red-600 transition-colors" />
                </div>
                <h3 className="text-xl font-bold text-gray-900 mb-1">{item.label}</h3>
                <p className={`text-3xl font-bold bg-gradient-to-r ${item.color} bg-clip-text text-transparent`}>
                  {item.number}
                </p>
              </motion.button>
            );
          })}
        </div>

        {/* Quick Actions */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <motion.button
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.5 }}
            onClick={handleShareLocation}
            disabled={sharingLocation}
            whileHover={{ scale: 1.02, y: -4 }}
            whileTap={{ scale: 0.98 }}
            className="bg-white border-2 border-teal-200 rounded-2xl p-6 hover:shadow-xl hover:border-teal-400 transition-all cursor-pointer text-left disabled:opacity-50 disabled:cursor-not-allowed"
          >
            <div className="flex items-center gap-3 mb-3">
              <div className="p-3 bg-gradient-to-br from-teal-500 to-cyan-600 rounded-xl">
                <MapPin className="w-6 h-6 text-white" />
              </div>
              <h3 className="font-bold text-gray-900">
                {sharingLocation ? (language === 'ps' ? 'منتظر شئ...' : language === 'fa' ? 'صبر کنید...' : 'Loading...') : t.location}
              </h3>
            </div>
            <p className="text-sm text-gray-600">
              {language === 'ps' ? '📍 خپل موقعیت شریک کړئ' : language === 'fa' ? '📍 موقعیت خود را به اشتراک بگذارید' : '📍 Share your location'}
            </p>
          </motion.button>

          <motion.button
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.6 }}
            onClick={handleEmergencyContacts}
            whileHover={{ scale: 1.02, y: -4 }}
            whileTap={{ scale: 0.98 }}
            className="bg-white border-2 border-purple-200 rounded-2xl p-6 hover:shadow-xl hover:border-purple-400 transition-all cursor-pointer text-left"
          >
            <div className="flex items-center gap-3 mb-3">
              <div className="p-3 bg-gradient-to-br from-indigo-500 to-purple-600 rounded-xl">
                <Users className="w-6 h-6 text-white" />
              </div>
              <h3 className="font-bold text-gray-900">{t.contacts}</h3>
            </div>
            <p className="text-sm text-gray-600">
              {language === 'ps' ? '☎️ د بیړني اړیکې' : language === 'fa' ? '��️ مخاطبین اضطراری' : '☎️ Emergency contacts'}
            </p>
          </motion.button>

          <motion.button
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.7 }}
            onClick={handleMedicalInfo}
            whileHover={{ scale: 1.02, y: -4 }}
            whileTap={{ scale: 0.98 }}
            className="bg-white border-2 border-pink-200 rounded-2xl p-6 hover:shadow-xl hover:border-pink-400 transition-all cursor-pointer text-left"
          >
            <div className="flex items-center gap-3 mb-3">
              <div className="p-3 bg-gradient-to-br from-pink-500 to-rose-600 rounded-xl">
                <Activity className="w-6 h-6 text-white" />
              </div>
              <h3 className="font-bold text-gray-900">{t.myInfo}</h3>
            </div>
            <p className="text-sm text-gray-600">
              {language === 'ps' ? '🏥 طبي معلومات' : language === 'fa' ? '🏥 اطلاعات پزشکی' : '🏥 Medical information'}
            </p>
          </motion.button>
        </div>
      </div>
    </div>
  );
}