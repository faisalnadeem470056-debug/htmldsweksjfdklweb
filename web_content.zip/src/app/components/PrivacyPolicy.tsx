import { motion } from 'motion/react';
import { Shield, Lock, Eye, Database, UserCheck, Mail, Phone, ArrowLeft } from 'lucide-react';
import { Button } from './ui/button';

interface PrivacyPolicyProps {
  language: 'ps' | 'fa' | 'en';
  onBack: () => void;
}

export function PrivacyPolicy({ language, onBack }: PrivacyPolicyProps) {
  const content = {
    ps: {
      title: 'د محرمیت پالیسي',
      lastUpdated: 'وروستی تازه: 25 نومبر 2024',
      intro: 'HealMate ستاسو د محرمیت په ساتلو کې باور لري. دا پالیسي تشریح کوي چې موږ څنګه ستاسو معلومات راټولوو، استعمالوو او ساتو.',
      sections: [
        {
          icon: Database,
          title: '1. د معلوماتو راټولول',
          content: `موږ لاندې معلومات راټولوو:

• د حساب معلومات: نوم، برېښنالیک، فون نمبر
• د پروفایل معلومات: عکس، بیوګرافي، موقعیت
• د استعمال معلومات: اپلیکیشن استعمال، د فعالیت logs
• د وسیلې معلومات: IP address، د وسیلې ډول، OS نسخه
• د روغتیا پوښتنې: د AI چټ سره تعامل (په محرمیت سره)

⚠️ مهم: موږ ستاسو د طبي تاریخچه یا حساس روغتیا معلومات نه ساتو.`
        },
        {
          icon: Lock,
          title: '2. د معلوماتو استعمال',
          content: `ستاسو معلومات یوازې د لاندې موخو لپاره استعمالیږي:

• د خدماتو چمتو کول او ښه کول
• د حساب مدیریت او تصدیق
• د کاروونکو سره اړیکه
• د امنیت او د غلط استعمال مخنیوی
• د قانوني اړتیاو پوره کول
• د اپلیکیشن ښه کول`
        },
        {
          icon: Shield,
          title: '3. د معلوماتو امنیت',
          content: `موږ ستاسو د معلوماتو د امنیت لپاره لاندې اقدامات کوو:

• د معلوماتو encryption (SSL/TLS)
• د محفوظ servers استعمال
• منظم security audits
• د لاسرسي محدودیت
• د Password encryption
• د دوه عاملي تصدیق ملاتړ`
        },
        {
          icon: Eye,
          title: '4. د معلوماتو شریکول',
          content: `موږ ستاسو معلومات د دریمو اړخونو سره نه شریکوو، پرته له:

• قانوني اړتیاو (د محکمې امر)
• ستاسو د صریح اجازې سره
• د خدماتو چمتو کوونکو سره (Amazon AWS، Firebase)
• د اضطراري طبي حالاتو کې (د ژوند ساتلو لپاره)

❌ موږ ستاسو معلومات نه پلوو او نه advertising ته ورکوو.`
        },
        {
          icon: UserCheck,
          title: '5. ستاسو حقوق',
          content: `تاسو لاندې حقوق لرئ:

• د خپلو معلوماتو لاسرسي
• د معلوماتو سمون
• د معلوماتو حذف (د حساب حذف)
• د معلوماتو راټولولو مخالفت
• د معلوماتو کاپي اخیستل (data portability)
• د خپل رضایت بیرته اخیستل`
        },
        {
          icon: Mail,
          title: '6. موږ سره اړیکه',
          content: `د محرمیت په اړه د پوښتنو یا اندېښنو لپاره:

📧 برېښنالیک: ibrahimkhaksar.it@gmail.com
📱 فون: +93 700 000 000
🌐 ویبسایټ: healmate.af
📍 پته: کابل، افغانستان

موږ به ستاسو پوښتنو ته د 48 ساعتو دننه ځواب ورکړو.`
        }
      ],
      cookies: {
        title: '7. Cookies او Tracking',
        content: `موږ Cookies استعمالوو د:

• د session مدیریت
• د کاروونکي preferences ساتلو
• د امنیت ښه کولو
• د analytics (د Google Analytics سره)

تاسو کولی شئ cookies په خپل browser کې غیر فعال کړئ.`
      },
      children: {
        title: '8. د ماشومانو محرمیت',
        content: 'دا اپلیکیشن د 13 کالو څخه لږ عمر لپاره نه دی. موږ په قصدي توګه د 13 کالو څخه کم عمر ماشومانو څخه معلومات نه راټولوو.'
      },
      changes: {
        title: '9. د پالیسي بدلونونه',
        content: 'موږ ممکن دا پالیسي وخت په وخت تازه کړو. د هر بدلون په صورت کې به تاسو ته خبر درکړو او اپلیکیشن کې به د تازه نېټې سره ښودل کیږي.'
      },
      gdpr: {
        title: '10. د GDPR او نورو قوانینو تعمیل',
        content: 'موږ د GDPR (General Data Protection Regulation)، CCPA او نورو نړیوالو د محرمیت قوانینو تعمیل کوو.'
      },
      consent: '✅ د دې اپلیکیشن استعمال سره، تاسو د دې محرمیت پالیسي شرطونو سره موافق یاست.'
    },
    fa: {
      title: 'سیاست حفظ حریم خصوصی',
      lastUpdated: 'آخرین بروزرسانی: 25 نوامبر 2024',
      intro: 'HealMate به حفظ حریم خصوصی شما اعتقاد دارد. این سیاست توضیح می‌دهد که ما چگونه اطلاعات شما را جمع‌آوری، استفاده و حفاظت می‌کنیم.',
      sections: [
        {
          icon: Database,
          title: '۱. جمع‌آوری اطلاعات',
          content: `ما اطلاعات زیر را جمع‌آوری می‌کنیم:

• اطلاعات حساب: نام، ایمیل، شماره تلفن
• اطلاعات پروفایل: عکس، بیوگرافی، موقعیت
• اطلاعات استفاده: استفاده از اپلیکیشن، گزارش‌های فعالیت
• اطلاعات دستگاه: IP address، نوع دستگاه، نسخه OS
• سوالات سلامتی: تعامل با AI Chat (با حفظ حریم خصوصی)

⚠️ مهم: ما تاریخچه پزشکی یا اطلاعات حساس سلامتی شما را ذخیره نمی‌کنیم.`
        },
        {
          icon: Lock,
          title: '۲. استفاده از اطلاعات',
          content: `اطلاعات شما فقط برای اهداف زیر استفاده می‌شود:

• ارائه و بهبود خدمات
• مدیریت حساب و احراز هویت
• ارتباط با کاربران
• امنیت و جلوگیری از سوء استفاده
• رعایت الزامات قانونی
• بهبود اپلیکیشن`
        },
        {
          icon: Shield,
          title: '۳. امنیت اطلاعات',
          content: `ما اقدامات زیر را برای امنیت اطلاعات شما انجام می‌دهیم:

• رمزنگاری اطلاعات (SSL/TLS)
• استفاده از سرورهای امن
• ممیزی‌های امنیتی منظم
• محدودیت دسترسی
• رمزنگاری رمز عبور
• پشتیبانی از احراز هویت دو مرحله‌ای`
        },
        {
          icon: Eye,
          title: '۴. اشتراک‌گذاری اطلاعات',
          content: `ما اطلاعات شما را با اشخاص ثالث به اشتراک نمی‌گذاریم، مگر:

• الزامات قانونی (دستور دادگاه)
• با رضایت صریح شما
• با ارائه‌دهندگان خدمات (Amazon AWS، Firebase)
• در شرایط اضطراری پزشکی (برای نجات جان)

❌ ما اطلاعات شما را نمی‌فروشیم و به تبلیغات ارائه نمی‌دهیم.`
        },
        {
          icon: UserCheck,
          title: '۵. حقوق شما',
          content: `شما حقوق زیر را دارید:

• دسترسی به اطلاعات خود
• اصلاح اطلاعات
• حذف اطلاعات (حذف حساب)
• مخالفت با جمع‌آوری اطلاعات
• دریافت کپی از اطلاعات (قابلیت انتقال داده)
• پس‌گیری رضایت خود`
        },
        {
          icon: Mail,
          title: '۶. تماس با ما',
          content: `برای سوالات یا نگرانی‌های مربوط به حریم خصوصی:

📧 ایمیل: ibrahimkhaksar.it@gmail.com
📱 تلفن: +93 700 000 000
🌐 وبسایت: healmate.af
📍 آدرس: کابل، افغانستان

ما به سوالات شما ظرف 48 ساعت پاسخ خواهیم داد.`
        }
      ],
      cookies: {
        title: '۷. Cookies و Tracking',
        content: `ما از Cookies برای موارد زیر استفاده می‌کنیم:

• مدیریت session
• ذخیره تنظیمات کاربر
• بهبود امنیت
• آنالیز (با Google Analytics)

شما می‌توانید cookies را در مرورگر خود غیرفعال کنید.`
      },
      children: {
        title: '۸. حریم خصوصی کودکان',
        content: 'این اپلیکیشن برای افراد زیر 13 سال نیست. ما عمداً اطلاعات کودکان زیر 13 سال را جمع‌آوری نمی‌کنیم.'
      },
      changes: {
        title: '۹. تغییرات سیاست',
        content: 'ما ممکن است این سیاست را به‌طور دوره‌ای بروزرسانی کنیم. در صورت هر تغییری، شما را مطلع می‌کنیم و در اپلیکیشن با تاریخ بروز نشان داده می‌شود.'
      },
      gdpr: {
        title: '۱۰. رعایت GDPR و قوانین دیگر',
        content: 'ما از GDPR (General Data Protection Regulation)، CCPA و سایر قوانین بین‌المللی حفظ حریم خصوصی پیروی می‌کنیم.'
      },
      consent: '✅ با استفاده از این اپلیکیشن، شما با شرایط این سیاست حفظ حریم خصوصی موافقت می‌کنید.'
    },
    en: {
      title: 'Privacy Policy',
      lastUpdated: 'Last Updated: November 25, 2024',
      intro: 'HealMate believes in protecting your privacy. This policy explains how we collect, use, and protect your information.',
      sections: [
        {
          icon: Database,
          title: '1. Information Collection',
          content: `We collect the following information:

• Account Information: name, email, phone number
• Profile Information: photo, biography, location
• Usage Information: app usage, activity logs
• Device Information: IP address, device type, OS version
• Health Queries: AI Chat interactions (privately stored)

⚠️ Important: We do NOT store your medical history or sensitive health information.`
        },
        {
          icon: Lock,
          title: '2. Information Use',
          content: `Your information is used only for:

• Providing and improving services
• Account management and authentication
• Communication with users
• Security and abuse prevention
• Legal compliance
• App improvement`
        },
        {
          icon: Shield,
          title: '3. Information Security',
          content: `We take the following measures to secure your information:

• Data encryption (SSL/TLS)
• Secure server usage
• Regular security audits
• Access restrictions
• Password encryption
• Two-factor authentication support`
        },
        {
          icon: Eye,
          title: '4. Information Sharing',
          content: `We do NOT share your information with third parties, except:

• Legal requirements (court order)
• With your explicit consent
• With service providers (Amazon AWS, Firebase)
• In medical emergencies (to save lives)

❌ We do NOT sell your information or provide it to advertisers.`
        },
        {
          icon: UserCheck,
          title: '5. Your Rights',
          content: `You have the following rights:

• Access to your information
• Information correction
• Information deletion (account deletion)
• Object to information collection
• Receive copy of information (data portability)
• Withdraw your consent`
        },
        {
          icon: Mail,
          title: '6. Contact Us',
          content: `For privacy questions or concerns:

📧 Email: ibrahimkhaksar.it@gmail.com
📱 Phone: +93 700 000 000
🌐 Website: healmate.af
📍 Address: Kabul, Afghanistan

We will respond to your inquiries within 48 hours.`
        }
      ],
      cookies: {
        title: '7. Cookies and Tracking',
        content: `We use Cookies for:

• Session management
• Saving user preferences
• Security improvement
• Analytics (with Google Analytics)

You can disable cookies in your browser.`
      },
      children: {
        title: '8. Children\'s Privacy',
        content: 'This application is not for users under 13 years old. We do not knowingly collect information from children under 13.'
      },
      changes: {
        title: '9. Policy Changes',
        content: 'We may update this policy periodically. In case of any changes, we will notify you and display the updated date in the app.'
      },
      gdpr: {
        title: '10. GDPR and Other Laws Compliance',
        content: 'We comply with GDPR (General Data Protection Regulation), CCPA, and other international privacy laws.'
      },
      consent: '✅ By using this application, you agree to the terms of this Privacy Policy.'
    }
  };

  const t = content[language];

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50 pb-28 md:pb-8">
      {/* Header */}
      <div className="sticky top-0 z-30 bg-white/80 backdrop-blur-xl border-b border-gray-200 shadow-lg">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center gap-4">
            <Button variant="ghost" size="icon" onClick={onBack}>
              <ArrowLeft className="w-5 h-5" />
            </Button>
            <div className="flex items-center gap-3">
              <div className="bg-gradient-to-br from-blue-500 to-indigo-600 p-2.5 rounded-2xl">
                <Shield className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-2xl bg-gradient-to-r from-blue-600 to-indigo-600 bg-clip-text text-transparent">
                  {t.title}
                </h1>
                <p className="text-xs text-gray-600">{t.lastUpdated}</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="container mx-auto px-4 py-6 max-w-4xl">
        {/* Introduction */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white rounded-2xl p-6 border border-gray-200 shadow-lg mb-6"
        >
          <p className="text-gray-700 leading-relaxed" dir={language === 'en' ? 'ltr' : 'rtl'}>
            {t.intro}
          </p>
        </motion.div>

        {/* Sections */}
        <div className="space-y-6">
          {t.sections.map((section, index) => {
            const Icon = section.icon;
            return (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                className="bg-white rounded-2xl p-6 border border-gray-200 shadow-lg"
              >
                <div className="flex items-start gap-4 mb-4">
                  <div className="bg-gradient-to-br from-blue-500 to-indigo-600 p-3 rounded-xl">
                    <Icon className="w-6 h-6 text-white" />
                  </div>
                  <div className="flex-1">
                    <h2 className="text-xl font-medium mb-2" dir={language === 'en' ? 'ltr' : 'rtl'}>
                      {section.title}
                    </h2>
                  </div>
                </div>
                <div 
                  className="text-gray-700 leading-relaxed whitespace-pre-wrap"
                  dir={language === 'en' ? 'ltr' : 'rtl'}
                >
                  {section.content}
                </div>
              </motion.div>
            );
          })}

          {/* Cookies Section */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.6 }}
            className="bg-white rounded-2xl p-6 border border-gray-200 shadow-lg"
          >
            <h2 className="text-xl font-medium mb-4" dir={language === 'en' ? 'ltr' : 'rtl'}>
              {t.cookies.title}
            </h2>
            <p className="text-gray-700 leading-relaxed whitespace-pre-wrap" dir={language === 'en' ? 'ltr' : 'rtl'}>
              {t.cookies.content}
            </p>
          </motion.div>

          {/* Children Privacy */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.7 }}
            className="bg-white rounded-2xl p-6 border border-gray-200 shadow-lg"
          >
            <h2 className="text-xl font-medium mb-4" dir={language === 'en' ? 'ltr' : 'rtl'}>
              {t.children.title}
            </h2>
            <p className="text-gray-700 leading-relaxed" dir={language === 'en' ? 'ltr' : 'rtl'}>
              {t.children.content}
            </p>
          </motion.div>

          {/* Changes */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.8 }}
            className="bg-white rounded-2xl p-6 border border-gray-200 shadow-lg"
          >
            <h2 className="text-xl font-medium mb-4" dir={language === 'en' ? 'ltr' : 'rtl'}>
              {t.changes.title}
            </h2>
            <p className="text-gray-700 leading-relaxed" dir={language === 'en' ? 'ltr' : 'rtl'}>
              {t.changes.content}
            </p>
          </motion.div>

          {/* GDPR */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.9 }}
            className="bg-white rounded-2xl p-6 border border-gray-200 shadow-lg"
          >
            <h2 className="text-xl font-medium mb-4" dir={language === 'en' ? 'ltr' : 'rtl'}>
              {t.gdpr.title}
            </h2>
            <p className="text-gray-700 leading-relaxed" dir={language === 'en' ? 'ltr' : 'rtl'}>
              {t.gdpr.content}
            </p>
          </motion.div>

          {/* Consent */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 1.0 }}
            className="bg-gradient-to-r from-green-50 to-emerald-50 border-2 border-green-200 rounded-2xl p-6"
          >
            <p className="text-center font-medium text-green-700" dir={language === 'en' ? 'ltr' : 'rtl'}>
              {t.consent}
            </p>
          </motion.div>
        </div>
      </div>
    </div>
  );
}
