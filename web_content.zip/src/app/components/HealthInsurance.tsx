import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";
import { Input } from "./ui/input";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "./ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs";
import { 
  Shield, 
  Upload,
  CheckCircle,
  XCircle,
  AlertCircle,
  FileText,
  CreditCard,
  User,
  Calendar,
  Building2,
  Sparkles,
  TrendingDown,
  Star,
  Phone,
  MapPin,
  Stethoscope,
  Heart,
  Eye,
  Pill,
  Activity,
  Brain,
  Baby,
  Hospital
} from "lucide-react";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select";
import { Separator } from "./ui/separator";
import { Alert, AlertDescription } from "./ui/alert";
import { Progress } from "./ui/progress";

interface InsuranceCard {
  id: number;
  provider: string;
  providerDari: string;
  policyNumber: string;
  holderName: string;
  validUntil: string;
  coverage: string;
  status: "active" | "expired" | "pending";
  logo?: string;
}

interface CoverageDetail {
  category: string;
  categoryDari: string;
  icon: any;
  covered: number;
  limit: number;
  color: string;
}

interface Doctor {
  id: number;
  name: string;
  nameDari: string;
  specialty: string;
  specialtyDari: string;
  rating: number;
  experience: string;
  location: string;
  locationDari: string;
  normalFee: number;
  discountedFee: number;
  discount: number;
  acceptsInsurance: string[];
  image?: string;
  online: boolean;
}

const mockInsuranceCards: InsuranceCard[] = [
  {
    id: 1,
    provider: "Afghan National Insurance",
    providerDari: "د افغانستان ملي بیمه",
    policyNumber: "ANI-2025-45678",
    holderName: "User Profile",
    validUntil: "2025-12-31",
    coverage: "Comprehensive",
    status: "active"
  },
  {
    id: 2,
    provider: "Kabul Health Insurance",
    providerDari: "کابل روغتیا بیمه",
    policyNumber: "KHI-2024-12345",
    holderName: "User Profile",
    validUntil: "2025-06-30",
    coverage: "Basic",
    status: "active"
  }
];

const coverageDetails: CoverageDetail[] = [
  {
    category: "Doctor Visits",
    categoryDari: "د ډاکټر لیدنې",
    icon: Stethoscope,
    covered: 15,
    limit: 20,
    color: "from-blue-500 to-cyan-500"
  },
  {
    category: "Lab Tests",
    categoryDari: "لابراتواري ازموینې",
    icon: Activity,
    covered: 8,
    limit: 15,
    color: "from-purple-500 to-violet-500"
  },
  {
    category: "Medicines",
    categoryDari: "دواګانې",
    icon: Pill,
    covered: 2500,
    limit: 5000,
    color: "from-green-500 to-emerald-500"
  },
  {
    category: "Surgery",
    categoryDari: "جراحي",
    icon: Hospital,
    covered: 0,
    limit: 100000,
    color: "from-red-500 to-pink-500"
  },
  {
    category: "Dental Care",
    categoryDari: "د غاښونو پاملرنه",
    icon: Heart,
    covered: 1200,
    limit: 3000,
    color: "from-orange-500 to-amber-500"
  },
  {
    category: "Eye Care",
    categoryDari: "د سترګو پاملرنه",
    icon: Eye,
    covered: 500,
    limit: 2000,
    color: "from-teal-500 to-cyan-500"
  }
];

const partneredDoctors: Doctor[] = [
  {
    id: 1,
    name: "Dr. Sarah Johnson",
    nameDari: "ډاکټره ساره جانسن",
    specialty: "Cardiologist",
    specialtyDari: "زړه متخصص",
    rating: 4.9,
    experience: "15 years",
    location: "Wazir Akbar Khan, Kabul",
    locationDari: "وزیر اکبر خان، کابل",
    normalFee: 1500,
    discountedFee: 750,
    discount: 50,
    acceptsInsurance: ["Afghan National Insurance", "Kabul Health Insurance"],
    online: true
  },
  {
    id: 2,
    name: "Dr. Noor Ahmadi",
    nameDari: "ډاکټر نور احمدي",
    specialty: "Pediatrician",
    specialtyDari: "د ماشومانو متخصص",
    rating: 4.8,
    experience: "12 years",
    location: "Shar-e-Naw, Kabul",
    locationDari: "شهر نو، کابل",
    normalFee: 1200,
    discountedFee: 600,
    discount: 50,
    acceptsInsurance: ["Afghan National Insurance"],
    online: true
  },
  {
    id: 3,
    name: "Dr. Hassan Karimi",
    nameDari: "ډاکټر حسن کریمي",
    specialty: "Neurologist",
    specialtyDari: "د اعصابو متخصص",
    rating: 4.7,
    experience: "18 years",
    location: "Karte 3, Kabul",
    locationDari: "کارته سوم، کابل",
    normalFee: 1800,
    discountedFee: 900,
    discount: 50,
    acceptsInsurance: ["Afghan National Insurance", "Kabul Health Insurance"],
    online: false
  },
  {
    id: 4,
    name: "Dr. Maryam Haidari",
    nameDari: "ډاکټره مریم حیدري",
    specialty: "Dermatologist",
    specialtyDari: "پوستکي متخصص",
    rating: 5.0,
    experience: "10 years",
    location: "Taimani, Kabul",
    locationDari: "تایماني، کابل",
    normalFee: 1400,
    discountedFee: 700,
    discount: 50,
    acceptsInsurance: ["Afghan National Insurance"],
    online: true
  },
  {
    id: 5,
    name: "Dr. Jamil Rahimi",
    nameDari: "ډاکټر جمیل رحیمي",
    specialty: "Orthopedic Surgeon",
    specialtyDari: "د هډوکو جراح",
    rating: 4.9,
    experience: "20 years",
    location: "Karte 4, Kabul",
    locationDari: "کارته څلورم، کابل",
    normalFee: 2000,
    discountedFee: 1000,
    discount: 50,
    acceptsInsurance: ["Afghan National Insurance", "Kabul Health Insurance"],
    online: false
  },
  {
    id: 6,
    name: "Dr. Zainab Azizi",
    nameDari: "ډاکټره زینب عزیزي",
    specialty: "Gynecologist",
    specialtyDari: "د ښځو متخصص",
    rating: 4.8,
    experience: "14 years",
    location: "Macroyan, Kabul",
    locationDari: "مکرویان، کابل",
    normalFee: 1300,
    discountedFee: 650,
    discount: 50,
    acceptsInsurance: ["Kabul Health Insurance"],
    online: true
  }
];

export function HealthInsurance() {
  const [activeTab, setActiveTab] = useState("cards");
  const [insuranceCards, setInsuranceCards] = useState<InsuranceCard[]>(mockInsuranceCards);
  const [uploadModalOpen, setUploadModalOpen] = useState(false);
  const [selectedCard, setSelectedCard] = useState<InsuranceCard | null>(null);
  const [filterInsurance, setFilterInsurance] = useState<string>("all");

  const filteredDoctors = filterInsurance === "all" 
    ? partneredDoctors 
    : partneredDoctors.filter(doc => doc.acceptsInsurance.includes(filterInsurance));

  return (
    <section className="py-16 md:py-24 bg-gradient-to-b from-white via-blue-50/30 to-white relative overflow-hidden min-h-screen">
      {/* Background decoration */}
      <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-gradient-to-br from-blue-100/50 to-cyan-100/50 rounded-full blur-3xl animate-float"></div>
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        {/* Header */}
        <div className="text-center mb-12 md:mb-16 space-y-4">
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-blue-100 to-cyan-100 rounded-full">
            <Sparkles className="w-4 h-4 text-blue-600 animate-pulse-glow" />
            <span className="text-blue-700 text-sm uppercase tracking-wider">Health Insurance</span>
          </div>
          <h2 className="text-4xl md:text-6xl">
            <span className="bg-gradient-to-r from-blue-600 via-cyan-600 to-teal-600 bg-clip-text text-transparent">
              Health Insurance
            </span>
          </h2>
          <p className="text-gray-600 max-w-2xl mx-auto text-lg">
            د روغتیا بیمه - Manage your health coverage and find partnered doctors
          </p>
        </div>

        {/* Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-3 mb-8">
            <TabsTrigger value="cards" className="flex items-center gap-2">
              <CreditCard className="w-4 h-4" />
              <span className="hidden md:inline">Insurance Cards</span>
            </TabsTrigger>
            <TabsTrigger value="coverage" className="flex items-center gap-2">
              <Shield className="w-4 h-4" />
              <span className="hidden md:inline">Coverage</span>
            </TabsTrigger>
            <TabsTrigger value="doctors" className="flex items-center gap-2">
              <Stethoscope className="w-4 h-4" />
              <span className="hidden md:inline">Partnered Doctors</span>
            </TabsTrigger>
          </TabsList>

          {/* Insurance Cards Tab */}
          <TabsContent value="cards" className="space-y-6">
            <Alert className="bg-blue-50 border-blue-200">
              <AlertCircle className="h-4 w-4 text-blue-600" />
              <AlertDescription className="text-blue-800">
                Upload your insurance card to check coverage and find partnered doctors with discounts.
                | خپل بیمه کارت اپلوډ کړئ ترڅو پوښښ وګورئ او تخفیف لرونکي ډاکټران ومومئ.
              </AlertDescription>
            </Alert>

            <div className="flex justify-end mb-6">
              <Button 
                className="bg-gradient-to-r from-blue-500 to-cyan-600 hover:from-blue-600 hover:to-cyan-700 shadow-lg"
                onClick={() => setUploadModalOpen(true)}
              >
                <Upload className="w-4 h-4 mr-2" />
                Upload Insurance Card
              </Button>
            </div>

            {/* Insurance Cards List */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {insuranceCards.map((card, index) => (
                <Card
                  key={card.id}
                  className="hover-lift border-0 shadow-lg overflow-hidden cursor-pointer"
                  style={{ animationDelay: `${index * 50}ms` }}
                  onClick={() => setSelectedCard(card)}
                >
                  <div className={`h-2 bg-gradient-to-r ${
                    card.status === "active" ? "from-green-500 to-emerald-600" :
                    card.status === "expired" ? "from-red-500 to-pink-600" :
                    "from-amber-500 to-orange-600"
                  }`}></div>
                  
                  <CardHeader className="pb-3">
                    <div className="flex items-start justify-between mb-3">
                      <div className="flex-1">
                        <CardTitle className="text-lg mb-1">{card.provider}</CardTitle>
                        <p className="text-sm text-blue-600">{card.providerDari}</p>
                      </div>
                      <Badge className={
                        card.status === "active" ? "bg-green-100 text-green-700" :
                        card.status === "expired" ? "bg-red-100 text-red-700" :
                        "bg-amber-100 text-amber-700"
                      }>
                        {card.status === "active" && <CheckCircle className="w-3 h-3 mr-1" />}
                        {card.status === "expired" && <XCircle className="w-3 h-3 mr-1" />}
                        {card.status.toUpperCase()}
                      </Badge>
                    </div>
                  </CardHeader>

                  <CardContent className="space-y-3">
                    <div className="p-4 bg-gradient-to-br from-blue-50 to-cyan-50 rounded-lg">
                      <div className="flex items-center gap-2 mb-3">
                        <CreditCard className="w-5 h-5 text-blue-600" />
                        <span className="text-sm text-gray-600">Policy Number</span>
                      </div>
                      <p className="text-xl tracking-wider text-gray-900 mb-1">{card.policyNumber}</p>
                    </div>

                    <div className="grid grid-cols-2 gap-3 text-sm">
                      <div>
                        <p className="text-gray-600 mb-1">Holder Name</p>
                        <p className="text-gray-900">{card.holderName}</p>
                      </div>
                      <div>
                        <p className="text-gray-600 mb-1">Valid Until</p>
                        <p className="text-gray-900">{card.validUntil}</p>
                      </div>
                    </div>

                    <Separator />

                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-xs text-gray-600 mb-1">Coverage Type</p>
                        <Badge variant="outline" className="text-blue-700 border-blue-300">
                          {card.coverage}
                        </Badge>
                      </div>
                      <Button size="sm" variant="outline">
                        View Details
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>

            {/* Add Card Placeholder */}
            <Card className="border-2 border-dashed border-gray-300 hover:border-blue-500 transition-colors cursor-pointer">
              <CardContent className="p-8 text-center" onClick={() => setUploadModalOpen(true)}>
                <div className="p-4 bg-gradient-to-br from-blue-100 to-cyan-100 rounded-full w-16 h-16 mx-auto mb-4 flex items-center justify-center">
                  <Upload className="w-8 h-8 text-blue-600" />
                </div>
                <h3 className="text-lg text-gray-900 mb-2">Add Insurance Card</h3>
                <p className="text-sm text-gray-600 mb-1">Upload your insurance card image or PDF</p>
                <p className="text-sm text-blue-600">بیمه کارت اپلوډ کړئ</p>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Coverage Tab */}
          <TabsContent value="coverage" className="space-y-6">
            {/* Selected Insurance */}
            <Card className="border-0 shadow-lg bg-gradient-to-r from-blue-50 to-cyan-50">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="p-3 bg-gradient-to-br from-blue-500 to-cyan-600 rounded-lg">
                      <Shield className="w-6 h-6 text-white" />
                    </div>
                    <div>
                      <h3 className="text-lg text-gray-900">{insuranceCards[0].provider}</h3>
                      <p className="text-sm text-blue-600">{insuranceCards[0].providerDari}</p>
                    </div>
                  </div>
                  <Select defaultValue={insuranceCards[0].id.toString()}>
                    <SelectTrigger className="w-[200px]">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {insuranceCards.map(card => (
                        <SelectItem key={card.id} value={card.id.toString()}>
                          {card.provider}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </CardContent>
            </Card>

            {/* Coverage Details */}
            <div>
              <h3 className="text-2xl mb-6">Coverage Details - د پوښښ تفصیلات</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {coverageDetails.map((coverage, index) => {
                  const percentage = (coverage.covered / coverage.limit) * 100;
                  const Icon = coverage.icon;

                  return (
                    <Card
                      key={index}
                      className="hover-lift border-0 shadow-lg overflow-hidden"
                      style={{ animationDelay: `${index * 50}ms` }}
                    >
                      <div className={`h-2 bg-gradient-to-r ${coverage.color}`}></div>
                      <CardHeader className="pb-3">
                        <div className="flex items-center gap-3 mb-2">
                          <div className={`p-3 bg-gradient-to-br ${coverage.color} rounded-xl`}>
                            <Icon className="w-6 h-6 text-white" />
                          </div>
                          <div className="flex-1">
                            <CardTitle className="text-base mb-1">{coverage.category}</CardTitle>
                            <p className="text-sm text-blue-600">{coverage.categoryDari}</p>
                          </div>
                        </div>
                      </CardHeader>
                      <CardContent className="space-y-3">
                        <div>
                          <div className="flex items-center justify-between text-sm mb-2">
                            <span className="text-gray-600">Used</span>
                            <span className="text-gray-900">
                              {coverage.covered.toLocaleString()} / {coverage.limit.toLocaleString()} AFN
                            </span>
                          </div>
                          <Progress value={percentage} className="h-2" />
                          <p className="text-xs text-gray-600 mt-1">
                            {coverage.limit - coverage.covered > 0 
                              ? `${(coverage.limit - coverage.covered).toLocaleString()} AFN remaining`
                              : "Limit reached"}
                          </p>
                        </div>

                        <Separator />

                        <div className="flex items-center justify-between text-sm">
                          <span className="text-gray-600">Coverage:</span>
                          <Badge className="bg-green-100 text-green-700">
                            {Math.round(100 - percentage)}% Available
                          </Badge>
                        </div>
                      </CardContent>
                    </Card>
                  );
                })}
              </div>
            </div>

            {/* Summary Card */}
            <Card className="border-0 shadow-lg bg-gradient-to-r from-green-50 to-emerald-50">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <CheckCircle className="w-5 h-5 text-green-600" />
                  Coverage Summary
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="p-4 bg-white rounded-lg">
                    <p className="text-sm text-gray-600 mb-1">Total Coverage</p>
                    <p className="text-2xl text-green-600">113,200 AFN</p>
                  </div>
                  <div className="p-4 bg-white rounded-lg">
                    <p className="text-sm text-gray-600 mb-1">Used</p>
                    <p className="text-2xl text-orange-600">4,215 AFN</p>
                  </div>
                  <div className="p-4 bg-white rounded-lg">
                    <p className="text-sm text-gray-600 mb-1">Remaining</p>
                    <p className="text-2xl text-blue-600">108,985 AFN</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Partnered Doctors Tab */}
          <TabsContent value="doctors" className="space-y-6">
            <Alert className="bg-green-50 border-green-200">
              <TrendingDown className="h-4 w-4 text-green-600" />
              <AlertDescription className="text-green-800">
                Save up to 50% on consultation fees with our partnered doctors!
                | زموږ د ملګرو ډاکټرانو سره د ورکړې فیس کې تر 50% پورې خوندي کړئ!
              </AlertDescription>
            </Alert>

            {/* Filter by Insurance */}
            <div className="flex items-center gap-4">
              <p className="text-sm text-gray-700">Filter by Insurance:</p>
              <Select value={filterInsurance} onValueChange={setFilterInsurance}>
                <SelectTrigger className="w-[300px]">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Doctors</SelectItem>
                  {insuranceCards.map(card => (
                    <SelectItem key={card.id} value={card.provider}>
                      {card.provider}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* Doctors List */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredDoctors.map((doctor, index) => (
                <Card
                  key={doctor.id}
                  className="hover-lift border-0 shadow-lg overflow-hidden"
                  style={{ animationDelay: `${index * 50}ms` }}
                >
                  <div className="h-2 bg-gradient-to-r from-green-500 to-emerald-600"></div>
                  
                  <CardHeader className="pb-3">
                    <div className="flex items-start justify-between mb-3">
                      <div className="flex-1">
                        <CardTitle className="text-base mb-1">{doctor.name}</CardTitle>
                        <p className="text-sm text-blue-600 mb-2">{doctor.nameDari}</p>
                        <div className="flex flex-wrap gap-2">
                          <Badge variant="outline" className="text-xs">
                            {doctor.specialty}
                          </Badge>
                          {doctor.online && (
                            <Badge className="bg-green-100 text-green-700 text-xs">
                              Online
                            </Badge>
                          )}
                        </div>
                      </div>
                    </div>
                  </CardHeader>

                  <CardContent className="space-y-3">
                    {/* Discount Badge */}
                    <div className="p-3 bg-gradient-to-r from-green-50 to-emerald-50 border-2 border-green-200 rounded-lg">
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-xs text-gray-600">Normal Fee:</span>
                        <span className="text-sm text-gray-500 line-through">{doctor.normalFee} AFN</span>
                      </div>
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <Shield className="w-4 h-4 text-green-600" />
                          <span className="text-xs text-gray-600">With Insurance:</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <span className="text-xl text-green-600">{doctor.discountedFee} AFN</span>
                          <Badge className="bg-red-500 text-white text-xs">
                            -{doctor.discount}%
                          </Badge>
                        </div>
                      </div>
                    </div>

                    <div className="space-y-2 text-sm">
                      <div className="flex items-center gap-2 text-gray-600">
                        <MapPin className="w-4 h-4" />
                        <span className="text-xs">{doctor.location}</span>
                      </div>
                      <div className="flex items-center gap-2 text-gray-600">
                        <Calendar className="w-4 h-4" />
                        <span className="text-xs">{doctor.experience} experience</span>
                      </div>
                    </div>

                    <div className="flex items-center gap-1">
                      {Array.from({ length: 5 }).map((_, i) => (
                        <Star
                          key={i}
                          className={`w-4 h-4 ${
                            i < Math.floor(doctor.rating)
                              ? "fill-yellow-400 text-yellow-400"
                              : "text-gray-300"
                          }`}
                        />
                      ))}
                      <span className="text-sm text-gray-600 ml-2">{doctor.rating}</span>
                    </div>

                    <Separator />

                    {/* Accepted Insurance */}
                    <div>
                      <p className="text-xs text-gray-600 mb-2">Accepts:</p>
                      <div className="flex flex-wrap gap-1">
                        {doctor.acceptsInsurance.map((ins, idx) => (
                          <Badge key={idx} className="bg-blue-100 text-blue-700 text-xs">
                            <CheckCircle className="w-3 h-3 mr-1" />
                            {ins === "Afghan National Insurance" ? "ANI" : "KHI"}
                          </Badge>
                        ))}
                      </div>
                    </div>

                    <Button className="w-full bg-gradient-to-r from-green-500 to-emerald-600 hover:from-green-600 hover:to-emerald-700">
                      Book Appointment
                    </Button>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>
        </Tabs>
      </div>

      {/* Upload Insurance Card Modal */}
      <Dialog open={uploadModalOpen} onOpenChange={setUploadModalOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle className="text-2xl">Upload Insurance Card</DialogTitle>
            <DialogDescription className="text-sm text-gray-600">بیمه کارت اپلوډ کړئ - Upload your insurance card details</DialogDescription>
          </DialogHeader>
          <div className="space-y-6">
            {/* Upload Area */}
            <div className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center hover:border-blue-500 transition-colors cursor-pointer bg-gradient-to-br from-blue-50/50 to-cyan-50/50">
              <Upload className="w-12 h-12 text-blue-600 mx-auto mb-4" />
              <p className="text-gray-700 mb-2">Click to upload or drag and drop</p>
              <p className="text-sm text-gray-500 mb-1">PNG, JPG, PDF up to 10MB</p>
              <p className="text-sm text-blue-600">د عکس یا PDF فایل اپلوډ کړئ</p>
            </div>

            {/* Insurance Information */}
            <div className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="text-sm text-gray-700 mb-2 block">Insurance Provider</label>
                  <Input placeholder="e.g., Afghan National Insurance" />
                </div>
                <div>
                  <label className="text-sm text-gray-700 mb-2 block">Policy Number</label>
                  <Input placeholder="e.g., ANI-2025-12345" />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="text-sm text-gray-700 mb-2 block">Holder Name</label>
                  <Input placeholder="Your full name" />
                </div>
                <div>
                  <label className="text-sm text-gray-700 mb-2 block">Valid Until</label>
                  <Input type="date" />
                </div>
              </div>

              <div>
                <label className="text-sm text-gray-700 mb-2 block">Coverage Type</label>
                <Select>
                  <SelectTrigger>
                    <SelectValue placeholder="Select coverage type" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="basic">Basic</SelectItem>
                    <SelectItem value="standard">Standard</SelectItem>
                    <SelectItem value="comprehensive">Comprehensive</SelectItem>
                    <SelectItem value="premium">Premium</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <Alert className="bg-amber-50 border-amber-200">
              <AlertCircle className="h-4 w-4 text-amber-600" />
              <AlertDescription className="text-amber-800">
                Your insurance information will be verified within 24-48 hours. You'll receive a notification once approved.
              </AlertDescription>
            </Alert>

            <div className="flex gap-3">
              <Button 
                variant="outline" 
                className="flex-1"
                onClick={() => setUploadModalOpen(false)}
              >
                Cancel
              </Button>
              <Button 
                className="flex-1 bg-gradient-to-r from-blue-500 to-cyan-600"
                onClick={() => {
                  setUploadModalOpen(false);
                  alert("Insurance card uploaded successfully! We'll verify it within 24-48 hours.");
                }}
              >
                <Upload className="w-4 h-4 mr-2" />
                Upload Card
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </section>
  );
}

export default HealthInsurance;
