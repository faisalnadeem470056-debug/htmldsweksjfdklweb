import { useState, useEffect } from 'react';
import { ArrowLeft, Info, Eye, EyeOff, Copy, Check, AlertCircle } from 'lucide-react';
import { Button } from './ui/button';
import { Switch } from './ui/switch';
import { getAdMobConfig } from '../config/admob';
import { toast } from 'sonner@2.0.3';
import { copyToClipboard as copyText } from '../utils/clipboard';

export function AdMobTestPage() {
  const [config, setConfig] = useState(getAdMobConfig());
  const [showIds, setShowIds] = useState(false);

  useEffect(() => {
    // د Configuration تازه کړئ هر 1 ثانیه
    const interval = setInterval(() => {
      setConfig(getAdMobConfig());
    }, 1000);
    return () => clearInterval(interval);
  }, []);

  const maskId = (id: string) => {
    if (showIds) return id;
    if (id.length < 20) return "••••••••";
    return id.slice(0, 15) + "••••••••" + id.slice(-4);
  };

  const copyToClipboard = async (text: string, label: string) => {
    const success = await copyText(text);
    if (success) {
      toast.success(`${label} کاپي شو! / ${label} copied!`);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-emerald-50 via-white to-blue-50 p-4 md:p-8">
      <div className="max-w-6xl mx-auto space-y-6">
        {/* Header */}
        <div className="text-center space-y-2">
          <h1 className="text-4xl md:text-5xl bg-gradient-to-r from-emerald-600 to-blue-600 bg-clip-text text-transparent">
            AdMob Configuration Test
          </h1>
          <p className="text-gray-600">
            د Google AdMob تنظیماتو ټیسټ صفحه
          </p>
        </div>

        {/* Status Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Card className="glass-effect border-emerald-200">
            <CardContent className="pt-6">
              <div className="flex items-center gap-3">
                <div className="p-3 bg-emerald-100 rounded-lg">
                  <Settings className="w-6 h-6 text-emerald-600" />
                </div>
                <div>
                  <p className="text-xs text-gray-600">Mode</p>
                  <p className="text-sm">
                    {config.testMode ? "Test" : "Production"}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="glass-effect border-blue-200">
            <CardContent className="pt-6">
              <div className="flex items-center gap-3">
                <div className="p-3 bg-blue-100 rounded-lg">
                  {config.showAds ? (
                    <CheckCircle className="w-6 h-6 text-blue-600" />
                  ) : (
                    <XCircle className="w-6 h-6 text-gray-400" />
                  )}
                </div>
                <div>
                  <p className="text-xs text-gray-600">Ads Status</p>
                  <p className="text-sm">
                    {config.showAds ? "Active" : "Disabled"}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="glass-effect border-purple-200">
            <CardContent className="pt-6">
              <div className="flex items-center gap-3">
                <div className="p-3 bg-purple-100 rounded-lg">
                  <Smartphone className="w-6 h-6 text-purple-600" />
                </div>
                <div>
                  <p className="text-xs text-gray-600">Platforms</p>
                  <p className="text-sm">Android & iOS</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="glass-effect border-amber-200">
            <CardContent className="pt-6">
              <div className="flex items-center gap-3">
                <div className="p-3 bg-amber-100 rounded-lg">
                  <DollarSign className="w-6 h-6 text-amber-600" />
                </div>
                <div>
                  <p className="text-xs text-gray-600">Ad Types</p>
                  <p className="text-sm">Banner, Inter, Rewarded</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Show/Hide IDs Toggle */}
        <div className="flex justify-end">
          <Button
            onClick={() => setShowIds(!showIds)}
            variant="outline"
            size="sm"
            className="gap-2"
          >
            {showIds ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
            {showIds ? "Hide IDs" : "Show IDs"}
          </Button>
        </div>

        {/* Android Configuration */}
        <Card className="glass-effect">
          <CardHeader>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Smartphone className="w-5 h-5 text-emerald-600" />
                <CardTitle>Android Configuration</CardTitle>
              </div>
              <Badge variant={config.testMode ? "secondary" : "default"}>
                {config.testMode ? "Test Mode" : "Production"}
              </Badge>
            </div>
            <CardDescription>د Android لپاره AdMob IDs</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {/* App ID */}
            <div className="p-4 bg-gray-50 rounded-lg space-y-2">
              <div className="flex items-center justify-between">
                <p className="text-sm text-gray-600">App ID</p>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => copyToClipboard(config.androidAppId, "Android App ID")}
                >
                  <Copy className="w-4 h-4" />
                </Button>
              </div>
              <p className="font-mono text-xs break-all">{maskId(config.androidAppId)}</p>
            </div>

            {/* Banner ID */}
            <div className="p-4 bg-gray-50 rounded-lg space-y-2">
              <div className="flex items-center justify-between">
                <p className="text-sm text-gray-600">Banner Ad ID</p>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => copyToClipboard(config.androidBannerId, "Android Banner ID")}
                >
                  <Copy className="w-4 h-4" />
                </Button>
              </div>
              <p className="font-mono text-xs break-all">{maskId(config.androidBannerId)}</p>
            </div>

            {/* Interstitial ID */}
            <div className="p-4 bg-gray-50 rounded-lg space-y-2">
              <div className="flex items-center justify-between">
                <p className="text-sm text-gray-600">Interstitial Ad ID</p>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => copyToClipboard(config.androidInterstitialId, "Android Interstitial ID")}
                >
                  <Copy className="w-4 h-4" />
                </Button>
              </div>
              <p className="font-mono text-xs break-all">{maskId(config.androidInterstitialId)}</p>
            </div>

            {/* Rewarded ID */}
            <div className="p-4 bg-gray-50 rounded-lg space-y-2">
              <div className="flex items-center justify-between">
                <p className="text-sm text-gray-600">Rewarded Ad ID</p>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => copyToClipboard(config.androidRewardedId, "Android Rewarded ID")}
                >
                  <Copy className="w-4 h-4" />
                </Button>
              </div>
              <p className="font-mono text-xs break-all">{maskId(config.androidRewardedId)}</p>
            </div>
          </CardContent>
        </Card>

        {/* iOS Configuration */}
        <Card className="glass-effect">
          <CardHeader>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Smartphone className="w-5 h-5 text-blue-600" />
                <CardTitle>iOS Configuration</CardTitle>
              </div>
              <Badge variant={config.testMode ? "secondary" : "default"}>
                {config.testMode ? "Test Mode" : "Production"}
              </Badge>
            </div>
            <CardDescription>د iOS لپاره AdMob IDs</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {/* App ID */}
            <div className="p-4 bg-gray-50 rounded-lg space-y-2">
              <div className="flex items-center justify-between">
                <p className="text-sm text-gray-600">App ID</p>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => copyToClipboard(config.iosAppId, "iOS App ID")}
                >
                  <Copy className="w-4 h-4" />
                </Button>
              </div>
              <p className="font-mono text-xs break-all">{maskId(config.iosAppId)}</p>
            </div>

            {/* Banner ID */}
            <div className="p-4 bg-gray-50 rounded-lg space-y-2">
              <div className="flex items-center justify-between">
                <p className="text-sm text-gray-600">Banner Ad ID</p>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => copyToClipboard(config.iosBannerId, "iOS Banner ID")}
                >
                  <Copy className="w-4 h-4" />
                </Button>
              </div>
              <p className="font-mono text-xs break-all">{maskId(config.iosBannerId)}</p>
            </div>

            {/* Interstitial ID */}
            <div className="p-4 bg-gray-50 rounded-lg space-y-2">
              <div className="flex items-center justify-between">
                <p className="text-sm text-gray-600">Interstitial Ad ID</p>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => copyToClipboard(config.iosInterstitialId, "iOS Interstitial ID")}
                >
                  <Copy className="w-4 h-4" />
                </Button>
              </div>
              <p className="font-mono text-xs break-all">{maskId(config.iosInterstitialId)}</p>
            </div>

            {/* Rewarded ID */}
            <div className="p-4 bg-gray-50 rounded-lg space-y-2">
              <div className="flex items-center justify-between">
                <p className="text-sm text-gray-600">Rewarded Ad ID</p>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => copyToClipboard(config.iosRewardedId, "iOS Rewarded ID")}
                >
                  <Copy className="w-4 h-4" />
                </Button>
              </div>
              <p className="font-mono text-xs break-all">{maskId(config.iosRewardedId)}</p>
            </div>
          </CardContent>
        </Card>

        {/* Instructions */}
        <Alert className="bg-gradient-to-r from-emerald-50 to-blue-50 border-emerald-200">
          <AlertCircle className="h-4 w-4 text-emerald-600" />
          <AlertDescription>
            <strong className="text-emerald-900">د یادښت وړ / Important:</strong>
            <ul className="mt-2 space-y-1 text-sm text-gray-700">
              <li>• په Admin Panel کې د Configuration بدلون کړئ</li>
              <li>• د ټیسټ حالت څخه Production ته بدله کړئ</li>
              <li>• د Google AdMob Console څخه خپل IDs واخلئ</li>
              <li>• د تغیراتو وروسته اپلیکیشن بیرته پرانیزئ</li>
            </ul>
          </AlertDescription>
        </Alert>
      </div>
    </div>
  );
}