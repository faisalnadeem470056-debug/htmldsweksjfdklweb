import { useState, useEffect } from "react";
import { Button } from "./ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Eye, EyeOff, Trash2, RefreshCw, Users } from "lucide-react";
import { toast } from "sonner@2.0.3";

export function AuthDebugHelper() {
  const [isOpen, setIsOpen] = useState(false);
  const [showPasswords, setShowPasswords] = useState(false);
  const [users, setUsers] = useState<any[]>([]);

  const loadUsers = () => {
    try {
      const storedUsers = localStorage.getItem("healmate_users");
      const parsedUsers = storedUsers ? JSON.parse(storedUsers) : [];
      setUsers(parsedUsers);
    } catch (error) {
      console.error("Error loading users:", error);
      setUsers([]);
    }
  };

  useEffect(() => {
    if (isOpen) {
      loadUsers();
    }
  }, [isOpen]);

  const handleClearAllUsers = () => {
    if (confirm("Are you sure you want to delete all users? This cannot be undone.")) {
      localStorage.removeItem("healmate_users");
      localStorage.removeItem("healmate_user");
      setUsers([]);
      toast.success("All users deleted successfully");
      
      // د page refresh کړئ
      setTimeout(() => {
        window.location.reload();
      }, 1000);
    }
  };

  const handleDeleteUser = (userId: string) => {
    if (confirm("Delete this user?")) {
      const updatedUsers = users.filter(u => u.id !== userId);
      localStorage.setItem("healmate_users", JSON.stringify(updatedUsers));
      setUsers(updatedUsers);
      toast.success("User deleted");
    }
  };

  if (!isOpen) {
    return (
      <Button
        onClick={() => setIsOpen(true)}
        variant="outline"
        size="sm"
        className="fixed bottom-4 left-4 z-50 bg-yellow-100 border-yellow-400 text-yellow-800 hover:bg-yellow-200"
      >
        <Users className="w-4 h-4 mr-2" />
        Debug Users ({users.length})
      </Button>
    );
  }

  return (
    <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
      <Card className="w-full max-w-2xl max-h-[80vh] overflow-auto">
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <span className="flex items-center gap-2">
              <Users className="w-5 h-5" />
              Registered Users ({users.length})
            </span>
            <div className="flex gap-2">
              <Button onClick={loadUsers} size="sm" variant="outline">
                <RefreshCw className="w-4 h-4 mr-2" />
                Refresh
              </Button>
              <Button onClick={() => setIsOpen(false)} size="sm" variant="outline">
                Close
              </Button>
            </div>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between p-3 bg-yellow-50 border border-yellow-200 rounded-lg">
            <div>
              <p className="text-sm font-semibold text-yellow-800">⚠️ Debug Tool</p>
              <p className="text-xs text-yellow-700">This tool helps you see and manage registered users</p>
            </div>
            <Button
              onClick={() => setShowPasswords(!showPasswords)}
              size="sm"
              variant="outline"
              className="text-yellow-700"
            >
              {showPasswords ? <EyeOff className="w-4 h-4 mr-2" /> : <Eye className="w-4 h-4 mr-2" />}
              {showPasswords ? "Hide" : "Show"} Passwords
            </Button>
          </div>

          {users.length === 0 ? (
            <div className="text-center py-8 text-gray-500">
              <Users className="w-12 h-12 mx-auto mb-3 opacity-50" />
              <p>No users registered yet</p>
              <p className="text-sm">Sign up to create your first user</p>
            </div>
          ) : (
            <div className="space-y-3">
              {users.map((user, index) => (
                <div
                  key={user.id}
                  className="p-4 border rounded-lg bg-gradient-to-r from-emerald-50 to-blue-50 border-emerald-200"
                >
                  <div className="flex items-start justify-between">
                    <div className="flex-1 space-y-1">
                      <div className="flex items-center gap-2">
                        <span className="font-semibold text-lg">#{index + 1}</span>
                        <span className="text-sm text-gray-500">ID: {user.id}</span>
                      </div>
                      
                      <div className="space-y-1 text-sm">
                        <p><strong>Name:</strong> {user.name}</p>
                        <p><strong>Email:</strong> <code className="bg-white px-2 py-0.5 rounded">{user.email}</code></p>
                        {user.phone && <p><strong>Phone:</strong> {user.phone}</p>}
                        <p>
                          <strong>Password:</strong> 
                          {showPasswords ? (
                            <code className="bg-red-100 text-red-800 px-2 py-0.5 rounded ml-2">
                              {user.password}
                            </code>
                          ) : (
                            <span className="text-gray-400 ml-2">••••••••</span>
                          )}
                        </p>
                        <p className="text-xs text-gray-500">
                          Created: {new Date(user.createdAt).toLocaleString()}
                        </p>
                      </div>
                    </div>
                    
                    <Button
                      onClick={() => handleDeleteUser(user.id)}
                      size="sm"
                      variant="destructive"
                      className="ml-4"
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          )}

          {users.length > 0 && (
            <div className="pt-4 border-t">
              <Button
                onClick={handleClearAllUsers}
                variant="destructive"
                className="w-full"
              >
                <Trash2 className="w-4 h-4 mr-2" />
                Delete All Users ({users.length})
              </Button>
            </div>
          )}

          <div className="p-3 bg-blue-50 border border-blue-200 rounded-lg text-sm">
            <p className="font-semibold text-blue-900 mb-1">💡 Tips:</p>
            <ul className="list-disc list-inside space-y-1 text-blue-800 text-xs">
              <li>All emails are stored in lowercase</li>
              <li>Passwords are trimmed (spaces removed)</li>
              <li>Use the exact email and password to login</li>
              <li>This debug tool is only for development</li>
            </ul>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
