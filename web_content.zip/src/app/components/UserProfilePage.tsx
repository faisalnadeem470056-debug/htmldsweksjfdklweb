import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  ArrowLeft, Mail, Phone, MapPin, Edit2, Check, X, Camera,
  Heart, LogOut, Crown, Calendar, Settings as SettingsIcon,
  Bell, Shield, Globe, Trash2, Star, Award
} from 'lucide-react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Textarea } from './ui/textarea';
import { ImageWithFallback } from './figma/ImageWithFallback';
import { premiumManager } from '../utils/PremiumManager';

interface UserProfilePageProps {
  language: 'ps' | 'fa' | 'en';
  onBack: () => void;
  onLogout: () => void;
  onLanguageChange: (lang: 'ps' | 'fa' | 'en') => void;
}

const translations = {
  ps: {
    myProfile: 'زما پروفایل',
    editProfile: 'پروفایل سم کړئ',
    save: 'خوندي کړئ',
    cancel: 'لغوه',
    logout: 'وتل',
    email: 'برېښنالیک',
    phone: 'نمبر',
    bio: 'د ځان په اړه',
    location: 'ځای',
    dateOfBirth: 'د زیږون نیټه',
    gender: 'جنسیت',
    male: 'نارینه',
    female: 'ښځینه',
    other: 'نور',
    joined: 'شامل شو',
    posts: 'پوستونه',
    followers: 'تعقیب کوونکي',
    following: 'تعقیب کوي',
    verified: 'تایید شوی',
    premium: 'Premium غړی',
    uploadPhoto: 'عکس اپلوډ',
    uploadCover: 'د پس منظر عکس',
    updateSuccess: 'پروفایل تازه شو',
    bioPlaceholder: 'خپل ځان معرفي کړئ...',
    phonePlaceholder: '+93 xxx xxx xxx',
    locationPlaceholder: 'کابل، افغانستان',
    favorites: 'خوښ شوي',
    language: 'ژبه',
    notifications: 'خبرتیاوې',
    privacy: 'محرمیت',
    clearCache: 'کیش پاک کړه',
    deleteAccount: 'حساب حذف کړئ',
    pashto: 'پښتو',
    dari: 'دری',
    english: 'انګلیسي',
    settings: 'تنظیمات',
    accountSettings: 'د حساب تنظیمات',
  },
  fa: {
    myProfile: 'پروفایل من',
    editProfile: 'ویرایش پروفایل',
    save: 'ذخیره',
    cancel: 'لغو',
    logout: 'خروج',
    email: 'ایمیل',
    phone: 'شماره',
    bio: 'درباره من',
    location: 'مکان',
    dateOfBirth: 'تاریخ تولد',
    gender: 'جنسیت',
    male: 'مرد',
    female: 'زن',
    other: 'دیگر',
    joined: 'عضو شد',
    posts: 'پست‌ها',
    followers: 'دنبال‌کنندگان',
    following: 'دنبال شده',
    verified: 'تایید شده',
    premium: 'عضو پریمیوم',
    uploadPhoto: 'بارگذاری عکس',
    uploadCover: 'عکس پس‌زمینه',
    updateSuccess: 'پروفایل به‌روز شد',
    bioPlaceholder: 'خود را معرفی کنید...',
    phonePlaceholder: '+93 xxx xxx xxx',
    locationPlaceholder: 'کابل، افغانستان',
    favorites: 'علاقه‌مندی‌ها',
    language: 'زبان',
    notifications: 'اعلان‌ها',
    privacy: 'حریم خصوصی',
    clearCache: 'پاک کردن کش',
    deleteAccount: 'حذف حساب',
    pashto: 'پشتو',
    dari: 'دری',
    english: 'انگلیسی',
    settings: 'تنظیمات',
    accountSettings: 'تنظیمات حساب',
  },
  en: {
    myProfile: 'My Profile',
    editProfile: 'Edit Profile',
    save: 'Save',
    cancel: 'Cancel',
    logout: 'Logout',
    email: 'Email',
    phone: 'Phone',
    bio: 'Bio',
    location: 'Location',
    dateOfBirth: 'Date of Birth',
    gender: 'Gender',
    male: 'Male',
    female: 'Female',
    other: 'Other',
    joined: 'Joined',
    posts: 'Posts',
    followers: 'Followers',
    following: 'Following',
    verified: 'Verified',
    premium: 'Premium Member',
    uploadPhoto: 'Upload Photo',
    uploadCover: 'Cover Photo',
    updateSuccess: 'Profile updated',
    bioPlaceholder: 'Tell us about yourself...',
    phonePlaceholder: '+93 xxx xxx xxx',
    locationPlaceholder: 'Kabul, Afghanistan',
    favorites: 'Favorites',
    language: 'Language',
    notifications: 'Notifications',
    privacy: 'Privacy',
    clearCache: 'Clear Cache',
    deleteAccount: 'Delete Account',
    pashto: 'Pashto',
    dari: 'Dari',
    english: 'English',
    settings: 'Settings',
    accountSettings: 'Account Settings',
  },
};

export function UserProfilePage({
  language,
  onBack,
  onLogout,
  onLanguageChange,
}: UserProfilePageProps) {
  const [isEditing, setIsEditing] = useState(false);
  const [message, setMessage] = useState('');
  const [profile, setProfile] = useState({
    name: localStorage.getItem('healmate_userName') || 'User',
    email: localStorage.getItem('healmate_userEmail') || 'user@healmate.com',
    phone: localStorage.getItem('healmate_userPhone') || '',
    bio: localStorage.getItem('healmate_userBio') || '',
    location: localStorage.getItem('healmate_userLocation') || '',
    dateOfBirth: localStorage.getItem('healmate_userDOB') || '',
    gender: localStorage.getItem('healmate_userGender') || 'male',
    profileImage: localStorage.getItem('healmate_userProfileImage') || 'https://images.unsplash.com/photo-1633332755192-727a05c4013d?w=400',
    coverImage: localStorage.getItem('healmate_userCoverImage') || 'https://images.unsplash.com/photo-1576091160550-2173dba999ef?w=1200',
    joinedDate: localStorage.getItem('healmate_userJoinedDate') || new Date().toISOString(),
    posts: 0,
    followers: 0,
    following: 0,
    verified: false,
  });

  const [editedProfile, setEditedProfile] = useState(profile);
  const isPremium = premiumManager.isPremium(profile.email);
  const t = translations[language];

  const handleSaveProfile = () => {
    // Save to localStorage
    localStorage.setItem('healmate_userName', editedProfile.name);
    localStorage.setItem('healmate_userPhone', editedProfile.phone);
    localStorage.setItem('healmate_userBio', editedProfile.bio);
    localStorage.setItem('healmate_userLocation', editedProfile.location);
    localStorage.setItem('healmate_userDOB', editedProfile.dateOfBirth);
    localStorage.setItem('healmate_userGender', editedProfile.gender);
    
    setProfile(editedProfile);
    setIsEditing(false);
    setMessage(t.updateSuccess);
    setTimeout(() => setMessage(''), 3000);
  };

  const handleClearCache = () => {
    // Clear only cache data, not user authentication
    const keysToKeep = ['healmate_userEmail', 'healmate_userName', 'healmate_isAuthenticated'];
    const allKeys = Object.keys(localStorage);
    
    allKeys.forEach(key => {
      if (key.startsWith('healmate_') && !keysToKeep.includes(key)) {
        localStorage.removeItem(key);
      }
    });
    
    setMessage('Cache cleared successfully!');
    setTimeout(() => setMessage(''), 3000);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-pink-50 to-red-50 pb-24 overflow-y-auto">
      {/* Header */}
      <div className="bg-white/80 backdrop-blur-xl border-b sticky top-0 z-40">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <button
              onClick={onBack}
              className="p-2 hover:bg-gray-100 rounded-full transition-colors"
            >
              <ArrowLeft className="w-6 h-6" />
            </button>
            <h1 className="text-xl font-bold">{t.myProfile}</h1>
            <button
              onClick={onLogout}
              className="p-2 hover:bg-red-100 rounded-full transition-colors text-red-600"
            >
              <LogOut className="w-6 h-6" />
            </button>
          </div>
        </div>
      </div>

      {/* Message Notification */}
      <AnimatePresence>
        {message && (
          <motion.div
            initial={{ opacity: 0, y: -50 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -50 }}
            className="fixed top-20 left-1/2 -translate-x-1/2 z-50"
          >
            <div className="px-6 py-3 rounded-2xl shadow-xl bg-green-500 text-white flex items-center gap-2">
              <Check className="w-5 h-5" />
              <span>{message}</span>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <div className="container mx-auto px-4 max-w-4xl">
        {/* Cover Image */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="relative h-48 rounded-3xl overflow-hidden mt-4 shadow-xl"
        >
          <ImageWithFallback
            src={profile.coverImage}
            alt="Cover"
            className="w-full h-full object-cover"
          />
          {isEditing && (
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className="absolute bottom-4 right-4 bg-white/90 backdrop-blur-xl p-3 rounded-full shadow-lg"
            >
              <Camera className="w-5 h-5 text-gray-700" />
            </motion.button>
          )}
        </motion.div>

        {/* Profile Card */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="bg-white/90 backdrop-blur-xl rounded-3xl shadow-2xl p-6 -mt-16 relative z-10 border border-white/50"
        >
          {/* Profile Header */}
          <div className="flex flex-col sm:flex-row gap-6 items-start">
            {/* Profile Image */}
            <div className="relative mx-auto sm:mx-0">
              <div className="w-32 h-32 rounded-full overflow-hidden border-4 border-white shadow-xl">
                <ImageWithFallback
                  src={profile.profileImage}
                  alt={profile.name}
                  className="w-full h-full object-cover"
                />
              </div>
              {isEditing && (
                <motion.button
                  whileHover={{ scale: 1.1 }}
                  whileTap={{ scale: 0.9 }}
                  className="absolute bottom-0 right-0 bg-gradient-to-r from-purple-500 to-pink-600 p-2 rounded-full shadow-lg text-white"
                >
                  <Camera className="w-4 h-4" />
                </motion.button>
              )}
              {isPremium && (
                <div className="absolute -top-2 -right-2 bg-gradient-to-r from-yellow-400 to-orange-500 p-2 rounded-full shadow-lg">
                  <Crown className="w-5 h-5 text-white" />
                </div>
              )}
            </div>

            {/* Profile Info */}
            <div className="flex-1 w-full">
              <div className="flex items-start justify-between flex-wrap gap-2">
                <div>
                  <div className="flex items-center gap-2 mb-1">
                    <h2 className="text-2xl font-bold">{profile.name}</h2>
                    {profile.verified && (
                      <div className="bg-blue-500 p-1 rounded-full">
                        <Check className="w-4 h-4 text-white" />
                      </div>
                    )}
                    {isPremium && (
                      <span className="bg-gradient-to-r from-yellow-400 to-orange-500 text-white px-3 py-1 rounded-full text-xs">
                        Premium
                      </span>
                    )}
                  </div>
                  <p className="text-gray-600 text-sm mb-2">{profile.email}</p>
                  {profile.bio && (
                    <p className="text-gray-700 mb-3 max-w-md" dir={language === 'en' ? 'ltr' : 'rtl'}>
                      {profile.bio}
                    </p>
                  )}
                  <div className="flex flex-wrap gap-4 text-sm text-gray-600">
                    {profile.location && (
                      <div className="flex items-center gap-1">
                        <MapPin className="w-4 h-4" />
                        <span>{profile.location}</span>
                      </div>
                    )}
                    <div className="flex items-center gap-1">
                      <Calendar className="w-4 h-4" />
                      <span>
                        {t.joined} {new Date(profile.joinedDate).toLocaleDateString()}
                      </span>
                    </div>
                  </div>
                </div>

                {/* Action Buttons */}
                <div className="flex gap-2">
                  {isEditing ? (
                    <>
                      <Button
                        onClick={handleSaveProfile}
                        className="bg-gradient-to-r from-green-500 to-emerald-600"
                      >
                        <Check className="w-4 h-4 mr-2" />
                        {t.save}
                      </Button>
                      <Button
                        onClick={() => {
                          setIsEditing(false);
                          setEditedProfile(profile);
                        }}
                        variant="outline"
                      >
                        <X className="w-4 h-4 mr-2" />
                        {t.cancel}
                      </Button>
                    </>
                  ) : (
                    <Button
                      onClick={() => setIsEditing(true)}
                      className="bg-gradient-to-r from-purple-500 to-pink-600"
                    >
                      <Edit2 className="w-4 h-4 mr-2" />
                      {t.editProfile}
                    </Button>
                  )}
                </div>
              </div>

              {/* Stats */}
              <div className="grid grid-cols-3 gap-4 mt-4 pt-4 border-t">
                <div className="text-center">
                  <div className="text-2xl font-bold">{profile.posts}</div>
                  <div className="text-sm text-gray-600">{t.posts}</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold">{profile.followers}</div>
                  <div className="text-sm text-gray-600">{t.followers}</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold">{profile.following}</div>
                  <div className="text-sm text-gray-600">{t.following}</div>
                </div>
              </div>
            </div>
          </div>

          {/* Edit Form */}
          <AnimatePresence>
            {isEditing && (
              <motion.div
                initial={{ height: 0, opacity: 0 }}
                animate={{ height: 'auto', opacity: 1 }}
                exit={{ height: 0, opacity: 0 }}
                className="mt-6 pt-6 border-t space-y-4"
              >
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label>{t.phone}</Label>
                    <div className="relative mt-2">
                      <Phone className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                      <Input
                        value={editedProfile.phone}
                        onChange={(e) => setEditedProfile({ ...editedProfile, phone: e.target.value })}
                        placeholder={t.phonePlaceholder}
                        className="pl-10"
                      />
                    </div>
                  </div>

                  <div>
                    <Label>{t.location}</Label>
                    <div className="relative mt-2">
                      <MapPin className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                      <Input
                        value={editedProfile.location}
                        onChange={(e) => setEditedProfile({ ...editedProfile, location: e.target.value })}
                        placeholder={t.locationPlaceholder}
                        className="pl-10"
                      />
                    </div>
                  </div>

                  <div>
                    <Label>{t.dateOfBirth}</Label>
                    <Input
                      type="date"
                      value={editedProfile.dateOfBirth}
                      onChange={(e) => setEditedProfile({ ...editedProfile, dateOfBirth: e.target.value })}
                      className="mt-2"
                    />
                  </div>

                  <div>
                    <Label>{t.gender}</Label>
                    <select
                      value={editedProfile.gender}
                      onChange={(e) => setEditedProfile({ ...editedProfile, gender: e.target.value })}
                      className="w-full mt-2 border border-gray-300 rounded-lg px-3 py-2 bg-white"
                    >
                      <option value="male">{t.male}</option>
                      <option value="female">{t.female}</option>
                      <option value="other">{t.other}</option>
                    </select>
                  </div>
                </div>

                <div>
                  <Label>{t.bio}</Label>
                  <Textarea
                    value={editedProfile.bio}
                    onChange={(e) => setEditedProfile({ ...editedProfile, bio: e.target.value })}
                    placeholder={t.bioPlaceholder}
                    rows={4}
                    className="mt-2"
                    dir={language === 'en' ? 'ltr' : 'rtl'}
                  />
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </motion.div>

        {/* Account Settings */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="mt-6 bg-white/90 backdrop-blur-xl rounded-3xl shadow-xl p-6 border border-white/50"
        >
          <h3 className="text-xl font-bold mb-4 flex items-center gap-2">
            <SettingsIcon className="w-6 h-6" />
            {t.accountSettings}
          </h3>

          <div className="space-y-3">
            {/* Language Selector */}
            <button
              onClick={() => {}}
              className="w-full flex items-center justify-between p-4 hover:bg-gray-50 rounded-2xl transition-colors group"
            >
              <div className="flex items-center gap-3">
                <div className="p-2 bg-blue-100 rounded-xl group-hover:bg-blue-200 transition-colors">
                  <Globe className="w-5 h-5 text-blue-600" />
                </div>
                <div className="text-left">
                  <div className="font-semibold">{t.language}</div>
                  <div className="text-sm text-gray-600">
                    {language === 'ps' ? t.pashto : language === 'fa' ? t.dari : t.english}
                  </div>
                </div>
              </div>
              <div className="flex gap-2">
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    onLanguageChange('ps');
                  }}
                  className={`px-3 py-1 rounded-lg text-sm transition-colors ${
                    language === 'ps' ? 'bg-blue-500 text-white' : 'bg-gray-200 hover:bg-gray-300'
                  }`}
                >
                  پښتو
                </button>
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    onLanguageChange('fa');
                  }}
                  className={`px-3 py-1 rounded-lg text-sm transition-colors ${
                    language === 'fa' ? 'bg-blue-500 text-white' : 'bg-gray-200 hover:bg-gray-300'
                  }`}
                >
                  دری
                </button>
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    onLanguageChange('en');
                  }}
                  className={`px-3 py-1 rounded-lg text-sm transition-colors ${
                    language === 'en' ? 'bg-blue-500 text-white' : 'bg-gray-200 hover:bg-gray-300'
                  }`}
                >
                  EN
                </button>
              </div>
            </button>

            {/* Favorites */}
            <button
              onClick={() => {}}
              className="w-full flex items-center justify-between p-4 hover:bg-gray-50 rounded-2xl transition-colors group"
            >
              <div className="flex items-center gap-3">
                <div className="p-2 bg-pink-100 rounded-xl group-hover:bg-pink-200 transition-colors">
                  <Heart className="w-5 h-5 text-pink-600" />
                </div>
                <div className="text-left">
                  <div className="font-semibold">{t.favorites}</div>
                  <div className="text-sm text-gray-600">View saved items</div>
                </div>
              </div>
              <Star className="w-5 h-5 text-gray-400" />
            </button>

            {/* Notifications */}
            <button
              onClick={() => {}}
              className="w-full flex items-center justify-between p-4 hover:bg-gray-50 rounded-2xl transition-colors group"
            >
              <div className="flex items-center gap-3">
                <div className="p-2 bg-purple-100 rounded-xl group-hover:bg-purple-200 transition-colors">
                  <Bell className="w-5 h-5 text-purple-600" />
                </div>
                <div className="text-left">
                  <div className="font-semibold">{t.notifications}</div>
                  <div className="text-sm text-gray-600">Manage notifications</div>
                </div>
              </div>
              <SettingsIcon className="w-5 h-5 text-gray-400" />
            </button>

            {/* Privacy */}
            <button
              onClick={() => {}}
              className="w-full flex items-center justify-between p-4 hover:bg-gray-50 rounded-2xl transition-colors group"
            >
              <div className="flex items-center gap-3">
                <div className="p-2 bg-green-100 rounded-xl group-hover:bg-green-200 transition-colors">
                  <Shield className="w-5 h-5 text-green-600" />
                </div>
                <div className="text-left">
                  <div className="font-semibold">{t.privacy}</div>
                  <div className="text-sm text-gray-600">Privacy settings</div>
                </div>
              </div>
              <Award className="w-5 h-5 text-gray-400" />
            </button>

            {/* Clear Cache */}
            <button
              onClick={handleClearCache}
              className="w-full flex items-center justify-between p-4 hover:bg-gray-50 rounded-2xl transition-colors group"
            >
              <div className="flex items-center gap-3">
                <div className="p-2 bg-orange-100 rounded-xl group-hover:bg-orange-200 transition-colors">
                  <Trash2 className="w-5 h-5 text-orange-600" />
                </div>
                <div className="text-left">
                  <div className="font-semibold">{t.clearCache}</div>
                  <div className="text-sm text-gray-600">Clear app cache</div>
                </div>
              </div>
            </button>
          </div>
        </motion.div>

        {/* Premium Upsell */}
        {!isPremium && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
            className="mt-6 bg-gradient-to-r from-yellow-400 via-orange-500 to-pink-600 rounded-3xl p-6 text-white shadow-xl mb-6"
          >
            <div className="flex items-center justify-between flex-wrap gap-4">
              <div className="flex items-center gap-4">
                <div className="bg-white/20 p-3 rounded-2xl">
                  <Crown className="w-8 h-8" />
                </div>
                <div>
                  <h3 className="text-xl font-bold mb-1">{t.premium}</h3>
                  <p className="text-white/90">
                    {language === 'ps'
                      ? 'Premium ته اپګریډ کړئ او ټول features خلاص کړئ!'
                      : language === 'fa'
                      ? 'به پریمیوم ارتقا دهید و همه ویژگی‌ها را باز کنید!'
                      : 'Upgrade to Premium and unlock all features!'}
                  </p>
                </div>
              </div>
              <Button className="bg-white text-orange-600 hover:bg-white/90">
                {language === 'ps' ? 'اپګریډ کړئ' : language === 'fa' ? 'ارتقا دهید' : 'Upgrade'}
              </Button>
            </div>
          </motion.div>
        )}
      </div>
    </div>
  );
}