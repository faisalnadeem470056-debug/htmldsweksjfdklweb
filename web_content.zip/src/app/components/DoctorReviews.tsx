import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "./ui/avatar";
import { Textarea } from "./ui/textarea";
import { Progress } from "./ui/progress";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "./ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs";
import { Separator } from "./ui/separator";
import { 
  Star,
  ThumbsUp,
  ThumbsDown,
  MessageSquare,
  CheckCircle2,
  Shield,
  Award,
  TrendingUp,
  Heart,
  Clock,
  MapPin,
  Calendar,
  Send,
  Image as ImageIcon,
  MoreVertical,
  Flag,
  Share2,
  Sparkles
} from "lucide-react";
import { useLanguage } from "../contexts/LanguageContext";

interface Review {
  id: number;
  patientName: string;
  patientImage: string;
  isVerified: boolean;
  rating: number;
  date: string;
  treatmentType: string;
  review: string;
  helpful: number;
  doctorResponse?: {
    message: string;
    date: string;
  };
  images?: string[];
}

const mockReviews: Review[] = [
  {
    id: 1,
    patientName: "Alex Morgan",
    patientImage: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=100&h=100&fit=crop",
    isVerified: true,
    rating: 5,
    date: "2 days ago",
    treatmentType: "General Checkup",
    review: "Dr. Naseri is an excellent cardiologist. Very professional and caring. He took time to explain everything in detail and answered all my questions. Highly recommend!",
    helpful: 24,
    doctorResponse: {
      message: "Thank you so much for your kind words! It was a pleasure treating you. Wishing you good health!",
      date: "1 day ago"
    }
  },
  {
    id: 2,
    patientName: "Jordan Smith",
    patientImage: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=100&h=100&fit=crop",
    isVerified: true,
    rating: 5,
    date: "5 days ago",
    treatmentType: "Heart Consultation",
    review: "Outstanding doctor! Very knowledgeable and compassionate. The staff was also very helpful. Clean clinic and modern equipment.",
    helpful: 18,
    doctorResponse: {
      message: "I appreciate your feedback! Take care and don't hesitate to reach out if you need anything.",
      date: "4 days ago"
    }
  },
  {
    id: 3,
    patientName: "Hassan Karimi",
    patientImage: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&h=100&fit=crop",
    isVerified: true,
    rating: 4,
    date: "1 week ago",
    treatmentType: "Follow-up Visit",
    review: "Good experience overall. Wait time was a bit long but the consultation was thorough. Doctor is very experienced.",
    helpful: 12
  },
  {
    id: 4,
    patientName: "Mariam Hashimi",
    patientImage: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=100&h=100&fit=crop",
    isVerified: true,
    rating: 5,
    date: "2 weeks ago",
    treatmentType: "Cardiac Screening",
    review: "Best cardiologist in Kabul! Very patient and explains everything clearly. I feel much better after following his treatment plan.",
    helpful: 31,
    images: ["https://images.unsplash.com/photo-1631217868264-e5b90bb7e133?w=200&h=200&fit=crop"]
  },
  {
    id: 5,
    patientName: "Omar Safi",
    patientImage: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=100&h=100&fit=crop",
    isVerified: false,
    rating: 5,
    date: "3 weeks ago",
    treatmentType: "ECG Test",
    review: "Professional service and accurate diagnosis. Highly recommend to anyone with heart concerns.",
    helpful: 9
  },
];

function DoctorReviews() {
  const { t } = useLanguage();
  const [reviews, setReviews] = useState<Review[]>(mockReviews);
  const [writeReviewOpen, setWriteReviewOpen] = useState(false);
  const [newRating, setNewRating] = useState(0);
  const [newReview, setNewReview] = useState("");
  const [filterRating, setFilterRating] = useState("all");

  // Calculate statistics
  const totalReviews = reviews.length;
  const averageRating = reviews.reduce((sum, r) => sum + r.rating, 0) / totalReviews;
  const ratingCounts = [5, 4, 3, 2, 1].map(rating => 
    reviews.filter(r => r.rating === rating).length
  );

  const filteredReviews = filterRating === "all" 
    ? reviews 
    : reviews.filter(r => r.rating === parseInt(filterRating));

  const handleHelpful = (reviewId: number) => {
    setReviews(reviews.map(r => 
      r.id === reviewId ? { ...r, helpful: r.helpful + 1 } : r
    ));
  };

  const StarRating = ({ rating, size = 5, interactive = false, onRate }: any) => {
    return (
      <div className="flex items-center gap-1">
        {[1, 2, 3, 4, 5].map((star) => (
          <button
            key={star}
            onClick={() => interactive && onRate && onRate(star)}
            disabled={!interactive}
            className={interactive ? "cursor-pointer hover:scale-110 transition-transform" : ""}
          >
            <Star
              className={`w-${size} h-${size} ${
                star <= rating 
                  ? "fill-yellow-400 text-yellow-400" 
                  : "text-gray-300"
              }`}
            />
          </button>
        ))}
      </div>
    );
  };

  return (
    <section className="py-16 md:py-24 bg-gradient-to-b from-white via-amber-50/30 to-white relative overflow-hidden min-h-screen">
      {/* Background decoration */}
      <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-gradient-to-br from-amber-100/50 to-yellow-100/50 rounded-full blur-3xl animate-float"></div>
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        {/* Header */}
        <div className="text-center mb-12 md:mb-16 space-y-4">
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-amber-100 to-yellow-100 rounded-full">
            <Sparkles className="w-4 h-4 text-amber-600 animate-pulse-glow" />
            <span className="text-amber-700 text-sm uppercase tracking-wider">Patient Reviews</span>
          </div>
          <h2 className="text-4xl md:text-6xl">
            <span className="bg-gradient-to-r from-amber-600 via-yellow-600 to-orange-600 bg-clip-text text-transparent">
              Doctor Reviews & Ratings
            </span>
          </h2>
          <p className="text-gray-600 max-w-2xl mx-auto text-lg">
            د ډاکټر درجه بندي او تبصرې - Verified patient reviews and ratings
          </p>
        </div>

        {/* Doctor Overview Card */}
        <Card className="border-0 shadow-lg mb-8">
          <CardContent className="p-6">
            <div className="flex flex-col md:flex-row items-start md:items-center gap-6">
              {/* Doctor Info */}
              <div className="flex items-center gap-4 flex-1">
                <Avatar className="w-20 h-20">
                  <AvatarImage src="https://images.unsplash.com/photo-1755189118414-14c8dacdb082?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxkb2N0b3IlMjBwb3J0cmFpdCUyMHByb2Zlc3Npb25hbHxlbnwxfHx8fDE3NjMxMjU5OTZ8MA&ixlib=rb-4.1.0&q=80&w=1080" />
                  <AvatarFallback>DN</AvatarFallback>
                </Avatar>
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-1">
                    <h3 className="text-xl text-gray-900">Dr. Ahmad Naseri</h3>
                    <Badge className="bg-blue-100 text-blue-700">
                      <Shield className="w-3 h-3 mr-1" />
                      Verified
                    </Badge>
                  </div>
                  <p className="text-sm text-gray-600 mb-2">Cardiologist • 15 years experience</p>
                  <div className="flex items-center gap-4 text-sm text-gray-600">
                    <span className="flex items-center gap-1">
                      <MapPin className="w-4 h-4" />
                      Kabul, Afghanistan
                    </span>
                    <span className="flex items-center gap-1">
                      <Heart className="w-4 h-4" />
                      {totalReviews} Patients
                    </span>
                  </div>
                </div>
              </div>

              {/* Rating Overview */}
              <div className="flex flex-col items-center gap-2 p-4 bg-gradient-to-r from-amber-50 to-yellow-50 rounded-lg">
                <div className="text-5xl text-amber-600">{averageRating.toFixed(1)}</div>
                <StarRating rating={Math.round(averageRating)} size={5} />
                <p className="text-sm text-gray-600">{totalReviews} Reviews</p>
              </div>

              {/* Action Button */}
              <Button 
                className="bg-gradient-to-r from-amber-500 to-yellow-600 hover:from-amber-600 hover:to-yellow-700"
                onClick={() => setWriteReviewOpen(true)}
              >
                <Star className="w-4 h-4 mr-2" />
                Write a Review
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Rating Breakdown */}
        <Card className="border-0 shadow-lg mb-8">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Award className="w-5 h-5 text-amber-600" />
              Rating Breakdown - د درجه بندۍ تفصیل
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {[5, 4, 3, 2, 1].map((rating, index) => (
                <div key={rating} className="flex items-center gap-4">
                  <div className="flex items-center gap-1 w-20">
                    <span className="text-sm text-gray-700">{rating}</span>
                    <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                  </div>
                  <Progress 
                    value={(ratingCounts[index] / totalReviews) * 100} 
                    className="flex-1 h-3" 
                  />
                  <span className="text-sm text-gray-600 w-12 text-right">
                    {ratingCounts[index]}
                  </span>
                </div>
              ))}
            </div>

            <Separator className="my-6" />

            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <div className="p-4 bg-green-50 rounded-lg text-center">
                <TrendingUp className="w-6 h-6 text-green-600 mx-auto mb-2" />
                <p className="text-2xl text-green-600">96%</p>
                <p className="text-xs text-gray-600">Recommend Rate</p>
              </div>
              <div className="p-4 bg-blue-50 rounded-lg text-center">
                <CheckCircle2 className="w-6 h-6 text-blue-600 mx-auto mb-2" />
                <p className="text-2xl text-blue-600">{reviews.filter(r => r.isVerified).length}</p>
                <p className="text-xs text-gray-600">Verified Patients</p>
              </div>
              <div className="p-4 bg-purple-50 rounded-lg text-center">
                <MessageSquare className="w-6 h-6 text-purple-600 mx-auto mb-2" />
                <p className="text-2xl text-purple-600">{reviews.filter(r => r.doctorResponse).length}</p>
                <p className="text-xs text-gray-600">Doctor Responses</p>
              </div>
              <div className="p-4 bg-amber-50 rounded-lg text-center">
                <Clock className="w-6 h-6 text-amber-600 mx-auto mb-2" />
                <p className="text-2xl text-amber-600">24h</p>
                <p className="text-xs text-gray-600">Avg Response Time</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Filter Tabs */}
        <div className="flex items-center gap-2 mb-6 overflow-x-auto pb-2">
          <Button
            variant={filterRating === "all" ? "default" : "outline"}
            size="sm"
            onClick={() => setFilterRating("all")}
            className={filterRating === "all" ? "bg-gradient-to-r from-amber-500 to-yellow-600" : ""}
          >
            All Reviews ({totalReviews})
          </Button>
          {[5, 4, 3, 2, 1].map((rating) => (
            <Button
              key={rating}
              variant={filterRating === rating.toString() ? "default" : "outline"}
              size="sm"
              onClick={() => setFilterRating(rating.toString())}
              className={filterRating === rating.toString() ? "bg-gradient-to-r from-amber-500 to-yellow-600" : ""}
            >
              <Star className="w-4 h-4 mr-1 fill-yellow-400 text-yellow-400" />
              {rating} ({ratingCounts[5 - rating]})
            </Button>
          ))}
        </div>

        {/* Reviews List */}
        <div className="space-y-6">
          {filteredReviews.map((review) => (
            <Card key={review.id} className="border-0 shadow-lg hover-lift">
              <CardContent className="p-6">
                {/* Review Header */}
                <div className="flex items-start justify-between mb-4">
                  <div className="flex items-start gap-3">
                    <Avatar className="w-12 h-12">
                      <AvatarImage src={review.patientImage} />
                      <AvatarFallback>{review.patientName[0]}</AvatarFallback>
                    </Avatar>
                    <div>
                      <div className="flex items-center gap-2 mb-1">
                        <h4 className="text-base text-gray-900">{review.patientName}</h4>
                        {review.isVerified && (
                          <Badge className="bg-green-100 text-green-700 text-xs">
                            <CheckCircle2 className="w-3 h-3 mr-1" />
                            Verified Patient
                          </Badge>
                        )}
                      </div>
                      <div className="flex items-center gap-2 mb-2">
                        <StarRating rating={review.rating} size={4} />
                        <span className="text-xs text-gray-600">• {review.date}</span>
                      </div>
                      <Badge variant="outline" className="text-xs">
                        {review.treatmentType}
                      </Badge>
                    </div>
                  </div>

                  <Button variant="ghost" size="icon">
                    <MoreVertical className="w-4 h-4" />
                  </Button>
                </div>

                {/* Review Content */}
                <p className="text-gray-700 mb-4 leading-relaxed">
                  {review.review}
                </p>

                {/* Review Images */}
                {review.images && review.images.length > 0 && (
                  <div className="flex gap-2 mb-4">
                    {review.images.map((img, index) => (
                      <img
                        key={index}
                        src={img}
                        alt="Review"
                        className="w-20 h-20 rounded-lg object-cover cursor-pointer hover:scale-105 transition-transform"
                      />
                    ))}
                  </div>
                )}

                {/* Review Actions */}
                <div className="flex items-center gap-4">
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => handleHelpful(review.id)}
                    className="text-gray-600 hover:text-blue-600"
                  >
                    <ThumbsUp className="w-4 h-4 mr-2" />
                    Helpful ({review.helpful})
                  </Button>
                  <Button variant="ghost" size="sm" className="text-gray-600">
                    <Share2 className="w-4 h-4 mr-2" />
                    Share
                  </Button>
                  <Button variant="ghost" size="sm" className="text-gray-600">
                    <Flag className="w-4 h-4 mr-2" />
                    Report
                  </Button>
                </div>

                {/* Doctor Response */}
                {review.doctorResponse && (
                  <>
                    <Separator className="my-4" />
                    <div className="p-4 bg-gradient-to-r from-blue-50 to-cyan-50 rounded-lg">
                      <div className="flex items-start gap-3">
                        <div className="p-2 bg-blue-500 rounded-full">
                          <MessageSquare className="w-4 h-4 text-white" />
                        </div>
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-2">
                            <span className="text-sm text-blue-900">Response from Dr. Naseri</span>
                            <span className="text-xs text-gray-600">• {review.doctorResponse.date}</span>
                          </div>
                          <p className="text-sm text-gray-700">
                            {review.doctorResponse.message}
                          </p>
                        </div>
                      </div>
                    </div>
                  </>
                )}
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Load More */}
        <div className="text-center mt-8">
          <Button variant="outline" size="lg">
            Load More Reviews
          </Button>
        </div>
      </div>

      {/* Write Review Modal */}
      <Dialog open={writeReviewOpen} onOpenChange={setWriteReviewOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle className="text-2xl">Write a Review - تبصره ولیکئ</DialogTitle>
            <DialogDescription>Share your experience and rate the doctor</DialogDescription>
          </DialogHeader>
          <div className="space-y-6">
            {/* Rating Selection */}
            <div className="text-center">
              <p className="text-sm text-gray-700 mb-3">Rate your experience:</p>
              <StarRating 
                rating={newRating} 
                size={8} 
                interactive 
                onRate={setNewRating}
              />
              {newRating > 0 && (
                <p className="text-sm text-gray-600 mt-2">
                  {newRating === 5 && "Excellent! 🌟"}
                  {newRating === 4 && "Very Good! 👍"}
                  {newRating === 3 && "Good"}
                  {newRating === 2 && "Could be better"}
                  {newRating === 1 && "Needs improvement"}
                </p>
              )}
            </div>

            <Separator />

            {/* Review Text */}
            <div>
              <label className="text-sm text-gray-700 mb-2 block">
                Your Review - ستاسو تبصره
              </label>
              <Textarea
                placeholder="Share your experience with Dr. Naseri..."
                value={newReview}
                onChange={(e) => setNewReview(e.target.value)}
                className="min-h-[150px]"
              />
              <p className="text-xs text-gray-600 mt-1">
                {newReview.length}/500 characters
              </p>
            </div>

            {/* Upload Photos */}
            <div>
              <label className="text-sm text-gray-700 mb-2 block">
                Add Photos (Optional)
              </label>
              <Button variant="outline" className="w-full">
                <ImageIcon className="w-4 h-4 mr-2" />
                Upload Photos
              </Button>
            </div>

            {/* Submit */}
            <div className="flex gap-3">
              <Button
                variant="outline"
                className="flex-1"
                onClick={() => setWriteReviewOpen(false)}
              >
                Cancel
              </Button>
              <Button
                className="flex-1 bg-gradient-to-r from-amber-500 to-yellow-600"
                disabled={newRating === 0 || newReview.trim().length === 0}
              >
                <Send className="w-4 h-4 mr-2" />
                Submit Review
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </section>
  );
}

export default DoctorReviews;
