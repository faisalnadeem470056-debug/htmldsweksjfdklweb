import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "./ui/avatar";
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs";
import { Input } from "./ui/input";
import { Textarea } from "./ui/textarea";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogFooter } from "./ui/dialog";
import { ImageWithFallback } from "./figma/ImageWithFallback";
import { Alert, AlertDescription } from "./ui/alert";
import { 
  Heart, 
  MessageCircle, 
  Share2, 
  Bookmark,
  Edit,
  Trash2,
  Eye,
  TrendingUp,
  Sparkles,
  Plus,
  BarChart3,
  Users,
  Calendar,
  CheckCircle2,
  Clock,
  Image as ImageIcon,
  Video,
  Smile
} from "lucide-react";
import { toast } from "sonner@2.0.3";
import { useAuth } from "../contexts/AuthContext";
import { AdBanner } from "./AdBanner";

interface Post {
  id: number;
  time: string;
  content: string;
  contentDari: string;
  image?: string;
  likes: number;
  comments: number;
  shares: number;
  views: number;
  status: "published" | "draft";
  isLiked: boolean;
  isBookmarked: boolean;
}

const initialMyPosts: Post[] = [
  {
    id: 1,
    time: "2 hours ago",
    content: "Just finished a great workout session! Remember, consistency is key to achieving your fitness goals. 💪 #HealthyLiving #Fitness",
    contentDari: "د ښه تمرین ناسته مې بشپړه کړه! یاد ولرئ، د خپلو فټنس اهدافو ترلاسه کولو لپاره دوام کلیدي دی.",
    image: "https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?w=600&h=400&fit=crop",
    likes: 45,
    comments: 12,
    shares: 5,
    views: 234,
    status: "published",
    isLiked: false,
    isBookmarked: false,
  },
  {
    id: 2,
    time: "1 day ago",
    content: "Healthy breakfast ideas for busy mornings! Quick, nutritious, and delicious. What's your favorite breakfast? 🥗",
    contentDari: "د مصروفو سهارونو لپاره د صحي ناشتا نظرونه! چټک، مغذي، او خوندور. ستاسو خوښه ناشتا څه ده؟",
    image: "https://images.unsplash.com/photo-1533089860892-a7c6f0a88666?w=600&h=400&fit=crop",
    likes: 89,
    comments: 23,
    shares: 15,
    views: 567,
    status: "published",
    isLiked: true,
    isBookmarked: true,
  },
  {
    id: 3,
    time: "3 days ago",
    content: "Mental health matters! Here are 5 simple techniques to reduce stress and anxiety in your daily life. Take care of yourself. 🧘‍♀️💚",
    contentDari: "ذهني روغتیا مهمه ده! دلته 5 ساده تخنیکونه دي چې ستاسو په ورځني ژوند کې فشار او اضطراب کموي. د خپل ځان پاملرنه وکړئ.",
    likes: 156,
    comments: 34,
    shares: 28,
    views: 892,
    status: "published",
    isLiked: true,
    isBookmarked: false,
  },
  {
    id: 4,
    time: "Draft",
    content: "Working on a comprehensive guide about healthy eating habits...",
    contentDari: "د صحي خوراک عادتونو په اړه د جامع لارښود پر کار روان یم...",
    likes: 0,
    comments: 0,
    shares: 0,
    views: 0,
    status: "draft",
    isLiked: false,
    isBookmarked: false,
  },
];

function MyPosts() {
  const { user } = useAuth();
  const [activeTab, setActiveTab] = useState("published");
  const [posts, setPosts] = useState<Post[]>(initialMyPosts);
  const [createPostOpen, setCreatePostOpen] = useState(false);
  const [editPostOpen, setEditPostOpen] = useState(false);
  const [deleteConfirmOpen, setDeleteConfirmOpen] = useState(false);
  const [selectedPost, setSelectedPost] = useState<Post | null>(null);
  const [newPostContent, setNewPostContent] = useState("");
  const [editPostContent, setEditPostContent] = useState("");

  const publishedPosts = posts.filter(p => p.status === "published");
  const draftPosts = posts.filter(p => p.status === "draft");

  // Calculate stats
  const totalLikes = publishedPosts.reduce((sum, p) => sum + p.likes, 0);
  const totalComments = publishedPosts.reduce((sum, p) => sum + p.comments, 0);
  const totalViews = publishedPosts.reduce((sum, p) => sum + p.views, 0);

  const handleCreatePost = () => {
    if (!newPostContent.trim()) return;

    const newPost: Post = {
      id: posts.length + 1,
      time: "Just now",
      content: newPostContent,
      contentDari: newPostContent,
      likes: 0,
      comments: 0,
      shares: 0,
      views: 0,
      status: "published",
      isLiked: false,
      isBookmarked: false,
    };

    setPosts([newPost, ...posts]);
    setNewPostContent("");
    setCreatePostOpen(false);
    toast.success("Post published successfully!");
  };

  const handleSaveDraft = () => {
    if (!newPostContent.trim()) return;

    const newPost: Post = {
      id: posts.length + 1,
      time: "Draft",
      content: newPostContent,
      contentDari: newPostContent,
      likes: 0,
      comments: 0,
      shares: 0,
      views: 0,
      status: "draft",
      isLiked: false,
      isBookmarked: false,
    };

    setPosts([newPost, ...posts]);
    setNewPostContent("");
    setCreatePostOpen(false);
    toast.success("Saved as draft!");
  };

  const handleEditPost = () => {
    if (!selectedPost || !editPostContent.trim()) return;

    setPosts(posts.map(p => 
      p.id === selectedPost.id 
        ? { ...p, content: editPostContent, contentDari: editPostContent }
        : p
    ));
    
    setEditPostOpen(false);
    setSelectedPost(null);
    setEditPostContent("");
    toast.success("Post updated successfully!");
  };

  const handleDeletePost = () => {
    if (!selectedPost) return;

    setPosts(posts.filter(p => p.id !== selectedPost.id));
    setDeleteConfirmOpen(false);
    setSelectedPost(null);
    toast.success("Post deleted successfully!");
  };

  const handlePublishDraft = (post: Post) => {
    setPosts(posts.map(p => 
      p.id === post.id 
        ? { ...p, status: "published" as const, time: "Just now" }
        : p
    ));
    toast.success("Draft published successfully!");
  };

  const openEditDialog = (post: Post) => {
    setSelectedPost(post);
    setEditPostContent(post.content);
    setEditPostOpen(true);
  };

  const openDeleteDialog = (post: Post) => {
    setSelectedPost(post);
    setDeleteConfirmOpen(true);
  };

  return (
    <section className="py-16 md:py-24 bg-gradient-to-b from-white via-violet-50/30 to-white relative overflow-hidden min-h-screen">
      {/* Background decoration */}
      <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-gradient-to-br from-violet-100/50 to-purple-100/50 rounded-full blur-3xl animate-float"></div>
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        {/* Header */}
        <div className="text-center mb-12 md:mb-16 space-y-4">
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-violet-100 to-purple-100 rounded-full">
            <Sparkles className="w-4 h-4 text-violet-600 animate-pulse-glow" />
            <span className="text-violet-700 text-sm uppercase tracking-wider">My Posts</span>
          </div>
          <h2 className="text-4xl md:text-6xl">
            <span className="bg-gradient-to-r from-violet-600 via-purple-600 to-fuchsia-600 bg-clip-text text-transparent">
              زما پوستونه
            </span>
          </h2>
          <p className="text-gray-600 max-w-2xl mx-auto text-lg">
            Manage your health posts and community contributions
          </p>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <Card className="border-0 shadow-lg hover-lift">
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-2">
                <div className="p-3 bg-gradient-to-br from-blue-500 to-cyan-600 rounded-xl">
                  <Eye className="w-6 h-6 text-white" />
                </div>
                <Badge className="bg-blue-100 text-blue-700">Total</Badge>
              </div>
              <p className="text-3xl text-gray-900 mb-1">{totalViews}</p>
              <p className="text-sm text-gray-600">Views</p>
            </CardContent>
          </Card>

          <Card className="border-0 shadow-lg hover-lift">
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-2">
                <div className="p-3 bg-gradient-to-br from-pink-500 to-rose-600 rounded-xl">
                  <Heart className="w-6 h-6 text-white" />
                </div>
                <Badge className="bg-pink-100 text-pink-700">Total</Badge>
              </div>
              <p className="text-3xl text-gray-900 mb-1">{totalLikes}</p>
              <p className="text-sm text-gray-600">Likes</p>
            </CardContent>
          </Card>

          <Card className="border-0 shadow-lg hover-lift">
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-2">
                <div className="p-3 bg-gradient-to-br from-purple-500 to-violet-600 rounded-xl">
                  <MessageCircle className="w-6 h-6 text-white" />
                </div>
                <Badge className="bg-purple-100 text-purple-700">Total</Badge>
              </div>
              <p className="text-3xl text-gray-900 mb-1">{totalComments}</p>
              <p className="text-sm text-gray-600">Comments</p>
            </CardContent>
          </Card>

          <Card className="border-0 shadow-lg hover-lift">
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-2">
                <div className="p-3 bg-gradient-to-br from-green-500 to-emerald-600 rounded-xl">
                  <BarChart3 className="w-6 h-6 text-white" />
                </div>
                <Badge className="bg-green-100 text-green-700">Active</Badge>
              </div>
              <p className="text-3xl text-gray-900 mb-1">{publishedPosts.length}</p>
              <p className="text-sm text-gray-600">Published</p>
            </CardContent>
          </Card>
        </div>

        {/* Create Post Button */}
        <div className="mb-8">
          <Button
            size="lg"
            className="bg-gradient-to-r from-violet-500 to-purple-600 hover:from-violet-600 hover:to-purple-700"
            onClick={() => setCreatePostOpen(true)}
          >
            <Plus className="w-5 h-5 mr-2" />
            Create New Post
          </Button>
        </div>

        {/* Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-2 mb-8">
            <TabsTrigger value="published">
              <CheckCircle2 className="w-4 h-4 mr-2" />
              Published ({publishedPosts.length})
            </TabsTrigger>
            <TabsTrigger value="drafts">
              <Clock className="w-4 h-4 mr-2" />
              Drafts ({draftPosts.length})
            </TabsTrigger>
          </TabsList>

          {/* Published Posts */}
          <TabsContent value="published" className="space-y-6">
            {publishedPosts.length === 0 ? (
              <Card className="border-0 shadow-lg">
                <CardContent className="p-12 text-center">
                  <BarChart3 className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                  <h3 className="text-xl text-gray-900 mb-2">No published posts yet</h3>
                  <p className="text-gray-600 mb-6">Start sharing your health journey with the community</p>
                  <Button
                    className="bg-gradient-to-r from-violet-500 to-purple-600"
                    onClick={() => setCreatePostOpen(true)}
                  >
                    Create Your First Post
                  </Button>
                </CardContent>
              </Card>
            ) : (
              publishedPosts.map((post, index) => (
                <>
                  {/* Show Ad after every 3 posts */}
                  {index > 0 && index % 3 === 0 && (
                    <div key={`ad-${index}`}>
                      <AdBanner size="large" position="middle" />
                    </div>
                  )}
                  
                <Card key={post.id} className="border-0 shadow-lg hover-lift">
                  <CardContent className="p-6">
                    {/* Post Header */}
                    <div className="flex items-start justify-between mb-4">
                      <div className="flex items-start gap-3">
                        <Avatar className="w-12 h-12">
                          <AvatarImage src={user?.avatar || "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150&h=150&fit=crop"} />
                          <AvatarFallback>{user?.firstName?.[0] || "U"}</AvatarFallback>
                        </Avatar>
                        <div>
                          <h4 className="text-base text-gray-900">{user?.firstName} {user?.lastName}</h4>
                          <p className="text-sm text-gray-600">Community Member</p>
                          <p className="text-xs text-gray-500">{post.time}</p>
                        </div>
                      </div>
                      <div className="flex gap-2">
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => openEditDialog(post)}
                        >
                          <Edit className="w-4 h-4" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => openDeleteDialog(post)}
                          className="text-red-600 hover:text-red-700"
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>

                    {/* Post Content */}
                    <p className="text-gray-700 mb-4 leading-relaxed">
                      {post.content}
                    </p>
                    <p className="text-violet-600 mb-4 text-sm">
                      {post.contentDari}
                    </p>

                    {/* Post Image */}
                    {post.image && (
                      <div className="mb-4 rounded-xl overflow-hidden">
                        <ImageWithFallback
                          src={post.image}
                          alt="Post"
                          className="w-full h-auto object-cover"
                        />
                      </div>
                    )}

                    {/* Post Stats */}
                    <div className="grid grid-cols-4 gap-4 p-4 bg-gradient-to-r from-violet-50 to-purple-50 rounded-lg">
                      <div className="text-center">
                        <Eye className="w-5 h-5 text-violet-600 mx-auto mb-1" />
                        <p className="text-sm text-gray-900">{post.views}</p>
                        <p className="text-xs text-gray-600">Views</p>
                      </div>
                      <div className="text-center">
                        <Heart className="w-5 h-5 text-pink-600 mx-auto mb-1" />
                        <p className="text-sm text-gray-900">{post.likes}</p>
                        <p className="text-xs text-gray-600">Likes</p>
                      </div>
                      <div className="text-center">
                        <MessageCircle className="w-5 h-5 text-blue-600 mx-auto mb-1" />
                        <p className="text-sm text-gray-900">{post.comments}</p>
                        <p className="text-xs text-gray-600">Comments</p>
                      </div>
                      <div className="text-center">
                        <Share2 className="w-5 h-5 text-green-600 mx-auto mb-1" />
                        <p className="text-sm text-gray-900">{post.shares}</p>
                        <p className="text-xs text-gray-600">Shares</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
                </>
              ))
            )}
          </TabsContent>

          {/* Draft Posts */}
          <TabsContent value="drafts" className="space-y-6">
            {draftPosts.length === 0 ? (
              <Card className="border-0 shadow-lg">
                <CardContent className="p-12 text-center">
                  <Clock className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                  <h3 className="text-xl text-gray-900 mb-2">No drafts</h3>
                  <p className="text-gray-600">All your draft posts will appear here</p>
                </CardContent>
              </Card>
            ) : (
              draftPosts.map((post) => (
                <Card key={post.id} className="border-0 shadow-lg hover-lift">
                  <CardContent className="p-6">
                    <div className="flex items-start justify-between mb-4">
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-2">
                          <Badge className="bg-yellow-100 text-yellow-700">
                            <Clock className="w-3 h-3 mr-1" />
                            Draft
                          </Badge>
                        </div>
                        <p className="text-gray-700 leading-relaxed">{post.content}</p>
                        <p className="text-violet-600 text-sm mt-2">{post.contentDari}</p>
                      </div>
                    </div>
                    <div className="flex gap-2 mt-4">
                      <Button
                        className="bg-gradient-to-r from-violet-500 to-purple-600"
                        onClick={() => handlePublishDraft(post)}
                      >
                        <CheckCircle2 className="w-4 h-4 mr-2" />
                        Publish
                      </Button>
                      <Button
                        variant="outline"
                        onClick={() => openEditDialog(post)}
                      >
                        <Edit className="w-4 h-4 mr-2" />
                        Edit
                      </Button>
                      <Button
                        variant="outline"
                        onClick={() => openDeleteDialog(post)}
                        className="text-red-600 hover:text-red-700"
                      >
                        <Trash2 className="w-4 h-4 mr-2" />
                        Delete
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))
            )}
          </TabsContent>
        </Tabs>
      </div>

      {/* Create Post Dialog */}
      <Dialog open={createPostOpen} onOpenChange={setCreatePostOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle className="text-2xl">Create New Post - نوی پوست جوړ کړئ</DialogTitle>
            <DialogDescription>Share your health journey with the community</DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <Textarea
              placeholder="What would you like to share? Tips, experiences, questions..."
              value={newPostContent}
              onChange={(e) => setNewPostContent(e.target.value)}
              className="min-h-[150px] resize-none"
            />

            <div className="flex items-center gap-2 text-sm text-gray-600">
              <Button variant="ghost" size="sm">
                <ImageIcon className="w-4 h-4 mr-2" />
                Photo
              </Button>
              <Button variant="ghost" size="sm">
                <Video className="w-4 h-4 mr-2" />
                Video
              </Button>
              <Button variant="ghost" size="sm">
                <Smile className="w-4 h-4 mr-2" />
                Emoji
              </Button>
            </div>

            <div className="flex gap-3 justify-end">
              <Button variant="outline" onClick={handleSaveDraft}>
                <Clock className="w-4 h-4 mr-2" />
                Save Draft
              </Button>
              <Button
                onClick={handleCreatePost}
                disabled={!newPostContent.trim()}
                className="bg-gradient-to-r from-violet-500 to-purple-600"
              >
                <CheckCircle2 className="w-4 h-4 mr-2" />
                Publish
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Edit Post Dialog */}
      <Dialog open={editPostOpen} onOpenChange={setEditPostOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle className="text-2xl">Edit Post - پوست سمول</DialogTitle>
            <DialogDescription>Update your post content</DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <Textarea
              value={editPostContent}
              onChange={(e) => setEditPostContent(e.target.value)}
              className="min-h-[150px] resize-none"
            />
            <div className="flex gap-3 justify-end">
              <Button variant="outline" onClick={() => setEditPostOpen(false)}>
                Cancel
              </Button>
              <Button
                onClick={handleEditPost}
                className="bg-gradient-to-r from-violet-500 to-purple-600"
              >
                <CheckCircle2 className="w-4 h-4 mr-2" />
                Save Changes
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation Dialog */}
      <Dialog open={deleteConfirmOpen} onOpenChange={setDeleteConfirmOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle className="text-2xl">Delete Post - پوست ړنګول</DialogTitle>
            <DialogDescription>Are you sure you want to delete this post?</DialogDescription>
          </DialogHeader>
          <Alert className="border-red-200 bg-red-50">
            <AlertDescription className="text-red-800">
              This action cannot be undone. Your post will be permanently deleted.
            </AlertDescription>
          </Alert>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDeleteConfirmOpen(false)}>
              Cancel
            </Button>
            <Button
              onClick={handleDeletePost}
              className="bg-gradient-to-r from-red-500 to-pink-600"
            >
              <Trash2 className="w-4 h-4 mr-2" />
              Delete Post
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </section>
  );
}

export default MyPosts;
