import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { Stethoscope, Video, Pill, Activity, Calendar, AlertCircle, ArrowRight } from "lucide-react";
import { toast } from "sonner@2.0.3";
import { AdBanner } from "./AdBanner";

interface ServicesProps {
  setActivePage?: (page: string) => void;
}

const services = [
  {
    icon: Stethoscope,
    title: "Online Consultation",
    titleDari: "آنلاین مشوره",
    titlePashto: "آنلاین مشوره",
    description: "Connect with certified doctors online for medical advice and prescriptions",
    gradient: "from-blue-500 to-cyan-500",
    iconBg: "bg-blue-50",
    page: "doctors",
  },
  {
    icon: Video,
    title: "Video Appointments",
    titleDari: "ویډیو ملاقاتونه",
    titlePashto: "ویډیو ملاقاتونه",
    description: "Face-to-face consultation with specialists from anywhere",
    gradient: "from-purple-500 to-pink-500",
    iconBg: "bg-purple-50",
    page: "video-consultation",
  },
  {
    icon: Pill,
    title: "Medicine Delivery",
    titleDari: "د درملو رسول",
    titlePashto: "د درملو رسول",
    description: "Order prescribed medicines and get them delivered to your doorstep",
    gradient: "from-pink-500 to-rose-500",
    iconBg: "bg-pink-50",
    page: "pharmacy",
  },
  {
    icon: Activity,
    title: "Health Tracking",
    titleDari: "د روغتیا تعقیب",
    titlePashto: "د روغتیا تعقیب",
    description: "Monitor your vital signs, medications, and health progress over time",
    gradient: "from-emerald-500 to-teal-500",
    iconBg: "bg-emerald-50",
    page: "health-dashboard",
  },
  {
    icon: Calendar,
    title: "Appointment Booking",
    titleDari: "د ملاقات ټاکل",
    titlePashto: "د ملاقات ټاکل",
    description: "Schedule in-person appointments with doctors at nearby hospitals",
    gradient: "from-orange-500 to-amber-500",
    iconBg: "bg-orange-50",
    page: "appointments",
  },
  {
    icon: AlertCircle,
    title: "Emergency Services",
    titleDari: "بیړني خدمتونه",
    titlePashto: "بیړني خدمتونه",
    description: "Quick access to emergency contacts and first aid information",
    gradient: "from-red-500 to-orange-500",
    iconBg: "bg-red-50",
    page: "emergency",
  },
];

export function Services({ setActivePage }: ServicesProps) {
  const handleServiceClick = (service: typeof services[0]) => {
    if (setActivePage && service.page) {
      setActivePage(service.page);
      toast.success(`Opening ${service.title}...`);
      // د Page ته scroll کول
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  return (
    <section id="services" className="py-16 md:py-24 bg-gradient-to-b from-white via-teal-50/30 to-white relative overflow-hidden">
      {/* Background decoration */}
      <div className="absolute bottom-0 left-0 w-[500px] h-[500px] bg-gradient-to-tr from-teal-100/50 to-emerald-100/50 rounded-full blur-3xl animate-float-slow"></div>
      <div className="absolute top-0 right-0 w-[400px] h-[400px] bg-gradient-to-bl from-cyan-100/40 to-blue-100/40 rounded-full blur-3xl animate-float"></div>
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="text-center mb-12 md:mb-16 space-y-4">
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-emerald-100 to-teal-100 rounded-full">
            <Stethoscope className="w-4 h-4 text-emerald-600 animate-pulse-glow" />
            <span className="text-emerald-700 text-sm uppercase tracking-wider">What We Offer</span>
          </div>
          <h2 className="text-4xl md:text-6xl">
            <span className="gradient-text">Our Services</span>
          </h2>
          <p className="text-gray-600 max-w-2xl mx-auto text-lg">
            زموږ خدمتونه - Comprehensive healthcare solutions for Afghan communities
          </p>
        </div>

        {/* AdMob Banner */}
        <div className="mb-8">
          <AdBanner size="large" position="top" />
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 md:gap-8">
          {services.map((service, index) => (
            <>
              {/* Show Ad after every 3 services */}
              {index > 0 && index % 3 === 0 && (
                <div key={`ad-${index}`} className="col-span-1 sm:col-span-2 lg:col-span-3">
                  <AdBanner size="large" position="middle" />
                </div>
              )}
              
            <Card 
              key={index} 
              className="group hover-lift transition-all duration-500 border-0 bg-white overflow-hidden shadow-lg cursor-pointer"
              style={{ animationDelay: `${index * 100}ms` }}
              onClick={() => handleServiceClick(service)}
            >
              <div className={`h-2 bg-gradient-to-r ${service.gradient}`}></div>
              <CardHeader className="pb-4">
                <div className={`w-14 h-14 rounded-2xl ${service.iconBg} flex items-center justify-center mb-4 group-hover:scale-110 transition-transform duration-500 shadow-lg`}>
                  <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${service.gradient} flex items-center justify-center`}>
                    <service.icon className="w-6 h-6 text-white" />
                  </div>
                </div>
                <CardTitle className="text-lg md:text-xl group-hover:text-emerald-600 transition-colors">
                  {service.title}
                </CardTitle>
                <p className="text-sm text-emerald-600">{service.titleDari}</p>
              </CardHeader>
              <CardContent className="space-y-4">
                <CardDescription className="text-gray-600 leading-relaxed">
                  {service.description}
                </CardDescription>
                
                <Button 
                  onClick={(e) => {
                    e.stopPropagation();
                    handleServiceClick(service);
                  }}
                  className={`w-full bg-gradient-to-r ${service.gradient} hover:opacity-90 transition-opacity group-hover:scale-105`}
                  size="sm"
                >
                  Access Service
                  <ArrowRight className="w-4 h-4 ml-2 group-hover:translate-x-1 transition-transform" />
                </Button>
              </CardContent>
            </Card>
            </>
          ))}
        </div>

        {/* Additional Info */}
        <div className="mt-12 text-center">
          <div className="inline-block p-6 bg-gradient-to-r from-emerald-50 to-teal-50 rounded-2xl border-2 border-emerald-200 shadow-lg">
            <p className="text-gray-700 mb-2">
              <strong>24/7 Support Available</strong>
            </p>
            <p className="text-sm text-gray-600">
              د ۲۴ ساعتونو ملاتړ - Need help? Contact us anytime!
            </p>
            <div className="flex flex-col items-center justify-center gap-2 mt-4 text-sm">
              <div className="flex items-center gap-3">
                <a href="tel:+93783040441" className="text-emerald-600 hover:underline">
                  📱 +93 783 040 441
                </a>
                <span className="text-gray-400">|</span>
                <a href="tel:+93779494512" className="text-emerald-600 hover:underline">
                  📱 +93 779 494 512
                </a>
              </div>
              <a 
                href="https://wa.me/93779494512" 
                target="_blank" 
                rel="noopener noreferrer"
                className="flex items-center gap-2 bg-green-500 hover:bg-green-600 text-white px-4 py-2 rounded-full transition-all shadow-lg hover:shadow-xl"
              >
                <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413Z"/>
                </svg>
                <span>واتساپ / WhatsApp</span>
              </a>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

export default Services;
