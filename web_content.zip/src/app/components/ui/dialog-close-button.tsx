import { Button } from "./button";
import { DialogClose } from "./dialog";
import { X } from "lucide-react";

interface DialogCloseButtonProps {
  children?: React.ReactNode;
  variant?: "default" | "outline" | "ghost";
  className?: string;
}

export function DialogCloseButton({ 
  children, 
  variant = "outline",
  className = ""
}: DialogCloseButtonProps) {
  return (
    <DialogClose asChild>
      <Button 
        variant={variant} 
        className={`min-w-[120px] ${className}`}
      >
        {children || (
          <>
            <X className="w-4 h-4 mr-2" />
            Close / بند کړئ
          </>
        )}
      </Button>
    </DialogClose>
  );
}
