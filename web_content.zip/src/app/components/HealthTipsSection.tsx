import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Lightbulb, Plus, Heart, Star, Clock, Eye, X, Send, Sparkles } from 'lucide-react';
import { Button } from './ui/button';
import { Card } from './ui/card';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from './ui/dialog';
import { Input } from './ui/input';
import { Textarea } from './ui/textarea';

interface HealthTip {
  id: string;
  title: { ps: string; fa: string; en: string };
  description: { ps: string; fa: string; en: string };
  category: string;
  likes: number;
  views: number;
  createdAt: Date;
  author: string;
}

interface HealthTipsSectionProps {
  language: 'ps' | 'fa' | 'en';
  currentUserEmail?: string;
  onAddTip?: (tip: Omit<HealthTip, 'id' | 'likes' | 'views' | 'createdAt'>) => void;
  onBack?: () => void;
}

export function HealthTipsSection({ language, currentUserEmail, onAddTip, onBack }: HealthTipsSectionProps) {
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [titlePs, setTitlePs] = useState('');
  const [titleFa, setTitleFa] = useState('');
  const [titleEn, setTitleEn] = useState('');
  const [descPs, setDescPs] = useState('');
  const [descFa, setDescFa] = useState('');
  const [descEn, setDescEn] = useState('');
  const [category, setCategory] = useState('');

  // Sample health tips
  const [healthTips, setHealthTips] = useState<HealthTip[]>([
    {
      id: '1',
      title: {
        ps: 'د اوبو څښل',
        fa: 'نوشیدن آب',
        en: 'Drink Water'
      },
      description: {
        ps: 'هره ورځ لږ تر لږه 8 ګیلاسه اوبه وڅښئ. اوبه ستاسو بدن پاک ساتي او روغتیا ښه کوي.',
        fa: 'هر روز حداقل 8 لیوان آب بنوشید. آب بدن شما را پاک نگه می‌دارد و سلامتی را بهبود می‌بخشد.',
        en: 'Drink at least 8 glasses of water daily. Water keeps your body clean and improves health.'
      },
      category: 'nutrition',
      likes: 245,
      views: 1250,
      createdAt: new Date('2024-01-15'),
      author: 'ډاکټر ابراهیم خاکسار'
    },
    {
      id: '2',
      title: {
        ps: 'نظمی ورزش',
        fa: 'ورزش منظم',
        en: 'Regular Exercise'
      },
      description: {
        ps: 'هره ورځ لږ تر لږه 30 دقیقې ورزش وکړئ. ورزش ستاسو زړه او عضلات قوي کوي.',
        fa: 'هر روز حداقل 30 دقیقه ورزش کنید. ورزش قلب و عضلات شما را قوی می‌کند.',
        en: 'Exercise at least 30 minutes daily. Exercise strengthens your heart and muscles.'
      },
      category: 'fitness',
      likes: 189,
      views: 980,
      createdAt: new Date('2024-01-14'),
      author: 'ډاکټر ابراهیم خاکسار'
    },
    {
      id: '3',
      title: {
        ps: 'کافي خوب',
        fa: 'خواب کافی',
        en: 'Adequate Sleep'
      },
      description: {
        ps: 'هره شپه 7-8 ساعته خوب وکړئ. ښه خوب ستاسو دماغ او بدن ته استراحت ورکوي.',
        fa: 'هر شب 7-8 ساعت بخوابید. خواب خوب به مغز و بدن شما استراحت می‌دهد.',
        en: 'Sleep 7-8 hours every night. Good sleep gives your brain and body rest.'
      },
      category: 'wellness',
      likes: 321,
      views: 1580,
      createdAt: new Date('2024-01-13'),
      author: 'ډاکټر ابراهیم خاکسار'
    },
    {
      id: '4',
      title: {
        ps: 'تازه میوه او سبزیجات',
        fa: 'میوه و سبزیجات تازه',
        en: 'Fresh Fruits & Vegetables'
      },
      description: {
        ps: 'هره ورځ تازه میوه او سبزیجات وخورئ. دا ستاسو بدن ته ویتامینونه او منرالونه ورکوي.',
        fa: 'هر روز میوه و سبزیجات تازه بخورید. اینها به بدن شما ویتامین و مواد معدنی می‌دهند.',
        en: 'Eat fresh fruits and vegetables daily. They provide vitamins and minerals to your body.'
      },
      category: 'nutrition',
      likes: 278,
      views: 1420,
      createdAt: new Date('2024-01-12'),
      author: 'ډاکټر ابراهیم خاکسار'
    }
  ]);

  const isAdmin = currentUserEmail === 'ibrahimkhaksar.it@gmail.com';

  const translations = {
    title: {
      ps: 'روغتیا مشورې',
      fa: 'مشاوره‌های سلامت',
      en: 'Health Tips'
    },
    subtitle: {
      ps: 'د روغتیا او تندرستۍ لپاره ګټورې مشورې',
      fa: 'مشاوره‌های مفید برای سلامت و تندرستی',
      en: 'Useful tips for health and wellness'
    },
    addTip: {
      ps: 'نوې مشوره اضافه کړئ',
      fa: 'افزودن مشاوره جدید',
      en: 'Add New Tip'
    },
    titlePsLabel: {
      ps: 'عنوان په پښتو',
      fa: 'عنوان به پشتو',
      en: 'Title in Pashto'
    },
    titleFaLabel: {
      ps: 'عنوان په دري',
      fa: 'عنوان به دری',
      en: 'Title in Dari'
    },
    titleEnLabel: {
      ps: 'عنوان په انګلیسي',
      fa: 'عنوان به انگلیسی',
      en: 'Title in English'
    },
    descPsLabel: {
      ps: 'تفصیل په پښتو',
      fa: 'توضیحات به پشتو',
      en: 'Description in Pashto'
    },
    descFaLabel: {
      ps: 'تفصیل په دري',
      fa: 'توضیحات به دری',
      en: 'Description in Dari'
    },
    descEnLabel: {
      ps: 'تفصیل په انګلیسي',
      fa: 'توضیحات به انگلیسی',
      en: 'Description in English'
    },
    categoryLabel: {
      ps: 'کټګوري',
      fa: 'دسته‌بندی',
      en: 'Category'
    },
    submit: {
      ps: 'خپره کړئ',
      fa: 'انتشار',
      en: 'Publish'
    },
    likes: {
      ps: 'خوښونه',
      fa: 'پسندها',
      en: 'Likes'
    },
    views: {
      ps: 'لیدونه',
      fa: 'بازدیدها',
      en: 'Views'
    }
  };

  const handleSubmit = () => {
    if (!titlePs || !titleFa || !titleEn || !descPs || !descFa || !descEn) {
      alert(language === 'ps' ? 'مهرباني وکړئ ټول برخې ډک کړئ' : language === 'fa' ? 'لطفا همه قسمت‌ها را پر کنید' : 'Please fill all fields');
      return;
    }

    const newTip: HealthTip = {
      id: Date.now().toString(),
      title: { ps: titlePs, fa: titleFa, en: titleEn },
      description: { ps: descPs, fa: descFa, en: descEn },
      category: category || 'general',
      likes: 0,
      views: 0,
      createdAt: new Date(),
      author: 'ډاکټر ابراهیم خاکسار'
    };

    setHealthTips([newTip, ...healthTips]);
    
    // Reset form
    setTitlePs('');
    setTitleFa('');
    setTitleEn('');
    setDescPs('');
    setDescFa('');
    setDescEn('');
    setCategory('');
    setIsDialogOpen(false);

    if (onAddTip) {
      onAddTip({
        title: newTip.title,
        description: newTip.description,
        category: newTip.category,
        author: newTip.author
      });
    }
  };

  return (
    <section className="py-16 px-4 bg-gradient-to-br from-green-50 via-teal-50 to-cyan-50 relative overflow-hidden">
      {/* Background decorations */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-20 left-10 w-64 h-64 bg-green-200/30 rounded-full blur-3xl" />
        <div className="absolute bottom-20 right-10 w-80 h-80 bg-teal-200/30 rounded-full blur-3xl" />
      </div>

      <div className="max-w-6xl mx-auto relative z-10">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-12"
        >
          <div className="flex items-center justify-center gap-3 mb-4">
            <div className="w-12 h-12 bg-gradient-to-br from-yellow-400 to-orange-500 rounded-2xl flex items-center justify-center">
              <Lightbulb className="w-6 h-6 text-white" />
            </div>
            <h2 className="text-4xl text-gray-800">{translations.title[language]}</h2>
          </div>
          <p className="text-gray-600 max-w-2xl mx-auto">
            {translations.subtitle[language]}
          </p>

          {/* Add Tip Button - Admin Only */}
          {isAdmin && (
            <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
              <DialogTrigger asChild>
                <Button className="mt-6 bg-gradient-to-r from-green-500 to-teal-500 hover:from-green-600 hover:to-teal-600 text-white gap-2">
                  <Plus className="w-4 h-4" />
                  {translations.addTip[language]}
                </Button>
              </DialogTrigger>
              <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
                <DialogHeader>
                  <DialogTitle className="flex items-center gap-2">
                    <Sparkles className="w-5 h-5 text-green-500" />
                    {translations.addTip[language]}
                  </DialogTitle>
                </DialogHeader>
                
                <div className="space-y-4 py-4">
                  {/* Titles */}
                  <div className="space-y-2">
                    <label className="text-sm font-medium">{translations.titlePsLabel[language]}</label>
                    <Input
                      value={titlePs}
                      onChange={(e) => setTitlePs(e.target.value)}
                      placeholder="د اوبو څښل"
                      dir="rtl"
                    />
                  </div>

                  <div className="space-y-2">
                    <label className="text-sm font-medium">{translations.titleFaLabel[language]}</label>
                    <Input
                      value={titleFa}
                      onChange={(e) => setTitleFa(e.target.value)}
                      placeholder="نوشیدن آب"
                      dir="rtl"
                    />
                  </div>

                  <div className="space-y-2">
                    <label className="text-sm font-medium">{translations.titleEnLabel[language]}</label>
                    <Input
                      value={titleEn}
                      onChange={(e) => setTitleEn(e.target.value)}
                      placeholder="Drink Water"
                    />
                  </div>

                  {/* Descriptions */}
                  <div className="space-y-2">
                    <label className="text-sm font-medium">{translations.descPsLabel[language]}</label>
                    <Textarea
                      value={descPs}
                      onChange={(e) => setDescPs(e.target.value)}
                      placeholder="د مشورې تفصیل په پښتو..."
                      rows={3}
                      dir="rtl"
                    />
                  </div>

                  <div className="space-y-2">
                    <label className="text-sm font-medium">{translations.descFaLabel[language]}</label>
                    <Textarea
                      value={descFa}
                      onChange={(e) => setDescFa(e.target.value)}
                      placeholder="توضیحات مشاوره به دری..."
                      rows={3}
                      dir="rtl"
                    />
                  </div>

                  <div className="space-y-2">
                    <label className="text-sm font-medium">{translations.descEnLabel[language]}</label>
                    <Textarea
                      value={descEn}
                      onChange={(e) => setDescEn(e.target.value)}
                      placeholder="Tip description in English..."
                      rows={3}
                    />
                  </div>

                  {/* Category */}
                  <div className="space-y-2">
                    <label className="text-sm font-medium">{translations.categoryLabel[language]}</label>
                    <Input
                      value={category}
                      onChange={(e) => setCategory(e.target.value)}
                      placeholder="nutrition, fitness, wellness..."
                    />
                  </div>

                  {/* Submit Button */}
                  <Button
                    onClick={handleSubmit}
                    className="w-full bg-gradient-to-r from-green-500 to-teal-500 hover:from-green-600 hover:to-teal-600 text-white gap-2"
                  >
                    <Send className="w-4 h-4" />
                    {translations.submit[language]}
                  </Button>
                </div>
              </DialogContent>
            </Dialog>
          )}
        </motion.div>

        {/* Health Tips Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <AnimatePresence>
            {healthTips.map((tip, index) => (
              <motion.div
                key={tip.id}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
              >
                <Card className="p-6 bg-white/80 backdrop-blur-sm border-green-100 hover:shadow-xl transition-all cursor-pointer group">
                  {/* Header */}
                  <div className="flex items-start justify-between mb-4">
                    <div className="flex-1">
                      <h3 className="text-xl font-semibold text-gray-800 mb-2 group-hover:text-green-600 transition-colors">
                        {tip.title[language]}
                      </h3>
                      <p className="text-sm text-gray-600 leading-relaxed" dir={language === 'en' ? 'ltr' : 'rtl'}>
                        {tip.description[language]}
                      </p>
                    </div>
                  </div>

                  {/* Footer */}
                  <div className="flex items-center justify-between pt-4 border-t border-gray-100">
                    <div className="flex items-center gap-4 text-sm text-gray-500">
                      <div className="flex items-center gap-1">
                        <Heart className="w-4 h-4 text-red-500" />
                        <span>{tip.likes}</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <Eye className="w-4 h-4 text-blue-500" />
                        <span>{tip.views}</span>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <Star className="w-4 h-4 text-yellow-500 fill-yellow-500" />
                      <span className="text-xs text-gray-500">{tip.category}</span>
                    </div>
                  </div>
                </Card>
              </motion.div>
            ))}
          </AnimatePresence>
        </div>
      </div>
    </section>
  );
}