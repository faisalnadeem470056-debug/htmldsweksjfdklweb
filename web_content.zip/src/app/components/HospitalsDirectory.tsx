import { useState } from 'react';
import { Search, MapPin, Phone, Bed, ArrowLeft, Hospital, Clock, CheckCircle } from 'lucide-react';
import { motion } from 'motion/react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { translations } from '../translations';
import { AdBanner } from './AdBanner';

interface HospitalsDirectoryProps {
  language: 'ps' | 'fa' | 'en';
  onBack: () => void;
}

const hospitals = [
  {
    id: 1,
    name: { ps: 'جمهوریت روغتون', fa: 'شفاخانه جمهوریت', en: 'Jamhuriat Hospital' },
    location: { ps: 'کابل', fa: 'کابل', en: 'Kabul' },
    phone: '+93 20 210 1234',
    beds: 500,
    emergency: true,
    open24h: true,
    services: [
      { ps: 'بیړني خدمات', fa: 'خدمات اضطراری', en: 'Emergency' },
      { ps: 'جراحي', fa: 'جراحی', en: 'Surgery' },
      { ps: 'ICU', fa: 'ICU', en: 'ICU' },
    ],
  },
  {
    id: 2,
    name: { ps: 'علي آباد روغتون', fa: 'شفاخانه علی‌آباد', en: 'Ali Abad Hospital' },
    location: { ps: 'کابل', fa: 'کابل', en: 'Kabul' },
    phone: '+93 20 220 2345',
    beds: 300,
    emergency: true,
    open24h: true,
    services: [
      { ps: 'ماشومانو', fa: 'اطفال', en: 'Pediatrics' },
      { ps: 'زړه', fa: 'قلب', en: 'Cardiology' },
      { ps: 'زیږون', fa: 'زایمان', en: 'Maternity' },
    ],
  },
  {
    id: 3,
    name: { ps: 'هرات ولایتي روغتون', fa: 'شفاخانه ولایتی هرات', en: 'Herat Regional Hospital' },
    location: { ps: 'هرات', fa: 'هرات', en: 'Herat' },
    phone: '+93 40 221 3456',
    beds: 400,
    emergency: true,
    open24h: true,
    services: [
      { ps: 'بیړني', fa: 'اضطراری', en: 'Emergency' },
      { ps: 'جراحي', fa: 'جراحی', en: 'Surgery' },
      { ps: 'لابراتوار', fa: 'آزمایشگاه', en: 'Laboratory' },
    ],
  },
  {
    id: 4,
    name: { ps: 'مزار شریف روغتون', fa: 'شفاخانه مزار شریف', en: 'Mazar-i-Sharif Hospital' },
    location: { ps: 'مزار شریف', fa: 'مزار شریف', en: 'Mazar-i-Sharif' },
    phone: '+93 50 230 4567',
    beds: 350,
    emergency: true,
    open24h: true,
    services: [
      { ps: 'عمومي', fa: 'عمومی', en: 'General' },
      { ps: 'ماشومان', fa: 'اطفال', en: 'Pediatrics' },
      { ps: 'X-Ray', fa: 'X-Ray', en: 'X-Ray' },
    ],
  },
  {
    id: 5,
    name: { ps: 'کندهار میرویس روغتون', fa: 'شفاخانه میرویس کندهار', en: 'Kandahar Mirwais Hospital' },
    location: { ps: 'کندهار', fa: 'کندهار', en: 'Kandahar' },
    phone: '+93 30 222 5678',
    beds: 450,
    emergency: true,
    open24h: true,
    services: [
      { ps: 'بیړني', fa: 'اضطراری', en: 'Emergency' },
      { ps: 'صدمات', fa: 'تروما', en: 'Trauma' },
      { ps: 'جراحي', fa: 'جراحی', en: 'Surgery' },
    ],
  },
];

export function HospitalsDirectory({ language, onBack }: HospitalsDirectoryProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const t = translations[language];

  const filteredHospitals = hospitals.filter(hospital =>
    hospital.name[language].toLowerCase().includes(searchQuery.toLowerCase()) ||
    hospital.location[language].toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="min-h-screen bg-gradient-to-br from-red-50 via-pink-50 to-rose-50 pb-28 md:pb-12">
      {/* Header */}
      <div className="sticky top-[73px] z-30 backdrop-blur-xl bg-white/70 border-b border-white/20 shadow-lg">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center gap-4 mb-4">
            <Button variant="ghost" size="icon" onClick={onBack}>
              <ArrowLeft className="w-5 h-5" />
            </Button>
            <div>
              <h1 className="text-2xl bg-gradient-to-r from-red-600 to-pink-600 bg-clip-text text-transparent">
                {t.hospitalsDirectory}
              </h1>
              <p className="text-sm text-gray-600">{hospitals.length} {t.stats.hospitals}</p>
            </div>
          </div>

          {/* Search */}
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
            <Input
              type="text"
              placeholder={t.searchHospitals}
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10 bg-white/80 backdrop-blur-md border-white/20"
            />
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="container mx-auto px-4 mt-6">
        <AdBanner type="medium" className="mb-6" />

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {filteredHospitals.map((hospital, index) => (
            <motion.div
              key={hospital.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              className="relative group"
            >
              <div className="absolute inset-0 bg-gradient-to-br from-red-500/20 to-pink-500/20 rounded-3xl blur-xl group-hover:blur-2xl transition-all" />
              <div className="relative bg-white/90 backdrop-blur-xl rounded-3xl p-6 border border-white/20 shadow-xl hover:shadow-2xl transition-all">
                {/* Header */}
                <div className="flex items-start gap-4 mb-4">
                  <div className="w-14 h-14 bg-gradient-to-br from-red-500 to-pink-600 rounded-2xl flex items-center justify-center flex-shrink-0">
                    <Hospital className="w-7 h-7 text-white" />
                  </div>
                  <div className="flex-1">
                    <h3 className="text-lg mb-2">{hospital.name[language]}</h3>
                    {hospital.open24h && (
                      <div className="inline-flex items-center gap-1 bg-green-100 text-green-700 px-3 py-1 rounded-full text-xs">
                        <Clock className="w-3 h-3" />
                        {t.open24Hours}
                      </div>
                    )}
                  </div>
                </div>

                {/* Details */}
                <div className="space-y-3 mb-4">
                  <div className="flex items-center gap-2 text-sm text-gray-600">
                    <MapPin className="w-4 h-4" />
                    {hospital.location[language]}
                  </div>
                  <div className="flex items-center gap-2 text-sm text-gray-600">
                    <Phone className="w-4 h-4" />
                    {hospital.phone}
                  </div>
                  <div className="flex items-center gap-2 text-sm text-gray-600">
                    <Bed className="w-4 h-4" />
                    {hospital.beds} {t.beds}
                  </div>
                  {hospital.emergency && (
                    <div className="flex items-center gap-2 text-sm text-red-600">
                      <CheckCircle className="w-4 h-4" />
                      {t.emergency}
                    </div>
                  )}
                </div>

                {/* Services */}
                <div className="mb-4">
                  <p className="text-sm text-gray-600 mb-2">{t.services}:</p>
                  <div className="flex flex-wrap gap-2">
                    {hospital.services.map((service, idx) => (
                      <span
                        key={idx}
                        className="bg-gradient-to-r from-red-100 to-pink-100 text-red-700 px-3 py-1 rounded-full text-xs"
                      >
                        {service[language]}
                      </span>
                    ))}
                  </div>
                </div>

                {/* Actions */}
                <div className="flex gap-2">
                  <Button className="flex-1 bg-gradient-to-r from-red-600 to-pink-600 hover:from-red-700 hover:to-pink-700">
                    <MapPin className="w-4 h-4 mr-2" />
                    {t.getDirections}
                  </Button>
                  <Button variant="outline" size="icon">
                    <Phone className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        <AdBanner type="large" className="mt-8" />
      </div>
    </div>
  );
}
