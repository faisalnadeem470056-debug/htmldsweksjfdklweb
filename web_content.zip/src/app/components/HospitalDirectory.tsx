import { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Hospital as HospitalIcon, MapPin, Phone, Mail, Clock, Users,
  Stethoscope, Building2, Search, Filter, X, Navigation, Star,
  ArrowLeft, ChevronRight, Calendar, Bed, Heart, Info
} from 'lucide-react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Card } from './ui/card';
import { ImageWithFallback } from './figma/ImageWithFallback';
import { afghanistanHospitals, afghanProvinces, medicalServices, Hospital } from '../data/hospitals';

interface HospitalDirectoryProps {
  language: 'ps' | 'fa' | 'en';
  onBack: () => void;
}

export function HospitalDirectory({ language, onBack }: HospitalDirectoryProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedProvince, setSelectedProvince] = useState<string>('all');
  const [selectedType, setSelectedType] = useState<'all' | 'hospital' | 'clinic' | 'health_center'>('all');
  const [selectedHospital, setSelectedHospital] = useState<Hospital | null>(null);
  const [showFilters, setShowFilters] = useState(false);

  const texts = {
    ps: {
      title: 'د افغانستان روغتونونه او کلینیکونه',
      subtitle: 'د ټولو 34 ولایتونو بشپړ معلومات',
      search: 'روغتون یا کلینیک ولټوئ...',
      allProvinces: 'ټول ولایتونه',
      allTypes: 'ټول ډولونه',
      hospital: 'روغتون',
      clinic: 'کلینیک',
      healthCenter: 'روغتیایی مرکز',
      filters: 'فلټرونه',
      results: 'پایلې',
      noResults: 'هیڅ پایله ونه موندل شوه',
      viewDetails: 'تفصیل وګورئ',
      location: 'موقعیت',
      contact: 'اړیکه',
      services: 'خدمتونه',
      availability: 'وخت',
      government: 'دولتي',
      private: 'خصوصي',
      beds: 'بسترې',
      doctors: 'ډاکټران',
      established: 'تاسیس',
      getDirections: 'لاره وګورئ',
      call: 'زنګ ووهئ',
      email: 'ایمیل',
      available247: '24/7 فعال',
      dayOnly: 'ورځې',
      limited: 'محدود',
      province: 'ولایت',
      district: 'ولسوالۍ',
      address: 'ادرس',
      type: 'ډول',
      totalHospitals: 'ټول روغتونونه'
    },
    fa: {
      title: 'شفاخانه‌ها و کلینیک‌های افغانستان',
      subtitle: 'اطلاعات کامل تمام 34 ولایت',
      search: 'جستجوی شفاخانه یا کلینیک...',
      allProvinces: 'تمام ولایات',
      allTypes: 'تمام انواع',
      hospital: 'شفاخانه',
      clinic: 'کلینیک',
      healthCenter: 'مرکز صحی',
      filters: 'فلترها',
      results: 'نتایج',
      noResults: 'هیچ نتیجه‌ای پیدا نشد',
      viewDetails: 'مشاهده جزئیات',
      location: 'موقعیت',
      contact: 'تماس',
      services: 'خدمات',
      availability: 'دسترسی',
      government: 'دولتی',
      private: 'خصوصی',
      beds: 'تخت',
      doctors: 'داکتران',
      established: 'تاسیس',
      getDirections: 'مسیریابی',
      call: 'تماس',
      email: 'ایمیل',
      available247: '24/7 فعال',
      dayOnly: 'روزانه',
      limited: 'محدود',
      province: 'ولایت',
      district: 'ولسوالی',
      address: 'آدرس',
      type: 'نوع',
      totalHospitals: 'مجموع شفاخانه‌ها'
    },
    en: {
      title: 'Afghanistan Hospitals & Clinics',
      subtitle: 'Complete information for all 34 provinces',
      search: 'Search hospital or clinic...',
      allProvinces: 'All Provinces',
      allTypes: 'All Types',
      hospital: 'Hospital',
      clinic: 'Clinic',
      healthCenter: 'Health Center',
      filters: 'Filters',
      results: 'Results',
      noResults: 'No results found',
      viewDetails: 'View Details',
      location: 'Location',
      contact: 'Contact',
      services: 'Services',
      availability: 'Availability',
      government: 'Government',
      private: 'Private',
      beds: 'Beds',
      doctors: 'Doctors',
      established: 'Established',
      getDirections: 'Get Directions',
      call: 'Call',
      email: 'Email',
      available247: '24/7 Available',
      dayOnly: 'Day Only',
      limited: 'Limited',
      province: 'Province',
      district: 'District',
      address: 'Address',
      type: 'Type',
      totalHospitals: 'Total Hospitals'
    }
  };

  const t = texts[language];

  // Filter hospitals
  const filteredHospitals = useMemo(() => {
    let results = afghanistanHospitals;

    // Filter by province
    if (selectedProvince !== 'all') {
      results = results.filter(h => h.province === selectedProvince);
    }

    // Filter by type
    if (selectedType !== 'all') {
      results = results.filter(h => h.type === selectedType);
    }

    // Filter by search query
    if (searchQuery.trim()) {
      const query = searchQuery.toLowerCase();
      results = results.filter(h =>
        h.name.ps.toLowerCase().includes(query) ||
        h.name.fa.toLowerCase().includes(query) ||
        h.name.en.toLowerCase().includes(query) ||
        h.province.toLowerCase().includes(query) ||
        h.district.toLowerCase().includes(query)
      );
    }

    return results;
  }, [searchQuery, selectedProvince, selectedType]);

  // Get type label
  const getTypeLabel = (type: string) => {
    switch (type) {
      case 'hospital': return t.hospital;
      case 'clinic': return t.clinic;
      case 'health_center': return t.healthCenter;
      default: return type;
    }
  };

  // Get availability label
  const getAvailabilityLabel = (availability: string) => {
    switch (availability) {
      case '24/7': return t.available247;
      case 'day': return t.dayOnly;
      case 'limited': return t.limited;
      default: return availability;
    }
  };

  // Open map directions
  const openDirections = (lat: number, lng: number) => {
    window.open(`https://www.google.com/maps/dir/?api=1&destination=${lat},${lng}`, '_blank');
  };

  // Hospital List View
  const HospitalListView = () => (
    <div className="max-w-6xl mx-auto px-4 py-6">
      {/* Search and Filters */}
      <Card className="bg-white rounded-2xl shadow-lg border-0 p-4 mb-6">
        <div className="flex flex-col gap-4">
          {/* Search Bar */}
          <div className="relative">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
            <Input
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder={t.search}
              className="pl-12 pr-12 rounded-xl border-2 border-gray-200 focus:border-blue-500 h-14"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute right-4 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600"
              >
                <X className="w-5 h-5" />
              </button>
            )}
          </div>

          {/* Filter Buttons */}
          <div className="flex gap-3 overflow-x-auto pb-2">
            <button
              onClick={() => setShowFilters(!showFilters)}
              className={`flex items-center gap-2 px-4 py-2 rounded-xl border-2 whitespace-nowrap ${
                showFilters ? 'border-blue-500 bg-blue-50 text-blue-700' : 'border-gray-200 bg-white'
              }`}
            >
              <Filter className="w-4 h-4" />
              {t.filters}
            </button>

            <button
              onClick={() => setSelectedProvince('all')}
              className={`px-4 py-2 rounded-xl border-2 whitespace-nowrap ${
                selectedProvince === 'all' ? 'border-blue-500 bg-blue-50 text-blue-700' : 'border-gray-200'
              }`}
            >
              {t.allProvinces}
            </button>

            {afghanProvinces.slice(0, 5).map(province => (
              <button
                key={province}
                onClick={() => setSelectedProvince(province)}
                className={`px-4 py-2 rounded-xl border-2 whitespace-nowrap ${
                  selectedProvince === province ? 'border-blue-500 bg-blue-50 text-blue-700' : 'border-gray-200'
                }`}
              >
                {province}
              </button>
            ))}
          </div>

          {/* Extended Filters */}
          {showFilters && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              className="border-t border-gray-200 pt-4 space-y-4"
            >
              <div>
                <p className="text-sm text-gray-600 mb-2">{t.type}</p>
                <div className="flex gap-2">
                  {['all', 'hospital', 'clinic', 'health_center'].map(type => (
                    <button
                      key={type}
                      onClick={() => setSelectedType(type as any)}
                      className={`px-4 py-2 rounded-xl border-2 text-sm ${
                        selectedType === type ? 'border-blue-500 bg-blue-50 text-blue-700' : 'border-gray-200'
                      }`}
                    >
                      {type === 'all' ? t.allTypes : getTypeLabel(type)}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <p className="text-sm text-gray-600 mb-2">{t.province}</p>
                <select
                  value={selectedProvince}
                  onChange={(e) => setSelectedProvince(e.target.value)}
                  className="w-full px-4 py-3 border-2 border-gray-200 rounded-xl focus:border-blue-500 focus:outline-none"
                >
                  <option value="all">{t.allProvinces}</option>
                  {afghanProvinces.map(province => (
                    <option key={province} value={province}>{province}</option>
                  ))}
                </select>
              </div>
            </motion.div>
          )}
        </div>
      </Card>

      {/* Results Count */}
      <div className="flex items-center justify-between mb-4 px-2">
        <p className="text-gray-600">
          {filteredHospitals.length} {t.results}
        </p>
        <div className="flex items-center gap-2 text-blue-600">
          <Building2 className="w-5 h-5" />
          <span className="text-sm">{t.totalHospitals}: {afghanistanHospitals.length}</span>
        </div>
      </div>

      {/* Hospital Cards */}
      {filteredHospitals.length === 0 ? (
        <Card className="bg-white rounded-2xl shadow-lg border-0 p-12 text-center">
          <div className="w-20 h-20 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <Search className="w-10 h-10 text-gray-400" />
          </div>
          <h3 className="text-xl text-gray-900 mb-2">{t.noResults}</h3>
          <p className="text-gray-500">
            {language === 'ps' ? 'بل ولایت یا نوم ولټوئ' :
             language === 'fa' ? 'ولایت یا نام دیگری جستجو کنید' :
             'Try searching for a different province or name'}
          </p>
        </Card>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredHospitals.map((hospital) => (
            <motion.div
              key={hospital.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3 }}
            >
              <Card
                className="bg-white rounded-2xl shadow-lg border-0 overflow-hidden hover:shadow-xl transition-shadow cursor-pointer"
                onClick={() => setSelectedHospital(hospital)}
              >
                {/* Image */}
                <div className="relative h-48">
                  <ImageWithFallback
                    src={hospital.image || 'https://images.unsplash.com/photo-1519494026892-80bbd2d6fd0d?w=800'}
                    alt={hospital.name[language]}
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute top-3 right-3 flex gap-2">
                    {hospital.isGovernment && (
                      <span className="px-3 py-1 bg-green-500 text-white text-xs rounded-full">
                        {t.government}
                      </span>
                    )}
                    {hospital.availability === '24/7' && (
                      <span className="px-3 py-1 bg-blue-500 text-white text-xs rounded-full flex items-center gap-1">
                        <Clock className="w-3 h-3" />
                        24/7
                      </span>
                    )}
                  </div>
                </div>

                {/* Content */}
                <div className="p-4">
                  <div className="mb-3">
                    <div className="flex items-start justify-between mb-2">
                      <h3 className="text-lg">{hospital.name[language]}</h3>
                      <div className={`w-10 h-10 rounded-full flex items-center justify-center ${
                        hospital.type === 'hospital' ? 'bg-blue-100' :
                        hospital.type === 'clinic' ? 'bg-green-100' : 'bg-purple-100'
                      }`}>
                        {hospital.type === 'hospital' ? <HospitalIcon className="w-5 h-5 text-blue-600" /> :
                         hospital.type === 'clinic' ? <Stethoscope className="w-5 h-5 text-green-600" /> :
                         <Heart className="w-5 h-5 text-purple-600" />}
                      </div>
                    </div>
                    <p className="text-sm text-gray-500">{getTypeLabel(hospital.type)}</p>
                  </div>

                  <div className="space-y-2 mb-4">
                    <div className="flex items-center gap-2 text-sm text-gray-600">
                      <MapPin className="w-4 h-4 text-blue-600 flex-shrink-0" />
                      <span className="line-clamp-1">{hospital.province}, {hospital.district}</span>
                    </div>
                    {hospital.beds && (
                      <div className="flex items-center gap-2 text-sm text-gray-600">
                        <Bed className="w-4 h-4 text-green-600 flex-shrink-0" />
                        <span>{hospital.beds} {t.beds}</span>
                      </div>
                    )}
                    {hospital.doctors && (
                      <div className="flex items-center gap-2 text-sm text-gray-600">
                        <Users className="w-4 h-4 text-purple-600 flex-shrink-0" />
                        <span>{hospital.doctors} {t.doctors}</span>
                      </div>
                    )}
                  </div>

                  <Button className="w-full bg-gradient-to-r from-blue-600 to-indigo-600 text-white rounded-xl py-3">
                    {t.viewDetails}
                    <ChevronRight className="w-4 h-4 ml-2" />
                  </Button>
                </div>
              </Card>
            </motion.div>
          ))}
        </div>
      )}
    </div>
  );

  // Hospital Detail View
  const HospitalDetailView = () => {
    if (!selectedHospital) return null;

    return (
      <div className="max-w-4xl mx-auto px-4 py-6">
        <Card className="bg-white rounded-3xl shadow-2xl border-0 overflow-hidden">
          {/* Header Image */}
          <div className="relative h-64">
            <ImageWithFallback
              src={selectedHospital.image || 'https://images.unsplash.com/photo-1519494026892-80bbd2d6fd0d?w=800'}
              alt={selectedHospital.name[language]}
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
            <button
              onClick={() => setSelectedHospital(null)}
              className="absolute top-4 left-4 w-10 h-10 bg-white/90 backdrop-blur-sm rounded-full flex items-center justify-center hover:bg-white transition-colors"
            >
              <ArrowLeft className="w-5 h-5" />
            </button>
            <div className="absolute bottom-4 left-4 right-4 text-white">
              <h1 className="text-2xl mb-2">{selectedHospital.name[language]}</h1>
              <div className="flex items-center gap-2">
                <span className="px-3 py-1 bg-white/20 backdrop-blur-sm rounded-full text-sm">
                  {getTypeLabel(selectedHospital.type)}
                </span>
                {selectedHospital.isGovernment && (
                  <span className="px-3 py-1 bg-green-500 rounded-full text-sm">
                    {t.government}
                  </span>
                )}
              </div>
            </div>
          </div>

          {/* Content */}
          <div className="p-6 space-y-6">
            {/* Quick Stats */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {selectedHospital.beds && (
                <div className="bg-blue-50 rounded-2xl p-4 text-center">
                  <Bed className="w-6 h-6 text-blue-600 mx-auto mb-2" />
                  <p className="text-2xl text-blue-900">{selectedHospital.beds}</p>
                  <p className="text-sm text-blue-600">{t.beds}</p>
                </div>
              )}
              {selectedHospital.doctors && (
                <div className="bg-green-50 rounded-2xl p-4 text-center">
                  <Users className="w-6 h-6 text-green-600 mx-auto mb-2" />
                  <p className="text-2xl text-green-900">{selectedHospital.doctors}</p>
                  <p className="text-sm text-green-600">{t.doctors}</p>
                </div>
              )}
              <div className="bg-purple-50 rounded-2xl p-4 text-center">
                <Clock className="w-6 h-6 text-purple-600 mx-auto mb-2" />
                <p className="text-sm text-purple-900">{getAvailabilityLabel(selectedHospital.availability)}</p>
                <p className="text-xs text-purple-600">{t.availability}</p>
              </div>
              {selectedHospital.established && (
                <div className="bg-orange-50 rounded-2xl p-4 text-center">
                  <Calendar className="w-6 h-6 text-orange-600 mx-auto mb-2" />
                  <p className="text-2xl text-orange-900">{selectedHospital.established}</p>
                  <p className="text-sm text-orange-600">{t.established}</p>
                </div>
              )}
            </div>

            {/* Location */}
            <div>
              <h3 className="flex items-center gap-2 text-lg mb-3">
                <MapPin className="w-5 h-5 text-blue-600" />
                {t.location}
              </h3>
              <div className="bg-gray-50 rounded-2xl p-4 space-y-2">
                <p className="text-gray-700">{selectedHospital.address[language]}</p>
                <p className="text-sm text-gray-600">{selectedHospital.district}, {selectedHospital.province}</p>
                <Button
                  onClick={() => openDirections(selectedHospital.location.lat, selectedHospital.location.lng)}
                  className="w-full bg-blue-600 text-white rounded-xl py-3 mt-3"
                >
                  <Navigation className="w-4 h-4 mr-2" />
                  {t.getDirections}
                </Button>
              </div>
            </div>

            {/* Contact */}
            <div>
              <h3 className="flex items-center gap-2 text-lg mb-3">
                <Phone className="w-5 h-5 text-green-600" />
                {t.contact}
              </h3>
              <div className="bg-gray-50 rounded-2xl p-4 space-y-3">
                {selectedHospital.phone.map((phone, index) => (
                  <a
                    key={index}
                    href={`tel:${phone}`}
                    className="flex items-center gap-3 p-3 bg-white rounded-xl hover:bg-blue-50 transition-colors"
                  >
                    <Phone className="w-5 h-5 text-green-600" />
                    <span className="text-gray-900">{phone}</span>
                  </a>
                ))}
                {selectedHospital.email && (
                  <a
                    href={`mailto:${selectedHospital.email}`}
                    className="flex items-center gap-3 p-3 bg-white rounded-xl hover:bg-blue-50 transition-colors"
                  >
                    <Mail className="w-5 h-5 text-blue-600" />
                    <span className="text-gray-900">{selectedHospital.email}</span>
                  </a>
                )}
              </div>
            </div>

            {/* Services */}
            <div>
              <h3 className="flex items-center gap-2 text-lg mb-3">
                <Stethoscope className="w-5 h-5 text-purple-600" />
                {t.services}
              </h3>
              <div className="flex flex-wrap gap-2">
                {selectedHospital.services.map((service, index) => (
                  <span
                    key={index}
                    className="px-4 py-2 bg-purple-50 text-purple-700 rounded-xl text-sm"
                  >
                    {medicalServices[language][service as keyof typeof medicalServices.ps] || service}
                  </span>
                ))}
              </div>
            </div>
          </div>
        </Card>
      </div>
    );
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-purple-50 to-pink-50 pb-24">
      {/* Header */}
      <div className="sticky top-0 z-40 bg-gradient-to-r from-blue-600 via-purple-600 to-pink-600 text-white shadow-xl">
        <div className="container mx-auto px-4 py-6">
          <div className="flex items-center gap-4 mb-4">
            <Button
              variant="ghost"
              size="icon"
              onClick={selectedHospital ? () => setSelectedHospital(null) : onBack}
              className="rounded-full text-white hover:bg-white/20"
            >
              <ArrowLeft className="w-5 h-5" />
            </Button>
            <div className="flex-1">
              <h1 className="text-2xl flex items-center gap-2">
                <HospitalIcon className="w-7 h-7" />
                {t.title}
              </h1>
              <p className="text-sm opacity-90">{t.subtitle}</p>
            </div>
          </div>
        </div>
      </div>

      {/* Content */}
      <AnimatePresence mode="wait">
        {selectedHospital ? (
          <motion.div
            key="detail"
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
          >
            <HospitalDetailView />
          </motion.div>
        ) : (
          <motion.div
            key="list"
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: 20 }}
          >
            <HospitalListView />
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
