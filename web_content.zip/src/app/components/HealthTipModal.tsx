import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "./ui/dialog";
import { Badge } from "./ui/badge";
import { Button } from "./ui/button";
import { Heart, CheckCircle, AlertCircle, Info, BookOpen, Share2 } from "lucide-react";

interface HealthTip {
  icon: any;
  title: string;
  titleDari: string;
  description: string;
  color: string;
  gradient: string;
}

interface HealthTipModalProps {
  tip: HealthTip | null;
  open: boolean;
  onClose: () => void;
}

const detailedContent: { [key: string]: any } = {
  "Stay Active": {
    fullDescription: "Regular physical activity is one of the most important things you can do for your health. Being physically active can improve your brain health, help manage weight, reduce the risk of disease, strengthen bones and muscles, and improve your ability to do everyday activities.",
    fullDescriptionDari: "منظم فزیکي فعالیت یو له خورا مهمو شیانو څخه دی چې تاسو یې د خپلې روغتیا لپاره کولی شئ. فزیکي فعالیت ستاسو د دماغ روغتیا ښه کولی شي، وزن کنټرولوي، د ناروغیو خطر کموي، هډوکي او عضلات پیاوړي کوي.",
    benefits: [
      "Improves cardiovascular health",
      "Boosts mental wellbeing",
      "Increases energy levels",
      "Helps control weight",
      "Strengthens immune system"
    ],
    benefitsDari: [
      "د زړه او رګونو روغتیا ښه کوي",
      "رواني تندرستي زیاتوي",
      "د انرژۍ کچه لوړوي",
      "وزن کنټرولوي",
      "د مدافعتي سیسټم پیاوړي کوي"
    ],
    tips: [
      "Start with 10-15 minutes daily",
      "Choose activities you enjoy",
      "Walk during lunch breaks",
      "Take stairs instead of elevator",
      "Exercise with friends or family"
    ],
    tipsDari: [
      "هره ورځ د ۱۰-۱۵ دقیقو سره پیل وکړئ",
      "هغه فعالیتونه انتخاب کړئ چې خوښوئ",
      "د غرمې د خوړو په وخت پیاده روی وکړئ",
      "د لفټ پر ځای پله وکاروئ",
      "د کورنۍ یا ملګرو سره ورزش وکړئ"
    ]
  },
  "Drink Water": {
    fullDescription: "Water is essential for life. It helps regulate body temperature, transport nutrients, remove waste, and maintain healthy skin. Staying properly hydrated improves physical performance, energy levels, and brain function.",
    fullDescriptionDari: "اوبه د ژوند لپاره اړین دی. دا د بدن د تودوخې تنظیموي، غذايي مواد لیږدوي، فضله لیري کوي، او د پوستکي روغتیا ساتي. مناسب هایډریشن فزیکي کارول، د انرژۍ کچه او د دماغ فعالیت ښه کوي.",
    benefits: [
      "Maintains body fluid balance",
      "Energizes muscles",
      "Helps kidney function",
      "Improves skin health",
      "Aids digestion"
    ],
    benefitsDari: [
      "د بدن د مایعاتو توازن ساتي",
      "عضلات پیاوړي کوي",
      "د پښتورګو فعالیت ښه کوي",
      "د پوستکي روغتیا ښه کوي",
      "هضم کول اسانه کوي"
    ],
    tips: [
      "Drink 8 glasses (2 liters) daily",
      "Carry a water bottle",
      "Drink before feeling thirsty",
      "Eat water-rich fruits",
      "Set water reminders on phone"
    ],
    tipsDari: [
      "هره ورځ ۸ ګیلاسه (۲ لیټره) اوبه وڅښئ",
      "د اوبو بوتل له ځان سره ولرئ",
      "د تږي احساس کولو څخه مخکې اوبه وڅښئ",
      "هغه میوې وخورئ چې اوبه لري",
      "په موبایل کې د اوبو یادونه تنظیم کړئ"
    ]
  },
  "Get Sunlight": {
    fullDescription: "Sunlight exposure is crucial for vitamin D production, which is essential for bone health, immune function, and mental wellbeing. Moderate sun exposure can improve mood, regulate sleep patterns, and boost overall health.",
    fullDescriptionDari: "د لمر رڼا د ویټامین D تولید لپاره خورا مهمه ده چې د هډوکو روغتیا، مدافعتي فعالیت او رواني تندرستۍ لپاره اړین دی. منځنی لمر تماس مزاج ښه کوي، د خوب نمونه تنظیموي او عمومي روغتیا ښه کوي.",
    benefits: [
      "Produces Vitamin D naturally",
      "Improves mood and reduces depression",
      "Strengthens bones",
      "Regulates sleep cycle",
      "Boosts immune system"
    ],
    benefitsDari: [
      "په طبیعي ډول ویټامین D تولیدوي",
      "مزاج ښه کوي او خپګان کموي",
      "هډوکي پیاوړي کوي",
      "د خوب دوره تنظیموي",
      "مدافعتي سیسټم پیاوړي کوي"
    ],
    tips: [
      "Get 15-20 minutes of sunlight daily",
      "Best time: morning (6-10 AM)",
      "Expose arms and legs safely",
      "Avoid midday sun (12-3 PM)",
      "Use sunscreen for longer exposure"
    ],
    tipsDari: [
      "هره ورځ ۱۵-۲۰ دقیقې د لمر رڼا واخلئ",
      "غوره وخت: سهار (۶-۱۰ AM)",
      "لاسونه او پښې په خوندي ډول خلاص کړئ",
      "د ماسپښین لمر څخه ډډه وکړئ (۱۲-۳ PM)",
      "د اوږد تماس لپاره سنسکرین وکاروئ"
    ]
  },
  "Eat Healthy": {
    fullDescription: "A balanced diet rich in fruits, vegetables, whole grains, and lean proteins provides essential nutrients your body needs. Healthy eating helps maintain a healthy weight, reduces disease risk, and improves overall wellbeing.",
    fullDescriptionDari: "یو متوازن خوراک چې په میوو، سبزیجاتو، بشپړو غلو دانو او لاغر پروټینونو بډای وي، هغه اړین غذايي مواد چمتو کوي چې ستاسو بدن ته اړتیا لري. صحي خوراک د صحي وزن ساتنه کوي، د ناروغیو خطر کموي او عمومي تندرستي ښه کوي.",
    benefits: [
      "Provides essential nutrients",
      "Maintains healthy weight",
      "Prevents chronic diseases",
      "Improves energy levels",
      "Enhances mental clarity"
    ],
    benefitsDari: [
      "اړین غذايي مواد چمتو کوي",
      "صحي وزن ساتي",
      "د اوږدمهاله ناروغیو مخنیوی کوي",
      "د انرژۍ کچه ښه کوي",
      "ذهني روښانتیا زیاتوي"
    ],
    tips: [
      "Eat 5 servings of fruits/vegetables daily",
      "Choose whole grains over refined",
      "Include lean protein in each meal",
      "Limit processed and sugary foods",
      "Practice portion control"
    ],
    tipsDari: [
      "هره ورځ ۵ برخې میوې/سبزیجات وخورئ",
      "بشپړ غلې دانې د تصفیه شوو پر ځای انتخاب کړئ",
      "په هر خوراک کې لاغر پروټین شامل کړئ",
      "پروسس شوي او بوره لرونکي خواړه محدود کړئ",
      "د برخې کنټرول تمرین وکړئ"
    ]
  },
  "Mental Health": {
    fullDescription: "Mental health is as important as physical health. It affects how we think, feel, and act. Good mental health helps you cope with stress, build relationships, and make healthy choices. Practice mindfulness, meditation, and self-care regularly.",
    fullDescriptionDari: "رواني روغتیا د فزیکي روغتیا په څیر مهمه ده. دا اغیزه کوي چې موږ څنګه فکر کوو، احساسوو او عمل کوو. ښه رواني روغتیا تاسو سره د فشار سره مقابله کې، اړیکې جوړولو او صحي انتخابونو کولو کې مرسته کوي.",
    benefits: [
      "Reduces stress and anxiety",
      "Improves emotional wellbeing",
      "Enhances relationships",
      "Increases productivity",
      "Better decision making"
    ],
    benefitsDari: [
      "فشار او اضطراب کموي",
      "احساساتي تندرستي ښه کوي",
      "اړیکې ښه کوي",
      "تولید زیاتوي",
      "غوره تصمیم نیول"
    ],
    tips: [
      "Practice daily meditation (10-15 min)",
      "Connect with loved ones regularly",
      "Engage in hobbies you enjoy",
      "Seek professional help when needed",
      "Practice gratitude daily"
    ],
    tipsDari: [
      "هره ورځ مراقبه وکړئ (۱۰-۱۵ دقیقې)",
      "د خپلو عزیزانو سره په منظمه توګه اړیکه ونیسئ",
      "هغه شوقونو کې برخه واخلئ چې خوښوئ",
      "په اړتیا وخت کې د متخصص مرسته وغواړئ",
      "هره ورځ د مننې تمرین وکړئ"
    ]
  },
  "Good Sleep": {
    fullDescription: "Quality sleep is essential for physical and mental health. During sleep, your body repairs tissues, consolidates memories, and regulates hormones. Good sleep improves mood, boosts immunity, and enhances cognitive function.",
    fullDescriptionDari: "با کیفیته خوب د فزیکي او رواني روغتیا لپاره اړین دی. د خوب په وخت کې، ستاسو بدن نسجونه ترمیموي، یادونې پیاوړي کوي او هورمونونه تنظیموي. ښه خوب مزاج ښه کوي، مدافعت زیاتوي او ذهني فعالیت ښه کوي.",
    benefits: [
      "Repairs and restores body",
      "Consolidates memory",
      "Regulates hormones",
      "Boosts immune function",
      "Improves concentration"
    ],
    benefitsDari: [
      "بدن ترمیموي او بیا رغوي",
      "یاد پیاوړي کوي",
      "هورمونونه تنظیموي",
      "مدافعتي فعالیت زیاتوي",
      "تمرکز ښه کوي"
    ],
    tips: [
      "Sleep 7-8 hours nightly",
      "Keep consistent sleep schedule",
      "Avoid screens 1 hour before bed",
      "Create dark, cool bedroom",
      "Avoid caffeine after 2 PM"
    ],
    tipsDari: [
      "هره شپه ۷-۸ ساعته ویده شئ",
      "د خوب منظمه مهالویش وساتئ",
      "له خوب څخه ۱ ساعت مخکې د سکرین څخه ډډه وکړئ",
      "تیاره او یخه خوب خونه جوړه کړئ",
      "له ماسپښین ۲ بجو وروسته له کافین څخه ډډه وکړئ"
    ]
  },
  "Check Vitals": {
    fullDescription: "Regular health checkups and monitoring vital signs help detect health issues early. Tracking blood pressure, heart rate, temperature, and other vitals can prevent serious complications and ensure timely treatment.",
    fullDescriptionDari: "منظم روغتیايي معاینې او د حیاتي نښو څارنه د روغتیايي ستونزو ژر کشف کې مرسته کوي. د وینې فشار، د زړه ضربان، تودوخه او نور حیاتي نښې د جدي پېښو مخنیوی او په وخت درملنه ډاډمن کوي.",
    benefits: [
      "Early disease detection",
      "Prevents complications",
      "Tracks health trends",
      "Peace of mind",
      "Better treatment outcomes"
    ],
    benefitsDari: [
      "د ناروغیو ژر کشف",
      "د پیښو مخنیوی",
      "د روغتیا رجحاناتو تعقیب",
      "ذهني آرامتیا",
      "غوره درملنې پایلې"
    ],
    tips: [
      "Get annual physical checkup",
      "Monitor blood pressure monthly",
      "Track weight regularly",
      "Keep health records organized",
      "Report unusual symptoms promptly"
    ],
    tipsDari: [
      "کلنۍ فزیکي معاینه ترلاسه کړئ",
      "میاشتنی د وینې فشار وڅارئ",
      "وزن په منظمه توګه وڅارئ",
      "د روغتیا ریکارډونه تنظیم کړئ",
      "غیر معمولي نښې سمدستي راپور ورکړئ"
    ]
  },
  "Exercise Daily": {
    fullDescription: "Daily exercise strengthens your heart, improves circulation, builds muscle mass, and maintains bone density. Just 30 minutes of physical activity can significantly improve your health and extend your lifespan.",
    fullDescriptionDari: "ورځنی ورزش ستاسو زړه پیاوړی کوي، گردش ښه کوي، د عضلاتو حجم جوړوي او د هډوکو کثافت ساتي. یوازې ۳۰ دقیقې فزیکي فعالیت کولی شي ستاسو روغتیا خورا ښه کړي او ستاسو عمر اوږد کړي.",
    benefits: [
      "Strengthens cardiovascular system",
      "Builds muscle and bone",
      "Improves flexibility",
      "Burns calories",
      "Reduces stress"
    ],
    benefitsDari: [
      "د زړه او رګونو سیسټم پیاوړی کوي",
      "عضلې او هډوکي جوړوي",
      "انعطاف ښه کوي",
      "کالوري سوځوي",
      "فشار کموي"
    ],
    tips: [
      "Exercise 30 minutes, 5 days/week",
      "Mix cardio and strength training",
      "Start slow and progress gradually",
      "Find exercise you enjoy",
      "Stay consistent"
    ],
    tipsDari: [
      "هفتې کې ۵ ورځې، ۳۰ دقیقې ورزش وکړئ",
      "کارډیو او د ځواک روزنه یوځای کړئ",
      "ورو پیل وکړئ او په تدریج پرمختګ وکړئ",
      "هغه ورزش ومومئ چې خوښوئ",
      "دوامداره اوسئ"
    ]
  }
};

export function HealthTipModal({ tip, open, onClose }: HealthTipModalProps) {
  if (!tip) return null;

  const content = detailedContent[tip.title];

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <div className="flex items-center gap-4 mb-4">
            <div className="relative">
              <div className={`absolute inset-0 bg-gradient-to-r ${tip.gradient} rounded-2xl blur-lg opacity-30`}></div>
              <div className={`relative w-16 h-16 bg-gradient-to-br ${tip.gradient} rounded-2xl flex items-center justify-center shadow-lg`}>
                <tip.icon className="w-8 h-8 text-white" />
              </div>
            </div>
            <div>
              <DialogTitle className="text-2xl mb-1">{tip.title}</DialogTitle>
              <DialogDescription className="text-base text-emerald-600">
                {tip.titleDari}
              </DialogDescription>
            </div>
          </div>
        </DialogHeader>

        <div className="space-y-6">
          {/* Full Description */}
          <div>
            <p className="text-gray-700 leading-relaxed mb-2">{content.fullDescription}</p>
            <p className="text-gray-600 leading-relaxed">{content.fullDescriptionDari}</p>
          </div>

          {/* Benefits */}
          <div>
            <div className="flex items-center gap-2 mb-3">
              <CheckCircle className="w-5 h-5 text-emerald-600" />
              <h3 className="text-lg text-gray-900">Key Benefits | ګټې</h3>
            </div>
            <div className="grid grid-cols-1 gap-2">
              {content.benefits.map((benefit: string, index: number) => (
                <div key={index} className="flex items-start gap-3 p-3 bg-emerald-50 rounded-lg">
                  <Heart className="w-4 h-4 text-emerald-600 mt-0.5 flex-shrink-0" />
                  <div>
                    <p className="text-sm text-gray-800">{benefit}</p>
                    <p className="text-sm text-emerald-700">{content.benefitsDari[index]}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Tips */}
          <div>
            <div className="flex items-center gap-2 mb-3">
              <Info className="w-5 h-5 text-blue-600" />
              <h3 className="text-lg text-gray-900">Practical Tips | عملي لارښودونه</h3>
            </div>
            <div className="grid grid-cols-1 gap-2">
              {content.tips.map((tipText: string, index: number) => (
                <div key={index} className="flex items-start gap-3 p-3 bg-blue-50 rounded-lg">
                  <BookOpen className="w-4 h-4 text-blue-600 mt-0.5 flex-shrink-0" />
                  <div>
                    <p className="text-sm text-gray-800">{tipText}</p>
                    <p className="text-sm text-blue-700">{content.tipsDari[index]}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Warning */}
          <div className="flex items-start gap-3 p-4 bg-amber-50 border border-amber-200 rounded-lg">
            <AlertCircle className="w-5 h-5 text-amber-600 mt-0.5 flex-shrink-0" />
            <div>
              <h4 className="text-sm text-amber-900 mb-1">Important Note</h4>
              <p className="text-sm text-amber-800">
                Always consult with your healthcare provider before making significant changes to your health routine.
              </p>
              <p className="text-sm text-amber-700 mt-1">
                د خپلې روغتیا روتین کې د مهمو بدلونونو کولو څخه مخکې تل د خپل روغتیا چمتو کوونکي سره مشوره وکړئ.
              </p>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex gap-3 pt-4">
            <Button
              className="flex-1 bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-600 hover:to-teal-700"
            >
              <BookOpen className="w-4 h-4 mr-2" />
              Save Tip
            </Button>
            <Button
              variant="outline"
              className="flex-1"
            >
              <Share2 className="w-4 h-4 mr-2" />
              Share
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
