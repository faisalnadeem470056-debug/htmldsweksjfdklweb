import { useState, useEffect } from 'react';
import { Search, Star, MapPin, Phone, Calendar, ArrowLeft, Stethoscope, Award, Clock, Check, Filter, X, Heart, MessageCircle, Video, Mail, Users } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { AdBanner } from './AdBanner';
import { ImageWithFallback } from './figma/ImageWithFallback';

interface DoctorsDirectoryProps {
  language: 'ps' | 'fa' | 'en';
  onBack: () => void;
}

interface Doctor {
  id: number;
  name: { ps: string; fa: string; en: string };
  specialty: { ps: string; fa: string; en: string };
  category: string;
  experience: number;
  rating: number;
  location: { ps: string; fa: string; en: string };
  phone: string;
  available: boolean;
  verified: boolean;
  image: string;
  patients: number;
  consultationFee: number;
  education: { ps: string; fa: string; en: string };
  languages: string[];
}

export function DoctorsDirectory({ language, onBack }: DoctorsDirectoryProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [filteredDoctors, setFilteredDoctors] = useState<Doctor[]>([]);
  const [showFilters, setShowFilters] = useState(false);
  const [selectedDoctor, setSelectedDoctor] = useState<Doctor | null>(null);
  const [sortBy, setSortBy] = useState<'rating' | 'experience' | 'name'>('rating');

  const t = {
    ps: {
      title: 'دوکتوران',
      subtitle: 'د تجربه کار او ماهر دوکتوران ومومئ',
      search: 'د دوکتور نوم یا تخصص لټون...',
      allCategories: 'ټول کټګورۍ',
      filter: 'فلټر',
      sortBy: 'ترتیب کول',
      rating: 'ریټنګ',
      experience: 'تجربه',
      name: 'نوم',
      verified: 'تایید شوی',
      available: 'شته',
      notAvailable: 'نشته',
      yearsExp: 'کاله تجربه',
      patients: 'ناروغان',
      consultationFee: 'د معاینې فیس',
      callNow: 'اوس زنګ ووهئ',
      bookAppointment: 'وخت ونیسئ',
      viewProfile: 'پروفایل وګورئ',
      languages: 'ژبې',
      education: 'زده کړې',
      location: 'موقعیت',
      noDoctors: 'هیڅ دوکتور و نه موندل شو',
      tryDifferent: 'د بل شي په لټون کې هڅه وکړئ',
      topRated: 'غوره ریټنګ',
      mostExperienced: 'ډیره تجربه',
      categories: {
        all: 'ټول',
        cardiologist: 'زړه متخصص',
        pediatrician: 'ماشومانو متخصص',
        surgeon: 'جراح',
        gynecologist: 'ښځو متخصص',
        dentist: 'غاښونو متخصص',
        ophthalmologist: 'سترګو متخصص',
        dermatologist: 'پوستکي متخصص',
        neurologist: 'عصبي متخصص',
        orthopedic: 'هډوکو متخصص',
        ent: 'غوږ، پوزه، ستوني متخصص'
      }
    },
    fa: {
      title: 'دکتران',
      subtitle: 'دکتران با تجربه و متخصص را پیدا کنید',
      search: 'جستجوی نام دکتر یا تخصص...',
      allCategories: 'همه دسته‌بندی‌ها',
      filter: 'فیلتر',
      sortBy: 'مرتب‌سازی',
      rating: 'امتیاز',
      experience: 'تجربه',
      name: 'نام',
      verified: 'تایید شده',
      available: 'در دسترس',
      notAvailable: 'غیر فعال',
      yearsExp: 'سال تجربه',
      patients: 'بیماران',
      consultationFee: 'هزینه معاینه',
      callNow: 'تماس فوری',
      bookAppointment: 'نوبت بگیرید',
      viewProfile: 'مشاهده پروفایل',
      languages: 'زبان‌ها',
      education: 'تحصیلات',
      location: 'موقعیت',
      noDoctors: 'هیچ دکتری پیدا نشد',
      tryDifferent: 'جستجوی دیگری را امتحان کنید',
      topRated: 'بالاترین امتیاز',
      mostExperienced: 'بیشترین تجربه',
      categories: {
        all: 'همه',
        cardiologist: 'متخصص قلب',
        pediatrician: 'متخصص اطفال',
        surgeon: 'جراح',
        gynecologist: 'متخصص زنان',
        dentist: 'دندانپزشک',
        ophthalmologist: 'متخصص چشم',
        dermatologist: 'متخصص پوست',
        neurologist: 'متخصص اعصاب',
        orthopedic: 'متخصص استخوان',
        ent: 'متخصص گوش، حلق، بینی'
      }
    },
    en: {
      title: 'Doctors',
      subtitle: 'Find experienced and specialist doctors',
      search: 'Search doctor name or specialty...',
      allCategories: 'All Categories',
      filter: 'Filter',
      sortBy: 'Sort By',
      rating: 'Rating',
      experience: 'Experience',
      name: 'Name',
      verified: 'Verified',
      available: 'Available',
      notAvailable: 'Unavailable',
      yearsExp: 'years experience',
      patients: 'patients',
      consultationFee: 'Consultation Fee',
      callNow: 'Call Now',
      bookAppointment: 'Book Appointment',
      viewProfile: 'View Profile',
      languages: 'Languages',
      education: 'Education',
      location: 'Location',
      noDoctors: 'No doctors found',
      tryDifferent: 'Try a different search',
      topRated: 'Top Rated',
      mostExperienced: 'Most Experienced',
      categories: {
        all: 'All',
        cardiologist: 'Cardiologist',
        pediatrician: 'Pediatrician',
        surgeon: 'Surgeon',
        gynecologist: 'Gynecologist',
        dentist: 'Dentist',
        ophthalmologist: 'Ophthalmologist',
        dermatologist: 'Dermatologist',
        neurologist: 'Neurologist',
        orthopedic: 'Orthopedic',
        ent: 'ENT Specialist'
      }
    }
  };

  const text = t[language];

  // Complete Doctors Database - 250+ doctors
  const doctors: Doctor[] = [
    // Top Verified Cardiologists
    {
      id: 1,
      name: { ps: 'ډاکټر احمد شاه حسینی', fa: 'داکتر احمد شاه حسینی', en: 'Dr. Ahmad Shah Hosseini' },
      specialty: { ps: 'زړه متخصص', fa: 'متخصص قلب', en: 'Cardiologist' },
      category: 'cardiologist',
      experience: 18,
      rating: 4.9,
      location: { ps: 'کابل - د ډاریوس روغتون', fa: 'کابل - بیمارستان دارالشفاء', en: 'Kabul - Dawood Hospital' },
      phone: '+93 700 111 001',
      available: true,
      verified: true,
      image: 'https://images.unsplash.com/photo-1612349317150-e413f6a5b16d?w=400',
      patients: 5400,
      consultationFee: 1500,
      education: { ps: 'کابل طبي پوهنتون - MD', fa: 'دانشگاه طبی کابل - دکترای پزشکی', en: 'Kabul Medical University - MD' },
      languages: ['Pashto', 'Dari', 'English']
    },
    {
      id: 2,
      name: { ps: 'ډاکټره فاطمه احمدي', fa: 'داکتر فاطمه احمدی', en: 'Dr. Fatima Ahmadi' },
      specialty: { ps: 'ماشومانو متخصص', fa: 'متخصص اطفال', en: 'Pediatrician' },
      category: 'pediatrician',
      experience: 15,
      rating: 4.8,
      location: { ps: 'هرات - د ماشومانو روغتون', fa: 'هرات - بیمارستان اطفال', en: 'Herat - Children Hospital' },
      phone: '+93 701 222 002',
      available: true,
      verified: true,
      image: 'https://images.unsplash.com/photo-1632054226752-b1b40867f7a5?w=400',
      patients: 4200,
      consultationFee: 1200,
      education: { ps: 'نندرهار طبي پوهنتون', fa: 'دانشگاه طبی ننگرهار', en: 'Nangarhar Medical University' },
      languages: ['Dari', 'English']
    },
    {
      id: 3,
      name: { ps: 'ډاکټر محمد رحیم', fa: 'داکتر محمد رحیم', en: 'Dr. Mohammad Rahim' },
      specialty: { ps: 'جراح', fa: 'جراح عمومی', en: 'General Surgeon' },
      category: 'surgeon',
      experience: 22,
      rating: 4.9,
      location: { ps: 'مزار شریف - مرکزي روغتون', fa: 'مزار شریف - بیمارستان مرکزی', en: 'Mazar-i-Sharif - Central Hospital' },
      phone: '+93 702 333 003',
      available: true,
      verified: true,
      image: 'https://images.unsplash.com/photo-1758691461516-7e716e0ca135?w=400',
      patients: 6800,
      consultationFee: 2000,
      education: { ps: 'کابل طبي پوهنتون - جراحي تخصص', fa: 'دانشگاه طبی کابل - تخصص جراحی', en: 'Kabul Medical University - Surgery' },
      languages: ['Pashto', 'Dari', 'English', 'Urdu']
    },
    {
      id: 4,
      name: { ps: 'ډاکټره زینب کریمي', fa: 'داکتر زینب کریمی', en: 'Dr. Zainab Karimi' },
      specialty: { ps: 'ښځو او ولادي متخصص', fa: 'متخصص زنان و زایمان', en: 'Gynecologist & Obstetrician' },
      category: 'gynecologist',
      experience: 12,
      rating: 4.7,
      location: { ps: 'کندهار - ښځو روغتون', fa: 'کندهار - بیمارستان زنان', en: 'Kandahar - Women Hospital' },
      phone: '+93 703 444 004',
      available: true,
      verified: true,
      image: 'https://images.unsplash.com/photo-1632054226038-ed6997bfce1f?w=400',
      patients: 3600,
      consultationFee: 1300,
      education: { ps: 'بلخ طبي پوهنتون', fa: 'دانشگاه طبی بلخ', en: 'Balkh Medical University' },
      languages: ['Pashto', 'Dari']
    },
    {
      id: 5,
      name: { ps: 'ډاکټر عمر فاروق', fa: 'داکتر عمر فاروق', en: 'Dr. Omar Farooq' },
      specialty: { ps: 'غاښونو او فکونو متخصص', fa: 'متخصص دندانپزشکی', en: 'Dentist & Oral Surgeon' },
      category: 'dentist',
      experience: 10,
      rating: 4.6,
      location: { ps: 'جلال آباد - غاښونو کلینیک', fa: 'جلال‌آباد - کلینیک دندان', en: 'Jalalabad - Dental Clinic' },
      phone: '+93 704 555 005',
      available: true,
      verified: true,
      image: 'https://images.unsplash.com/photo-1725693485717-dbf8eac577c6?w=400',
      patients: 2800,
      consultationFee: 800,
      education: { ps: 'کابل غاښونو پوهنتون', fa: 'دانشگاه دندانپزشکی کابل', en: 'Kabul Dental University' },
      languages: ['Pashto', 'English']
    },
    {
      id: 6,
      name: { ps: 'ډاکټره مریم نوري', fa: 'داکتر مریم نوری', en: 'Dr. Maryam Noori' },
      specialty: { ps: 'سترګو متخصص', fa: 'متخصص چشم', en: 'Ophthalmologist' },
      category: 'ophthalmologist',
      experience: 16,
      rating: 4.8,
      location: { ps: 'کابل - د سترګو مرکز', fa: 'کابل - مرکز چشم', en: 'Kabul - Eye Center' },
      phone: '+93 705 666 006',
      available: true,
      verified: true,
      image: 'https://images.unsplash.com/photo-1615177393114-bd2917a4f74a?w=400',
      patients: 4500,
      consultationFee: 1400,
      education: { ps: 'هند - سترګو تخصص', fa: 'هند - تخصص چشم', en: 'India - Ophthalmology Specialization' },
      languages: ['Dari', 'English', 'Hindi']
    },
    {
      id: 7,
      name: { ps: 'ډاکټر رحمت الله', fa: 'داکتر رحمت‌الله', en: 'Dr. Rahmatullah' },
      specialty: { ps: 'پوستکي متخصص', fa: 'متخصص پوست', en: 'Dermatologist' },
      category: 'dermatologist',
      experience: 11,
      rating: 4.5,
      location: { ps: 'هرات - پوستکي کلینیک', fa: 'هرات - کلینیک پوست', en: 'Herat - Skin Clinic' },
      phone: '+93 706 777 007',
      available: true,
      verified: true,
      image: 'https://images.unsplash.com/photo-1666886573230-2b730505f298?w=400',
      patients: 3200,
      consultationFee: 1100,
      education: { ps: 'ترکیه - پوستکي تخصص', fa: 'ترکیه - تخصص پوست', en: 'Turkey - Dermatology' },
      languages: ['Dari', 'Pashto', 'Turkish']
    },
    {
      id: 8,
      name: { ps: 'ډاکټره سحر احمدزی', fa: 'داکتر سحر احمدزی', en: 'Dr. Sahar Ahmadzai' },
      specialty: { ps: 'عصبي متخصص', fa: 'متخصص اعصاب', en: 'Neurologist' },
      category: 'neurologist',
      experience: 14,
      rating: 4.7,
      location: { ps: 'کابل - عصبي روغتون', fa: 'کابل - بیمارستان اعصاب', en: 'Kabul - Neurology Hospital' },
      phone: '+93 707 888 008',
      available: false,
      verified: true,
      image: 'https://images.unsplash.com/photo-1622475441028-8927e3772656?w=400',
      patients: 3900,
      consultationFee: 1600,
      education: { ps: 'کابل طبي پوهنتون - عصبي علوم', fa: 'دانشگاه طبی کابل - علوم اعصاب', en: 'Kabul Medical University - Neuroscience' },
      languages: ['Pashto', 'Dari', 'English']
    },
    {
      id: 9,
      name: { ps: 'ډاکټر یوسف نظري', fa: 'داکتر یوسف نظری', en: 'Dr. Yousuf Nazari' },
      specialty: { ps: 'هډوکو متخصص', fa: 'متخصص استخوان', en: 'Orthopedic Surgeon' },
      category: 'orthopedic',
      experience: 19,
      rating: 4.9,
      location: { ps: 'مزار - هډوکو کلینیک', fa: 'مزار - کلینیک استخوان', en: 'Mazar - Orthopedic Clinic' },
      phone: '+93 708 999 009',
      available: true,
      verified: true,
      image: 'https://images.unsplash.com/photo-1758691462615-beafbf50bf3c?w=400',
      patients: 5100,
      consultationFee: 1700,
      education: { ps: 'پاکستان - هډوکو جراحي', fa: 'پاکستان - جراحی استخوان', en: 'Pakistan - Orthopedic Surgery' },
      languages: ['Dari', 'Urdu', 'English']
    },
    {
      id: 10,
      name: { ps: 'ډاکټره لیلا حسیني', fa: 'داکتر لیلا حسینی', en: 'Dr. Laila Hosseini' },
      specialty: { ps: 'غوږ، پوزه، ستوني متخصص', fa: 'متخصص گوش، حلق، بینی', en: 'ENT Specialist' },
      category: 'ent',
      experience: 13,
      rating: 4.6,
      location: { ps: 'کندهار - ENT مرکز', fa: 'کندهار - مرکز گوش و حلق', en: 'Kandahar - ENT Center' },
      phone: '+93 709 101 010',
      available: true,
      verified: true,
      image: 'https://images.unsplash.com/photo-1758691461513-88a0aef72160?w=400',
      patients: 2900,
      consultationFee: 1200,
      education: { ps: 'ایران - غوږ، پوزه، ستوني', fa: 'ایران - گوش، حلق، بینی', en: 'Iran - ENT Specialization' },
      languages: ['Dari', 'Persian']
    },
    // Add more doctors (continuing to 250+)
    ...Array.from({ length: 240 }, (_, i) => ({
      id: i + 11,
      name: {
        ps: `ډاکټر ${['احمد', 'محمد', 'علي', 'حسن', 'حسین', 'رحیم', 'کریم', 'فرید'][i % 8]} ${['احمدي', 'کریمي', 'نوري', 'حسیني', 'رحماني', 'فاروقي'][i % 6]}`,
        fa: `داکتر ${['احمد', 'محمد', 'علی', 'حسن', 'حسین', 'رحیم', 'کریم', 'فرید'][i % 8]} ${['احمدی', 'کریمی', 'نوری', 'حسینی', 'رحمانی', 'فاروقی'][i % 6]}`,
        en: `Dr. ${['Ahmad', 'Mohammad', 'Ali', 'Hassan', 'Hussain', 'Rahim', 'Karim', 'Farid'][i % 8]} ${['Ahmadi', 'Karimi', 'Noori', 'Hosseini', 'Rahmani', 'Farooqi'][i % 6]}`
      },
      specialty: {
        ps: ['زړه متخصص', 'ماشومانو متخصص', 'جراح', 'ښځو متخصص', 'غاښونو متخصص', 'سترګو متخصص', 'پوستکي متخصص', 'عصبي متخصص', 'هډوکو متخصص', 'غوږ، پوزه متخصص'][i % 10],
        fa: ['متخصص قلب', 'متخصص اطفال', 'جراح', 'متخصص زنان', 'دندانپزشک', 'متخصص چشم', 'متخصص پوست', 'متخصص اعصاب', 'متخصص استخوان', 'متخصص گوش و حلق'][i % 10],
        en: ['Cardiologist', 'Pediatrician', 'Surgeon', 'Gynecologist', 'Dentist', 'Ophthalmologist', 'Dermatologist', 'Neurologist', 'Orthopedic', 'ENT Specialist'][i % 10]
      },
      category: ['cardiologist', 'pediatrician', 'surgeon', 'gynecologist', 'dentist', 'ophthalmologist', 'dermatologist', 'neurologist', 'orthopedic', 'ent'][i % 10],
      experience: 5 + (i % 20),
      rating: 4.0 + (Math.random() * 0.9),
      location: {
        ps: ['کابل', 'هرات', 'مزار', 'کندهار', 'جلال آباد', 'بلخ'][i % 6] + ' - ' + ['مرکزي روغتون', 'کلینیک', 'طبي مرکز'][i % 3],
        fa: ['کابل', 'هرات', 'مزار', 'کندهار', 'جلال‌آباد', 'بلخ'][i % 6] + ' - ' + ['بیمارستان مرکزی', 'کلینیک', 'مرکز طبی'][i % 3],
        en: ['Kabul', 'Herat', 'Mazar', 'Kandahar', 'Jalalabad', 'Balkh'][i % 6] + ' - ' + ['Central Hospital', 'Clinic', 'Medical Center'][i % 3]
      },
      phone: `+93 ${700 + (i % 99)} ${(100 + i).toString().padStart(3, '0')} ${(i * 11).toString().padStart(3, '0')}`,
      available: i % 3 !== 0,
      verified: i % 2 === 0,
      image: [
        'https://images.unsplash.com/photo-1612349317150-e413f6a5b16d?w=400',
        'https://images.unsplash.com/photo-1632054226752-b1b40867f7a5?w=400',
        'https://images.unsplash.com/photo-1758691461516-7e716e0ca135?w=400',
        'https://images.unsplash.com/photo-1632054226038-ed6997bfce1f?w=400',
        'https://images.unsplash.com/photo-1725693485717-dbf8eac577c6?w=400',
        'https://images.unsplash.com/photo-1615177393114-bd2917a4f74a?w=400',
        'https://images.unsplash.com/photo-1666886573230-2b730505f298?w=400',
        'https://images.unsplash.com/photo-1622475441028-8927e3772656?w=400',
        'https://images.unsplash.com/photo-1758691462615-beafbf50bf3c?w=400',
        'https://images.unsplash.com/photo-1758691461513-88a0aef72160?w=400'
      ][i % 10],
      patients: 1000 + (i * 50),
      consultationFee: 800 + (i % 12) * 100,
      education: {
        ps: ['کابل طبي پوهنتون', 'نندرهار طبي پوهنتون', 'بلخ طبي پوهنتون'][i % 3],
        fa: ['دانشگاه طبی کابل', 'دانشگاه طبی ننگرهار', 'دانشگاه طبی بلخ'][i % 3],
        en: ['Kabul Medical University', 'Nangarhar Medical University', 'Balkh Medical University'][i % 3]
      },
      languages: [['Pashto', 'Dari'], ['Dari', 'English'], ['Pashto', 'Dari', 'English']][i % 3]
    }))
  ];

  useEffect(() => {
    filterDoctors();
  }, [searchQuery, selectedCategory, sortBy]);

  const filterDoctors = () => {
    let filtered = [...doctors];

    // Category filter
    if (selectedCategory !== 'all') {
      filtered = filtered.filter(doc => doc.category === selectedCategory);
    }

    // Search filter
    if (searchQuery.trim()) {
      filtered = filtered.filter(doc => 
        doc.name[language].toLowerCase().includes(searchQuery.toLowerCase()) ||
        doc.specialty[language].toLowerCase().includes(searchQuery.toLowerCase()) ||
        doc.location[language].toLowerCase().includes(searchQuery.toLowerCase())
      );
    }

    // Sort
    filtered.sort((a, b) => {
      if (sortBy === 'rating') return b.rating - a.rating;
      if (sortBy === 'experience') return b.experience - a.experience;
      return a.name[language].localeCompare(b.name[language]);
    });

    setFilteredDoctors(filtered);
  };

  const categories = [
    { id: 'all', icon: '🏥', color: 'from-gray-500 to-gray-600' },
    { id: 'cardiologist', icon: '❤️', color: 'from-red-500 to-pink-600' },
    { id: 'pediatrician', icon: '👶', color: 'from-blue-500 to-cyan-600' },
    { id: 'surgeon', icon: '🔪', color: 'from-purple-500 to-violet-600' },
    { id: 'gynecologist', icon: '👩', color: 'from-pink-500 to-rose-600' },
    { id: 'dentist', icon: '🦷', color: 'from-teal-500 to-cyan-600' },
    { id: 'ophthalmologist', icon: '👁️', color: 'from-indigo-500 to-blue-600' },
    { id: 'dermatologist', icon: '🧴', color: 'from-orange-500 to-amber-600' },
    { id: 'neurologist', icon: '🧠', color: 'from-violet-500 to-purple-600' },
    { id: 'orthopedic', icon: '🦴', color: 'from-green-500 to-emerald-600' },
    { id: 'ent', icon: '👂', color: 'from-yellow-500 to-orange-600' }
  ];

  const handleCall = (phone: string) => {
    window.location.href = `tel:${phone}`;
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50 pb-28 md:pb-8">
      {/* Header */}
      <div className="sticky top-0 z-40 backdrop-blur-xl bg-white/80 border-b border-white/20 shadow-lg">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center gap-4 mb-4">
            <Button variant="ghost" size="icon" onClick={onBack}>
              <ArrowLeft className="w-5 h-5" />
            </Button>
            <div className="flex-1">
              <h1 className="text-2xl bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
                {text.title}
              </h1>
              <p className="text-sm text-gray-600">{text.subtitle}</p>
            </div>
            <Button variant="outline" size="icon" onClick={() => setShowFilters(!showFilters)}>
              <Filter className="w-5 h-5" />
            </Button>
          </div>

          {/* Search Bar */}
          <div className="relative">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
            <Input
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder={text.search}
              className="pl-12 pr-4 h-12 bg-white/90 backdrop-blur-xl border-2 border-white/50 rounded-2xl"
              dir={language === 'en' ? 'ltr' : 'rtl'}
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute right-4 top-1/2 -translate-y-1/2"
              >
                <X className="w-5 h-5 text-gray-400" />
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Filters Panel */}
      <AnimatePresence>
        {showFilters && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            className="bg-white border-b border-gray-200"
          >
            <div className="container mx-auto px-4 py-4">
              <p className="text-sm font-medium mb-3">{text.sortBy}:</p>
              <div className="flex gap-2">
                {[
                  { id: 'rating' as const, label: text.rating, icon: Star },
                  { id: 'experience' as const, label: text.experience, icon: Award },
                  { id: 'name' as const, label: text.name, icon: Stethoscope }
                ].map(sort => (
                  <button
                    key={sort.id}
                    onClick={() => setSortBy(sort.id)}
                    className={`flex items-center gap-2 px-4 py-2 rounded-xl transition-all ${
                      sortBy === sort.id
                        ? 'bg-gradient-to-r from-blue-500 to-purple-600 text-white shadow-lg'
                        : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                    }`}
                  >
                    <sort.icon className="w-4 h-4" />
                    <span className="text-sm">{sort.label}</span>
                  </button>
                ))}
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <div className="container mx-auto px-4 py-6">
        {/* Categories Horizontal Scroll */}
        <div className="mb-6 overflow-x-auto pb-4 -mx-4 px-4 scrollbar-hide">
          <div className="flex gap-3 min-w-max">
            {categories.map(cat => (
              <button
                key={cat.id}
                onClick={() => setSelectedCategory(cat.id)}
                className={`flex flex-col items-center gap-2 p-4 rounded-2xl transition-all ${
                  selectedCategory === cat.id
                    ? `bg-gradient-to-br ${cat.color} text-white shadow-xl scale-105`
                    : 'bg-white/90 backdrop-blur-xl border border-white/50 text-gray-700 hover:scale-105'
                }`}
              >
                <span className="text-3xl">{cat.icon}</span>
                <span className="text-xs whitespace-nowrap">{text.categories[cat.id as keyof typeof text.categories]}</span>
              </button>
            ))}
          </div>
        </div>

        <AdBanner type="large" className="mb-6" />

        {/* Results Count */}
        <div className="flex items-center justify-between mb-4">
          <p className="text-sm text-gray-600">
            {filteredDoctors.length} {language === 'ps' ? 'دوکتوران' : language === 'fa' ? 'دکتر' : 'doctors'}
          </p>
          {selectedCategory !== 'all' && (
            <button
              onClick={() => setSelectedCategory('all')}
              className="text-sm text-blue-600 hover:underline"
            >
              {text.allCategories}
            </button>
          )}
        </div>

        {/* Doctors Grid */}
        {filteredDoctors.length === 0 ? (
          <div className="bg-white/90 backdrop-blur-xl rounded-3xl p-12 text-center">
            <Stethoscope className="w-16 h-16 text-gray-300 mx-auto mb-4" />
            <h3 className="text-xl mb-2 text-gray-700">{text.noDoctors}</h3>
            <p className="text-gray-500">{text.tryDifferent}</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredDoctors.map((doctor, index) => (
              <motion.div
                key={doctor.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.05 }}
                className="bg-white/90 backdrop-blur-xl rounded-3xl overflow-hidden border border-white/20 shadow-xl hover:shadow-2xl transition-all"
              >
                {/* Doctor Image */}
                <div className="relative h-48 overflow-hidden">
                  <ImageWithFallback
                    src={doctor.image}
                    alt={doctor.name[language]}
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
                  
                  {/* Badges */}
                  <div className="absolute top-3 right-3 flex flex-col gap-2">
                    {doctor.verified && (
                      <div className="bg-blue-500 text-white px-3 py-1 rounded-full text-xs flex items-center gap-1 shadow-lg">
                        <Check className="w-3 h-3" />
                        {text.verified}
                      </div>
                    )}
                    {doctor.available ? (
                      <div className="bg-green-500 text-white px-3 py-1 rounded-full text-xs shadow-lg">
                        {text.available}
                      </div>
                    ) : (
                      <div className="bg-gray-500 text-white px-3 py-1 rounded-full text-xs shadow-lg">
                        {text.notAvailable}
                      </div>
                    )}
                  </div>

                  {/* Rating */}
                  <div className="absolute bottom-3 left-3 bg-white/90 backdrop-blur-xl px-3 py-1 rounded-full flex items-center gap-1">
                    <Star className="w-4 h-4 text-yellow-500 fill-yellow-500" />
                    <span className="text-sm font-medium">{doctor.rating.toFixed(1)}</span>
                  </div>
                </div>

                {/* Doctor Info */}
                <div className="p-5">
                  <h3 className="text-lg font-medium mb-1">{doctor.name[language]}</h3>
                  <p className="text-sm text-blue-600 mb-3">{doctor.specialty[language]}</p>

                  <div className="space-y-2 mb-4">
                    <div className="flex items-center gap-2 text-sm text-gray-600">
                      <Award className="w-4 h-4" />
                      <span>{doctor.experience} {text.yearsExp}</span>
                    </div>
                    <div className="flex items-center gap-2 text-sm text-gray-600">
                      <MapPin className="w-4 h-4" />
                      <span className="truncate">{doctor.location[language]}</span>
                    </div>
                    <div className="flex items-center gap-2 text-sm text-gray-600">
                      <Users className="w-4 h-4" />
                      <span>{doctor.patients.toLocaleString()}+ {text.patients}</span>
                    </div>
                  </div>

                  {/* Consultation Fee */}
                  <div className="bg-gradient-to-r from-blue-50 to-purple-50 rounded-xl p-3 mb-4">
                    <p className="text-xs text-gray-600 mb-1">{text.consultationFee}</p>
                    <p className="text-lg font-medium text-blue-600">{doctor.consultationFee} افغانی</p>
                  </div>

                  {/* Action Buttons */}
                  <div className="grid grid-cols-2 gap-2">
                    <Button
                      onClick={() => handleCall(doctor.phone)}
                      className="bg-gradient-to-r from-green-500 to-emerald-600 hover:from-green-600 hover:to-emerald-700 text-white"
                    >
                      <Phone className="w-4 h-4 mr-2" />
                      {text.callNow}
                    </Button>
                    <Button
                      variant="outline"
                      onClick={() => setSelectedDoctor(doctor)}
                      className="border-blue-200 text-blue-600 hover:bg-blue-50"
                    >
                      {text.viewProfile}
                    </Button>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        )}
      </div>

      {/* Doctor Profile Modal */}
      <AnimatePresence>
        {selectedDoctor && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4"
            onClick={() => setSelectedDoctor(null)}
          >
            <motion.div
              initial={{ scale: 0.9, y: 50 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.9, y: 50 }}
              onClick={(e) => e.stopPropagation()}
              className="bg-white rounded-3xl max-w-2xl w-full max-h-[90vh] overflow-y-auto"
            >
              {/* Header Image */}
              <div className="relative h-64">
                <ImageWithFallback
                  src={selectedDoctor.image}
                  alt={selectedDoctor.name[language]}
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent" />
                
                <button
                  onClick={() => setSelectedDoctor(null)}
                  className="absolute top-4 right-4 bg-white/90 p-2 rounded-full hover:bg-white"
                >
                  <X className="w-5 h-5" />
                </button>

                {selectedDoctor.verified && (
                  <div className="absolute top-4 left-4 bg-blue-500 text-white px-4 py-2 rounded-full flex items-center gap-2">
                    <Check className="w-4 h-4" />
                    {text.verified}
                  </div>
                )}

                <div className="absolute bottom-4 left-4 right-4">
                  <h2 className="text-2xl text-white mb-2">{selectedDoctor.name[language]}</h2>
                  <p className="text-blue-200">{selectedDoctor.specialty[language]}</p>
                </div>
              </div>

              {/* Content */}
              <div className="p-6">
                {/* Stats */}
                <div className="grid grid-cols-3 gap-4 mb-6">
                  <div className="text-center p-4 bg-gradient-to-br from-blue-50 to-purple-50 rounded-2xl">
                    <Star className="w-6 h-6 text-yellow-500 mx-auto mb-2 fill-yellow-500" />
                    <p className="text-2xl font-medium">{selectedDoctor.rating}</p>
                    <p className="text-xs text-gray-600">{text.rating}</p>
                  </div>
                  <div className="text-center p-4 bg-gradient-to-br from-green-50 to-emerald-50 rounded-2xl">
                    <Award className="w-6 h-6 text-green-600 mx-auto mb-2" />
                    <p className="text-2xl font-medium">{selectedDoctor.experience}</p>
                    <p className="text-xs text-gray-600">{text.yearsExp}</p>
                  </div>
                  <div className="text-center p-4 bg-gradient-to-br from-purple-50 to-pink-50 rounded-2xl">
                    <Users className="w-6 h-6 text-purple-600 mx-auto mb-2" />
                    <p className="text-2xl font-medium">{(selectedDoctor.patients / 1000).toFixed(1)}K</p>
                    <p className="text-xs text-gray-600">{text.patients}</p>
                  </div>
                </div>

                {/* Details */}
                <div className="space-y-4 mb-6">
                  <div>
                    <p className="text-sm text-gray-600 mb-1">{text.education}</p>
                    <p className="font-medium">{selectedDoctor.education[language]}</p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-600 mb-1">{text.location}</p>
                    <p className="font-medium flex items-center gap-2">
                      <MapPin className="w-4 h-4 text-red-600" />
                      {selectedDoctor.location[language]}
                    </p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-600 mb-1">{text.languages}</p>
                    <div className="flex flex-wrap gap-2">
                      {selectedDoctor.languages.map(lang => (
                        <span key={lang} className="px-3 py-1 bg-blue-100 text-blue-700 rounded-full text-sm">
                          {lang}
                        </span>
                      ))}
                    </div>
                  </div>
                  <div>
                    <p className="text-sm text-gray-600 mb-1">{text.consultationFee}</p>
                    <p className="text-2xl font-medium text-blue-600">{selectedDoctor.consultationFee} افغانی</p>
                  </div>
                </div>

                {/* Action Buttons */}
                <div className="grid grid-cols-2 gap-3">
                  <Button
                    onClick={() => handleCall(selectedDoctor.phone)}
                    className="bg-gradient-to-r from-green-500 to-emerald-600 hover:from-green-600 hover:to-emerald-700 text-white h-12"
                  >
                    <Phone className="w-5 h-5 mr-2" />
                    {text.callNow}
                  </Button>
                  <Button
                    variant="outline"
                    className="border-blue-200 text-blue-600 hover:bg-blue-50 h-12"
                  >
                    <Calendar className="w-5 h-5 mr-2" />
                    {text.bookAppointment}
                  </Button>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}