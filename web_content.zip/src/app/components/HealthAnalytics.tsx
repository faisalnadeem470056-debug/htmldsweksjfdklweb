import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select";
import { Progress } from "./ui/progress";
import { 
  Activity,
  Heart,
  Footprints,
  Droplets,
  TrendingUp,
  TrendingDown,
  Calendar,
  Download,
  Share2,
  Target,
  Flame,
  Moon,
  Sun,
  Award,
  BarChart3,
  LineChart,
  Sparkles,
  Clock,
  AlertCircle,
  CheckCircle2
} from "lucide-react";
import { Separator } from "./ui/separator";
import {
  LineChart as RechartsLineChart,
  Line,
  BarChart as RechartsBarChart,
  Bar,
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Legend,
  PieChart,
  Pie,
  Cell
} from "recharts";
import { useLanguage } from "../contexts/LanguageContext";

// Blood Pressure Data
const bloodPressureData = [
  { date: "Nov 9", systolic: 128, diastolic: 82, time: "8:00 AM" },
  { date: "Nov 10", systolic: 125, diastolic: 80, time: "8:15 AM" },
  { date: "Nov 11", systolic: 130, diastolic: 85, time: "8:30 AM" },
  { date: "Nov 12", systolic: 122, diastolic: 78, time: "8:00 AM" },
  { date: "Nov 13", systolic: 135, diastolic: 88, time: "8:45 AM" },
  { date: "Nov 14", systolic: 120, diastolic: 76, time: "8:10 AM" },
  { date: "Nov 15", systolic: 125, diastolic: 80, time: "8:00 AM" },
];

// Step Count Data
const stepCountData = [
  { date: "Nov 9", steps: 8500, calories: 320, distance: 6.2 },
  { date: "Nov 10", steps: 10200, calories: 385, distance: 7.5 },
  { date: "Nov 11", steps: 6800, calories: 260, distance: 5.0 },
  { date: "Nov 12", steps: 12500, calories: 475, distance: 9.2 },
  { date: "Nov 13", steps: 9200, calories: 350, distance: 6.8 },
  { date: "Nov 14", steps: 11000, calories: 420, distance: 8.1 },
  { date: "Nov 15", steps: 9800, calories: 375, distance: 7.2 },
];

// Heart Rate Data
const heartRateData = [
  { time: "6 AM", bpm: 65, zone: "Rest" },
  { time: "9 AM", bpm: 72, zone: "Normal" },
  { time: "12 PM", bpm: 85, zone: "Light" },
  { time: "3 PM", bpm: 95, zone: "Moderate" },
  { time: "6 PM", bpm: 78, zone: "Normal" },
  { time: "9 PM", bpm: 68, zone: "Rest" },
];

// Water Intake Data
const waterIntakeData = [
  { day: "Mon", glasses: 8, goal: 8 },
  { day: "Tue", glasses: 6, goal: 8 },
  { day: "Wed", glasses: 7, goal: 8 },
  { day: "Thu", glasses: 9, goal: 8 },
  { day: "Fri", glasses: 5, goal: 8 },
  { day: "Sat", glasses: 8, goal: 8 },
  { day: "Sun", glasses: 7, goal: 8 },
];

// Sleep Data
const sleepData = [
  { name: "Deep", value: 2.5, color: "#3b82f6" },
  { name: "Light", value: 4.0, color: "#60a5fa" },
  { name: "REM", value: 1.5, color: "#93c5fd" },
  { name: "Awake", value: 0.5, color: "#e5e7eb" },
];

function HealthAnalytics() {
  const { t } = useLanguage();
  const [timeRange, setTimeRange] = useState("7days");
  const [activeTab, setActiveTab] = useState("overview");

  // Calculate averages
  const avgSystolic = Math.round(bloodPressureData.reduce((sum, d) => sum + d.systolic, 0) / bloodPressureData.length);
  const avgDiastolic = Math.round(bloodPressureData.reduce((sum, d) => sum + d.diastolic, 0) / bloodPressureData.length);
  const avgSteps = Math.round(stepCountData.reduce((sum, d) => sum + d.steps, 0) / stepCountData.length);
  const totalSteps = stepCountData.reduce((sum, d) => sum + d.steps, 0);
  const avgHeartRate = Math.round(heartRateData.reduce((sum, d) => sum + d.bpm, 0) / heartRateData.length);
  const totalWater = waterIntakeData.reduce((sum, d) => sum + d.glasses, 0);
  const totalSleep = sleepData.reduce((sum, d) => sum + d.value, 0);

  // Today's stats
  const todaySteps = stepCountData[stepCountData.length - 1].steps;
  const stepGoal = 10000;
  const stepProgress = (todaySteps / stepGoal) * 100;

  const todayWater = waterIntakeData[waterIntakeData.length - 1].glasses;
  const waterGoal = 8;
  const waterProgress = (todayWater / waterGoal) * 100;

  return (
    <section className="py-16 md:py-24 bg-gradient-to-b from-white via-blue-50/30 to-white relative overflow-hidden min-h-screen">
      {/* Background decoration */}
      <div className="absolute top-0 left-0 w-[500px] h-[500px] bg-gradient-to-br from-blue-100/50 to-cyan-100/50 rounded-full blur-3xl animate-float"></div>
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        {/* Header */}
        <div className="text-center mb-12 md:mb-16 space-y-4">
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-blue-100 to-cyan-100 rounded-full">
            <Sparkles className="w-4 h-4 text-blue-600 animate-pulse-glow" />
            <span className="text-blue-700 text-sm uppercase tracking-wider">Health Analytics</span>
          </div>
          <h2 className="text-4xl md:text-6xl">
            <span className="bg-gradient-to-r from-blue-600 via-cyan-600 to-teal-600 bg-clip-text text-transparent">
              {t("health_dashboard")}
            </span>
          </h2>
          <p className="text-gray-600 max-w-2xl mx-auto text-lg">
            د روغتیا وضعیت تحلیل - Track your health metrics and progress
          </p>
        </div>

        {/* Time Range Selector */}
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center gap-2">
            <Calendar className="w-5 h-5 text-blue-600" />
            <span className="text-sm text-gray-700">Time Period:</span>
          </div>
          <Select value={timeRange} onValueChange={setTimeRange}>
            <SelectTrigger className="w-[140px]">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="today">Today</SelectItem>
              <SelectItem value="7days">Last 7 Days</SelectItem>
              <SelectItem value="30days">Last 30 Days</SelectItem>
              <SelectItem value="90days">Last 3 Months</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {/* Quick Stats */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
          {/* Steps Today */}
          <Card className="hover-lift border-0 shadow-lg">
            <CardContent className="p-6">
              <div className="flex items-start justify-between mb-4">
                <div className="p-3 bg-gradient-to-br from-blue-500 to-cyan-600 rounded-xl">
                  <Footprints className="w-6 h-6 text-white" />
                </div>
                <Badge className="bg-blue-100 text-blue-700">
                  {stepProgress >= 100 ? (
                    <><CheckCircle2 className="w-3 h-3 mr-1" /> Goal Met</>
                  ) : (
                    <><Target className="w-3 h-3 mr-1" /> {Math.round(stepProgress)}%</>
                  )}
                </Badge>
              </div>
              <h3 className="text-sm text-gray-600 mb-1">Steps Today</h3>
              <p className="text-xs text-blue-600 mb-3">نن قدمونه</p>
              <div className="flex items-baseline gap-2 mb-2">
                <span className="text-3xl text-gray-900">{todaySteps.toLocaleString()}</span>
                <span className="text-sm text-gray-600">/ {stepGoal.toLocaleString()}</span>
              </div>
              <Progress value={stepProgress} className="h-2" />
            </CardContent>
          </Card>

          {/* Heart Rate */}
          <Card className="hover-lift border-0 shadow-lg">
            <CardContent className="p-6">
              <div className="flex items-start justify-between mb-4">
                <div className="p-3 bg-gradient-to-br from-red-500 to-pink-600 rounded-xl">
                  <Heart className="w-6 h-6 text-white" />
                </div>
                <Badge className="bg-green-100 text-green-700">
                  <CheckCircle2 className="w-3 h-3 mr-1" />
                  Normal
                </Badge>
              </div>
              <h3 className="text-sm text-gray-600 mb-1">{t("heart_rate")}</h3>
              <p className="text-xs text-red-600 mb-3">د زړه ضربان</p>
              <div className="flex items-baseline gap-2 mb-2">
                <span className="text-3xl text-gray-900">{avgHeartRate}</span>
                <span className="text-sm text-gray-600">bpm avg</span>
              </div>
              <div className="flex items-center gap-1 text-sm text-green-600">
                <TrendingDown className="w-4 h-4" />
                <span>-2 bpm from yesterday</span>
              </div>
            </CardContent>
          </Card>

          {/* Water Intake */}
          <Card className="hover-lift border-0 shadow-lg">
            <CardContent className="p-6">
              <div className="flex items-start justify-between mb-4">
                <div className="p-3 bg-gradient-to-br from-cyan-500 to-blue-600 rounded-xl">
                  <Droplets className="w-6 h-6 text-white" />
                </div>
                <Badge className={waterProgress >= 100 ? "bg-green-100 text-green-700" : "bg-yellow-100 text-yellow-700"}>
                  {waterProgress >= 100 ? (
                    <><CheckCircle2 className="w-3 h-3 mr-1" /> Goal Met</>
                  ) : (
                    <><Target className="w-3 h-3 mr-1" /> {Math.round(waterProgress)}%</>
                  )}
                </Badge>
              </div>
              <h3 className="text-sm text-gray-600 mb-1">Water Intake</h3>
              <p className="text-xs text-cyan-600 mb-3">د اوبو استعمال</p>
              <div className="flex items-baseline gap-2 mb-2">
                <span className="text-3xl text-gray-900">{todayWater}</span>
                <span className="text-sm text-gray-600">/ {waterGoal} glasses</span>
              </div>
              <Progress value={waterProgress} className="h-2" />
            </CardContent>
          </Card>

          {/* Blood Pressure */}
          <Card className="hover-lift border-0 shadow-lg">
            <CardContent className="p-6">
              <div className="flex items-start justify-between mb-4">
                <div className="p-3 bg-gradient-to-br from-purple-500 to-pink-600 rounded-xl">
                  <Activity className="w-6 h-6 text-white" />
                </div>
                <Badge className="bg-yellow-100 text-yellow-700">
                  <AlertCircle className="w-3 h-3 mr-1" />
                  Monitor
                </Badge>
              </div>
              <h3 className="text-sm text-gray-600 mb-1">{t("blood_pressure")}</h3>
              <p className="text-xs text-purple-600 mb-3">د وینې فشار</p>
              <div className="flex items-baseline gap-2 mb-2">
                <span className="text-3xl text-gray-900">{avgSystolic}/{avgDiastolic}</span>
                <span className="text-sm text-gray-600">mmHg</span>
              </div>
              <div className="flex items-center gap-1 text-sm text-yellow-600">
                <TrendingUp className="w-4 h-4" />
                <span>Slightly elevated</span>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Main Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-4 mb-8">
            <TabsTrigger value="overview">
              <BarChart3 className="w-4 h-4 mr-2" />
              <span className="hidden md:inline">Overview</span>
            </TabsTrigger>
            <TabsTrigger value="steps">
              <Footprints className="w-4 h-4 mr-2" />
              <span className="hidden md:inline">Steps</span>
            </TabsTrigger>
            <TabsTrigger value="heart">
              <Heart className="w-4 h-4 mr-2" />
              <span className="hidden md:inline">Heart</span>
            </TabsTrigger>
            <TabsTrigger value="vitals">
              <Activity className="w-4 h-4 mr-2" />
              <span className="hidden md:inline">Vitals</span>
            </TabsTrigger>
          </TabsList>

          {/* Overview Tab */}
          <TabsContent value="overview" className="space-y-6">
            {/* Blood Pressure Trends */}
            <Card className="border-0 shadow-lg">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle className="flex items-center gap-2">
                    <Activity className="w-5 h-5 text-purple-600" />
                    Blood Pressure Trends - د وینې فشار رجحانات
                  </CardTitle>
                  <Button size="sm" variant="outline">
                    <Download className="w-4 h-4 mr-2" />
                    Export
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <RechartsLineChart data={bloodPressureData}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
                    <XAxis dataKey="date" stroke="#6b7280" />
                    <YAxis stroke="#6b7280" />
                    <Tooltip 
                      contentStyle={{ 
                        backgroundColor: '#fff', 
                        border: '1px solid #e5e7eb',
                        borderRadius: '8px',
                        boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)'
                      }}
                    />
                    <Legend />
                    <Line 
                      type="monotone" 
                      dataKey="systolic" 
                      stroke="#8b5cf6" 
                      strokeWidth={3}
                      name="Systolic"
                      dot={{ fill: '#8b5cf6', r: 5 }}
                    />
                    <Line 
                      type="monotone" 
                      dataKey="diastolic" 
                      stroke="#ec4899" 
                      strokeWidth={3}
                      name="Diastolic"
                      dot={{ fill: '#ec4899', r: 5 }}
                    />
                  </RechartsLineChart>
                </ResponsiveContainer>
                <div className="grid grid-cols-3 gap-4 mt-6">
                  <div className="p-3 bg-purple-50 rounded-lg text-center">
                    <p className="text-sm text-gray-600 mb-1">Average</p>
                    <p className="text-xl text-purple-600">{avgSystolic}/{avgDiastolic}</p>
                  </div>
                  <div className="p-3 bg-green-50 rounded-lg text-center">
                    <p className="text-sm text-gray-600 mb-1">Normal Range</p>
                    <p className="text-xl text-green-600">120/80</p>
                  </div>
                  <div className="p-3 bg-blue-50 rounded-lg text-center">
                    <p className="text-sm text-gray-600 mb-1">Latest</p>
                    <p className="text-xl text-blue-600">
                      {bloodPressureData[bloodPressureData.length - 1].systolic}/
                      {bloodPressureData[bloodPressureData.length - 1].diastolic}
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Water Intake Chart */}
            <Card className="border-0 shadow-lg">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Droplets className="w-5 h-5 text-cyan-600" />
                  Water Intake - د اوبو استعمال
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <RechartsBarChart data={waterIntakeData}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
                    <XAxis dataKey="day" stroke="#6b7280" />
                    <YAxis stroke="#6b7280" />
                    <Tooltip 
                      contentStyle={{ 
                        backgroundColor: '#fff', 
                        border: '1px solid #e5e7eb',
                        borderRadius: '8px'
                      }}
                    />
                    <Legend />
                    <Bar dataKey="glasses" fill="#06b6d4" name="Glasses" radius={[8, 8, 0, 0]} />
                    <Bar dataKey="goal" fill="#e5e7eb" name="Goal" radius={[8, 8, 0, 0]} />
                  </RechartsBarChart>
                </ResponsiveContainer>
                <div className="grid grid-cols-2 gap-4 mt-6">
                  <div className="p-4 bg-cyan-50 rounded-lg">
                    <div className="flex items-center gap-2 mb-2">
                      <Droplets className="w-5 h-5 text-cyan-600" />
                      <span className="text-sm text-gray-700">Total This Week</span>
                    </div>
                    <p className="text-2xl text-cyan-600">{totalWater} glasses</p>
                    <p className="text-xs text-gray-600 mt-1">≈ {(totalWater * 0.25).toFixed(1)} Liters</p>
                  </div>
                  <div className="p-4 bg-blue-50 rounded-lg">
                    <div className="flex items-center gap-2 mb-2">
                      <Target className="w-5 h-5 text-blue-600" />
                      <span className="text-sm text-gray-700">Goal Achievement</span>
                    </div>
                    <p className="text-2xl text-blue-600">{Math.round((totalWater / (waterGoal * 7)) * 100)}%</p>
                    <p className="text-xs text-gray-600 mt-1">{totalWater} / {waterGoal * 7} glasses</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Steps Tab */}
          <TabsContent value="steps" className="space-y-6">
            <Card className="border-0 shadow-lg">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle className="flex items-center gap-2">
                    <Footprints className="w-5 h-5 text-blue-600" />
                    Step Count Activity - د قدمونو فعالیت
                  </CardTitle>
                  <Button size="sm" variant="outline">
                    <Share2 className="w-4 h-4 mr-2" />
                    Share
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={350}>
                  <AreaChart data={stepCountData}>
                    <defs>
                      <linearGradient id="colorSteps" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.8}/>
                        <stop offset="95%" stopColor="#3b82f6" stopOpacity={0}/>
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
                    <XAxis dataKey="date" stroke="#6b7280" />
                    <YAxis stroke="#6b7280" />
                    <Tooltip 
                      contentStyle={{ 
                        backgroundColor: '#fff', 
                        border: '1px solid #e5e7eb',
                        borderRadius: '8px'
                      }}
                    />
                    <Area 
                      type="monotone" 
                      dataKey="steps" 
                      stroke="#3b82f6" 
                      strokeWidth={3}
                      fillOpacity={1} 
                      fill="url(#colorSteps)" 
                    />
                  </AreaChart>
                </ResponsiveContainer>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-6">
                  <div className="p-4 bg-gradient-to-r from-blue-50 to-cyan-50 rounded-lg">
                    <div className="flex items-center gap-2 mb-2">
                      <Footprints className="w-5 h-5 text-blue-600" />
                      <span className="text-sm text-gray-700">Total Steps</span>
                    </div>
                    <p className="text-2xl text-blue-600">{totalSteps.toLocaleString()}</p>
                    <p className="text-xs text-gray-600 mt-1">Last 7 days</p>
                  </div>

                  <div className="p-4 bg-gradient-to-r from-green-50 to-emerald-50 rounded-lg">
                    <div className="flex items-center gap-2 mb-2">
                      <Flame className="w-5 h-5 text-green-600" />
                      <span className="text-sm text-gray-700">Calories Burned</span>
                    </div>
                    <p className="text-2xl text-green-600">
                      {stepCountData.reduce((sum, d) => sum + d.calories, 0).toLocaleString()}
                    </p>
                    <p className="text-xs text-gray-600 mt-1">≈ {Math.round(stepCountData.reduce((sum, d) => sum + d.calories, 0) / 7)} cal/day</p>
                  </div>

                  <div className="p-4 bg-gradient-to-r from-purple-50 to-pink-50 rounded-lg">
                    <div className="flex items-center gap-2 mb-2">
                      <Target className="w-5 h-5 text-purple-600" />
                      <span className="text-sm text-gray-700">Distance</span>
                    </div>
                    <p className="text-2xl text-purple-600">
                      {stepCountData.reduce((sum, d) => sum + d.distance, 0).toFixed(1)} km
                    </p>
                    <p className="text-xs text-gray-600 mt-1">≈ {(stepCountData.reduce((sum, d) => sum + d.distance, 0) / 7).toFixed(1)} km/day</p>
                  </div>
                </div>

                <Separator className="my-6" />

                <div className="grid grid-cols-2 gap-4">
                  <div className="p-3 border-2 border-blue-200 rounded-lg">
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-sm text-gray-700">Daily Goal</span>
                      <Badge className="bg-blue-100 text-blue-700">Active</Badge>
                    </div>
                    <p className="text-xl text-blue-600">{stepGoal.toLocaleString()} steps</p>
                  </div>
                  <div className="p-3 border-2 border-green-200 rounded-lg">
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-sm text-gray-700">Best Day</span>
                      <Award className="w-4 h-4 text-green-600" />
                    </div>
                    <p className="text-xl text-green-600">
                      {Math.max(...stepCountData.map(d => d.steps)).toLocaleString()}
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Heart Tab */}
          <TabsContent value="heart" className="space-y-6">
            <Card className="border-0 shadow-lg">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Heart className="w-5 h-5 text-red-600" />
                  Heart Rate Throughout Day - د ورځې په اوږدو کې د زړه ضربان
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <RechartsLineChart data={heartRateData}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
                    <XAxis dataKey="time" stroke="#6b7280" />
                    <YAxis stroke="#6b7280" domain={[50, 120]} />
                    <Tooltip 
                      contentStyle={{ 
                        backgroundColor: '#fff', 
                        border: '1px solid #e5e7eb',
                        borderRadius: '8px'
                      }}
                    />
                    <Line 
                      type="monotone" 
                      dataKey="bpm" 
                      stroke="#ef4444" 
                      strokeWidth={3}
                      dot={{ fill: '#ef4444', r: 6 }}
                    />
                  </RechartsLineChart>
                </ResponsiveContainer>

                {/* Heart Rate Zones */}
                <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mt-6">
                  <div className="p-3 bg-gray-50 rounded-lg text-center">
                    <div className="w-8 h-8 bg-gray-400 rounded-full mx-auto mb-2"></div>
                    <p className="text-xs text-gray-600 mb-1">Rest</p>
                    <p className="text-sm text-gray-900">60-70 bpm</p>
                  </div>
                  <div className="p-3 bg-green-50 rounded-lg text-center">
                    <div className="w-8 h-8 bg-green-500 rounded-full mx-auto mb-2"></div>
                    <p className="text-xs text-gray-600 mb-1">Light</p>
                    <p className="text-sm text-gray-900">70-100 bpm</p>
                  </div>
                  <div className="p-3 bg-yellow-50 rounded-lg text-center">
                    <div className="w-8 h-8 bg-yellow-500 rounded-full mx-auto mb-2"></div>
                    <p className="text-xs text-gray-600 mb-1">Moderate</p>
                    <p className="text-sm text-gray-900">100-140 bpm</p>
                  </div>
                  <div className="p-3 bg-red-50 rounded-lg text-center">
                    <div className="w-8 h-8 bg-red-500 rounded-full mx-auto mb-2"></div>
                    <p className="text-xs text-gray-600 mb-1">Intense</p>
                    <p className="text-sm text-gray-900">140+ bpm</p>
                  </div>
                </div>

                <Separator className="my-6" />

                <div className="grid grid-cols-3 gap-4">
                  <div className="p-4 bg-red-50 rounded-lg text-center">
                    <p className="text-sm text-gray-600 mb-2">Current</p>
                    <p className="text-3xl text-red-600">{heartRateData[heartRateData.length - 1].bpm}</p>
                    <p className="text-xs text-gray-600 mt-1">bpm</p>
                  </div>
                  <div className="p-4 bg-blue-50 rounded-lg text-center">
                    <p className="text-sm text-gray-600 mb-2">Average</p>
                    <p className="text-3xl text-blue-600">{avgHeartRate}</p>
                    <p className="text-xs text-gray-600 mt-1">bpm</p>
                  </div>
                  <div className="p-4 bg-purple-50 rounded-lg text-center">
                    <p className="text-sm text-gray-600 mb-2">Resting</p>
                    <p className="text-3xl text-purple-600">65</p>
                    <p className="text-xs text-gray-600 mt-1">bpm</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Vitals Tab */}
          <TabsContent value="vitals" className="space-y-6">
            {/* Sleep Analysis */}
            <Card className="border-0 shadow-lg">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Moon className="w-5 h-5 text-indigo-600" />
                  Sleep Analysis - د خوب تحلیل
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <ResponsiveContainer width="100%" height={250}>
                      <PieChart>
                        <Pie
                          data={sleepData}
                          cx="50%"
                          cy="50%"
                          innerRadius={60}
                          outerRadius={90}
                          paddingAngle={5}
                          dataKey="value"
                        >
                          {sleepData.map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={entry.color} />
                          ))}
                        </Pie>
                        <Tooltip />
                      </PieChart>
                    </ResponsiveContainer>
                    <div className="text-center mt-4">
                      <p className="text-3xl text-indigo-600">{totalSleep}h</p>
                      <p className="text-sm text-gray-600">Total Sleep</p>
                    </div>
                  </div>

                  <div className="space-y-3">
                    {sleepData.map((phase, index) => (
                      <div key={index} className="p-3 rounded-lg" style={{ backgroundColor: `${phase.color}20` }}>
                        <div className="flex items-center justify-between mb-2">
                          <span className="text-sm text-gray-700">{phase.name} Sleep</span>
                          <span className="text-sm font-medium" style={{ color: phase.color }}>
                            {phase.value}h
                          </span>
                        </div>
                        <Progress 
                          value={(phase.value / totalSleep) * 100} 
                          className="h-2"
                          style={{ 
                            backgroundColor: '#e5e7eb'
                          }}
                        />
                      </div>
                    ))}
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Activity Summary */}
            <Card className="border-0 shadow-lg">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Sun className="w-5 h-5 text-yellow-600" />
                  Today's Activity Summary - د نن فعالیت لنډیز
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-4">
                    <div className="flex items-center justify-between p-4 bg-blue-50 rounded-lg">
                      <div className="flex items-center gap-3">
                        <div className="p-2 bg-blue-500 rounded-lg">
                          <Footprints className="w-5 h-5 text-white" />
                        </div>
                        <div>
                          <p className="text-sm text-gray-600">Steps</p>
                          <p className="text-xl text-blue-600">{todaySteps.toLocaleString()}</p>
                        </div>
                      </div>
                      <Badge className="bg-blue-200 text-blue-800">+12%</Badge>
                    </div>

                    <div className="flex items-center justify-between p-4 bg-green-50 rounded-lg">
                      <div className="flex items-center gap-3">
                        <div className="p-2 bg-green-500 rounded-lg">
                          <Flame className="w-5 h-5 text-white" />
                        </div>
                        <div>
                          <p className="text-sm text-gray-600">Calories</p>
                          <p className="text-xl text-green-600">{stepCountData[stepCountData.length - 1].calories}</p>
                        </div>
                      </div>
                      <Badge className="bg-green-200 text-green-800">+8%</Badge>
                    </div>

                    <div className="flex items-center justify-between p-4 bg-cyan-50 rounded-lg">
                      <div className="flex items-center gap-3">
                        <div className="p-2 bg-cyan-500 rounded-lg">
                          <Droplets className="w-5 h-5 text-white" />
                        </div>
                        <div>
                          <p className="text-sm text-gray-600">Water</p>
                          <p className="text-xl text-cyan-600">{todayWater} glasses</p>
                        </div>
                      </div>
                      <Badge className="bg-cyan-200 text-cyan-800">On Track</Badge>
                    </div>
                  </div>

                  <div className="p-6 bg-gradient-to-br from-purple-50 to-pink-50 rounded-lg">
                    <div className="flex items-center gap-2 mb-4">
                      <Award className="w-6 h-6 text-purple-600" />
                      <h3 className="text-lg text-gray-900">Health Score</h3>
                    </div>
                    <div className="text-center mb-4">
                      <p className="text-5xl text-purple-600 mb-2">85</p>
                      <p className="text-sm text-gray-600">out of 100</p>
                    </div>
                    <Progress value={85} className="h-3 mb-4" />
                    <div className="space-y-2 text-sm text-gray-700">
                      <div className="flex items-center justify-between">
                        <span>• Activity Level</span>
                        <span className="text-green-600">Excellent</span>
                      </div>
                      <div className="flex items-center justify-between">
                        <span>• Sleep Quality</span>
                        <span className="text-blue-600">Good</span>
                      </div>
                      <div className="flex items-center justify-between">
                        <span>• Hydration</span>
                        <span className="text-cyan-600">Good</span>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </section>
  );
}

export default HealthAnalytics;
