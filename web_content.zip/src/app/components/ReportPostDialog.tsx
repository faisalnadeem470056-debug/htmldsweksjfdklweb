import { useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "./ui/dialog";
import { Button } from "./ui/button";
import { Label } from "./ui/label";
import { Textarea } from "./ui/textarea";
import { RadioGroup, RadioGroupItem } from "./ui/radio-group";
import { Alert, AlertDescription } from "./ui/alert";
import { Flag, AlertTriangle, CheckCircle2, Shield } from "lucide-react";
import { reportPost } from "../utils/contentModeration";
import { toast } from "sonner@2.0.3";
import { useAuth } from "../contexts/AuthContext";

interface ReportPostDialogProps {
  postId: number;
  postAuthor: string;
}

export function ReportPostDialog({ postId, postAuthor }: ReportPostDialogProps) {
  const { user } = useAuth();
  const [open, setOpen] = useState(false);
  const [selectedReason, setSelectedReason] = useState("");
  const [description, setDescription] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);

  const reportReasons = [
    {
      value: "spam",
      label: "Spam or Misleading",
      labelDari: "سپم یا گمراه کننده",
      labelPashto: "سپم یا غلط معلومات"
    },
    {
      value: "harassment",
      label: "Harassment or Bullying",
      labelDari: "آزار یا قلدری",
      labelPashto: "ځورول یا تیری"
    },
    {
      value: "inappropriate",
      label: "Inappropriate Content",
      labelDari: "محتوای نامناسب",
      labelPashto: "ناسم محتوا"
    },
    {
      value: "violence",
      label: "Violence or Threats",
      labelDari: "خشونت یا تهدید",
      labelPashto: "تشدد یا ګواښونه"
    },
    {
      value: "false_info",
      label: "False Health Information",
      labelDari: "اطلاعات غلط صحی",
      labelPashto: "غلط روغتیایی معلومات"
    },
    {
      value: "other",
      label: "Other",
      labelDari: "دیگر",
      labelPashto: "نور"
    }
  ];

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!selectedReason) {
      toast.error("Please select a reason / مهرباني وکړئ دلیل انتخاب کړئ");
      return;
    }

    if (!description.trim()) {
      toast.error("Please provide details / مهرباني وکړئ تفصیلات ولیکئ");
      return;
    }

    setIsSubmitting(true);

    try {
      reportPost({
        postId,
        reportedBy: user?.email || "Anonymous",
        reason: selectedReason,
        description: description.trim(),
        timestamp: new Date().toISOString()
      });

      toast.success(
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-green-600" />
            <span className="font-semibold">Report submitted successfully!</span>
          </div>
          <p className="text-sm text-gray-600">
            Admin has been notified at: ibrahimkhaksar.it@gmail.com
          </p>
          <p className="text-sm text-gray-600">
            راپور په بریالیتوب سره وسپارل شو! Admin ته خبر ورکړل شو.
          </p>
        </div>,
        { duration: 6000 }
      );

      setOpen(false);
      setSelectedReason("");
      setDescription("");
    } catch (error) {
      toast.error("Failed to submit report / راپور وسپارل نشو");
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <button className="flex items-center gap-1 text-xs text-gray-500 hover:text-red-600 transition-colors">
          <Flag className="w-3.5 h-3.5" />
          <span>Report</span>
        </button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <div className="flex items-center gap-3 mb-2">
            <div className="w-12 h-12 bg-gradient-to-br from-red-500 to-orange-500 rounded-full flex items-center justify-center">
              <Shield className="w-6 h-6 text-white" />
            </div>
            <div>
              <DialogTitle className="text-xl">Report Post</DialogTitle>
              <DialogDescription>
                Help us keep the community safe / د ټولنې امنیت کې مرسته وکړئ
              </DialogDescription>
            </div>
          </div>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Alert */}
          <Alert className="border-orange-200 bg-orange-50">
            <AlertTriangle className="h-4 w-4 text-orange-600" />
            <AlertDescription className="text-orange-800 text-sm">
              <strong>Note:</strong> False reports may result in action on your account.
              <br />
              <span className="text-xs">
                یادونه: غلط راپورونه ستاسو په حساب کې اقدام لامل کیدای شي.
              </span>
            </AlertDescription>
          </Alert>

          {/* Reason Selection */}
          <div className="space-y-3">
            <Label>Why are you reporting this post? / ولې دا پوست راپور کوئ؟</Label>
            <RadioGroup value={selectedReason} onValueChange={setSelectedReason}>
              <div className="space-y-2">
                {reportReasons.map((reason) => (
                  <div key={reason.value} className="flex items-start space-x-3 space-x-reverse">
                    <RadioGroupItem value={reason.value} id={reason.value} />
                    <Label
                      htmlFor={reason.value}
                      className="cursor-pointer text-sm leading-relaxed"
                    >
                      <span className="font-medium text-gray-900">{reason.label}</span>
                      <br />
                      <span className="text-xs text-gray-500">
                        {reason.labelPashto} • {reason.labelDari}
                      </span>
                    </Label>
                  </div>
                ))}
              </div>
            </RadioGroup>
          </div>

          {/* Description */}
          <div className="space-y-2">
            <Label htmlFor="description">
              Additional Details / نور تفصیلات
            </Label>
            <Textarea
              id="description"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Please provide more details about this issue...&#10;د دې مسلې په اړه نور تفصیلات ولیکئ..."
              className="min-h-[120px]"
              disabled={isSubmitting}
            />
            <p className="text-xs text-gray-500">
              {description.length}/500 characters
            </p>
          </div>

          {/* Admin Contact Info */}
          <div className="p-3 bg-blue-50 border border-blue-200 rounded-lg">
            <p className="text-xs text-blue-900">
              <strong>📧 Admin:</strong> ibrahimkhaksar.it@gmail.com
              <br />
              <strong>📱 Phone:</strong> +93783040441
            </p>
          </div>

          {/* Action Buttons */}
          <div className="flex gap-3">
            <Button
              type="button"
              variant="outline"
              className="flex-1"
              onClick={() => setOpen(false)}
              disabled={isSubmitting}
            >
              Cancel / لغوه
            </Button>
            <Button
              type="submit"
              className="flex-1 bg-gradient-to-r from-red-500 to-orange-600 hover:from-red-600 hover:to-orange-700"
              disabled={isSubmitting}
            >
              {isSubmitting ? (
                <>Submitting... / سپارل کیږي...</>
              ) : (
                <>
                  <Flag className="w-4 h-4 mr-2" />
                  Submit Report / راپور وسپارئ
                </>
              )}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
