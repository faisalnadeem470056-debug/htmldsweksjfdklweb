import { useState } from "react";
import { Card } from "./ui/card";
import { Heart, Brain, Stethoscope, Users, Sparkles, Eye, Ear, Bone, Activity, AlertCircle, Baby } from "lucide-react";
import { CategoryDetailModal } from "./CategoryDetailModal";
import { useLanguage } from "../contexts/LanguageContext";

const categories = [
  {
    id: "cardiology",
    name: "Cardiology",
    label: "Cardiology",
    labelPashto: "زړه",
    labelDari: "قلب",
    namePashto: "زړه",
    nameDari: "قلب",
    icon: Heart,
    gradient: "from-red-500 to-pink-600",
    bgColor: "from-red-50 to-pink-50",
    textColor: "text-red-600",
    doctors: [
      { name: "Dr. احمد رحیمي", specialty: "Cardiologist", experience: "15 years", rating: 4.9, patients: "1000+" },
      { name: "Dr. Sarah Johnson", specialty: "Heart Surgeon", experience: "20 years", rating: 4.8, patients: "850+" },
      { name: "Dr. فریده کریمي", specialty: "Cardiac Specialist", experience: "12 years", rating: 4.7, patients: "720+" },
    ],
    books: [
      { 
        title: "Heart Health Guide", 
        titlePs: "د زړه روغتیا لارښود", 
        titleFa: "راهنمای سلامت قلب", 
        author: "Dr. Michael Davis", 
        pages: 320, 
        language: "Multi", 
        rating: 4.8,
        downloads: 15420,
        views: 45320,
        summary: "Complete guide to maintaining a healthy heart through diet, exercise, and lifestyle changes. Learn about common heart conditions and prevention strategies.",
        summaryPs: "د روغ زړه د ساتلو بشپړ لارښود د خوړو، ورزش، او ژوند طرز له لارې. د زړه د عامو ناروغیو او د مخنیوي ستراتیژیو په اړه زده کړئ.",
        summaryFa: "راهنمای کامل برای حفظ قلب سالم از طریق رژیم غذایی، ورزش و تغییرات سبک زندگی. در مورد بیماری‌های رایج قلبی و استراتژی‌های پیشگیری بیاموزید."
      },
      { 
        title: "Cardiac Care Manual", 
        titlePs: "د زړه پاملرنې لارښود", 
        titleFa: "کتابچه مراقبت قلبی", 
        author: "Dr. Sarah Johnson", 
        pages: 285, 
        language: "Multi", 
        rating: 4.7,
        downloads: 12850,
        views: 38920,
        summary: "Comprehensive manual for cardiac care including emergency response, medications, and post-surgery recovery guidelines.",
        summaryPs: "د زړه د پاملرنې بشپړ لارښود د بیړني ځواب، درملو، او د جراحۍ وروسته روغیدو لارښودونو په شمول.",
        summaryFa: "کتابچه جامع مراقبت قلبی شامل پاسخ اضطراری، داروها و دستورالعمل‌های بهبودی پس از جراحی."
      },
      { 
        title: "Prevent Heart Disease", 
        titlePs: "د زړه ناروغۍ مخنیوی", 
        titleFa: "پیشگیری از بیماری قلبی", 
        author: "Dr. احمد رحیمي", 
        pages: 240, 
        language: "Multi", 
        rating: 4.9,
        downloads: 18920,
        views: 52100,
        summary: "Evidence-based strategies to prevent heart disease through nutrition, stress management, and regular check-ups.",
        summaryPs: "د زړه د ناروغۍ د مخنیوي لپاره د ثبوت پر بنسټ ستراتیژۍ د تغذیې، فشار اداره کولو، او منظمو معاینو له لارې.",
        summaryFa: "استراتژی‌های مبتنی بر شواهد برای پیشگیری از بیماری قلبی از طریق تغذیه، مدیریت استرس و معاینات منظم."
      },
      { 
        title: "Cardiology Essentials", 
        titlePs: "د زړه اړین معلومات", 
        titleFa: "اصول قلب و عروق", 
        author: "Dr. Emily Chen", 
        pages: 395, 
        language: "Multi", 
        rating: 4.6,
        downloads: 10250,
        views: 31400,
        summary: "Essential cardiology concepts for medical students and healthcare professionals. Covers anatomy, physiology, and common cardiovascular conditions.",
        summaryPs: "د طبي زده کوونکو او روغتیا پاملرنې مسلکیانو لپاره د زړه اړین مفکورې. اناتومي، فزیولوژي، او عام زړه ناروغۍ په پام کې نیسي.",
        summaryFa: "مفاهیم اساسی قلب و عروق برای دانشجویان پزشکی و متخصصان بهداشت. شامل آناتومی، فیزیولوژی و شرایط رایج قلبی عروقی."
      },
      { 
        title: "Heart Attack Prevention", 
        titlePs: "د زړه حملې مخنیوی", 
        titleFa: "پیشگیری از سکته قلبی", 
        author: "Dr. فریده نوري", 
        pages: 210, 
        language: "Multi", 
        rating: 4.8,
        downloads: 16780,
        views: 48650,
        summary: "Learn to recognize early warning signs of heart attack and implement preventive measures to protect your heart health.",
        summaryPs: "د زړه حملې لومړني خبرداری نښې وپیژنئ او د خپل زړه روغتیا ساتلو لپاره مخنیوي اقدامات پلي کړئ.",
        summaryFa: "نشانه‌های هشدار اولیه سکته قلبی را بشناسید و اقدامات پیشگیرانه برای محافظت از سلامت قلب خود اجرا کنید."
      },
    ]
  },
  {
    id: "neurology",
    name: "Neurology",
    label: "Neurology",
    labelPashto: "اعصاب",
    labelDari: "اعصاب",
    namePashto: "اعصاب",
    nameDari: "اعصاب",
    icon: Brain,
    gradient: "from-purple-500 to-indigo-600",
    bgColor: "from-purple-50 to-indigo-50",
    textColor: "text-purple-600",
    doctors: [
      { name: "Dr. فاطمه رحیمي", specialty: "Neurologist", experience: "16 years", rating: 4.8, patients: "700+" },
      { name: "Dr. Hassan Khan", specialty: "Brain Surgeon", experience: "22 years", rating: 4.9, patients: "850+" },
      { name: "Dr. زینب احمدي", specialty: "Neuro Specialist", experience: "14 years", rating: 4.7, patients: "600+" },
    ],
    books: [
      { 
        title: "Brain Health Guide", 
        titlePs: "د دماغ روغتیا لارښود", 
        titleFa: "راهنمای سلامت مغز", 
        author: "Dr. James Wilson", 
        pages: 350, 
        language: "Multi", 
        rating: 4.9,
        downloads: 14200,
        views: 42800,
        summary: "Comprehensive guide to brain health covering cognitive function, memory improvement, and neurological disease prevention.",
        summaryPs: "د دماغ روغتیا بشپړ لارښود چې د ادراکي فعالیت، حافظې ښه والي، او د اعصابي ناروغیو مخنیوی په پام کې نیسي.",
        summaryFa: "راهنمای جامع سلامت مغز شامل عملکرد شناختی، بهبود حافظه و پیشگیری از بیماری‌های عصبی."
      },
      { 
        title: "Neurology Basics", 
        titlePs: "د اعصابو بنیادی معلومات", 
        titleFa: "مبانی عصب‌شناسی", 
        author: "Dr. رحمان احمدي", 
        pages: 290, 
        language: "Multi", 
        rating: 4.7,
        downloads: 11850,
        views: 36200,
        summary: "Foundational neurology concepts for understanding brain structure, nervous system function, and common neurological disorders.",
        summaryPs: "د دماغ جوړښت، عصبي سیسټم فعالیت، او عام اعصابي اختلالاتو پوهیدو لپاره د اعصابو بنیادي مفکورې.",
        summaryFa: "مفاهیم پایه عصب‌شناسی برای درک ساختار مغز، عملکرد سیستم عصبی و اختلالات عصبی رایج."
      },
      { 
        title: "Memory & Brain", 
        titlePs: "حافظه او دماغ", 
        titleFa: "حافظه و مغز", 
        author: "Dr. Lisa Anderson", 
        pages: 265, 
        language: "Multi", 
        rating: 4.8,
        downloads: 13420,
        views: 39800,
        summary: "Explore how memory works, techniques to improve recall, and methods to protect cognitive function as you age.",
        summaryPs: "معلومه کړئ چې حافظه څنګه کار کوي، د یادولو ښه والي تخنیکونه، او د عمر سره د ادراکي فعالیت ساتلو میتودونه.",
        summaryFa: "کشف کنید که حافظه چگونه کار می‌کند، تکنیک‌های بهبود یادآوری و روش‌های محافظت از عملکرد شناختی با افزایش سن."
      },
      { 
        title: "Stroke Prevention", 
        titlePs: "د فالج مخنیوی", 
        titleFa: "پیشگیری از سکته مغزی", 
        author: "Dr. محمد کریمي", 
        pages: 310, 
        language: "Multi", 
        rating: 4.6,
        downloads: 10980,
        views: 33500,
        summary: "Learn risk factors, warning signs, and evidence-based strategies to prevent stroke and protect brain health.",
        summaryPs: "د خطر فکتورونه، خبرداری نښې، او د فالج د مخنیوي او د دماغ روغتیا ساتلو لپاره د ثبوت پر بنسټ ستراتیژۍ زده کړئ.",
        summaryFa: "عوامل خطر، علائم هشدار دهنده و استراتژی‌های مبتنی بر شواهد برای پیشگیری از سکته مغزی و محافظت از سلامت مغز را بیاموزید."
      },
      { 
        title: "Headache Solutions", 
        titlePs: "د سر درد حلونه", 
        titleFa: "راه‌حل‌های سردرد", 
        author: "Dr. زهره نوري", 
        pages: 195, 
        language: "Multi", 
        rating: 4.7,
        downloads: 15600,
        views: 46200,
        summary: "Identify headache types, triggers, and effective treatment options including natural remedies and medical interventions.",
        summaryPs: "د سر درد ډولونه، تحریکونه، او مؤثره درملنې انتخابونه پیژنئ د طبیعي درملو او طبي مداخلو په شمول.",
        summaryFa: "انواع سردرد، محرک‌ها و گزینه‌های درمانی مؤثر شامل درمان‌های طبیعی و مداخلات پزشکی را شناسایی کنید."
      },
    ]
  },
  {
    id: "pediatrics",
    name: "Pediatrics",
    label: "Pediatrics",
    labelPashto: "ماشومان",
    labelDari: "اطفال",
    namePashto: "ماشومان",
    nameDari: "اطفال",
    icon: Baby,
    gradient: "from-emerald-500 to-teal-600",
    bgColor: "from-emerald-50 to-teal-50",
    textColor: "text-emerald-600",
    doctors: [
      { name: "Dr. سمیرا احمدي", specialty: "Child Specialist", experience: "14 years", rating: 4.9, patients: "1200+" },
      { name: "Dr. Ahmad Rahimi", specialty: "Pediatrician", experience: "16 years", rating: 4.8, patients: "980+" },
      { name: "Dr. زهره نوري", specialty: "Baby Care Expert", experience: "11 years", rating: 4.8, patients: "850+" },
    ],
    books: [
      { 
        title: "Child Health Guide", 
        titlePs: "د ماشوم روغتیا لارښود", 
        titleFa: "راهنمای سلامت کودک", 
        author: "Dr. Amanda White", 
        pages: 360, 
        language: "Multi", 
        rating: 4.9,
        downloads: 18500,
        views: 52000,
        summary: "Complete guide to child health from birth to adolescence, covering growth milestones, common illnesses, and development.",
        summaryPs: "د زیږون څخه تر لویوالي پورې د ماشوم روغتیا بشپړ لارښود، د ودې نښلونه، عامې ناروغۍ، او پراختیا په پام کې نیسي.",
        summaryFa: "راهنمای کامل سلامت کودک از تولد تا نوجوانی، شامل مراحل رشد، بیماری‌های رایج و توسعه."
      },
      { 
        title: "Baby Care Manual", 
        titlePs: "د ماشوم پاملرنې لارښود", 
        titleFa: "کتابچه مراقبت از نوزاد", 
        author: "Dr. نرګس احمدي", 
        pages: 325, 
        language: "Multi", 
        rating: 4.8,
        downloads: 16800,
        views: 48300,
        summary: "Essential baby care guide for new parents covering feeding, sleep, hygiene, and early development stages.",
        summaryPs: "د نویو مور او پلرونو لپاره د ماشوم د پاملرنې اړین لارښود چې خواړه، خوب، صفايي، او لومړني پراختیا مراحل په پام کې نیسي.",
        summaryFa: "راهنمای ضروری مراقبت از نوزاد برای والدین جدید شامل تغذیه، خواب، بهداشت و مراحل اولیه رشد."
      },
      { 
        title: "Vaccination Guide", 
        titlePs: "د واکسین لارښود", 
        titleFa: "راهنمای واکسیناسیون", 
        author: "Dr. Benjamin Clark", 
        pages: 260, 
        language: "Multi", 
        rating: 4.7,
        downloads: 14200,
        views: 41500,
        summary: "Comprehensive vaccination schedule and information about immunizations to protect children from preventable diseases.",
        summaryPs: "د واکسین بشپړ مهال ویش او د مصونیت په اړه معلومات چې ماشومان د مخنیوي وړ ناروغیو څخه خوندي کړي.",
        summaryFa: "برنامه جامع واکسیناسیون و اطلاعات در مورد ایمن‌سازی برای محافظت از کودکان در برابر بیماری‌های قابل پیشگیری."
      },
      { 
        title: "Child Nutrition", 
        titlePs: "د ماشوم تغذیه", 
        titleFa: "تغذیه کودک", 
        author: "Dr. لیلا رحیمي", 
        pages: 290, 
        language: "Multi", 
        rating: 4.8,
        downloads: 15900,
        views: 44700,
        summary: "Essential nutrition guide for children including healthy meal plans, dietary requirements, and feeding strategies.",
        summaryPs: "د ماشومانو لپاره د تغذیې اړین لارښود چې روغ خواړه پلانونه، غذایي اړتیاوې، او د خواړه کولو ستراتیژۍ په پام کې نیسي.",
        summaryFa: "راهنمای تغذیه ضروری برای کودکان شامل برنامه‌های غذایی سالم، نیازهای رژیمی و استراتژی‌های تغذیه."
      },
      { 
        title: "Common Child Diseases", 
        titlePs: "د ماشومانو عامې ناروغۍ", 
        titleFa: "بیماری‌های شایع کودکان", 
        author: "Dr. عارف نوري", 
        pages: 310, 
        language: "Multi", 
        rating: 4.6,
        downloads: 13600,
        views: 39800,
        summary: "Guide to recognizing, treating, and preventing common childhood illnesses and when to seek medical care.",
        summaryPs: "د ماشومانو عامو ناروغیو پیژندلو، درملنې، او مخنیوي لارښود او دا چې کله طبي پاملرنې ته اړتیا ده.",
        summaryFa: "راهنمای شناخت، درمان و پیشگیری از بیماری‌های رایج کودکان و زمان مراجعه به مراقبت پزشکی."
      },
    ]
  },
  {
    id: "gynecology",
    name: "Gynecology",
    label: "Gynecology",
    labelPashto: "ښځینه",
    labelDari: "زنان",
    namePashto: "ښځینه",
    nameDari: "زنان",
    icon: Heart,
    gradient: "from-fuchsia-500 to-pink-600",
    bgColor: "from-fuchsia-50 to-pink-50",
    textColor: "text-fuchsia-600",
    doctors: [
      { name: "Dr. فریده کریمي", specialty: "Gynecologist", experience: "17 years", rating: 4.9, patients: "880+" },
      { name: "Dr. Nargis Ahmadi", specialty: "Pregnancy Specialist", experience: "15 years", rating: 4.8, patients: "750+" },
      { name: "Dr. شکریه نوري", specialty: "Women Health", experience: "13 years", rating: 4.8, patients: "690+" },
    ],
    books: [
      { title: "Women's Health Guide", titlePs: "د ښځو روغتیا لارښود", titleFa: "راهنمای سلامت زنان", author: "Dr. Rachel Martinez", pages: 380, language: "Multi", rating: 4.9, downloads: 17200, views: 51000, summary: "Comprehensive women's health guide.", summaryPs: "د ښځو د روغتیا بشپړ لارښود.", summaryFa: "راهنمای جامع سلامت زنان." },
      { title: "Pregnancy Manual", titlePs: "د حمل لارښود", titleFa: "کتابچه بارداری", author: "Dr. هدیه احمدي", pages: 340, language: "Multi", rating: 4.8, downloads: 15800, views: 47500, summary: "Complete pregnancy guide.", summaryPs: "د حمل بشپړ لارښود.", summaryFa: "راهنمای کامل بارداری." },
      { title: "Maternal Care", titlePs: "د مور پاملرنه", titleFa: "مراقبت مادری", author: "Dr. Susan Taylor", pages: 295, language: "Multi", rating: 4.7, downloads: 14200, views: 42800, summary: "Maternal healthcare essentials.", summaryPs: "د مور روغتیا پاملرنې اړینې.", summaryFa: "ملزومات مراقبت مادری." },
      { title: "PCOS Management", titlePs: "د PCOS اداره", titleFa: "مدیریت PCOS", author: "Dr. زینب کریمي", pages: 270, language: "Multi", rating: 4.8, downloads: 13500, views: 40200, summary: "PCOS management guide.", summaryPs: "د PCOS د اداره لارښود.", summaryFa: "راهنمای مدیریت PCOS." },
      { title: "Fertility Guide", titlePs: "د زیږون وړتیا لارښود", titleFa: "راهنمای باروری", author: "Dr. مریم نوري", pages: 315, language: "Multi", rating: 4.6, downloads: 12800, views: 38500, summary: "Fertility and conception guide.", summaryPs: "د زیږون او حمل لارښود.", summaryFa: "راهنمای باروری و بارداری." },
    ]
  },
  {
    id: "dentistry",
    name: "Dentistry",
    label: "Dentistry",
    labelPashto: "غاښونه",
    labelDari: "دندان",
    namePashto: "غاښونه",
    nameDari: "دندان",
    icon: Sparkles,
    gradient: "from-cyan-500 to-blue-600",
    bgColor: "from-cyan-50 to-blue-50",
    textColor: "text-cyan-600",
    doctors: [
      { name: "Dr. حامد احمدي", specialty: "Dentist", experience: "14 years", rating: 4.8, patients: "920+" },
      { name: "Dr. Laila Karimi", specialty: "Orthodontist", experience: "12 years", rating: 4.7, patients: "650+" },
      { name: "Dr. کریم نوري", specialty: "Dental Surgeon", experience: "16 years", rating: 4.9, patients: "780+" },
    ],
    books: [
      { title: "Dental Care Guide", titlePs: "د غاښونو پاملرنې لارښود", titleFa: "راهنمای مراقبت دندانی", author: "Dr. David Johnson", pages: 300, language: "Multi", rating: 4.8, downloads: 16500, views: 49200, summary: "Complete dental care guide.", summaryPs: "د غاښونو پاملرنې بشپړ لارښود.", summaryFa: "راهنمای کامل مراقبت دندانی." },
      { title: "Oral Hygiene Manual", titlePs: "د خولې پاکوالی لارښود", titleFa: "کتابچه بهداشت دهان", author: "Dr. ثریا احمدي", pages: 245, language: "Multi", rating: 4.7, downloads: 14800, views: 44300, summary: "Oral hygiene essentials.", summaryPs: "د خولې پاکوالي اړینې.", summaryFa: "ملزومات بهداشت دهان." },
      { title: "Teeth Whitening", titlePs: "د غاښونو سپین کول", titleFa: "سفید کردن دندان", author: "Dr. Michelle Wong", pages: 220, language: "Multi", rating: 4.9, downloads: 18200, views: 54100, summary: "Teeth whitening guide.", summaryPs: "د غاښونو سپینولو لارښود.", summaryFa: "راهنمای سفید کردن دندان." },
      { title: "Orthodontics Guide", titlePs: "د غاښونو سم کولو لارښود", titleFa: "راهنمای ارتودنسی", author: "Dr. فرید کریمي", pages: 285, language: "Multi", rating: 4.6, downloads: 11200, views: 33500, summary: "Orthodontics essentials.", summaryPs: "د غاښونو سم کولو اړینې.", summaryFa: "ملزومات ارتودنسی." },
      { title: "Gum Disease Prevention", titlePs: "د مسوڼو ناروغۍ مخنیوی", titleFa: "پیشگیری از بیماری لثه", author: "Dr. سارا نوري", pages: 265, language: "Multi", rating: 4.8, downloads: 13800, views: 41200, summary: "Gum disease prevention guide.", summaryPs: "د مسوڼو ناروغۍ د مخنیوي لارښود.", summaryFa: "راهنمای پیشگیری از بیماری لثه." },
    ]
  },
  {
    id: "ophthalmology",
    name: "Ophthalmology",
    label: "Ophthalmology",
    labelPashto: "سترګې",
    labelDari: "چشم",
    namePashto: "سترګې",
    nameDari: "چشم",
    icon: Eye,
    gradient: "from-blue-500 to-indigo-600",
    bgColor: "from-blue-50 to-indigo-50",
    textColor: "text-blue-600",
    doctors: [
      { name: "Dr. رحمان احمدي", specialty: "Eye Specialist", experience: "18 years", rating: 4.9, patients: "850+" },
      { name: "Dr. Jennifer Lee", specialty: "Ophthalmologist", experience: "15 years", rating: 4.8, patients: "720+" },
      { name: "Dr. نجیب کریمي", specialty: "Eye Surgeon", experience: "20 years", rating: 4.9, patients: "960+" },
    ],
    books: [
      { title: "Eye Health Guide", titlePs: "د سترګو روغتیا لارښود", titleFa: "راهنمای سلامت چشم", author: "Dr. Thomas Brown", pages: 330, language: "Multi", rating: 4.9, downloads: 15600, views: 46800, summary: "Complete eye health guide.", summaryPs: "د سترګو روغتیا بشپړ لارښود.", summaryFa: "راهنمای کامل سلامت چشم." },
      { title: "Vision Care Manual", titlePs: "د لید پاملرنې لارښود", titleFa: "کتابچه مراقبت بینایی", author: "Dr. فاطمه نوري", pages: 280, language: "Multi", rating: 4.8, downloads: 14200, views: 42500, summary: "Vision care essentials.", summaryPs: "د لید پاملرنې اړینې.", summaryFa: "ملزومات مراقبت بینایی." },
      { title: "Eye Diseases", titlePs: "د سترګو ناروغۍ", titleFa: "بیماری‌های چشم", author: "Dr. Richard White", pages: 310, language: "Multi", rating: 4.7, downloads: 13400, views: 40100, summary: "Common eye diseases guide.", summaryPs: "د سترګو عامې ناروغۍ لارښود.", summaryFa: "راهنمای بیماری‌های رایج چشم." },
      { title: "Contact Lens Guide", titlePs: "د کانتکټ لینز لارښود", titleFa: "راهنمای لنز تماسی", author: "Dr. لیلا احمدي", pages: 240, language: "Multi", rating: 4.8, downloads: 16800, views: 50200, summary: "Contact lens care guide.", summaryPs: "د کانتکټ لینز پاملرنې لارښود.", summaryFa: "راهنمای مراقبت از لنز تماسی." },
      { title: "Cataract Surgery", titlePs: "د موتیا جراحي", titleFa: "جراحی آب مروارید", author: "Dr. کریم کریمي", pages: 290, language: "Multi", rating: 4.6, downloads: 11900, views: 35700, summary: "Cataract surgery guide.", summaryPs: "د موتیا جراحۍ لارښود.", summaryFa: "راهنمای جراحی آب مروارید." },
    ]
  },
  {
    id: "dermatology",
    name: "Dermatology",
    label: "Dermatology",
    labelPashto: "پوستکی",
    labelDari: "پوست",
    namePashto: "پوستکی",
    nameDari: "پوست",
    icon: Sparkles,
    gradient: "from-pink-500 to-rose-600",
    bgColor: "from-pink-50 to-rose-50",
    textColor: "text-pink-600",
    doctors: [
      { name: "Dr. شکریه احمدي", specialty: "Dermatologist", experience: "13 years", rating: 4.8, patients: "680+" },
      { name: "Dr. Michael Chen", specialty: "Skin Specialist", experience: "16 years", rating: 4.9, patients: "790+" },
      { name: "Dr. مریم نوري", specialty: "Cosmetic Derm", experience: "11 years", rating: 4.7, patients: "550+" },
    ],
    books: [
      { title: "Skin Care Guide", titlePs: "د پوستکي پاملرنې لارښود", titleFa: "راهنمای مراقبت پوست", author: "Dr. Emma Wilson", pages: 340, language: "Multi", rating: 4.9, downloads: 19200, views: 57500, summary: "Complete skin care guide.", summaryPs: "د پوستکي پاملرنې بشپړ لارښود.", summaryFa: "راهنمای کامل مراقبت پوست." },
      { title: "Acne Treatment", titlePs: "د ګوزڼو درملنه", titleFa: "درمان جوش", author: "Dr. احمد کریمي", pages: 260, language: "Multi", rating: 4.8, downloads: 17500, views: 52300, summary: "Acne treatment guide.", summaryPs: "د ګوزڼو درملنې لارښود.", summaryFa: "راهنمای درمان جوش." },
      { title: "Skin Diseases", titlePs: "د پوستکي ناروغۍ", titleFa: "بیماری‌های پوست", author: "Dr. Lisa Martin", pages: 315, language: "Multi", rating: 4.7, downloads: 15800, views: 47300, summary: "Common skin diseases.", summaryPs: "د پوستکي عامې ناروغۍ.", summaryFa: "بیماری‌های رایج پوست." },
      { title: "Eczema Solutions", titlePs: "د اکزیما حلونه", titleFa: "راه‌حل‌های اگزما", author: "Dr. حامد نوري", pages: 220, language: "Multi", rating: 4.6, downloads: 13200, views: 39600, summary: "Eczema treatment solutions.", summaryPs: "د اکزیما درملنې حلونه.", summaryFa: "راه‌حل‌های درمان اگزما." },
      { title: "Beauty & Skin Health", titlePs: "ښکلا او د پوست روغتیا", titleFa: "زیبایی و سلامت پوست", author: "Dr. شکریه کریمي", pages: 295, language: "Multi", rating: 4.8, downloads: 20500, views: 61400, summary: "Beauty and skin health guide.", summaryPs: "د ښکلا او پوستکي روغتیا لارښود.", summaryFa: "راهنمای زیبایی و سلامت پوست." },
    ]
  },
  {
    id: "orthopedics",
    name: "Orthopedics",
    label: "Orthopedics",
    labelPashto: "هډوکي",
    labelDari: "استخوان",
    namePashto: "هډوکي",
    nameDari: "استخوان",
    icon: Bone,
    gradient: "from-gray-500 to-slate-600",
    bgColor: "from-gray-50 to-slate-50",
    textColor: "text-gray-600",
    doctors: [
      { name: "Dr. عبدالله احمدي", specialty: "Orthopedic Surgeon", experience: "19 years", rating: 4.9, patients: "890+" },
      { name: "Dr. Rebecca Smith", specialty: "Bone Specialist", experience: "17 years", rating: 4.8, patients: "760+" },
      { name: "Dr. حسن کریمي", specialty: "Sports Medicine", experience: "14 years", rating: 4.7, patients: "650+" },
    ],
    books: [
      { title: "Bone Health Guide", titlePs: "د هډوکو روغتیا لارښود", titleFa: "راهنمای سلامت استخوان", author: "Dr. Kevin Brown", pages: 350, language: "Multi", rating: 4.8, downloads: 14800, views: 44300, summary: "Complete bone health guide.", summaryPs: "د هډوکو روغتیا بشپړ لارښود.", summaryFa: "راهنمای کامل سلامت استخوان." },
      { title: "Joint Care Manual", titlePs: "د بندونو پاملرنې لارښود", titleFa: "کتابچه مراقبت مفاصل", author: "Dr. ثریا نوري", pages: 310, language: "Multi", rating: 4.7, downloads: 13200, views: 39500, summary: "Joint care essentials.", summaryPs: "د بندونو پاملرنې اړینې.", summaryFa: "ملزومات مراقبت مفاصل." },
      { title: "Fracture Treatment", titlePs: "د ماتېدو درملنه", titleFa: "درمان شکستگی", author: "Dr. William Davis", pages: 285, language: "Multi", rating: 4.9, downloads: 15600, views: 46700, summary: "Fracture treatment guide.", summaryPs: "د ماتېدو درملنې لارښود.", summaryFa: "راهنمای درمان شکستگی." },
      { title: "Sports Injuries", titlePs: "د سپورت ټپونه", titleFa: "آسیب‌های ورزشی", author: "Dr. زهره احمدي", pages: 270, language: "Multi", rating: 4.6, downloads: 12400, views: 37100, summary: "Sports injuries guide.", summaryPs: "د سپورت ټپونو لارښود.", summaryFa: "راهنمای آسیب‌های ورزشی." },
      { title: "Arthritis Management", titlePs: "د بند درد اداره", titleFa: "مدیریت آرتریت", author: "Dr. احمد رحیمي", pages: 305, language: "Multi", rating: 4.8, downloads: 16200, views: 48500, summary: "Arthritis management guide.", summaryPs: "د بند درد د اداره لارښود.", summaryFa: "راهنمای مدیریت آرتریت." },
    ]
  },
  {
    id: "general",
    name: "General Medicine",
    label: "General Medicine",
    labelPashto: "عمومي",
    labelDari: "عمومی",
    namePashto: "عمومي",
    nameDari: "عمومی",
    icon: Stethoscope,
    gradient: "from-emerald-500 to-teal-600",
    bgColor: "from-emerald-50 to-teal-50",
    textColor: "text-emerald-600",
    doctors: [
      { name: "Dr. جمیل نوري", specialty: "General Physician", experience: "20 years", rating: 4.9, patients: "1500+" },
      { name: "Dr. Shabana Karimi", specialty: "Family Doctor", experience: "18 years", rating: 4.8, patients: "1200+" },
      { name: "Dr. رحیم احمدي", specialty: "GP Specialist", experience: "22 years", rating: 4.9, patients: "1600+" },
    ],
    books: [
      { title: "Family Health Guide", titlePs: "د کورنۍ روغتیا لارښود", titleFa: "راهنمای سلامت خانواده", author: "Dr. James Anderson", pages: 420, language: "Multi", rating: 4.9, downloads: 21500, views: 64300, summary: "Complete family health guide.", summaryPs: "د کورنۍ روغتیا بشپړ لارښود.", summaryFa: "راهنمای کامل سلامت خانواده." },
      { title: "Home Remedies", titlePs: "د کور درمل", titleFa: "درمان‌های خانگی", author: "Dr. شبانه احمدي", pages: 340, language: "Multi", rating: 4.8, downloads: 19800, views: 59200, summary: "Home remedies guide.", summaryPs: "د کور درملو لارښود.", summaryFa: "راهنمای درمان‌های خانگی." },
      { title: "Preventive Medicine", titlePs: "د مخنیوي درمل", titleFa: "پزشکی پیشگیرانه", author: "Dr. Robert Brown", pages: 380, language: "Multi", rating: 4.7, downloads: 17200, views: 51500, summary: "Preventive medicine guide.", summaryPs: "د مخنیوي درملو لارښود.", summaryFa: "راهنمای پزشکی پیشگیرانه." },
      { title: "First Aid Manual", titlePs: "د لومړنیو مرستو لارښود", titleFa: "کتابچه کمک‌های اولیه", author: "Dr. زهره کریمي", pages: 295, language: "Multi", rating: 4.8, downloads: 22100, views: 66200, summary: "First aid essentials.", summaryPs: "د لومړنیو مرستو اړینې.", summaryFa: "ملزومات کمک‌های اولیه." },
      { title: "Common Diseases", titlePs: "عامې ناروغۍ", titleFa: "بیماری‌های شایع", author: "Dr. عمر نوري", pages: 360, language: "Multi", rating: 4.6, downloads: 18600, views: 55700, summary: "Common diseases guide.", summaryPs: "عامو ناروغیو لارښود.", summaryFa: "راهنمای بیماری‌های شایع." },
    ]
  },
  {
    id: "ent",
    name: "ENT",
    label: "ENT",
    labelPashto: "غوږونه",
    labelDari: "گوش حلق بینی",
    namePashto: "غوږونه",
    nameDari: "گوش حلق بینی",
    icon: Ear,
    gradient: "from-indigo-500 to-purple-600",
    bgColor: "from-indigo-50 to-purple-50",
    textColor: "text-indigo-600",
    doctors: [
      { name: "Dr. نصیر احمدي", specialty: "ENT Specialist", experience: "16 years", rating: 4.8, patients: "720+" },
      { name: "Dr. Patricia Wilson", specialty: "Ear Surgeon", experience: "14 years", rating: 4.7, patients: "580+" },
      { name: "Dr. یوسف کریمي", specialty: "Voice Specialist", experience: "12 years", rating: 4.9, patients: "640+" },
    ],
    books: [
      { title: "ENT Care Guide", titlePs: "د غوږ، ستوني، پوزې لارښود", titleFa: "راهنمای مراقبت گوش حلق بینی", author: "Dr. Christopher Lee", pages: 320, language: "Multi", rating: 4.8, downloads: 13800, views: 41300, summary: "Complete ENT care guide.", summaryPs: "بشپړ ENT پاملرنې لارښود.", summaryFa: "راهنمای کامل مراقبت ENT." },
      { title: "Hearing Health", titlePs: "د اوریدلو روغتیا", titleFa: "سلامت شنوایی", author: "Dr. فاطمه نوري", pages: 280, language: "Multi", rating: 4.7, downloads: 12400, views: 37100, summary: "Hearing health guide.", summaryPs: "د اوریدلو روغتیا لارښود.", summaryFa: "راهنمای سلامت شنوایی." },
      { title: "Throat Diseases", titlePs: "د ستوني ناروغۍ", titleFa: "بیماری‌های گلو", author: "Dr. Daniel Smith", pages: 265, language: "Multi", rating: 4.9, downloads: 14600, views: 43700, summary: "Throat diseases guide.", summaryPs: "د ستوني ناروغیو لارښود.", summaryFa: "راهنمای بیماری‌های گلو." },
      { title: "Sinus Problems", titlePs: "د سینوس ستونزې", titleFa: "مشکلات سینوس", author: "Dr. لیلا احمدي", pages: 240, language: "Multi", rating: 4.6, downloads: 11800, views: 35300, summary: "Sinus problems guide.", summaryPs: "د سینوس ستونزو لارښود.", summaryFa: "راهنمای مشکلات سینوس." },
      { title: "Voice Care Manual", titlePs: "د غږ پاملرنې لارښود", titleFa: "کتابچه مراقبت صدا", author: "Dr. عمر کریمي", pages: 255, language: "Multi", rating: 4.8, downloads: 13200, views: 39500, summary: "Voice care essentials.", summaryPs: "د غږ پاملرنې اړینې.", summaryFa: "ملزومات مراقبت صدا." },
    ]
  },
  {
    id: "emergency",
    name: "Emergency",
    label: "Emergency",
    labelPashto: "بیړني",
    labelDari: "اورژانس",
    namePashto: "بیړني",
    nameDari: "اورژانس",
    icon: AlertCircle,
    gradient: "from-red-600 to-orange-600",
    bgColor: "from-red-50 to-orange-50",
    textColor: "text-red-600",
    doctors: [
      { name: "Dr. فرید کریمي", specialty: "Emergency Medicine", experience: "19 years", rating: 4.9, patients: "24/7" },
      { name: "Dr. Nasir Ahmadi", specialty: "ER Specialist", experience: "17 years", rating: 4.8, patients: "24/7" },
      { name: "Dr. ثریا نوري", specialty: "Trauma Care", experience: "15 years", rating: 4.9, patients: "24/7" },
    ],
    books: [
      { title: "Emergency Care Guide", titlePs: "د بیړني پاملرنې لارښود", titleFa: "راهنمای مراقبت اورژانسی", author: "Dr. Daniel White", pages: 385, language: "Multi", rating: 4.9, downloads: 18500, views: 55400, summary: "Emergency care essentials.", summaryPs: "د بیړني پاملرنې اړینې.", summaryFa: "ملزومات مراقبت اورژانسی." },
      { title: "Trauma Management", titlePs: "د ټپونو اداره", titleFa: "مدیریت تروما", author: "Dr. حسین احمدي", pages: 360, language: "Multi", rating: 4.8, downloads: 16200, views: 48500, summary: "Trauma management guide.", summaryPs: "د ټپونو د اداره لارښود.", summaryFa: "راهنمای مدیریت تروما." },
      { title: "Life Support Manual", titlePs: "د ژوند ملاتړ لارښود", titleFa: "کتابچه حمایت حیاتی", author: "Dr. Karen Smith", pages: 320, language: "Multi", rating: 4.7, downloads: 14800, views: 44300, summary: "Life support essentials.", summaryPs: "د ژوند ملاتړ اړینې.", summaryFa: "ملزومات حمایت حیاتی." },
      { title: "Crisis Response", titlePs: "د بحران ځواب", titleFa: "پاسخ به بحران", author: "Dr. فرزانه کریمي", pages: 295, language: "Multi", rating: 4.8, downloads: 17600, views: 52700, summary: "Crisis response guide.", summaryPs: "د بحران ځواب لارښود.", summaryFa: "راهنمای پاسخ به بحران." },
      { title: "Emergency Protocols", titlePs: "د بیړني پروتوکولونه", titleFa: "پروتکل‌های اورژانس", author: "Dr. نصیر نوري", pages: 340, language: "Multi", rating: 4.6, downloads: 15200, views: 45500, summary: "Emergency protocols guide.", summaryPs: "د بیړني پروتوکولونو لارښود.", summaryFa: "راهنمای پروتکل‌های اورژانس." },
    ]
  },
  {
    id: "psychiatry",
    name: "Mental Health",
    label: "Mental Health",
    labelPashto: "رواني",
    labelDari: "روانی",
    namePashto: "رواني",
    nameDari: "روانی",
    icon: Brain,
    gradient: "from-violet-500 to-purple-600",
    bgColor: "from-violet-50 to-purple-50",
    textColor: "text-violet-600",
    doctors: [
      { name: "Dr. سلمی کریمي", specialty: "Psychiatrist", experience: "16 years", rating: 4.9, patients: "720+" },
      { name: "Dr. Arif Rahimi", specialty: "Mental Health", experience: "14 years", rating: 4.8, patients: "650+" },
      { name: "Dr. هدیه احمدي", specialty: "Psychologist", experience: "12 years", rating: 4.7, patients: "580+" },
    ],
    books: [
      { title: "Mental Health Guide", titlePs: "د رواني روغتیا لارښود", titleFa: "راهنمای سلامت روان", author: "Dr. Patricia Wilson", pages: 350, language: "Multi", rating: 4.9, downloads: 20100, views: 60200, summary: "Mental health essentials.", summaryPs: "د رواني روغتیا اړینې.", summaryFa: "ملزومات سلامت روان." },
      { title: "Depression Treatment", titlePs: "د خپګان درملنه", titleFa: "درمان افسردگی", author: "Dr. احمد رحیمي", pages: 305, language: "Multi", rating: 4.8, downloads: 18400, views: 55100, summary: "Depression treatment guide.", summaryPs: "د خپګان درملنې لارښود.", summaryFa: "راهنمای درمان افسردگی." },
      { title: "Anxiety Solutions", titlePs: "د اضطراب حلونه", titleFa: "راه‌حل‌های اضطراب", author: "Dr. Laura Martinez", pages: 280, language: "Multi", rating: 4.7, downloads: 16800, views: 50300, summary: "Anxiety solutions guide.", summaryPs: "د اضطراب حلونو لارښود.", summaryFa: "راهنمای راه‌حل‌های اضطراب." },
      { title: "Stress Management", titlePs: "د فشار اداره", titleFa: "مدیریت استرس", author: "Dr. نبیله کریمي", pages: 265, language: "Multi", rating: 4.8, downloads: 19200, views: 57500, summary: "Stress management guide.", summaryPs: "د فشار د اداره لارښود.", summaryFa: "راهنمای مدیریت استرس." },
      { title: "Psychology Basics", titlePs: "د ارواپوهنې بنیادونه", titleFa: "مبانی روانشناسی", author: "Dr. یوسف احمدي", pages: 330, language: "Multi", rating: 4.6, downloads: 15400, views: 46100, summary: "Psychology basics guide.", summaryPs: "د ارواپوهنې بنیادونو لارښود.", summaryFa: "راهنمای مبانی روانشناسی." },
    ]
  },
];

export function Categories() {
  const { language } = useLanguage();
  const [selectedCategory, setSelectedCategory] = useState<any>(null);
  const [isCategoryModalOpen, setIsCategoryModalOpen] = useState(false);

  const handleCategoryClick = (category: any) => {
    setSelectedCategory(category);
    setIsCategoryModalOpen(true);
  };

  return (
    <section id="categories" className="py-16 md:py-24 bg-gradient-to-b from-white via-gray-50 to-white relative overflow-hidden">
      {/* Background Decoration */}
      <div className="absolute top-0 left-0 w-[500px] h-[500px] bg-gradient-to-br from-emerald-100/30 to-teal-100/30 rounded-full blur-3xl animate-float"></div>
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="text-center mb-12 md:mb-16 space-y-4">
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-emerald-100 to-teal-100 rounded-full">
            <Stethoscope className="w-4 h-4 text-emerald-600 animate-pulse-glow" />
            <span className="text-emerald-700 text-sm uppercase tracking-wider">
              {language === "ps" ? "روغتیا کټګورۍ" : language === "fa" ? "دسته‌بندی‌های سلامت" : "Health Categories"}
            </span>
          </div>
          <h2 className="text-4xl md:text-6xl">
            <span className="gradient-text">
              {language === "ps" ? "د تخصص له مخې ولټوئ" : language === "fa" ? "مرور بر اساس تخصص" : "Browse by Specialty"}
            </span>
          </h2>
          <p className="text-gray-600 max-w-2xl mx-auto text-lg">
            {language === "ps" 
              ? "د خپلو اړتیاوو لپاره سم روغتیا متخصص ومومئ" 
              : language === "fa"
              ? "متخصص بهداشتی مناسب برای نیازهای خود را پیدا کنید"
              : "Find the right healthcare specialist for your needs"}
          </p>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4 md:gap-6">
          {categories.map((category, index) => (
            <Card
              key={category.id}
              onClick={() => handleCategoryClick(category)}
              className={`group hover-lift border-0 shadow-lg overflow-hidden cursor-pointer bg-gradient-to-br ${category.bgColor} hover:shadow-2xl transition-all`}
              style={{ animationDelay: `${index * 50}ms` }}
            >
              <div className="p-5 text-center space-y-3">
                {/* Icon */}
                <div className="relative">
                  <div className={`absolute inset-0 bg-gradient-to-r ${category.gradient} rounded-2xl blur-lg opacity-30 group-hover:opacity-50 transition-opacity`}></div>
                  <div className={`relative w-16 h-16 mx-auto bg-gradient-to-br ${category.gradient} rounded-2xl flex items-center justify-center shadow-lg group-hover:scale-110 transition-transform`}>
                    <category.icon className="w-8 h-8 text-white" />
                  </div>
                </div>

                {/* Category Name */}
                <div>
                  <h3 className={`text-sm mb-1 ${category.textColor} group-hover:scale-105 transition-transform`}>
                    {language === "ps" ? category.namePashto : language === "fa" ? category.nameDari : category.name}
                  </h3>
                  <p className="text-xs text-gray-600">
                    {category.doctors.length}{" "}
                    {language === "ps" ? "ډاکټران" : language === "fa" ? "دکتر" : "Doctors"}
                  </p>
                </div>

                {/* Count */}
                <div className={`text-xs ${category.textColor} bg-white/80 backdrop-blur rounded-full px-3 py-1 inline-block`}>
                  {category.books.length}{" "}
                  {language === "ps" ? "کتابونه" : language === "fa" ? "کتاب" : "Books"}
                </div>
              </div>
            </Card>
          ))}
        </div>

        {/* View All Button */}
        <div className="text-center mt-10">
          <p className="text-gray-600">
            {language === "ps" 
              ? "د کټګورۍ لپاره کلیک وکړئ او بشپړ معلومات، کتابونه او ډاکټران وګورئ" 
              : language === "fa"
              ? "روی دسته‌بندی کلیک کنید تا اطلاعات کامل، کتاب‌ها و دکترها را ببینید"
              : "Click on a category to view complete information, books and doctors"}
          </p>
        </div>
      </div>

      {/* Category Detail Modal */}
      <CategoryDetailModal
        isOpen={isCategoryModalOpen}
        onClose={() => setIsCategoryModalOpen(false)}
        category={selectedCategory}
      />
    </section>
  );
}
