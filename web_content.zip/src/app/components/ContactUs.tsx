import { useState } from 'react';
import { ArrowLeft, Mail, Phone, MapPin, Send, Globe, MessageCircle } from 'lucide-react';
import { motion } from 'motion/react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Textarea } from './ui/textarea';
import { translations } from '../translations';
import { AdBanner } from './AdBanner';
import Logo from './Logo';

interface ContactUsProps {
  language: 'ps' | 'fa' | 'en';
  onBack: () => void;
}

export function ContactUs({ language, onBack }: ContactUsProps) {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    message: '',
  });
  const [submitted, setSubmitted] = useState(false);
  const t = translations[language];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Here you would normally send the form data to a backend
    setSubmitted(true);
    setTimeout(() => {
      setSubmitted(false);
      setFormData({ name: '', email: '', phone: '', message: '' });
    }, 3000);
  };

  const contactInfo = [
    {
      icon: Mail,
      title: { ps: 'بریښنالیک', fa: 'ایمیل', en: 'Email' },
      value: 'ibrahimkhaksar.it@gmail.com',
      color: 'from-blue-500 to-cyan-500',
    },
    {
      icon: Phone,
      title: { ps: 'تلیفون', fa: 'تلفون', en: 'Phone' },
      value: '+93 783 040 441',
      color: 'from-green-500 to-emerald-500',
    },
    {
      icon: Phone,
      title: { ps: 'بل شمېره', fa: 'شماره دیگر', en: 'Alternative' },
      value: '+93 779 494 512',
      color: 'from-purple-500 to-violet-500',
    },
    {
      icon: MessageCircle,
      title: { ps: 'واتساپ', fa: 'واتساپ', en: 'WhatsApp' },
      value: '+93 779 494 512',
      link: 'https://wa.me/93779494512',
      color: 'from-green-400 to-green-600',
      isWhatsApp: true,
    },
    {
      icon: MapPin,
      title: { ps: 'موقعیت', fa: 'موقعیت', en: 'Location' },
      value: { ps: 'افغانستان', fa: 'افغانستان', en: 'Afghanistan' },
      color: 'from-red-500 to-pink-500',
    },
    {
      icon: Globe,
      title: { ps: 'وب پاڼه', fa: 'وبسایت', en: 'Website' },
      value: 'www.Ibrahimkhaksar.com',
      link: 'https://www.Ibrahimkhaksar.com',
      color: 'from-indigo-500 to-blue-500',
    },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 via-teal-50 to-cyan-50 pb-28 md:pb-12">
      {/* Header */}
      <div className="sticky top-[73px] z-30 backdrop-blur-xl bg-white/70 border-b border-white/20 shadow-lg">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center gap-4">
            <Button variant="ghost" size="icon" onClick={onBack}>
              <ArrowLeft className="w-5 h-5" />
            </Button>
            <div>
              <h1 className="text-2xl bg-gradient-to-r from-green-600 to-teal-600 bg-clip-text text-transparent">
                {t.contactUs}
              </h1>
              <p className="text-sm text-gray-600">{t.getInTouch}</p>
            </div>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="container mx-auto px-4 mt-6">
        <AdBanner type="medium" className="mb-8" />

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 max-w-6xl mx-auto">
          {/* Contact Info */}
          <div className="space-y-6">
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
            >
              <h2 className="text-2xl mb-6">
                {language === 'ps' && 'د اړیکې معلومات'}
                {language === 'fa' && 'اطلاعات تماس'}
                {language === 'en' && 'Contact Information'}
              </h2>

              <div className="space-y-4">
                {contactInfo.map((info, index) => {
                  const Icon = info.icon;
                  const isClickable = 'link' in info;
                  const isWhatsApp = 'isWhatsApp' in info && info.isWhatsApp;
                  const displayValue = typeof info.value === 'string' ? info.value : info.value[language];
                  
                  return (
                    <motion.div
                      key={index}
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: index * 0.1 }}
                      className="relative group"
                    >
                      <div className={`absolute inset-0 bg-gradient-to-br ${info.color} opacity-20 rounded-2xl blur-xl group-hover:blur-2xl transition-all`} />
                      <div 
                        className={`relative bg-white/90 backdrop-blur-xl rounded-2xl p-6 border border-white/20 shadow-xl hover:shadow-2xl transition-all ${isClickable ? 'cursor-pointer' : ''}`}
                        onClick={() => isClickable && info.link && window.open(info.link, '_blank')}
                      >
                        <div className="flex items-center gap-4">
                          <div className={`w-12 h-12 bg-gradient-to-br ${info.color} rounded-xl flex items-center justify-center flex-shrink-0 ${isWhatsApp ? 'animate-pulse' : ''}`}>
                            <Icon className="w-6 h-6 text-white" />
                          </div>
                          <div className="flex-1">
                            <p className="text-sm text-gray-600 mb-1">{info.title[language]}</p>
                            <p className={`text-base ${isClickable ? 'text-green-600 hover:text-green-700 font-medium' : ''} ${isWhatsApp ? 'flex items-center gap-2' : ''}`}>
                              {displayValue}
                              {isWhatsApp && (
                                <span className="text-xs bg-green-100 text-green-700 px-2 py-1 rounded-full">
                                  {language === 'ps' ? 'پیغام ولېږئ' : language === 'fa' ? 'پیام بفرستید' : 'Chat Now'}
                                </span>
                              )}
                            </p>
                          </div>
                        </div>
                      </div>
                    </motion.div>
                  );
                })}
              </div>
            </motion.div>

            {/* Map Placeholder */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.4 }}
              className="relative group"
            >
              <div className="absolute inset-0 bg-gradient-to-br from-blue-500 to-purple-600 rounded-3xl blur-2xl opacity-30" />
              <div className="relative bg-white/90 backdrop-blur-xl rounded-3xl p-8 border border-white/20 shadow-xl h-64 flex items-center justify-center">
                <div className="text-center text-gray-600">
                  <MapPin className="w-16 h-16 mx-auto mb-4 text-gray-400" />
                  <p>
                    {language === 'ps' && 'د نقشې ځای'}
                    {language === 'fa' && 'محل نقشه'}
                    {language === 'en' && 'Map Location'}
                  </p>
                </div>
              </div>
            </motion.div>
          </div>

          {/* Contact Form */}
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            className="relative group"
          >
            <div className="absolute inset-0 bg-gradient-to-br from-green-500 to-teal-600 rounded-3xl blur-2xl opacity-30" />
            <div className="relative bg-white/90 backdrop-blur-xl rounded-3xl p-8 border border-white/20 shadow-xl">
              <h2 className="text-2xl mb-6">
                {language === 'ps' && 'پیغام راولېږئ'}
                {language === 'fa' && 'پیام ارسال کنید'}
                {language === 'en' && 'Send Message'}
              </h2>

              {submitted ? (
                <motion.div
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  className="text-center py-12"
                >
                  <div className="w-20 h-20 bg-gradient-to-br from-green-500 to-emerald-600 rounded-full flex items-center justify-center mx-auto mb-4">
                    <Send className="w-10 h-10 text-white" />
                  </div>
                  <h3 className="text-2xl mb-2 bg-gradient-to-r from-green-600 to-emerald-600 bg-clip-text text-transparent">
                    {t.messageSent}
                  </h3>
                  <p className="text-gray-600">
                    {language === 'ps' && 'موږ به ډیر ژر تاسو ته ځواب درکړو'}
                    {language === 'fa' && 'ما به خیلی زود به شما پاسخ خواهیم داد'}
                    {language === 'en' && 'We will respond to you very soon'}
                  </p>
                </motion.div>
              ) : (
                <form onSubmit={handleSubmit} className="space-y-6">
                  <div>
                    <label className="block text-sm mb-2">{t.name}</label>
                    <Input
                      type="text"
                      value={formData.name}
                      onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                      required
                      className="bg-white/80 backdrop-blur-md border-white/20"
                      dir={language === 'en' ? 'ltr' : 'rtl'}
                    />
                  </div>

                  <div>
                    <label className="block text-sm mb-2">{t.email}</label>
                    <Input
                      type="email"
                      value={formData.email}
                      onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                      required
                      className="bg-white/80 backdrop-blur-md border-white/20"
                    />
                  </div>

                  <div>
                    <label className="block text-sm mb-2">{t.phone}</label>
                    <Input
                      type="tel"
                      value={formData.phone}
                      onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                      className="bg-white/80 backdrop-blur-md border-white/20"
                    />
                  </div>

                  <div>
                    <label className="block text-sm mb-2">{t.message}</label>
                    <Textarea
                      value={formData.message}
                      onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                      required
                      className="min-h-[150px] bg-white/80 backdrop-blur-md border-white/20"
                      dir={language === 'en' ? 'ltr' : 'rtl'}
                    />
                  </div>

                  <Button
                    type="submit"
                    className="w-full bg-gradient-to-r from-green-600 to-teal-600 hover:from-green-700 hover:to-teal-700"
                  >
                    <Send className="w-4 h-4 mr-2" />
                    {t.send}
                  </Button>
                </form>
              )}
            </div>
          </motion.div>
        </div>

        <AdBanner type="large" className="mt-8" />
      </div>
    </div>
  );
}