import { useState } from 'react';
import { motion } from 'motion/react';
import { Hash, Search, Plus, Eye, Edit2, Trash2 } from 'lucide-react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { healthCategories, getPopularCategories } from '../data/healthCategories';

interface HealthCategoriesManagementProps {
  language: 'ps' | 'fa' | 'en';
}

export function HealthCategoriesManagement({ language }: HealthCategoriesManagementProps) {
  const [searchQuery, setSearchQuery] = useState('');

  const text = {
    ps: {
      categoryManagement: 'د کټګورۍ مدیریت',
      search: 'لټون...',
      addCategory: 'کټګوري اضافه',
      view: 'کتل',
      edit: 'سمون',
      delete: 'حذف',
      categories: 'کټګورۍ',
      completeHealthCategories: 'د روغتیا بشپړ کټګورۍ او خدمتونه',
      type: 'ډول',
      items: 'شمیر',
      popular: 'مشهور',
      specialties: 'تخصصونه',
      diseases: 'ناروغۍ',
      nutrition: 'خوراک',
      exercise: 'ورزش',
      summary: 'لنډیز',
      totalCategories: 'ټولې کټګورۍ',
      totalItems: 'ټول توکي',
      types: 'ډولونه'
    },
    fa: {
      categoryManagement: 'مدیریت دسته‌بندی‌ها',
      search: 'جستجو...',
      addCategory: 'افزودن دسته',
      view: 'مشاهده',
      edit: 'ویرایش',
      delete: 'حذف',
      categories: 'دسته',
      completeHealthCategories: 'دسته‌بندی‌ها و خدمات کامل سلامتی',
      type: 'نوع',
      items: 'تعداد',
      popular: 'محبوب',
      specialties: 'تخصص‌ها',
      diseases: 'بیماری‌ها',
      nutrition: 'تغذیه',
      exercise: 'ورزش',
      summary: 'خلاصه',
      totalCategories: 'کل دسته‌ها',
      totalItems: 'کل موارد',
      types: 'انواع'
    },
    en: {
      categoryManagement: 'Category Management',
      search: 'Search...',
      addCategory: 'Add Category',
      view: 'View',
      edit: 'Edit',
      delete: 'Delete',
      categories: 'Categories',
      completeHealthCategories: 'Complete health categories and services',
      type: 'Type',
      items: 'Items',
      popular: 'Popular',
      specialties: 'Specialties',
      diseases: 'Diseases',
      nutrition: 'Nutrition',
      exercise: 'Exercise',
      summary: 'Summary',
      totalCategories: 'Total Categories',
      totalItems: 'Total Items',
      types: 'Types'
    }
  };

  const t = text[language];

  const getTypeLabel = (type: string) => {
    const labels = {
      ps: {
        specialty: 'تخصص',
        disease: 'ناروغي',
        nutrition: 'خوراک',
        exercise: 'ورزش',
        emergency: 'بیړني',
        service: 'خدمت',
        'health-tip': 'مشوره',
        'mental-health': 'رواني'
      },
      fa: {
        specialty: 'تخصص',
        disease: 'بیماری',
        nutrition: 'تغذیه',
        exercise: 'ورزش',
        emergency: 'اورژانس',
        service: 'خدمت',
        'health-tip': 'توصیه',
        'mental-health': 'روانی'
      },
      en: {
        specialty: 'Specialty',
        disease: 'Disease',
        nutrition: 'Nutrition',
        exercise: 'Exercise',
        emergency: 'Emergency',
        service: 'Service',
        'health-tip': 'Health Tip',
        'mental-health': 'Mental Health'
      }
    };

    return labels[language][type as keyof typeof labels['en']] || type;
  };

  const filteredCategories = healthCategories.filter(cat => {
    const searchTerm = searchQuery.toLowerCase();
    return (
      (language === 'ps' && cat.namePs.toLowerCase().includes(searchTerm)) ||
      (language === 'fa' && cat.nameFa.toLowerCase().includes(searchTerm)) ||
      (language === 'en' && cat.nameEn.toLowerCase().includes(searchTerm)) ||
      searchQuery === ''
    );
  });

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-gradient-to-r from-teal-500 to-cyan-600 rounded-2xl p-6 text-white shadow-lg">
        <div className="flex items-center justify-between mb-2">
          <div className="flex items-center gap-3">
            <Hash className="w-8 h-8" />
            <h2 className="text-2xl font-bold">{t.categoryManagement}</h2>
          </div>
          <span className="bg-white/20 px-4 py-2 rounded-lg font-semibold">
            100 {t.categories}
          </span>
        </div>
        <p className="text-white/90">{t.completeHealthCategories}</p>
      </div>

      {/* Search & Filter */}
      <div className="bg-white rounded-2xl p-4 border border-gray-200 shadow-lg">
        <div className="flex flex-col sm:flex-row gap-3">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
            <Input
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder={t.search}
              className="pl-10"
            />
          </div>
          <Button className="bg-gradient-to-r from-teal-500 to-cyan-600">
            <Plus className="w-4 h-4 mr-2" />
            {t.addCategory}
          </Button>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        {[
          { label: t.specialties, count: healthCategories.filter(c => c.type === 'specialty').length, color: 'from-blue-500 to-cyan-600' },
          { label: t.diseases, count: healthCategories.filter(c => c.type === 'disease').length, color: 'from-red-500 to-pink-600' },
          { label: t.nutrition, count: healthCategories.filter(c => c.type === 'nutrition').length, color: 'from-green-500 to-emerald-600' },
          { label: t.exercise, count: healthCategories.filter(c => c.type === 'exercise').length, color: 'from-purple-500 to-violet-600' }
        ].map((stat, idx) => (
          <div key={idx} className="bg-white rounded-xl p-4 border border-gray-200 shadow-md">
            <div className={`w-10 h-10 rounded-lg bg-gradient-to-br ${stat.color} flex items-center justify-center mb-2`}>
              <span className="text-white text-xl font-bold">{stat.count}</span>
            </div>
            <p className="text-sm text-gray-600">{stat.label}</p>
          </div>
        ))}
      </div>

      {/* Categories Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
        {filteredCategories.map((cat) => (
          <motion.div
            key={cat.id}
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="bg-white rounded-2xl p-5 border border-gray-200 shadow-lg hover:shadow-xl transition-all relative overflow-hidden"
          >
            {/* Popular Badge */}
            {cat.popular && (
              <div className="absolute top-3 right-3">
                <span className="bg-yellow-100 text-yellow-700 text-xs px-2 py-1 rounded-full font-medium">
                  ⭐ {t.popular}
                </span>
              </div>
            )}

            {/* Icon */}
            <div className={`bg-gradient-to-br ${cat.color} p-4 rounded-xl w-16 h-16 flex items-center justify-center mb-3 text-3xl`}>
              {cat.icon}
            </div>

            {/* Content */}
            <h3 className="font-semibold mb-1 text-gray-900">
              {language === 'ps' ? cat.namePs : language === 'fa' ? cat.nameFa : cat.nameEn}
            </h3>
            <p className="text-xs text-gray-600 mb-3 line-clamp-2">
              {language === 'ps' ? cat.descriptionPs : language === 'fa' ? cat.descriptionFa : cat.descriptionEn}
            </p>

            {/* Stats */}
            <div className="flex items-center justify-between mb-3 pb-3 border-b border-gray-100">
              <span className="text-xs text-gray-500">{t.type}:</span>
              <span className={`text-xs px-2 py-0.5 rounded-full ${
                cat.type === 'specialty' ? 'bg-blue-100 text-blue-700' :
                cat.type === 'disease' ? 'bg-red-100 text-red-700' :
                cat.type === 'nutrition' ? 'bg-green-100 text-green-700' :
                cat.type === 'exercise' ? 'bg-purple-100 text-purple-700' :
                cat.type === 'emergency' ? 'bg-orange-100 text-orange-700' :
                cat.type === 'service' ? 'bg-teal-100 text-teal-700' :
                cat.type === 'health-tip' ? 'bg-cyan-100 text-cyan-700' :
                'bg-gray-100 text-gray-700'
              }`}>
                {getTypeLabel(cat.type)}
              </span>
            </div>

            <div className="flex items-center justify-between mb-3">
              <span className="text-xs text-gray-500">{t.items}:</span>
              <span className="text-lg font-bold text-gray-900">{cat.itemCount}</span>
            </div>

            {/* Actions */}
            <div className="flex gap-2">
              <Button variant="outline" size="sm" className="flex-1">
                <Eye className="w-3 h-3 mr-1" />
                {t.view}
              </Button>
              <Button variant="outline" size="sm" className="flex-1">
                <Edit2 className="w-3 h-3 mr-1" />
                {t.edit}
              </Button>
              <Button variant="outline" size="sm" className="text-red-600">
                <Trash2 className="w-3 h-3" />
              </Button>
            </div>
          </motion.div>
        ))}
      </div>

      {/* Summary */}
      <div className="bg-gradient-to-br from-gray-50 to-gray-100 rounded-2xl p-6 border border-gray-200">
        <h3 className="text-lg font-semibold mb-4">{t.summary}</h3>
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
          <div className="text-center">
            <p className="text-3xl font-bold text-gray-900">{healthCategories.length}</p>
            <p className="text-sm text-gray-600">{t.totalCategories}</p>
          </div>
          <div className="text-center">
            <p className="text-3xl font-bold text-gray-900">{getPopularCategories().length}</p>
            <p className="text-sm text-gray-600">{t.popular}</p>
          </div>
          <div className="text-center">
            <p className="text-3xl font-bold text-gray-900">
              {healthCategories.reduce((sum, cat) => sum + cat.itemCount, 0)}
            </p>
            <p className="text-sm text-gray-600">{t.totalItems}</p>
          </div>
          <div className="text-center">
            <p className="text-3xl font-bold text-gray-900">8</p>
            <p className="text-sm text-gray-600">{t.types}</p>
          </div>
        </div>
      </div>
    </div>
  );
}
