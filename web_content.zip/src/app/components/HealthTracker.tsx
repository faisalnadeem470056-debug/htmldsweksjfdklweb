import { motion } from 'motion/react';
import { Activity, Heart, Droplet, Weight, TrendingUp, TrendingDown, Plus, Calendar, BarChart3, ArrowLeft } from 'lucide-react';
import { useState } from 'react';
import { LineChart, Line, AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

interface HealthTrackerProps {
  language: 'ps' | 'fa' | 'en';
  onBack?: () => void;
}

export function HealthTracker({ language, onBack }: HealthTrackerProps) {
  const [selectedMetric, setSelectedMetric] = useState<'weight' | 'bp' | 'sugar' | 'heart'>('weight');

  const translations = {
    ps: {
      title: 'د روغتیا ټریکر',
      subtitle: 'خپل روغتیا معلومات وڅارئ',
      weight: 'وزن',
      bloodPressure: 'د وینې فشار',
      bloodSugar: 'د وینې قند',
      heartRate: 'د زړه ضربان',
      add: 'نوی ثبت',
      history: 'تاریخچه',
      today: 'نن',
      week: 'اونۍ',
      month: 'میاشت',
      kg: 'کیلوګرام',
      mmHg: 'mmHg',
      mgdL: 'mg/dL',
      bpm: 'BPM',
      normal: 'نورمال',
      high: 'لوړ',
      low: 'ټیټ',
      trend: 'رویه'
    },
    fa: {
      title: 'ردیاب سلامت',
      subtitle: 'اطلاعات سلامت خود را رصد کنید',
      weight: 'وزن',
      bloodPressure: 'فشار خون',
      bloodSugar: 'قند خون',
      heartRate: 'ضربان قلب',
      add: 'ثبت جدید',
      history: 'تاریخچه',
      today: 'امروز',
      week: 'هفته',
      month: 'ماه',
      kg: 'کیلوگرام',
      mmHg: 'mmHg',
      mgdL: 'mg/dL',
      bpm: 'BPM',
      normal: 'نرمال',
      high: 'بالا',
      low: 'پایین',
      trend: 'روند'
    },
    en: {
      title: 'Health Tracker',
      subtitle: 'Monitor your health metrics',
      weight: 'Weight',
      bloodPressure: 'Blood Pressure',
      bloodSugar: 'Blood Sugar',
      heartRate: 'Heart Rate',
      add: 'Add New',
      history: 'History',
      today: 'Today',
      week: 'Week',
      month: 'Month',
      kg: 'kg',
      mmHg: 'mmHg',
      mgdL: 'mg/dL',
      bpm: 'BPM',
      normal: 'Normal',
      high: 'High',
      low: 'Low',
      trend: 'Trend'
    }
  };

  const t = translations[language];

  const metrics = [
    {
      id: 'weight' as const,
      icon: Weight,
      label: t.weight,
      value: '72.5',
      unit: t.kg,
      change: -2.3,
      status: 'normal',
      color: 'from-blue-500 to-cyan-600',
      bgColor: 'bg-blue-50',
      borderColor: 'border-blue-200'
    },
    {
      id: 'bp' as const,
      icon: Activity,
      label: t.bloodPressure,
      value: '120/80',
      unit: t.mmHg,
      change: 0,
      status: 'normal',
      color: 'from-green-500 to-emerald-600',
      bgColor: 'bg-green-50',
      borderColor: 'border-green-200'
    },
    {
      id: 'sugar' as const,
      icon: Droplet,
      label: t.bloodSugar,
      value: '95',
      unit: t.mgdL,
      change: 5,
      status: 'normal',
      color: 'from-purple-500 to-violet-600',
      bgColor: 'bg-purple-50',
      borderColor: 'border-purple-200'
    },
    {
      id: 'heart' as const,
      icon: Heart,
      label: t.heartRate,
      value: '72',
      unit: t.bpm,
      change: -3,
      status: 'normal',
      color: 'from-red-500 to-rose-600',
      bgColor: 'bg-red-50',
      borderColor: 'border-red-200'
    }
  ];

  // Sample data for charts
  const weightData = [
    { date: 'Mon', value: 74.8 },
    { date: 'Tue', value: 74.2 },
    { date: 'Wed', value: 73.8 },
    { date: 'Thu', value: 73.3 },
    { date: 'Fri', value: 72.9 },
    { date: 'Sat', value: 72.7 },
    { date: 'Sun', value: 72.5 }
  ];

  const bpData = [
    { date: 'Mon', systolic: 125, diastolic: 82 },
    { date: 'Tue', systolic: 122, diastolic: 81 },
    { date: 'Wed', systolic: 121, diastolic: 80 },
    { date: 'Thu', systolic: 120, diastolic: 80 },
    { date: 'Fri', systolic: 119, diastolic: 79 },
    { date: 'Sat', systolic: 120, diastolic: 80 },
    { date: 'Sun', systolic: 120, diastolic: 80 }
  ];

  const sugarData = [
    { date: 'Mon', value: 92 },
    { date: 'Tue', value: 94 },
    { date: 'Wed', value: 91 },
    { date: 'Thu', value: 93 },
    { date: 'Fri', value: 95 },
    { date: 'Sat', value: 94 },
    { date: 'Sun', value: 95 }
  ];

  const heartData = [
    { date: 'Mon', value: 75 },
    { date: 'Tue', value: 73 },
    { date: 'Wed', value: 74 },
    { date: 'Thu', value: 72 },
    { date: 'Fri', value: 71 },
    { date: 'Sat', value: 72 },
    { date: 'Sun', value: 72 }
  ];

  const getChartData = () => {
    switch (selectedMetric) {
      case 'weight': return weightData;
      case 'bp': return bpData;
      case 'sugar': return sugarData;
      case 'heart': return heartData;
      default: return weightData;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-50 via-purple-50 to-pink-50 p-4 md:p-8">
      <div className="container mx-auto max-w-6xl">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-8"
        >
          <div className="inline-flex items-center justify-center w-16 h-16 bg-gradient-to-br from-indigo-500 to-purple-600 rounded-2xl mb-4">
            <BarChart3 className="w-8 h-8 text-white" />
          </div>
          <h1 className="text-3xl font-bold text-gray-900 mb-2">{t.title}</h1>
          <p className="text-gray-600">{t.subtitle}</p>
        </motion.div>

        {/* Metrics Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          {metrics.map((metric, index) => {
            const Icon = metric.icon;
            const isSelected = selectedMetric === metric.id;
            
            return (
              <motion.button
                key={metric.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                onClick={() => setSelectedMetric(metric.id)}
                className={`${metric.bgColor} border-2 ${isSelected ? metric.borderColor : 'border-transparent'} rounded-3xl p-6 text-left hover:shadow-xl transition-all ${isSelected ? 'shadow-xl scale-105' : ''}`}
              >
                <div className="flex items-start justify-between mb-4">
                  <div className={`p-3 bg-gradient-to-br ${metric.color} rounded-2xl`}>
                    <Icon className="w-6 h-6 text-white" />
                  </div>
                  <div className="flex items-center gap-1">
                    {metric.change > 0 ? (
                      <TrendingUp className="w-4 h-4 text-red-500" />
                    ) : metric.change < 0 ? (
                      <TrendingDown className="w-4 h-4 text-green-500" />
                    ) : null}
                    <span className={`text-sm font-semibold ${metric.change > 0 ? 'text-red-500' : metric.change < 0 ? 'text-green-500' : 'text-gray-400'}`}>
                      {metric.change > 0 ? '+' : ''}{metric.change}
                    </span>
                  </div>
                </div>
                <p className="text-sm text-gray-600 mb-1">{metric.label}</p>
                <p className="text-2xl font-bold text-gray-900 mb-1">
                  {metric.value}
                  <span className="text-sm font-normal text-gray-500 ml-1">{metric.unit}</span>
                </p>
                <div className="flex items-center gap-2">
                  <div className={`w-2 h-2 rounded-full ${metric.status === 'normal' ? 'bg-green-500' : metric.status === 'high' ? 'bg-red-500' : 'bg-yellow-500'}`} />
                  <span className="text-xs text-gray-600">{t.normal}</span>
                </div>
              </motion.button>
            );
          })}
        </div>

        {/* Chart Section */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5 }}
          className="bg-white rounded-3xl p-6 md:p-8 shadow-xl mb-8"
        >
          <div className="flex items-center justify-between mb-6">
            <div>
              <h2 className="text-xl font-bold text-gray-900 mb-1">{t.trend}</h2>
              <p className="text-sm text-gray-600">{t.week}</p>
            </div>
            <button className="flex items-center gap-2 bg-gradient-to-r from-indigo-600 to-purple-600 text-white px-6 py-3 rounded-2xl font-semibold hover:shadow-lg transition-all">
              <Plus className="w-5 h-5" />
              {t.add}
            </button>
          </div>

          <div className="h-64 md:h-80">
            <ResponsiveContainer width="100%" height="100%">
              {selectedMetric === 'bp' ? (
                <LineChart data={getChartData()}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
                  <XAxis dataKey="date" stroke="#6b7280" />
                  <YAxis stroke="#6b7280" />
                  <Tooltip />
                  <Line type="monotone" dataKey="systolic" stroke="#10b981" strokeWidth={3} dot={{ fill: '#10b981', r: 5 }} />
                  <Line type="monotone" dataKey="diastolic" stroke="#3b82f6" strokeWidth={3} dot={{ fill: '#3b82f6', r: 5 }} />
                </LineChart>
              ) : (
                <AreaChart data={getChartData()}>
                  <defs>
                    <linearGradient id="colorValue" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#8b5cf6" stopOpacity={0.8}/>
                      <stop offset="95%" stopColor="#8b5cf6" stopOpacity={0}/>
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
                  <XAxis dataKey="date" stroke="#6b7280" />
                  <YAxis stroke="#6b7280" />
                  <Tooltip />
                  <Area type="monotone" dataKey="value" stroke="#8b5cf6" strokeWidth={3} fillOpacity={1} fill="url(#colorValue)" />
                </AreaChart>
              )}
            </ResponsiveContainer>
          </div>
        </motion.div>

        {/* Quick Stats */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.6 }}
            className="bg-white rounded-2xl p-6 border-2 border-gray-200"
          >
            <div className="flex items-center gap-3 mb-3">
              <Calendar className="w-6 h-6 text-indigo-600" />
              <h3 className="font-bold text-gray-900">{t.today}</h3>
            </div>
            <p className="text-3xl font-bold text-indigo-600">4</p>
            <p className="text-sm text-gray-600 mt-1">
              {language === 'ps' ? 'ثبت شوي' : language === 'fa' ? 'ثبت شده' : 'Records'}
            </p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.7 }}
            className="bg-white rounded-2xl p-6 border-2 border-gray-200"
          >
            <div className="flex items-center gap-3 mb-3">
              <TrendingUp className="w-6 h-6 text-green-600" />
              <h3 className="font-bold text-gray-900">{t.week}</h3>
            </div>
            <p className="text-3xl font-bold text-green-600">28</p>
            <p className="text-sm text-gray-600 mt-1">
              {language === 'ps' ? 'ثبت شوي' : language === 'fa' ? 'ثبت شده' : 'Records'}
            </p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.8 }}
            className="bg-white rounded-2xl p-6 border-2 border-gray-200"
          >
            <div className="flex items-center gap-3 mb-3">
              <BarChart3 className="w-6 h-6 text-purple-600" />
              <h3 className="font-bold text-gray-900">{t.month}</h3>
            </div>
            <p className="text-3xl font-bold text-purple-600">120</p>
            <p className="text-sm text-gray-600 mt-1">
              {language === 'ps' ? 'ثبت شوي' : language === 'fa' ? 'ثبت شده' : 'Records'}
            </p>
          </motion.div>
        </div>
      </div>
    </div>
  );
}