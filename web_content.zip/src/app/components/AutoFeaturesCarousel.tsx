import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Stethoscope,
  Hospital,
  Pill,
  Shield,
  Calculator,
  Search,
  FileText,
  Droplet,
  BookOpen,
  Utensils,
  Bot,
  MessageCircle,
  Star,
  Phone,
  Lock,
  Globe,
  Heart,
  Brain,
  Activity,
  Zap,
  Users,
  Clock,
  TrendingUp,
  Award,
  Building2
} from 'lucide-react';

interface AutoFeaturesCarouselProps {
  language: 'ps' | 'fa' | 'en';
  interval?: number;
}

export function AutoFeaturesCarousel({ language, interval = 4000 }: AutoFeaturesCarouselProps) {
  const [currentIndex, setCurrentIndex] = useState(0);

  // د 25 فیچرونو لیست
  const allFeatures = [
    // Medical Services (5)
    {
      icon: Stethoscope,
      label: { ps: '250+ دوکتوران', fa: '250+ دکتران', en: '250+ Doctors' },
      gradient: 'from-blue-500 to-cyan-500'
    },
    {
      icon: Hospital,
      label: { ps: '150+ روغتونونه', fa: '150+ بیمارستان', en: '150+ Hospitals' },
      gradient: 'from-red-500 to-pink-500'
    },
    {
      icon: Pill,
      label: { ps: '1500+ درمل', fa: '1500+ داروها', en: '1500+ Medicines' },
      gradient: 'from-purple-500 to-violet-500'
    },
    {
      icon: Shield,
      label: { ps: 'اسعافی مرسته', fa: 'کمک فوری', en: 'Emergency Aid' },
      gradient: 'from-orange-500 to-red-500'
    },
    {
      icon: Heart,
      label: { ps: 'د زړه روغتیا', fa: 'سلامت قلب', en: 'Heart Health' },
      gradient: 'from-rose-500 to-red-600'
    },

    // Health Tools (5)
    {
      icon: Calculator,
      label: { ps: 'BMI محاسبه', fa: 'محاسبه BMI', en: 'BMI Calculator' },
      gradient: 'from-teal-500 to-cyan-500'
    },
    {
      icon: Search,
      label: { ps: 'علایم چېک', fa: 'بررسی علائم', en: 'Symptoms Check' },
      gradient: 'from-indigo-500 to-blue-500'
    },
    {
      icon: FileText,
      label: { ps: 'ناروغۍ معلومات', fa: 'اطلاعات بیماری', en: 'Disease Info' },
      gradient: 'from-violet-500 to-purple-500'
    },
    {
      icon: Droplet,
      label: { ps: 'د وینې چېک', fa: 'آزمایش خون', en: 'Blood Test' },
      gradient: 'from-rose-500 to-red-500'
    },
    {
      icon: Activity,
      label: { ps: 'صحت څارنه', fa: 'نظارت سلامت', en: 'Health Monitor' },
      gradient: 'from-green-500 to-teal-500'
    },

    // Education & Info (5)
    {
      icon: BookOpen,
      label: { ps: 'روغتیا مشورې', fa: 'مشاوره سلامت', en: 'Health Tips' },
      gradient: 'from-green-500 to-emerald-500'
    },
    {
      icon: Utensils,
      label: { ps: 'د خواړو لارښود', fa: 'راهنمای تغذیه', en: 'Nutrition Guide' },
      gradient: 'from-amber-500 to-orange-500'
    },
    {
      icon: Brain,
      label: { ps: 'رواني روغتیا', fa: 'سلامت روان', en: 'Mental Health' },
      gradient: 'from-purple-500 to-pink-500'
    },
    {
      icon: TrendingUp,
      label: { ps: 'د پرمختګ څارنه', fa: 'پیگیری پیشرفت', en: 'Progress Track' },
      gradient: 'from-blue-500 to-indigo-500'
    },
    {
      icon: Award,
      label: { ps: 'صحت جایزې', fa: 'جوایز سلامت', en: 'Health Rewards' },
      gradient: 'from-yellow-500 to-amber-500'
    },

    // AI & Technology (5)
    {
      icon: Bot,
      label: { ps: 'AI روغتیا مشاور', fa: 'مشاور سلامت AI', en: 'AI Health Advisor' },
      gradient: 'from-pink-500 to-rose-500'
    },
    {
      icon: Zap,
      label: { ps: 'چټک تشخیص', fa: 'تشخیص سریع', en: 'Quick Diagnosis' },
      gradient: 'from-yellow-500 to-orange-600'
    },
    {
      icon: MessageCircle,
      label: { ps: '24/7 چټ مرسته', fa: '24/7 چت کمک', en: '24/7 Chat Support' },
      gradient: 'from-cyan-500 to-blue-500'
    },
    {
      icon: Building2,
      label: { ps: 'ویرچوال کلینیک', fa: 'کلینیک مجازی', en: 'Virtual Clinic' },
      gradient: 'from-indigo-500 to-purple-500'
    },
    {
      icon: Clock,
      label: { ps: 'د وخت یادونه', fa: 'یادآوری زمان', en: 'Time Reminder' },
      gradient: 'from-teal-500 to-green-500'
    },

    // Community & Premium (5)
    {
      icon: Users,
      label: { ps: 'روغتیا ټولنه', fa: 'انجمن سلامت', en: 'Health Community' },
      gradient: 'from-blue-500 to-cyan-500'
    },
    {
      icon: Star,
      label: { ps: 'پریمیم فیچرونه', fa: 'ویژگی‌های پریمیوم', en: 'Premium Features' },
      gradient: 'from-yellow-500 to-orange-500'
    },
    {
      icon: Phone,
      label: { ps: 'اړیکه ونیسئ', fa: 'تماس بگیرید', en: 'Contact Us' },
      gradient: 'from-blue-500 to-indigo-500'
    },
    {
      icon: Lock,
      label: { ps: 'امن پلیټفارم', fa: 'پلتفرم امن', en: 'Secure Platform' },
      gradient: 'from-gray-500 to-slate-500'
    },
    {
      icon: Globe,
      label: { ps: '3 ژبې ملاتړ', fa: 'پشتیبانی 3 زبان', en: '3 Languages Support' },
      gradient: 'from-teal-500 to-green-500'
    }
  ];

  // Auto-rotate features
  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentIndex((prev) => (prev + 4) % allFeatures.length);
    }, interval);

    return () => clearInterval(timer);
  }, [interval, allFeatures.length]);

  // د اوسني 4 فیچرونو ښودل
  const visibleFeatures = [
    allFeatures[currentIndex % allFeatures.length],
    allFeatures[(currentIndex + 1) % allFeatures.length],
    allFeatures[(currentIndex + 2) % allFeatures.length],
    allFeatures[(currentIndex + 3) % allFeatures.length]
  ];

  return (
    <div>
      {/* Features Grid */}
      <AnimatePresence mode="wait">
        <motion.div
          key={currentIndex}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -20 }}
          transition={{ duration: 0.5 }}
          className="grid grid-cols-2 gap-4"
        >
          {visibleFeatures.map((feature, i) => (
            <motion.button
              key={`${currentIndex}-${i}`}
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: i * 0.1 }}
              whileHover={{ scale: 1.05, y: -5 }}
              whileTap={{ scale: 0.95 }}
              className="flex items-center gap-3 px-4 py-3 bg-white/70 backdrop-blur-sm rounded-2xl border border-green-100 shadow-lg hover:shadow-xl transition-all cursor-pointer hover:bg-white/90"
            >
              <div className={`w-10 h-10 bg-gradient-to-br ${feature.gradient} rounded-xl flex items-center justify-center shrink-0`}>
                <feature.icon className="w-5 h-5 text-white" />
              </div>
              <span className="text-sm font-medium text-gray-700 text-left">
                {feature.label[language]}
              </span>
            </motion.button>
          ))}
        </motion.div>
      </AnimatePresence>
    </div>
  );
}