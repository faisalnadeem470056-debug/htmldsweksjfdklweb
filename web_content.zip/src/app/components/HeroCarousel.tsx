import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ImageWithFallback } from './figma/ImageWithFallback';

interface HeroCarouselProps {
  language: 'ps' | 'fa' | 'en';
}

export function HeroCarousel({ language }: HeroCarouselProps) {
  const [currentIndex, setCurrentIndex] = useState(0);
  const SLIDE_DURATION = 30 * 60 * 1000; // 30 minutes in milliseconds

  const slides = [
    {
      image: 'https://images.unsplash.com/photo-1758691463198-dc663b8a64e4?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxkb2N0b3IlMjBjb25zdWx0YXRpb24lMjBtZWRpY2FsfGVufDF8fHx8MTc2Mzk1MDk1M3ww&ixlib=rb-4.1.0&q=80&w=1080',
      titlePs: 'مسلکي طبي مشوره',
      titleFa: 'مشاوره طبی حرفه‌ای',
      titleEn: 'Professional Medical Consultation'
    },
    {
      image: 'https://images.unsplash.com/photo-1758654860020-36fa3fd0dd35?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxudXJzZSUyMGhvc3BpdGFsJTIwY2FyZXxlbnwxfHx8fDE3NjQwNDQxNDl8MA&ixlib=rb-4.1.0&q=80&w=1080',
      titlePs: 'د نرسانو پاملرنه',
      titleFa: 'مراقبت پرستاری',
      titleEn: 'Nursing Care'
    },
    {
      image: 'https://images.unsplash.com/photo-1760074032551-fef8992ca72d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtZWRpY2FsJTIwbGFib3JhdG9yeSUyMHNjaWVuY2V8ZW58MXx8fHwxNzY0MDQ0MTQ5fDA&ixlib=rb-4.1.0&q=80&w=1080',
      titlePs: 'طبي لابراتوار',
      titleFa: 'آزمایشگاه طبی',
      titleEn: 'Medical Laboratory'
    },
    {
      image: 'https://images.unsplash.com/photo-1646392206581-2527b1cae5cb?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwaGFybWFjeSUyMG1lZGljaW5lJTIwcGlscHN8ZW58MXx8fHwxNzY0MDIxMDgwfDA&ixlib=rb-4.1.0&q=80&w=1080',
      titlePs: 'درملتون خدمات',
      titleFa: 'خدمات داروخانه',
      titleEn: 'Pharmacy Services'
    },
    {
      image: 'https://images.unsplash.com/photo-1721114989769-0423619f03d2?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxob3NwaXRhbCUyMGVtZXJnZW5jeSUyMHJvb218ZW58MXx8fHwxNzYzOTY0MjgzfDA&ixlib=rb-4.1.0&q=80&w=1080',
      titlePs: 'اسعافي خونه',
      titleFa: 'اتاق اورژانس',
      titleEn: 'Emergency Room'
    },
    {
      image: 'https://images.unsplash.com/photo-1606685622133-ed6fbaaf445c?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtZWRpY2FsJTIwc3VyZ2VyeSUyMG9wZXJhdGlvbnxlbnwxfHx8fDE3NjQwNDQxNTB8MA&ixlib=rb-4.1.0&q=80&w=1080',
      titlePs: 'جراحي عملیات',
      titleFa: 'عمل جراحی',
      titleEn: 'Surgical Operation'
    },
    {
      image: 'https://images.unsplash.com/photo-1758691463331-2ac00e6f676f?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwZWRpYXRyaWNpYW4lMjBjaGlsZCUyMGhlYWx0aHxlbnwxfHx8fDE3NjQwNDQxNTF8MA&ixlib=rb-4.1.0&q=80&w=1080',
      titlePs: 'د ماشومانو روغتیا',
      titleFa: 'سلامت کودکان',
      titleEn: 'Child Health'
    },
    {
      image: 'https://images.unsplash.com/photo-1655636304332-5a98fee2b828?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxkZW50aXN0JTIwZGVudGFsJTIwY2FyZXxlbnwxfHx8fDE3NjM5NjA2OTh8MA&ixlib=rb-4.1.0&q=80&w=1080',
      titlePs: 'غاښونو درملنه',
      titleFa: 'مراقبت دندانی',
      titleEn: 'Dental Care'
    },
    {
      image: 'https://images.unsplash.com/photo-1758206523830-a5b8afb372a6?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtZWRpY2FsJTIwZXF1aXBtZW50JTIwdGVjaG5vbG9neXxlbnwxfHx8fDE3NjM5NDUwMTJ8MA&ixlib=rb-4.1.0&q=80&w=1080',
      titlePs: 'طبي تجهیزات',
      titleFa: 'تجهیزات پزشکی',
      titleEn: 'Medical Equipment'
    },
    {
      image: 'https://images.unsplash.com/photo-1650174378624-c9ab2c99e512?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxob3NwaXRhbCUyMGJlZCUyMHBhdGllbnR8ZW58MXx8fHwxNzY0MDQ0MTUyfDA&ixlib=rb-4.1.0&q=80&w=1080',
      titlePs: 'د ناروغانو پاملرنه',
      titleFa: 'مراقبت بیماران',
      titleEn: 'Patient Care'
    },
    {
      image: 'https://images.unsplash.com/photo-1759813641406-980519f58b1c?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtZWRpY2FsJTIwc3RhZmYlMjB0ZWFtd29ya3xlbnwxfHx8fDE3NjM5NTk2MjZ8MA&ixlib=rb-4.1.0&q=80&w=1080',
      titlePs: 'طبي ټیم کار',
      titleFa: 'کار تیمی پزشکی',
      titleEn: 'Medical Teamwork'
    },
    {
      image: 'https://images.unsplash.com/photo-1516841273335-e39b37888115?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxoZWFsdGglMjBjaGVja3VwJTIwZXhhbWluYXRpb258ZW58MXx8fHwxNzYzOTgzMzQ5fDA&ixlib=rb-4.1.0&q=80&w=1080',
      titlePs: 'روغتیا معاینه',
      titleFa: 'معاینه سلامت',
      titleEn: 'Health Checkup'
    },
    {
      image: 'https://images.unsplash.com/photo-1631556760585-2e846196d5a9?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtZWRpY2FsJTIwcmVzZWFyY2glMjBzY2llbnRpc3R8ZW58MXx8fHwxNzYzOTYzOTM2fDA&ixlib=rb-4.1.0&q=80&w=1080',
      titlePs: 'طبي څېړنه',
      titleFa: 'تحقیقات پزشکی',
      titleEn: 'Medical Research'
    },
    {
      image: 'https://images.unsplash.com/photo-1721411480070-fcb558776d54?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxhbWJ1bGFuY2UlMjBlbWVyZ2VuY3klMjBtZWRpY2FsfGVufDF8fHx8MTc2Mzk5ODcxNHww&ixlib=rb-4.1.0&q=80&w=1080',
      titlePs: 'امبولانس خدمت',
      titleFa: 'خدمات آمبولانس',
      titleEn: 'Ambulance Service'
    },
    {
      image: 'https://images.unsplash.com/photo-1720180246349-584d40758674?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxob3NwaXRhbCUyMGNvcnJpZG9yJTIwbW9kZXJufGVufDF8fHx8MTc2NDA0NDE1M3ww&ixlib=rb-4.1.0&q=80&w=1080',
      titlePs: 'عصري روغتون',
      titleFa: 'بیمارستان مدرن',
      titleEn: 'Modern Hospital'
    },
    {
      image: 'https://images.unsplash.com/photo-1762625570087-6d98fca29531?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtZWRpY2FsJTIwY2xpbmljJTIwcmVjZXB0aW9ufGVufDF8fHx8MTc2Mzk5OTkyOXww&ixlib=rb-4.1.0&q=80&w=1080',
      titlePs: 'کلینیک خدمات',
      titleFa: 'خدمات کلینیک',
      titleEn: 'Clinic Services'
    },
    {
      image: 'https://images.unsplash.com/photo-1633488781325-d36e6818d0c8?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxudXJzZSUyMHBhdGllbnQlMjBjYXJlfGVufDF8fHx8MTc2NDA0NDE1NHww&ixlib=rb-4.1.0&q=80&w=1080',
      titlePs: 'نرسینګ خدمات',
      titleFa: 'خدمات پرستاری',
      titleEn: 'Nursing Services'
    },
    {
      image: 'https://images.unsplash.com/photo-1575468332949-4bd46064dd66?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtZWRpY2FsJTIwdmFjY2luYXRpb24lMjBpbmplY3Rpb258ZW58MXx8fHwxNzY0MDQ0MTU0fDA&ixlib=rb-4.1.0&q=80&w=1080',
      titlePs: 'واکسین خدمات',
      titleFa: 'خدمات واکسیناسیون',
      titleEn: 'Vaccination Services'
    },
    {
      image: 'https://images.unsplash.com/photo-1759476532819-e37ac3d05cff?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxoZWFsdGglMjBmaXRuZXNzJTIwd2VsbG5lc3N8ZW58MXx8fHwxNzY0MDExNDkyfDA&ixlib=rb-4.1.0&q=80&w=1080',
      titlePs: 'روغتیا او تندرستي',
      titleFa: 'سلامت و تناسب اندام',
      titleEn: 'Health & Wellness'
    },
    {
      image: 'https://images.unsplash.com/photo-1530026454774-50cce722a1fb?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtZWRpY2FsJTIwaGVhcnQlMjBoZWFsdGh8ZW58MXx8fHwxNzY0MDAwNjM0fDA&ixlib=rb-4.1.0&q=80&w=1080',
      titlePs: 'د زړه روغتیا',
      titleFa: 'سلامت قلب',
      titleEn: 'Heart Health'
    },
    {
      image: 'https://images.unsplash.com/photo-1656337426914-5e5ba162d606?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtZWRpY2FsJTIwdGVzdCUyMGJsb29kfGVufDF8fHx8MTc2NDA0NDE2MHww&ixlib=rb-4.1.0&q=80&w=1080',
      titlePs: 'وینې ازموینه',
      titleFa: 'آزمایش خون',
      titleEn: 'Blood Test'
    },
    {
      image: 'https://images.unsplash.com/photo-1550831106-0994fe8abcfe?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxob3NwaXRhbCUyMHN1cmdlcnklMjB0ZWFtfGVufDF8fHx8MTY0MDQ0MTYwfDA&ixlib=rb-4.1.0&q=80&w=1080',
      titlePs: 'جراحي ټیم',
      titleFa: 'تیم جراحی',
      titleEn: 'Surgery Team'
    },
    {
      image: 'https://images.unsplash.com/photo-1655913197756-fbcf99b273cb?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxkb2N0b3IlMjBzdGV0aG9zY29wZXxlbnwxfHx8fDE3NjQwNDQxNjF8MA&ixlib=rb-4.1.0&q=80&w=1080',
      titlePs: 'طبي معاینه',
      titleFa: 'معاینه پزشکی',
      titleEn: 'Medical Examination'
    },
    {
      image: 'https://images.unsplash.com/photo-1583604310111-9cd137d6ffe5?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtZWRpY2FsJTIwcHJlc2NyaXB0aW9uJTIwZHJ1Z3N8ZW58MXx8fHwxNzY0MDQ0MTYxfDA&ixlib=rb-4.1.0&q=80&w=1080',
      titlePs: 'نسخه او درمل',
      titleFa: 'نسخه و داروها',
      titleEn: 'Prescription & Drugs'
    },
    {
      image: 'https://images.unsplash.com/photo-1580615633399-a69c661568c9?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxob3NwaXRhbCUyMHdhaXRpbmclMjByb29tfGVufDF8fHx8MTc2Mzk2OTIzOHww&ixlib=rb-4.1.0&q=80&w=1080',
      titlePs: 'د انتظار خونه',
      titleFa: 'اتاق انتظار',
      titleEn: 'Waiting Room'
    },
    {
      image: 'https://images.unsplash.com/photo-1620423855978-e5d74a7bef30?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtZWRpY2FsJTIweHJheSUyMHNjYW58ZW58MXx8fHwxNzY0MDQ0MTYyfDA&ixlib=rb-4.1.0&q=80&w=1080',
      titlePs: 'اکسری سکین',
      titleFa: 'اسکن اشعه ایکس',
      titleEn: 'X-Ray Scan'
    },
    {
      image: 'https://images.unsplash.com/photo-1758575514487-0390fcacc339?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxudXJzZSUyMHVuaWZvcm0lMjBob3NwaXRhbHxlbnwxfHx8fDE3NjQwNDQxNjJ8MA&ixlib=rb-4.1.0&q=80&w=1080',
      titlePs: 'نرس یونیفورم',
      titleFa: 'لباس پرستاری',
      titleEn: 'Nurse Uniform'
    },
    {
      image: 'https://images.unsplash.com/photo-1584819762556-68601d7f3a86?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtZWRpY2FsJTIwZ2xvdmVzJTIwaGFuZHN8ZW58MXx8fHwxNzY0MDQ0MTYyfDA&ixlib=rb-4.1.0&q=80&w=1080',
      titlePs: 'طبي دستکش',
      titleFa: 'دستکش پزشکی',
      titleEn: 'Medical Gloves'
    },
    {
      image: 'https://images.unsplash.com/photo-1702428903130-dda216ebd63f?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxob3NwaXRhbCUyMGludGVuc2l2ZSUyMGNhcmV8ZW58MXx8fHwxNjQwNDQxNjN8MA&ixlib=rb-4.1.0&q=80&w=1080',
      titlePs: 'ICU خونه',
      titleFa: 'بخش مراقبت ویژه',
      titleEn: 'Intensive Care'
    },
    {
      image: 'https://images.unsplash.com/photo-1598300188480-626f2f79ab8d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtZWRpY2FsJTIwaW5qZWN0aW9uJTIwdmFjY2luZXxlbnwxfHx8fDE3NjQwNDQxNjN8MA&ixlib=rb-4.1.0&q=80&w=1080',
      titlePs: 'واکسین انجکشن',
      titleFa: 'تزریق واکسن',
      titleEn: 'Vaccine Injection'
    },
    {
      image: 'https://images.unsplash.com/photo-1594819246185-dbf1d40ebeaf?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxkb2N0b3IlMjB3aGl0ZSUyMGNvYXR8ZW58MXx8fHwxNzYzOTY3NTU3fDA&ixlib=rb-4.1.0&q=80&w=1080',
      titlePs: 'ډاکټر جامې',
      titleFa: 'لباس دکتر',
      titleEn: 'Doctor Coat'
    },
    {
      image: 'https://images.unsplash.com/photo-1659366100362-d4547c23ceeb?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtZWRpY2FsJTIwaGVhcnQlMjBtb25pdG9yfGVufDF8fHx8MTc2NDA0NDE2NHww&ixlib=rb-4.1.0&q=80&w=1080',
      titlePs: 'د زړه مانیټر',
      titleFa: 'مانیتور قلب',
      titleEn: 'Heart Monitor'
    },
    {
      image: 'https://images.unsplash.com/photo-1653491950066-bec107ee0536?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxob3NwaXRhbCUyMHBhdGllbnQlMjByb29tfGVufDF8fHx8MTc2Mzk4Mzk3MHww&ixlib=rb-4.1.0&q=80&w=1080',
      titlePs: 'د ناروغ خونه',
      titleFa: 'اتاق بیمار',
      titleEn: 'Patient Room'
    },
    {
      image: 'https://images.unsplash.com/photo-1688224821110-e0e45cb718d0?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtZWRpY2FsJTIwdGhlcm1vbWV0ZXIlMjBmZXZlcnxlbnwxfHx8fDE3NjQwNDQxNjV8MA&ixlib=rb-4.1.0&q=80&w=1080',
      titlePs: 'تبې معاینه',
      titleFa: 'معاینه تب',
      titleEn: 'Fever Check'
    },
    {
      image: 'https://images.unsplash.com/photo-1638598124048-10c5b3f2f964?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxkb2N0b3IlMjBudXJzZSUyMHRlYW13b3JrfGVufDF8fHx8MTc2Mzk3NDA2MXww&ixlib=rb-4.1.0&q=80&w=1080',
      titlePs: 'ډاکټر او نرس',
      titleFa: 'دکتر و پرستار',
      titleEn: 'Doctor & Nurse'
    },
    {
      image: 'https://images.unsplash.com/photo-1659019479941-1fd644624339?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtZWRpY2FsJTIwYmFuZGFnZSUyMHdvdW5kfGVufDF8fHx8MTc2NDA0NDE2NXww&ixlib=rb-4.1.0&q=80&w=1080',
      titlePs: 'زخم پټۍ',
      titleFa: 'پانسمان زخم',
      titleEn: 'Wound Bandage'
    },
    {
      image: 'https://images.unsplash.com/photo-1605654580413-5a7f24649936?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxob3NwaXRhbCUyMG9wZXJhdGluZyUyMHJvb218ZW58MXx8fHwxNzY0MDQ0MTY2fDA&ixlib=rb-4.1.0&q=80&w=1080',
      titlePs: 'عملیات خونه',
      titleFa: 'اتاق عمل',
      titleEn: 'Operating Room'
    },
    {
      image: 'https://images.unsplash.com/photo-1668453557069-023d287d22f6?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtZWRpY2FsJTIwc3lyaW5nZSUyMG1lZGljaW5lfGVufDF8fHx8MTc2NDA0NDE2Nnww&ixlib=rb-4.1.0&q=80&w=1080',
      titlePs: 'سوزن او درمل',
      titleFa: 'سرنگ و دارو',
      titleEn: 'Syringe & Medicine'
    },
    {
      image: 'https://images.unsplash.com/photo-1631217868264-e5b90bb7e133?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxkb2N0b3IlMjBwYXRpZW50JTIwY29uc3VsdGF0aW9ufGVufDF8fHx8MTc2MzkzMDE3Mnww&ixlib=rb-4.1.0&q=80&w=1080',
      titlePs: 'ډاکټر مشوره',
      titleFa: 'مشاوره دکتر',
      titleEn: 'Doctor Consultation'
    },
    {
      image: 'https://images.unsplash.com/photo-1580281658626-ee379f3cce93?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtZWRpY2FsJTIwbGFiJTIwY29hdHxlbnwxfHx8fDE3NjQwNDQxNjd8MA&ixlib=rb-4.1.0&q=80&w=1080',
      titlePs: 'لابراتوار کوټ',
      titleFa: 'روپوش آزمایشگاه',
      titleEn: 'Lab Coat'
    },
    {
      image: 'https://images.unsplash.com/photo-1758204055017-1f83b2c256a9?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxob3NwaXRhbCUyMG1lZGljYWwlMjBzdGFmZnxlbnwxfHx8fDE3NjQwMzYxMTJ8MA&ixlib=rb-4.1.0&q=80&w=1080',
      titlePs: 'طبي کارمندان',
      titleFa: 'کارکنان پزشکی',
      titleEn: 'Medical Staff'
    },
    {
      image: 'https://images.unsplash.com/photo-1739285452629-2672b13fa42d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtZWRpY2FsJTIwaGVhbHRoJTIwY2hlY2t1cHxlbnwxfHx8fDE3NjQwNDA1MTB8MA&ixlib=rb-4.1.0&q=80&w=1080',
      titlePs: 'صحي معاینه',
      titleFa: 'معاینه سلامت',
      titleEn: 'Health Checkup'
    },
    {
      image: 'https://images.unsplash.com/photo-1631558553269-03a775c388b5?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxkb2N0b3IlMjBleGFtaW5hdGlvbiUyMHBhdGllbnR8ZW58MXx8fHwxNzY0MDQ0MTY4fDA&ixlib=rb-4.1.0&q=80&w=1080',
      titlePs: 'طبي کتنه',
      titleFa: 'معاینه طبی',
      titleEn: 'Medical Examination'
    },
    {
      image: 'https://images.unsplash.com/photo-1758691462493-120a069304e6?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtZWRpY2FsJTIwY2xpbmljJTIwaGVhbHRofGVufDF8fHx8MTc2Mzk4MDcyMnww&ixlib=rb-4.1.0&q=80&w=1080',
      titlePs: 'روغتیا کلینیک',
      titleFa: 'کلینیک سلامت',
      titleEn: 'Health Clinic'
    },
    {
      image: 'https://images.unsplash.com/photo-1613377512409-59c33c10c821?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxob3NwaXRhbCUyMGNhcmUlMjBtZWRpY2FsfGVufDF8fHx8MTc2NDA0MDUxOHww&ixlib=rb-4.1.0&q=80&w=1080',
      titlePs: 'روغتون پاملرنه',
      titleFa: 'مراقبت بیمارستانی',
      titleEn: 'Hospital Care'
    },
    {
      image: 'https://images.unsplash.com/photo-1666886573681-a8fbe983a3fd?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxkb2N0b3IlMjBoZWFsdGhjYXJlJTIwcHJvZmVzc2lvbmFsfGVufDF8fHx8MTc2Mzk3MDc4M3ww&ixlib=rb-4.1.0&q=80&w=1080',
      titlePs: 'مسلکي ډاکټر',
      titleFa: 'دکتر حرفه‌ای',
      titleEn: 'Healthcare Professional'
    },
    {
      image: 'https://images.unsplash.com/photo-1761881917053-a48d16611196?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtZWRpY2FsJTIwaG9zcGl0YWwlMjBidWlsZGluZ3xlbnwxfHx8fDE3NjM5NzY3NjF8MA&ixlib=rb-4.1.0&q=80&w=1080',
      titlePs: 'روغتون ودانۍ',
      titleFa: 'ساختمان بیمارستان',
      titleEn: 'Hospital Building'
    },
    {
      image: 'https://images.unsplash.com/photo-1584982751601-97dcc096659c?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxoZWFsdGhjYXJlJTIwd29ya2VyJTIwZG9jdG9yfGVufDF8fHx8MTc2NDA0NDE3MHww&ixlib=rb-4.1.0&q=80&w=1080',
      titlePs: 'روغتیا کارګر',
      titleFa: 'کارگر سلامت',
      titleEn: 'Healthcare Worker'
    },
    {
      image: 'https://images.unsplash.com/photo-1517120026326-d87759a7b63b?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtZWRpY2FsJTIwdHJlYXRtZW50JTIwaG9zcGl0YWx8ZW58MXx8fHwxNzY0MDQ0MTcwfDA&ixlib=rb-4.1.0&q=80&w=1080',
      titlePs: 'طبي درملنه',
      titleFa: 'درمان پزشکی',
      titleEn: 'Medical Treatment'
    },
    {
      image: 'https://images.unsplash.com/photo-1758691463626-0ab959babe00?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxkb2N0b3IlMjBtZWRpY2FsJTIwcHJvZmVzc2lvbmFsfGVufDF8fHx8MTc2NDA0NDE3MHww&ixlib=rb-4.1.0&q=80&w=1080',
      titlePs: 'طبي متخصص',
      titleFa: 'متخصص پزشکی',
      titleEn: 'Medical Specialist'
    }
  ];

  // Auto-rotation every 30 minutes
  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentIndex((prev) => (prev + 1) % slides.length);
    }, SLIDE_DURATION);

    return () => clearInterval(timer);
  }, [slides.length]);

  const currentSlide = slides[currentIndex];

  return (
    <div className="relative w-full h-[600px] overflow-hidden rounded-3xl shadow-2xl mb-12">
      {/* Background Images with Animation */}
      <AnimatePresence mode="wait">
        <motion.div
          key={currentIndex}
          initial={{ opacity: 0, scale: 1.1 }}
          animate={{ opacity: 1, scale: 1 }}
          exit={{ opacity: 0, scale: 0.95 }}
          transition={{ duration: 0.8 }}
          className="absolute inset-0"
        >
          <div className="relative w-full h-full">
            <ImageWithFallback
              src={currentSlide.image}
              alt={language === 'ps' ? currentSlide.titlePs : language === 'fa' ? currentSlide.titleFa : currentSlide.titleEn}
              className="w-full h-full object-cover"
            />
            {/* Gradient Overlay */}
            <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/40 to-transparent" />
            
            {/* Mesh Gradient Effect */}
            <div className="absolute inset-0 bg-gradient-to-br from-red-600/30 via-transparent to-purple-600/30 mix-blend-overlay" />
          </div>
        </motion.div>
      </AnimatePresence>

      {/* Content Overlay */}
      <div className="absolute inset-0 flex items-end justify-center z-10 pb-20">
        <div className="container mx-auto px-4 text-center">
          <AnimatePresence mode="wait">
            <motion.div
              key={`content-${currentIndex}`}
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -30 }}
              transition={{ duration: 0.6 }}
              className="max-w-4xl mx-auto"
            >
              {/* Slide Title */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: 0.3 }}
                className="mb-4"
              >
                <h2 className="text-3xl md:text-4xl lg:text-5xl text-white mb-2" style={{ textShadow: '0 4px 20px rgba(0,0,0,0.5)' }}>
                  {language === 'ps' && currentSlide.titlePs}
                  {language === 'fa' && currentSlide.titleFa}
                  {language === 'en' && currentSlide.titleEn}
                </h2>
              </motion.div>

              {/* Compact Stats */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: 0.5 }}
                className="flex flex-wrap justify-center gap-3"
              >
                {[
                  { number: '250+', label: language === 'ps' ? 'دوکتوران' : language === 'fa' ? 'پزشکان' : 'Doctors' },
                  { number: '150+', label: language === 'ps' ? 'روغتونونه' : language === 'fa' ? 'بیمارستان' : 'Hospitals' },
                  { number: '10K+', label: language === 'ps' ? 'کاروونکي' : language === 'fa' ? 'کاربران' : 'Users' },
                  { number: '1500+', label: language === 'ps' ? 'درمل' : language === 'fa' ? 'داروها' : 'Medicines' }
                ].map((stat, index) => (
                  <motion.div
                    key={index}
                    initial={{ scale: 0 }}
                    animate={{ scale: 1 }}
                    transition={{ duration: 0.4, delay: 0.7 + index * 0.1 }}
                    className="bg-white/10 backdrop-blur-md rounded-xl px-3 py-2 border border-white/20"
                  >
                    <div className="text-lg text-white">{stat.number}</div>
                    <div className="text-xs text-white/80">{stat.label}</div>
                  </motion.div>
                ))}
              </motion.div>
            </motion.div>
          </AnimatePresence>
        </div>
      </div>

      {/* Progress Bar - Shows time until next slide */}
      <div className="absolute bottom-0 left-0 right-0 z-20 h-1 bg-white/20">
        <motion.div
          key={currentIndex}
          initial={{ width: '0%' }}
          animate={{ width: '100%' }}
          transition={{ duration: SLIDE_DURATION / 1000, ease: 'linear' }}
          className="h-full bg-gradient-to-r from-red-500 to-pink-500"
        />
      </div>

      {/* Slide Counter */}
      <div className="absolute top-4 right-4 z-20 bg-white/10 backdrop-blur-xl rounded-full px-4 py-2 border border-white/20">
        <span className="text-white text-sm">
          {currentIndex + 1} / {slides.length}
        </span>
      </div>

      {/* Time Remaining Indicator */}
      <div className="absolute top-4 left-4 z-20 bg-white/10 backdrop-blur-xl rounded-full px-4 py-2 border border-white/20">
        <span className="text-white text-xs">
          {language === 'ps' ? '🕐 ۳۰ دقیقې' : language === 'fa' ? '🕐 ۳۰ دقیقه' : '🕐 30 min'}
        </span>
      </div>

      {/* Floating Particles Effect */}
      <div className="absolute inset-0 pointer-events-none z-5">
        {[...Array(20)].map((_, i) => (
          <motion.div
            key={i}
            initial={{
              x: Math.random() * 100 + '%',
              y: '100%',
              opacity: 0
            }}
            animate={{
              y: '-20%',
              opacity: [0, 1, 0]
            }}
            transition={{
              duration: Math.random() * 10 + 10,
              repeat: Infinity,
              delay: Math.random() * 5
            }}
            className="absolute w-2 h-2 bg-white rounded-full"
            style={{
              left: `${Math.random() * 100}%`,
              filter: 'blur(1px)'
            }}
          />
        ))}
      </div>
    </div>
  );
}
