// Book Detail Modal - د کتاب بشپړ معلومات
// Modal for showing complete book information with download option

import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "./ui/dialog";
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";
import { ShareModal } from "./ShareModal";
import {
  Star,
  BookOpen,
  Download,
  FileText,
  Eye,
  Heart,
  Share2,
  User,
  Calendar,
  Languages,
} from "lucide-react";
import { useLanguage } from "../contexts/LanguageContext";
import { toast } from "sonner@2.0.3";
import { useState } from "react";

interface Book {
  title: string;
  titlePs: string;
  titleFa: string;
  author: string;
  pages: number;
  language: string;
  rating: number;
  summary?: string;
  summaryPs?: string;
  summaryFa?: string;
  downloads?: number;
  views?: number;
}

interface BookDetailModalProps {
  isOpen: boolean;
  onClose: () => void;
  book: Book | null;
  categoryGradient: string;
  categoryBgColor: string;
  bookCoverImage: string;
}

export function BookDetailModal({
  isOpen,
  onClose,
  book,
  categoryGradient,
  categoryBgColor,
  bookCoverImage,
}: BookDetailModalProps) {
  const { language } = useLanguage();
  const [isLiked, setIsLiked] = useState(false);
  const [downloadCount, setDownloadCount] = useState(book?.downloads || 0);
  const [shareModalOpen, setShareModalOpen] = useState(false);

  if (!book) return null;

  const bookTitle =
    language === "ps"
      ? book.titlePs
      : language === "fa"
      ? book.titleFa
      : book.title;

  const bookSummary =
    language === "ps"
      ? book.summaryPs || book.summary || "د کتاب خلاصه شتون نه لري."
      : language === "fa"
      ? book.summaryFa || book.summary || "خلاصه کتاب موجود نیست."
      : book.summary || "Book summary not available.";

  const handleDownload = () => {
    setDownloadCount((prev) => prev + 1);
    toast.success(
      language === "ps"
        ? `✅ "${bookTitle}" ډاونلوډ شروع شو!`
        : language === "fa"
        ? `✅ "${bookTitle}" دانلود شروع شد!`
        : `✅ "${bookTitle}" download started!`,
      {
        description:
          language === "ps"
            ? "ستاسو کتاب د ډاونلوډ کېږي..."
            : language === "fa"
            ? "کتاب شما در حال دانلود است..."
            : "Your book is downloading...",
      }
    );
  };

  const handleShare = () => {
    setShareModalOpen(true);
  };

  const handleLike = () => {
    setIsLiked(!isLiked);
    toast.success(
      isLiked
        ? language === "ps"
          ? "خوښ له لیست څخه لیرې شو"
          : language === "fa"
          ? "از لیست علاقه‌مندی‌ها حذف شد"
          : "Removed from favorites"
        : language === "ps"
        ? "✅ د خوښ لیست ته اضافه شو!"
        : language === "fa"
        ? "✅ به لیست علاقه‌مندی‌ها اضافه شد!"
        : "✅ Added to favorites!",
      {
        duration: 2000,
      }
    );
  };

  return (
    <>
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="sr-only">{bookTitle}</DialogTitle>
          <DialogDescription className="sr-only">
            {book.summary || book.summaryPs || book.summaryFa || "Book details and information"}
          </DialogDescription>
        </DialogHeader>

        {/* Book Header با Cover Image */}
        <div className="flex flex-col md:flex-row gap-6 -mt-6">
          {/* Book Cover - بزرگتر */}
          <div className="flex-shrink-0">
            <div className="w-48 h-64 rounded-2xl overflow-hidden shadow-2xl relative group">
              <img
                src={bookCoverImage}
                alt={bookTitle}
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
              />
              <div
                className={`absolute inset-0 bg-gradient-to-br ${categoryGradient} opacity-20 group-hover:opacity-30 transition-opacity`}
              ></div>
            </div>
          </div>

          {/* Book Info */}
          <div className="flex-1 space-y-4">
            {/* Title */}
            <h2 className="text-3xl">{bookTitle}</h2>

            {/* Author */}
            <div className="flex items-center gap-2 text-gray-600">
              <User className="w-5 h-5" />
              <span className="text-lg">{book.author}</span>
            </div>

            {/* Rating & Stats */}
            <div className="flex flex-wrap items-center gap-4">
              <div className="flex items-center gap-1 text-amber-600">
                <Star className="w-5 h-5 fill-amber-400" />
                <span className="text-lg">{book.rating}</span>
              </div>
              <Badge variant="secondary" className="text-sm">
                <BookOpen className="w-4 h-4 mr-1" />
                {book.pages}{" "}
                {language === "ps"
                  ? "مخونه"
                  : language === "fa"
                  ? "صفحه"
                  : "pages"}
              </Badge>
              <Badge variant="secondary" className="text-sm">
                <Languages className="w-4 h-4 mr-1" />
                {book.language}
              </Badge>
            </div>

            {/* Downloads & Views */}
            <div className="flex items-center gap-6 text-sm text-gray-500">
              {downloadCount > 0 && (
                <span className="flex items-center gap-1">
                  <Download className="w-4 h-4" />
                  {downloadCount.toLocaleString()}{" "}
                  {language === "ps"
                    ? "ډاونلوډونه"
                    : language === "fa"
                    ? "دانلود"
                    : "downloads"}
                </span>
              )}
              {book.views && (
                <span className="flex items-center gap-1">
                  <Eye className="w-4 h-4" />
                  {book.views.toLocaleString()}{" "}
                  {language === "ps"
                    ? "لیدل"
                    : language === "fa"
                    ? "بازدید"
                    : "views"}
                </span>
              )}
            </div>

            {/* Action Buttons */}
            <div className="flex flex-wrap gap-3 pt-2">
              <Button
                onClick={handleDownload}
                className={`bg-gradient-to-r ${categoryGradient} text-white hover:opacity-90 shadow-lg flex-1 md:flex-initial`}
                size="lg"
              >
                <Download className="w-5 h-5 mr-2" />
                {language === "ps"
                  ? "ډاونلوډ کړئ"
                  : language === "fa"
                  ? "دانلود کنید"
                  : "Download"}
              </Button>

              <Button
                onClick={handleLike}
                variant="outline"
                size="lg"
                className={`${
                  isLiked
                    ? "bg-red-50 border-red-300 text-red-600"
                    : "border-gray-300"
                }`}
              >
                <Heart
                  className={`w-5 h-5 ${isLiked ? "fill-red-500" : ""}`}
                />
              </Button>

              <Button onClick={handleShare} variant="outline" size="lg">
                <Share2 className="w-5 h-5" />
              </Button>
            </div>
          </div>
        </div>

        {/* Book Summary */}
        <div className="mt-6">
          <div
            className={`p-6 rounded-2xl bg-gradient-to-br ${categoryBgColor} border-2 border-gray-200`}
          >
            <h3 className="text-xl mb-4 flex items-center gap-2">
              <FileText className="w-5 h-5" />
              {language === "ps"
                ? "د کتاب خلاصه"
                : language === "fa"
                ? "خلاصه کتاب"
                : "Book Summary"}
            </h3>
            <p className="text-gray-700 leading-relaxed text-base whitespace-pre-line">
              {bookSummary}
            </p>
          </div>
        </div>

        {/* Additional Info */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-4">
          <div className="p-4 rounded-xl bg-gray-50 text-center">
            <BookOpen className="w-8 h-8 mx-auto mb-2 text-emerald-600" />
            <p className="text-sm text-gray-600">
              {language === "ps"
                ? "د لوستلو موده"
                : language === "fa"
                ? "مدت زمان مطالعه"
                : "Reading Time"}
            </p>
            <p className="text-lg">
              ~{Math.ceil(book.pages / 50)}{" "}
              {language === "ps"
                ? "ساعته"
                : language === "fa"
                ? "ساعت"
                : "hours"}
            </p>
          </div>

          <div className="p-4 rounded-xl bg-gray-50 text-center">
            <Star className="w-8 h-8 mx-auto mb-2 text-amber-500 fill-amber-400" />
            <p className="text-sm text-gray-600">
              {language === "ps"
                ? "ریټینګ"
                : language === "fa"
                ? "امتیاز"
                : "Rating"}
            </p>
            <p className="text-lg">
              {book.rating}/5.0
            </p>
          </div>

          <div className="p-4 rounded-xl bg-gray-50 text-center">
            <Languages className="w-8 h-8 mx-auto mb-2 text-blue-600" />
            <p className="text-sm text-gray-600">
              {language === "ps"
                ? "ژبه"
                : language === "fa"
                ? "زبان"
                : "Language"}
            </p>
            <p className="text-lg">{book.language}</p>
          </div>
        </div>

        {/* Footer Note */}
        <div className="mt-4 p-4 bg-blue-50 rounded-xl border border-blue-200">
          <p className="text-sm text-blue-800 text-center">
            {language === "ps"
              ? "📚 دا کتاب د تعلیمي او معلوماتي موخو لپاره دی. د طبي مشورې لپاره د ډاکټر سره مشوره وکړئ."
              : language === "fa"
              ? "📚 این کتاب برای اهداف آموزشی و اطلاعاتی است. برای مشاوره پزشکی با دکتر مشورت کنید."
              : "📚 This book is for educational and informational purposes. For medical advice, consult with a doctor."}
          </p>
        </div>
      </DialogContent>
    </Dialog>

    <ShareModal
      isOpen={shareModalOpen}
      onClose={() => setShareModalOpen(false)}
      language={language}
      shareContent={{
        title: bookTitle,
        description: bookDescription.slice(0, 150) + '...',
        url: window.location.href
      }}
    />
  </>
  );
}
