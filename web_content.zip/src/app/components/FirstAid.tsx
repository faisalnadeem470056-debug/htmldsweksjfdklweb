import { ArrowLeft, Phone, AlertTriangle, Heart, Droplet, Flame, Zap } from 'lucide-react';
import { motion } from 'motion/react';
import { Button } from './ui/button';
import { translations } from '../translations';
import { AdBanner } from './AdBanner';

interface FirstAidProps {
  language: 'ps' | 'fa' | 'en';
  onBack: () => void;
}

const emergencyContacts = [
  { name: { ps: 'بیړني خدمات', fa: 'خدمات اضطراری', en: 'Emergency Services' }, number: '112' },
  { name: { ps: 'امبولانس', fa: 'آمبولانس', en: 'Ambulance' }, number: '102' },
  { name: { ps: 'اور وژونکي', fa: 'آتش‌نشانی', en: 'Fire Department' }, number: '119' },
  { name: { ps: 'پولیس', fa: 'پولیس', en: 'Police' }, number: '100' },
];

const emergencies = [
  {
    id: 1,
    title: { ps: 'زړه بند', fa: 'ایست قلبی', en: 'Cardiac Arrest' },
    icon: Heart,
    color: 'from-red-500 to-pink-600',
    steps: {
      ps: [
        '۱۱۲ ته زنګ ووهئ',
        'CPR پیل کړئ',
        'د سینې په مرکز کې زور فشار ورکړئ',
        'په دقیقه کې ۱۰۰-۱۲۰ ځله',
        'د مرستې تر رارسیدو پورې دوام ورکړئ',
      ],
      fa: [
        'با ۱۱۲ تماس بگیرید',
        'CPR را شروع کنید',
        'فشار قوی به مرکز قفسه سینه',
        '۱۰۰-۱۲۰ بار در دقیقه',
        'تا رسیدن کمک ادامه دهید',
      ],
      en: [
        'Call 112',
        'Start CPR',
        'Push hard and fast in center of chest',
        '100-120 compressions per minute',
        'Continue until help arrives',
      ],
    },
  },
  {
    id: 2,
    title: { ps: 'وینه بهېدل', fa: 'خونریزی', en: 'Bleeding' },
    icon: Droplet,
    color: 'from-red-600 to-rose-700',
    steps: {
      ps: [
        'پاکه ټوکر یا کاپړه په زخم کېږدئ',
        'زور فشار ورکړئ',
        'زخمي برخه پورته کړئ',
        'که وینه بهېدل نه ودریږي، نور کاپړه اضافه کړئ',
        'د ډېرې وینې بهېدو په صورت کې ۱۱۲ ته زنګ ووهئ',
      ],
      fa: [
        'پارچه تمیز روی زخم بگذارید',
        'فشار قوی وارد کنید',
        'ناحیه مجروح را بالا نگه دارید',
        'اگر خونریزی متوقف نشد، پارچه دیگری اضافه کنید',
        'در صورت خونریزی شدید با ۱۱۲ تماس بگیرید',
      ],
      en: [
        'Apply clean cloth to wound',
        'Apply firm pressure',
        'Elevate the injured area',
        'Add more cloth if bleeding doesn\'t stop',
        'Call 112 for severe bleeding',
      ],
    },
  },
  {
    id: 3,
    title: { ps: 'سوځېدنه', fa: 'سوختگی', en: 'Burns' },
    icon: Flame,
    color: 'from-orange-500 to-red-600',
    steps: {
      ps: [
        'سوځېدلې برخه له یخ اوبو لاندې ونیسئ',
        'د ۱۰-۲۰ دقیقو لپاره',
        'پټۍ او زېور لرې کړئ',
        'پاک کاپړه پرې کېږدئ',
        'د لویو سوځېدنو لپاره ډاکټر ته ورشئ',
      ],
      fa: [
        'ناحیه سوخته را زیر آب سرد قرار دهید',
        'به مدت ۱۰-۲۰ دقیقه',
        'لباس و زیورآلات را بردارید',
        'پارچه تمیز روی آن بگذارید',
        'برای سوختگی‌های بزرگ به پزشک مراجعه کنید',
      ],
      en: [
        'Run cool water over burn',
        'For 10-20 minutes',
        'Remove clothing and jewelry',
        'Cover with clean cloth',
        'Seek medical help for large burns',
      ],
    },
  },
  {
    id: 4,
    title: { ps: 'بریښنا اخیستل', fa: 'برق گرفتگی', en: 'Electric Shock' },
    icon: Zap,
    color: 'from-yellow-500 to-orange-600',
    steps: {
      ps: [
        'د بریښنا سرچینه بنده کړئ',
        'قرباني ته د لاسونو په مستقیم ډول مه نیسئ',
        'د لرګي یا پلاستیک څیز وکاروئ',
        '۱۱۲ ته زنګ ووهئ',
        'که اړین وي CPR پیل کړئ',
      ],
      fa: [
        'منبع برق را قطع کنید',
        'مستقیماً قربانی را لمس نکنید',
        'از شی چوبی یا پلاستیکی استفاده کنید',
        'با ۱۱۲ تماس بگیرید',
        'در صورت نیاز CPR شروع کنید',
      ],
      en: [
        'Turn off power source',
        'Don\'t touch victim directly',
        'Use wooden or plastic object',
        'Call 112',
        'Start CPR if needed',
      ],
    },
  },
];

export function FirstAid({ language, onBack }: FirstAidProps) {
  const t = translations[language];

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 via-amber-50 to-yellow-50 pb-28 md:pb-12">
      {/* Header */}
      <div className="sticky top-[73px] z-30 backdrop-blur-xl bg-white/70 border-b border-white/20 shadow-lg">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center gap-4">
            <Button variant="ghost" size="icon" onClick={onBack}>
              <ArrowLeft className="w-5 h-5" />
            </Button>
            <div>
              <h1 className="text-2xl bg-gradient-to-r from-orange-600 to-amber-600 bg-clip-text text-transparent">
                {t.firstAidGuide}
              </h1>
              <p className="text-sm text-gray-600">{t.commonEmergencies}</p>
            </div>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="container mx-auto px-4 mt-6">
        {/* Emergency Contacts */}
        <div className="mb-8">
          <h2 className="text-xl mb-4">{t.emergencyContacts}</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {emergencyContacts.map((contact, index) => (
              <motion.a
                key={index}
                href={`tel:${contact.number}`}
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: index * 0.1 }}
                className="relative group"
              >
                <div className="absolute inset-0 bg-gradient-to-br from-red-500 to-orange-600 rounded-2xl blur-lg opacity-50 group-hover:opacity-75 transition-all" />
                <div className="relative bg-white/90 backdrop-blur-xl rounded-2xl p-6 border border-white/20 shadow-xl hover:shadow-2xl transition-all text-center">
                  <Phone className="w-8 h-8 text-red-600 mx-auto mb-2" />
                  <p className="text-sm text-gray-600 mb-1">{contact.name[language]}</p>
                  <p className="text-2xl bg-gradient-to-r from-red-600 to-orange-600 bg-clip-text text-transparent">
                    {contact.number}
                  </p>
                </div>
              </motion.a>
            ))}
          </div>
        </div>

        <AdBanner type="medium" className="mb-8" />

        {/* Emergency Procedures */}
        <div className="space-y-6">
          <h2 className="text-xl">{t.commonEmergencies}</h2>
          {emergencies.map((emergency, index) => {
            const Icon = emergency.icon;
            return (
              <motion.div
                key={emergency.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                className="relative group"
              >
                <div className={`absolute inset-0 bg-gradient-to-br ${emergency.color} opacity-20 rounded-3xl blur-xl group-hover:blur-2xl transition-all`} />
                <div className="relative bg-white/90 backdrop-blur-xl rounded-3xl p-6 md:p-8 border border-white/20 shadow-xl">
                  <div className="flex items-center gap-4 mb-6">
                    <div className={`w-14 h-14 bg-gradient-to-br ${emergency.color} rounded-2xl flex items-center justify-center flex-shrink-0`}>
                      <Icon className="w-7 h-7 text-white" />
                    </div>
                    <div>
                      <h3 className="text-xl mb-1">{emergency.title[language]}</h3>
                      <div className="flex items-center gap-2 text-sm text-red-600">
                        <AlertTriangle className="w-4 h-4" />
                        <span>{t.warning}: {t.call112}</span>
                      </div>
                    </div>
                  </div>

                  <div className="bg-gradient-to-br from-white/50 to-gray-50/50 rounded-2xl p-6">
                    <h4 className="mb-4 flex items-center gap-2">
                      <span className="w-6 h-6 bg-gradient-to-br from-orange-500 to-red-600 rounded-full flex items-center justify-center text-white text-sm">
                        !
                      </span>
                      {t.steps}:
                    </h4>
                    <ol className="space-y-3">
                      {emergency.steps[language].map((step, idx) => (
                        <li key={idx} className="flex gap-3">
                          <span className={`flex-shrink-0 w-6 h-6 bg-gradient-to-br ${emergency.color} rounded-full flex items-center justify-center text-white text-sm`}>
                            {idx + 1}
                          </span>
                          <span className="text-gray-700">{step}</span>
                        </li>
                      ))}
                    </ol>
                  </div>
                </div>
              </motion.div>
            );
          })}
        </div>

        <AdBanner type="large" className="mt-8" />

        {/* Disclaimer */}
        <div className="mt-8 p-6 bg-yellow-50 border border-yellow-200 rounded-2xl">
          <div className="flex items-start gap-3">
            <AlertTriangle className="w-6 h-6 text-yellow-600 flex-shrink-0 mt-0.5" />
            <div className="text-sm text-yellow-800">
              <p className="mb-2">
                {language === 'ps' && 'د جدي طبي بیړني حالتونو لپاره تل ۱۱۲ ته زنګ ووهئ. دا معلومات یوازې تعلیمي موخو لپاره دي.'}
                {language === 'fa' && 'برای موارد اضطراری پزشکی جدی همیشه با ۱۱۲ تماس بگیرید. این اطلاعات فقط برای اهداف آموزشی است.'}
                {language === 'en' && 'Always call 112 for serious medical emergencies. This information is for educational purposes only.'}
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
