import { useState } from "react";
import { 
  Lock, 
  Mail, 
  Eye,
  EyeOff, 
  Shield,
  AlertCircle,
  ArrowLeft,
  Key,
  UserPlus,
  LogIn,
  Send
} from "lucide-react";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Label } from "./ui/label";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "./ui/card";
import { Alert, AlertDescription } from "./ui/alert";
import { toast } from "sonner@2.0.3";
import { useLanguage } from "../contexts/LanguageContext";
import { OWNER_EMAIL, isOwnerEmail } from '../config/admin-config';

interface AdminAuthProps {
  onAuthSuccess: () => void;
}

type AuthMode = "login" | "signup" | "forgot";

export function AdminAuth({ onAuthSuccess }: AdminAuthProps) {
  const { language } = useLanguage();
  const [mode, setMode] = useState<AuthMode>("login");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  // Login Handler - د LocalStorage سره
  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!email || !password) {
      toast.error(
        language === "ps" ? "مهرباني وکړئ ټول معلومات ډک کړئ!" :
        language === "fa" ? "لطفا تمام اطلاعات را پر کنید!" :
        "Please fill all fields!"
      );
      return;
    }

    // د Owner Email چیک کړئ
    if (!isOwnerEmail(email)) {
      toast.error(
        language === "ps" ? "❌ تاسو د Admin Panel لاسرسی نه لرئ!" :
        language === "fa" ? "❌ شما به پنل ادمین دسترسی ندارید!" :
        "❌ You don't have access to Admin Panel!"
      );
      return;
    }

    setIsLoading(true);

    try {
      const trimmedEmail = email.trim().toLowerCase();
      
      // د LocalStorage څخه admin معلومات راوړئ
      const storedAdminData = localStorage.getItem('healmate_admin_account');
      
      if (!storedAdminData) {
        toast.error(
          language === "ps" ? "❌ لومړی باید حساب جوړ کړئ!" :
          language === "fa" ? "❌ ابتدا باید حساب ایجاد کنید!" :
          "❌ You need to create an account first!"
        );
        setMode("signup");
        setIsLoading(false);
        return;
      }

      const adminData = JSON.parse(storedAdminData);
      
      // چیک کړئ ایمیل او پاسورډ سم دي که نه
      if (adminData.email !== trimmedEmail || adminData.password !== password) {
        toast.error(
          language === "ps" ? "❌ ایمیل یا پاسورډ غلط دی!" :
          language === "fa" ? "❌ ایمیل یا رمز عبور اشتباه است!" :
          "❌ Email or password is incorrect!"
        );
        setIsLoading(false);
        return;
      }
      
      // د session معلومات ذخیره کړئ
      localStorage.setItem('healmate_admin_session', JSON.stringify({
        email: trimmedEmail,
        loggedInAt: new Date().toISOString(),
        role: 'owner'
      }));

      // د last login وخت update کړئ
      adminData.lastLogin = new Date().toISOString();
      localStorage.setItem('healmate_admin_account', JSON.stringify(adminData));
      
      toast.success(
        language === "ps" ? "✅ بریالي ننوتلی یاست!" :
        language === "fa" ? "✅ با موفقیت وارد شدید!" :
        "✅ Successfully logged in!"
      );
      
      setTimeout(() => {
        onAuthSuccess();
      }, 500);
      
    } catch (error: any) {
      console.error("Admin login error:", error);
      toast.error(
        language === "ps" ? "❌ یوه تېروتنه رامنځته شوه!" :
        language === "fa" ? "❌ خطایی رخ داد!" :
        "❌ An error occurred!"
      );
    } finally {
      setIsLoading(false);
    }
  };

  // Sign Up Handler - د LocalStorage سره
  const handleSignUp = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!email || !password || !confirmPassword) {
      toast.error(
        language === "ps" ? "مهرباني وکړئ ټول معلومات ډک کړئ!" :
        language === "fa" ? "لطفا تمام اطلاعات را پر کنید!" :
        "Please fill all fields!"
      );
      return;
    }

    // د Owner Email چیک کړئ
    if (!isOwnerEmail(email)) {
      toast.error(
        language === "ps" ? "❌ یوازې Owner کولای شي Admin حساب جوړ کړي!" :
        language === "fa" ? "❌ فقط Owner می‌تواند حساب ادمین ایجاد کند!" :
        "❌ Only Owner can create Admin account!"
      );
      return;
    }

    if (password !== confirmPassword) {
      toast.error(
        language === "ps" ? "❌ پاسورډونه سره برابر نه دي!" :
        language === "fa" ? "❌ رمزهای عبور یکسان نیستند!" :
        "❌ Passwords do not match!"
      );
      return;
    }

    if (password.length < 6) {
      toast.error(
        language === "ps" ? "❌ پاسورډ لږ تر لږه 6 حروف باید ولري!" :
        language === "fa" ? "❌ رمز عبور باید حداقل 6 کاراکتر باشد!" :
        "❌ Password must be at least 6 characters!"
      );
      return;
    }

    setIsLoading(true);

    try {
      const trimmedEmail = email.trim().toLowerCase();
      
      // چیک کړئ که مخکې حساب جوړ شوی وي
      const existingAdmin = localStorage.getItem('healmate_admin_account');
      if (existingAdmin) {
        toast.error(
          language === "ps" ? "❌ Admin حساب مخکې جوړ شوی دی! Login وکړئ" :
          language === "fa" ? "❌ حساب ادمین قبلاً ایجاد شده! وارد شوید" :
          "❌ Admin account already exists! Please login"
        );
        setMode("login");
        setIsLoading(false);
        return;
      }
      
      // نوی admin account جوړ کړئ
      const adminData = {
        email: trimmedEmail,
        password: password, // Note: په real production app کې باید encrypted وي
        role: "owner",
        createdAt: new Date().toISOString(),
        lastLogin: new Date().toISOString(),
        name: "Dr. Ibrahim Khaksar",
        status: "active"
      };
      
      localStorage.setItem('healmate_admin_account', JSON.stringify(adminData));
      
      toast.success(
        language === "ps" ? "✅ Admin حساب بریالۍ سره جوړ شو! اوس Login وکړئ" :
        language === "fa" ? "✅ حساب ادمین با موفقیت ایجاد شد! اکنون وارد شوید" :
        "✅ Admin account created successfully! Please login"
      );
      
      // د signup وروسته د login mode ته لاړ شئ
      setMode("login");
      setPassword("");
      setConfirmPassword("");
      
    } catch (error: any) {
      console.error("Admin signup error:", error);
      toast.error(
        language === "ps" ? "❌ یوه تېروتنه رامنځته شوه!" :
        language === "fa" ? "❌ خطایی رخ داد!" :
        "❌ An error occurred!"
      );
    } finally {
      setIsLoading(false);
    }
  };

  // Forgot Password Handler
  const handleForgotPassword = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!email) {
      toast.error(
        language === "ps" ? "مهرباني وکړئ خپل ایمیل ولیکئ!" :
        language === "fa" ? "لطفا ایمیل خود را وارد کنید!" :
        "Please enter your email!"
      );
      return;
    }

    // د Owner Email چیک کړئ
    if (!isOwnerEmail(email)) {
      toast.error(
        language === "ps" ? "❌ دا ایمیل د Admin Panel لاسرسی نه لري!" :
        language === "fa" ? "❌ این ایمیل به پنل ادمین دسترسی ندارد!" :
        "❌ This email doesn't have access to Admin Panel!"
      );
      return;
    }

    setIsLoading(true);

    try {
      const trimmedEmail = email.trim().toLowerCase();
      
      // د LocalStorage څخه admin معلومات راوړئ
      const storedAdminData = localStorage.getItem('healmate_admin_account');
      
      if (!storedAdminData) {
        toast.error(
          language === "ps" ? "❌ دا ایمیل شتون نه لري!" :
          language === "fa" ? "❌ این ایمیل وجود ندارد!" :
          "❌ This email doesn't exist!"
        );
        setIsLoading(false);
        return;
      }

      const adminData = JSON.parse(storedAdminData);
      
      if (adminData.email !== trimmedEmail) {
        toast.error(
          language === "ps" ? "❌ دا ایمیل شتون نه لري!" :
          language === "fa" ? "❌ این ایمیل وجود ندارد!" :
          "❌ This email doesn't exist!"
        );
        setIsLoading(false);
        return;
      }
      
      // د password reset وېې په console کې ښودل شي
      console.log("🔑 Password Reset Request:");
      console.log("   Email:", trimmedEmail);
      console.log("   Current Password:", adminData.password);
      console.log("   Contact: ibrahimkhaksar.it@gmail.com");
      
      toast.success(
        language === "ps" ? "✅ د پاسورډ بیا تنظیم کولو معلومات Console کې ګورئ!" :
        language === "fa" ? "✅ اطلاعات بازنشانی رمز را در Console ببینید!" :
        "✅ Password reset info sent to Console!"
      );
      
      setMode("login");
      
    } catch (error: any) {
      console.error("Forgot password error:", error);
      toast.error(
        language === "ps" ? "❌ یوه تېروتنه رامنځته شوه!" :
        language === "fa" ? "❌ خطایی رخ داد!" :
        "❌ An error occurred!"
      );
    } finally {
      setIsLoading(false);
    }
  };

  // د ژبې متن
  const texts = {
    ps: {
      login: "ننوتل",
      signup: "نوم لیکنه",
      forgot: "پاسورډ هیر شو؟",
      email: "ایمیل",
      password: "پاسورډ",
      confirmPassword: "پاسورډ تایید",
      loginButton: "ننوتل",
      signupButton: "حساب جوړول",
      resetButton: "بیا تنظیم",
      backToLogin: "بیرته Login ته",
      createAccount: "نوی حساب جوړ کړئ",
      resetPassword: "پاسورډ بیا تنظیم کړئ",
      adminPanelTitle: "Admin Panel",
      adminPanelDesc: "د Owner لپاره خصوصي لاسرسی",
      ownerOnlyAccess: "یوازې Owner لاسرسی لري",
      secureLogin: "خوندي ننوتل"
    },
    fa: {
      login: "ورود",
      signup: "ثبت‌نام",
      forgot: "رمز عبور فراموش شد؟",
      email: "ایمیل",
      password: "رمز عبور",
      confirmPassword: "تایید رمز عبور",
      loginButton: "ورود",
      signupButton: "ایجاد حساب",
      resetButton: "بازنشانی",
      backToLogin: "بازگشت به ورود",
      createAccount: "ایجاد حساب جدید",
      resetPassword: "بازنشانی رمز عبور",
      adminPanelTitle: "پنل مدیریت",
      adminPanelDesc: "دسترسی خصوصی برای Owner",
      ownerOnlyAccess: "فقط Owner دسترسی دارد",
      secureLogin: "ورود امن"
    },
    en: {
      login: "Login",
      signup: "Sign Up",
      forgot: "Forgot Password?",
      email: "Email",
      password: "Password",
      confirmPassword: "Confirm Password",
      loginButton: "Login",
      signupButton: "Create Account",
      resetButton: "Reset",
      backToLogin: "Back to Login",
      createAccount: "Create New Account",
      resetPassword: "Reset Password",
      adminPanelTitle: "Admin Panel",
      adminPanelDesc: "Private Access for Owner",
      ownerOnlyAccess: "Owner Only Access",
      secureLogin: "Secure Login"
    }
  };

  const t = texts[language];

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-600 via-blue-600 to-cyan-600 flex items-center justify-center p-4">
      {/* Animated Background */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute -top-40 -right-40 w-80 h-80 bg-purple-500 rounded-full mix-blend-multiply filter blur-xl opacity-70 animate-blob" />
        <div className="absolute -bottom-40 -left-40 w-80 h-80 bg-cyan-500 rounded-full mix-blend-multiply filter blur-xl opacity-70 animate-blob animation-delay-2000" />
        <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-80 h-80 bg-blue-500 rounded-full mix-blend-multiply filter blur-xl opacity-70 animate-blob animation-delay-4000" />
      </div>

      <Card className="w-full max-w-md relative z-10 shadow-2xl border-0 bg-white/95 backdrop-blur-xl">
        <CardHeader className="space-y-4 text-center pb-6">
          <div className="mx-auto w-20 h-20 bg-gradient-to-br from-purple-600 to-blue-600 rounded-2xl flex items-center justify-center shadow-lg">
            <Shield className="w-10 h-10 text-white" />
          </div>
          <div>
            <CardTitle className="text-3xl font-bold bg-gradient-to-r from-purple-600 to-blue-600 bg-clip-text text-transparent">
              {t.adminPanelTitle}
            </CardTitle>
            <CardDescription className="text-base mt-2">
              {t.adminPanelDesc}
            </CardDescription>
          </div>
          
          <Alert className="bg-amber-50 border-amber-200">
            <AlertCircle className="w-4 h-4 text-amber-600" />
            <AlertDescription className="text-amber-800 text-sm">
              {t.ownerOnlyAccess}: <strong>{OWNER_EMAIL}</strong>
            </AlertDescription>
          </Alert>
        </CardHeader>

        <CardContent className="space-y-6">
          {/* Login Form */}
          {mode === "login" && (
            <form onSubmit={handleLogin} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="email" className="flex items-center gap-2">
                  <Mail className="w-4 h-4" />
                  {t.email}
                </Label>
                <Input
                  id="email"
                  type="email"
                  placeholder="ibrahimkhaksar.it@gmail.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="h-11"
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="password" className="flex items-center gap-2">
                  <Lock className="w-4 h-4" />
                  {t.password}
                </Label>
                <div className="relative">
                  <Input
                    id="password"
                    type={showPassword ? "text" : "password"}
                    placeholder="••••••••"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="h-11 pr-10"
                    required
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600"
                  >
                    {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              <Button
                type="submit"
                className="w-full h-11 bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 text-white shadow-lg"
                disabled={isLoading}
              >
                {isLoading ? (
                  <div className="flex items-center gap-2">
                    <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                    Loading...
                  </div>
                ) : (
                  <div className="flex items-center gap-2">
                    <LogIn className="w-4 h-4" />
                    {t.loginButton}
                  </div>
                )}
              </Button>

              <div className="flex items-center justify-between text-sm">
                <button
                  type="button"
                  onClick={() => setMode("forgot")}
                  className="text-blue-600 hover:text-blue-700 hover:underline"
                >
                  {t.forgot}
                </button>
                <button
                  type="button"
                  onClick={() => setMode("signup")}
                  className="text-purple-600 hover:text-purple-700 hover:underline"
                >
                  {t.createAccount}
                </button>
              </div>
            </form>
          )}

          {/* Sign Up Form */}
          {mode === "signup" && (
            <form onSubmit={handleSignUp} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="email" className="flex items-center gap-2">
                  <Mail className="w-4 h-4" />
                  {t.email}
                </Label>
                <Input
                  id="email"
                  type="email"
                  placeholder="ibrahimkhaksar.it@gmail.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="h-11"
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="password" className="flex items-center gap-2">
                  <Lock className="w-4 h-4" />
                  {t.password}
                </Label>
                <div className="relative">
                  <Input
                    id="password"
                    type={showPassword ? "text" : "password"}
                    placeholder="••••••••"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="h-11 pr-10"
                    required
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600"
                  >
                    {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="confirmPassword" className="flex items-center gap-2">
                  <Key className="w-4 h-4" />
                  {t.confirmPassword}
                </Label>
                <div className="relative">
                  <Input
                    id="confirmPassword"
                    type={showConfirmPassword ? "text" : "password"}
                    placeholder="••••••••"
                    value={confirmPassword}
                    onChange={(e) => setConfirmPassword(e.target.value)}
                    className="h-11 pr-10"
                    required
                  />
                  <button
                    type="button"
                    onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600"
                  >
                    {showConfirmPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              <Button
                type="submit"
                className="w-full h-11 bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 text-white shadow-lg"
                disabled={isLoading}
              >
                {isLoading ? (
                  <div className="flex items-center gap-2">
                    <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                    Loading...
                  </div>
                ) : (
                  <div className="flex items-center gap-2">
                    <UserPlus className="w-4 h-4" />
                    {t.signupButton}
                  </div>
                )}
              </Button>

              <button
                type="button"
                onClick={() => setMode("login")}
                className="w-full text-sm text-blue-600 hover:text-blue-700 hover:underline flex items-center justify-center gap-2"
              >
                <ArrowLeft className="w-4 h-4" />
                {t.backToLogin}
              </button>
            </form>
          )}

          {/* Forgot Password Form */}
          {mode === "forgot" && (
            <form onSubmit={handleForgotPassword} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="email" className="flex items-center gap-2">
                  <Mail className="w-4 h-4" />
                  {t.email}
                </Label>
                <Input
                  id="email"
                  type="email"
                  placeholder="ibrahimkhaksar.it@gmail.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="h-11"
                  required
                />
              </div>

              <Button
                type="submit"
                className="w-full h-11 bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 text-white shadow-lg"
                disabled={isLoading}
              >
                {isLoading ? (
                  <div className="flex items-center gap-2">
                    <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                    Loading...
                  </div>
                ) : (
                  <div className="flex items-center gap-2">
                    <Send className="w-4 h-4" />
                    {t.resetButton}
                  </div>
                )}
              </Button>

              <button
                type="button"
                onClick={() => setMode("login")}
                className="w-full text-sm text-blue-600 hover:text-blue-700 hover:underline flex items-center justify-center gap-2"
              >
                <ArrowLeft className="w-4 h-4" />
                {t.backToLogin}
              </button>
            </form>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
