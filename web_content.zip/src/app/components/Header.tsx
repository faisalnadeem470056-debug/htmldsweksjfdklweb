import { Menu, X } from "lucide-react";
import { useState } from "react";
import Logo from "./Logo";

export function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  return (
    <header className="bg-white shadow-sm sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center py-4">
          <Logo size="lg" showText={true} />

          {/* Desktop Navigation */}
          <nav className="hidden md:flex gap-6">
            <a href="#home" className="text-gray-700 hover:text-emerald-600 transition">Home</a>
            <a href="#services" className="text-gray-700 hover:text-emerald-600 transition">Services</a>
            <a href="#doctors" className="text-gray-700 hover:text-emerald-600 transition">Doctors</a>
            <a href="#emergency" className="text-gray-700 hover:text-emerald-600 transition">Emergency</a>
          </nav>

          {/* Mobile Menu Button */}
          <button
            onClick={() => setIsMenuOpen(!isMenuOpen)}
            className="md:hidden p-2 rounded-lg hover:bg-gray-100"
          >
            {isMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>

        {/* Mobile Navigation */}
        {isMenuOpen && (
          <nav className="md:hidden pb-4 flex flex-col gap-2">
            <a href="#home" className="px-4 py-2 text-gray-700 hover:bg-emerald-50 rounded-lg transition">Home</a>
            <a href="#services" className="px-4 py-2 text-gray-700 hover:bg-emerald-50 rounded-lg transition">Services</a>
            <a href="#doctors" className="px-4 py-2 text-gray-700 hover:bg-emerald-50 rounded-lg transition">Doctors</a>
            <a href="#emergency" className="px-4 py-2 text-gray-700 hover:bg-emerald-50 rounded-lg transition">Emergency</a>
          </nav>
        )}
      </div>
    </header>
  );
}
