import { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { Camera, Mail, Phone, MapPin, Calendar, Edit2, Save, X, UserPlus, UserMinus, Flag, Settings, Heart, MessageCircle, Users } from 'lucide-react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Textarea } from './ui/textarea';
import { ImageWithFallback } from './figma/ImageWithFallback';

interface UserProfileProps {
  userId: string;
  currentUserId: string;
  language: 'ps' | 'fa' | 'en';
  onBack: () => void;
}

interface UserData {
  id: string;
  name: string;
  email: string;
  phone: string;
  location: string;
  bio: string;
  profileImage: string;
  coverImage: string;
  verified: boolean;
  joinedDate: string;
  followers: string[];
  following: string[];
  posts: number;
}

export function UserProfile({ userId, currentUserId, language, onBack }: UserProfileProps) {
  const [userData, setUserData] = useState<UserData | null>(null);
  const [isEditing, setIsEditing] = useState(false);
  const [editData, setEditData] = useState<Partial<UserData>>({});
  const [isFollowing, setIsFollowing] = useState(false);
  const [showReportModal, setShowReportModal] = useState(false);

  const isOwnProfile = userId === currentUserId;

  const t = {
    ps: {
      editProfile: 'پروفایل ایډیټ',
      save: 'خوندي کول',
      cancel: 'لغوه',
      follow: 'تعقیب',
      following: 'تعقیب کوي',
      unfollow: 'تعقیب مه کوئ',
      report: 'ریپورټ',
      posts: 'پوستونه',
      followers: 'تعقیب کوونکي',
      followingCount: 'تعقیب کوي',
      joined: 'شامل شو',
      bio: 'په اړه',
      email: 'برېښنالیک',
      phone: 'نمبر',
      location: 'موقعیت',
      editPhoto: 'عکس بدل کړئ',
      coverPhoto: 'پس منظر عکس',
      verified: 'تایید شوی',
      reportUser: 'د کاروونکي ریپورټ',
      reportReason: 'د ریپورټ دلیل',
      submitReport: 'ریپورټ واستوئ',
      spam: 'سپم',
      harassment: 'ځورول',
      inappropriate: 'نامناسب مینځپانګه',
      fake: 'جعلي حساب'
    },
    fa: {
      editProfile: 'ویرایش پروفایل',
      save: 'ذخیره',
      cancel: 'لغو',
      follow: 'دنبال کردن',
      following: 'دنبال می‌کنید',
      unfollow: 'لغو دنبال کردن',
      report: 'گزارش',
      posts: 'پست‌ها',
      followers: 'دنبال کنندگان',
      followingCount: 'دنبال شده',
      joined: 'عضو شده',
      bio: 'درباره',
      email: 'ایمیل',
      phone: 'شماره',
      location: 'موقعیت',
      editPhoto: 'تغییر عکس',
      coverPhoto: 'عکس کاور',
      verified: 'تایید شده',
      reportUser: 'گزارش کاربر',
      reportReason: 'دلیل گزارش',
      submitReport: 'ارسال گزارش',
      spam: 'اسپم',
      harassment: 'آزار',
      inappropriate: 'محتوای نامناسب',
      fake: 'حساب جعلی'
    },
    en: {
      editProfile: 'Edit Profile',
      save: 'Save',
      cancel: 'Cancel',
      follow: 'Follow',
      following: 'Following',
      unfollow: 'Unfollow',
      report: 'Report',
      posts: 'Posts',
      followers: 'Followers',
      followingCount: 'Following',
      joined: 'Joined',
      bio: 'Bio',
      email: 'Email',
      phone: 'Phone',
      location: 'Location',
      editPhoto: 'Change Photo',
      coverPhoto: 'Cover Photo',
      verified: 'Verified',
      reportUser: 'Report User',
      reportReason: 'Report Reason',
      submitReport: 'Submit Report',
      spam: 'Spam',
      harassment: 'Harassment',
      inappropriate: 'Inappropriate Content',
      fake: 'Fake Account'
    }
  };

  const text = t[language];

  useEffect(() => {
    loadUserData();
  }, [userId]);

  const loadUserData = () => {
    // Load from localStorage (in production, this would be Firebase)
    const users = JSON.parse(localStorage.getItem('healmate_users_data') || '[]');
    let user = users.find((u: UserData) => u.id === userId);
    
    if (!user) {
      // Create default user data
      user = {
        id: userId,
        name: localStorage.getItem('healmate_userName') || 'کاروونکی',
        email: localStorage.getItem('healmate_userEmail') || '',
        phone: '+93 700 000 000',
        location: 'کابل، افغانستان',
        bio: 'HealMate کاروونکی',
        profileImage: 'https://images.unsplash.com/photo-1633332755192-727a05c4013d?w=400',
        coverImage: 'https://images.unsplash.com/photo-1576091160399-112ba8d25d1d?w=1200',
        verified: false,
        joinedDate: new Date().toISOString(),
        followers: [],
        following: [],
        posts: 0
      };
      users.push(user);
      localStorage.setItem('healmate_users_data', JSON.stringify(users));
    }
    
    setUserData(user);
    setEditData(user);
    
    // Check if current user is following
    const currentUser = users.find((u: UserData) => u.id === currentUserId);
    if (currentUser) {
      setIsFollowing(currentUser.following.includes(userId));
    }
  };

  const handleSave = () => {
    if (!userData) return;
    
    const users = JSON.parse(localStorage.getItem('healmate_users_data') || '[]');
    const index = users.findIndex((u: UserData) => u.id === userId);
    
    if (index !== -1) {
      users[index] = { ...userData, ...editData };
      localStorage.setItem('healmate_users_data', JSON.stringify(users));
      setUserData(users[index]);
      setIsEditing(false);
    }
  };

  const handleFollow = () => {
    const users = JSON.parse(localStorage.getItem('healmate_users_data') || '[]');
    const currentUserIndex = users.findIndex((u: UserData) => u.id === currentUserId);
    const targetUserIndex = users.findIndex((u: UserData) => u.id === userId);
    
    if (currentUserIndex !== -1 && targetUserIndex !== -1) {
      if (isFollowing) {
        // Unfollow
        users[currentUserIndex].following = users[currentUserIndex].following.filter((id: string) => id !== userId);
        users[targetUserIndex].followers = users[targetUserIndex].followers.filter((id: string) => id !== currentUserId);
      } else {
        // Follow
        users[currentUserIndex].following.push(userId);
        users[targetUserIndex].followers.push(currentUserId);
      }
      
      localStorage.setItem('healmate_users_data', JSON.stringify(users));
      setIsFollowing(!isFollowing);
      setUserData(users[targetUserIndex]);
    }
  };

  const handleReport = (reason: string) => {
    const reports = JSON.parse(localStorage.getItem('healmate_user_reports') || '[]');
    reports.push({
      reporterId: currentUserId,
      reportedUserId: userId,
      reason,
      timestamp: new Date().toISOString()
    });
    localStorage.setItem('healmate_user_reports', JSON.stringify(reports));
    setShowReportModal(false);
    alert(language === 'ps' ? 'ریپورټ واستول شو' : language === 'fa' ? 'گزارش ارسال شد' : 'Report submitted');
  };

  if (!userData) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-red-50 via-pink-50 to-purple-50 flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-4 border-red-500 border-t-transparent" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-red-50 via-pink-50 to-purple-50 pb-28 md:pb-8">
      {/* Cover Image */}
      <div className="relative h-64 overflow-hidden">
        <ImageWithFallback
          src={userData.coverImage}
          alt="Cover"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-transparent to-black/50" />
        
        {/* Back Button */}
        <Button
          variant="ghost"
          onClick={onBack}
          className="absolute top-4 left-4 bg-black/50 hover:bg-black/70 text-white backdrop-blur-xl"
        >
          <X className="w-5 h-5" />
        </Button>

        {/* Edit Cover Photo */}
        {isOwnProfile && isEditing && (
          <Button
            variant="ghost"
            className="absolute top-4 right-4 bg-black/50 hover:bg-black/70 text-white backdrop-blur-xl"
          >
            <Camera className="w-5 h-5 mr-2" />
            {text.coverPhoto}
          </Button>
        )}
      </div>

      {/* Profile Info */}
      <div className="container mx-auto px-4 -mt-20">
        <div className="bg-white/90 backdrop-blur-xl rounded-3xl shadow-2xl border border-white/20 p-6">
          {/* Profile Picture & Stats */}
          <div className="flex flex-col md:flex-row gap-6 items-start">
            {/* Profile Picture */}
            <div className="relative">
              <div className="w-32 h-32 rounded-3xl overflow-hidden border-4 border-white shadow-xl">
                <ImageWithFallback
                  src={userData.profileImage}
                  alt={userData.name}
                  className="w-full h-full object-cover"
                />
              </div>
              {userData.verified && (
                <div className="absolute -bottom-2 -right-2 bg-blue-500 text-white p-2 rounded-full shadow-lg">
                  <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 20 20">
                    <path fillRule="evenodd" d="M6.267 3.455a3.066 3.066 0 001.745-.723 3.066 3.066 0 013.976 0 3.066 3.066 0 001.745.723 3.066 3.066 0 012.812 2.812c.051.643.304 1.254.723 1.745a3.066 3.066 0 010 3.976 3.066 3.066 0 00-.723 1.745 3.066 3.066 0 01-2.812 2.812 3.066 3.066 0 00-1.745.723 3.066 3.066 0 01-3.976 0 3.066 3.066 0 00-1.745-.723 3.066 3.066 0 01-2.812-2.812 3.066 3.066 0 00-.723-1.745 3.066 3.066 0 010-3.976 3.066 3.066 0 00.723-1.745 3.066 3.066 0 012.812-2.812zm7.44 5.252a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                  </svg>
                </div>
              )}
              {isOwnProfile && isEditing && (
                <button className="absolute top-0 right-0 bg-red-500 text-white p-2 rounded-full shadow-lg hover:bg-red-600">
                  <Camera className="w-4 h-4" />
                </button>
              )}
            </div>

            {/* User Info */}
            <div className="flex-1">
              {!isEditing ? (
                <>
                  <div className="flex items-center gap-2 mb-2">
                    <h1 className="text-3xl">{userData.name}</h1>
                    {userData.verified && (
                      <span className="text-blue-500 text-sm">✓ {text.verified}</span>
                    )}
                  </div>
                  <p className="text-gray-600 mb-4">{userData.bio}</p>
                  
                  <div className="flex flex-wrap gap-4 mb-4 text-sm text-gray-600">
                    {userData.email && (
                      <div className="flex items-center gap-2">
                        <Mail className="w-4 h-4" />
                        {userData.email}
                      </div>
                    )}
                    {userData.phone && (
                      <div className="flex items-center gap-2">
                        <Phone className="w-4 h-4" />
                        {userData.phone}
                      </div>
                    )}
                    {userData.location && (
                      <div className="flex items-center gap-2">
                        <MapPin className="w-4 h-4" />
                        {userData.location}
                      </div>
                    )}
                    <div className="flex items-center gap-2">
                      <Calendar className="w-4 h-4" />
                      {text.joined} {new Date(userData.joinedDate).toLocaleDateString()}
                    </div>
                  </div>

                  {/* Stats */}
                  <div className="flex gap-6 mb-4">
                    <div className="text-center">
                      <div className="text-2xl">{userData.posts}</div>
                      <div className="text-sm text-gray-600">{text.posts}</div>
                    </div>
                    <div className="text-center">
                      <div className="text-2xl">{userData.followers.length}</div>
                      <div className="text-sm text-gray-600">{text.followers}</div>
                    </div>
                    <div className="text-center">
                      <div className="text-2xl">{userData.following.length}</div>
                      <div className="text-sm text-gray-600">{text.followingCount}</div>
                    </div>
                  </div>

                  {/* Action Buttons */}
                  <div className="flex gap-3">
                    {isOwnProfile ? (
                      <Button
                        onClick={() => setIsEditing(true)}
                        className="bg-gradient-to-r from-red-600 to-pink-600"
                      >
                        <Edit2 className="w-4 h-4 mr-2" />
                        {text.editProfile}
                      </Button>
                    ) : (
                      <>
                        <Button
                          onClick={handleFollow}
                          className={isFollowing ? 'bg-gray-200 text-gray-800' : 'bg-gradient-to-r from-red-600 to-pink-600'}
                        >
                          {isFollowing ? (
                            <>
                              <UserMinus className="w-4 h-4 mr-2" />
                              {text.following}
                            </>
                          ) : (
                            <>
                              <UserPlus className="w-4 h-4 mr-2" />
                              {text.follow}
                            </>
                          )}
                        </Button>
                        <Button
                          variant="outline"
                          onClick={() => setShowReportModal(true)}
                          className="border-red-200 text-red-600"
                        >
                          <Flag className="w-4 h-4 mr-2" />
                          {text.report}
                        </Button>
                      </>
                    )}
                  </div>
                </>
              ) : (
                <div className="space-y-4">
                  <div>
                    <Label>{text.bio}</Label>
                    <Input
                      value={editData.name || ''}
                      onChange={(e) => setEditData({ ...editData, name: e.target.value })}
                    />
                  </div>
                  <div>
                    <Label>{text.bio}</Label>
                    <Textarea
                      value={editData.bio || ''}
                      onChange={(e) => setEditData({ ...editData, bio: e.target.value })}
                    />
                  </div>
                  <div>
                    <Label>{text.phone}</Label>
                    <Input
                      value={editData.phone || ''}
                      onChange={(e) => setEditData({ ...editData, phone: e.target.value })}
                    />
                  </div>
                  <div>
                    <Label>{text.location}</Label>
                    <Input
                      value={editData.location || ''}
                      onChange={(e) => setEditData({ ...editData, location: e.target.value })}
                    />
                  </div>
                  
                  <div className="flex gap-3">
                    <Button onClick={handleSave} className="bg-gradient-to-r from-green-600 to-emerald-600">
                      <Save className="w-4 h-4 mr-2" />
                      {text.save}
                    </Button>
                    <Button variant="outline" onClick={() => setIsEditing(false)}>
                      <X className="w-4 h-4 mr-2" />
                      {text.cancel}
                    </Button>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* User Posts Section */}
        <div className="mt-6">
          <h2 className="text-2xl mb-4">{text.posts}</h2>
          <div className="bg-white/90 backdrop-blur-xl rounded-3xl shadow-xl border border-white/20 p-6">
            <p className="text-center text-gray-500">
              {language === 'ps' ? 'د پوستونو سیستم په ګړندي توګه...' : 
               language === 'fa' ? 'سیستم پست‌ها به زودی...' : 
               'Posts system coming soon...'}
            </p>
          </div>
        </div>
      </div>

      {/* Report Modal */}
      {showReportModal && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <motion.div
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            className="bg-white rounded-3xl p-6 max-w-md w-full"
          >
            <h3 className="text-2xl mb-4">{text.reportUser}</h3>
            <p className="text-gray-600 mb-4">{text.reportReason}</p>
            
            <div className="space-y-2">
              {[
                { key: 'spam', label: text.spam },
                { key: 'harassment', label: text.harassment },
                { key: 'inappropriate', label: text.inappropriate },
                { key: 'fake', label: text.fake }
              ].map((reason) => (
                <button
                  key={reason.key}
                  onClick={() => handleReport(reason.key)}
                  className="w-full p-4 text-left border border-gray-200 rounded-xl hover:bg-gray-50 transition-all"
                >
                  {reason.label}
                </button>
              ))}
            </div>
            
            <Button
              variant="outline"
              className="w-full mt-4"
              onClick={() => setShowReportModal(false)}
            >
              {text.cancel}
            </Button>
          </motion.div>
        </div>
      )}
    </div>
  );
}
