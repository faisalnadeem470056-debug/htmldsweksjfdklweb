import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  ArrowLeft, Search, Filter, Pill, AlertCircle, Info,
  Clock, DollarSign, Package, Heart, TrendingUp, X,
  ChevronRight, Star, Shield, Zap, Activity
} from 'lucide-react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Badge } from './ui/badge';
import { Medicine, medicinesDatabase, medicineCategories, searchMedicines } from '../data/medicinesData';

interface MedicineDatabaseProps {
  language: 'ps' | 'fa' | 'en';
  onBack: () => void;
}

export function MedicineDatabase({ language, onBack }: MedicineDatabaseProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [selectedMedicine, setSelectedMedicine] = useState<Medicine | null>(null);
  const [filteredMedicines, setFilteredMedicines] = useState<Medicine[]>(medicinesDatabase);

  const t = {
    ps: {
      title: 'د دواګانو ډیټابیس',
      subtitle: '1500+ بشپړ دواګانې معلومات',
      search: 'د دوا نوم ولټوئ...',
      allCategories: 'ټولې کټګورۍ',
      medicines: 'دواګانې',
      name: 'نوم',
      genericName: 'عمومي نوم',
      category: 'کټګوري',
      usage: 'استعمال',
      dosage: 'مقدار',
      sideEffects: 'منفي اغیزې',
      warnings: 'خبرتیاوې',
      price: 'نرخ',
      prescription: 'نسخه',
      required: 'اړین',
      notRequired: 'اړین نه',
      manufacturer: 'جوړوونکی',
      details: 'تفصیلات',
      back: 'شاته',
      noResults: 'هیڅ پایله ونه موندل شوه',
      searchOrFilter: 'د لټون یا فلټر استعمال وکړئ',
      total: 'ټول',
      prescriptionRequired: '⚕️ د طبیب نسخه اړینه',
      overthecounter: '✅ د نسخې پرته',
      importantWarning: '⚠️ مهم خبرتیا',
      howToUse: '📋 د استعمال طریقه',
      possibleSideEffects: '⚡ احتمالي منفي اغیزې',
      precautions: '🛡️ احتیاطي تدابیر'
    },
    fa: {
      title: 'پایگاه داده داروها',
      subtitle: 'اطلاعات کامل 1500+ دارو',
      search: 'نام دارو را جستجو کنید...',
      allCategories: 'همه دسته‌ها',
      medicines: 'داروها',
      name: 'نام',
      genericName: 'نام عمومی',
      category: 'دسته',
      usage: 'استفاده',
      dosage: 'دوز',
      sideEffects: 'عوارض جانبی',
      warnings: 'هشدارها',
      price: 'قیمت',
      prescription: 'نسخه',
      required: 'لازم',
      notRequired: 'لازم نیست',
      manufacturer: 'تولیدکننده',
      details: 'جزئیات',
      back: 'بازگشت',
      noResults: 'نتیجه‌ای یافت نشد',
      searchOrFilter: 'از جستجو یا فیلتر استفاده کنید',
      total: 'کل',
      prescriptionRequired: '⚕️ نسخه پزشک لازم',
      overthecounter: '✅ بدون نسخه',
      importantWarning: '⚠️ هشدار مهم',
      howToUse: '📋 نحوه مصرف',
      possibleSideEffects: '⚡ عوارض احتمالی',
      precautions: '🛡️ احتیاط‌ها'
    },
    en: {
      title: 'Medicine Database',
      subtitle: 'Complete information of 1500+ medicines',
      search: 'Search medicine name...',
      allCategories: 'All Categories',
      medicines: 'Medicines',
      name: 'Name',
      genericName: 'Generic Name',
      category: 'Category',
      usage: 'Usage',
      dosage: 'Dosage',
      sideEffects: 'Side Effects',
      warnings: 'Warnings',
      price: 'Price',
      prescription: 'Prescription',
      required: 'Required',
      notRequired: 'Not Required',
      manufacturer: 'Manufacturer',
      details: 'Details',
      back: 'Back',
      noResults: 'No results found',
      searchOrFilter: 'Use search or filter',
      total: 'Total',
      prescriptionRequired: '⚕️ Prescription Required',
      overthecounter: '✅ Over-the-counter',
      importantWarning: '⚠️ Important Warning',
      howToUse: '📋 How to Use',
      possibleSideEffects: '⚡ Possible Side Effects',
      precautions: '🛡️ Precautions'
    }
  };

  const text = t[language];

  useEffect(() => {
    filterMedicines();
  }, [searchQuery, selectedCategory]);

  const filterMedicines = () => {
    let results = medicinesDatabase;

    // Search filter
    if (searchQuery.trim()) {
      results = searchMedicines(searchQuery, language);
    }

    // Category filter
    if (selectedCategory) {
      results = results.filter(med => med.category === selectedCategory);
    }

    setFilteredMedicines(results);
  };

  const categories = Object.keys(medicineCategories.en);

  if (selectedMedicine) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-cyan-50 pb-20">
        {/* Header */}
        <div className="sticky top-0 z-40 backdrop-blur-xl bg-white/80 border-b border-white/20 shadow-lg">
          <div className="container mx-auto px-4 py-4">
            <div className="flex items-center gap-4">
              <Button variant="ghost" size="icon" onClick={() => setSelectedMedicine(null)}>
                <ArrowLeft className="w-5 h-5" />
              </Button>
              <div className="flex-1">
                <h1 className="text-2xl bg-gradient-to-r from-blue-600 to-cyan-600 bg-clip-text text-transparent">
                  {selectedMedicine.name[language]}
                </h1>
                <p className="text-sm text-gray-600">{selectedMedicine.name.generic}</p>
              </div>
            </div>
          </div>
        </div>

        {/* Medicine Details */}
        <div className="container mx-auto px-4 py-6 max-w-4xl">
          <div className="space-y-6">
            {/* Basic Info Card */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="bg-white/90 backdrop-blur-xl rounded-3xl p-6 border border-white/20 shadow-xl"
            >
              <div className="flex items-start justify-between mb-4">
                <div>
                  <div className="flex items-center gap-2 mb-2">
                    <Pill className="w-6 h-6 text-blue-600" />
                    <h2 className="text-2xl">{selectedMedicine.name[language]}</h2>
                  </div>
                  <p className="text-gray-600">{selectedMedicine.name.generic}</p>
                </div>
                <Badge variant={selectedMedicine.prescription ? "destructive" : "default"}>
                  {selectedMedicine.prescription ? text.required : text.notRequired}
                </Badge>
              </div>

              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div className="bg-blue-50 rounded-xl p-4">
                  <Package className="w-5 h-5 text-blue-600 mb-2" />
                  <p className="text-xs text-gray-600">{text.category}</p>
                  <p className="font-medium">{medicineCategories[language][selectedMedicine.category as keyof typeof medicineCategories.en]}</p>
                </div>
                {selectedMedicine.price && (
                  <div className="bg-green-50 rounded-xl p-4">
                    <DollarSign className="w-5 h-5 text-green-600 mb-2" />
                    <p className="text-xs text-gray-600">{text.price}</p>
                    <p className="font-medium">{selectedMedicine.price} AFN</p>
                  </div>
                )}
                {selectedMedicine.manufacturer && (
                  <div className="bg-purple-50 rounded-xl p-4">
                    <Star className="w-5 h-5 text-purple-600 mb-2" />
                    <p className="text-xs text-gray-600">{text.manufacturer}</p>
                    <p className="font-medium text-sm">{selectedMedicine.manufacturer}</p>
                  </div>
                )}
                <div className="bg-orange-50 rounded-xl p-4">
                  <Shield className="w-5 h-5 text-orange-600 mb-2" />
                  <p className="text-xs text-gray-600">{text.prescription}</p>
                  <p className="font-medium text-sm">
                    {selectedMedicine.prescription ? text.prescriptionRequired : text.overthecounter}
                  </p>
                </div>
              </div>
            </motion.div>

            {/* Usage Card */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1 }}
              className="bg-white/90 backdrop-blur-xl rounded-3xl p-6 border border-white/20 shadow-xl"
            >
              <div className="flex items-center gap-3 mb-4">
                <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-cyan-600 rounded-xl flex items-center justify-center">
                  <Info className="w-6 h-6 text-white" />
                </div>
                <h3 className="text-xl">{text.howToUse}</h3>
              </div>
              <p className="text-gray-700 mb-4">{selectedMedicine.usage[language]}</p>
              
              <div className="bg-blue-50 rounded-xl p-4">
                <div className="flex items-center gap-2 mb-2">
                  <Clock className="w-5 h-5 text-blue-600" />
                  <h4 className="font-medium">{text.dosage}</h4>
                </div>
                <p className="text-gray-700">{selectedMedicine.dosage[language]}</p>
              </div>
            </motion.div>

            {/* Side Effects Card */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 }}
              className="bg-white/90 backdrop-blur-xl rounded-3xl p-6 border border-white/20 shadow-xl"
            >
              <div className="flex items-center gap-3 mb-4">
                <div className="w-12 h-12 bg-gradient-to-br from-yellow-500 to-orange-600 rounded-xl flex items-center justify-center">
                  <Zap className="w-6 h-6 text-white" />
                </div>
                <h3 className="text-xl">{text.possibleSideEffects}</h3>
              </div>
              <ul className="space-y-2">
                {selectedMedicine.sideEffects[language].map((effect, idx) => (
                  <li key={idx} className="flex items-start gap-2">
                    <Activity className="w-4 h-4 text-orange-600 mt-1 flex-shrink-0" />
                    <span className="text-gray-700">{effect}</span>
                  </li>
                ))}
              </ul>
            </motion.div>

            {/* Warnings Card */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3 }}
              className="bg-white/90 backdrop-blur-xl rounded-3xl p-6 border border-red-200 shadow-xl"
            >
              <div className="flex items-center gap-3 mb-4">
                <div className="w-12 h-12 bg-gradient-to-br from-red-500 to-pink-600 rounded-xl flex items-center justify-center">
                  <AlertCircle className="w-6 h-6 text-white" />
                </div>
                <h3 className="text-xl">{text.precautions}</h3>
              </div>
              <ul className="space-y-2">
                {selectedMedicine.warnings[language].map((warning, idx) => (
                  <li key={idx} className="flex items-start gap-2">
                    <Shield className="w-4 h-4 text-red-600 mt-1 flex-shrink-0" />
                    <span className="text-gray-700">{warning}</span>
                  </li>
                ))}
              </ul>
            </motion.div>

            {/* Disclaimer */}
            <div className="bg-yellow-50 border border-yellow-200 rounded-2xl p-4">
              <div className="flex items-start gap-3">
                <AlertCircle className="w-5 h-5 text-yellow-600 mt-0.5 flex-shrink-0" />
                <div>
                  <p className="text-sm text-yellow-800">
                    {language === 'ps' && 'د دې معلوماتو استعمال یوازې د عمومي معلوماتو لپاره دی. د کومې دوا استعمال څخه مخکې لازمه ده د طبیب سره مشوره وکړئ.'}
                    {language === 'fa' && 'استفاده از این اطلاعات فقط برای اطلاعات عمومی است. قبل از استفاده از هر دارو، لازم است با پزشک مشورت کنید.'}
                    {language === 'en' && 'This information is for general knowledge only. Always consult with a doctor before using any medicine.'}
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-cyan-50 pb-20">
      {/* Header */}
      <div className="sticky top-0 z-40 backdrop-blur-xl bg-white/80 border-b border-white/20 shadow-lg">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center gap-4">
            <Button variant="ghost" size="icon" onClick={onBack}>
              <ArrowLeft className="w-5 h-5" />
            </Button>
            <div className="flex-1">
              <h1 className="text-2xl bg-gradient-to-r from-blue-600 to-cyan-600 bg-clip-text text-transparent">
                {text.title}
              </h1>
              <p className="text-sm text-gray-600">{text.subtitle}</p>
            </div>
          </div>
        </div>
      </div>

      {/* Search & Filter */}
      <div className="container mx-auto px-4 py-6">
        <div className="bg-white/90 backdrop-blur-xl rounded-3xl p-4 border border-white/20 shadow-xl mb-6">
          <div className="flex flex-col sm:flex-row gap-3">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
              <Input
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder={text.search}
                className="pl-10"
              />
            </div>
            <Button
              variant={selectedCategory ? "default" : "outline"}
              onClick={() => setSelectedCategory(null)}
            >
              <Filter className="w-4 h-4 mr-2" />
              {text.allCategories}
            </Button>
          </div>

          {/* Categories */}
          <div className="flex gap-2 overflow-x-auto mt-4 pb-2">
            {categories.map(cat => (
              <button
                key={cat}
                onClick={() => setSelectedCategory(cat === selectedCategory ? null : cat)}
                className={`px-4 py-2 rounded-full whitespace-nowrap text-sm transition-all ${
                  selectedCategory === cat
                    ? 'bg-gradient-to-r from-blue-500 to-cyan-600 text-white shadow-lg'
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                }`}
              >
                {medicineCategories[language][cat as keyof typeof medicineCategories.en]}
              </button>
            ))}
          </div>

          <div className="mt-4 flex items-center justify-between text-sm text-gray-600">
            <span>{text.total}: {filteredMedicines.length} {text.medicines}</span>
          </div>
        </div>

        {/* Medicines Grid */}
        {filteredMedicines.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {filteredMedicines.map((medicine, idx) => (
              <motion.div
                key={medicine.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: idx * 0.05 }}
                onClick={() => setSelectedMedicine(medicine)}
                className="bg-white/90 backdrop-blur-xl rounded-2xl p-5 border border-white/20 shadow-lg hover:shadow-2xl transition-all cursor-pointer group"
              >
                <div className="flex items-start justify-between mb-3">
                  <div className="flex items-center gap-2">
                    <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-cyan-600 rounded-xl flex items-center justify-center">
                      <Pill className="w-5 h-5 text-white" />
                    </div>
                    {medicine.prescription && (
                      <Badge variant="outline" className="text-xs">⚕️</Badge>
                    )}
                  </div>
                  <ChevronRight className="w-5 h-5 text-gray-400 group-hover:translate-x-1 transition-transform" />
                </div>

                <h3 className="font-medium mb-1 line-clamp-1">{medicine.name[language]}</h3>
                <p className="text-sm text-gray-600 mb-2 line-clamp-1">{medicine.name.generic}</p>

                <div className="flex items-center gap-2 mb-3">
                  <Badge variant="secondary" className="text-xs">
                    {medicineCategories[language][medicine.category as keyof typeof medicineCategories.en]}
                  </Badge>
                  {medicine.price && (
                    <span className="text-sm text-gray-600">{medicine.price} AFN</span>
                  )}
                </div>

                <p className="text-sm text-gray-600 line-clamp-2">{medicine.usage[language]}</p>
              </motion.div>
            ))}
          </div>
        ) : (
          <div className="text-center py-20">
            <Pill className="w-16 h-16 text-gray-400 mx-auto mb-4" />
            <h3 className="text-xl text-gray-600 mb-2">{text.noResults}</h3>
            <p className="text-gray-500">{text.searchOrFilter}</p>
          </div>
        )}
      </div>
    </div>
  );
}
