/**
 * Simple Input Component - بغیر external dependencies
 */

import { forwardRef } from 'react';

interface InputProps extends React.InputHTMLAttributes<HTMLInputElement> {}

export const SimpleInput = forwardRef<HTMLInputElement, InputProps>(
  ({ className = '', type = 'text', ...props }, ref) => {
    return (
      <input
        type={type}
        ref={ref}
        className={`
          w-full px-4 py-3 rounded-xl
          border-2 border-gray-300
          bg-white
          text-gray-900
          placeholder:text-gray-400
          focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent
          disabled:opacity-50 disabled:cursor-not-allowed
          transition-all duration-200
          ${className}
        `}
        {...props}
      />
    );
  }
);

SimpleInput.displayName = 'SimpleInput';
