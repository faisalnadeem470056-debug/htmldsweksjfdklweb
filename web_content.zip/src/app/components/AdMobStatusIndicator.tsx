import { useState, useEffect } from "react";
import { Badge } from "./ui/badge";
import { Eye, EyeOff } from "lucide-react";
import { getAdMobConfig } from "../config/admob-config";

interface AdMobStatusIndicatorProps {
  position?: "top-left" | "top-right" | "bottom-left" | "bottom-right";
  show?: boolean;
}

export function AdMobStatusIndicator({ 
  position = "bottom-right",
  show = true 
}: AdMobStatusIndicatorProps) {
  const [config, setConfig] = useState(getAdMobConfig());
  const [isVisible, setIsVisible] = useState(show);

  useEffect(() => {
    // د Configuration تازه کړئ هر 2 ثانیه
    const interval = setInterval(() => {
      setConfig(getAdMobConfig());
    }, 2000);
    return () => clearInterval(interval);
  }, []);

  if (!isVisible) {
    return (
      <button
        onClick={() => setIsVisible(true)}
        className={`fixed z-50 p-2 bg-gray-200 hover:bg-gray-300 rounded-full shadow-lg transition-all ${getPositionClasses(position)}`}
      >
        <Eye className="w-4 h-4 text-gray-600" />
      </button>
    );
  }

  return (
    <div 
      className={`fixed z-50 glass-effect rounded-lg shadow-xl p-3 space-y-2 ${getPositionClasses(position)} max-w-[200px]`}
    >
      <div className="flex items-center justify-between">
        <p className="text-xs text-gray-600">AdMob Status</p>
        <button
          onClick={() => setIsVisible(false)}
          className="p-1 hover:bg-gray-200 rounded-full transition-all"
        >
          <EyeOff className="w-3 h-3 text-gray-500" />
        </button>
      </div>

      <div className="space-y-1.5">
        <div className="flex items-center justify-between">
          <span className="text-xs text-gray-600">Mode:</span>
          <Badge 
            variant={config.testMode ? "secondary" : "default"}
            className="text-xs px-2 py-0"
          >
            {config.testMode ? "Test" : "Prod"}
          </Badge>
        </div>

        <div className="flex items-center justify-between">
          <span className="text-xs text-gray-600">Ads:</span>
          <Badge 
            variant={config.showAds ? "default" : "destructive"}
            className="text-xs px-2 py-0"
          >
            {config.showAds ? "ON" : "OFF"}
          </Badge>
        </div>
      </div>

      {config.testMode && (
        <div className="pt-2 border-t border-gray-200">
          <p className="text-xs text-amber-600">
            ⚠️ Test Mode Active
          </p>
        </div>
      )}
    </div>
  );
}

function getPositionClasses(position: string): string {
  switch (position) {
    case "top-left":
      return "top-4 left-4";
    case "top-right":
      return "top-4 right-4";
    case "bottom-left":
      return "bottom-4 left-4";
    case "bottom-right":
      return "bottom-4 right-4";
    default:
      return "bottom-4 right-4";
  }
}
