import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  ArrowLeft, Search, AlertTriangle, Heart, Brain, Thermometer,
  Activity, Zap, Droplet, Wind, Eye, Ear, Users, Calendar,
  Clock, TrendingUp, CheckCircle, X, Plus, Minus, ChevronRight,
  Stethoscope, Pill, Hospital, Phone, Share2, ChevronDown
} from 'lucide-react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { AdBanner } from './AdBanner';

interface SymptomCheckerProps {
  language: 'ps' | 'fa' | 'en';
  onBack: () => void;
}

interface Symptom {
  id: string;
  name: { ps: string; fa: string; en: string };
  category: string;
  severity: 'mild' | 'moderate' | 'severe';
  icon: string;
}

interface DiagnosisResult {
  condition: { ps: string; fa: string; en: string };
  probability: number;
  description: { ps: string; fa: string; en: string };
  severity: 'mild' | 'moderate' | 'severe' | 'emergency';
  recommendations: { ps: string[]; fa: string[]; en: string[] };
  whenToSeek: { ps: string; fa: string; en: string };
  relatedSpecialist: { ps: string; fa: string; en: string };
}

const translations = {
  ps: {
    title: 'د نښو معاینه کوونکی',
    subtitle: 'خپلې نښې انتخاب کړئ او ممکنه تشخیص وګورئ',
    searchSymptoms: 'نښې ولټوئ...',
    selectedSymptoms: 'انتخاب شوي نښې',
    addSymptom: 'نښه اضافه کړئ',
    removeSymptom: 'لرې کړئ',
    checkSymptoms: 'نښې معاینه کړئ',
    reset: 'له سره پیل',
    selectAtLeast: 'لږترلږه ۱ نښه انتخاب کړئ',
    analyzing: 'معاینه کیږي...',
    results: 'نتیجې',
    possibleConditions: 'احتمالي ناروغۍ',
    probability: 'احتمال',
    severity: 'شدت',
    recommendations: 'سپارښتنې',
    whenToSeek: 'ډاکټر ته کله لاړ شئ',
    specialist: 'ماهر ډاکټر',
    disclaimer: 'خبرداري: دا یوازې معلوماتي موخو لپاره دی. د طبي مشورې لپاره ډاکټر ته مراجعه وکړئ.',
    emergency: 'بیړني!',
    seekImmediate: 'سمدستي طبي مرسته ترلاسه کړئ',
    call: 'زنګ ووهئ',
    categories: {
      general: 'عمومي',
      pain: 'درد',
      respiratory: 'تنفسي',
      digestive: 'هاضمه',
      neurological: 'عصبي',
      cardiovascular: 'زړه',
      skin: 'پوستکي',
      mental: 'رواني'
    },
    severityLevels: {
      mild: 'لږ',
      moderate: 'منځنی',
      severe: 'شدید',
      emergency: 'بیړني'
    },
    shareResults: 'نتیجې شریک کړئ',
    viewDoctors: 'ډاکټران وګورئ',
    bookAppointment: 'وخت ونیسئ',
    noSymptoms: 'هیڅ نښه ندي انتخاب شوې',
    selectSymptoms: 'لږترلږه ۱ نښه انتخاب کړئ',
    commonSymptoms: 'عام نښې',
    allSymptoms: 'ټولې نښې',
    duration: 'موده',
    days: 'ورځې',
    intensity: 'شدت',
    low: 'لږ',
    medium: 'منځنی',
    high: 'ډیر'
  },
  fa: {
    title: 'بررسی علائم',
    subtitle: 'علائم خود را انتخاب کنید و تشخیص احتمالی را ببینید',
    searchSymptoms: 'جستجوی علائم...',
    selectedSymptoms: 'علائم انتخاب شده',
    addSymptom: 'افزودن علامت',
    removeSymptom: 'حذف',
    checkSymptoms: 'بررسی علائم',
    reset: 'شروع مجدد',
    selectAtLeast: 'حداقل ۱ علامت انتخاب کنید',
    analyzing: 'در حال تحلیل...',
    results: 'نتایج',
    possibleConditions: 'بیماری‌های احتمالی',
    probability: 'احتمال',
    severity: 'شدت',
    recommendations: 'توصیه‌ها',
    whenToSeek: 'چه زمانی به پزشک مراجعه کنید',
    specialist: 'متخصص',
    disclaimer: 'هشدار: این فقط برای اطلاع است. برای مشاوره پزشکی به دکتر مراجعه کنید.',
    emergency: 'اضطراری!',
    seekImmediate: 'فوراً به دنبال کمک پزشکی باشید',
    call: 'تماس',
    categories: {
      general: 'عمومی',
      pain: 'درد',
      respiratory: 'تنفسی',
      digestive: 'گوارشی',
      neurological: 'عصبی',
      cardiovascular: 'قلبی',
      skin: 'پوستی',
      mental: 'روانی'
    },
    severityLevels: {
      mild: 'خفیف',
      moderate: 'متوسط',
      severe: 'شدید',
      emergency: 'اضطراری'
    },
    shareResults: 'اشتراک نتایج',
    viewDoctors: 'مشاهده پزشکان',
    bookAppointment: 'نوبت‌گیری',
    noSymptoms: 'هیچ علامتی انتخاب نشده',
    selectSymptoms: 'حداقل ۱ علامت انتخاب کنید',
    commonSymptoms: 'علائم رایج',
    allSymptoms: 'همه علائم',
    duration: 'مدت',
    days: 'روز',
    intensity: 'شدت',
    low: 'کم',
    medium: 'متوسط',
    high: 'زیاد'
  },
  en: {
    title: 'Symptom Checker',
    subtitle: 'Select your symptoms and see possible diagnosis',
    searchSymptoms: 'Search symptoms...',
    selectedSymptoms: 'Selected Symptoms',
    addSymptom: 'Add Symptom',
    removeSymptom: 'Remove',
    checkSymptoms: 'Check Symptoms',
    reset: 'Reset',
    selectAtLeast: 'Select at least 1 symptom',
    analyzing: 'Analyzing...',
    results: 'Results',
    possibleConditions: 'Possible Conditions',
    probability: 'Probability',
    severity: 'Severity',
    recommendations: 'Recommendations',
    whenToSeek: 'When to seek medical help',
    specialist: 'Specialist',
    disclaimer: 'Disclaimer: This is for informational purposes only. Consult a doctor for medical advice.',
    emergency: 'Emergency!',
    seekImmediate: 'Seek immediate medical attention',
    call: 'Call',
    categories: {
      general: 'General',
      pain: 'Pain',
      respiratory: 'Respiratory',
      digestive: 'Digestive',
      neurological: 'Neurological',
      cardiovascular: 'Cardiovascular',
      skin: 'Skin',
      mental: 'Mental Health'
    },
    severityLevels: {
      mild: 'Mild',
      moderate: 'Moderate',
      severe: 'Severe',
      emergency: 'Emergency'
    },
    shareResults: 'Share Results',
    viewDoctors: 'View Doctors',
    bookAppointment: 'Book Appointment',
    noSymptoms: 'No symptoms selected',
    selectSymptoms: 'Select at least 1 symptom',
    commonSymptoms: 'Common Symptoms',
    allSymptoms: 'All Symptoms',
    duration: 'Duration',
    days: 'days',
    intensity: 'Intensity',
    low: 'Low',
    medium: 'Medium',
    high: 'High'
  }
};

const symptomsList: Symptom[] = [
  // General
  { id: 'fever', name: { ps: 'تبه', fa: 'تب', en: 'Fever' }, category: 'general', severity: 'moderate', icon: '🌡️' },
  { id: 'fatigue', name: { ps: 'ستړیا', fa: 'خستگی', en: 'Fatigue' }, category: 'general', severity: 'mild', icon: '😴' },
  { id: 'weakness', name: { ps: 'کمزوري', fa: 'ضعف', en: 'Weakness' }, category: 'general', severity: 'mild', icon: '💪' },
  { id: 'chills', name: { ps: 'یخنی', fa: 'لرز', en: 'Chills' }, category: 'general', severity: 'moderate', icon: '🥶' },
  { id: 'night-sweats', name: { ps: 'شپنۍ خولې', fa: 'عرق شبانه', en: 'Night Sweats' }, category: 'general', severity: 'mild', icon: '💦' },
  
  // Pain
  { id: 'headache', name: { ps: 'سر درد', fa: 'سردرد', en: 'Headache' }, category: 'pain', severity: 'moderate', icon: '🤕' },
  { id: 'chest-pain', name: { ps: 'د سینې درد', fa: 'درد قفسه سینه', en: 'Chest Pain' }, category: 'pain', severity: 'severe', icon: '💔' },
  { id: 'abdominal-pain', name: { ps: 'د خیټې درد', fa: 'درد شکم', en: 'Abdominal Pain' }, category: 'pain', severity: 'moderate', icon: '🤰' },
  { id: 'back-pain', name: { ps: 'د شا درد', fa: 'کمردرد', en: 'Back Pain' }, category: 'pain', severity: 'mild', icon: '🔙' },
  { id: 'joint-pain', name: { ps: 'د مفصل درد', fa: 'درد مفاصل', en: 'Joint Pain' }, category: 'pain', severity: 'moderate', icon: '🦴' },
  { id: 'muscle-pain', name: { ps: 'د عضلاتو درد', fa: 'درد عضلانی', en: 'Muscle Pain' }, category: 'pain', severity: 'mild', icon: '💪' },

  // Respiratory
  { id: 'cough', name: { ps: 'ټوخی', fa: 'سرفه', en: 'Cough' }, category: 'respiratory', severity: 'moderate', icon: '😷' },
  { id: 'shortness-breath', name: { ps: 'د ساه تنګي', fa: 'تنگی نفس', en: 'Shortness of Breath' }, category: 'respiratory', severity: 'severe', icon: '😮‍💨' },
  { id: 'wheezing', name: { ps: 'د ساه غږ', fa: 'خس خس سینه', en: 'Wheezing' }, category: 'respiratory', severity: 'moderate', icon: '🫁' },
  { id: 'sore-throat', name: { ps: 'د ګلې درد', fa: 'گلودرد', en: 'Sore Throat' }, category: 'respiratory', severity: 'mild', icon: '🗣️' },
  { id: 'runny-nose', name: { ps: 'د پزې بهیدل', fa: 'آبریزش بینی', en: 'Runny Nose' }, category: 'respiratory', severity: 'mild', icon: '🤧' },
  { id: 'congestion', name: { ps: 'د پزې بندېدل', fa: 'گرفتگی بینی', en: 'Nasal Congestion' }, category: 'respiratory', severity: 'mild', icon: '👃' },

  // Digestive
  { id: 'nausea', name: { ps: 'زړه بدوالی', fa: 'حالت تهوع', en: 'Nausea' }, category: 'digestive', severity: 'moderate', icon: '🤢' },
  { id: 'vomiting', name: { ps: 'کانګې', fa: 'استفراغ', en: 'Vomiting' }, category: 'digestive', severity: 'moderate', icon: '🤮' },
  { id: 'diarrhea', name: { ps: 'نس', fa: 'اسهال', en: 'Diarrhea' }, category: 'digestive', severity: 'moderate', icon: '🚽' },
  { id: 'constipation', name: { ps: 'قبضیت', fa: 'یبوست', en: 'Constipation' }, category: 'digestive', severity: 'mild', icon: '⛔' },
  { id: 'bloating', name: { ps: 'د خیټې پړسوب', fa: 'نفخ شکم', en: 'Bloating' }, category: 'digestive', severity: 'mild', icon: '🎈' },
  { id: 'appetite-loss', name: { ps: 'د اشتها کمښت', fa: 'از دست دادن اشتها', en: 'Loss of Appetite' }, category: 'digestive', severity: 'moderate', icon: '🍽️' },

  // Neurological
  { id: 'dizziness', name: { ps: 'سر چکر', fa: 'سرگیجه', en: 'Dizziness' }, category: 'neurological', severity: 'moderate', icon: '😵' },
  { id: 'confusion', name: { ps: 'ګډوډي', fa: 'سردرگمی', en: 'Confusion' }, category: 'neurological', severity: 'severe', icon: '🤔' },
  { id: 'numbness', name: { ps: 'بې حسي', fa: 'بی‌حسی', en: 'Numbness' }, category: 'neurological', severity: 'moderate', icon: '🔌' },
  { id: 'tingling', name: { ps: 'خاروالی', fa: 'سوزن سوزن شدن', en: 'Tingling' }, category: 'neurological', severity: 'mild', icon: '⚡' },
  { id: 'seizures', name: { ps: 'میرګۍ', fa: 'تشنج', en: 'Seizures' }, category: 'neurological', severity: 'severe', icon: '⚠️' },
  { id: 'memory-loss', name: { ps: 'د حافظې کمښت', fa: 'از دست دادن حافظه', en: 'Memory Loss' }, category: 'neurological', severity: 'severe', icon: '🧠' },

  // Cardiovascular
  { id: 'palpitations', name: { ps: 'د زړه ټکان', fa: 'تپش قلب', en: 'Heart Palpitations' }, category: 'cardiovascular', severity: 'moderate', icon: '💓' },
  { id: 'irregular-heartbeat', name: { ps: 'نا منظم زړه ټکان', fa: 'ضربان نامنظم قلب', en: 'Irregular Heartbeat' }, category: 'cardiovascular', severity: 'severe', icon: '💔' },
  { id: 'swelling', name: { ps: 'پړسوب', fa: 'تورم', en: 'Swelling' }, category: 'cardiovascular', severity: 'moderate', icon: '🦵' },
  { id: 'fainting', name: { ps: 'بې هوشي', fa: 'غش', en: 'Fainting' }, category: 'cardiovascular', severity: 'severe', icon: '😵‍💫' },

  // Skin
  { id: 'rash', name: { ps: 'خارښت', fa: 'بثورات', en: 'Rash' }, category: 'skin', severity: 'mild', icon: '🔴' },
  { id: 'itching', name: { ps: 'خارښ', fa: 'خارش', en: 'Itching' }, category: 'skin', severity: 'mild', icon: '🤚' },
  { id: 'bruising', name: { ps: 'د وینې غوټۍ', fa: 'کبودی', en: 'Bruising' }, category: 'skin', severity: 'moderate', icon: '🟣' },
  { id: 'pale-skin', name: { ps: 'رنګ پريوتل', fa: 'رنگ پریدگی', en: 'Pale Skin' }, category: 'skin', severity: 'moderate', icon: '👻' },

  // Mental
  { id: 'anxiety', name: { ps: 'اضطراب', fa: 'اضطراب', en: 'Anxiety' }, category: 'mental', severity: 'moderate', icon: '😰' },
  { id: 'depression', name: { ps: 'افسردګي', fa: 'افسردگی', en: 'Depression' }, category: 'mental', severity: 'moderate', icon: '😔' },
  { id: 'insomnia', name: { ps: 'بې خوبي', fa: 'بی‌خوابی', en: 'Insomnia' }, category: 'mental', severity: 'moderate', icon: '😴' },
  { id: 'irritability', name: { ps: 'جلنديتوب', fa: 'تحریک‌پذیری', en: 'Irritability' }, category: 'mental', severity: 'mild', icon: '😠' }
];

// AI Diagnosis Logic
const diagnosisDatabase: { [key: string]: DiagnosisResult } = {
  'fever-cough-fatigue': {
    condition: { ps: 'زکام یا انفلونزا', fa: 'سرماخوردگی یا آنفولانزا', en: 'Common Cold or Influenza' },
    probability: 85,
    description: {
      ps: 'دا د ویروسي انتانونو معمول نښې دي. ډیری خلک ۷-۱۰ ورځو کې روغ کیږي.',
      fa: 'این علائم معمول عفونت‌های ویروسی است. اکثر افراد در ۷-۱۰ روز بهبود می‌یابند.',
      en: 'These are common symptoms of viral infections. Most people recover in 7-10 days.'
    },
    severity: 'moderate',
    recommendations: {
      ps: [
        '✓ آرام او استراحت وکړئ',
        '✓ ډیره اوبه وڅښئ',
        '✓ د تبې لپاره Paracetamol واخلئ',
        '✓ توده سوپ وڅښئ',
        '✓ د نورو څخه لرې پاتې شئ'
      ],
      fa: [
        '✓ استراحت کنید',
        '✓ مایعات زیاد بنوشید',
        '✓ برای تب پاراستامول مصرف کنید',
        '✓ سوپ گرم بنوشید',
        '✓ از دیگران دوری کنید'
      ],
      en: [
        '✓ Get plenty of rest',
        '✓ Drink lots of fluids',
        '✓ Take Paracetamol for fever',
        '✓ Drink warm soup',
        '✓ Avoid contact with others'
      ]
    },
    whenToSeek: {
      ps: 'که تبه د ۳ ورځو څخه زیاته وي، د ساه تنګي وي، یا نښې خراب شي',
      fa: 'اگر تب بیش از ۳ روز طول بکشد، تنگی نفس داشته باشید، یا علائم بدتر شود',
      en: 'If fever persists beyond 3 days, you have difficulty breathing, or symptoms worsen'
    },
    relatedSpecialist: {
      ps: 'عمومي ډاکټر',
      fa: 'پزشک عمومی',
      en: 'General Physician'
    }
  },
  'chest-pain-shortness-breath': {
    condition: { ps: 'د زړه اړوند خطر', fa: 'خطر قلبی', en: 'Possible Cardiac Emergency' },
    probability: 75,
    description: {
      ps: 'د سینې درد او د ساه تنګي د زړه د مسلو نښې کیدای شي. بیړني طبي پاملرنې ته اړتیا ده!',
      fa: 'درد قفسه سینه و تنگی نفس می‌تواند نشانه مشکلات قلبی باشد. نیاز به مراقبت فوری پزشکی!',
      en: 'Chest pain with shortness of breath can indicate heart problems. Requires immediate medical attention!'
    },
    severity: 'emergency',
    recommendations: {
      ps: [
        '🚨 سمدستي ۱۱۹ ته زنګ ووهئ',
        '✓ کښېنئ او آرام اوسئ',
        '✓ کښتۍ درمل (Aspirin) وخورئ',
        '✓ د خپل کالر خلاص کړئ',
        '✓ د امبولانس انتظار وکړئ'
      ],
      fa: [
        '🚨 فوراً با ۱۱۹ تماس بگیرید',
        '✓ بنشینید و آرام باشید',
        '✓ آسپرین مصرف کنید',
        '✓ یقه خود را باز کنید',
        '✓ منتظر آمبولانس بمانید'
      ],
      en: [
        '🚨 Call 119 immediately',
        '✓ Sit down and stay calm',
        '✓ Take Aspirin if available',
        '✓ Loosen your collar',
        '✓ Wait for ambulance'
      ]
    },
    whenToSeek: {
      ps: 'سمدستي! دا یو طبي بیړنی حالت دی',
      fa: 'فوری! این یک اضطرار پزشکی است',
      en: 'Immediately! This is a medical emergency'
    },
    relatedSpecialist: {
      ps: 'د زړه ماهر',
      fa: 'متخصص قلب',
      en: 'Cardiologist'
    }
  },
  'headache-fever-confusion': {
    condition: { ps: 'د دماغي جھيلي التہاب (مننجائٹس)', fa: 'مننژیت (التهاب مننژ)', en: 'Possible Meningitis' },
    probability: 70,
    description: {
      ps: 'دا د دماغي جھيلي د التهاب نښې کیدای شي. خطرناک حالت دی چې بیړني پاملرنې ته اړتیا لري.',
      fa: 'این می‌تواند نشانه التهاب مننژ باشد. وضعیت خطرناکی که نیاز به مراقبت فوری دارد.',
      en: 'This could indicate meningitis. A serious condition requiring urgent care.'
    },
    severity: 'emergency',
    recommendations: {
      ps: [
        '🚨 سمدستي روغتون ته لاړ شئ',
        '✓ د رڼا څخه لرې پاتې شئ',
        '✓ آرام پروت شئ',
        '✓ د نورو څخه جلا پاتې شئ'
      ],
      fa: [
        '🚨 فوراً به بیمارستان بروید',
        '✓ از نور دوری کنید',
        '✓ آرام بخوابید',
        '✓ از دیگران جدا باشید'
      ],
      en: [
        '🚨 Go to hospital immediately',
        '✓ Avoid bright lights',
        '✓ Lie down quietly',
        '✓ Isolate from others'
      ]
    },
    whenToSeek: {
      ps: 'سمدستي روغتون ته لاړ شئ!',
      fa: 'فوراً به بیمارستان مراجعه کنید!',
      en: 'Go to hospital immediately!'
    },
    relatedSpecialist: {
      ps: 'د عصبي نظام ماهر',
      fa: 'متخصص مغز و اعصاب',
      en: 'Neurologist'
    }
  },
  'abdominal-pain-nausea-vomiting': {
    condition: { ps: 'د معدې ناروغي یا خوراکي مسمومیت', fa: 'عفونت معده یا مسمومیت غذایی', en: 'Gastroenteritis or Food Poisoning' },
    probability: 80,
    description: {
      ps: 'دا د معدې د انتان یا خوراکي مسمومیت معمول نښې دي. ډیری خلک څو ورځو کې روغ کیږي.',
      fa: 'این علائم معمول عفونت معده یا مسمومیت غذایی است. اکثر افراد در چند روز بهبود می‌یابند.',
      en: 'Common symptoms of stomach infection or food poisoning. Most people recover in a few days.'
    },
    severity: 'moderate',
    recommendations: {
      ps: [
        '✓ ډیرې مایعات وڅښئ (ORS)',
        '✓ د اسانه خوړو څخه ګټه واخلئ',
        '✓ د خوړو څخه لږ وقفه وکړئ',
        '✓ د Loperamide یا ورته درمل واخلئ',
        '✓ پاکې اوبه وڅښئ'
      ],
      fa: [
        '✓ مایعات زیاد بنوشید (ORS)',
        '✓ از غذاهای ساده استفاده کنید',
        '✓ از خوردن کمی استراحت کنید',
        '✓ لوپرامید یا داروی مشابه مصرف کنید',
        '✓ آب تمیز بنوشید'
      ],
      en: [
        '✓ Drink plenty of fluids (ORS)',
        '✓ Eat bland foods',
        '✓ Rest your stomach',
        '✓ Take Loperamide if needed',
        '✓ Drink clean water'
      ]
    },
    whenToSeek: {
      ps: 'که د وینې نس، شدید درد، یا د ۲ ورځو څخه زیات د اوبو کموالی وي',
      fa: 'اگر اسهال خونی، درد شدید، یا کم‌آبی بیش از ۲ روز داشته باشید',
      en: 'If you have bloody diarrhea, severe pain, or dehydration lasting more than 2 days'
    },
    relatedSpecialist: {
      ps: 'د هاضمې ماهر',
      fa: 'متخصص گوارش',
      en: 'Gastroenterologist'
    }
  },
  'cough-shortness-breath-wheezing': {
    condition: { ps: 'دمه (Asthma) یا د ریو انتان', fa: 'آسم یا عفونت ریوی', en: 'Asthma or Respiratory Infection' },
    probability: 75,
    description: {
      ps: 'دا د دمې یا د ریو د انتان نښې کیدای شي. د ساه د سیسټم د ارزونې ته اړتیا ده.',
      fa: 'این می‌تواند نشانه آسم یا عفونت ریوی باشد. نیاز به ارزیابی سیستم تنفسی دارد.',
      en: 'Could indicate asthma or respiratory infection. Requires respiratory system evaluation.'
    },
    severity: 'moderate',
    recommendations: {
      ps: [
        '✓ Inhaler واستعمال کړئ (که لرئ)',
        '✓ په مستقیم حالت کې کښېنئ',
        '✓ د تنګو او تودو ځایونو څخه لرې شئ',
        '✓ ډیره اوبه وڅښئ',
        '✓ د Steam واخلئ'
      ],
      fa: [
        '✓ از اینهیلر استفاده کنید (اگر دارید)',
        '✓ در حالت عمودی بنشینید',
        '✓ از محیط‌های شلوغ و گرم دوری کنید',
        '✓ مایعات زیاد بنوشید',
        '✓ بخار آب بگیرید'
      ],
      en: [
        '✓ Use inhaler if available',
        '✓ Sit upright',
        '✓ Avoid crowded, hot places',
        '✓ Drink plenty of fluids',
        '✓ Use steam inhalation'
      ]
    },
    whenToSeek: {
      ps: 'که د ساه تنګي خرابه شي، شونډې نیلګونې شي، یا خبرې نشئ کولی',
      fa: 'اگر تنگی نفس بدتر شود، لب‌ها کبود شود، یا نتوانید صحبت کنید',
      en: 'If breathing worsens, lips turn blue, or you cannot speak'
    },
    relatedSpecialist: {
      ps: 'د ریو ماهر',
      fa: 'متخصص ریه',
      en: 'Pulmonologist'
    }
  },
  'dizziness-palpitations-fainting': {
    condition: { ps: 'د وینې فشار کمښت یا د زړه مسله', fa: 'فشار خون پایین یا مشکل قلبی', en: 'Low Blood Pressure or Cardiac Issue' },
    probability: 70,
    description: {
      ps: 'دا د وینې د فشار د کمښت یا د زړه د مسلو نښې کیدای شي. د طبي ارزونې ته اړتیا ده.',
      fa: 'این می‌تواند نشانه فشار خون پایین یا مشکلات قلبی باشد. نیاز به ارزیابی پزشکی دارد.',
      en: 'Could indicate low blood pressure or heart problems. Requires medical evaluation.'
    },
    severity: 'moderate',
    recommendations: {
      ps: [
        '✓ آهسته پورته شئ',
        '✓ ډیره مالګه او اوبه واخلئ',
        '✓ د پښو لوړول',
        '✓ د ټایټ جامو څخه مخنیوی',
        '✓ د وینې فشار معاینه کړئ'
      ],
      fa: [
        '✓ آهسته بلند شوید',
        '✓ نمک و مایعات زیاد مصرف کنید',
        '✓ پاهای خود را بالا نگه دارید',
        '✓ از لباس‌های تنگ خودداری کنید',
        '✓ فشار خون را چک کنید'
      ],
      en: [
        '✓ Rise slowly from sitting',
        '✓ Increase salt and fluid intake',
        '✓ Elevate your legs',
        '✓ Avoid tight clothing',
        '✓ Check blood pressure'
      ]
    },
    whenToSeek: {
      ps: 'که ډیری وارې بې هوشه شئ، د سینې درد ولرئ، یا غیرمنظم زړه ټکان ولرئ',
      fa: 'اگر مکرر غش کنید، درد قفسه سینه داشته باشید، یا ضربان قلب نامنظم باشد',
      en: 'If you faint repeatedly, have chest pain, or irregular heartbeat'
    },
    relatedSpecialist: {
      ps: 'د زړه ماهر',
      fa: 'متخصص قلب',
      en: 'Cardiologist'
    }
  },
  'anxiety-insomnia-fatigue': {
    condition: { ps: 'اضطراب او فشار', fa: 'اضطراب و استرس', en: 'Anxiety and Stress' },
    probability: 80,
    description: {
      ps: 'دا د اضطراب او رواني فشار معمول نښې دي. د رواني روغتیا پاملرنې ته اړتیا ده.',
      fa: 'این علائم معمول اضطراب و فشار روانی است. نیاز به مراقبت سلامت روان دارد.',
      en: 'Common symptoms of anxiety and stress. Mental health support is recommended.'
    },
    severity: 'moderate',
    recommendations: {
      ps: [
        '✓ د ژورې ساه تمرینونه وکړئ',
        '✓ منظم ورزش وکړئ',
        '✓ کافي خوب ترلاسه کړئ',
        '✓ د Meditation او Yoga وکړئ',
        '✓ د مشورې تر لاسه کولو په هکله فکر وکړئ'
      ],
      fa: [
        '✓ تمرین‌های تنفس عمیق انجام دهید',
        '✓ ورزش منظم داشته باشید',
        '✓ خواب کافی داشته باشید',
        '✓ مدیتیشن و یوگا انجام دهید',
        '✓ مشاوره را در نظر بگیرید'
      ],
      en: [
        '✓ Practice deep breathing',
        '✓ Exercise regularly',
        '✓ Get adequate sleep',
        '✓ Try meditation and yoga',
        '✓ Consider counseling'
      ]
    },
    whenToSeek: {
      ps: 'که د ځان وژنې فکرونه ولرئ، د ورځني ژوند کې ستونزې ولرئ، یا په ځان کنټرول نشئ کولی',
      fa: 'اگر افکار خودکشی داشته باشید، در زندگی روزمره مشکل داشته باشید، یا نتوانید کنترل کنید',
      en: 'If you have suicidal thoughts, daily life is impaired, or you cannot cope'
    },
    relatedSpecialist: {
      ps: 'رواني روغتیا ماهر',
      fa: 'متخصص سلامت روان',
      en: 'Mental Health Specialist'
    }
  }
};

export function SymptomChecker({ language, onBack }: SymptomCheckerProps) {
  const [selectedSymptoms, setSelectedSymptoms] = useState<string[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [results, setResults] = useState<DiagnosisResult[]>([]);
  const [showResults, setShowResults] = useState(false);

  const t = translations[language];
  const isRTL = language === 'ps' || language === 'fa';

  // Filter symptoms
  const filteredSymptoms = symptomsList.filter(symptom => {
    const matchesSearch = symptom.name[language].toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = selectedCategory === 'all' || symptom.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  // Add symptom
  const addSymptom = (symptomId: string) => {
    if (!selectedSymptoms.includes(symptomId)) {
      setSelectedSymptoms([...selectedSymptoms, symptomId]);
    }
  };

  // Remove symptom
  const removeSymptom = (symptomId: string) => {
    setSelectedSymptoms(selectedSymptoms.filter(id => id !== symptomId));
  };

  // AI Diagnosis Engine
  const analyzeSymptoms = () => {
    if (selectedSymptoms.length === 0) {
      alert(t.selectAtLeast);
      return;
    }

    setIsAnalyzing(true);
    setShowResults(false);

    // Simulate AI analysis
    setTimeout(() => {
      const diagnosisResults: DiagnosisResult[] = [];
      
      // Check for specific combinations
      const symptomKeys = selectedSymptoms.sort().join('-');
      
      // Emergency conditions check
      if (selectedSymptoms.includes('chest-pain') && selectedSymptoms.includes('shortness-breath')) {
        diagnosisResults.push(diagnosisDatabase['chest-pain-shortness-breath']);
      } else if (selectedSymptoms.includes('headache') && selectedSymptoms.includes('fever') && selectedSymptoms.includes('confusion')) {
        diagnosisResults.push(diagnosisDatabase['headache-fever-confusion']);
      } else if (selectedSymptoms.includes('fever') && selectedSymptoms.includes('cough') && selectedSymptoms.includes('fatigue')) {
        diagnosisResults.push(diagnosisDatabase['fever-cough-fatigue']);
      } else if (selectedSymptoms.includes('abdominal-pain') && selectedSymptoms.includes('nausea') && selectedSymptoms.includes('vomiting')) {
        diagnosisResults.push(diagnosisDatabase['abdominal-pain-nausea-vomiting']);
      } else if (selectedSymptoms.includes('cough') && selectedSymptoms.includes('shortness-breath') && selectedSymptoms.includes('wheezing')) {
        diagnosisResults.push(diagnosisDatabase['cough-shortness-breath-wheezing']);
      } else if (selectedSymptoms.includes('dizziness') && selectedSymptoms.includes('palpitations')) {
        diagnosisResults.push(diagnosisDatabase['dizziness-palpitations-fainting']);
      } else if (selectedSymptoms.includes('anxiety') && selectedSymptoms.includes('insomnia')) {
        diagnosisResults.push(diagnosisDatabase['anxiety-insomnia-fatigue']);
      } else {
        // Default generic diagnosis based on category
        const categories = selectedSymptoms.map(id => {
          const symptom = symptomsList.find(s => s.id === id);
          return symptom?.category;
        });
        
        if (categories.includes('respiratory')) {
          diagnosisResults.push({
            condition: {
              ps: 'د تنفسي نظام ناروغي',
              fa: 'بیماری دستگاه تنفسی',
              en: 'Respiratory System Disorder'
            },
            probability: 70,
            description: {
              ps: 'ستاسو نښې د تنفسي نظام د مسلو نښه ده. د ډاکټر سره مشوره وکړئ.',
              fa: 'علائم شما نشانه مشکلات دستگاه تنفسی است. با پزشک مشورت کنید.',
              en: 'Your symptoms indicate respiratory system issues. Consult a doctor.'
            },
            severity: 'moderate',
            recommendations: {
              ps: ['✓ ډاکټر ته مراجعه وکړئ', '✓ آرام او استراحت وکړئ', '✓ ډیره اوبه وڅښئ'],
              fa: ['✓ به پزشک مراجعه کنید', '✓ استراحت کنید', '✓ مایعات زیاد بنوشید'],
              en: ['✓ Consult a doctor', '✓ Get rest', '✓ Drink plenty of fluids']
            },
            whenToSeek: {
              ps: 'که نښې خراب شي',
              fa: 'اگر علائم بدتر شود',
              en: 'If symptoms worsen'
            },
            relatedSpecialist: {
              ps: 'عمومي ډاکټر',
              fa: 'پزشک عمومی',
              en: 'General Physician'
            }
          });
        } else {
          diagnosisResults.push({
            condition: {
              ps: 'عمومي ناروغي',
              fa: 'بیماری عمومی',
              en: 'General Medical Condition'
            },
            probability: 60,
            description: {
              ps: 'ستاسو نښې مختلف حالتونه ښکاره کوي. د بشپړ ارزونې لپاره ډاکټر ته مراجعه وکړئ.',
              fa: 'علائم شما حالت‌های مختلف را نشان می‌دهد. برای ارزیابی کامل به پزشک مراجعه کنید.',
              en: 'Your symptoms indicate various conditions. See a doctor for complete evaluation.'
            },
            severity: 'moderate',
            recommendations: {
              ps: ['✓ ډاکټر ته مراجعه وکړئ', '✓ د نښو یادښت وکړئ', '✓ آرام او استراحت وکړئ'],
              fa: ['✓ به پزشک مراجعه کنید', '✓ علائم را یادداشت کنید', '✓ استراحت کنید'],
              en: ['✓ See a doctor', '✓ Keep track of symptoms', '✓ Get rest']
            },
            whenToSeek: {
              ps: 'د ډاکټر سره مشوره وکړئ',
              fa: 'با پزشک مشورت کنید',
              en: 'Consult a doctor'
            },
            relatedSpecialist: {
              ps: 'عمومي ډاکټر',
              fa: 'پزشک عمومی',
              en: 'General Physician'
            }
          });
        }
      }

      setResults(diagnosisResults);
      setIsAnalyzing(false);
      setShowResults(true);
    }, 2000);
  };

  // Reset
  const handleReset = () => {
    setSelectedSymptoms([]);
    setSearchTerm('');
    setShowResults(false);
    setResults([]);
  };

  // Share results
  const handleShare = async () => {
    const selectedNames = selectedSymptoms.map(id => {
      const symptom = symptomsList.find(s => s.id === id);
      return symptom?.name[language];
    }).join(', ');

    const message = `${t.title}\n\n${t.selectedSymptoms}: ${selectedNames}\n\n${results[0]?.condition[language]}\n${t.probability}: ${results[0]?.probability}%\n\nHealMate - Your Health Companion`;

    if (navigator.share) {
      try {
        await navigator.share({ title: t.title, text: message });
      } catch (err) {
        // که share ناکامه شي، په clipboard کې کاپي کړه
        if (err instanceof Error && err.name !== 'AbortError') {
          navigator.clipboard.writeText(message);
          alert(language === 'ps' ? 'کاپي شو!' : language === 'fa' ? 'کپی شد!' : 'Copied!');
        }
      }
    } else {
      navigator.clipboard.writeText(message);
      alert(language === 'ps' ? 'کاپي شو!' : language === 'fa' ? 'کپی شد!' : 'Copied!');
    }
  };

  return (
    <div className={`min-h-screen bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50 ${isRTL ? 'rtl' : 'ltr'}`}>
      {/* Header */}
      <div className="sticky top-0 z-40 bg-white/80 backdrop-blur-lg border-b border-blue-200">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between mb-4">
            <button
              onClick={onBack}
              className={`flex items-center gap-2 text-gray-700 hover:text-blue-600 transition-colors ${isRTL ? 'flex-row-reverse' : ''}`}
            >
              <ArrowLeft className={`w-5 h-5 ${isRTL ? 'rotate-180' : ''}`} />
              <span>{language === 'ps' ? 'شاته' : language === 'fa' ? 'بازگشت' : 'Back'}</span>
            </button>
            {selectedSymptoms.length > 0 && (
              <Button
                onClick={handleReset}
                className="bg-red-500 text-white hover:bg-red-600 text-sm py-2"
              >
                {t.reset}
              </Button>
            )}
          </div>

          <div className="text-center mb-4">
            <h1 className="text-3xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent mb-2 flex items-center justify-center gap-3">
              <Stethoscope className="w-8 h-8 text-blue-600" />
              {t.title}
            </h1>
            <p className="text-gray-600">{t.subtitle}</p>
          </div>
        </div>
      </div>

      {/* AdBanner */}
      <div className="container mx-auto px-4 py-4">
        <AdBanner variant="horizontal" />
      </div>

      <div className="container mx-auto px-4 pb-8">
        {!showResults ? (
          <>
            {/* Search */}
            <div className="mb-6">
              <div className="relative">
                <Search className={`absolute ${isRTL ? 'right-4' : 'left-4'} top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400`} />
                <Input
                  type="text"
                  placeholder={t.searchSymptoms}
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className={`w-full ${isRTL ? 'pr-12 pl-4' : 'pl-12 pr-4'} py-4 rounded-2xl border-2 border-blue-200 focus:border-blue-400 bg-white shadow-md`}
                />
              </div>
            </div>

            {/* Categories */}
            <div className="flex items-center gap-2 overflow-x-auto pb-4 mb-6">
              {['all', ...Object.keys(t.categories)].map((category) => (
                <button
                  key={category}
                  onClick={() => setSelectedCategory(category)}
                  className={`px-4 py-2 rounded-xl whitespace-nowrap transition-all ${
                    selectedCategory === category
                      ? 'bg-gradient-to-r from-blue-600 to-purple-600 text-white shadow-lg'
                      : 'bg-white text-gray-700 hover:bg-blue-50 shadow-md'
                  }`}
                >
                  {category === 'all' ? (language === 'ps' ? 'ټول' : language === 'fa' ? 'همه' : 'All') : t.categories[category as keyof typeof t.categories]}
                </button>
              ))}
            </div>

            {/* Selected Symptoms */}
            {selectedSymptoms.length > 0 && (
              <div className="bg-white rounded-3xl shadow-lg p-6 mb-6">
                <h2 className="text-xl font-bold text-gray-900 mb-4 flex items-center gap-2">
                  <CheckCircle className="w-6 h-6 text-green-500" />
                  {t.selectedSymptoms} ({selectedSymptoms.length})
                </h2>
                <div className="flex flex-wrap gap-2 mb-4">
                  {selectedSymptoms.map(symptomId => {
                    const symptom = symptomsList.find(s => s.id === symptomId);
                    return (
                      <motion.div
                        key={symptomId}
                        initial={{ scale: 0 }}
                        animate={{ scale: 1 }}
                        exit={{ scale: 0 }}
                        className="bg-gradient-to-r from-blue-100 to-purple-100 px-4 py-2 rounded-xl flex items-center gap-2 shadow-md"
                      >
                        <span>{symptom?.icon}</span>
                        <span className="font-semibold text-gray-800">{symptom?.name[language]}</span>
                        <button
                          onClick={() => removeSymptom(symptomId)}
                          className="ml-2 p-1 hover:bg-red-200 rounded-full transition-colors"
                        >
                          <X className="w-4 h-4 text-red-600" />
                        </button>
                      </motion.div>
                    );
                  })}
                </div>
                <Button
                  onClick={analyzeSymptoms}
                  disabled={isAnalyzing}
                  className="w-full bg-gradient-to-r from-blue-600 to-purple-600 text-white py-4 rounded-2xl font-bold hover:shadow-xl transition-all disabled:opacity-50"
                >
                  {isAnalyzing ? (
                    <>
                      <Activity className="w-5 h-5 mr-2 animate-spin" />
                      {t.analyzing}
                    </>
                  ) : (
                    <>
                      <Stethoscope className="w-5 h-5 mr-2" />
                      {t.checkSymptoms}
                    </>
                  )}
                </Button>
              </div>
            )}

            {/* Symptoms List */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {filteredSymptoms.map((symptom, index) => {
                const isSelected = selectedSymptoms.includes(symptom.id);
                
                return (
                  <motion.button
                    key={symptom.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: index * 0.05 }}
                    onClick={() => isSelected ? removeSymptom(symptom.id) : addSymptom(symptom.id)}
                    className={`bg-white rounded-2xl p-4 shadow-md hover:shadow-xl transition-all text-left ${
                      isSelected ? 'ring-4 ring-blue-500 bg-blue-50' : ''
                    }`}
                  >
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-3xl">{symptom.icon}</span>
                      {isSelected ? (
                        <CheckCircle className="w-6 h-6 text-blue-600" />
                      ) : (
                        <Plus className="w-6 h-6 text-gray-400" />
                      )}
                    </div>
                    <h3 className="font-bold text-gray-900 mb-1">{symptom.name[language]}</h3>
                    <div className="flex items-center gap-2 text-xs">
                      <span className={`px-2 py-1 rounded-lg ${
                        symptom.severity === 'severe' ? 'bg-red-100 text-red-700' :
                        symptom.severity === 'moderate' ? 'bg-yellow-100 text-yellow-700' :
                        'bg-green-100 text-green-700'
                      }`}>
                        {t.severityLevels[symptom.severity]}
                      </span>
                    </div>
                  </motion.button>
                );
              })}
            </div>
          </>
        ) : (
          /* Results */
          <div className="space-y-6">
            {/* Disclaimer */}
            <div className="bg-yellow-50 border-2 border-yellow-200 rounded-2xl p-4 flex items-start gap-3">
              <AlertTriangle className="w-6 h-6 text-yellow-600 flex-shrink-0 mt-1" />
              <p className="text-yellow-800 text-sm">{t.disclaimer}</p>
            </div>

            {/* Results */}
            {results.map((result, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="bg-white rounded-3xl shadow-xl overflow-hidden"
              >
                {/* Header */}
                <div className={`p-6 ${
                  result.severity === 'emergency' ? 'bg-gradient-to-r from-red-500 to-pink-600' :
                  result.severity === 'severe' ? 'bg-gradient-to-r from-orange-500 to-red-500' :
                  result.severity === 'moderate' ? 'bg-gradient-to-r from-yellow-500 to-orange-500' :
                  'bg-gradient-to-r from-green-500 to-teal-500'
                } text-white`}>
                  <div className="flex items-center justify-between mb-3">
                    <h2 className="text-2xl font-bold">{result.condition[language]}</h2>
                    {result.severity === 'emergency' && (
                      <AlertTriangle className="w-8 h-8 animate-pulse" />
                    )}
                  </div>
                  <div className="flex items-center gap-4 text-sm">
                    <div className="flex items-center gap-2">
                      <TrendingUp className="w-5 h-5" />
                      <span>{t.probability}: {result.probability}%</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Activity className="w-5 h-5" />
                      <span>{t.severity}: {t.severityLevels[result.severity]}</span>
                    </div>
                  </div>
                </div>

                {/* Emergency Warning */}
                {result.severity === 'emergency' && (
                  <div className="bg-red-50 border-l-4 border-red-500 p-4">
                    <div className="flex items-center gap-3 mb-2">
                      <AlertTriangle className="w-6 h-6 text-red-600" />
                      <h3 className="font-bold text-red-900 text-lg">{t.emergency}</h3>
                    </div>
                    <p className="text-red-800 mb-3">{t.seekImmediate}</p>
                    <Button
                      onClick={() => window.location.href = 'tel:119'}
                      className="w-full bg-red-600 text-white hover:bg-red-700 py-3 rounded-xl font-bold"
                    >
                      <Phone className="w-5 h-5 mr-2" />
                      {t.call} 119
                    </Button>
                  </div>
                )}

                {/* Description */}
                <div className="p-6 border-b border-gray-100">
                  <p className="text-gray-700 leading-relaxed">{result.description[language]}</p>
                </div>

                {/* Recommendations */}
                <div className="p-6 bg-blue-50">
                  <h3 className="font-bold text-gray-900 mb-3 flex items-center gap-2">
                    <Pill className="w-5 h-5 text-blue-600" />
                    {t.recommendations}
                  </h3>
                  <ul className="space-y-2">
                    {result.recommendations[language].map((rec, i) => (
                      <li key={i} className="text-gray-700 flex items-start gap-2">
                        <span className="text-green-500 mt-1">•</span>
                        <span>{rec}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                {/* When to Seek Help */}
                <div className="p-6 bg-orange-50 border-b border-gray-100">
                  <h3 className="font-bold text-gray-900 mb-2 flex items-center gap-2">
                    <Clock className="w-5 h-5 text-orange-600" />
                    {t.whenToSeek}
                  </h3>
                  <p className="text-gray-700">{result.whenToSeek[language]}</p>
                </div>

                {/* Specialist */}
                <div className="p-6 bg-purple-50">
                  <h3 className="font-bold text-gray-900 mb-2 flex items-center gap-2">
                    <Users className="w-5 h-5 text-purple-600" />
                    {t.specialist}
                  </h3>
                  <p className="text-gray-700">{result.relatedSpecialist[language]}</p>
                </div>

                {/* Actions */}
                <div className="p-6 flex gap-3">
                  <Button
                    onClick={handleShare}
                    className="flex-1 bg-blue-500 text-white hover:bg-blue-600 py-3 rounded-xl"
                  >
                    <Share2 className="w-5 h-5 mr-2" />
                    {t.shareResults}
                  </Button>
                  <Button
                    onClick={() => {
                      handleReset();
                      // Navigate to doctors page would go here
                    }}
                    className="flex-1 bg-gradient-to-r from-purple-600 to-pink-600 text-white hover:shadow-lg py-3 rounded-xl"
                  >
                    <Hospital className="w-5 h-5 mr-2" />
                    {t.viewDoctors}
                  </Button>
                </div>
              </motion.div>
            ))}

            {/* Check Again */}
            <Button
              onClick={handleReset}
              className="w-full bg-white text-gray-700 hover:bg-gray-100 py-4 rounded-2xl font-bold shadow-lg border-2 border-gray-200"
            >
              <ArrowLeft className={`w-5 h-5 mr-2 ${isRTL ? 'rotate-180' : ''}`} />
              {language === 'ps' ? 'بیرته معاینه کړئ' : language === 'fa' ? 'بررسی مجدد' : 'Check Again'}
            </Button>
          </div>
        )}
      </div>
    </div>
  );
}
