import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Crown, X, Sparkles, Star, Zap } from 'lucide-react';
import { premiumManager } from '../utils/PremiumManager';

interface PremiumFloatingButtonProps {
  currentPage: string;
  userId: string;
  onNavigateToPremium: () => void;
  language: 'ps' | 'fa' | 'en';
}

const translations = {
  ps: {
    getPremium: 'پریمیم ترلاسه کړئ',
    unlockFeatures: 'بشپړ ځانګړتیاوې خلاصې کړئ',
    upgrade: 'اپګریډ کړئ',
    premium: 'پریمیم',
    viewPlans: 'پلانونه وګورئ',
    limited: '⏰ محدود وخت',
    discount: '17% تخفیف',
  },
  fa: {
    getPremium: 'پریمیوم دریافت کنید',
    unlockFeatures: 'ویژگی‌های کامل را باز کنید',
    upgrade: 'ارتقا دهید',
    premium: 'پریمیوم',
    viewPlans: 'مشاهده پلان‌ها',
    limited: '⏰ زمان محدود',
    discount: '17% تخفیف',
  },
  en: {
    getPremium: 'Get Premium',
    unlockFeatures: 'Unlock Full Features',
    upgrade: 'Upgrade',
    premium: 'Premium',
    viewPlans: 'View Plans',
    limited: '⏰ Limited Time',
    discount: '17% Off',
  },
};

export function PremiumFloatingButton({ 
  currentPage, 
  userId, 
  onNavigateToPremium,
  language 
}: PremiumFloatingButtonProps) {
  const [isExpanded, setIsExpanded] = useState(false);
  const [showBadge, setShowBadge] = useState(true);
  const [isPremium, setIsPremium] = useState(false);
  
  const t = translations[language];

  // د Premium status چک کړئ
  useEffect(() => {
    if (userId) {
      const premium = premiumManager.isPremium(userId);
      setIsPremium(premium);
    }
  }, [userId]);

  // د expiry reminder چک کړئ (د Premium users لپاره)
  useEffect(() => {
    if (isPremium && userId) {
      const reminder = premiumManager.checkExpiryReminder(userId, language);
      if (reminder) {
        // Show reminder notification
        console.log('[Premium] Expiry reminder:', reminder);
        // دلته notification ښکاره کړئ
      }
    }
  }, [isPremium, userId, language]);

  // Auto-collapse after 5 seconds
  useEffect(() => {
    if (isExpanded) {
      const timer = setTimeout(() => {
        setIsExpanded(false);
      }, 5000);
      return () => clearTimeout(timer);
    }
  }, [isExpanded]);

  // Hide on premium page or if already premium
  if (currentPage === 'premium' || isPremium) {
    return null;
  }

  // Hide if not authenticated
  if (!userId) {
    return null;
  }

  return (
    <motion.div
      className="fixed bottom-24 right-4 z-40"
      initial={{ scale: 0, opacity: 0 }}
      animate={{ scale: 1, opacity: 1 }}
      transition={{ type: 'spring', delay: 0.5 }}
    >
      <AnimatePresence mode="wait">
        {!isExpanded ? (
          // Collapsed Button
          <motion.button
            key="collapsed"
            initial={{ scale: 0 }}
            animate={{ scale: 1, rotate: [0, -10, 10, -10, 0] }}
            exit={{ scale: 0 }}
            transition={{
              scale: { type: 'spring', stiffness: 200 },
              rotate: { duration: 0.5, repeat: Infinity, repeatDelay: 3 },
            }}
            onClick={() => setIsExpanded(true)}
            className="relative group"
          >
            {/* Glow Effect */}
            <div className="absolute inset-0 bg-gradient-to-r from-yellow-400 via-orange-500 to-pink-600 rounded-full blur-xl opacity-75 group-hover:opacity-100 animate-pulse" />
            
            {/* Main Button */}
            <div className="relative bg-gradient-to-r from-yellow-400 via-orange-500 to-pink-600 p-4 rounded-full shadow-2xl hover:shadow-3xl transition-all">
              <Crown className="w-8 h-8 text-white" />
              
              {/* Badge */}
              {showBadge && (
                <motion.div
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  className="absolute -top-1 -right-1 bg-red-500 text-white text-xs px-2 py-1 rounded-full font-bold border-2 border-white shadow-lg"
                >
                  NEW
                </motion.div>
              )}
              
              {/* Sparkles */}
              <Sparkles className="absolute -top-2 -right-2 w-4 h-4 text-yellow-300 animate-pulse" />
              <Sparkles className="absolute -bottom-2 -left-2 w-4 h-4 text-pink-300 animate-pulse" />
            </div>
          </motion.button>
        ) : (
          // Expanded Card
          <motion.div
            key="expanded"
            initial={{ scale: 0, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0, opacity: 0 }}
            className="bg-white rounded-3xl shadow-2xl overflow-hidden w-80 border-4 border-transparent"
            style={{
              background: 'linear-gradient(white, white) padding-box, linear-gradient(135deg, #fbbf24, #f97316, #ec4899) border-box',
            }}
          >
            {/* Header */}
            <div className="bg-gradient-to-r from-yellow-400 via-orange-500 to-pink-600 p-4 relative overflow-hidden">
              {/* Background Pattern */}
              <div className="absolute inset-0 opacity-20">
                <div className="absolute inset-0" style={{
                  backgroundImage: 'repeating-linear-gradient(45deg, transparent, transparent 10px, rgba(255,255,255,.1) 10px, rgba(255,255,255,.1) 20px)'
                }} />
              </div>
              
              <div className="relative flex items-center justify-between text-white">
                <div className="flex items-center gap-2">
                  <Crown className="w-6 h-6" />
                  <div>
                    <h3 className="font-bold">{t.premium}</h3>
                    <p className="text-xs opacity-90">{t.unlockFeatures}</p>
                  </div>
                </div>
                <button
                  onClick={() => setIsExpanded(false)}
                  className="p-1 hover:bg-white/20 rounded-full transition-colors"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            {/* Content */}
            <div className="p-4">
              {/* Limited Time Offer */}
              <div className="bg-gradient-to-r from-red-50 to-orange-50 border-2 border-red-200 rounded-2xl p-3 mb-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-bold text-red-700">{t.limited}</p>
                    <p className="text-xs text-red-600">{t.discount}</p>
                  </div>
                  <div className="bg-red-500 text-white px-3 py-1 rounded-full text-xs font-bold animate-pulse">
                    🔥 HOT
                  </div>
                </div>
              </div>

              {/* Features Preview */}
              <div className="space-y-2 mb-4">
                {[
                  { icon: '🩺', text: language === 'ps' ? 'بشپړ ډاکټران' : language === 'fa' ? 'داکتران کامل' : 'Complete Doctors' },
                  { icon: '💊', text: language === 'ps' ? '1500+ درمل' : language === 'fa' ? '1500+ دارو' : '1500+ Medicines' },
                  { icon: '🤖', text: language === 'ps' ? 'AI چټ' : language === 'fa' ? 'چت AI' : 'AI Chat' },
                  { icon: '⚡', text: language === 'ps' ? 'بې اعلاناتو' : language === 'fa' ? 'بدون اعلانات' : 'Ad-Free' },
                ].map((feature, index) => (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: index * 0.1 }}
                    className="flex items-center gap-2 text-sm"
                  >
                    <span className="text-2xl">{feature.icon}</span>
                    <span className="text-gray-700">{feature.text}</span>
                  </motion.div>
                ))}
              </div>

              {/* CTA Button */}
              <button
                onClick={() => {
                  setIsExpanded(false);
                  setShowBadge(false);
                  onNavigateToPremium();
                }}
                className="w-full bg-gradient-to-r from-yellow-400 via-orange-500 to-pink-600 text-white py-3 rounded-xl font-bold shadow-lg hover:shadow-xl transition-all flex items-center justify-center gap-2 group"
              >
                <Zap className="w-5 h-5 group-hover:animate-bounce" />
                {t.viewPlans}
                <Star className="w-5 h-5 group-hover:animate-spin" />
              </button>

              {/* Close Text */}
              <p className="text-center text-xs text-gray-500 mt-3">
                {language === 'ps' ? 'د بندولو لپاره click کړئ' : 
                 language === 'fa' ? 'برای بستن کلیک کنید' : 
                 'Click anywhere to close'}
              </p>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
}
