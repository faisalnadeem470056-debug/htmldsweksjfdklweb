import { useState } from "react";
import { LoginForm } from "./LoginForm";
import { SignUpForm } from "./SignUpForm";
import { ForgotPasswordForm } from "./ForgotPasswordForm";
import { LanguageSwitcher } from "./LanguageSwitcher";
import { AuthDebugHelper } from "./AuthDebugHelper";
import logoImage from "figma:asset/ba48654895779a4ce2efe10c107b371087cee470.png";

type AuthView = "login" | "signup" | "forgot";

interface AuthScreenProps {
  onAuthSuccess: () => void;
}

export function AuthScreen({ onAuthSuccess }: AuthScreenProps) {
  const [currentView, setCurrentView] = useState<AuthView>("login");

  return (
    <div className="min-h-screen bg-gradient-to-br from-emerald-50 via-white to-blue-50 flex items-center justify-center p-4 relative overflow-hidden">
      {/* Background Decorations */}
      <div className="absolute top-0 left-0 w-[500px] h-[500px] bg-gradient-to-br from-emerald-200/30 to-blue-200/30 rounded-full blur-3xl animate-float"></div>
      <div className="absolute bottom-0 right-0 w-[600px] h-[600px] bg-gradient-to-tl from-purple-200/30 to-pink-200/30 rounded-full blur-3xl animate-float-slow"></div>
      
      {/* Language Switcher */}
      <div className="absolute top-4 right-4 z-10">
        <LanguageSwitcher />
      </div>

      {/* Logo */}
      <div className="absolute top-4 left-4 z-10">
        <img src={logoImage} alt="HealMate" className="h-12 w-auto" />
      </div>

      {/* Auth Form Container */}
      <div className="w-full max-w-md relative z-10">
        <div className="mb-8 text-center animate-fade-in">
          <img src={logoImage} alt="HealMate" className="h-20 w-auto mx-auto mb-4" />
          <h1 className="text-4xl gradient-text mb-2">HealMate</h1>
          <p className="text-gray-600">
            د افغانستان لومړنی بشپړ روغتیا اپلیکیشن
          </p>
          <p className="text-gray-600 text-sm">
            Afghanistan's Complete Healthcare App
          </p>
        </div>

        <div className="animate-fade-in">
          {currentView === "login" && (
            <LoginForm
              onSwitchToSignup={() => setCurrentView("signup")}
              onSwitchToForgot={() => setCurrentView("forgot")}
              onSuccess={onAuthSuccess}
            />
          )}

          {currentView === "signup" && (
            <SignUpForm
              onSwitchToLogin={() => setCurrentView("login")}
              onSuccess={onAuthSuccess}
            />
          )}

          {currentView === "forgot" && (
            <ForgotPasswordForm
              onSwitchToLogin={() => setCurrentView("login")}
            />
          )}
        </div>

        {/* Footer */}
        <div className="mt-8 text-center text-sm text-gray-500 space-y-1">
          <p>© 2025 HealMate. All rights reserved.</p>
          <p className="text-xs">
            📧 ibrahimkhaksar.it@gmail.com | 📱 +93783040441
          </p>
        </div>
      </div>

      {/* Debug Helper - د Development لپاره */}
      <AuthDebugHelper />
    </div>
  );
}
