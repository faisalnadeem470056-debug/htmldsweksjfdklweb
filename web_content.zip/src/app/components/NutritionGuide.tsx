import { useState } from 'react';
import { Search, Apple, ArrowLeft, Leaf, Beef, Milk, Wheat } from 'lucide-react';
import { motion } from 'motion/react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { translations } from '../translations';
import { AdBanner } from './AdBanner';

interface NutritionGuideProps {
  language: 'ps' | 'fa' | 'en';
  onBack: () => void;
}

const foods = [
  {
    id: 1,
    name: { ps: 'مڼې', fa: 'سیب', en: 'Apple' },
    icon: Apple,
    color: 'from-red-500 to-pink-500',
    calories: 95,
    protein: 0.5,
    carbs: 25,
    fats: 0.3,
    benefits: {
      ps: 'د زړه روغتیا، د وزن کمول، د معدې پاکول',
      fa: 'سلامت قلب، کاهش وزن، پاکسازی معده',
      en: 'Heart health, weight loss, digestion',
    },
  },
  {
    id: 2,
    name: { ps: 'چرګ', fa: 'مرغ', en: 'Chicken' },
    icon: Beef,
    color: 'from-orange-500 to-amber-500',
    calories: 165,
    protein: 31,
    carbs: 0,
    fats: 3.6,
    benefits: {
      ps: 'د پروټین سرچینه، د عضلاتو جوړول، د وزن کنټرول',
      fa: 'منبع پروتئین، ساخت عضله، کنترل وزن',
      en: 'Protein source, muscle building, weight control',
    },
  },
  {
    id: 3,
    name: { ps: 'شودې', fa: 'شیر', en: 'Milk' },
    icon: Milk,
    color: 'from-blue-400 to-cyan-500',
    calories: 149,
    protein: 8,
    carbs: 12,
    fats: 8,
    benefits: {
      ps: 'کلسیم، د هډوکو قوت، ویتامین D',
      fa: 'کلسیم، استحکام استخوان، ویتامین D',
      en: 'Calcium, bone strength, Vitamin D',
    },
  },
  {
    id: 4,
    name: { ps: 'وریجې', fa: 'برنج', en: 'Rice' },
    icon: Wheat,
    color: 'from-yellow-500 to-orange-500',
    calories: 206,
    protein: 4.3,
    carbs: 45,
    fats: 0.4,
    benefits: {
      ps: 'انرژي، کاربوهایډریټ، د معدې لپاره اسان',
      fa: 'انرژی، کربوهیدرات، آسان برای معده',
      en: 'Energy, carbohydrates, easy on stomach',
    },
  },
  {
    id: 5,
    name: { ps: 'پالک', fa: 'اسفناج', en: 'Spinach' },
    icon: Leaf,
    color: 'from-green-500 to-emerald-500',
    calories: 23,
    protein: 2.9,
    carbs: 3.6,
    fats: 0.4,
    benefits: {
      ps: 'اوسپنه، ویتامینونه، د سترګو روغتیا',
      fa: 'آهن، ویتامین‌ها، سلامت چشم',
      en: 'Iron, vitamins, eye health',
    },
  },
  {
    id: 6,
    name: { ps: 'کیله', fa: 'موز', en: 'Banana' },
    icon: Apple,
    color: 'from-yellow-400 to-yellow-600',
    calories: 105,
    protein: 1.3,
    carbs: 27,
    fats: 0.4,
    benefits: {
      ps: 'پوتاشیم، انرژي، د زړه روغتیا',
      fa: 'پتاسیم، انرژی، سلامت قلب',
      en: 'Potassium, energy, heart health',
    },
  },
  {
    id: 7,
    name: { ps: 'کچالو', fa: 'گوجه فرنگی', en: 'Tomato' },
    icon: Apple,
    color: 'from-red-600 to-rose-600',
    calories: 22,
    protein: 1.1,
    carbs: 4.8,
    fats: 0.2,
    benefits: {
      ps: 'لایکوپین، د سرطان مخنیوی، د پوستکي روغتیا',
      fa: 'لیکوپن، پیشگیری از سرطان، سلامت پوست',
      en: 'Lycopene, cancer prevention, skin health',
    },
  },
  {
    id: 8,
    name: { ps: 'بادام', fa: 'بادام', en: 'Almonds' },
    icon: Apple,
    color: 'from-amber-600 to-orange-700',
    calories: 164,
    protein: 6,
    carbs: 6,
    fats: 14,
    benefits: {
      ps: 'ویتامین E، د دماغ روغتیا، د زړه ساتنه',
      fa: 'ویتامین E، سلامت مغز، حفظ قلب',
      en: 'Vitamin E, brain health, heart protection',
    },
  },
];

export function NutritionGuide({ language, onBack }: NutritionGuideProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const t = translations[language];

  const filteredFoods = foods.filter(food =>
    food.name[language].toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="min-h-screen bg-gradient-to-br from-teal-50 via-cyan-50 to-blue-50 pb-28 md:pb-12">
      {/* Header */}
      <div className="sticky top-[73px] z-30 backdrop-blur-xl bg-white/70 border-b border-white/20 shadow-lg">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center gap-4 mb-4">
            <Button variant="ghost" size="icon" onClick={onBack}>
              <ArrowLeft className="w-5 h-5" />
            </Button>
            <div>
              <h1 className="text-2xl bg-gradient-to-r from-teal-600 to-cyan-600 bg-clip-text text-transparent">
                {t.nutritionGuide}
              </h1>
              <p className="text-sm text-gray-600">{foods.length} Foods</p>
            </div>
          </div>

          {/* Search */}
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
            <Input
              type="text"
              placeholder={t.searchFood}
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10 bg-white/80 backdrop-blur-md border-white/20"
            />
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="container mx-auto px-4 mt-6">
        <AdBanner type="medium" className="mb-8" />

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredFoods.map((food, index) => {
            const Icon = food.icon;
            return (
              <motion.div
                key={food.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                className="relative group"
              >
                <div className={`absolute inset-0 bg-gradient-to-br ${food.color} opacity-20 rounded-3xl blur-xl group-hover:blur-2xl transition-all`} />
                <div className="relative bg-white/90 backdrop-blur-xl rounded-3xl p-6 border border-white/20 shadow-xl hover:shadow-2xl transition-all">
                  {/* Header */}
                  <div className="flex items-center gap-4 mb-4">
                    <div className={`w-14 h-14 bg-gradient-to-br ${food.color} rounded-2xl flex items-center justify-center flex-shrink-0 group-hover:scale-110 transition-transform`}>
                      <Icon className="w-7 h-7 text-white" />
                    </div>
                    <div>
                      <h3 className="text-lg">{food.name[language]}</h3>
                      <p className="text-sm text-gray-600">{food.calories} {t.calories}</p>
                    </div>
                  </div>

                  {/* Nutrition Facts */}
                  <div className="grid grid-cols-3 gap-3 mb-4">
                    <div className="bg-gradient-to-br from-blue-50 to-blue-100/50 rounded-xl p-3 text-center">
                      <p className="text-xs text-gray-600 mb-1">{t.protein}</p>
                      <p className={`bg-gradient-to-r ${food.color} bg-clip-text text-transparent`}>
                        {food.protein}g
                      </p>
                    </div>
                    <div className="bg-gradient-to-br from-green-50 to-green-100/50 rounded-xl p-3 text-center">
                      <p className="text-xs text-gray-600 mb-1">{t.carbs}</p>
                      <p className={`bg-gradient-to-r ${food.color} bg-clip-text text-transparent`}>
                        {food.carbs}g
                      </p>
                    </div>
                    <div className="bg-gradient-to-br from-orange-50 to-orange-100/50 rounded-xl p-3 text-center">
                      <p className="text-xs text-gray-600 mb-1">{t.fats}</p>
                      <p className={`bg-gradient-to-r ${food.color} bg-clip-text text-transparent`}>
                        {food.fats}g
                      </p>
                    </div>
                  </div>

                  {/* Benefits */}
                  <div>
                    <p className="text-sm text-gray-600 mb-2">{t.benefits}:</p>
                    <p className="text-sm text-gray-700">{food.benefits[language]}</p>
                  </div>
                </div>
              </motion.div>
            );
          })}
        </div>

        <AdBanner type="large" className="mt-8" />

        {/* Daily Nutrition Tips */}
        <div className="mt-8 grid grid-cols-1 md:grid-cols-2 gap-6">
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            className="relative group"
          >
            <div className="absolute inset-0 bg-gradient-to-br from-green-500 to-emerald-600 rounded-3xl blur-2xl opacity-30 group-hover:opacity-50 transition-all" />
            <div className="relative bg-gradient-to-br from-green-600 to-emerald-600 rounded-3xl p-6 text-white">
              <h3 className="text-xl mb-3">
                {language === 'ps' && '🥗 متوازن خوراک'}
                {language === 'fa' && '🥗 غذای متعادل'}
                {language === 'en' && '🥗 Balanced Diet'}
              </h3>
              <p className="text-sm opacity-90">
                {language === 'ps' && 'په ورځ کې مختلف رنګونه خوړل - میوې، سابه، پروټین او دانې.'}
                {language === 'fa' && 'روزانه رنگ‌های مختلف بخورید - میوه‌ها، سبزیجات، پروتئین و غلات.'}
                {language === 'en' && 'Eat different colors daily - fruits, vegetables, proteins, and grains.'}
              </p>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            className="relative group"
          >
            <div className="absolute inset-0 bg-gradient-to-br from-blue-500 to-cyan-600 rounded-3xl blur-2xl opacity-30 group-hover:opacity-50 transition-all" />
            <div className="relative bg-gradient-to-br from-blue-600 to-cyan-600 rounded-3xl p-6 text-white">
              <h3 className="text-xl mb-3">
                {language === 'ps' && '💧 د اوبو اهمیت'}
                {language === 'fa' && '💧 اهمیت آب'}
                {language === 'en' && '💧 Water Importance'}
              </h3>
              <p className="text-sm opacity-90">
                {language === 'ps' && 'د خوړو سره اوبه وښئ. دا د هضم کولو او د غذایي موادو جذب کولو کې مرسته کوي.'}
                {language === 'fa' && 'با غذا آب بنوشید. این به هضم و جذب مواد مغذی کمک می‌کند.'}
                {language === 'en' && 'Drink water with meals. This helps digestion and nutrient absorption.'}
              </p>
            </div>
          </motion.div>
        </div>
      </div>
    </div>
  );
}
