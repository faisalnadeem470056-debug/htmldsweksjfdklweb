import { motion } from 'motion/react';
import { Pill, Clock, Bell, Plus, Check, X, Calendar, AlertCircle, ArrowLeft } from 'lucide-react';
import { useState } from 'react';

interface MedicineReminderProps {
  language: 'ps' | 'fa' | 'en';
  onBack?: () => void;
}

interface Medicine {
  id: number;
  name: string;
  dosage: string;
  time: string;
  frequency: string;
  taken: boolean;
  color: string;
}

export function MedicineReminder({ language, onBack }: MedicineReminderProps) {
  const [medicines, setMedicines] = useState<Medicine[]>([
    {
      id: 1,
      name: language === 'ps' ? 'پینسیلین' : language === 'fa' ? 'پنی‌سیلین' : 'Penicillin',
      dosage: '500mg',
      time: '08:00 AM',
      frequency: language === 'ps' ? 'هره ورځ' : language === 'fa' ? 'هر روز' : 'Daily',
      taken: true,
      color: 'from-blue-500 to-cyan-600'
    },
    {
      id: 2,
      name: language === 'ps' ? 'وټامین D' : language === 'fa' ? 'ویتامین D' : 'Vitamin D',
      dosage: '1000 IU',
      time: '12:00 PM',
      frequency: language === 'ps' ? 'هره ورځ' : language === 'fa' ? 'هر روز' : 'Daily',
      taken: false,
      color: 'from-yellow-500 to-orange-600'
    },
    {
      id: 3,
      name: language === 'ps' ? 'اومیپرازول' : language === 'fa' ? 'اُمپرازول' : 'Omeprazole',
      dosage: '20mg',
      time: '08:00 PM',
      frequency: language === 'ps' ? 'هره ورځ' : language === 'fa' ? 'هر روز' : 'Daily',
      taken: false,
      color: 'from-purple-500 to-violet-600'
    }
  ]);

  const [showAddForm, setShowAddForm] = useState(false);

  const translations = {
    ps: {
      title: 'د درملو یادونه',
      subtitle: 'خپل درمل په وخت واخلئ',
      addMedicine: 'نوی درمل',
      today: 'نن',
      upcoming: 'راتلونکي',
      history: 'تاریخچه',
      taken: 'اخیستل شوی',
      pending: 'پاتې',
      markTaken: 'د اخیستل نښه',
      skip: 'پریښودل',
      medicineName: 'د درملو نوم',
      dosage: 'خوراک',
      time: 'وخت',
      frequency: 'تکرار',
      save: 'خوندي کول',
      cancel: 'لغوه کول',
      notifications: 'خبرتیاوې فعالې دي',
      nextDose: 'بل خوراک',
      streak: 'دوام',
      days: 'ورځې'
    },
    fa: {
      title: 'یادآور دارو',
      subtitle: 'دارو خود را به موقع بخورید',
      addMedicine: 'دارو جدید',
      today: 'امروز',
      upcoming: 'آینده',
      history: 'تاریخچه',
      taken: 'مصرف شده',
      pending: 'در انتظار',
      markTaken: 'علامت مصرف',
      skip: 'رد شدن',
      medicineName: 'نام دارو',
      dosage: 'دوز',
      time: 'زمان',
      frequency: 'تکرار',
      save: 'ذخیره',
      cancel: 'لغو',
      notifications: 'اعلان‌ها فعال است',
      nextDose: 'دوز بعدی',
      streak: 'پیوستگی',
      days: 'روز'
    },
    en: {
      title: 'Medicine Reminder',
      subtitle: 'Take your medicine on time',
      addMedicine: 'Add Medicine',
      today: 'Today',
      upcoming: 'Upcoming',
      history: 'History',
      taken: 'Taken',
      pending: 'Pending',
      markTaken: 'Mark Taken',
      skip: 'Skip',
      medicineName: 'Medicine Name',
      dosage: 'Dosage',
      time: 'Time',
      frequency: 'Frequency',
      save: 'Save',
      cancel: 'Cancel',
      notifications: 'Notifications enabled',
      nextDose: 'Next dose',
      streak: 'Streak',
      days: 'days'
    }
  };

  const t = translations[language];

  const toggleTaken = (id: number) => {
    setMedicines(medicines.map(med => 
      med.id === id ? { ...med, taken: !med.taken } : med
    ));
  };

  const takenCount = medicines.filter(m => m.taken).length;
  const totalCount = medicines.length;

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50 p-4 md:p-8">
      <div className="container mx-auto max-w-4xl">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-8"
        >
          <div className="inline-flex items-center justify-center w-16 h-16 bg-gradient-to-br from-blue-500 to-indigo-600 rounded-2xl mb-4">
            <Pill className="w-8 h-8 text-white" />
          </div>
          <h1 className="text-3xl font-bold text-gray-900 mb-2">{t.title}</h1>
          <p className="text-gray-600">{t.subtitle}</p>
        </motion.div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="bg-white rounded-2xl p-6 border-2 border-green-200"
          >
            <div className="flex items-center gap-3 mb-3">
              <div className="p-3 bg-gradient-to-br from-green-500 to-emerald-600 rounded-xl">
                <Check className="w-6 h-6 text-white" />
              </div>
              <h3 className="font-bold text-gray-900">{t.today}</h3>
            </div>
            <p className="text-3xl font-bold text-green-600">{takenCount}/{totalCount}</p>
            <p className="text-sm text-gray-600 mt-1">{t.taken}</p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="bg-white rounded-2xl p-6 border-2 border-orange-200"
          >
            <div className="flex items-center gap-3 mb-3">
              <div className="p-3 bg-gradient-to-br from-orange-500 to-amber-600 rounded-xl">
                <Clock className="w-6 h-6 text-white" />
              </div>
              <h3 className="font-bold text-gray-900">{t.nextDose}</h3>
            </div>
            <p className="text-3xl font-bold text-orange-600">12:00</p>
            <p className="text-sm text-gray-600 mt-1">PM</p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
            className="bg-white rounded-2xl p-6 border-2 border-purple-200"
          >
            <div className="flex items-center gap-3 mb-3">
              <div className="p-3 bg-gradient-to-br from-purple-500 to-violet-600 rounded-xl">
                <Calendar className="w-6 h-6 text-white" />
              </div>
              <h3 className="font-bold text-gray-900">{t.streak}</h3>
            </div>
            <p className="text-3xl font-bold text-purple-600">7</p>
            <p className="text-sm text-gray-600 mt-1">{t.days}</p>
          </motion.div>
        </div>

        {/* Add Button */}
        <motion.button
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.4 }}
          onClick={() => setShowAddForm(!showAddForm)}
          className="w-full bg-gradient-to-r from-indigo-600 to-purple-600 text-white py-4 rounded-2xl font-semibold mb-6 flex items-center justify-center gap-2 hover:shadow-xl transition-all"
        >
          <Plus className="w-5 h-5" />
          {t.addMedicine}
        </motion.button>

        {/* Add Form */}
        {showAddForm && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="bg-white rounded-2xl p-6 mb-6 border-2 border-indigo-200"
          >
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">{t.medicineName}</label>
                <input
                  type="text"
                  className="w-full px-4 py-3 border-2 border-gray-200 rounded-xl focus:border-indigo-500 focus:outline-none"
                  placeholder={language === 'ps' ? 'د درملو نوم' : language === 'fa' ? 'نام دارو' : 'Enter medicine name'}
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-2">{t.dosage}</label>
                  <input
                    type="text"
                    className="w-full px-4 py-3 border-2 border-gray-200 rounded-xl focus:border-indigo-500 focus:outline-none"
                    placeholder="500mg"
                  />
                </div>
                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-2">{t.time}</label>
                  <input
                    type="time"
                    className="w-full px-4 py-3 border-2 border-gray-200 rounded-xl focus:border-indigo-500 focus:outline-none"
                  />
                </div>
              </div>
              <div className="flex gap-3">
                <button className="flex-1 bg-gradient-to-r from-indigo-600 to-purple-600 text-white py-3 rounded-xl font-semibold hover:shadow-lg transition-all">
                  {t.save}
                </button>
                <button
                  onClick={() => setShowAddForm(false)}
                  className="flex-1 bg-gray-200 text-gray-700 py-3 rounded-xl font-semibold hover:bg-gray-300 transition-all"
                >
                  {t.cancel}
                </button>
              </div>
            </div>
          </motion.div>
        )}

        {/* Medicine List */}
        <div className="space-y-4">
          {medicines.map((medicine, index) => (
            <motion.div
              key={medicine.id}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.5 + index * 0.1 }}
              className={`bg-white rounded-2xl p-6 border-2 ${medicine.taken ? 'border-green-200 opacity-60' : 'border-gray-200'} hover:shadow-lg transition-all`}
            >
              <div className="flex items-start gap-4">
                {/* Icon */}
                <div className={`p-3 bg-gradient-to-br ${medicine.color} rounded-xl flex-shrink-0`}>
                  <Pill className="w-6 h-6 text-white" />
                </div>

                {/* Info */}
                <div className="flex-1">
                  <div className="flex items-start justify-between mb-2">
                    <div>
                      <h3 className={`font-bold text-lg ${medicine.taken ? 'line-through text-gray-500' : 'text-gray-900'}`}>
                        {medicine.name}
                      </h3>
                      <p className="text-sm text-gray-600">{medicine.dosage}</p>
                    </div>
                    {medicine.taken && (
                      <div className="flex items-center gap-2 bg-green-100 px-3 py-1 rounded-full">
                        <Check className="w-4 h-4 text-green-600" />
                        <span className="text-xs font-semibold text-green-700">{t.taken}</span>
                      </div>
                    )}
                  </div>

                  <div className="flex items-center gap-4 text-sm text-gray-600 mb-4">
                    <div className="flex items-center gap-2">
                      <Clock className="w-4 h-4" />
                      <span>{medicine.time}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Bell className="w-4 h-4" />
                      <span>{medicine.frequency}</span>
                    </div>
                  </div>

                  {/* Actions */}
                  {!medicine.taken && (
                    <div className="flex gap-3">
                      <button
                        onClick={() => toggleTaken(medicine.id)}
                        className="flex-1 bg-gradient-to-r from-green-600 to-emerald-600 text-white py-2 rounded-xl text-sm font-semibold hover:shadow-lg transition-all flex items-center justify-center gap-2"
                      >
                        <Check className="w-4 h-4" />
                        {t.markTaken}
                      </button>
                      <button className="px-4 bg-gray-200 text-gray-700 rounded-xl text-sm font-semibold hover:bg-gray-300 transition-all flex items-center gap-2">
                        <X className="w-4 h-4" />
                        {t.skip}
                      </button>
                    </div>
                  )}
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Notification Banner */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.9 }}
          className="mt-8 bg-gradient-to-r from-blue-50 to-indigo-50 border-2 border-blue-200 rounded-2xl p-6 flex items-center gap-4"
        >
          <Bell className="w-6 h-6 text-blue-600 flex-shrink-0" />
          <div className="flex-1">
            <h3 className="font-bold text-gray-900 mb-1">{t.notifications}</h3>
            <p className="text-sm text-gray-600">
              {language === 'ps' ? 'موږ به تاسو ته د درملو د وخت یادونه درکړو' : language === 'fa' ? 'ما به زمان دارو را به شما یادآوری کنیم' : "We'll remind you when it's time for your medicine"}
            </p>
          </div>
          <div className="w-12 h-6 bg-green-500 rounded-full relative">
            <div className="absolute right-1 top-1 w-4 h-4 bg-white rounded-full"></div>
          </div>
        </motion.div>
      </div>
    </div>
  );
}