import { useState, useRef, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Textarea } from "./ui/textarea";
import { Badge } from "./ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "./ui/avatar";
import { Separator } from "./ui/separator";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "./ui/dialog";
import { 
  Send, 
  Paperclip, 
  Mic, 
  Image as ImageIcon,
  FileText,
  Video,
  Phone,
  MoreVertical,
  Search,
  CheckCheck,
  Clock,
  X,
  Download,
  Play,
  Pause,
  Sparkles,
  MessageSquare,
  UserPlus,
  Calendar,
  Stethoscope
} from "lucide-react";
import { ScrollArea } from "./ui/scroll-area";

interface Doctor {
  id: number;
  name: string;
  nameDari: string;
  specialty: string;
  specialtyDari: string;
  image: string;
  online: boolean;
  lastSeen?: string;
}

interface Message {
  id: number;
  senderId: number;
  senderName: string;
  message?: string;
  type: "text" | "voice" | "file" | "image";
  fileUrl?: string;
  fileName?: string;
  fileSize?: string;
  voiceDuration?: string;
  timestamp: string;
  read: boolean;
  isSender: boolean;
}

interface ChatConversation {
  doctor: Doctor;
  messages: Message[];
  unreadCount: number;
  lastMessage: string;
  lastMessageTime: string;
}

const mockDoctors: Doctor[] = [
  {
    id: 1,
    name: "Dr. Sarah Johnson",
    nameDari: "ډاکټره ساره جانسن",
    specialty: "Cardiologist",
    specialtyDari: "زړه متخصص",
    image: "https://images.unsplash.com/photo-1755189118414-14c8dacdb082?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxkb2N0b3IlMjBwb3J0cmFpdCUyMHByb2Zlc3Npb25hbHxlbnwxfHx8fDE3NjMxMjU5OTZ8MA&ixlib=rb-4.1.0&q=80&w=1080",
    online: true,
  },
  {
    id: 2,
    name: "Dr. Noor Ahmadi",
    nameDari: "ډاکټر نور احمدي",
    specialty: "Pediatrician",
    specialtyDari: "د ماشومانو متخصص",
    image: "https://images.unsplash.com/photo-1585842378054-ee2e52f94ba2?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmZW1hbGUlMjBkb2N0b3IlMjBtZWRpY2FsfGVufDF8fHx8MTc2MzA5OTUxNnww&ixlib=rb-4.1.0&q=80&w=1080",
    online: true,
  },
  {
    id: 3,
    name: "Dr. Hassan Karimi",
    nameDari: "ډاکټر حسن کریمي",
    specialty: "Neurologist",
    specialtyDari: "د اعصابو متخصص",
    image: "https://images.unsplash.com/photo-1690306816872-91063f6de36b?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjYXJkaW9sb2dpc3QlMjBkb2N0b3J8ZW58MXx8fHwxNzYzMTY1OTM5fDA&ixlib=rb-4.1.0&q=80&w=1080",
    online: false,
    lastSeen: "2 hours ago"
  },
  {
    id: 4,
    name: "Dr. Maryam Haidari",
    nameDari: "ډاکټره مریم حیدري",
    specialty: "Dermatologist",
    specialtyDari: "پوستکي متخصص",
    image: "https://images.unsplash.com/photo-1567745566980-4378a3db17fc?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwZWRpYXRyaWNpYW4lMjBkb2N0b3J8ZW58MXx8fHwxNzYzMTUxNzQ4fDA&ixlib=rb-4.1.0&q=80&w=1080",
    online: true,
  }
];

const mockConversations: ChatConversation[] = [
  {
    doctor: mockDoctors[0],
    unreadCount: 2,
    lastMessage: "Please send me your latest blood test results",
    lastMessageTime: "10:30 AM",
    messages: [
      {
        id: 1,
        senderId: 0,
        senderName: "You",
        message: "Hello Doctor, I need your advice about my heart condition",
        type: "text",
        timestamp: "10:15 AM",
        read: true,
        isSender: true
      },
      {
        id: 2,
        senderId: 1,
        senderName: "Dr. Sarah Johnson",
        message: "Hello! I'd be happy to help. Can you describe your symptoms?",
        type: "text",
        timestamp: "10:20 AM",
        read: true,
        isSender: false
      },
      {
        id: 3,
        senderId: 0,
        senderName: "You",
        message: "I've been experiencing chest pain occasionally",
        type: "text",
        timestamp: "10:25 AM",
        read: true,
        isSender: true
      },
      {
        id: 4,
        senderId: 1,
        senderName: "Dr. Sarah Johnson",
        message: "Please send me your latest blood test results",
        type: "text",
        timestamp: "10:30 AM",
        read: false,
        isSender: false
      }
    ]
  },
  {
    doctor: mockDoctors[1],
    unreadCount: 0,
    lastMessage: "Thank you! The medication is working well",
    lastMessageTime: "Yesterday",
    messages: [
      {
        id: 1,
        senderId: 0,
        senderName: "You",
        message: "My child has fever since yesterday",
        type: "text",
        timestamp: "Yesterday 3:00 PM",
        read: true,
        isSender: true
      },
      {
        id: 2,
        senderId: 2,
        senderName: "Dr. Noor Ahmadi",
        message: "I recommend Paracetamol 250mg every 6 hours. Monitor the temperature.",
        type: "text",
        timestamp: "Yesterday 3:15 PM",
        read: true,
        isSender: false
      }
    ]
  }
];

export function DoctorChat() {
  const [selectedChat, setSelectedChat] = useState<ChatConversation | null>(mockConversations[0]);
  const [messageText, setMessageText] = useState("");
  const [isRecording, setIsRecording] = useState(false);
  const [recordingTime, setRecordingTime] = useState(0);
  const [uploadModalOpen, setUploadModalOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const scrollRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [selectedChat?.messages]);

  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (isRecording) {
      interval = setInterval(() => {
        setRecordingTime(prev => prev + 1);
      }, 1000);
    } else {
      setRecordingTime(0);
    }
    return () => clearInterval(interval);
  }, [isRecording]);

  const handleSendMessage = () => {
    if (!messageText.trim() || !selectedChat) return;

    const newMessage: Message = {
      id: selectedChat.messages.length + 1,
      senderId: 0,
      senderName: "You",
      message: messageText,
      type: "text",
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      read: false,
      isSender: true
    };

    setSelectedChat({
      ...selectedChat,
      messages: [...selectedChat.messages, newMessage]
    });
    setMessageText("");
  };

  const handleVoiceRecord = () => {
    if (isRecording) {
      // Stop recording and send
      if (selectedChat) {
        const newMessage: Message = {
          id: selectedChat.messages.length + 1,
          senderId: 0,
          senderName: "You",
          type: "voice",
          voiceDuration: `${Math.floor(recordingTime / 60)}:${(recordingTime % 60).toString().padStart(2, '0')}`,
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          read: false,
          isSender: true
        };
        setSelectedChat({
          ...selectedChat,
          messages: [...selectedChat.messages, newMessage]
        });
      }
      setIsRecording(false);
    } else {
      setIsRecording(true);
    }
  };

  const handleFileUpload = (type: "prescription" | "test" | "image") => {
    if (!selectedChat) return;

    const fileNames = {
      prescription: "prescription_scan.pdf",
      test: "blood_test_results.pdf",
      image: "symptom_photo.jpg"
    };

    const newMessage: Message = {
      id: selectedChat.messages.length + 1,
      senderId: 0,
      senderName: "You",
      type: type === "image" ? "image" : "file",
      fileName: fileNames[type],
      fileSize: "2.4 MB",
      fileUrl: "#",
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      read: false,
      isSender: true
    };

    setSelectedChat({
      ...selectedChat,
      messages: [...selectedChat.messages, newMessage]
    });
    setUploadModalOpen(false);
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  return (
    <section className="py-16 md:py-24 bg-gradient-to-b from-white via-blue-50/30 to-white relative overflow-hidden min-h-screen">
      {/* Background decoration */}
      <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-gradient-to-br from-blue-100/50 to-cyan-100/50 rounded-full blur-3xl animate-float"></div>
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        {/* Header */}
        <div className="text-center mb-12 md:mb-16 space-y-4">
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-blue-100 to-cyan-100 rounded-full">
            <Sparkles className="w-4 h-4 text-blue-600 animate-pulse-glow" />
            <span className="text-blue-700 text-sm uppercase tracking-wider">Live Chat</span>
          </div>
          <h2 className="text-4xl md:text-6xl">
            <span className="bg-gradient-to-r from-blue-600 via-cyan-600 to-teal-600 bg-clip-text text-transparent">
              Doctor Chat
            </span>
          </h2>
          <p className="text-gray-600 max-w-2xl mx-auto text-lg">
            د ډاکټر سره مستقیم چیټ - Chat with doctors in real-time
          </p>
        </div>

        {/* Chat Interface */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 max-w-6xl mx-auto">
          {/* Conversations List */}
          <Card className="lg:col-span-1 border-0 shadow-lg">
            <CardHeader className="pb-3">
              <CardTitle className="flex items-center gap-2">
                <MessageSquare className="w-5 h-5 text-blue-600" />
                Conversations
              </CardTitle>
              <div className="relative mt-3">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                <Input
                  placeholder="Search doctors..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
            </CardHeader>
            <Separator />
            <ScrollArea className="h-[600px]">
              <div className="p-4 space-y-2">
                {mockConversations.map((conversation) => (
                  <button
                    key={conversation.doctor.id}
                    onClick={() => setSelectedChat(conversation)}
                    className={`w-full p-3 rounded-lg transition-all text-left ${
                      selectedChat?.doctor.id === conversation.doctor.id
                        ? "bg-gradient-to-r from-blue-100 to-cyan-100 shadow-md"
                        : "hover:bg-gray-50"
                    }`}
                  >
                    <div className="flex items-start gap-3">
                      <div className="relative">
                        <Avatar className="w-12 h-12">
                          <AvatarImage src={conversation.doctor.image} />
                          <AvatarFallback>{conversation.doctor.name[0]}</AvatarFallback>
                        </Avatar>
                        {conversation.doctor.online && (
                          <div className="absolute bottom-0 right-0 w-3 h-3 bg-green-500 rounded-full border-2 border-white"></div>
                        )}
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center justify-between mb-1">
                          <p className="text-sm text-gray-900 truncate">{conversation.doctor.name}</p>
                          <span className="text-xs text-gray-500">{conversation.lastMessageTime}</span>
                        </div>
                        <p className="text-xs text-blue-600 mb-1">{conversation.doctor.specialty}</p>
                        <p className="text-xs text-gray-600 truncate">{conversation.lastMessage}</p>
                      </div>
                      {conversation.unreadCount > 0 && (
                        <Badge className="bg-blue-600 text-white text-xs">
                          {conversation.unreadCount}
                        </Badge>
                      )}
                    </div>
                  </button>
                ))}

                <Separator className="my-4" />

                {/* New Chat Button */}
                <Button className="w-full bg-gradient-to-r from-blue-500 to-cyan-600 hover:from-blue-600 hover:to-cyan-700">
                  <UserPlus className="w-4 h-4 mr-2" />
                  Start New Chat
                </Button>
              </div>
            </ScrollArea>
          </Card>

          {/* Chat Window */}
          <Card className="lg:col-span-2 border-0 shadow-lg">
            {selectedChat ? (
              <>
                {/* Chat Header */}
                <CardHeader className="pb-3">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className="relative">
                        <Avatar className="w-12 h-12">
                          <AvatarImage src={selectedChat.doctor.image} />
                          <AvatarFallback>{selectedChat.doctor.name[0]}</AvatarFallback>
                        </Avatar>
                        {selectedChat.doctor.online && (
                          <div className="absolute bottom-0 right-0 w-3 h-3 bg-green-500 rounded-full border-2 border-white"></div>
                        )}
                      </div>
                      <div>
                        <h3 className="text-lg text-gray-900">{selectedChat.doctor.name}</h3>
                        <p className="text-sm text-blue-600">{selectedChat.doctor.specialty}</p>
                        <p className="text-xs text-gray-500">
                          {selectedChat.doctor.online ? (
                            <span className="text-green-600">● Online</span>
                          ) : (
                            <span>Last seen: {selectedChat.doctor.lastSeen}</span>
                          )}
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <Button size="sm" variant="outline" className="hidden sm:flex">
                        <Phone className="w-4 h-4 mr-2" />
                        Call
                      </Button>
                      <Button size="sm" variant="outline" className="hidden sm:flex">
                        <Video className="w-4 h-4 mr-2" />
                        Video
                      </Button>
                      <Button size="sm" variant="outline">
                        <MoreVertical className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                </CardHeader>

                <Separator />

                {/* Messages Area */}
                <ScrollArea className="h-[450px] p-4" ref={scrollRef}>
                  <div className="space-y-4">
                    {selectedChat.messages.map((msg) => (
                      <div
                        key={msg.id}
                        className={`flex ${msg.isSender ? "justify-end" : "justify-start"}`}
                      >
                        <div className={`max-w-[70%] ${msg.isSender ? "order-2" : "order-1"}`}>
                          {!msg.isSender && (
                            <p className="text-xs text-gray-600 mb-1 ml-2">{msg.senderName}</p>
                          )}
                          <div
                            className={`rounded-2xl p-3 ${
                              msg.isSender
                                ? "bg-gradient-to-r from-blue-500 to-cyan-600 text-white"
                                : "bg-gray-100 text-gray-900"
                            }`}
                          >
                            {msg.type === "text" && (
                              <p className="text-sm">{msg.message}</p>
                            )}

                            {msg.type === "voice" && (
                              <div className="flex items-center gap-3 min-w-[200px]">
                                <Button
                                  size="sm"
                                  variant="ghost"
                                  className={msg.isSender ? "text-white hover:bg-blue-600" : "hover:bg-gray-200"}
                                >
                                  <Play className="w-4 h-4" />
                                </Button>
                                <div className="flex-1 h-8 bg-white/20 rounded-full"></div>
                                <span className="text-xs">{msg.voiceDuration}</span>
                              </div>
                            )}

                            {msg.type === "file" && (
                              <div className="flex items-center gap-3 min-w-[250px]">
                                <div className={`p-2 rounded-lg ${msg.isSender ? "bg-blue-600" : "bg-gray-200"}`}>
                                  <FileText className="w-5 h-5" />
                                </div>
                                <div className="flex-1">
                                  <p className="text-sm">{msg.fileName}</p>
                                  <p className={`text-xs ${msg.isSender ? "text-blue-100" : "text-gray-600"}`}>
                                    {msg.fileSize}
                                  </p>
                                </div>
                                <Button
                                  size="sm"
                                  variant="ghost"
                                  className={msg.isSender ? "text-white hover:bg-blue-600" : "hover:bg-gray-200"}
                                >
                                  <Download className="w-4 h-4" />
                                </Button>
                              </div>
                            )}

                            {msg.type === "image" && (
                              <div className="space-y-2">
                                <div className="w-full h-32 bg-white/20 rounded-lg flex items-center justify-center">
                                  <ImageIcon className="w-8 h-8 opacity-50" />
                                </div>
                                <p className="text-xs">{msg.fileName}</p>
                              </div>
                            )}
                          </div>
                          <div className="flex items-center gap-1 mt-1 px-2">
                            <span className={`text-xs ${msg.isSender ? "text-gray-500" : "text-gray-600"}`}>
                              {msg.timestamp}
                            </span>
                            {msg.isSender && (
                              <CheckCheck className={`w-3 h-3 ${msg.read ? "text-blue-600" : "text-gray-400"}`} />
                            )}
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </ScrollArea>

                <Separator />

                {/* Message Input */}
                <div className="p-4">
                  {isRecording && (
                    <div className="mb-3 p-3 bg-red-50 rounded-lg flex items-center justify-between animate-pulse-glow">
                      <div className="flex items-center gap-2">
                        <div className="w-3 h-3 bg-red-500 rounded-full animate-pulse"></div>
                        <span className="text-sm text-red-700">Recording...</span>
                      </div>
                      <span className="text-red-700">{formatTime(recordingTime)}</span>
                    </div>
                  )}

                  <div className="flex items-end gap-2">
                    <div className="flex-1">
                      <Textarea
                        placeholder="Type your message... | پیغام ولیکئ..."
                        value={messageText}
                        onChange={(e) => setMessageText(e.target.value)}
                        onKeyPress={(e) => {
                          if (e.key === "Enter" && !e.shiftKey) {
                            e.preventDefault();
                            handleSendMessage();
                          }
                        }}
                        className="min-h-[60px] max-h-[120px] resize-none"
                        disabled={isRecording}
                      />
                    </div>
                    <div className="flex gap-2">
                      <Button
                        size="icon"
                        variant="outline"
                        onClick={() => setUploadModalOpen(true)}
                        disabled={isRecording}
                      >
                        <Paperclip className="w-5 h-5" />
                      </Button>
                      <Button
                        size="icon"
                        variant="outline"
                        onClick={handleVoiceRecord}
                        className={isRecording ? "bg-red-100 hover:bg-red-200" : ""}
                      >
                        <Mic className={`w-5 h-5 ${isRecording ? "text-red-600" : ""}`} />
                      </Button>
                      <Button
                        size="icon"
                        className="bg-gradient-to-r from-blue-500 to-cyan-600 hover:from-blue-600 hover:to-cyan-700"
                        onClick={handleSendMessage}
                        disabled={!messageText.trim() || isRecording}
                      >
                        <Send className="w-5 h-5" />
                      </Button>
                    </div>
                  </div>
                </div>
              </>
            ) : (
              <div className="h-[600px] flex items-center justify-center">
                <div className="text-center">
                  <MessageSquare className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                  <h3 className="text-xl text-gray-600 mb-2">No conversation selected</h3>
                  <p className="text-gray-500">Select a doctor to start chatting</p>
                </div>
              </div>
            )}
          </Card>
        </div>
      </div>

      {/* Upload Modal */}
      <Dialog open={uploadModalOpen} onOpenChange={setUploadModalOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Send File - فایل واستوئ</DialogTitle>
            <DialogDescription>Attach and send files to your doctor</DialogDescription>
          </DialogHeader>
          <div className="space-y-3">
            <Button
              className="w-full justify-start bg-gradient-to-r from-purple-100 to-pink-100 text-purple-700 hover:from-purple-200 hover:to-pink-200"
              onClick={() => handleFileUpload("prescription")}
            >
              <FileText className="w-5 h-5 mr-3" />
              <div className="text-left">
                <p className="text-sm">Upload Prescription</p>
                <p className="text-xs text-purple-600">د نسخې سند</p>
              </div>
            </Button>

            <Button
              className="w-full justify-start bg-gradient-to-r from-blue-100 to-cyan-100 text-blue-700 hover:from-blue-200 hover:to-cyan-200"
              onClick={() => handleFileUpload("test")}
            >
              <Stethoscope className="w-5 h-5 mr-3" />
              <div className="text-left">
                <p className="text-sm">Upload Test Results</p>
                <p className="text-xs text-blue-600">د ازموینې نتیجې</p>
              </div>
            </Button>

            <Button
              className="w-full justify-start bg-gradient-to-r from-green-100 to-emerald-100 text-green-700 hover:from-green-200 hover:to-emerald-200"
              onClick={() => handleFileUpload("image")}
            >
              <ImageIcon className="w-5 h-5 mr-3" />
              <div className="text-left">
                <p className="text-sm">Upload Image</p>
                <p className="text-xs text-green-600">عکس اپلوډ کړئ</p>
              </div>
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </section>
  );
}

export default DoctorChat;
