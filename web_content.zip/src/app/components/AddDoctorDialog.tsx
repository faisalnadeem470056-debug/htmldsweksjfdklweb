import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "./ui/dialog";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Label } from "./ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select";
import { Textarea } from "./ui/textarea";
import { useLanguage } from "../contexts/LanguageContext";
import { User, Stethoscope, Phone, Mail, MapPin, Award, DollarSign, Clock, Image as ImageIcon, FileText, Upload, CheckCircle2 } from "lucide-react";
import { toast } from "sonner@2.0.3";

interface AddDoctorDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onDoctorAdded: (doctor: any) => void;
}

export function AddDoctorDialog({ open, onOpenChange, onDoctorAdded }: AddDoctorDialogProps) {
  const { t, language } = useLanguage();
  
  const [formData, setFormData] = useState({
    name: "",
    nameDari: "",
    qualifications: "",
    specialty: "",
    specialtyDari: "",
    specialtyFa: "",
    phone: "",
    whatsapp: "",
    email: "",
    department: "",
    departmentDari: "",
    departmentFa: "",
    gender: "",
    experience: "",
    consultationFee: "",
    location: "",
    locationDari: "",
    hospital: "",
    hospitalDari: "",
    imageUrl: "",
    biography: "", // یو ځای د دري ژبو لپاره
    workingHours: "",
  });

  const [imagePreview, setImagePreview] = useState("");
  const [imageError, setImageError] = useState(false);

  const specialties = [
    { en: "Cardiologist", ps: "زړه متخصص", fa: "متخصص قلب" },
    { en: "Pediatrician", ps: "د ماشومانو متخصص", fa: "متخصص اطفال" },
    { en: "Gynecologist", ps: "د ښځو ډاکټر", fa: "متخصص زنان" },
    { en: "Neurologist", ps: "د اعصابو متخصص", fa: "متخصص اعصاب" },
    { en: "Orthopedic", ps: "د هډوکو متخصص", fa: "متخصص ارتوپد" },
    { en: "Dermatologist", ps: "پوستکي متخصص", fa: "متخصص پوست" },
    { en: "General Physician", ps: "عمومي ډاکټر", fa: "پزشک عمومی" },
    { en: "Dentist", ps: "غاښونو ډاکټر", fa: "دندانپزشک" },
    { en: "Mental Health Specialist", ps: "د رواني روغتیا متخصص", fa: "متخصص سلامت روان" },
  ];

  const departments = [
    { en: "Cardiology", ps: "زړه بخش", fa: "بخش قلب" },
    { en: "Pediatrics", ps: "د ماشومانو بخش", fa: "بخش اطفال" },
    { en: "Gynecology", ps: "د ښځو بخش", fa: "بخش زنان" },
    { en: "Neurology", ps: "د اعصابو بخش", fa: "بخش اعصاب" },
    { en: "Orthopedics", ps: "د هډوکو بخش", fa: "بخش ارتوپد" },
    { en: "Dermatology", ps: "پوستکي بخش", fa: "بخش پوست" },
    { en: "General Medicine", ps: "عمومي درملتون", fa: "پزشکی عمومی" },
    { en: "Dentistry", ps: "غاښونو بخش", fa: "دندانپزشکی" },
    { en: "Psychiatry", ps: "رواني روغتیا", fa: "روانپزشکی" },
  ];

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleSpecialtyChange = (value: string) => {
    const specialty = specialties.find(s => s.en === value);
    if (specialty) {
      setFormData(prev => ({
        ...prev,
        specialty: specialty.en,
        specialtyDari: specialty.ps,
        specialtyFa: specialty.fa,
      }));
    }
  };

  const handleDepartmentChange = (value: string) => {
    const dept = departments.find(d => d.en === value);
    if (dept) {
      setFormData(prev => ({
        ...prev,
        department: dept.en,
        departmentDari: dept.ps,
        departmentFa: dept.fa,
      }));
    }
  };

  // د عکس URL د test کولو function
  const handleImageUrlChange = (url: string) => {
    setFormData(prev => ({ ...prev, imageUrl: url }));
    setImageError(false);
    
    if (url.trim()) {
      // د عکس د test کولو لپاره
      const img = new window.Image();
      img.onload = () => {
        setImagePreview(url);
        setImageError(false);
      };
      img.onerror = () => {
        setImagePreview("");
        setImageError(true);
      };
      img.src = url;
    } else {
      setImagePreview("");
      setImageError(false);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Validation
    if (!formData.name || !formData.specialty || !formData.phone || !formData.gender) {
      toast.error(
        language === "ps" ? "مهربانی وکړئ ټول اړین ساحې ډک کړئ" :
        language === "fa" ? "لطفاً همه فیلدهای ضروری را پر کنید" :
        "Please fill all required fields"
      );
      return;
    }

    // د تجربې validation
    if (!formData.experience) {
      toast.error(
        language === "ps" ? "مهربانی وکړئ تجربه ولیکئ" :
        language === "fa" ? "لطفاً تجربه را وارد کنید" :
        "Please enter experience"
      );
      return;
    }

    // Create new doctor object
    const newDoctor = {
      id: Date.now(),
      name: formData.name,
      nameDari: formData.nameDari || formData.name,
      qualifications: formData.qualifications || "",
      specialty: formData.specialty,
      specialtyDari: formData.specialtyDari,
      phone: formData.phone,
      whatsapp: formData.whatsapp || formData.phone,
      email: formData.email,
      department: formData.department,
      departmentDari: formData.departmentDari,
      gender: formData.gender,
      experience: formData.experience,
      rating: 4.5,
      patients: "0+",
      consultationFee: formData.consultationFee || "500 AFN",
      location: formData.location || "Afghanistan",
      locationDari: formData.locationDari || "افغانستان",
      hospital: formData.hospital || formData.location || "Health Center",
      hospitalDari: formData.hospitalDari || formData.locationDari || "روغتیایي مرکز",
      image: formData.imageUrl || (formData.gender === "male" 
        ? "https://images.unsplash.com/photo-1632054224659-280be3239aff?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtYWxlJTIwZG9jdG9yJTIwcHJvZmVzc2lvbmFsfGVufDF8fHx8MTc2MzEwNjQ0MXww&ixlib=rb-4.1.0&q=80&w=1080"
        : "https://images.unsplash.com/photo-1676552055618-22ec8cde399a?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmZW1hbGUlMjBkb2N0b3IlMjBzbWlsaW5nfGVufDF8fHx8MTc2MzE2NDc0NXww&ixlib=rb-4.1.0&q=80&w=1080"
      ),
      available: "Available Now",
      biography: formData.biography, // یو biography په دري ژبو
      workingHours: formData.workingHours || "9:00 AM - 5:00 PM",
      addedDate: new Date().toISOString(),
    };

    // Save to localStorage
    const existingDoctors = JSON.parse(localStorage.getItem("customDoctors") || "[]");
    existingDoctors.push(newDoctor);
    localStorage.setItem("customDoctors", JSON.stringify(existingDoctors));

    // Call callback
    onDoctorAdded(newDoctor);

    // Show success message
    toast.success(
      language === "ps" ? "ډاکټر په بریالیتوب سره اضافه شو!" :
      language === "fa" ? "دکتر با موفقیت اضافه شد!" :
      "Doctor added successfully!"
    );

    // Reset form
    setFormData({
      name: "",
      nameDari: "",
      qualifications: "",
      specialty: "",
      specialtyDari: "",
      specialtyFa: "",
      phone: "",
      whatsapp: "",
      email: "",
      department: "",
      departmentDari: "",
      departmentFa: "",
      gender: "",
      experience: "",
      consultationFee: "",
      location: "",
      locationDari: "",
      hospital: "",
      hospitalDari: "",
      imageUrl: "",
      biography: "",
      workingHours: "",
    });
    setImagePreview("");
    setImageError(false);

    onOpenChange(false);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-2xl">
            <Stethoscope className="w-6 h-6 text-emerald-600" />
            {language === "ps" ? "نوی ډاکټر اضافه کړئ" :
             language === "fa" ? "اضافه کردن دکتر جدید" :
             "Add New Doctor"}
          </DialogTitle>
          <DialogDescription>
            {language === "ps" ? "د نوي ډاکټر معلومات ولیکئ" :
             language === "fa" ? "اطلاعات دکتر جدید را وارد کنید" :
             "Enter the information of the new doctor"}
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-6 mt-4">
          {/* Basic Information */}
          <div className="space-y-4 bg-gradient-to-br from-emerald-50 to-teal-50 p-4 rounded-lg border border-emerald-200">
            <h3 className="font-semibold text-lg flex items-center gap-2">
              <User className="w-5 h-5 text-emerald-600" />
              {language === "ps" ? "بنسټیز معلومات" :
               language === "fa" ? "اطلاعات اولیه" :
               "Basic Information"}
            </h3>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="name">
                  {language === "ps" ? "نوم (انګلیسي)" :
                   language === "fa" ? "نام (انگلیسی)" :
                   "Name (English)"} *
                </Label>
                <Input
                  id="name"
                  value={formData.name}
                  onChange={(e) => handleInputChange("name", e.target.value)}
                  placeholder="Dr. Sarah Johnson"
                  required
                  className="bg-white"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="nameDari">
                  {language === "ps" ? "نوم (پښتو/دري)" :
                   language === "fa" ? "نام (دری/پشتو)" :
                   "Name (Pashto/Dari)"}
                </Label>
                <Input
                  id="nameDari"
                  value={formData.nameDari}
                  onChange={(e) => handleInputChange("nameDari", e.target.value)}
                  placeholder="ډاکټره ساره جانسن"
                  className="text-right bg-white"
                  dir="rtl"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="gender">
                  {language === "ps" ? "جنسیت" :
                   language === "fa" ? "جنسیت" :
                   "Gender"} *
                </Label>
                <Select value={formData.gender} onValueChange={(value) => handleInputChange("gender", value)}>
                  <SelectTrigger className="bg-white">
                    <SelectValue placeholder={
                      language === "ps" ? "جنسیت انتخاب کړئ" :
                      language === "fa" ? "جنسیت را انتخاب کنید" :
                      "Select Gender"
                    } />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="male">
                      {language === "ps" ? "نارینه" :
                       language === "fa" ? "مرد" :
                       "Male"}
                    </SelectItem>
                    <SelectItem value="female">
                      {language === "ps" ? "ښځینه" :
                       language === "fa" ? "زن" :
                       "Female"}
                    </SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="qualifications">
                  <Award className="w-4 h-4 inline mr-1" />
                  {language === "ps" ? "تعلیم/سندونه" :
                   language === "fa" ? "تحصیلات/مدارک" :
                   "Qualifications"}
                </Label>
                <Input
                  id="qualifications"
                  value={formData.qualifications}
                  onChange={(e) => handleInputChange("qualifications", e.target.value)}
                  placeholder="MBBS, MD, PhD"
                  className="bg-white"
                />
              </div>
            </div>
          </div>

          {/* Professional Information */}
          <div className="space-y-4 bg-gradient-to-br from-blue-50 to-indigo-50 p-4 rounded-lg border border-blue-200">
            <h3 className="font-semibold text-lg flex items-center gap-2">
              <Stethoscope className="w-5 h-5 text-blue-600" />
              {language === "ps" ? "حرفه‌ای معلومات" :
               language === "fa" ? "اطلاعات حرفه‌ای" :
               "Professional Information"}
            </h3>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="specialty">
                  {language === "ps" ? "تخصص" :
                   language === "fa" ? "تخصص" :
                   "Specialty"} *
                </Label>
                <Select value={formData.specialty} onValueChange={handleSpecialtyChange}>
                  <SelectTrigger className="bg-white">
                    <SelectValue placeholder={
                      language === "ps" ? "تخصص انتخاب کړئ" :
                      language === "fa" ? "تخصص را انتخاب کنید" :
                      "Select Specialty"
                    } />
                  </SelectTrigger>
                  <SelectContent>
                    {specialties.map((spec) => (
                      <SelectItem key={spec.en} value={spec.en}>
                        {language === "ps" ? spec.ps :
                         language === "fa" ? spec.fa :
                         spec.en}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="department">
                  {language === "ps" ? "بخش/څانګه" :
                   language === "fa" ? "بخش" :
                   "Department"}
                </Label>
                <Select value={formData.department} onValueChange={handleDepartmentChange}>
                  <SelectTrigger className="bg-white">
                    <SelectValue placeholder={
                      language === "ps" ? "بخش انتخاب کړئ" :
                      language === "fa" ? "بخش را انتخاب کنید" :
                      "Select Department"
                    } />
                  </SelectTrigger>
                  <SelectContent>
                    {departments.map((dept) => (
                      <SelectItem key={dept.en} value={dept.en}>
                        {language === "ps" ? dept.ps :
                         language === "fa" ? dept.fa :
                         dept.en}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="experience">
                  <Clock className="w-4 h-4 inline mr-1" />
                  {language === "ps" ? "تجربه" :
                   language === "fa" ? "تجربه" :
                   "Experience"} *
                </Label>
                <Input
                  id="experience"
                  value={formData.experience}
                  onChange={(e) => handleInputChange("experience", e.target.value)}
                  placeholder={
                    language === "ps" ? "۱۵ کاله" :
                    language === "fa" ? "۱۵ سال" :
                    "15 years"
                  }
                  required
                  className="bg-white"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="consultationFee">
                  <DollarSign className="w-4 h-4 inline mr-1" />
                  {language === "ps" ? "معاینې فیس" :
                   language === "fa" ? "هزینه معاینه" :
                   "Consultation Fee"}
                </Label>
                <Input
                  id="consultationFee"
                  value={formData.consultationFee}
                  onChange={(e) => handleInputChange("consultationFee", e.target.value)}
                  placeholder="500 AFN"
                  className="bg-white"
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="workingHours">
                <Clock className="w-4 h-4 inline mr-1" />
                {language === "ps" ? "د کار ساعتونه" :
                 language === "fa" ? "ساعات کاری" :
                 "Working Hours"}
              </Label>
              <Input
                id="workingHours"
                value={formData.workingHours}
                onChange={(e) => handleInputChange("workingHours", e.target.value)}
                placeholder="9:00 AM - 5:00 PM"
                className="bg-white"
              />
            </div>
          </div>

          {/* Contact Information */}
          <div className="space-y-4 bg-gradient-to-br from-purple-50 to-pink-50 p-4 rounded-lg border border-purple-200">
            <h3 className="font-semibold text-lg flex items-center gap-2">
              <Phone className="w-5 h-5 text-purple-600" />
              {language === "ps" ? "د اړیکې معلومات" :
               language === "fa" ? "اطلاعات تماس" :
               "Contact Information"}
            </h3>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="phone">
                  <Phone className="w-4 h-4 inline mr-1" />
                  {language === "ps" ? "تلیفون" :
                   language === "fa" ? "تلفن" :
                   "Phone"} *
                </Label>
                <Input
                  id="phone"
                  type="tel"
                  value={formData.phone}
                  onChange={(e) => handleInputChange("phone", e.target.value)}
                  placeholder="+93 700 000 000"
                  required
                  className="bg-white"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="whatsapp">
                  {language === "ps" ? "واټساپ" :
                   language === "fa" ? "واتساپ" :
                   "WhatsApp"}
                </Label>
                <Input
                  id="whatsapp"
                  type="tel"
                  value={formData.whatsapp}
                  onChange={(e) => handleInputChange("whatsapp", e.target.value)}
                  placeholder="+93 700 000 000"
                  className="bg-white"
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="email">
                <Mail className="w-4 h-4 inline mr-1" />
                {language === "ps" ? "ایمیل" :
                 language === "fa" ? "ایمیل" :
                 "Email"}
              </Label>
              <Input
                id="email"
                type="email"
                value={formData.email}
                onChange={(e) => handleInputChange("email", e.target.value)}
                placeholder="doctor@healmate.af"
                className="bg-white"
              />
            </div>
          </div>

          {/* Location Information */}
          <div className="space-y-4 bg-gradient-to-br from-orange-50 to-amber-50 p-4 rounded-lg border border-orange-200">
            <h3 className="font-semibold text-lg flex items-center gap-2">
              <MapPin className="w-5 h-5 text-orange-600" />
              {language === "ps" ? "د ځای معلومات" :
               language === "fa" ? "اطلاعات مکان" :
               "Location Information"}
            </h3>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="location">
                  {language === "ps" ? "ځای (انګلیسي)" :
                   language === "fa" ? "مکان (انگلیسی)" :
                   "Location (English)"}
                </Label>
                <Input
                  id="location"
                  value={formData.location}
                  onChange={(e) => handleInputChange("location", e.target.value)}
                  placeholder="Kabul"
                  className="bg-white"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="locationDari">
                  {language === "ps" ? "ځای (پښتو/دري)" :
                   language === "fa" ? "مکان (دری/پشتو)" :
                   "Location (Pashto/Dari)"}
                </Label>
                <Input
                  id="locationDari"
                  value={formData.locationDari}
                  onChange={(e) => handleInputChange("locationDari", e.target.value)}
                  placeholder="کابل"
                  className="text-right bg-white"
                  dir="rtl"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="hospital">
                  {language === "ps" ? "روغتون/کلینیک (انګلیسي)" :
                   language === "fa" ? "بیمارستان/کلینیک (انگلیسی)" :
                   "Hospital/Clinic (English)"}
                </Label>
                <Input
                  id="hospital"
                  value={formData.hospital}
                  onChange={(e) => handleInputChange("hospital", e.target.value)}
                  placeholder="Kabul Medical Center"
                  className="bg-white"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="hospitalDari">
                  {language === "ps" ? "روغتون/کلینیک (پښتو/دري)" :
                   language === "fa" ? "بیمارستان/کلینیک (دری/پشتو)" :
                   "Hospital/Clinic (Pashto/Dari)"}
                </Label>
                <Input
                  id="hospitalDari"
                  value={formData.hospitalDari}
                  onChange={(e) => handleInputChange("hospitalDari", e.target.value)}
                  placeholder="د کابل طبي مرکز"
                  className="text-right bg-white"
                  dir="rtl"
                />
              </div>
            </div>
          </div>

          {/* د عکس Upload */}
          <div className="space-y-4 bg-gradient-to-br from-cyan-50 to-blue-50 p-4 rounded-lg border border-cyan-200">
            <h3 className="font-semibold text-lg flex items-center gap-2">
              <ImageIcon className="w-5 h-5 text-cyan-600" />
              {language === "ps" ? "د عکس لینک" :
               language === "fa" ? "لینک تصویر" :
               "Image Link"}
            </h3>

            <div className="space-y-2">
              <Label htmlFor="imageUrl">
                <Upload className="w-4 h-4 inline mr-1" />
                {language === "ps" ? "د عکس URL ولیکئ" :
                 language === "fa" ? "URL تصویر را وارد کنید" :
                 "Enter Image URL"}
              </Label>
              <Input
                id="imageUrl"
                type="url"
                value={formData.imageUrl}
                onChange={(e) => handleImageUrlChange(e.target.value)}
                placeholder="https://example.com/doctor-photo.jpg"
                className="bg-white"
              />
              <p className="text-xs text-gray-500">
                {language === "ps" ? "د ډاکټر د عکس لینک دلته ولیکئ. که عکس ونه لیکل شي، نو اتوماتیک default عکس استعمالیږي." :
                 language === "fa" ? "لینک تصویر دکتر را اینجا وارد کنید. اگر تصویر وارد نشود، تصویر پیش‌فرض استفاده می‌شود." :
                 "Enter doctor's image URL here. If no image is provided, a default image will be used."}
              </p>
            </div>

            {/* Live Preview */}
            {imagePreview && !imageError && (
              <div className="space-y-2">
                <Label className="flex items-center gap-2 text-green-600">
                  <CheckCircle2 className="w-4 h-4" />
                  {language === "ps" ? "د عکس معاینه" :
                   language === "fa" ? "پیش‌نمایش تصویر" :
                   "Image Preview"}
                </Label>
                <div className="relative w-32 h-32 mx-auto border-2 border-green-500 rounded-lg overflow-hidden">
                  <img 
                    src={imagePreview} 
                    alt="Preview" 
                    className="w-full h-full object-cover"
                  />
                </div>
              </div>
            )}

            {imageError && (
              <div className="text-red-600 text-sm">
                {language === "ps" ? "❌ عکس نه لیدل کیږي. مهربانی وکړئ صحیح URL ولیکئ." :
                 language === "fa" ? "❌ تصویر قابل نمایش نیست. لطفاً URL صحیح وارد کنید." :
                 "❌ Image cannot be loaded. Please enter a valid URL."}
              </div>
            )}
          </div>

          {/* د تفصیل یو ځای په دري ژبو */}
          <div className="space-y-4 bg-gradient-to-br from-green-50 to-emerald-50 p-4 rounded-lg border border-green-200">
            <h3 className="font-semibold text-lg flex items-center gap-2">
              <FileText className="w-5 h-5 text-green-600" />
              {language === "ps" ? "تفصیل / Biography" :
               language === "fa" ? "شرح حال / Biography" :
               "Biography / Details"}
            </h3>

            <div className="space-y-2">
              <Label htmlFor="biography">
                {language === "ps" ? "د ډاکټر بشپړ تفصیل په دري ژبو (انګلیسي، پښتو، دري)" :
                 language === "fa" ? "شرح کامل دکتر به سه زبان (انگلیسی، پشتو، دری)" :
                 "Complete biography in three languages (English, Pashto, Dari)"}
              </Label>
              <Textarea
                id="biography"
                value={formData.biography}
                onChange={(e) => handleInputChange("biography", e.target.value)}
                placeholder={
                  language === "ps" ? 
                  "انګلیسي:\nDr. Sarah has over 15 years of experience in cardiology...\n\nپښتو:\nډاکټره ساره د زړه په برخه کې ۱۵ کاله تجربه لري...\n\nدري:\nداکتر ساره ۱۵ سال تجربه در قلب دارد..." :
                  language === "fa" ?
                  "انگلیسی:\nDr. Sarah has over 15 years of experience in cardiology...\n\nپشتو:\nډاکټره ساره د زړه په برخه کې ۱۵ کاله تجربه لري...\n\nدری:\nداکتر ساره ۱۵ سال تجربه در قلب دارد..." :
                  "English:\nDr. Sarah has over 15 years of experience in cardiology...\n\nPashto:\nډاکټره ساره د زړه په برخه کې ۱۵ کاله تجربه لري...\n\nDari:\nداکتر ساره ۱۵ سال تجربه در قلب دارد..."
                }
                rows={10}
                className="bg-white resize-y font-mono text-sm"
              />
              <p className="text-xs text-gray-500">
                {language === "ps" ? "💡 په دې یو ځای کې د دري ژبو تفصیل ولیکئ. د اسانتیا لپاره په هر ژبه یو پاراګراف ولیکئ." :
                 language === "fa" ? "💡 در این یک جا شرح حال به سه زبان بنویسید. برای راحتی در هر زبان یک پاراگراف بنویسید." :
                 "💡 Write the biography in all three languages in this one field. For ease, write one paragraph per language."}
              </p>
            </div>
          </div>

          {/* Submit Buttons */}
          <div className="flex gap-3 pt-4 border-t">
            <Button
              type="button"
              variant="outline"
              onClick={() => onOpenChange(false)}
              className="flex-1"
            >
              {language === "ps" ? "لغوه کول" :
               language === "fa" ? "لغو" :
               "Cancel"}
            </Button>
            <Button
              type="submit"
              className="flex-1 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700"
            >
              <Stethoscope className="w-4 h-4 mr-2" />
              {language === "ps" ? "ډاکټر اضافه کړئ" :
               language === "fa" ? "اضافه کردن دکتر" :
               "Add Doctor"}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
