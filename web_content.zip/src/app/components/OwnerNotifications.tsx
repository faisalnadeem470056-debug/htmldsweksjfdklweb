import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Bell, DollarSign, CheckCircle, XCircle, Download, Mail, 
  Phone, User, Calendar, CreditCard, ArrowLeft, Eye,
  Filter, Search, TrendingUp, Users, Wallet
} from 'lucide-react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Card } from './ui/card';
import { PaymentProcessor } from '../utils/PaymentProcessor';

interface OwnerNotificationsProps {
  language: 'ps' | 'fa' | 'en';
  onBack: () => void;
}

export function OwnerNotifications({ language, onBack }: OwnerNotificationsProps) {
  const [payments, setPayments] = useState<any[]>([]);
  const [filter, setFilter] = useState<'all' | 'pending' | 'verified' | 'failed'>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedPayment, setSelectedPayment] = useState<any>(null);

  const texts = {
    ps: {
      title: 'د پیسو معلومات',
      subtitle: 'د ټولو Premium Subscriptions لیست',
      totalRevenue: 'ټوله عاید',
      totalTransactions: 'ټولې لیږدونې',
      pending: 'په انتظار',
      verified: 'تایید شوی',
      failed: 'ناکام',
      all: 'ټول',
      search: 'ولټوئ...',
      customerName: 'د مشتری نوم',
      email: 'ایمیل',
      phone: 'تلیفون',
      amount: 'مقدار',
      plan: 'پلان',
      date: 'نیټه',
      status: 'حالت',
      transactionId: 'Transaction ID',
      viewDetails: 'تفصیل وګورئ',
      downloadReceipt: 'رسید ډاونلوډ',
      sendEmail: 'ایمیل ولیږه',
      noPayments: 'هیڅ پیسې نه دي موندل شوې',
      paymentDetails: 'د پیسو تفصیل',
      customerInfo: 'د مشتری معلومات',
      paymentInfo: 'د پیسو معلومات',
      totalEarned: 'ټوله ترلاسه شوې',
      afn: 'افغانی',
      monthly: 'میاشتنی',
      yearly: 'کلنی',
      hesabPay: 'Hesab Pay',
      ownerPhone: 'ستاسو Hesab Pay',
      paymentReceived: 'پیسې ترلاسه شوې',
      premiumActivated: 'Premium فعال شو',
      contactCustomer: 'د مشتری سره اړیکه',
      exportData: 'ډاټا صادره کړه'
    },
    fa: {
      title: 'اطلاعات پرداخت',
      subtitle: 'لیست تمام Subscriptions Premium',
      totalRevenue: 'مجموع درآمد',
      totalTransactions: 'مجموع تراکنش‌ها',
      pending: 'در انتظار',
      verified: 'تایید شده',
      failed: 'ناموفق',
      all: 'همه',
      search: 'جستجو...',
      customerName: 'نام مشتری',
      email: 'ایمیل',
      phone: 'تلفن',
      amount: 'مبلغ',
      plan: 'پلان',
      date: 'تاریخ',
      status: 'وضعیت',
      transactionId: 'شناسه تراکنش',
      viewDetails: 'مشاهده جزئیات',
      downloadReceipt: 'دانلود رسید',
      sendEmail: 'ارسال ایمیل',
      noPayments: 'هیچ پرداختی یافت نشد',
      paymentDetails: 'جزئیات پرداخت',
      customerInfo: 'اطلاعات مشتری',
      paymentInfo: 'اطلاعات پرداخت',
      totalEarned: 'مجموع دریافتی',
      afn: 'افغانی',
      monthly: 'ماهانه',
      yearly: 'سالانه',
      hesabPay: 'Hesab Pay',
      ownerPhone: 'Hesab Pay شما',
      paymentReceived: 'پرداخت دریافت شد',
      premiumActivated: 'Premium فعال شد',
      contactCustomer: 'تماس با مشتری',
      exportData: 'خروجی داده'
    },
    en: {
      title: 'Payment Information',
      subtitle: 'All Premium Subscriptions',
      totalRevenue: 'Total Revenue',
      totalTransactions: 'Total Transactions',
      pending: 'Pending',
      verified: 'Verified',
      failed: 'Failed',
      all: 'All',
      search: 'Search...',
      customerName: 'Customer Name',
      email: 'Email',
      phone: 'Phone',
      amount: 'Amount',
      plan: 'Plan',
      date: 'Date',
      status: 'Status',
      transactionId: 'Transaction ID',
      viewDetails: 'View Details',
      downloadReceipt: 'Download Receipt',
      sendEmail: 'Send Email',
      noPayments: 'No payments found',
      paymentDetails: 'Payment Details',
      customerInfo: 'Customer Information',
      paymentInfo: 'Payment Information',
      totalEarned: 'Total Earned',
      afn: 'AFN',
      monthly: 'Monthly',
      yearly: 'Yearly',
      hesabPay: 'Hesab Pay',
      ownerPhone: 'Your Hesab Pay',
      paymentReceived: 'Payment Received',
      premiumActivated: 'Premium Activated',
      contactCustomer: 'Contact Customer',
      exportData: 'Export Data'
    }
  };

  const t = texts[language];

  useEffect(() => {
    loadPayments();
  }, []);

  const loadPayments = () => {
    const allPayments = PaymentProcessor.getAllPayments();
    setPayments(allPayments);
  };

  // Calculate statistics
  const stats = {
    total: payments.reduce((sum, p) => sum + p.amount, 0),
    count: payments.length,
    pending: payments.filter(p => p.status === 'pending').length,
    verified: payments.filter(p => p.status === 'verified').length,
    failed: payments.filter(p => p.status === 'failed').length
  };

  // Filter payments
  const filteredPayments = payments.filter(payment => {
    // Filter by status
    if (filter !== 'all' && payment.status !== filter) return false;

    // Filter by search query
    if (searchQuery.trim()) {
      const query = searchQuery.toLowerCase();
      return (
        payment.customerName.toLowerCase().includes(query) ||
        payment.customerEmail.toLowerCase().includes(query) ||
        payment.customerPhone.includes(query) ||
        payment.transactionId.toLowerCase().includes(query)
      );
    }

    return true;
  });

  // Get status badge
  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'pending':
        return (
          <span className="px-3 py-1 bg-yellow-100 text-yellow-700 rounded-full text-sm flex items-center gap-1">
            <Clock className="w-4 h-4" />
            {t.pending}
          </span>
        );
      case 'verified':
        return (
          <span className="px-3 py-1 bg-green-100 text-green-700 rounded-full text-sm flex items-center gap-1">
            <CheckCircle className="w-4 h-4" />
            {t.verified}
          </span>
        );
      case 'failed':
        return (
          <span className="px-3 py-1 bg-red-100 text-red-700 rounded-full text-sm flex items-center gap-1">
            <XCircle className="w-4 h-4" />
            {t.failed}
          </span>
        );
      default:
        return null;
    }
  };

  // Download receipt
  const handleDownloadReceipt = (transactionId: string) => {
    PaymentProcessor.downloadReceipt(transactionId);
  };

  // Export data
  const handleExportData = () => {
    const csv = [
      ['Transaction ID', 'Customer Name', 'Email', 'Phone', 'Amount', 'Plan', 'Status', 'Date'].join(','),
      ...filteredPayments.map(p => [
        p.transactionId,
        p.customerName,
        p.customerEmail,
        p.customerPhone,
        p.amount,
        p.plan,
        p.status,
        new Date(p.timestamp).toLocaleString()
      ].join(','))
    ].join('\n');

    const blob = new Blob([csv], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `HealMate_Payments_${new Date().toISOString().split('T')[0]}.csv`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  // Payment Detail Modal
  const PaymentDetailModal = ({ payment }: { payment: any }) => (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-50 bg-black/50 backdrop-blur-sm flex items-center justify-center p-4"
      onClick={() => setSelectedPayment(null)}
    >
      <motion.div
        initial={{ scale: 0.9, y: 20 }}
        animate={{ scale: 1, y: 0 }}
        exit={{ scale: 0.9, y: 20 }}
        className="bg-white rounded-3xl shadow-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="sticky top-0 bg-gradient-to-r from-blue-600 to-indigo-600 text-white p-6 rounded-t-3xl">
          <div className="flex items-center justify-between">
            <h2 className="text-2xl">{t.paymentDetails}</h2>
            <button
              onClick={() => setSelectedPayment(null)}
              className="w-10 h-10 bg-white/20 rounded-full flex items-center justify-center hover:bg-white/30 transition-colors"
            >
              <XCircle className="w-6 h-6" />
            </button>
          </div>
        </div>

        <div className="p-6 space-y-6">
          {/* Status Badge */}
          <div className="flex items-center justify-center">
            {getStatusBadge(payment.status)}
          </div>

          {/* Amount */}
          <div className="bg-gradient-to-br from-green-50 to-emerald-50 rounded-2xl p-6 text-center">
            <p className="text-sm text-gray-600 mb-2">{t.amount}</p>
            <p className="text-4xl text-green-600">{payment.amount} {t.afn}</p>
          </div>

          {/* Customer Info */}
          <div>
            <h3 className="text-lg mb-4 flex items-center gap-2">
              <User className="w-5 h-5 text-blue-600" />
              {t.customerInfo}
            </h3>
            <div className="bg-gray-50 rounded-2xl p-4 space-y-3">
              <div className="flex items-center gap-3">
                <User className="w-5 h-5 text-gray-400" />
                <div>
                  <p className="text-sm text-gray-500">{t.customerName}</p>
                  <p className="text-gray-900">{payment.customerName}</p>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <Mail className="w-5 h-5 text-gray-400" />
                <div>
                  <p className="text-sm text-gray-500">{t.email}</p>
                  <a href={`mailto:${payment.customerEmail}`} className="text-blue-600 hover:underline">
                    {payment.customerEmail}
                  </a>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <Phone className="w-5 h-5 text-gray-400" />
                <div>
                  <p className="text-sm text-gray-500">{t.phone}</p>
                  <a href={`tel:${payment.customerPhone}`} className="text-blue-600 hover:underline">
                    {payment.customerPhone}
                  </a>
                </div>
              </div>
            </div>
          </div>

          {/* Payment Info */}
          <div>
            <h3 className="text-lg mb-4 flex items-center gap-2">
              <CreditCard className="w-5 h-5 text-purple-600" />
              {t.paymentInfo}
            </h3>
            <div className="bg-gray-50 rounded-2xl p-4 space-y-3">
              <div className="flex justify-between">
                <span className="text-gray-600">{t.transactionId}:</span>
                <span className="text-gray-900 font-mono text-sm">{payment.transactionId}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">{t.plan}:</span>
                <span className="text-gray-900">{payment.plan}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">{t.date}:</span>
                <span className="text-gray-900">{new Date(payment.timestamp).toLocaleString()}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Payment Method:</span>
                <span className="text-gray-900">{t.hesabPay}</span>
              </div>
            </div>
          </div>

          {/* Actions */}
          <div className="flex gap-3">
            <Button
              onClick={() => handleDownloadReceipt(payment.transactionId)}
              className="flex-1 bg-blue-600 text-white rounded-xl py-6"
            >
              <Download className="w-5 h-5 mr-2" />
              {t.downloadReceipt}
            </Button>
            <Button
              onClick={() => window.location.href = `mailto:${payment.customerEmail}`}
              variant="outline"
              className="flex-1 rounded-xl py-6 border-2"
            >
              <Mail className="w-5 h-5 mr-2" />
              {t.sendEmail}
            </Button>
          </div>
        </div>
      </motion.div>
    </motion.div>
  );

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-purple-50 to-pink-50 pb-24">
      {/* Header */}
      <div className="sticky top-0 z-40 bg-gradient-to-r from-blue-600 via-purple-600 to-pink-600 text-white shadow-xl">
        <div className="container mx-auto px-4 py-6">
          <div className="flex items-center gap-4 mb-4">
            <Button
              variant="ghost"
              size="icon"
              onClick={onBack}
              className="rounded-full text-white hover:bg-white/20"
            >
              <ArrowLeft className="w-5 h-5" />
            </Button>
            <div className="flex-1">
              <h1 className="text-2xl flex items-center gap-2">
                <Wallet className="w-7 h-7" />
                {t.title}
              </h1>
              <p className="text-sm opacity-90">{t.subtitle}</p>
            </div>
            <Button
              onClick={handleExportData}
              className="bg-white/20 hover:bg-white/30 text-white rounded-xl"
            >
              <Download className="w-5 h-5 mr-2" />
              {t.exportData}
            </Button>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-6">
        {/* Statistics Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
          <Card className="bg-gradient-to-br from-green-500 to-emerald-600 text-white rounded-2xl p-6 shadow-xl">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm opacity-90">{t.totalRevenue}</p>
                <p className="text-3xl mt-2">{stats.total} {t.afn}</p>
              </div>
              <DollarSign className="w-12 h-12 opacity-50" />
            </div>
          </Card>

          <Card className="bg-gradient-to-br from-blue-500 to-indigo-600 text-white rounded-2xl p-6 shadow-xl">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm opacity-90">{t.totalTransactions}</p>
                <p className="text-3xl mt-2">{stats.count}</p>
              </div>
              <TrendingUp className="w-12 h-12 opacity-50" />
            </div>
          </Card>

          <Card className="bg-gradient-to-br from-yellow-500 to-orange-600 text-white rounded-2xl p-6 shadow-xl">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm opacity-90">{t.pending}</p>
                <p className="text-3xl mt-2">{stats.pending}</p>
              </div>
              <Clock className="w-12 h-12 opacity-50" />
            </div>
          </Card>

          <Card className="bg-gradient-to-br from-purple-500 to-pink-600 text-white rounded-2xl p-6 shadow-xl">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm opacity-90">{t.verified}</p>
                <p className="text-3xl mt-2">{stats.verified}</p>
              </div>
              <CheckCircle className="w-12 h-12 opacity-50" />
            </div>
          </Card>
        </div>

        {/* Owner Hesab Pay Info */}
        <Card className="bg-white rounded-2xl shadow-lg border-0 p-6 mb-6">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center">
              <Phone className="w-6 h-6 text-blue-600" />
            </div>
            <div className="flex-1">
              <p className="text-sm text-gray-600">{t.ownerPhone}</p>
              <p className="text-xl text-blue-600">+93 779 494 512</p>
            </div>
            <CheckCircle className="w-8 h-8 text-green-600" />
          </div>
        </Card>

        {/* Search and Filter */}
        <Card className="bg-white rounded-2xl shadow-lg border-0 p-4 mb-6">
          <div className="flex flex-col md:flex-row gap-4">
            {/* Search */}
            <div className="flex-1 relative">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
              <Input
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder={t.search}
                className="pl-12 rounded-xl border-2 border-gray-200"
              />
            </div>

            {/* Filter */}
            <div className="flex gap-2 overflow-x-auto">
              {(['all', 'pending', 'verified', 'failed'] as const).map((status) => (
                <button
                  key={status}
                  onClick={() => setFilter(status)}
                  className={`px-4 py-2 rounded-xl whitespace-nowrap transition-all ${
                    filter === status
                      ? 'bg-blue-600 text-white'
                      : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                  }`}
                >
                  {t[status]}
                </button>
              ))}
            </div>
          </div>
        </Card>

        {/* Payments List */}
        {filteredPayments.length === 0 ? (
          <Card className="bg-white rounded-2xl shadow-lg border-0 p-12 text-center">
            <div className="w-20 h-20 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <DollarSign className="w-10 h-10 text-gray-400" />
            </div>
            <p className="text-xl text-gray-600">{t.noPayments}</p>
          </Card>
        ) : (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            {filteredPayments.map((payment) => (
              <motion.div
                key={payment.transactionId}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
              >
                <Card className="bg-white rounded-2xl shadow-lg border-0 overflow-hidden hover:shadow-xl transition-shadow">
                  <div className="p-6">
                    <div className="flex items-start justify-between mb-4">
                      <div className="flex-1">
                        <h3 className="text-lg mb-1">{payment.customerName}</h3>
                        <p className="text-sm text-gray-500">{payment.customerEmail}</p>
                      </div>
                      {getStatusBadge(payment.status)}
                    </div>

                    <div className="bg-gray-50 rounded-xl p-4 mb-4">
                      <div className="flex items-center justify-between">
                        <span className="text-gray-600">{t.amount}:</span>
                        <span className="text-2xl text-green-600">{payment.amount} {t.afn}</span>
                      </div>
                    </div>

                    <div className="space-y-2 mb-4 text-sm">
                      <div className="flex items-center gap-2 text-gray-600">
                        <Phone className="w-4 h-4" />
                        {payment.customerPhone}
                      </div>
                      <div className="flex items-center gap-2 text-gray-600">
                        <Calendar className="w-4 h-4" />
                        {new Date(payment.timestamp).toLocaleString()}
                      </div>
                      <div className="flex items-center gap-2 text-gray-600">
                        <CreditCard className="w-4 h-4" />
                        {payment.plan}
                      </div>
                    </div>

                    <Button
                      onClick={() => setSelectedPayment(payment)}
                      className="w-full bg-blue-600 text-white rounded-xl"
                    >
                      <Eye className="w-4 h-4 mr-2" />
                      {t.viewDetails}
                    </Button>
                  </div>
                </Card>
              </motion.div>
            ))}
          </div>
        )}
      </div>

      {/* Payment Detail Modal */}
      <AnimatePresence>
        {selectedPayment && <PaymentDetailModal payment={selectedPayment} />}
      </AnimatePresence>
    </div>
  );
}
