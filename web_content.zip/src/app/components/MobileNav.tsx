import { Home, Pill, Settings, Plus, Heart, Users, MessagesSquare, FileText, Shield, Stethoscope, BookOpen } from "lucide-react";
import { useLanguage } from "../contexts/LanguageContext";

interface MobileNavProps {
  activePage: string;
  setActivePage: (page: string) => void;
}

export function MobileNav({ activePage, setActivePage }: MobileNavProps) {
  const { t } = useLanguage();
  
  const navItems = [
    { id: "home", icon: Home, labelKey: "home", color: "from-blue-500 to-cyan-600", iconColor: "text-blue-500" },
    { id: "medicines", icon: Pill, labelKey: "medicines", color: "from-purple-500 to-pink-600", iconColor: "text-purple-500" },
    { id: "community", icon: Users, labelKey: "posts", isSpecial: true, color: "from-emerald-500 via-teal-600 to-cyan-600", iconColor: "text-emerald-500" },
    { id: "books", icon: BookOpen, labelKey: "books", color: "from-orange-500 to-amber-600", iconColor: "text-orange-500" },
    { id: "settings", icon: Settings, labelKey: "settings", color: "from-gray-500 to-slate-600", iconColor: "text-gray-500" },
  ];

  const handleNavClick = (pageId: string) => {
    setActivePage(pageId);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <nav className="fixed bottom-0 left-0 right-0 glass-effect border-t border-white/30 md:hidden z-50 safe-area-inset-bottom shadow-2xl">
      <div className="grid grid-cols-5 gap-0 px-1 py-2">
        {navItems.map((item) => {
          if (item.isSpecial) {
            // Special floating services button
            return (
              <button
                key={item.id}
                onClick={() => handleNavClick(item.id)}
                className="relative flex flex-col items-center justify-center"
              >
                <div className="absolute -top-8 left-1/2 -translate-x-1/2">
                  <div className="relative">
                    <div className="absolute inset-0 bg-gradient-to-r from-emerald-500 via-teal-600 to-cyan-600 rounded-full blur-lg animate-pulse-glow"></div>
                    <div className={`relative w-14 h-14 bg-gradient-to-r from-emerald-500 via-teal-600 to-cyan-600 rounded-full flex items-center justify-center shadow-2xl hover-scale border-4 border-white neon-glow ${
                      activePage === item.id ? "scale-110" : ""
                    }`}>
                      <item.icon className="w-7 h-7 text-white" />
                    </div>
                  </div>
                </div>
                <span className={`text-xs mt-4 ${
                  activePage === item.id ? "text-emerald-600" : "text-emerald-600"
                }`}>
                  {t(item.labelKey)}
                </span>
              </button>
            );
          }

          return (
            <button
              key={item.id}
              onClick={() => handleNavClick(item.id)}
              className={`relative flex flex-col items-center justify-center py-3 px-2 rounded-2xl transition-all duration-300 ${
                activePage === item.id
                  ? "text-white"
                  : "hover:bg-gray-50/50"
              }`}
            >
              {activePage === item.id && (
                <div className={`absolute inset-0 bg-gradient-to-r ${item.color} rounded-2xl shadow-lg neon-glow animate-gradient`}></div>
              )}
              <item.icon className={`w-6 h-6 mb-1 relative z-10 transition-all duration-300 ${
                activePage === item.id ? "text-white animate-pulse-glow" : item.iconColor
              }`} />
              <span className={`text-xs relative z-10 transition-all duration-300 ${
                activePage === item.id ? "text-white" : item.iconColor
              }`}>
                {t(item.labelKey)}
              </span>
            </button>
          );
        })}
      </div>
    </nav>
  );
}
