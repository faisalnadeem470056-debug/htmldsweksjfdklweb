import { useState } from "react";
import { ChevronDown, ChevronRight, Heart, Brain, Apple, Smile, Baby, Users, Stethoscope, Pill, Activity, Eye, Ear, Bone, Sparkles, Zap, Dumbbell } from "lucide-react";
import { ScrollArea } from "./ui/scroll-area";

const categories = [
  {
    id: 1,
    name: "Cardiology",
    nameDari: "د زړه ډاکټر",
    icon: "❤️",
    gradient: "from-red-500 to-pink-500",
    subcategories: [
      "Heart Surgery",
      "ECG & Monitoring",
      "Blood Pressure",
      "Cardiovascular Health",
    ]
  },
  {
    id: 2,
    name: "Mental Health",
    nameDari: "رواني روغتیا",
    icon: "🧠",
    gradient: "from-purple-500 to-violet-500",
    subcategories: [
      "Counseling",
      "Depression Treatment",
      "Anxiety Management",
      "Therapy Sessions",
    ]
  },
  {
    id: 3,
    name: "Nutrition",
    nameDari: "تغذیه",
    icon: "🍎",
    gradient: "from-green-500 to-emerald-500",
    subcategories: [
      "Diet Planning",
      "Weight Management",
      "Food Allergies",
      "Nutritional Supplements",
    ]
  },
  {
    id: 4,
    name: "Dental Care",
    nameDari: "غاښونه",
    icon: "😁",
    gradient: "from-blue-500 to-cyan-500",
    subcategories: [
      "Teeth Cleaning",
      "Root Canal",
      "Dental Implants",
      "Orthodontics",
    ]
  },
  {
    id: 5,
    name: "Maternal Care",
    nameDari: "د مور پاملرنه",
    icon: "👶",
    gradient: "from-pink-500 to-rose-500",
    subcategories: [
      "Prenatal Care",
      "Delivery Services",
      "Postnatal Care",
      "Breastfeeding Support",
    ]
  },
  {
    id: 6,
    name: "Elderly Care",
    nameDari: "د زړو پاملرنه",
    icon: "👴",
    gradient: "from-orange-500 to-amber-500",
    subcategories: [
      "Geriatric Medicine",
      "Home Care",
      "Mobility Support",
      "Memory Care",
    ]
  },
  {
    id: 7,
    name: "General Medicine",
    nameDari: "عمومي ډاکټر",
    icon: "🩺",
    gradient: "from-teal-500 to-cyan-500",
    subcategories: [
      "General Checkup",
      "Fever & Flu",
      "Chronic Diseases",
      "Preventive Care",
    ]
  },
  {
    id: 8,
    name: "Pharmacy",
    nameDari: "درملتون",
    icon: "💊",
    gradient: "from-violet-500 to-purple-500",
    subcategories: [
      "Prescription Medicines",
      "Over-the-Counter",
      "Medical Supplies",
      "Home Delivery",
    ]
  },
  {
    id: 9,
    name: "Pediatrics",
    nameDari: "د ماشومانو ډاکټر",
    icon: "🧒",
    gradient: "from-amber-500 to-orange-500",
    subcategories: [
      "Child Health",
      "Vaccinations",
      "Growth Monitoring",
      "Child Nutrition",
    ]
  },
  {
    id: 10,
    name: "Ophthalmology",
    nameDari: "د سترګو ډاکټر",
    icon: "👁️",
    gradient: "from-sky-500 to-blue-500",
    subcategories: [
      "Eye Exams",
      "Cataract Surgery",
      "Vision Correction",
      "Eye Diseases",
    ]
  },
  {
    id: 11,
    name: "ENT",
    nameDari: "غوږ، پوزه، ستوني",
    icon: "👂",
    gradient: "from-indigo-500 to-purple-500",
    subcategories: [
      "Ear Problems",
      "Nose Disorders",
      "Throat Issues",
      "Hearing Tests",
    ]
  },
  {
    id: 12,
    name: "Orthopedics",
    nameDari: "د هډوکو ډاکټر",
    icon: "🦴",
    gradient: "from-slate-500 to-gray-500",
    subcategories: [
      "Bone Fractures",
      "Joint Replacement",
      "Sports Injuries",
      "Spine Care",
    ]
  },
  {
    id: 13,
    name: "Dermatology",
    nameDari: "د پوستکي ډاکټر",
    icon: "✨",
    gradient: "from-fuchsia-500 to-pink-500",
    subcategories: [
      "Skin Treatment",
      "Acne Care",
      "Hair Treatment",
      "Cosmetic Procedures",
    ]
  },
  {
    id: 14,
    name: "Neurology",
    nameDari: "د اعصابو ډاکټر",
    icon: "🧬",
    gradient: "from-cyan-500 to-teal-500",
    subcategories: [
      "Brain Disorders",
      "Nerve Problems",
      "Stroke Care",
      "Headache Treatment",
    ]
  },
  {
    id: 15,
    name: "Physiotherapy",
    nameDari: "فزیوتراپي",
    icon: "💪",
    gradient: "from-lime-500 to-green-500",
    subcategories: [
      "Physical Therapy",
      "Rehabilitation",
      "Pain Management",
      "Exercise Programs",
    ]
  },
];

interface CategoriesSidebarProps {
  isOpen: boolean;
  onClose: () => void;
}

export function CategoriesSidebar({ isOpen, onClose }: CategoriesSidebarProps) {
  const [expandedCategories, setExpandedCategories] = useState<number[]>([]);

  const toggleCategory = (categoryId: number) => {
    setExpandedCategories((prev) =>
      prev.includes(categoryId)
        ? prev.filter((id) => id !== categoryId)
        : [...prev, categoryId]
    );
  };

  if (!isOpen) return null;

  return (
    <>
      {/* Overlay */}
      <div
        className="fixed inset-0 bg-black/50 z-40 animate-fade-in md:hidden"
        onClick={onClose}
      />

      {/* Sidebar */}
      <div className="fixed top-0 right-0 h-full w-80 md:w-96 bg-white shadow-2xl z-50 animate-slide-in-right overflow-hidden">
        {/* Header */}
        <div className="glass-effect border-b border-gray-200 p-4 sticky top-0 z-10">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="gradient-text text-xl">Health Categories</h2>
              <p className="text-sm text-gray-600 mt-1">روغتیا کټګورۍ</p>
            </div>
            <button
              onClick={onClose}
              className="w-10 h-10 bg-gradient-to-r from-red-500 to-pink-500 rounded-full flex items-center justify-center hover-scale shadow-lg"
            >
              <span className="text-white text-xl">×</span>
            </button>
          </div>
        </div>

        {/* Categories List */}
        <ScrollArea className="h-[calc(100vh-80px)]">
          <div className="p-4 space-y-2">
            {categories.map((category, index) => (
              <div
                key={category.id}
                className="animate-slide-right"
                style={{ animationDelay: `${index * 30}ms` }}
              >
                {/* Category Header */}
                <button
                  onClick={() => toggleCategory(category.id)}
                  className="w-full flex items-center justify-between p-4 rounded-xl bg-gradient-to-r from-gray-50 to-white hover:from-emerald-50 hover:to-teal-50 transition-all border border-gray-100 hover:border-emerald-200 shadow-sm hover-lift"
                >
                  <div className="flex items-center gap-3">
                    <div className={`w-10 h-10 bg-gradient-to-br ${category.gradient} rounded-xl flex items-center justify-center shadow-md`}>
                      <span className="text-2xl">{category.icon}</span>
                    </div>
                    <div className="text-left">
                      <p className="text-gray-900">{category.name}</p>
                      <p className="text-xs text-gray-600">{category.nameDari}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-xs text-emerald-600 bg-emerald-50 px-2 py-1 rounded-full">
                      {category.subcategories.length}
                    </span>
                    {expandedCategories.includes(category.id) ? (
                      <ChevronDown className="w-5 h-5 text-gray-600 transition-transform" />
                    ) : (
                      <ChevronRight className="w-5 h-5 text-gray-600 transition-transform" />
                    )}
                  </div>
                </button>

                {/* Subcategories */}
                {expandedCategories.includes(category.id) && (
                  <div className="mt-2 ml-4 space-y-1 animate-slide-up">
                    {category.subcategories.map((subcategory, subIndex) => (
                      <button
                        key={subIndex}
                        className="w-full text-left px-4 py-3 rounded-lg bg-white hover:bg-gradient-to-r hover:from-emerald-50 hover:to-teal-50 transition-all border border-gray-100 hover:border-emerald-200 text-sm text-gray-700 hover:text-emerald-700 flex items-center gap-2 group"
                      >
                        <div className="w-1.5 h-1.5 rounded-full bg-gradient-to-r from-emerald-500 to-teal-500 group-hover:scale-150 transition-transform" />
                        {subcategory}
                      </button>
                    ))}
                  </div>
                )}
              </div>
            ))}
          </div>
        </ScrollArea>
      </div>
    </>
  );
}
