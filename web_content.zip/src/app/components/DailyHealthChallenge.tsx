import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Trophy, Flame, Target, CheckCircle2, Lock, Star, Zap, Award, TrendingUp } from 'lucide-react';
import { Button } from './ui/button';
import { Card } from './ui/card';

interface Challenge {
  id: string;
  title: { ps: string; fa: string; en: string };
  description: { ps: string; fa: string; en: string };
  points: number;
  completed: boolean;
  icon: any;
  color: string;
  difficulty: 'easy' | 'medium' | 'hard';
}

interface DailyHealthChallengeProps {
  language: 'ps' | 'fa' | 'en';
  userId?: string;
}

export function DailyHealthChallenge({ language, userId }: DailyHealthChallengeProps) {
  const [streak, setStreak] = useState(0);
  const [totalPoints, setTotalPoints] = useState(0);
  const [dailyChallenges, setDailyChallenges] = useState<Challenge[]>([
    {
      id: '1',
      title: {
        ps: '8 ګیلاسه اوبه وڅښئ',
        fa: '8 لیوان آب بنوشید',
        en: 'Drink 8 Glasses of Water'
      },
      description: {
        ps: 'نن ورځ 8 ګیلاسه پاکه اوبه وڅښئ',
        fa: 'امروز 8 لیوان آب تمیز بنوشید',
        en: 'Drink 8 glasses of clean water today'
      },
      points: 50,
      completed: false,
      icon: '💧',
      color: 'from-blue-500 to-cyan-500',
      difficulty: 'easy'
    },
    {
      id: '2',
      title: {
        ps: '30 دقیقې پیاده روی',
        fa: '30 دقیقه پیاده‌روی',
        en: '30 Minutes Walk'
      },
      description: {
        ps: 'لږ تر لږه 30 دقیقې پیاده روی وکړئ',
        fa: 'حداقل 30 دقیقه پیاده‌روی کنید',
        en: 'Walk for at least 30 minutes'
      },
      points: 100,
      completed: false,
      icon: '🚶',
      color: 'from-green-500 to-emerald-500',
      difficulty: 'medium'
    },
    {
      id: '3',
      title: {
        ps: 'صحي ډوډۍ وخورئ',
        fa: 'غذای سالم بخورید',
        en: 'Eat Healthy Meal'
      },
      description: {
        ps: 'یوه بشپړه صحي ډوډۍ د میوو او سبزیجاتو سره وخورئ',
        fa: 'یک وعده غذای کامل با میوه و سبزیجات بخورید',
        en: 'Eat one complete healthy meal with fruits and vegetables'
      },
      points: 75,
      completed: false,
      icon: '🥗',
      color: 'from-orange-500 to-amber-500',
      difficulty: 'easy'
    },
    {
      id: '4',
      title: {
        ps: 'د خوب وخت ساتل',
        fa: 'رعایت زمان خواب',
        en: 'Sleep on Time'
      },
      description: {
        ps: 'نن شپه په وخت ویده شئ (10 بجې)',
        fa: 'امشب سر وقت بخوابید (ساعت 10)',
        en: 'Sleep on time tonight (10 PM)'
      },
      points: 80,
      completed: false,
      icon: '😴',
      color: 'from-purple-500 to-violet-500',
      difficulty: 'medium'
    },
    {
      id: '5',
      title: {
        ps: '10 دقیقې مراقبه',
        fa: '10 دقیقه مدیتیشن',
        en: '10 Minutes Meditation'
      },
      description: {
        ps: '10 دقیقې د ذهن ارامولو تمرین وکړئ',
        fa: '10 دقیقه تمرین آرامش ذهن انجام دهید',
        en: 'Practice 10 minutes of mental relaxation'
      },
      points: 120,
      completed: false,
      icon: '🧘',
      color: 'from-pink-500 to-rose-500',
      difficulty: 'hard'
    }
  ]);

  useEffect(() => {
    // د local storage څخه معلومات راوړل
    const savedStreak = localStorage.getItem('healthmate_challenge_streak');
    const savedPoints = localStorage.getItem('healthmate_challenge_points');
    const savedChallenges = localStorage.getItem('healthmate_challenges_today');
    const lastCompletedDate = localStorage.getItem('healthmate_last_challenge_date');

    if (savedStreak) setStreak(parseInt(savedStreak));
    if (savedPoints) setTotalPoints(parseInt(savedPoints));
    
    // که نن ورځ challenges مخکې complete شوي وي
    const today = new Date().toDateString();
    if (savedChallenges && lastCompletedDate === today) {
      setDailyChallenges(JSON.parse(savedChallenges));
    } else if (lastCompletedDate && lastCompletedDate !== today) {
      // نوی ورځ - challenges reset کړئ
      localStorage.setItem('healthmate_challenges_today', JSON.stringify(dailyChallenges));
    }
  }, []);

  const completeChallenge = (challengeId: string) => {
    const updatedChallenges = dailyChallenges.map(challenge => {
      if (challenge.id === challengeId && !challenge.completed) {
        const newPoints = totalPoints + challenge.points;
        setTotalPoints(newPoints);
        localStorage.setItem('healthmate_challenge_points', newPoints.toString());
        
        return { ...challenge, completed: true };
      }
      return challenge;
    });

    setDailyChallenges(updatedChallenges);
    localStorage.setItem('healthmate_challenges_today', JSON.stringify(updatedChallenges));
    localStorage.setItem('healthmate_last_challenge_date', new Date().toDateString());

    // که ټولې challenges complete شوې وي، streak زیات کړئ
    const allCompleted = updatedChallenges.every(c => c.completed);
    if (allCompleted) {
      const newStreak = streak + 1;
      setStreak(newStreak);
      localStorage.setItem('healthmate_challenge_streak', newStreak.toString());
    }
  };

  const completedCount = dailyChallenges.filter(c => c.completed).length;
  const progressPercent = (completedCount / dailyChallenges.length) * 100;

  const texts = {
    ps: {
      title: '🏆 ورځنۍ روغتیا ننګونې',
      subtitle: 'خپله روغتیا ته د یوې لوبې په شکل وګورئ',
      yourProgress: 'ستاسو پرمختګ',
      streak: 'د پرله پسې ورځو',
      points: 'ټولې نمرې',
      challenges: 'ننګونې',
      completed: 'بشپړې شوې',
      complete: 'بشپړه کړئ',
      pts: 'نمرې',
      difficulty: {
        easy: 'اسانه',
        medium: 'منځنۍ',
        hard: 'سختې'
      }
    },
    fa: {
      title: '🏆 چالش‌های روزانه سلامتی',
      subtitle: 'سلامتی خود را به شکل یک بازی ببینید',
      yourProgress: 'پیشرفت شما',
      streak: 'روزهای متوالی',
      points: 'مجموع امتیازات',
      challenges: 'چالش‌ها',
      completed: 'تکمیل شده',
      complete: 'تکمیل کنید',
      pts: 'امتیاز',
      difficulty: {
        easy: 'آسان',
        medium: 'متوسط',
        hard: 'سخت'
      }
    },
    en: {
      title: '🏆 Daily Health Challenges',
      subtitle: 'Gamify your health journey',
      yourProgress: 'Your Progress',
      streak: 'Day Streak',
      points: 'Total Points',
      challenges: 'Challenges',
      completed: 'Completed',
      complete: 'Complete',
      pts: 'pts',
      difficulty: {
        easy: 'Easy',
        medium: 'Medium',
        hard: 'Hard'
      }
    }
  };

  const t = texts[language];

  return (
    <div className="w-full">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="mb-6"
      >
        <div className="text-center mb-6">
          <h2 className="text-3xl mb-2 bg-gradient-to-r from-purple-600 via-pink-600 to-orange-600 bg-clip-text text-transparent">
            {t.title}
          </h2>
          <p className="text-gray-600">{t.subtitle}</p>
        </div>

        {/* Statistics Cards */}
        <div className="grid grid-cols-3 gap-3 mb-6">
          <motion.div
            whileHover={{ scale: 1.05 }}
            className="bg-gradient-to-br from-orange-500 to-red-500 rounded-2xl p-4 text-white shadow-lg"
          >
            <Flame className="w-8 h-8 mb-2 mx-auto" />
            <div className="text-2xl text-center">{streak}</div>
            <div className="text-xs text-center opacity-90">{t.streak}</div>
          </motion.div>

          <motion.div
            whileHover={{ scale: 1.05 }}
            className="bg-gradient-to-br from-purple-500 to-pink-500 rounded-2xl p-4 text-white shadow-lg"
          >
            <Star className="w-8 h-8 mb-2 mx-auto fill-white" />
            <div className="text-2xl text-center">{totalPoints}</div>
            <div className="text-xs text-center opacity-90">{t.points}</div>
          </motion.div>

          <motion.div
            whileHover={{ scale: 1.05 }}
            className="bg-gradient-to-br from-green-500 to-emerald-500 rounded-2xl p-4 text-white shadow-lg"
          >
            <Trophy className="w-8 h-8 mb-2 mx-auto" />
            <div className="text-2xl text-center">{completedCount}/{dailyChallenges.length}</div>
            <div className="text-xs text-center opacity-90">{t.challenges}</div>
          </motion.div>
        </div>

        {/* Progress Bar */}
        <div className="bg-white/80 backdrop-blur-lg rounded-2xl p-4 shadow-lg mb-6">
          <div className="flex justify-between items-center mb-2">
            <span className="text-sm text-gray-600">{t.yourProgress}</span>
            <span className="text-sm bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent">
              {Math.round(progressPercent)}%
            </span>
          </div>
          <div className="w-full bg-gray-200 rounded-full h-3 overflow-hidden">
            <motion.div
              initial={{ width: 0 }}
              animate={{ width: `${progressPercent}%` }}
              transition={{ duration: 0.5 }}
              className="h-full bg-gradient-to-r from-purple-500 via-pink-500 to-orange-500 rounded-full"
            />
          </div>
        </div>

        {/* Challenges List */}
        <div className="space-y-3">
          <AnimatePresence>
            {dailyChallenges.map((challenge, index) => (
              <motion.div
                key={challenge.id}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: index * 0.1 }}
              >
                <Card className={`relative overflow-hidden ${
                  challenge.completed 
                    ? 'bg-green-50 border-green-200' 
                    : 'bg-white/80 backdrop-blur-lg border-white/50'
                } shadow-lg hover:shadow-xl transition-all`}>
                  <div className="p-4">
                    <div className="flex items-start gap-4">
                      <motion.div
                        whileHover={{ scale: 1.1, rotate: 5 }}
                        className={`w-16 h-16 rounded-2xl bg-gradient-to-br ${challenge.color} flex items-center justify-center text-3xl shadow-lg`}
                      >
                        {challenge.icon}
                      </motion.div>
                      
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-1">
                          <h3 className="font-bold">{challenge.title[language]}</h3>
                          <span className={`text-xs px-2 py-0.5 rounded-full ${
                            challenge.difficulty === 'easy' 
                              ? 'bg-green-100 text-green-700'
                              : challenge.difficulty === 'medium'
                              ? 'bg-yellow-100 text-yellow-700'
                              : 'bg-red-100 text-red-700'
                          }`}>
                            {t.difficulty[challenge.difficulty]}
                          </span>
                        </div>
                        <p className="text-sm text-gray-600 mb-3">{challenge.description[language]}</p>
                        
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-2">
                            <Zap className="w-4 h-4 text-yellow-500 fill-yellow-500" />
                            <span className="text-sm bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent">
                              +{challenge.points} {t.pts}
                            </span>
                          </div>

                          {challenge.completed ? (
                            <motion.div
                              initial={{ scale: 0 }}
                              animate={{ scale: 1 }}
                              className="flex items-center gap-2 text-green-600"
                            >
                              <CheckCircle2 className="w-5 h-5 fill-green-600" />
                              <span className="text-sm">{t.completed}</span>
                            </motion.div>
                          ) : (
                            <Button
                              size="sm"
                              onClick={() => completeChallenge(challenge.id)}
                              className={`bg-gradient-to-r ${challenge.color} text-white border-0 hover:shadow-lg`}
                            >
                              <CheckCircle2 className="w-4 h-4 mr-2" />
                              {t.complete}
                            </Button>
                          )}
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Sparkle Effect on Complete */}
                  {challenge.completed && (
                    <motion.div
                      initial={{ opacity: 0, scale: 0 }}
                      animate={{ opacity: 1, scale: 1 }}
                      className="absolute top-2 right-2"
                    >
                      <Award className="w-8 h-8 text-yellow-500 fill-yellow-400" />
                    </motion.div>
                  )}
                </Card>
              </motion.div>
            ))}
          </AnimatePresence>
        </div>

        {/* Achievement Banner */}
        {completedCount === dailyChallenges.length && (
          <motion.div
            initial={{ opacity: 0, y: 20, scale: 0.9 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            className="mt-6 bg-gradient-to-r from-yellow-400 via-orange-500 to-red-500 rounded-2xl p-6 text-white text-center shadow-2xl"
          >
            <motion.div
              animate={{ rotate: [0, 10, -10, 10, 0] }}
              transition={{ duration: 0.5, repeat: Infinity, repeatDelay: 2 }}
              className="text-6xl mb-2"
            >
              🎉
            </motion.div>
            <h3 className="text-2xl mb-2">
              {language === 'ps' ? 'مبارک شه! ټولې ننګونې مو بشپړې کړې!' :
               language === 'fa' ? 'تبریک! تمام چالش‌ها را تکمیل کردید!' :
               'Congratulations! All challenges completed!'}
            </h3>
            <p className="opacity-90">
              {language === 'ps' ? 'تاسو د نن ورځې لپاره ډیر ښه کار وکړ!' :
               language === 'fa' ? 'شما امروز عالی کار کردید!' :
               'You did amazing work today!'}
            </p>
          </motion.div>
        )}
      </motion.div>
    </div>
  );
}
