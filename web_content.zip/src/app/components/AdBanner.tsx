import { motion } from 'motion/react';
import { usePremium } from '../hooks/usePremium';

interface AdBannerProps {
  type?: 'small' | 'medium' | 'large';
  className?: string;
  userId?: string;
}

export function AdBanner({ type = 'small', className = '', userId }: AdBannerProps) {
  const { isPremium } = usePremium(userId);
  
  // Don't show ads to premium users
  if (isPremium) {
    return null;
  }

  // Safety check for type
  if (!type) {
    type = 'small';
  }

  const heights = {
    small: 'h-16',
    medium: 'h-24',
    large: 'h-32',
  };

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      className={`${heights[type]} ${className}`}
    >
      <div className="relative w-full h-full rounded-2xl overflow-hidden bg-gradient-to-r from-purple-500 via-pink-500 to-red-500 flex items-center justify-center">
        <div className="absolute inset-0 bg-black/10" />
        <div className="relative text-center text-white">
          <p className="text-sm opacity-75">AdMob Advertisement Space</p>
          <p className="text-xs opacity-50 mt-1">{type.toUpperCase()} Banner - {type === 'small' ? '320x50' : type === 'medium' ? '320x100' : '320x250'}</p>
        </div>
      </div>
    </motion.div>
  );
}