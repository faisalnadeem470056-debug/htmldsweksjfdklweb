import { X, User, Heart, Calendar, FileText, Award, Settings, LogOut, Mail, Phone, MapPin, Edit } from "lucide-react";
import { Button } from "./ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "./ui/avatar";
import { Badge } from "./ui/badge";
import { Card } from "./ui/card";
import { useAuth } from "../contexts/AuthContext";
import { toast } from "sonner@2.0.3";

interface ProfileSidebarProps {
  isOpen: boolean;
  onClose: () => void;
  setActivePage?: (page: string) => void;
}

export function ProfileSidebar({ isOpen, onClose, setActivePage }: ProfileSidebarProps) {
  const { user, logout } = useAuth();
  const menuItems = [
    { icon: User, label: "My Profile", labelDari: "زما پروفایل", badge: null, page: "profile" },
    { icon: Heart, label: "Saved Items", labelDari: "خوندي شوي", badge: "12", page: null },
    { icon: Calendar, label: "Appointments", labelDari: "ملاقاتونه", badge: "2", page: "appointments" },
    { icon: FileText, label: "Medical Records", labelDari: "طبي ریکارډونه", badge: null, page: "community" },
    { icon: Award, label: "Health Goals", labelDari: "روغتیايي اهداف", badge: null, page: null },
    { icon: Settings, label: "Settings", labelDari: "تنظیمات", badge: null, page: "settings" },
  ];

  return (
    <>
      {/* Backdrop */}
      {isOpen && (
        <div 
          className="fixed inset-0 bg-black/50 backdrop-blur-sm z-[100] transition-opacity duration-300"
          onClick={onClose}
        />
      )}

      {/* Sidebar */}
      <div 
        className={`fixed top-0 right-0 h-full w-80 bg-white shadow-2xl z-[101] transform transition-transform duration-300 ${
          isOpen ? "translate-x-0" : "translate-x-full"
        }`}
      >
        <div className="flex flex-col h-full">
          {/* Header with gradient */}
          <div className="relative bg-gradient-to-br from-emerald-500 via-teal-600 to-cyan-600 p-6 pb-20">
            {/* Background Pattern */}
            <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMjAwIiBoZWlnaHQ9IjIwMCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZGVmcz48cGF0dGVybiBpZD0iZ3JpZCIgd2lkdGg9IjQwIiBoZWlnaHQ9IjQwIiBwYXR0ZXJuVW5pdHM9InVzZXJTcGFjZU9uVXNlIj48cGF0aCBkPSJNIDQwIDAgTCAwIDAgMCA0MCIgZmlsbD0ibm9uZSIgc3Ryb2tlPSJ3aGl0ZSIgc3Ryb2tlLW9wYWNpdHk9IjAuMSIgc3Ryb2tlLXdpZHRoPSIxIi8+PC9wYXR0ZXJuPjwvZGVmcz48cmVjdCB3aWR0aD0iMTAwJSIgaGVpZ2h0PSIxMDAlIiBmaWxsPSJ1cmwoI2dyaWQpIi8+PC9zdmc+')] opacity-30"></div>
            
            {/* Close Button */}
            <Button 
              variant="ghost" 
              size="icon" 
              onClick={onClose}
              className="absolute top-4 left-4 text-white hover:bg-white/20 rounded-full z-10"
            >
              <X className="w-5 h-5" />
            </Button>

            <div className="text-center text-white relative z-10">
              <h2 className="text-xl mb-1">My Profile</h2>
              <p className="text-sm text-emerald-100">زما پروفایل</p>
            </div>
          </div>

          {/* Profile Card - Overlapping */}
          <div className="px-6 -mt-16 relative z-10">
            <Card className="p-6 shadow-xl border-0">
              <div className="flex flex-col items-center">
                {/* Avatar with Edit Button */}
                <div className="relative mb-4">
                  <Avatar className="w-24 h-24 border-4 border-white shadow-lg">
                    <AvatarImage src={user?.avatar || "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150&h=150&fit=crop"} />
                    <AvatarFallback className="bg-gradient-to-br from-emerald-400 to-teal-500 text-white text-2xl">
                      {user?.name?.split(' ').map(n => n[0]).join('').toUpperCase() || "U"}
                    </AvatarFallback>
                  </Avatar>
                  <Button 
                    size="icon" 
                    className="absolute -bottom-1 -right-1 w-8 h-8 rounded-full bg-gradient-to-r from-emerald-500 to-teal-600 shadow-lg hover:scale-110 transition-transform"
                  >
                    <Edit className="w-4 h-4 text-white" />
                  </Button>
                </div>

                <h3 className="text-xl mb-1">{user?.name || "User"}</h3>
                <p className="text-sm text-gray-500 mb-3">کاروونکی</p>
                
                {/* Contact Info */}
                <div className="w-full space-y-2 text-sm">
                  <div className="flex items-center gap-2 text-gray-600">
                    <Mail className="w-4 h-4 text-emerald-600" />
                    <span className="text-xs truncate">{user?.email || "user@healmate.af"}</span>
                  </div>
                  {user?.phone && (
                    <div className="flex items-center gap-2 text-gray-600">
                      <Phone className="w-4 h-4 text-emerald-600" />
                      <span>{user.phone}</span>
                    </div>
                  )}
                  <div className="flex items-center gap-2 text-gray-600">
                    <MapPin className="w-4 h-4 text-emerald-600" />
                    <span>Afghanistan</span>
                  </div>
                </div>

                {/* Health Score */}
                <div className="w-full mt-4 p-3 bg-gradient-to-r from-emerald-50 to-teal-50 rounded-lg">
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-700">Health Score</span>
                    <Badge className="bg-gradient-to-r from-emerald-500 to-teal-600 text-white">
                      85/100
                    </Badge>
                  </div>
                </div>
              </div>
            </Card>
          </div>

          {/* Menu Items */}
          <div className="flex-1 overflow-y-auto px-6 py-6 space-y-2">
            {menuItems.map((item, index) => (
              <button
                key={index}
                onClick={() => {
                  if (item.page && setActivePage) {
                    setActivePage(item.page);
                    onClose();
                  }
                }}
                className="w-full flex items-center justify-between p-3 rounded-xl hover:bg-gray-50 transition-all active:scale-95 group"
              >
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-emerald-100 to-teal-100 flex items-center justify-center group-hover:scale-110 transition-transform">
                    <item.icon className="w-5 h-5 text-emerald-600" />
                  </div>
                  <div className="text-left">
                    <p className="text-sm text-gray-800">{item.label}</p>
                    <p className="text-xs text-gray-500">{item.labelDari}</p>
                  </div>
                </div>
                {item.badge && (
                  <Badge className="bg-gradient-to-r from-red-500 to-pink-500 text-white">
                    {item.badge}
                  </Badge>
                )}
              </button>
            ))}
          </div>

          {/* Logout Button */}
          <div className="p-6 border-t border-gray-200">
            <Button 
              onClick={() => {
                logout();
                toast.success("Logged out successfully! وتلو په بریالیتوب سره!");
                onClose();
              }}
              className="w-full bg-gradient-to-r from-red-500 to-pink-500 hover:from-red-600 hover:to-pink-600 text-white shadow-lg"
              size="lg"
            >
              <LogOut className="w-5 h-5 mr-2" />
              <div className="text-left">
                <div>Logout</div>
                <div className="text-xs opacity-90">وتل</div>
              </div>
            </Button>
          </div>
        </div>
      </div>
    </>
  );
}
