import { useState } from 'react';
import {
  Heart, DollarSign, CreditCard, Users, ArrowLeft, Plus, Edit2, Trash2,
  Target, TrendingUp, Globe, MapPin, Calendar, Phone, Share2, CheckCircle,
  X, Wallet, QrCode, Copy, ExternalLink, Shield, Crown, AlertCircle
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { AdBanner } from './AdBanner';
import { ImageWithFallback } from './figma/ImageWithFallback';

interface DonationSystemProps {
  language: 'ps' | 'fa' | 'en';
  onBack: () => void;
  isAdmin?: boolean;
  adminEmail?: string;
}

interface DonationCase {
  id: number;
  patientName: { ps: string; fa: string; en: string };
  disease: { ps: string; fa: string; en: string };
  story: { ps: string; fa: string; en: string };
  targetAmount: number;
  raisedAmount: number;
  currency: 'AFN' | 'USD';
  image: string;
  location: { ps: string; fa: string; en: string };
  age: number;
  gender: { ps: string; fa: string; en: string };
  urgency: 'critical' | 'high' | 'medium';
  verified: boolean;
  donors: number;
  createdDate: string;
  category: 'heart' | 'cancer' | 'kidney' | 'surgery' | 'emergency' | 'children' | 'other';
}

const translations = {
  ps: {
    title: 'مرسته وکړئ',
    subtitle: 'د اړمنو ناروغانو سره مرسته وکړئ',
    allCases: 'ټولې قضیې',
    critical: 'بیړني',
    donate: 'مرسته وکړئ',
    viewDetails: 'تفصیل وګورئ',
    raised: 'راټول شوي',
    target: 'هدف',
    donors: 'مرسته کوونکي',
    share: 'شریک کړئ',
    donateNow: 'اوس مرسته وکړئ',
    selectAmount: 'رقم غوره کړئ',
    customAmount: 'ځانګړی رقم',
    paymentMethod: 'د تادیې طریقه',
    paypal: 'PayPal',
    card: 'کارډ',
    hesabPay: 'حساب پے',
    easypaisa: 'Easypaisa',
    bankTransfer: 'بانکي لیږد',
    patientInfo: 'د ناروغ معلومات',
    name: 'نوم',
    age: 'عمر',
    years: 'کلن',
    gender: 'جنس',
    location: 'موقعیت',
    disease: 'ناروغي',
    story: 'کیسه',
    urgency: 'بیړنیتوب',
    verified: 'تایید شوی',
    addCase: 'نوی قضیه',
    edit: 'تغیر',
    delete: 'حذف',
    close: 'تړل',
    male: 'نارینه',
    female: 'ښځینه',
    child: 'ماشوم',
    confirmDonation: 'تایید کړئ',
    cancel: 'لغوه',
    thankYou: 'مننه!',
    donationSuccess: 'ستاسو مرسته بریالۍ وه!',
    helpMore: 'نورو سره هم مرسته وکړئ',
    categories: {
      all: 'ټول',
      heart: 'زړه',
      cancer: 'سرطان',
      kidney: 'پښتورګي',
      surgery: 'جراحي',
      emergency: 'بیړني',
      children: 'ماشومان',
      other: 'نور'
    },
    urgencyLevels: {
      critical: '🔴 خورا بیړني',
      high: '🟠 بیړني',
      medium: '🟡 منځني'
    },
    paymentInfo: {
      paypal: 'د PayPal له لاري تادیه وکړئ',
      card: 'د کارډ له لاري تادیه وکړئ',
      hesabPay: 'حساب پے: +93779494512',
      bankDetails: 'د بانک تفصیلات'
    },
    copiedToClipboard: 'کاپي شو!',
    ownerInfo: 'ډاکټر ابراهیم خاکسار',
    hesabPayNumber: '+93779494512',
    addPaymentMethod: 'د تادیې میتود اضافه کړئ'
  },
  fa: {
    title: 'کمک کنید',
    subtitle: 'به بیماران نیازمند کمک کنید',
    allCases: 'همه موارد',
    critical: 'فوری',
    donate: 'کمک کنید',
    viewDetails: 'مشاهده جزئیات',
    raised: 'جمع‌آوری شده',
    target: 'هدف',
    donors: 'کمک‌کنندگان',
    share: 'اشتراک',
    donateNow: 'اکنون کمک کنید',
    selectAmount: 'مبلغ را انتخاب کنید',
    customAmount: 'مبلغ دلخواه',
    paymentMethod: 'روش پرداخت',
    paypal: 'پی‌پال',
    card: 'کارت',
    hesabPay: 'حساب پے',
    easypaisa: 'ایزی پیسہ',
    bankTransfer: 'انتقال بانکی',
    patientInfo: 'اطلاعات بیمار',
    name: 'نام',
    age: 'سن',
    years: 'ساله',
    gender: 'جنسیت',
    location: 'موقعیت',
    disease: 'بیماری',
    story: 'داستان',
    urgency: 'فوریت',
    verified: 'تایید شده',
    addCase: 'مورد جدید',
    edit: 'ویرایش',
    delete: 'حذف',
    close: 'بستن',
    male: 'مرد',
    female: 'زن',
    child: 'کودک',
    confirmDonation: 'تایید',
    cancel: 'لغو',
    thankYou: 'متشکریم!',
    donationSuccess: 'کمک شما موفقیت‌آمیز بود!',
    helpMore: 'به دیگران نیز کمک کنید',
    categories: {
      all: 'همه',
      heart: 'قلب',
      cancer: 'سرطان',
      kidney: 'کلیه',
      surgery: 'جراحی',
      emergency: 'اضطراری',
      children: 'کودکان',
      other: 'سایر'
    },
    urgencyLevels: {
      critical: '🔴 بسیار فوری',
      high: '🟠 فوری',
      medium: '🟡 متوسط'
    },
    paymentInfo: {
      paypal: 'پرداخت از طریق پی‌پال',
      card: 'پرداخت با کارت',
      hesabPay: 'حساب پے: +93779494512',
      bankDetails: 'جزئیات بانکی'
    },
    copiedToClipboard: 'کپی شد!',
    ownerInfo: 'داکتر ابراهیم خاکسار',
    hesabPayNumber: '+93779494512',
    addPaymentMethod: 'افزودن روش پرداخت'
  },
  en: {
    title: 'Help & Support',
    subtitle: 'Help patients in need',
    allCases: 'All Cases',
    critical: 'Critical',
    donate: 'Donate',
    viewDetails: 'View Details',
    raised: 'Raised',
    target: 'Target',
    donors: 'Donors',
    share: 'Share',
    donateNow: 'Donate Now',
    selectAmount: 'Select Amount',
    customAmount: 'Custom Amount',
    paymentMethod: 'Payment Method',
    paypal: 'PayPal',
    card: 'Credit/Debit Card',
    hesabPay: 'Hesab Pay',
    easypaisa: 'Easypaisa',
    bankTransfer: 'Bank Transfer',
    patientInfo: 'Patient Information',
    name: 'Name',
    age: 'Age',
    years: 'years old',
    gender: 'Gender',
    location: 'Location',
    disease: 'Disease',
    story: 'Story',
    urgency: 'Urgency',
    verified: 'Verified',
    addCase: 'Add New Case',
    edit: 'Edit',
    delete: 'Delete',
    close: 'Close',
    male: 'Male',
    female: 'Female',
    child: 'Child',
    confirmDonation: 'Confirm',
    cancel: 'Cancel',
    thankYou: 'Thank You!',
    donationSuccess: 'Your donation was successful!',
    helpMore: 'Help others too',
    categories: {
      all: 'All',
      heart: 'Heart',
      cancer: 'Cancer',
      kidney: 'Kidney',
      surgery: 'Surgery',
      emergency: 'Emergency',
      children: 'Children',
      other: 'Other'
    },
    urgencyLevels: {
      critical: '🔴 Critical',
      high: '🟠 High',
      medium: '🟡 Medium'
    },
    paymentInfo: {
      paypal: 'Pay via PayPal',
      card: 'Pay with Card',
      hesabPay: 'Hesab Pay: +93779494512',
      bankDetails: 'Bank Details'
    },
    copiedToClipboard: 'Copied!',
    ownerInfo: 'Dr. Ibrahim Khaksar',
    hesabPayNumber: '+93779494512',
    addPaymentMethod: 'Add Payment Method'
  }
};

const initialCases: DonationCase[] = [
  {
    id: 1,
    patientName: { ps: 'احمد شاه', fa: 'احمد شاه', en: 'Ahmad Shah' },
    disease: { ps: 'د زړه جراحي', fa: 'عمل جراحی قلب', en: 'Heart Surgery' },
    story: {
      ps: 'احمد شاه ۸ کلن ماشوم دی چې د زړه د جراحۍ ته اړتیا لري. د هغه کورنۍ خورا غریبه ده او د جراحۍ لګښت یې نشي تادیه کولی. د احمد شاه د ژوند ژغورلو لپاره ستاسو مرسته ته اړتیا لري.',
      fa: 'احمد شاه کودک ۸ ساله است که به عمل جراحی قلب نیاز دارد. خانواده او بسیار فقیر است و نمی‌تواند هزینه عمل را بپردازد. احمد شاه برای نجات جانش به کمک شما نیاز دارد.',
      en: 'Ahmad Shah is an 8-year-old child who needs heart surgery. His family is very poor and cannot afford the surgery cost. Ahmad Shah needs your help to save his life.'
    },
    targetAmount: 15000,
    raisedAmount: 8500,
    currency: 'USD',
    image: 'https://images.unsplash.com/photo-1631815588090-d4bfec5b1ccb?w=600',
    location: { ps: 'کابل، افغانستان', fa: 'کابل، افغانستان', en: 'Kabul, Afghanistan' },
    age: 8,
    gender: { ps: 'نارینه', fa: 'پسر', en: 'Male' },
    urgency: 'critical',
    verified: true,
    donors: 142,
    createdDate: '2025-01-15',
    category: 'heart'
  },
  {
    id: 2,
    patientName: { ps: 'فاطمه', fa: 'فاطمه', en: 'Fatema' },
    disease: { ps: 'سرطان', fa: 'سرطان', en: 'Cancer Treatment' },
    story: {
      ps: 'فاطمه ۳۵ کلنه میرمن ده چې د سرطان د درملنې ته اړتیا لري. د هغې د درملنې لګښت خورا ډیر دی او د هغې کورنۍ نشي کولی چې دا لګښت تادیه کړي.',
      fa: 'فاطمه خانم ۳۵ ساله است که به درمان سرطان نیاز دارد. هزینه درمان او بسیار زیاد است و خانواده او نمی‌تواند این هزینه را بپردازد.',
      en: 'Fatema is a 35-year-old woman who needs cancer treatment. The treatment cost is very high and her family cannot afford it.'
    },
    targetAmount: 25000,
    raisedAmount: 12000,
    currency: 'USD',
    image: 'https://images.unsplash.com/photo-1576765608535-5f04d1e3f289?w=600',
    location: { ps: 'هرات، افغانستان', fa: 'هرات، افغانستان', en: 'Herat, Afghanistan' },
    age: 35,
    gender: { ps: 'ښځینه', fa: 'زن', en: 'Female' },
    urgency: 'high',
    verified: true,
    donors: 89,
    createdDate: '2025-01-10',
    category: 'cancer'
  },
  {
    id: 3,
    patientName: { ps: 'علي رضا', fa: 'علی رضا', en: 'Ali Reza' },
    disease: { ps: 'د پښتورګو ناکامي', fa: 'نارسایی کلیه', en: 'Kidney Failure' },
    story: {
      ps: 'علي رضا د پښتورګو د ناکامۍ له امله د پیوند ته اړتیا لري. د هغه کورنۍ د دې لوی جراحۍ لګښت نشي تادیه کولی.',
      fa: 'علی رضا به دلیل نارسایی کلیه به پیوند نیاز دارد. خانواده او نمی‌تواند هزینه این عمل بزرگ را بپردازد.',
      en: 'Ali Reza needs a kidney transplant due to kidney failure. His family cannot afford the cost of this major surgery.'
    },
    targetAmount: 30000,
    raisedAmount: 5000,
    currency: 'USD',
    image: 'https://images.unsplash.com/photo-1579684385127-1ef15d508118?w=600',
    location: { ps: 'مزار شریف', fa: 'مزار شریف', en: 'Mazar-e-Sharif' },
    age: 42,
    gender: { ps: 'نارینه', fa: 'مرد', en: 'Male' },
    urgency: 'critical',
    verified: true,
    donors: 45,
    createdDate: '2025-01-20',
    category: 'kidney'
  },
  {
    id: 4,
    patientName: { ps: 'زینب', fa: 'زینب', en: 'Zainab' },
    disease: { ps: 'د زیږون جراحي', fa: 'عمل زایمان', en: 'Emergency Delivery' },
    story: {
      ps: 'زینب حامله میرمن ده چې د بیړني جراحي ته اړتیا لري. د هغې او د ماشوم ژوند په خطر کې دی.',
      fa: 'زینب خانم باردار است که به عمل جراحی فوری نیاز دارد. جان او و نوزادش در خطر است.',
      en: 'Zainab is a pregnant woman who needs emergency surgery. Her life and her baby\'s life are at risk.'
    },
    targetAmount: 5000,
    raisedAmount: 3200,
    currency: 'USD',
    image: 'https://images.unsplash.com/photo-1584515933487-779824d29309?w=600',
    location: { ps: 'کندهار', fa: 'قندهار', en: 'Kandahar' },
    age: 28,
    gender: { ps: 'ښځینه', fa: 'زن', en: 'Female' },
    urgency: 'critical',
    verified: true,
    donors: 67,
    createdDate: '2025-01-25',
    category: 'emergency'
  }
];

const suggestedAmounts = {
  USD: [10, 25, 50, 100, 250, 500],
  AFN: [500, 1000, 2500, 5000, 10000, 25000]
};

export function DonationSystem({ language, onBack, isAdmin, adminEmail }: DonationSystemProps) {
  const [cases, setCases] = useState<DonationCase[]>(initialCases);
  const [selectedCase, setSelectedCase] = useState<DonationCase | null>(null);
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [showDonationModal, setShowDonationModal] = useState(false);
  const [selectedAmount, setSelectedAmount] = useState<number | null>(null);
  const [customAmount, setCustomAmount] = useState('');
  const [selectedPayment, setSelectedPayment] = useState<string>('');
  const [showSuccessModal, setShowSuccessModal] = useState(false);

  const t = translations[language];
  const isOwner = isAdmin && adminEmail === 'ibrahimkhaksar.it@gmail.com';

  const filteredCases = cases.filter(c => 
    selectedCategory === 'all' || c.category === selectedCategory
  );

  const handleDonate = (donationCase: DonationCase) => {
    setSelectedCase(donationCase);
    setShowDonationModal(true);
    setSelectedAmount(null);
    setCustomAmount('');
    setSelectedPayment('');
  };

  const handleConfirmDonation = () => {
    const amount = selectedAmount || parseFloat(customAmount);
    
    if (!amount || amount <= 0) {
      alert(language === 'ps' ? 'مهرباني وکړئ رقم انتخاب کړئ' : language === 'fa' ? 'لطفا مبلغ را انتخاب کنید' : 'Please select an amount');
      return;
    }

    if (!selectedPayment) {
      alert(language === 'ps' ? 'مهرباني وکړئ د تادیې طریقه انتخاب کړئ' : language === 'fa' ? 'لطفا روش پرداخت را انتخاب کنید' : 'Please select a payment method');
      return;
    }

    // Process payment based on method
    if (selectedPayment === 'paypal') {
      window.open('https://www.paypal.com/donate', '_blank');
    } else if (selectedPayment === 'hesabPay') {
      const message = `${language === 'ps' ? 'مرسته' : language === 'fa' ? 'کمک' : 'Donation'}: $${amount} ${language === 'ps' ? 'د' : language === 'fa' ? 'برای' : 'for'} ${selectedCase?.patientName[language]}`;
      window.open(`https://wa.me/93779494512?text=${encodeURIComponent(message)}`, '_blank');
    }

    setShowDonationModal(false);
    setShowSuccessModal(true);
    
    setTimeout(() => {
      setShowSuccessModal(false);
      setSelectedCase(null);
    }, 3000);
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    alert(t.copiedToClipboard);
  };

  const handleShare = async (donationCase: DonationCase) => {
    const message = `${language === 'ps' ? '💝 مرسته وکړئ' : language === 'fa' ? '💝 کمک کنید' : '💝 Help Needed'}\n\n${donationCase.patientName[language]}\n${donationCase.disease[language]}\n\n${language === 'ps' ? 'هدف:' : language === 'fa' ? 'هدف:' : 'Target:'} $${donationCase.targetAmount}\n${language === 'ps' ? 'راټول شوي:' : language === 'fa' ? 'جمع‌شده:' : 'Raised:'} $${donationCase.raisedAmount}\n\n${t.ownerInfo}: ${t.hesabPayNumber}`;
    
    if (navigator.share) {
      try {
        await navigator.share({
          title: donationCase.patientName[language],
          text: message
        });
      } catch (err) {
        // که share ناکامه شي، په clipboard کې کاپي کړه
        if (err instanceof Error && err.name !== 'AbortError') {
          copyToClipboard(message);
        }
      }
    } else {
      copyToClipboard(message);
    }
  };

  const handleAddCase = () => {
    const newCase: DonationCase = {
      id: Date.now(),
      patientName: { ps: 'نوی ناروغ', fa: 'بیمار جدید', en: 'New Patient' },
      disease: { ps: 'ناروغي', fa: 'بیماری', en: 'Disease' },
      story: { ps: 'کیسه اضافه کړئ', fa: 'داستان اضافه کنید', en: 'Add story' },
      targetAmount: 10000,
      raisedAmount: 0,
      currency: 'USD',
      image: 'https://images.unsplash.com/photo-1631815588090-d4bfec5b1ccb?w=600',
      location: { ps: 'کابل', fa: 'کابل', en: 'Kabul' },
      age: 0,
      gender: { ps: 'نارینه', fa: 'مرد', en: 'Male' },
      urgency: 'medium',
      verified: false,
      donors: 0,
      createdDate: new Date().toISOString().split('T')[0],
      category: 'other'
    };
    setCases([newCase, ...cases]);
    alert(language === 'ps' ? '✅ نوی قضیه اضافه شوه!' : language === 'fa' ? '✅ مورد جدید اضافه شد!' : '✅ New case added!');
  };

  const handleDelete = (id: number) => {
    if (confirm(language === 'ps' ? 'ایا تاسو ډاډه یاست؟' : language === 'fa' ? 'آیا مطمئن هستید؟' : 'Are you sure?')) {
      setCases(cases.filter(c => c.id !== id));
      alert(language === 'ps' ? '✅ حذف شو!' : language === 'fa' ? '✅ حذف شد!' : '✅ Deleted!');
    }
  };

  const getProgress = (raised: number, target: number) => {
    return Math.min((raised / target) * 100, 100);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-rose-50 via-pink-50 to-red-50">
      {/* Header */}
      <div className="sticky top-0 z-40 bg-white/80 backdrop-blur-lg border-b border-rose-200">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between mb-4">
            <button
              onClick={onBack}
              className="flex items-center gap-2 text-gray-700 hover:text-rose-600 transition-colors"
            >
              <ArrowLeft className="w-5 h-5" />
              <span>{language === 'ps' ? 'شاته' : language === 'fa' ? 'بازگشت' : 'Back'}</span>
            </button>
            {isOwner && (
              <Button
                onClick={handleAddCase}
                className="bg-gradient-to-r from-rose-600 to-pink-600 text-white hover:shadow-lg"
              >
                <Plus className="w-4 h-4 mr-2" />
                {t.addCase}
              </Button>
            )}
          </div>

          <div className="text-center mb-4">
            <h1 className="text-3xl font-bold bg-gradient-to-r from-rose-600 to-pink-600 bg-clip-text text-transparent mb-2 flex items-center justify-center gap-3">
              <Heart className="w-8 h-8 text-rose-600 fill-rose-600" />
              {t.title}
            </h1>
            <p className="text-gray-600">{t.subtitle}</p>
          </div>

          {/* Categories */}
          <div className="flex items-center gap-2 overflow-x-auto pb-2">
            {Object.entries(t.categories).map(([key, label]) => (
              <button
                key={key}
                onClick={() => setSelectedCategory(key)}
                className={`px-4 py-2 rounded-xl whitespace-nowrap transition-all ${
                  selectedCategory === key
                    ? 'bg-gradient-to-r from-rose-600 to-pink-600 text-white'
                    : 'bg-white text-gray-700 hover:bg-rose-50'
                }`}
              >
                {label}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* AdBanner */}
      <div className="container mx-auto px-4 py-4">
        <AdBanner variant="horizontal" />
      </div>

      {/* Cases Grid */}
      <div className="container mx-auto px-4 pb-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredCases.map((donationCase, index) => {
            const progress = getProgress(donationCase.raisedAmount, donationCase.targetAmount);
            
            return (
              <motion.div
                key={donationCase.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                className="bg-white rounded-3xl overflow-hidden shadow-lg hover:shadow-2xl transition-all group"
              >
                {/* Image */}
                <div className="relative h-56 overflow-hidden">
                  <ImageWithFallback
                    src={donationCase.image}
                    alt={donationCase.patientName[language]}
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                  />
                  
                  {/* Urgency Badge */}
                  {donationCase.urgency === 'critical' && (
                    <div className="absolute top-3 left-3 bg-red-500 text-white px-3 py-1 rounded-full text-xs font-bold animate-pulse flex items-center gap-1">
                      <AlertCircle className="w-3 h-3" />
                      {t.urgencyLevels[donationCase.urgency]}
                    </div>
                  )}
                  
                  {/* Verified Badge */}
                  {donationCase.verified && (
                    <div className="absolute top-3 right-3 bg-blue-500 text-white px-3 py-1 rounded-full text-xs font-bold flex items-center gap-1">
                      <Shield className="w-3 h-3" />
                      {t.verified}
                    </div>
                  )}

                  {/* Share Button */}
                  <button
                    onClick={() => handleShare(donationCase)}
                    className="absolute bottom-3 right-3 bg-white/90 backdrop-blur-sm p-2 rounded-full hover:bg-white transition-colors"
                  >
                    <Share2 className="w-4 h-4 text-rose-600" />
                  </button>
                </div>

                {/* Content */}
                <div className="p-6">
                  <h3 className="text-xl font-bold text-gray-900 mb-1">
                    {donationCase.patientName[language]}
                  </h3>
                  <p className="text-rose-600 text-sm mb-3">{donationCase.disease[language]}</p>

                  {/* Progress Bar */}
                  <div className="mb-4">
                    <div className="flex justify-between text-sm mb-2">
                      <span className="text-gray-600">
                        {t.raised}: <span className="font-bold text-rose-600">${donationCase.raisedAmount.toLocaleString()}</span>
                      </span>
                      <span className="text-gray-600">
                        {t.target}: <span className="font-bold">${donationCase.targetAmount.toLocaleString()}</span>
                      </span>
                    </div>
                    <div className="w-full h-3 bg-gray-200 rounded-full overflow-hidden">
                      <motion.div
                        initial={{ width: 0 }}
                        animate={{ width: `${progress}%` }}
                        transition={{ duration: 1, delay: index * 0.1 }}
                        className="h-full bg-gradient-to-r from-rose-500 to-pink-500"
                      />
                    </div>
                    <p className="text-xs text-gray-500 mt-1 text-right">{progress.toFixed(0)}%</p>
                  </div>

                  {/* Info */}
                  <div className="flex items-center gap-4 text-sm text-gray-600 mb-4">
                    <div className="flex items-center gap-1">
                      <MapPin className="w-4 h-4" />
                      <span className="text-xs">{donationCase.location[language]}</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <Users className="w-4 h-4" />
                      <span>{donationCase.donors}</span>
                    </div>
                  </div>

                  {/* Admin Actions */}
                  {isOwner && (
                    <div className="flex gap-2 mb-3">
                      <Button
                        onClick={() => alert(language === 'ps' ? 'د تغیر فیچر ډېر ژر!' : language === 'fa' ? 'ویرایش بزودی!' : 'Edit feature coming soon!')}
                        className="flex-1 bg-blue-500 text-white hover:bg-blue-600 py-2 text-sm"
                      >
                        <Edit2 className="w-3 h-3 mr-1" />
                        {t.edit}
                      </Button>
                      <Button
                        onClick={() => handleDelete(donationCase.id)}
                        className="flex-1 bg-red-500 text-white hover:bg-red-600 py-2 text-sm"
                      >
                        <Trash2 className="w-3 h-3 mr-1" />
                        {t.delete}
                      </Button>
                    </div>
                  )}

                  {/* Actions */}
                  <div className="flex gap-2">
                    <Button
                      onClick={() => setSelectedCase(donationCase)}
                      className="flex-1 bg-gray-100 text-gray-700 hover:bg-gray-200"
                    >
                      {t.viewDetails}
                    </Button>
                    <Button
                      onClick={() => handleDonate(donationCase)}
                      className="flex-1 bg-gradient-to-r from-rose-600 to-pink-600 text-white hover:shadow-lg"
                    >
                      <Heart className="w-4 h-4 mr-2" />
                      {t.donate}
                    </Button>
                  </div>
                </div>
              </motion.div>
            );
          })}
        </div>
      </div>

      {/* Details Modal */}
      <AnimatePresence>
        {selectedCase && !showDonationModal && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/70 backdrop-blur-sm z-50 flex items-center justify-center p-4 overflow-y-auto"
            onClick={() => setSelectedCase(null)}
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="bg-white rounded-3xl max-w-2xl w-full my-8"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="relative h-72">
                <ImageWithFallback
                  src={selectedCase.image}
                  alt={selectedCase.patientName[language]}
                  className="w-full h-full object-cover"
                />
                <button
                  onClick={() => setSelectedCase(null)}
                  className="absolute top-4 right-4 bg-white/90 backdrop-blur-sm rounded-full p-2 hover:bg-white transition-colors"
                >
                  <X className="w-5 h-5" />
                </button>
                {selectedCase.urgency === 'critical' && (
                  <div className="absolute top-4 left-4 bg-red-500 text-white px-4 py-2 rounded-full font-bold animate-pulse">
                    {t.urgencyLevels[selectedCase.urgency]}
                  </div>
                )}
              </div>

              <div className="p-6">
                <h2 className="text-3xl font-bold text-gray-900 mb-2">
                  {selectedCase.patientName[language]}
                </h2>
                <p className="text-rose-600 text-lg mb-4">{selectedCase.disease[language]}</p>

                {/* Progress */}
                <div className="mb-6">
                  <div className="flex justify-between text-lg mb-2">
                    <span className="font-bold text-rose-600">
                      ${selectedCase.raisedAmount.toLocaleString()}
                    </span>
                    <span className="text-gray-600">
                      {language === 'ps' ? 'له' : language === 'fa' ? 'از' : 'of'} ${selectedCase.targetAmount.toLocaleString()}
                    </span>
                  </div>
                  <div className="w-full h-4 bg-gray-200 rounded-full overflow-hidden">
                    <div
                      style={{ width: `${getProgress(selectedCase.raisedAmount, selectedCase.targetAmount)}%` }}
                      className="h-full bg-gradient-to-r from-rose-500 to-pink-500"
                    />
                  </div>
                  <div className="flex justify-between text-sm text-gray-600 mt-2">
                    <span>{selectedCase.donors} {t.donors}</span>
                    <span>{getProgress(selectedCase.raisedAmount, selectedCase.targetAmount).toFixed(0)}%</span>
                  </div>
                </div>

                {/* Patient Info */}
                <div className="bg-rose-50 rounded-2xl p-4 mb-6 space-y-2">
                  <h3 className="font-bold text-gray-900 mb-3">{t.patientInfo}</h3>
                  <div className="grid grid-cols-2 gap-3 text-sm">
                    <div>
                      <span className="text-gray-600">{t.age}:</span>
                      <span className="ml-2 font-semibold">{selectedCase.age} {t.years}</span>
                    </div>
                    <div>
                      <span className="text-gray-600">{t.gender}:</span>
                      <span className="ml-2 font-semibold">{selectedCase.gender[language]}</span>
                    </div>
                    <div className="col-span-2">
                      <span className="text-gray-600">{t.location}:</span>
                      <span className="ml-2 font-semibold">{selectedCase.location[language]}</span>
                    </div>
                  </div>
                </div>

                {/* Story */}
                <div className="mb-6">
                  <h3 className="font-bold text-gray-900 mb-2">{t.story}</h3>
                  <p className="text-gray-600 leading-relaxed">{selectedCase.story[language]}</p>
                </div>

                {/* Actions */}
                <div className="flex gap-3">
                  <Button
                    onClick={() => handleShare(selectedCase)}
                    className="flex-1 bg-blue-500 text-white hover:bg-blue-600 py-3"
                  >
                    <Share2 className="w-5 h-5 mr-2" />
                    {t.share}
                  </Button>
                  <Button
                    onClick={() => {
                      setShowDonationModal(true);
                    }}
                    className="flex-1 bg-gradient-to-r from-rose-600 to-pink-600 text-white hover:shadow-lg py-3"
                  >
                    <Heart className="w-5 h-5 mr-2 fill-white" />
                    {t.donateNow}
                  </Button>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Donation Modal */}
      <AnimatePresence>
        {showDonationModal && selectedCase && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/70 backdrop-blur-sm z-[60] flex items-center justify-center p-4 overflow-y-auto"
            onClick={() => setShowDonationModal(false)}
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="bg-white rounded-3xl max-w-md w-full my-8"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="p-6">
                <div className="flex items-center justify-between mb-6">
                  <h2 className="text-2xl font-bold text-gray-900">{t.donateNow}</h2>
                  <button
                    onClick={() => setShowDonationModal(false)}
                    className="p-2 hover:bg-gray-100 rounded-full transition-colors"
                  >
                    <X className="w-5 h-5" />
                  </button>
                </div>

                {/* Amount Selection */}
                <div className="mb-6">
                  <h3 className="font-semibold text-gray-900 mb-3">{t.selectAmount}</h3>
                  <div className="grid grid-cols-3 gap-2 mb-3">
                    {suggestedAmounts.USD.map(amount => (
                      <button
                        key={amount}
                        onClick={() => {
                          setSelectedAmount(amount);
                          setCustomAmount('');
                        }}
                        className={`py-3 rounded-xl font-semibold transition-all ${
                          selectedAmount === amount
                            ? 'bg-gradient-to-r from-rose-600 to-pink-600 text-white'
                            : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                        }`}
                      >
                        ${amount}
                      </button>
                    ))}
                  </div>
                  <Input
                    type="number"
                    placeholder={t.customAmount}
                    value={customAmount}
                    onChange={(e) => {
                      setCustomAmount(e.target.value);
                      setSelectedAmount(null);
                    }}
                    className="w-full px-4 py-3 rounded-xl border-2 border-gray-200 focus:border-rose-400"
                  />
                </div>

                {/* Payment Methods */}
                <div className="mb-6">
                  <h3 className="font-semibold text-gray-900 mb-3">{t.paymentMethod}</h3>
                  <div className="space-y-2">
                    {/* PayPal */}
                    <button
                      onClick={() => setSelectedPayment('paypal')}
                      className={`w-full p-4 rounded-xl border-2 transition-all flex items-center gap-3 ${
                        selectedPayment === 'paypal'
                          ? 'border-rose-500 bg-rose-50'
                          : 'border-gray-200 hover:border-rose-300'
                      }`}
                    >
                      <Wallet className="w-5 h-5 text-blue-600" />
                      <span className="font-semibold">{t.paypal}</span>
                      {selectedPayment === 'paypal' && <CheckCircle className="w-5 h-5 text-rose-600 ml-auto" />}
                    </button>

                    {/* Card */}
                    <button
                      onClick={() => setSelectedPayment('card')}
                      className={`w-full p-4 rounded-xl border-2 transition-all flex items-center gap-3 ${
                        selectedPayment === 'card'
                          ? 'border-rose-500 bg-rose-50'
                          : 'border-gray-200 hover:border-rose-300'
                      }`}
                    >
                      <CreditCard className="w-5 h-5 text-purple-600" />
                      <span className="font-semibold">{t.card}</span>
                      {selectedPayment === 'card' && <CheckCircle className="w-5 h-5 text-rose-600 ml-auto" />}
                    </button>

                    {/* Hesab Pay */}
                    <button
                      onClick={() => setSelectedPayment('hesabPay')}
                      className={`w-full p-4 rounded-xl border-2 transition-all flex items-center gap-3 ${
                        selectedPayment === 'hesabPay'
                          ? 'border-rose-500 bg-rose-50'
                          : 'border-gray-200 hover:border-rose-300'
                      }`}
                    >
                      <Phone className="w-5 h-5 text-green-600" />
                      <div className="flex-1 text-left">
                        <div className="font-semibold">{t.hesabPay}</div>
                        <div className="text-xs text-gray-600">{t.hesabPayNumber}</div>
                      </div>
                      {selectedPayment === 'hesabPay' && <CheckCircle className="w-5 h-5 text-rose-600 ml-auto" />}
                    </button>
                  </div>
                </div>

                {/* Owner Info */}
                <div className="bg-blue-50 rounded-2xl p-4 mb-6">
                  <div className="flex items-center gap-3 mb-2">
                    <Shield className="w-5 h-5 text-blue-600" />
                    <span className="font-bold text-blue-900">{t.ownerInfo}</span>
                  </div>
                  <div className="text-sm text-blue-800">
                    <div className="flex items-center justify-between">
                      <span>{t.hesabPay}: {t.hesabPayNumber}</span>
                      <button
                        onClick={() => copyToClipboard(t.hesabPayNumber)}
                        className="p-1 hover:bg-blue-100 rounded"
                      >
                        <Copy className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                </div>

                {/* Confirm Button */}
                <div className="flex gap-3">
                  <Button
                    onClick={() => setShowDonationModal(false)}
                    className="flex-1 bg-gray-100 text-gray-700 hover:bg-gray-200 py-3"
                  >
                    {t.cancel}
                  </Button>
                  <Button
                    onClick={handleConfirmDonation}
                    className="flex-1 bg-gradient-to-r from-rose-600 to-pink-600 text-white hover:shadow-lg py-3"
                  >
                    <Heart className="w-5 h-5 mr-2 fill-white" />
                    {t.confirmDonation}
                  </Button>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Success Modal */}
      <AnimatePresence>
        {showSuccessModal && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/70 backdrop-blur-sm z-[70] flex items-center justify-center p-4"
          >
            <motion.div
              initial={{ scale: 0.5, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.5, opacity: 0 }}
              className="bg-white rounded-3xl p-8 max-w-md w-full text-center"
            >
              <motion.div
                animate={{ scale: [1, 1.2, 1] }}
                transition={{ duration: 0.5, repeat: 2 }}
                className="w-24 h-24 mx-auto mb-6 bg-gradient-to-br from-rose-500 to-pink-500 rounded-full flex items-center justify-center"
              >
                <Heart className="w-12 h-12 text-white fill-white" />
              </motion.div>
              <h2 className="text-3xl font-bold text-gray-900 mb-2">{t.thankYou}</h2>
              <p className="text-gray-600 mb-6">{t.donationSuccess}</p>
              <div className="text-sm text-gray-500">{t.helpMore}</div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
