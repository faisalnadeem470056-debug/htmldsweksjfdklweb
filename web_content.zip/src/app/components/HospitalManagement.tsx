import { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { Plus, Edit2, Trash2, Save, X, Building2, MapPin, Phone, Mail } from 'lucide-react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Card } from './ui/card';
import { Hospital, afghanProvinces } from '../data/hospitals';

interface HospitalManagementProps {
  language: 'ps' | 'fa' | 'en';
  onBack: () => void;
}

export function HospitalManagement({ language, onBack }: HospitalManagementProps) {
  const [hospitals, setHospitals] = useState<Hospital[]>([]);
  const [showAddForm, setShowAddForm] = useState(false);
  const [editingHospital, setEditingHospital] = useState<Hospital | null>(null);
  const [formData, setFormData] = useState<Partial<Hospital>>({
    name: { ps: '', fa: '', en: '' },
    type: 'hospital',
    province: '',
    district: '',
    address: { ps: '', fa: '', en: '' },
    location: { lat: 0, lng: 0 },
    phone: [''],
    email: '',
    services: [],
    availability: '24/7',
    isGovernment: true,
    beds: 0,
    doctors: 0,
    established: new Date().getFullYear()
  });

  const texts = {
    ps: {
      title: 'د روغتونونو مدیریت',
      subtitle: 'نوي روغتونونه او کلینیکونه اضافه کړئ',
      addNew: 'نوی اضافه کړه',
      edit: 'تغیر ورکړه',
      delete: 'پاک کړه',
      save: 'خوندي کول',
      cancel: 'لغوه',
      name: 'نوم',
      type: 'ډول',
      province: 'ولایت',
      district: 'ولسوالۍ',
      address: 'ادرس',
      location: 'موقعیت',
      latitude: 'عرض البلد',
      longitude: 'طول البلد',
      phone: 'تلیفون',
      email: 'ایمیل',
      services: 'خدمتونه',
      availability: 'وخت',
      government: 'دولتي',
      beds: 'بسترې',
      doctors: 'ډاکټران',
      established: 'تاسیس',
      hospital: 'روغتون',
      clinic: 'کلینیک',
      healthCenter: 'روغتیایی مرکز',
      available247: '24/7',
      dayOnly: 'ورځې',
      limited: 'محدود',
      addPhone: 'تلیفون اضافه',
      removePhone: 'تلیفون پاک',
      pashto: 'پښتو',
      dari: 'دري',
      english: 'انګلیسي',
      successAdded: 'بریالي اضافه شو!',
      successUpdated: 'بریالي تغیر شو!',
      successDeleted: 'بریالي پاک شو!',
      confirmDelete: 'ایا تاسو ډاډه یاست؟',
      totalHospitals: 'ټول روغتونونه',
      image: 'عکس URL'
    },
    fa: {
      title: 'مدیریت شفاخانه‌ها',
      subtitle: 'افزودن شفاخانه‌ها و کلینیک‌های جدید',
      addNew: 'افزودن جدید',
      edit: 'ویرایش',
      delete: 'حذف',
      save: 'ذخیره',
      cancel: 'لغو',
      name: 'نام',
      type: 'نوع',
      province: 'ولایت',
      district: 'ولسوالی',
      address: 'آدرس',
      location: 'موقعیت',
      latitude: 'عرض جغرافیایی',
      longitude: 'طول جغرافیایی',
      phone: 'تلفن',
      email: 'ایمیل',
      services: 'خدمات',
      availability: 'دسترسی',
      government: 'دولتی',
      beds: 'تخت',
      doctors: 'داکتران',
      established: 'تاسیس',
      hospital: 'شفاخانه',
      clinic: 'کلینیک',
      healthCenter: 'مرکز صحی',
      available247: '24/7',
      dayOnly: 'روزانه',
      limited: 'محدود',
      addPhone: 'افزودن تلفن',
      removePhone: 'حذف تلفن',
      pashto: 'پشتو',
      dari: 'دری',
      english: 'انگلیسی',
      successAdded: 'با موفقیت اضافه شد!',
      successUpdated: 'با موفقیت ویرایش شد!',
      successDeleted: 'با موفقیت حذف شد!',
      confirmDelete: 'آیا مطمئن هستید؟',
      totalHospitals: 'مجموع شفاخانه‌ها',
      image: 'URL عکس'
    },
    en: {
      title: 'Hospital Management',
      subtitle: 'Add new hospitals and clinics',
      addNew: 'Add New',
      edit: 'Edit',
      delete: 'Delete',
      save: 'Save',
      cancel: 'Cancel',
      name: 'Name',
      type: 'Type',
      province: 'Province',
      district: 'District',
      address: 'Address',
      location: 'Location',
      latitude: 'Latitude',
      longitude: 'Longitude',
      phone: 'Phone',
      email: 'Email',
      services: 'Services',
      availability: 'Availability',
      government: 'Government',
      beds: 'Beds',
      doctors: 'Doctors',
      established: 'Established',
      hospital: 'Hospital',
      clinic: 'Clinic',
      healthCenter: 'Health Center',
      available247: '24/7',
      dayOnly: 'Day Only',
      limited: 'Limited',
      addPhone: 'Add Phone',
      removePhone: 'Remove Phone',
      pashto: 'Pashto',
      dari: 'Dari',
      english: 'English',
      successAdded: 'Successfully added!',
      successUpdated: 'Successfully updated!',
      successDeleted: 'Successfully deleted!',
      confirmDelete: 'Are you sure?',
      totalHospitals: 'Total Hospitals',
      image: 'Image URL'
    }
  };

  const t = texts[language];

  // Load hospitals from localStorage
  useEffect(() => {
    const stored = localStorage.getItem('healmate_custom_hospitals');
    if (stored) {
      setHospitals(JSON.parse(stored));
    }
  }, []);

  // Save hospital
  const handleSave = () => {
    if (!formData.name?.ps || !formData.province || !formData.district) {
      alert(language === 'ps' ? 'مهرباني وکړئ ټول اړین برخې ډک کړئ!' :
            language === 'fa' ? 'لطفاً تمام فیلدهای الزامی را پر کنید!' :
            'Please fill all required fields!');
      return;
    }

    const newHospital: Hospital = {
      id: editingHospital?.id || 'CUSTOM_' + Date.now(),
      name: formData.name as any,
      type: formData.type as any,
      province: formData.province as string,
      district: formData.district as string,
      address: formData.address as any,
      location: formData.location as any,
      phone: formData.phone as string[],
      email: formData.email,
      services: formData.services as string[],
      availability: formData.availability as any,
      isGovernment: formData.isGovernment as boolean,
      beds: formData.beds,
      doctors: formData.doctors,
      established: formData.established,
      image: formData.image
    };

    let updatedHospitals;
    if (editingHospital) {
      updatedHospitals = hospitals.map(h => h.id === editingHospital.id ? newHospital : h);
      alert(t.successUpdated);
    } else {
      updatedHospitals = [...hospitals, newHospital];
      alert(t.successAdded);
    }

    localStorage.setItem('healmate_custom_hospitals', JSON.stringify(updatedHospitals));
    setHospitals(updatedHospitals);
    setShowAddForm(false);
    setEditingHospital(null);
    resetForm();
  };

  // Delete hospital
  const handleDelete = (id: string) => {
    if (confirm(t.confirmDelete)) {
      const updatedHospitals = hospitals.filter(h => h.id !== id);
      localStorage.setItem('healmate_custom_hospitals', JSON.stringify(updatedHospitals));
      setHospitals(updatedHospitals);
      alert(t.successDeleted);
    }
  };

  // Edit hospital
  const handleEdit = (hospital: Hospital) => {
    setEditingHospital(hospital);
    setFormData(hospital);
    setShowAddForm(true);
  };

  // Reset form
  const resetForm = () => {
    setFormData({
      name: { ps: '', fa: '', en: '' },
      type: 'hospital',
      province: '',
      district: '',
      address: { ps: '', fa: '', en: '' },
      location: { lat: 0, lng: 0 },
      phone: [''],
      email: '',
      services: [],
      availability: '24/7',
      isGovernment: true,
      beds: 0,
      doctors: 0,
      established: new Date().getFullYear()
    });
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-purple-50 to-pink-50 pb-24">
      {/* Header */}
      <div className="sticky top-0 z-40 bg-gradient-to-r from-blue-600 via-purple-600 to-pink-600 text-white shadow-xl">
        <div className="container mx-auto px-4 py-6">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl flex items-center gap-2">
                <Building2 className="w-7 h-7" />
                {t.title}
              </h1>
              <p className="text-sm opacity-90">{t.subtitle}</p>
            </div>
            <Button
              onClick={() => {
                setShowAddForm(true);
                setEditingHospital(null);
                resetForm();
              }}
              className="bg-white text-blue-600 hover:bg-blue-50 rounded-xl"
            >
              <Plus className="w-5 h-5 mr-2" />
              {t.addNew}
            </Button>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="max-w-6xl mx-auto px-4 py-6">
        {/* Add/Edit Form */}
        {showAddForm && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            className="mb-6"
          >
            <Card className="bg-white rounded-3xl shadow-2xl border-0 p-6">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-xl">
                  {editingHospital ? t.edit : t.addNew}
                </h2>
                <button
                  onClick={() => {
                    setShowAddForm(false);
                    setEditingHospital(null);
                    resetForm();
                  }}
                  className="w-8 h-8 bg-gray-100 rounded-full flex items-center justify-center hover:bg-gray-200"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {/* Name Fields */}
                <div className="md:col-span-2">
                  <Label className="text-gray-700 mb-2">{t.name}</Label>
                  <div className="grid grid-cols-3 gap-3">
                    <div>
                      <Input
                        placeholder={t.pashto}
                        value={formData.name?.ps || ''}
                        onChange={(e) => setFormData({ ...formData, name: { ...formData.name!, ps: e.target.value } })}
                        className="rounded-xl border-2 border-gray-200"
                      />
                    </div>
                    <div>
                      <Input
                        placeholder={t.dari}
                        value={formData.name?.fa || ''}
                        onChange={(e) => setFormData({ ...formData, name: { ...formData.name!, fa: e.target.value } })}
                        className="rounded-xl border-2 border-gray-200"
                      />
                    </div>
                    <div>
                      <Input
                        placeholder={t.english}
                        value={formData.name?.en || ''}
                        onChange={(e) => setFormData({ ...formData, name: { ...formData.name!, en: e.target.value } })}
                        className="rounded-xl border-2 border-gray-200"
                      />
                    </div>
                  </div>
                </div>

                {/* Type */}
                <div>
                  <Label className="text-gray-700 mb-2">{t.type}</Label>
                  <select
                    value={formData.type}
                    onChange={(e) => setFormData({ ...formData, type: e.target.value as any })}
                    className="w-full px-4 py-3 border-2 border-gray-200 rounded-xl focus:border-blue-500 focus:outline-none"
                  >
                    <option value="hospital">{t.hospital}</option>
                    <option value="clinic">{t.clinic}</option>
                    <option value="health_center">{t.healthCenter}</option>
                  </select>
                </div>

                {/* Province */}
                <div>
                  <Label className="text-gray-700 mb-2">{t.province}</Label>
                  <select
                    value={formData.province}
                    onChange={(e) => setFormData({ ...formData, province: e.target.value })}
                    className="w-full px-4 py-3 border-2 border-gray-200 rounded-xl focus:border-blue-500 focus:outline-none"
                  >
                    <option value="">{t.province}</option>
                    {afghanProvinces.map(province => (
                      <option key={province} value={province}>{province}</option>
                    ))}
                  </select>
                </div>

                {/* District */}
                <div>
                  <Label className="text-gray-700 mb-2">{t.district}</Label>
                  <Input
                    value={formData.district}
                    onChange={(e) => setFormData({ ...formData, district: e.target.value })}
                    className="rounded-xl border-2 border-gray-200"
                  />
                </div>

                {/* Availability */}
                <div>
                  <Label className="text-gray-700 mb-2">{t.availability}</Label>
                  <select
                    value={formData.availability}
                    onChange={(e) => setFormData({ ...formData, availability: e.target.value as any })}
                    className="w-full px-4 py-3 border-2 border-gray-200 rounded-xl focus:border-blue-500 focus:outline-none"
                  >
                    <option value="24/7">{t.available247}</option>
                    <option value="day">{t.dayOnly}</option>
                    <option value="limited">{t.limited}</option>
                  </select>
                </div>

                {/* Address Fields */}
                <div className="md:col-span-2">
                  <Label className="text-gray-700 mb-2">{t.address}</Label>
                  <div className="grid grid-cols-3 gap-3">
                    <Input
                      placeholder={t.pashto}
                      value={formData.address?.ps || ''}
                      onChange={(e) => setFormData({ ...formData, address: { ...formData.address!, ps: e.target.value } })}
                      className="rounded-xl border-2 border-gray-200"
                    />
                    <Input
                      placeholder={t.dari}
                      value={formData.address?.fa || ''}
                      onChange={(e) => setFormData({ ...formData, address: { ...formData.address!, fa: e.target.value } })}
                      className="rounded-xl border-2 border-gray-200"
                    />
                    <Input
                      placeholder={t.english}
                      value={formData.address?.en || ''}
                      onChange={(e) => setFormData({ ...formData, address: { ...formData.address!, en: e.target.value } })}
                      className="rounded-xl border-2 border-gray-200"
                    />
                  </div>
                </div>

                {/* Location */}
                <div>
                  <Label className="text-gray-700 mb-2">{t.latitude}</Label>
                  <Input
                    type="number"
                    step="0.000001"
                    value={formData.location?.lat || 0}
                    onChange={(e) => setFormData({ ...formData, location: { ...formData.location!, lat: parseFloat(e.target.value) } })}
                    className="rounded-xl border-2 border-gray-200"
                  />
                </div>
                <div>
                  <Label className="text-gray-700 mb-2">{t.longitude}</Label>
                  <Input
                    type="number"
                    step="0.000001"
                    value={formData.location?.lng || 0}
                    onChange={(e) => setFormData({ ...formData, location: { ...formData.location!, lng: parseFloat(e.target.value) } })}
                    className="rounded-xl border-2 border-gray-200"
                  />
                </div>

                {/* Beds */}
                <div>
                  <Label className="text-gray-700 mb-2">{t.beds}</Label>
                  <Input
                    type="number"
                    value={formData.beds || 0}
                    onChange={(e) => setFormData({ ...formData, beds: parseInt(e.target.value) })}
                    className="rounded-xl border-2 border-gray-200"
                  />
                </div>

                {/* Doctors */}
                <div>
                  <Label className="text-gray-700 mb-2">{t.doctors}</Label>
                  <Input
                    type="number"
                    value={formData.doctors || 0}
                    onChange={(e) => setFormData({ ...formData, doctors: parseInt(e.target.value) })}
                    className="rounded-xl border-2 border-gray-200"
                  />
                </div>

                {/* Established */}
                <div>
                  <Label className="text-gray-700 mb-2">{t.established}</Label>
                  <Input
                    type="number"
                    value={formData.established || new Date().getFullYear()}
                    onChange={(e) => setFormData({ ...formData, established: parseInt(e.target.value) })}
                    className="rounded-xl border-2 border-gray-200"
                  />
                </div>

                {/* Email */}
                <div>
                  <Label className="text-gray-700 mb-2">{t.email}</Label>
                  <Input
                    type="email"
                    value={formData.email || ''}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    className="rounded-xl border-2 border-gray-200"
                  />
                </div>

                {/* Image URL */}
                <div className="md:col-span-2">
                  <Label className="text-gray-700 mb-2">{t.image}</Label>
                  <Input
                    value={formData.image || ''}
                    onChange={(e) => setFormData({ ...formData, image: e.target.value })}
                    placeholder="https://example.com/image.jpg"
                    className="rounded-xl border-2 border-gray-200"
                  />
                </div>

                {/* Government Toggle */}
                <div className="md:col-span-2 flex items-center gap-3">
                  <input
                    type="checkbox"
                    checked={formData.isGovernment}
                    onChange={(e) => setFormData({ ...formData, isGovernment: e.target.checked })}
                    className="w-5 h-5 rounded border-2 border-gray-300"
                  />
                  <Label className="text-gray-700">{t.government}</Label>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex gap-3 mt-6">
                <Button
                  onClick={() => {
                    setShowAddForm(false);
                    setEditingHospital(null);
                    resetForm();
                  }}
                  variant="outline"
                  className="flex-1 rounded-xl py-6 border-2"
                >
                  {t.cancel}
                </Button>
                <Button
                  onClick={handleSave}
                  className="flex-1 bg-gradient-to-r from-blue-600 to-indigo-600 text-white rounded-xl py-6"
                >
                  <Save className="w-5 h-5 mr-2" />
                  {t.save}
                </Button>
              </div>
            </Card>
          </motion.div>
        )}

        {/* Stats */}
        <Card className="bg-gradient-to-r from-blue-600 to-indigo-600 text-white rounded-2xl shadow-lg border-0 p-6 mb-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm opacity-90">{t.totalHospitals}</p>
              <p className="text-4xl">{hospitals.length}</p>
            </div>
            <Building2 className="w-16 h-16 opacity-50" />
          </div>
        </Card>

        {/* Hospitals List */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {hospitals.map((hospital) => (
            <motion.div
              key={hospital.id}
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
            >
              <Card className="bg-white rounded-2xl shadow-lg border-0 p-4 hover:shadow-xl transition-shadow">
                <div className="flex items-start justify-between mb-3">
                  <div className="flex-1">
                    <h3 className="text-lg mb-1">{hospital.name[language]}</h3>
                    <div className="flex items-center gap-2 text-sm text-gray-500">
                      <MapPin className="w-4 h-4" />
                      <span>{hospital.province}, {hospital.district}</span>
                    </div>
                  </div>
                </div>

                <div className="space-y-2 mb-4">
                  {hospital.phone.map((phone, idx) => (
                    <div key={idx} className="flex items-center gap-2 text-sm text-gray-600">
                      <Phone className="w-4 h-4 text-green-600" />
                      <span>{phone}</span>
                    </div>
                  ))}
                  {hospital.email && (
                    <div className="flex items-center gap-2 text-sm text-gray-600">
                      <Mail className="w-4 h-4 text-blue-600" />
                      <span>{hospital.email}</span>
                    </div>
                  )}
                </div>

                <div className="flex gap-2">
                  <Button
                    onClick={() => handleEdit(hospital)}
                    variant="outline"
                    className="flex-1 rounded-xl border-2"
                  >
                    <Edit2 className="w-4 h-4 mr-2" />
                    {t.edit}
                  </Button>
                  <Button
                    onClick={() => handleDelete(hospital.id)}
                    variant="outline"
                    className="rounded-xl border-2 border-red-500 text-red-600 hover:bg-red-50"
                  >
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
              </Card>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  );
}
