import { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Mic, MicOff, Volume2, VolumeX, Sparkles, 
  Brain, Zap, Circle, CheckCircle2, MessageCircle
} from 'lucide-react';
import { Button } from './ui/button';
import { Card } from './ui/card';

interface VoiceHealthAssistantProps {
  language: 'ps' | 'fa' | 'en';
}

export function VoiceHealthAssistant({ language }: VoiceHealthAssistantProps) {
  const [isListening, setIsListening] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [transcript, setTranscript] = useState('');
  const [response, setResponse] = useState('');
  const [showPanel, setShowPanel] = useState(false);
  const [audioLevel, setAudioLevel] = useState(0);
  const recognitionRef = useRef<any>(null);

  const texts = {
    ps: {
      title: '🎤 غږیز روغتیا مرستیال',
      subtitle: 'د خپل غږ په واسطه پوښتنې وکړئ',
      tapToSpeak: 'د خبرو لپاره ټپ وکړئ',
      listening: 'اوریدل کیږي...',
      processing: 'پروسس کیږي...',
      speaking: 'ځواب ویل کیږي...',
      youSaid: 'تاسو وویل:',
      assistant: 'مرستیال:',
      examples: 'د پوښتنو بیلګې:',
      example1: 'د سر درد لپاره څه وکړم؟',
      example2: 'د BMI محاسبه څنګه کړم؟',
      example3: 'د اوبو څومره مقدار په کار دی؟',
      stopListening: 'اوریدل بند کړئ',
      clearChat: 'پاک کول'
    },
    fa: {
      title: '🎤 دستیار صوتی سلامتی',
      subtitle: 'با صدای خود سوال کنید',
      tapToSpeak: 'برای صحبت ضربه بزنید',
      listening: 'در حال گوش دادن...',
      processing: 'در حال پردازش...',
      speaking: 'در حال پاسخ...',
      youSaid: 'شما گفتید:',
      assistant: 'دستیار:',
      examples: 'نمونه سوالات:',
      example1: 'برای سردرد چه کنم؟',
      example2: 'چگونه BMI محاسبه کنم؟',
      example3: 'چقدر آب نیاز دارم؟',
      stopListening: 'توقف گوش دادن',
      clearChat: 'پاک کردن'
    },
    en: {
      title: '🎤 Voice Health Assistant',
      subtitle: 'Ask questions with your voice',
      tapToSpeak: 'Tap to speak',
      listening: 'Listening...',
      processing: 'Processing...',
      speaking: 'Speaking...',
      youSaid: 'You said:',
      assistant: 'Assistant:',
      examples: 'Example questions:',
      example1: 'What should I do for headache?',
      example2: 'How to calculate BMI?',
      example3: 'How much water do I need?',
      stopListening: 'Stop Listening',
      clearChat: 'Clear Chat'
    }
  };

  const t = texts[language];

  // د Sample responses
  const healthResponses: Record<string, { ps: string; fa: string; en: string }> = {
    headache: {
      ps: 'د سر درد لپاره: 1) ډیره اوبه وڅښئ 2) په تیاره خونه کې استراحت وکړئ 3) سړه کمپرس وکاروئ. که درد دوام ومومي، له ډاکټر سره مشوره وکړئ.',
      fa: 'برای سردرد: 1) آب زیاد بنوشید 2) در اتاق تاریک استراحت کنید 3) کمپرس سرد استفاده کنید. اگر درد ادامه یافت، با پزشک مشورت کنید.',
      en: 'For headache: 1) Drink plenty of water 2) Rest in a dark room 3) Use cold compress. If pain persists, consult a doctor.'
    },
    bmi: {
      ps: 'د BMI محاسبه: وزن (کیلوګرام) ÷ (قد × قد متره کې). بیلګه: که وزن 70 کیلو او قد 1.75 متره وي، نو BMI = 70 ÷ (1.75 × 1.75) = 22.9',
      fa: 'محاسبه BMI: وزن (کیلوگرم) ÷ (قد × قد به متر). مثال: اگر وزن 70 کیلو و قد 1.75 متر باشد، BMI = 70 ÷ (1.75 × 1.75) = 22.9',
      en: 'BMI calculation: Weight (kg) ÷ (Height × Height in meters). Example: If weight is 70kg and height is 1.75m, then BMI = 70 ÷ (1.75 × 1.75) = 22.9'
    },
    water: {
      ps: 'هره ورځ لږ تر لږه 8 ګیلاسه (2 لیټره) اوبه وڅښئ. که تاسو ورزش کوئ یا هوا ګرمه وي، نور اوبه په کار دي.',
      fa: 'هر روز حداقل 8 لیوان (2 لیتر) آب بنوشید. اگر ورزش می‌کنید یا هوا گرم است، آب بیشتری نیاز دارید.',
      en: 'Drink at least 8 glasses (2 liters) of water daily. If you exercise or it\'s hot, you need more water.'
    },
    default: {
      ps: 'ستاسو پوښتنه زه ونه پوهیدم. مهرباني وکړئ بیا هڅه وکړئ یا یو ساده پوښتنه وکړئ.',
      fa: 'سوال شما را متوجه نشدم. لطفا دوباره تلاش کنید یا سوال ساده‌تری بپرسید.',
      en: 'I didn\'t understand your question. Please try again or ask a simpler question.'
    }
  };

  useEffect(() => {
    // د Speech Recognition setup
    if ('webkitSpeechRecognition' in window || 'SpeechRecognition' in window) {
      const SpeechRecognition = (window as any).webkitSpeechRecognition || (window as any).SpeechRecognition;
      recognitionRef.current = new SpeechRecognition();
      recognitionRef.current.continuous = false;
      recognitionRef.current.interimResults = false;
      
      // د ژبې په اساس language set کړئ
      if (language === 'ps') {
        recognitionRef.current.lang = 'ps-AF'; // Pashto
      } else if (language === 'fa') {
        recognitionRef.current.lang = 'fa-IR'; // Dari/Persian
      } else {
        recognitionRef.current.lang = 'en-US'; // English
      }

      recognitionRef.current.onresult = (event: any) => {
        const text = event.results[0][0].transcript;
        setTranscript(text);
        setIsListening(false);
        processVoiceCommand(text);
      };

      recognitionRef.current.onerror = (event: any) => {
        console.error('Speech recognition error:', event.error);
        setIsListening(false);
        
        // د error message د ژبې په اساس
        if (event.error === 'not-allowed') {
          const errorMsg = language === 'ps' 
            ? 'مایکروفون ته اجازه نشته. مهرباني وکړئ د browser تنظیماتو کې اجازه ورکړئ.'
            : language === 'fa'
            ? 'دسترسی به میکروفون مجاز نیست. لطفا در تنظیمات مرورگر اجازه دهید.'
            : 'Microphone access is not allowed. Please enable it in browser settings.';
          setResponse(errorMsg);
        } else if (event.error === 'no-speech') {
          const errorMsg = language === 'ps' 
            ? 'هیڅ غږ ونه موندل شو. مهرباني وکړئ بیا هڅه وکړئ.'
            : language === 'fa'
            ? 'هیچ صدایی شناسایی نشد. لطفا دوباره تلاش کنید.'
            : 'No speech detected. Please try again.';
          setResponse(errorMsg);
        }
      };

      recognitionRef.current.onend = () => {
        setIsListening(false);
      };
    }

    // د Audio level animation
    const interval = setInterval(() => {
      if (isListening) {
        setAudioLevel(Math.random() * 100);
      } else {
        setAudioLevel(0);
      }
    }, 100);

    return () => clearInterval(interval);
  }, [isListening, language]);

  const startListening = async () => {
    if (recognitionRef.current) {
      try {
        // د microphone permission وګورئ
        if (navigator.permissions) {
          const permission = await navigator.permissions.query({ name: 'microphone' as PermissionName });
          if (permission.state === 'denied') {
            const errorMsg = language === 'ps' 
              ? 'مایکروفون ته اجازه نشته. مهرباني وکړئ د browser تنظیماتو کې اجازه ورکړئ.'
              : language === 'fa'
              ? 'دسترسی به میکروفون مجاز نیست. لطفا در تنظیمات مرورگر اجازه دهید.'
              : 'Microphone access denied. Please enable it in browser settings.';
            setResponse(errorMsg);
            return;
          }
        }
        
        setTranscript('');
        setResponse('');
        setIsListening(true);
        recognitionRef.current.start();
      } catch (error) {
        console.error('Permission check error:', error);
        setTranscript('');
        setResponse('');
        setIsListening(true);
        recognitionRef.current.start();
      }
    }
  };

  const stopListening = () => {
    if (recognitionRef.current && isListening) {
      recognitionRef.current.stop();
      setIsListening(false);
    }
  };

  const processVoiceCommand = (text: string) => {
    const lowerText = text.toLowerCase();
    
    let responseKey = 'default';
    
    if (lowerText.includes('headache') || lowerText.includes('سر') || lowerText.includes('سردرد')) {
      responseKey = 'headache';
    } else if (lowerText.includes('bmi') || lowerText.includes('وزن')) {
      responseKey = 'bmi';
    } else if (lowerText.includes('water') || lowerText.includes('اوبه') || lowerText.includes('آب')) {
      responseKey = 'water';
    }

    const responseText = healthResponses[responseKey][language];
    setResponse(responseText);
    
    // د Text-to-Speech
    speakResponse(responseText);
  };

  const speakResponse = (text: string) => {
    if ('speechSynthesis' in window) {
      setIsSpeaking(true);
      const utterance = new SpeechSynthesisUtterance(text);
      
      // د ژبې په اساس voice set کړئ
      const voices = speechSynthesis.getVoices();
      const langCode = language === 'ps' ? 'ps' : language === 'fa' ? 'fa' : 'en';
      const voice = voices.find(v => v.lang.startsWith(langCode));
      if (voice) utterance.voice = voice;
      
      utterance.rate = 0.9;
      utterance.pitch = 1;
      
      utterance.onend = () => {
        setIsSpeaking(false);
      };

      speechSynthesis.speak(utterance);
    }
  };

  const stopSpeaking = () => {
    if ('speechSynthesis' in window) {
      speechSynthesis.cancel();
      setIsSpeaking(false);
    }
  };

  return (
    <div className="w-full">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="mb-6"
      >
        <div className="text-center mb-6">
          <h2 className="text-3xl mb-2 bg-gradient-to-r from-blue-600 via-purple-600 to-pink-600 bg-clip-text text-transparent">
            {t.title}
          </h2>
          <p className="text-gray-600">{t.subtitle}</p>
        </div>

        {/* Voice Control Panel */}
        <Card className="relative overflow-hidden bg-gradient-to-br from-purple-50 to-pink-50 border-2 shadow-xl mb-6">
          <div className="p-8">
            {/* Microphone Button */}
            <div className="flex justify-center mb-6">
              <motion.button
                onClick={isListening ? stopListening : startListening}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                animate={isListening ? {
                  boxShadow: [
                    '0 0 0 0 rgba(147, 51, 234, 0.7)',
                    '0 0 0 40px rgba(147, 51, 234, 0)',
                  ]
                } : {}}
                transition={isListening ? { duration: 1.5, repeat: Infinity } : {}}
                className={`relative w-32 h-32 rounded-full flex items-center justify-center shadow-2xl ${
                  isListening 
                    ? 'bg-gradient-to-br from-red-500 to-pink-600' 
                    : 'bg-gradient-to-br from-purple-500 to-pink-600'
                }`}
              >
                {isListening ? (
                  <MicOff className="w-16 h-16 text-white" />
                ) : (
                  <Mic className="w-16 h-16 text-white" />
                )}

                {/* Audio Level Indicator */}
                {isListening && (
                  <motion.div
                    animate={{ scale: [1, 1 + audioLevel / 100, 1] }}
                    transition={{ duration: 0.1 }}
                    className="absolute inset-0 rounded-full bg-purple-400/30"
                  />
                )}
              </motion.button>
            </div>

            {/* Status Text */}
            <div className="text-center mb-6">
              <AnimatePresence mode="wait">
                {isListening ? (
                  <motion.div
                    key="listening"
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -10 }}
                    className="text-lg text-purple-600"
                  >
                    <div className="flex items-center justify-center gap-2 mb-2">
                      <motion.div
                        animate={{ scale: [1, 1.2, 1] }}
                        transition={{ duration: 1, repeat: Infinity }}
                      >
                        <Circle className="w-3 h-3 fill-red-500 text-red-500" />
                      </motion.div>
                      {t.listening}
                    </div>
                  </motion.div>
                ) : isSpeaking ? (
                  <motion.div
                    key="speaking"
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -10 }}
                    className="text-lg text-blue-600"
                  >
                    <div className="flex items-center justify-center gap-2 mb-2">
                      <Volume2 className="w-5 h-5" />
                      {t.speaking}
                    </div>
                  </motion.div>
                ) : transcript ? (
                  <motion.div
                    key="processing"
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -10 }}
                    className="text-lg text-green-600"
                  >
                    <div className="flex items-center justify-center gap-2 mb-2">
                      <CheckCircle2 className="w-5 h-5" />
                      {t.processing}
                    </div>
                  </motion.div>
                ) : (
                  <motion.div
                    key="tap"
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -10 }}
                    className="text-lg text-gray-600"
                  >
                    {t.tapToSpeak}
                  </motion.div>
                )}
              </AnimatePresence>
            </div>

            {/* Control Buttons */}
            <div className="flex justify-center gap-3">
              {isSpeaking && (
                <Button
                  onClick={stopSpeaking}
                  variant="outline"
                  size="sm"
                  className="border-red-200 text-red-600 hover:bg-red-50"
                >
                  <VolumeX className="w-4 h-4 mr-2" />
                  Stop
                </Button>
              )}
              {(transcript || response) && (
                <Button
                  onClick={() => {
                    setTranscript('');
                    setResponse('');
                  }}
                  variant="outline"
                  size="sm"
                  className="border-gray-200"
                >
                  {t.clearChat}
                </Button>
              )}
            </div>
          </div>

          {/* Transcript & Response */}
          <AnimatePresence>
            {(transcript || response) && (
              <motion.div
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: 'auto' }}
                exit={{ opacity: 0, height: 0 }}
                className="border-t-2 border-white/50 p-6 space-y-4"
              >
                {transcript && (
                  <div className="bg-white/70 backdrop-blur-md rounded-2xl p-4">
                    <div className="flex items-start gap-3">
                      <div className="w-10 h-10 rounded-full bg-gradient-to-br from-blue-500 to-cyan-500 flex items-center justify-center flex-shrink-0">
                        <MessageCircle className="w-5 h-5 text-white" />
                      </div>
                      <div>
                        <div className="text-sm text-gray-500 mb-1">{t.youSaid}</div>
                        <div className="text-gray-900">{transcript}</div>
                      </div>
                    </div>
                  </div>
                )}

                {response && (
                  <div className="bg-gradient-to-br from-purple-100 to-pink-100 rounded-2xl p-4">
                    <div className="flex items-start gap-3">
                      <div className="w-10 h-10 rounded-full bg-gradient-to-br from-purple-500 to-pink-600 flex items-center justify-center flex-shrink-0">
                        <Brain className="w-5 h-5 text-white" />
                      </div>
                      <div>
                        <div className="text-sm text-purple-600 mb-1">{t.assistant}</div>
                        <div className="text-gray-900">{response}</div>
                      </div>
                    </div>
                  </div>
                )}
              </motion.div>
            )}
          </AnimatePresence>
        </Card>

        {/* Example Questions */}
        <Card className="bg-white/80 backdrop-blur-lg shadow-lg">
          <div className="p-6">
            <h3 className="text-lg mb-4 flex items-center gap-2">
              <Sparkles className="w-5 h-5 text-purple-600" />
              {t.examples}
            </h3>
            <div className="space-y-2">
              {[t.example1, t.example2, t.example3].map((example, index) => (
                <motion.div
                  key={index}
                  whileHover={{ scale: 1.02, x: 5 }}
                  className="flex items-center gap-3 p-3 rounded-xl bg-gradient-to-r from-purple-50 to-pink-50 cursor-pointer border border-purple-100 hover:border-purple-300 transition-all"
                  onClick={() => {
                    setTranscript(example);
                    processVoiceCommand(example);
                  }}
                >
                  <Zap className="w-4 h-4 text-purple-600 flex-shrink-0" />
                  <span className="text-sm text-gray-700">{example}</span>
                </motion.div>
              ))}
            </div>
          </div>
        </Card>
      </motion.div>
    </div>
  );
}
