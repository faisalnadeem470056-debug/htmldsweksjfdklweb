import { useState, useEffect } from 'react';
import {
  Heart, DollarSign, Euro, Coins, ArrowLeft, Plus, Edit2, Trash2, Check, X,
  Target, Users, MapPin, Calendar, Share2, CheckCircle, AlertCircle,
  Wallet, Copy, ExternalLink, Shield, Crown, Eye, Clock, Ban, Filter,
  TrendingUp, Globe, Phone, MessageCircle, Upload, Image as ImageIcon,
  CreditCard, Building2, Info
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { AdBanner } from './AdBanner';
import { ImageWithFallback } from './figma/ImageWithFallback';

interface CharitySystemProps {
  language: 'ps' | 'fa' | 'en';
  onBack: () => void;
  currentUserEmail: string;
  currentUserName: string;
}

type Currency = 'AFN' | 'USD' | 'EUR';
type PostStatus = 'pending' | 'approved' | 'rejected';

interface PaymentInfo {
  hesabPay?: string;
  bankAccount?: string;
  bankName?: string;
  cardNumber?: string;
  paypal?: string;
  easypaisa?: string;
}

interface CharityPost {
  id: string;
  userId: string;
  userName: string;
  userEmail: string;
  title: { ps: string; fa: string; en: string };
  description: { ps: string; fa: string; en: string };
  targetAmount: number;
  raisedAmount: number;
  currency: Currency;
  image: string;
  location: { ps: string; fa: string; en: string };
  category: string;
  urgency: 'critical' | 'high' | 'medium';
  status: PostStatus;
  verified: boolean;
  donors: Array<{ name: string; amount: number; currency: Currency; date: string }>;
  createdAt: string;
  approvedAt?: string;
  rejectedReason?: string;
  contactPhone?: string;
  paymentInfo?: PaymentInfo;
}

const translations = {
  ps: {
    title: 'مرسته وکړئ',
    subtitle: 'د اړمنو خلکو سره مرسته وکړئ',
    myPosts: 'زما پوسټونه',
    allCases: 'ټولې قضیې',
    createPost: 'نوی پوسټ جوړ کړئ',
    donate: 'مرسته وکړئ',
    share: 'شریک کړئ',
    raised: 'راټول شوي',
    target: 'هدف',
    donors: 'مرسته کوونکي',
    viewDetails: 'تفصیل',
    pending: 'د تایید په انتظار',
    approved: 'تایید شوی',
    rejected: 'رد شوی',
    critical: 'خورا بیړني',
    high: 'بیړني',
    medium: 'منځني',
    postDetails: 'د پوسټ تفصیلات',
    donateNow: 'اوس مرسته وکړئ',
    selectAmount: 'رقم غوره کړئ',
    customAmount: 'ځانګړی رقم',
    paymentMethod: 'د تادیې طریقه',
    hesabPay: 'حساب پے',
    bankTransfer: 'بانکي لیږد',
    easypaisa: 'Easypaisa',
    cardPayment: 'کارډ',
    paypalPayment: 'PayPal',
    close: 'تړل',
    submit: 'وسپارئ',
    cancel: 'لغوه',
    title_label_ps: 'سرلیک (په پښتو)',
    title_label_fa: 'سرلیک (په دری)',
    title_label_en: 'سرلیک (په انګلیسي)',
    description_label_ps: 'تفصیل (په پښتو)',
    description_label_fa: 'تفصیل (په دری)',
    description_label_en: 'تفصیل (په انګلیسي)',
    targetAmount_label: 'هدف رقم',
    currency_label: 'اسعار',
    location_label_ps: 'موقعیت (په پښتو)',
    location_label_fa: 'موقعیت (په دری)',
    location_label_en: 'موقعیت (په انګلیسي)',
    category_label: 'کټګوري',
    urgency_label: 'بیړنیتوب',
    image_label: 'د انځور URL',
    contactPhone_label: 'د تماس شمیره',
    paymentInfo_label: 'د تادیې معلومات',
    hesabPay_label: 'حساب پے شمیره',
    bankAccount_label: 'د بانک حساب شمیره',
    bankName_label: 'د بانک نوم',
    cardNumber_label: 'د کارډ شمیره',
    paypal_label: 'PayPal ایمیل یا شمیره',
    easypaisa_label: 'Easypaisa شمیره',
    thankYou: 'مننه!',
    donationSuccess: 'ستاسو مرسته بریالۍ وه!',
    postSubmitted: 'ستاسو پوسټ د Admin تایید ته واستول شو',
    adminPanel: 'Admin Panel',
    pendingApproval: 'د تایید په انتظار',
    approve: 'تایید',
    reject: 'رد',
    rejectReason: 'د رد کولو دلیل',
    categories: {
      medical: 'طبي',
      education: 'تعلیم',
      emergency: 'بیړني',
      food: 'خواړه',
      shelter: 'استوګنه',
      other: 'نور'
    },
    filters: {
      all: 'ټول',
      critical: 'بیړني',
      recent: 'تازه',
      popular: 'مشهور'
    },
    donationHistory: 'د مرستې تاریخچه',
    totalDonated: 'ټول مرستې',
    verifiedBadge: 'تایید شوی',
    postedBy: 'د لاسه',
    postedOn: 'نیټه',
    noPosts: 'هیڅ پوسټ نشته',
    noPendingPosts: 'د تایید لپاره هیڅ پوسټ نشته',
    confirmDonation: 'تایید کړئ',
    enterAmount: 'رقم داخل کړئ',
    min50: 'لږترلږه 50',
    postCreated: 'پوسټ جوړ شو!',
    editPost: 'پوسټ تغیر کړئ',
    deletePost: 'پوسټ حذف کړئ',
    confirmDelete: 'ایا تاسو ډاډه یاست؟',
    postDeleted: 'پوسټ حذف شو',
    fillAllFields: 'ټول اړین ساحې ډک کړئ',
    noImage: 'اختیاري - که انځور نه وي خالي پریږدئ',
    validation: {
      titleRequired: 'سرلیک په ټولو ژبو کې اړین دی',
      descriptionRequired: 'تفصیل په ټولو ژبو کې اړین دی',
      locationRequired: 'موقعیت په ټولو ژبو کې اړین دی',
      amountMin: 'لږترلږه رقم 1000 وي',
      amountMax: 'د 100,000,000 څخه زیات نشي',
      phoneInvalid: 'د تماس شمیره باید + سره پیل شي',
      imageInvalid: 'د انځور URL باید https:// سره پیل شي',
      paymentRequired: 'لږترلږه یوه د تادیې طریقه داخل کړئ'
    },
    walletInfo: 'د واليټ معلومات',
    myWallet: 'زما واليټ',
    totalBalance: 'ټول بیلانس',
    countryCode: 'د هیواد کوډ',
    selectCountry: 'هیواد غوره کړئ',
    countries: {
      af: 'افغانستان (+93)',
      pk: 'پاکستان (+92)',
      ir: 'ایران (+98)',
      ae: 'متحده عرب امارات (+971)',
      sa: 'سعودي عربستان (+966)',
      tr: 'ترکیه (+90)',
      us: 'امریکا (+1)',
      uk: 'انګلستان (+44)',
      ca: 'کاناډا (+1)',
      au: 'آسټرالیا (+61)',
      de: 'جرمني (+49)',
      other: 'نور'
    },
    paymentMethods: 'د تادیې طریقې',
    addPaymentMethod: 'د تادیې طریقه اضافه کړئ',
    optional: 'اختیاري',
    required: 'اړین',
    contactInfo: 'د تماس معلومات',
    copyToClipboard: 'کاپي کړئ',
    copied: 'کاپي شو!',
    callNow: 'اوس زنګ ووهئ',
    viewPaymentInfo: 'د تادیې معلومات وګورئ'
  },
  fa: {
    title: 'کمک کنید',
    subtitle: 'به افراد نیازمند کمک کنید',
    myPosts: 'پست‌های من',
    allCases: 'همه موارد',
    createPost: 'ایجاد پست جدید',
    donate: 'کمک کنید',
    share: 'اشتراک',
    raised: 'جمع‌آوری شده',
    target: 'هدف',
    donors: 'کمک‌کنندگان',
    viewDetails: 'جزئیات',
    pending: 'در انتظار تایید',
    approved: 'تایید شده',
    rejected: 'رد شده',
    critical: 'بسیار فوری',
    high: 'فوری',
    medium: 'متوسط',
    postDetails: 'جزئیات پست',
    donateNow: 'اکنون کمک کنید',
    selectAmount: 'مبلغ را انتخاب کنید',
    customAmount: 'مبلغ دلخواه',
    paymentMethod: 'روش پرداخت',
    hesabPay: 'حساب پی',
    bankTransfer: 'انتقال بانکی',
    easypaisa: 'Easypaisa',
    cardPayment: 'کارت',
    paypalPayment: 'PayPal',
    close: 'بستن',
    submit: 'ارسال',
    cancel: 'لغو',
    title_label_ps: 'عنوان (به پشتو)',
    title_label_fa: 'عنوان (به دری)',
    title_label_en: 'عنوان (به انگلیسی)',
    description_label_ps: 'توضیحات (به پشتو)',
    description_label_fa: 'توضیحات (به دری)',
    description_label_en: 'توضیحات (به انگلیسی)',
    targetAmount_label: 'مبلغ هدف',
    currency_label: 'ارز',
    location_label_ps: 'موقعیت (به پشتو)',
    location_label_fa: 'موقعیت (به دری)',
    location_label_en: 'موقعیت (به انگلیسی)',
    category_label: 'دسته‌بندی',
    urgency_label: 'فوریت',
    image_label: 'URL تصویر',
    contactPhone_label: 'شماره تماس',
    paymentInfo_label: 'اطلاعات پرداخت',
    hesabPay_label: 'شماره حساب پی',
    bankAccount_label: 'شماره حساب بانکی',
    bankName_label: 'نام بانک',
    cardNumber_label: 'شماره کارت',
    paypal_label: 'ایمیل یا شماره PayPal',
    easypaisa_label: 'شماره Easypaisa',
    thankYou: 'متشکرم!',
    donationSuccess: 'کمک شما موفق بود!',
    postSubmitted: 'پست شما برای تایید Admin ارسال شد',
    adminPanel: 'پنل مدیریت',
    pendingApproval: 'در انتظار تایید',
    approve: 'تایید',
    reject: 'رد',
    rejectReason: 'دلیل رد',
    categories: {
      medical: 'پزشکی',
      education: 'تحصیلی',
      emergency: 'اضطراری',
      food: 'غذا',
      shelter: 'سرپناه',
      other: 'دیگر'
    },
    filters: {
      all: 'همه',
      critical: 'فوری',
      recent: 'جدید',
      popular: 'محبوب'
    },
    donationHistory: 'تاریخچه کمک‌ها',
    totalDonated: 'مجموع کمک‌ها',
    verifiedBadge: 'تایید شده',
    postedBy: 'توسط',
    postedOn: 'تاریخ',
    noPosts: 'هیچ پستی وجود ندارد',
    noPendingPosts: 'هیچ پست در انتظار تایید نیست',
    confirmDonation: 'تایید',
    enterAmount: 'مبلغ را وارد کنید',
    min50: 'حداقل 50',
    postCreated: 'پست ایجاد شد!',
    editPost: 'ویرایش پست',
    deletePost: 'حذف پست',
    confirmDelete: 'آیا مطمئن هستید؟',
    postDeleted: 'پست حذف شد',
    fillAllFields: 'همه فیلدهای الزامی را پر کنید',
    noImage: 'اختیاری - اگر تصویر ندارید خالی بگذارید',
    validation: {
      titleRequired: 'عنوان در همه زبان‌ها الزامی است',
      descriptionRequired: 'توضیحات در همه زبان‌ها الزامی است',
      locationRequired: 'موقعیت در همه زبان‌ها الزامی است',
      amountMin: 'حداقل مبلغ 1000 باشد',
      amountMax: 'بیشتر از 100,000,000 نباشد',
      phoneInvalid: 'شماره باید با + شروع شود',
      imageInvalid: 'URL تصویر باید با https:// شروع شود',
      paymentRequired: 'حداقل یک روش پرداخت وارد کنید'
    },
    walletInfo: 'اطلاعات کیف پول',
    myWallet: 'کیف پول من',
    totalBalance: 'موجودی کل',
    countryCode: 'کد کشور',
    selectCountry: 'کشور را انتخاب کنید',
    countries: {
      af: 'افغانستان (+93)',
      pk: 'پاکستان (+92)',
      ir: 'ایران (+98)',
      ae: 'امارات متحده عربی (+971)',
      sa: 'عربستان سعودی (+966)',
      tr: 'ترکیه (+90)',
      us: 'امریکا (+1)',
      uk: 'انگلستان (+44)',
      ca: 'کانادا (+1)',
      au: 'استرالیا (+61)',
      de: 'آلمان (+49)',
      other: 'سایر'
    },
    paymentMethods: 'روش‌های پرداخت',
    addPaymentMethod: 'افزودن روش پرداخت',
    optional: 'اختیاری',
    required: 'الزامی',
    contactInfo: 'اطلاعات تماس',
    copyToClipboard: 'کپی کنید',
    copied: 'کپی شد!',
    callNow: 'اکنون تماس بگیرید',
    viewPaymentInfo: 'مشاهده اطلاعات پرداخت'
  },
  en: {
    title: 'Help & Support',
    subtitle: 'Help those in need',
    myPosts: 'My Posts',
    allCases: 'All Cases',
    createPost: 'Create New Post',
    donate: 'Donate',
    share: 'Share',
    raised: 'Raised',
    target: 'Target',
    donors: 'Donors',
    viewDetails: 'Details',
    pending: 'Pending Approval',
    approved: 'Approved',
    rejected: 'Rejected',
    critical: 'Critical',
    high: 'High',
    medium: 'Medium',
    postDetails: 'Post Details',
    donateNow: 'Donate Now',
    selectAmount: 'Select Amount',
    customAmount: 'Custom Amount',
    paymentMethod: 'Payment Method',
    hesabPay: 'Hesab Pay',
    bankTransfer: 'Bank Transfer',
    easypaisa: 'Easypaisa',
    cardPayment: 'Card',
    paypalPayment: 'PayPal',
    close: 'Close',
    submit: 'Submit',
    cancel: 'Cancel',
    title_label_ps: 'Title (in Pashto)',
    title_label_fa: 'Title (in Dari)',
    title_label_en: 'Title (in English)',
    description_label_ps: 'Description (in Pashto)',
    description_label_fa: 'Description (in Dari)',
    description_label_en: 'Description (in English)',
    targetAmount_label: 'Target Amount',
    currency_label: 'Currency',
    location_label_ps: 'Location (in Pashto)',
    location_label_fa: 'Location (in Dari)',
    location_label_en: 'Location (in English)',
    category_label: 'Category',
    urgency_label: 'Urgency',
    image_label: 'Image URL',
    contactPhone_label: 'Contact Phone',
    paymentInfo_label: 'Payment Information',
    hesabPay_label: 'Hesab Pay Number',
    bankAccount_label: 'Bank Account Number',
    bankName_label: 'Bank Name',
    cardNumber_label: 'Card Number',
    paypal_label: 'PayPal Email or Number',
    easypaisa_label: 'Easypaisa Number',
    thankYou: 'Thank You!',
    donationSuccess: 'Your donation was successful!',
    postSubmitted: 'Your post has been submitted for Admin approval',
    adminPanel: 'Admin Panel',
    pendingApproval: 'Pending Approval',
    approve: 'Approve',
    reject: 'Reject',
    rejectReason: 'Rejection Reason',
    categories: {
      medical: 'Medical',
      education: 'Education',
      emergency: 'Emergency',
      food: 'Food',
      shelter: 'Shelter',
      other: 'Other'
    },
    filters: {
      all: 'All',
      critical: 'Critical',
      recent: 'Recent',
      popular: 'Popular'
    },
    donationHistory: 'Donation History',
    totalDonated: 'Total Donated',
    verifiedBadge: 'Verified',
    postedBy: 'Posted by',
    postedOn: 'Posted on',
    noPosts: 'No posts available',
    noPendingPosts: 'No pending posts',
    confirmDonation: 'Confirm',
    enterAmount: 'Enter amount',
    min50: 'Min 50',
    postCreated: 'Post Created!',
    editPost: 'Edit Post',
    deletePost: 'Delete Post',
    confirmDelete: 'Are you sure?',
    postDeleted: 'Post Deleted',
    fillAllFields: 'Fill all required fields',
    noImage: 'Optional - leave empty if no image',
    validation: {
      titleRequired: 'Title required in all languages',
      descriptionRequired: 'Description required in all languages',
      locationRequired: 'Location required in all languages',
      amountMin: 'Minimum amount is 1000',
      amountMax: 'Maximum amount is 100,000,000',
      phoneInvalid: 'Phone must start with +',
      imageInvalid: 'Image URL must start with https://',
      paymentRequired: 'Enter at least one payment method'
    },
    walletInfo: 'Wallet Information',
    myWallet: 'My Wallet',
    totalBalance: 'Total Balance',
    countryCode: 'Country Code',
    selectCountry: 'Select Country',
    countries: {
      af: 'Afghanistan (+93)',
      pk: 'Pakistan (+92)',
      ir: 'Iran (+98)',
      ae: 'UAE (+971)',
      sa: 'Saudi Arabia (+966)',
      tr: 'Turkey (+90)',
      us: 'USA (+1)',
      uk: 'UK (+44)',
      ca: 'Canada (+1)',
      au: 'Australia (+61)',
      de: 'Germany (+49)',
      other: 'Other'
    },
    paymentMethods: 'Payment Methods',
    addPaymentMethod: 'Add Payment Method',
    optional: 'Optional',
    required: 'Required',
    contactInfo: 'Contact Information',
    copyToClipboard: 'Copy',
    copied: 'Copied!',
    callNow: 'Call Now',
    viewPaymentInfo: 'View Payment Info'
  }
};

export function CharitySystem({ language, onBack, currentUserEmail, currentUserName }: CharitySystemProps) {
  const [activeTab, setActiveTab] = useState<'create' | 'all' | 'my' | 'admin'>('create');
  const [posts, setPosts] = useState<CharityPost[]>([]);
  const [selectedPost, setSelectedPost] = useState<CharityPost | null>(null);
  const [showDonateModal, setShowDonateModal] = useState(false);
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [showDetailModal, setShowDetailModal] = useState(false);
  const [donationAmount, setDonationAmount] = useState('');
  const [selectedCurrency, setSelectedCurrency] = useState<Currency>('AFN');
  const [selectedPayment, setSelectedPayment] = useState('hesabPay');
  const [notification, setNotification] = useState('');
  const [filter, setFilter] = useState('all');
  const [rejectReason, setRejectReason] = useState('');
  const [formErrors, setFormErrors] = useState<Record<string, string>>({});
  const [imagePreview, setImagePreview] = useState('');
  const [selectedCountryCode, setSelectedCountryCode] = useState('+93');

  const t = translations[language];
  const isAdmin = currentUserEmail === 'ibrahimkhaksar.it@gmail.com';

  const countryCodes = [
    { code: '+93', country: 'af' },
    { code: '+92', country: 'pk' },
    { code: '+98', country: 'ir' },
    { code: '+971', country: 'ae' },
    { code: '+966', country: 'sa' },
    { code: '+90', country: 'tr' },
    { code: '+1', country: 'us' },
    { code: '+44', country: 'uk' },
    { code: '+61', country: 'au' },
    { code: '+49', country: 'de' }
  ];

  // Load posts from localStorage
  useEffect(() => {
    const savedPosts = localStorage.getItem('healmate_charity_posts');
    if (savedPosts) {
      setPosts(JSON.parse(savedPosts));
    } else {
      // Sample posts
      const samplePosts: CharityPost[] = [
        {
          id: '1',
          userId: 'sample@example.com',
          userName: 'Ahmad Khan',
          userEmail: 'ahmad@example.com',
          title: {
            ps: 'د زړه د جراحي لپاره مرسته',
            fa: 'کمک برای جراحی قلب',
            en: 'Help for Heart Surgery'
          },
          description: {
            ps: 'زما پلار ته د زړه جراحي ته اړتیا ده. مهرباني وکړئ مرسته وکړئ. د عملیات لګښت ډیر لوړ دی او موږ ستاسو د ملاتړ ته اړتیا لرو.',
            fa: 'پدرم به جراحی قلب نیاز دارد. لطفا کمک کنید. هزینه عمل بسیار بالاست و ما به حمایت شما نیاز داریم.',
            en: 'My father needs heart surgery. Please help. The surgery cost is very high and we need your support.'
          },
          targetAmount: 500000,
          raisedAmount: 150000,
          currency: 'AFN',
          image: 'https://images.unsplash.com/photo-1576091160550-2173dba999ef?w=800',
          location: { ps: 'کابل، افغانستان', fa: 'کابل، افغانستان', en: 'Kabul, Afghanistan' },
          category: 'medical',
          urgency: 'critical',
          status: 'approved',
          verified: true,
          donors: [
            { name: 'Ali', amount: 50000, currency: 'AFN', date: '2025-01-15' },
            { name: 'Fatima', amount: 100000, currency: 'AFN', date: '2025-01-16' }
          ],
          createdAt: '2025-01-15T10:00:00Z',
          approvedAt: '2025-01-15T11:00:00Z',
          contactPhone: '+93700123456',
          paymentInfo: {
            hesabPay: '+93779494512',
            bankAccount: '1234567890',
            bankName: 'Afghanistan International Bank',
            cardNumber: '1234 5678 9012 3456',
            paypal: 'ahmad@paypal.com'
          }
        },
        {
          id: '2',
          userId: 'sample2@example.com',
          userName: 'Fatima Ahmadi',
          userEmail: 'fatima@example.com',
          title: {
            ps: 'د زده کړې لپاره مرسته',
            fa: 'کمک برای تحصیل',
            en: 'Help for Education'
          },
          description: {
            ps: 'زه په پوهنتون کې زده کړه کوم خو د فیس ورکولو توان نه لرم. مهرباني وکړئ مرسته وکړئ چې زه خپلې زده کړې بشپړې کړم.',
            fa: 'من در دانشگاه تحصیل می‌کنم اما توان پرداخت شهریه را ندارم. لطفا کمک کنید تا تحصیلم را کامل کنم.',
            en: 'I am studying at university but cannot afford the tuition. Please help me complete my education.'
          },
          targetAmount: 200000,
          raisedAmount: 80000,
          currency: 'AFN',
          image: 'https://images.unsplash.com/photo-1523050854058-8df90110c9f1?w=800',
          location: { ps: 'هرات، افغانستان', fa: 'هرات، افغانستان', en: 'Herat, Afghanistan' },
          category: 'education',
          urgency: 'high',
          status: 'approved',
          verified: true,
          donors: [
            { name: 'Hassan', amount: 30000, currency: 'AFN', date: '2025-01-17' },
            { name: 'Zahra', amount: 50000, currency: 'AFN', date: '2025-01-18' }
          ],
          createdAt: '2025-01-17T10:00:00Z',
          approvedAt: '2025-01-17T11:00:00Z',
          contactPhone: '+93701234567',
          paymentInfo: {
            hesabPay: '+93701234567',
            easypaisa: '+92301234567',
            cardNumber: '9876 5432 1098 7654'
          }
        }
      ];
      setPosts(samplePosts);
      localStorage.setItem('healmate_charity_posts', JSON.stringify(samplePosts));
    }
  }, []);

  // Save posts to localStorage
  useEffect(() => {
    if (posts.length > 0) {
      localStorage.setItem('healmate_charity_posts', JSON.stringify(posts));
    }
  }, [posts]);

  const showNotification = (message: string) => {
    setNotification(message);
    setTimeout(() => setNotification(''), 3000);
  };

  const validateForm = (formData: any): boolean => {
    const errors: Record<string, string> = {};

    // Title validation
    if (!formData.title_ps?.trim()) errors.title_ps = t.validation.titleRequired;
    if (!formData.title_fa?.trim()) errors.title_fa = t.validation.titleRequired;
    if (!formData.title_en?.trim()) errors.title_en = t.validation.titleRequired;

    // Description validation
    if (!formData.description_ps?.trim()) errors.description_ps = t.validation.descriptionRequired;
    if (!formData.description_fa?.trim()) errors.description_fa = t.validation.descriptionRequired;
    if (!formData.description_en?.trim()) errors.description_en = t.validation.descriptionRequired;

    // Location validation (single field)
    if (!formData.location?.trim()) {
      errors.location = t.validation.locationRequired;
    }

    // Amount validation
    const amount = parseFloat(formData.targetAmount);
    if (amount < 1000) errors.targetAmount = t.validation.amountMin;
    if (amount > 100000000) errors.targetAmount = t.validation.amountMax;

    // Phone validation
    if (formData.contactPhone && !formData.contactPhone.startsWith('+')) {
      errors.contactPhone = t.validation.phoneInvalid;
    }
    if (formData.contactPhone && formData.contactPhone.length < 8) {
      errors.contactPhone = t.validation.phoneInvalid;
    }

    // Image validation
    if (formData.image && !formData.image.startsWith('https://')) {
      errors.image = t.validation.imageInvalid;
    }

    // Payment validation - at least one method required
    const hasPaymentMethod = (
      (formData.hesabPay && formData.hesabPay.trim()) || 
      (formData.bankAccount && formData.bankAccount.trim()) || 
      (formData.cardNumber && formData.cardNumber.trim()) || 
      (formData.paypal && formData.paypal.trim()) || 
      (formData.easypaisa && formData.easypaisa.trim())
    );
    if (!hasPaymentMethod) {
      errors.payment = t.validation.paymentRequired;
    }

    setFormErrors(errors);
    return Object.keys(errors).length === 0;
  };

  const handleCreatePost = (formData: any) => {
    // Combine country code with phone number
    if (formData.contactPhone && formData.contactPhone.trim()) {
      formData.contactPhone = selectedCountryCode + formData.contactPhone.replace(/[^0-9]/g, '');
    }

    if (!validateForm(formData)) {
      showNotification(t.fillAllFields);
      return;
    }

    const paymentInfo: PaymentInfo = {};
    if (formData.hesabPay && formData.hesabPay.trim()) paymentInfo.hesabPay = formData.hesabPay.trim();
    if (formData.bankAccount && formData.bankAccount.trim()) paymentInfo.bankAccount = formData.bankAccount.trim();
    if (formData.bankName && formData.bankName.trim()) paymentInfo.bankName = formData.bankName.trim();
    if (formData.cardNumber && formData.cardNumber.trim()) paymentInfo.cardNumber = formData.cardNumber.trim();
    if (formData.paypal && formData.paypal.trim()) paymentInfo.paypal = formData.paypal.trim();
    if (formData.easypaisa && formData.easypaisa.trim()) paymentInfo.easypaisa = formData.easypaisa.trim();

    const newPost: CharityPost = {
      id: Date.now().toString(),
      userId: currentUserEmail,
      userName: currentUserName,
      userEmail: currentUserEmail,
      title: {
        ps: formData.title_ps.trim(),
        fa: formData.title_fa.trim(),
        en: formData.title_en.trim()
      },
      description: {
        ps: formData.description_ps.trim(),
        fa: formData.description_fa.trim(),
        en: formData.description_en.trim()
      },
      targetAmount: parseFloat(formData.targetAmount),
      raisedAmount: 0,
      currency: formData.currency || 'AFN',
      image: formData.image || 'https://images.unsplash.com/photo-1532629345422-7515f3d16bb6?w=800',
      location: {
        ps: formData.location.trim(),
        fa: formData.location.trim(),
        en: formData.location.trim()
      },
      category: formData.category,
      urgency: formData.urgency,
      status: 'pending',
      verified: false,
      donors: [],
      createdAt: new Date().toISOString(),
      contactPhone: formData.contactPhone || undefined,
      paymentInfo
    };

    setPosts([newPost, ...posts]);
    showNotification(t.postSubmitted);
    setShowCreateModal(false);
    setFormErrors({});
    setImagePreview('');
    setSelectedCountryCode('+93');
    setActiveTab('my'); // Switch to "My Posts" tab after creating
  };

  const handleApprovePost = (postId: string) => {
    setPosts(posts.map(post => 
      post.id === postId 
        ? { ...post, status: 'approved' as PostStatus, verified: true, approvedAt: new Date().toISOString() }
        : post
    ));
    showNotification('Post Approved!');
  };

  const handleRejectPost = (postId: string, reason: string) => {
    setPosts(posts.map(post => 
      post.id === postId 
        ? { ...post, status: 'rejected' as PostStatus, rejectedReason: reason }
        : post
    ));
    showNotification('Post Rejected!');
    setRejectReason('');
  };

  const handleDeletePost = (postId: string) => {
    if (confirm(t.confirmDelete)) {
      setPosts(posts.filter(post => post.id !== postId));
      showNotification(t.postDeleted);
    }
  };

  const handleDonate = () => {
    if (!donationAmount || parseFloat(donationAmount) < 50) {
      alert(t.min50);
      return;
    }

    if (selectedPost) {
      const newDonor = {
        name: currentUserName,
        amount: parseFloat(donationAmount),
        currency: selectedCurrency,
        date: new Date().toISOString()
      };

      setPosts(posts.map(post => 
        post.id === selectedPost.id
          ? {
              ...post,
              raisedAmount: post.raisedAmount + parseFloat(donationAmount),
              donors: [...post.donors, newDonor]
            }
          : post
      ));

      showNotification(t.donationSuccess);
      setShowDonateModal(false);
      setDonationAmount('');
    }
  };

  const copyToClipboard = async (text: string) => {
    try {
      if (navigator.clipboard && navigator.clipboard.writeText) {
        await navigator.clipboard.writeText(text);
        showNotification(t.copied);
      } else {
        const tempInput = document.createElement('input');
        tempInput.value = text;
        document.body.appendChild(tempInput);
        tempInput.select();
        document.execCommand('copy');
        document.body.removeChild(tempInput);
        showNotification(t.copied);
      }
    } catch (err) {
      showNotification('Error copying');
    }
  };

  const getCurrencySymbol = (currency: Currency) => {
    switch (currency) {
      case 'AFN': return '؋';
      case 'USD': return '$';
      case 'EUR': return '€';
    }
  };

  const getCurrencyName = (currency: Currency) => {
    switch (currency) {
      case 'AFN': return language === 'ps' ? 'افغانی' : language === 'fa' ? 'افغانی' : 'Afghani';
      case 'USD': return language === 'ps' ? 'ډالر' : language === 'fa' ? 'دالر' : 'Dollar';
      case 'EUR': return language === 'ps' ? 'یورو' : language === 'fa' ? 'یورو' : 'Euro';
    }
  };

  const getUrgencyColor = (urgency: string) => {
    switch (urgency) {
      case 'critical': return 'from-red-500 to-pink-600';
      case 'high': return 'from-orange-500 to-amber-600';
      case 'medium': return 'from-yellow-500 to-orange-500';
      default: return 'from-gray-500 to-gray-600';
    }
  };

  const getStatusBadge = (status: PostStatus) => {
    const badges = {
      pending: { color: 'bg-yellow-100 text-yellow-800 border-yellow-300', icon: Clock },
      approved: { color: 'bg-green-100 text-green-800 border-green-300', icon: CheckCircle },
      rejected: { color: 'bg-red-100 text-red-800 border-red-300', icon: Ban }
    };
    const badge = badges[status];
    const Icon = badge.icon;
    return (
      <span className={`inline-flex items-center gap-1 px-3 py-1 rounded-full text-xs border ${badge.color}`}>
        <Icon className="w-3 h-3" />
        {t[status]}
      </span>
    );
  };

  const filteredPosts = posts.filter(post => {
    if (activeTab === 'my') return post.userId === currentUserEmail;
    if (activeTab === 'admin') return post.status === 'pending';
    if (activeTab === 'all' && post.status !== 'approved') return false;
    
    if (filter === 'critical') return post.urgency === 'critical';
    if (filter === 'recent') return true;
    if (filter === 'popular') return post.donors.length > 0;
    
    return true;
  });

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-pink-50 to-rose-50 pb-28 md:pb-8">
      {/* Header */}
      <div className="sticky top-0 z-40 backdrop-blur-xl bg-white/70 border-b border-white/20 shadow-lg">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between flex-wrap gap-4">
            <div className="flex items-center gap-4">
              <Button variant="ghost" size="icon" onClick={onBack}>
                <ArrowLeft className="w-6 h-6" />
              </Button>
              <div className="flex items-center gap-3">
                <div className="bg-gradient-to-br from-pink-500 to-rose-600 p-3 rounded-2xl">
                  <Heart className="w-6 h-6 text-white" />
                </div>
                <div>
                  <h1 className="text-xl">{t.title}</h1>
                  <p className="text-sm text-gray-600">{t.subtitle}</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Notification */}
      <AnimatePresence>
        {notification && (
          <motion.div
            initial={{ opacity: 0, y: -50 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -50 }}
            className="fixed top-20 left-1/2 transform -translate-x-1/2 z-50 bg-green-500 text-white px-6 py-3 rounded-full shadow-xl flex items-center gap-2"
          >
            <CheckCircle className="w-5 h-5" />
            {notification}
          </motion.div>
        )}
      </AnimatePresence>

      <div className="container mx-auto px-4 py-6 max-w-6xl">
        {/* Tabs */}
        <div className="flex items-center gap-4 mb-6 flex-wrap">
          <Button
            variant={activeTab === 'create' ? 'default' : 'outline'}
            onClick={() => setActiveTab('create')}
            className={activeTab === 'create' ? 'bg-gradient-to-r from-pink-500 to-rose-600 text-white' : ''}
          >
            <Plus className="w-4 h-4 mr-2" />
            {t.createPost}
          </Button>
          <Button
            variant={activeTab === 'all' ? 'default' : 'outline'}
            onClick={() => setActiveTab('all')}
            className={activeTab === 'all' ? 'bg-gradient-to-r from-blue-500 to-indigo-600 text-white' : ''}
          >
            <Globe className="w-4 h-4 mr-2" />
            {t.allCases}
          </Button>
          <Button
            variant={activeTab === 'my' ? 'default' : 'outline'}
            onClick={() => setActiveTab('my')}
            className={activeTab === 'my' ? 'bg-gradient-to-r from-purple-500 to-pink-600 text-white' : ''}
          >
            <Users className="w-4 h-4 mr-2" />
            {t.myPosts}
          </Button>
          {isAdmin && (
            <Button
              variant={activeTab === 'admin' ? 'default' : 'outline'}
              onClick={() => setActiveTab('admin')}
              className={activeTab === 'admin' ? 'bg-gradient-to-r from-amber-500 to-orange-600 text-white' : ''}
            >
              <Crown className="w-4 h-4 mr-2" />
              {t.adminPanel}
            </Button>
          )}
        </div>

        {/* Create Post Form */}
        {activeTab === 'create' && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-white/90 backdrop-blur-xl rounded-3xl p-8 shadow-2xl border border-white/50 mb-6"
          >
            <form
              onSubmit={(e) => {
                e.preventDefault();
                const formData = new FormData(e.currentTarget);
                const data = Object.fromEntries(formData.entries());
                handleCreatePost(data);
              }}
              className="space-y-6"
            >
              {/* Basic Info Section */}
              <div className="bg-gradient-to-br from-pink-50 to-rose-50 rounded-2xl p-6">
                <h3 className="font-semibold mb-4 flex items-center gap-2">
                  <Info className="w-5 h-5 text-pink-600" />
                  {language === 'ps' ? 'اساسي معلومات' : language === 'fa' ? 'اطلاعات اساسی' : 'Basic Information'}
                </h3>
                
                {/* Title in all languages */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
                  <div>
                    <label className="block text-sm font-semibold mb-2">{t.title_label_ps} *</label>
                    <Input 
                      name="title_ps"
                      placeholder={t.title_placeholder_ps}
                      required
                      className="bg-white/90"
                      dir="rtl"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-semibold mb-2">{t.title_label_fa} *</label>
                    <Input 
                      name="title_fa"
                      placeholder={t.title_placeholder_fa}
                      required
                      className="bg-white/90"
                      dir="rtl"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-semibold mb-2">{t.title_label_en} *</label>
                    <Input 
                      name="title_en"
                      placeholder={t.title_placeholder_en}
                      required
                      className="bg-white/90"
                    />
                  </div>
                </div>

                {/* Description in all languages */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
                  <div>
                    <label className="block text-sm font-semibold mb-2">{t.desc_label_ps} *</label>
                    <textarea
                      name="description_ps"
                      placeholder={t.desc_placeholder_ps}
                      required
                      rows={4}
                      className="w-full px-4 py-2 bg-white/90 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-pink-500"
                      dir="rtl"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-semibold mb-2">{t.desc_label_fa} *</label>
                    <textarea
                      name="description_fa"
                      placeholder={t.desc_placeholder_fa}
                      required
                      rows={4}
                      className="w-full px-4 py-2 bg-white/90 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-pink-500"
                      dir="rtl"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-semibold mb-2">{t.desc_label_en} *</label>
                    <textarea
                      name="description_en"
                      placeholder={t.desc_placeholder_en}
                      required
                      rows={4}
                      className="w-full px-4 py-2 bg-white/90 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-pink-500"
                    />
                  </div>
                </div>

                {/* Location and Category */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-semibold mb-2">{t.location} *</label>
                    <Input 
                      name="location"
                      placeholder={language === 'ps' ? 'کابل، افغانستان' : language === 'fa' ? 'کابل، افغانستان' : 'Kabul, Afghanistan'}
                      required
                      className="bg-white/90"
                      dir={language === 'en' ? 'ltr' : 'rtl'}
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-semibold mb-2">{t.category} *</label>
                    <select
                      name="category"
                      required
                      className="w-full px-4 py-2 bg-white/90 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-pink-500"
                    >
                      {Object.entries(t.categories).map(([key, label]) => (
                        <option key={key} value={key}>{label}</option>
                      ))}
                    </select>
                  </div>
                </div>
              </div>

              {/* Financial Info */}
              <div className="bg-gradient-to-br from-blue-50 to-indigo-50 rounded-2xl p-6">
                <h3 className="font-semibold mb-4 flex items-center gap-2">
                  <DollarSign className="w-5 h-5 text-blue-600" />
                  {language === 'ps' ? 'مالي معلومات' : language === 'fa' ? 'اطلاعات مالی' : 'Financial Information'}
                </h3>
                
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div>
                    <label className="block text-sm font-semibold mb-2">{language === 'ps' ? 'اړینه رقم' : language === 'fa' ? 'مبلغ مورد نیاز' : 'Target Amount'} *</label>
                    <Input 
                      name="targetAmount"
                      type="number"
                      placeholder="50000"
                      required
                      min="1000"
                      className="bg-white/90"
                    />
                    <p className="text-xs text-gray-500 mt-1">
                      {language === 'ps' ? 'لږترلږه: 1000 افغانۍ' : language === 'fa' ? 'حداقل: 1000 افغانی' : 'Minimum: 1000 AFN'}
                    </p>
                  </div>
                  <div>
                    <label className="block text-sm font-semibold mb-2">{language === 'ps' ? 'اسعار' : language === 'fa' ? 'واحد پول' : 'Currency'} *</label>
                    <select
                      name="currency"
                      required
                      defaultValue="AFN"
                      className="w-full px-4 py-2 bg-white/90 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500"
                    >
                      <option value="AFN">؋ {getCurrencyName('AFN')}</option>
                      <option value="USD">$ {getCurrencyName('USD')}</option>
                      <option value="EUR">€ {getCurrencyName('EUR')}</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-semibold mb-2">{language === 'ps' ? 'بیړنیتوب' : language === 'fa' ? 'فوریت' : 'Urgency'} *</label>
                    <select
                      name="urgency"
                      required
                      className="w-full px-4 py-2 bg-white/90 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500"
                    >
                      {Object.entries(t.urgencies).map(([key, label]) => (
                        <option key={key} value={key}>{label}</option>
                      ))}
                    </select>
                  </div>
                </div>
              </div>

              {/* Contact Info */}
              <div className="bg-gradient-to-br from-purple-50 to-pink-50 rounded-2xl p-6">
                <h3 className="font-semibold mb-4 flex items-center gap-2">
                  <Phone className="w-5 h-5 text-purple-600" />
                  {language === 'ps' ? 'د تماس معلومات' : language === 'fa' ? 'اطلاعات تماس' : 'Contact Information'}
                </h3>
                
                <div className="mb-4">
                  <label className="block text-sm font-semibold mb-2">{t.contactPhone} *</label>
                  <div className="flex gap-2">
                    <select
                      value={selectedCountryCode}
                      onChange={(e) => setSelectedCountryCode(e.target.value)}
                      className="w-32 px-3 py-2 bg-white/90 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-purple-500"
                    >
                      {countryCodes.map((country) => (
                        <option key={country.code} value={country.code}>
                          {country.flag} {country.code}
                        </option>
                      ))}
                    </select>
                    <Input 
                      name="contactPhone"
                      type="tel"
                      placeholder="700123456"
                      required
                      className="flex-1 bg-white/90"
                    />
                  </div>
                  {formErrors.phone && (
                    <p className="text-red-500 text-sm mt-1">{formErrors.phone}</p>
                  )}
                </div>
              </div>

              {/* Payment Methods */}
              <div className="bg-gradient-to-br from-green-50 to-emerald-50 rounded-2xl p-6">
                <h3 className="font-semibold mb-4 flex items-center gap-2">
                  <CreditCard className="w-5 h-5 text-green-600" />
                  {language === 'ps' ? 'د تادیې طریقې' : language === 'fa' ? 'روش‌های پرداخت' : 'Payment Methods'}
                </h3>
                <p className="text-sm text-gray-600 mb-4">
                  {language === 'ps' ? 'لږترلږه یوه تادیې طریقه داخل کړئ' : language === 'fa' ? 'حداقل یک روش پرداخت وارد کنید' : 'Enter at least one payment method'}
                </p>
                
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-semibold mb-2">Hesab Pay</label>
                    <Input 
                      name="hesabPay"
                      type="tel"
                      placeholder="+93779494512"
                      className="bg-white/90"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-semibold mb-2">Easypaisa</label>
                    <Input 
                      name="easypaisa"
                      type="tel"
                      placeholder="+92301234567"
                      className="bg-white/90"
                    />
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-semibold mb-2">{t.bankAccount}</label>
                      <Input 
                        name="bankAccount"
                        placeholder={t.bankAccountPlaceholder}
                        className="bg-white/90"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-semibold mb-2">{t.bankName}</label>
                      <Input 
                        name="bankName"
                        placeholder={t.bankNamePlaceholder}
                        className="bg-white/90"
                      />
                    </div>
                  </div>
                  <div>
                    <label className="block text-sm font-semibold mb-2">{t.cardNumber}</label>
                    <Input 
                      name="cardNumber"
                      placeholder="1234 5678 9012 3456"
                      className="bg-white/90"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-semibold mb-2">PayPal</label>
                    <Input 
                      name="paypal"
                      type="email"
                      placeholder="your@email.com"
                      className="bg-white/90"
                    />
                  </div>
                </div>
                {formErrors.payment && (
                  <p className="text-red-500 text-sm mt-2">{formErrors.payment}</p>
                )}
              </div>

              {/* Image Upload */}
              <div className="bg-gradient-to-br from-amber-50 to-orange-50 rounded-2xl p-6">
                <h3 className="font-semibold mb-4 flex items-center gap-2">
                  <Camera className="w-5 h-5 text-amber-600" />
                  {language === 'ps' ? 'انځور' : language === 'fa' ? 'تصویر' : 'Image'}
                </h3>
                <Input 
                  name="image"
                  placeholder="https://example.com/image.jpg"
                  onChange={(e) => setImagePreview(e.target.value)}
                  className="bg-white/90 mb-3"
                />
                {imagePreview && (
                  <div className="relative h-48 rounded-xl overflow-hidden">
                    <ImageWithFallback
                      src={imagePreview}
                      alt="Preview"
                      className="w-full h-full object-cover"
                    />
                  </div>
                )}
                <p className="text-xs text-gray-500 mt-2">
                  {language === 'ps' ? 'د انځور URL داخل کړئ (اختیاري)' : language === 'fa' ? 'URL تصویر را وارد کنید (اختیاری)' : 'Enter image URL (optional)'}
                </p>
              </div>

              {/* Submit Button */}
              <Button
                type="submit"
                className="w-full bg-gradient-to-r from-pink-500 to-rose-600 text-white py-6 text-lg"
              >
                <Send className="w-5 h-5 mr-2" />
                {t.submitPost}
              </Button>
            </form>
          </motion.div>
        )}

        {/* Filters */}
        {activeTab === 'all' && (
          <div className="flex items-center gap-3 mb-6 flex-wrap">
            <Filter className="w-5 h-5 text-gray-600" />
            {Object.entries(t.filters).map(([key, label]) => (
              <button
                key={key}
                onClick={() => setFilter(key)}
                className={`px-4 py-2 rounded-full text-sm transition-all ${
                  filter === key
                    ? 'bg-gradient-to-r from-pink-500 to-rose-600 text-white shadow-lg'
                    : 'bg-white/60 hover:bg-white'
                }`}
              >
                {label}
              </button>
            ))}
          </div>
        )}

        {/* Ad Banner */}
        {activeTab !== 'create' && (
          <div className="mb-6">
            <AdBanner adId="charity_top_banner" />
          </div>
        )}

        {/* Posts Grid */}
        {activeTab !== 'create' && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredPosts.length === 0 ? (
            <div className="col-span-full text-center py-12">
              <Heart className="w-16 h-16 text-gray-300 mx-auto mb-4" />
              <p className="text-gray-500">{activeTab === 'admin' ? t.noPendingPosts : t.noPosts}</p>
            </div>
          ) : (
            filteredPosts.map((post) => (
              <motion.div
                key={post.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="bg-white/90 backdrop-blur-xl rounded-3xl overflow-hidden shadow-xl hover:shadow-2xl transition-all border border-white/50"
              >
                {/* Image */}
                <div className="relative h-48 overflow-hidden">
                  <ImageWithFallback
                    src={post.image}
                    alt={post.title[language]}
                    className="w-full h-full object-cover"
                  />
                  <div className={`absolute top-3 right-3 bg-gradient-to-r ${getUrgencyColor(post.urgency)} text-white px-3 py-1 rounded-full text-xs flex items-center gap-1`}>
                    <AlertCircle className="w-3 h-3" />
                    {t[post.urgency]}
                  </div>
                  {post.verified && (
                    <div className="absolute top-3 left-3 bg-blue-500 text-white px-3 py-1 rounded-full text-xs flex items-center gap-1">
                      <CheckCircle className="w-3 h-3" />
                      {t.verifiedBadge}
                    </div>
                  )}
                  <div className="absolute bottom-3 left-3">
                    {getStatusBadge(post.status)}
                  </div>
                </div>

                {/* Content */}
                <div className="p-6">
                  <h3 className="text-lg mb-2 line-clamp-1">{post.title[language]}</h3>
                  <p className="text-sm text-gray-600 mb-4 line-clamp-2">{post.description[language]}</p>

                  {/* Progress */}
                  <div className="mb-4">
                    <div className="flex items-center justify-between mb-2 text-sm">
                      <span className="text-gray-600">{t.raised}:</span>
                      <span className="font-semibold">
                        {getCurrencySymbol(post.currency)} {post.raisedAmount.toLocaleString()}
                      </span>
                    </div>
                    <div className="flex items-center justify-between mb-2 text-sm">
                      <span className="text-gray-600">{t.target}:</span>
                      <span className="font-semibold">
                        {getCurrencySymbol(post.currency)} {post.targetAmount.toLocaleString()}
                      </span>
                    </div>
                    <div className="w-full h-2 bg-gray-200 rounded-full overflow-hidden">
                      <div
                        className="h-full bg-gradient-to-r from-pink-500 to-rose-600 transition-all"
                        style={{ width: `${Math.min((post.raisedAmount / post.targetAmount) * 100, 100)}%` }}
                      />
                    </div>
                    <div className="flex items-center justify-between mt-2 text-xs text-gray-500">
                      <span>{Math.round((post.raisedAmount / post.targetAmount) * 100)}%</span>
                      <span className="flex items-center gap-1">
                        <Users className="w-3 h-3" />
                        {post.donors.length} {t.donors}
                      </span>
                    </div>
                  </div>

                  {/* Meta */}
                  <div className="flex items-center gap-2 text-xs text-gray-500 mb-4">
                    <MapPin className="w-3 h-3" />
                    {post.location[language]}
                  </div>

                  {/* Actions */}
                  <div className="flex items-center gap-2">
                    {post.status === 'approved' && (
                      <>
                        <Button
                          onClick={() => {
                            setSelectedPost(post);
                            setShowDetailModal(true);
                          }}
                          variant="outline"
                          size="icon"
                        >
                          <Eye className="w-4 h-4" />
                        </Button>
                        <Button
                          onClick={() => {
                            setSelectedPost(post);
                            setShowDonateModal(true);
                          }}
                          className="flex-1 bg-gradient-to-r from-pink-500 to-rose-600 text-white"
                        >
                          <Heart className="w-4 h-4 mr-2" />
                          {t.donate}
                        </Button>
                        <Button
                          variant="outline"
                          size="icon"
                          onClick={async () => {
                            try {
                              if (navigator.share) {
                                await navigator.share({
                                  title: post.title[language],
                                  text: post.description[language],
                                  url: window.location.href
                                }).catch(() => {});
                              } else {
                                copyToClipboard(window.location.href);
                              }
                            } catch (err) {
                              copyToClipboard(window.location.href);
                            }
                          }}
                        >
                          <Share2 className="w-4 h-4" />
                        </Button>
                      </>
                    )}
                    {activeTab === 'my' && post.userId === currentUserEmail && (
                      <Button
                        variant="outline"
                        size="icon"
                        onClick={() => handleDeletePost(post.id)}
                        className="text-red-500 hover:text-red-700"
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    )}
                    {activeTab === 'admin' && isAdmin && (
                      <>
                        <Button
                          onClick={() => handleApprovePost(post.id)}
                          className="flex-1 bg-green-500 hover:bg-green-600 text-white"
                        >
                          <Check className="w-4 h-4 mr-2" />
                          {t.approve}
                        </Button>
                        <Button
                          onClick={() => {
                            const reason = prompt(t.rejectReason);
                            if (reason) handleRejectPost(post.id, reason);
                          }}
                          variant="outline"
                          className="text-red-500 hover:text-red-700"
                        >
                          <X className="w-4 h-4" />
                        </Button>
                      </>
                    )}
                  </div>
                </div>
              </motion.div>
            ))
          )}
          </div>
        )}

        {/* Ad Banner */}
        {activeTab !== 'create' && (
          <div className="mt-6">
            <AdBanner adId="charity_bottom_banner" />
          </div>
        )}
      </div>

      {/* Detail Modal */}
      <AnimatePresence>
        {showDetailModal && selectedPost && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4"
            onClick={() => setShowDetailModal(false)}
          >
            <motion.div
              initial={{ scale: 0.9, y: 20 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.9, y: 20 }}
              className="bg-white rounded-3xl p-6 max-w-2xl w-full max-h-[90vh] overflow-y-auto"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-xl flex items-center gap-2">
                  <Info className="w-6 h-6 text-pink-500" />
                  {t.postDetails}
                </h2>
                <Button variant="ghost" size="icon" onClick={() => setShowDetailModal(false)}>
                  <X className="w-5 h-5" />
                </Button>
              </div>

              {/* Image */}
              <div className="rounded-2xl overflow-hidden mb-6">
                <ImageWithFallback
                  src={selectedPost.image}
                  alt={selectedPost.title[language]}
                  className="w-full h-64 object-cover"
                />
              </div>

              {/* Title & Description */}
              <div className="mb-6">
                <h3 className="text-2xl mb-3">{selectedPost.title[language]}</h3>
                <p className="text-gray-700 leading-relaxed">{selectedPost.description[language]}</p>
              </div>

              {/* Progress */}
              <div className="bg-gradient-to-br from-pink-50 to-rose-50 rounded-2xl p-6 mb-6">
                <div className="flex items-center justify-between mb-4">
                  <div>
                    <p className="text-sm text-gray-600">{t.raised}</p>
                    <p className="text-2xl font-semibold text-pink-600">
                      {getCurrencySymbol(selectedPost.currency)} {selectedPost.raisedAmount.toLocaleString()}
                    </p>
                  </div>
                  <div className="text-right">
                    <p className="text-sm text-gray-600">{t.target}</p>
                    <p className="text-2xl font-semibold">
                      {getCurrencySymbol(selectedPost.currency)} {selectedPost.targetAmount.toLocaleString()}
                    </p>
                  </div>
                </div>
                <div className="w-full h-3 bg-white rounded-full overflow-hidden">
                  <div
                    className="h-full bg-gradient-to-r from-pink-500 to-rose-600 transition-all"
                    style={{ width: `${Math.min((selectedPost.raisedAmount / selectedPost.targetAmount) * 100, 100)}%` }}
                  />
                </div>
                <p className="text-center text-sm text-gray-600 mt-2">
                  {Math.round((selectedPost.raisedAmount / selectedPost.targetAmount) * 100)}% {t.raised}
                </p>
              </div>

              {/* Contact Info */}
              <div className="bg-gradient-to-br from-blue-50 to-indigo-50 rounded-2xl p-6 mb-6">
                <h4 className="font-semibold mb-4 flex items-center gap-2">
                  <Phone className="w-5 h-5 text-blue-600" />
                  {t.contactInfo}
                </h4>
                {selectedPost.contactPhone && (
                  <div className="flex items-center gap-3 mb-3">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => copyToClipboard(selectedPost.contactPhone!)}
                      className="flex-1"
                    >
                      <Copy className="w-4 h-4 mr-2" />
                      {selectedPost.contactPhone}
                    </Button>
                    <a href={`tel:${selectedPost.contactPhone}`}>
                      <Button size="sm" className="bg-green-500 hover:bg-green-600 text-white">
                        <Phone className="w-4 h-4 mr-2" />
                        {t.callNow}
                      </Button>
                    </a>
                  </div>
                )}
              </div>

              {/* Payment Info */}
              {selectedPost.paymentInfo && (
                <div className="bg-gradient-to-br from-purple-50 to-pink-50 rounded-2xl p-6 mb-6">
                  <h4 className="font-semibold mb-4 flex items-center gap-2">
                    <Wallet className="w-5 h-5 text-purple-600" />
                    {t.paymentMethods}
                  </h4>
                  <div className="space-y-3">
                    {selectedPost.paymentInfo.hesabPay && (
                      <div className="flex items-center gap-3">
                        <div className="flex-1 bg-white rounded-xl p-3">
                          <p className="text-xs text-gray-600 mb-1">{t.hesabPay}</p>
                          <p className="font-semibold">{selectedPost.paymentInfo.hesabPay}</p>
                        </div>
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => copyToClipboard(selectedPost.paymentInfo!.hesabPay!)}
                        >
                          <Copy className="w-4 h-4" />
                        </Button>
                      </div>
                    )}
                    {selectedPost.paymentInfo.bankAccount && (
                      <div className="flex items-center gap-3">
                        <div className="flex-1 bg-white rounded-xl p-3">
                          <p className="text-xs text-gray-600 mb-1">{t.bankTransfer}</p>
                          <p className="font-semibold">{selectedPost.paymentInfo.bankAccount}</p>
                          {selectedPost.paymentInfo.bankName && (
                            <p className="text-sm text-gray-600">{selectedPost.paymentInfo.bankName}</p>
                          )}
                        </div>
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => copyToClipboard(selectedPost.paymentInfo!.bankAccount!)}
                        >
                          <Copy className="w-4 h-4" />
                        </Button>
                      </div>
                    )}
                    {selectedPost.paymentInfo.cardNumber && (
                      <div className="flex items-center gap-3">
                        <div className="flex-1 bg-white rounded-xl p-3">
                          <p className="text-xs text-gray-600 mb-1">{t.cardPayment}</p>
                          <p className="font-semibold">{selectedPost.paymentInfo.cardNumber}</p>
                        </div>
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => copyToClipboard(selectedPost.paymentInfo!.cardNumber!)}
                        >
                          <Copy className="w-4 h-4" />
                        </Button>
                      </div>
                    )}
                    {selectedPost.paymentInfo.paypal && (
                      <div className="flex items-center gap-3">
                        <div className="flex-1 bg-white rounded-xl p-3">
                          <p className="text-xs text-gray-600 mb-1">{t.paypalPayment}</p>
                          <p className="font-semibold">{selectedPost.paymentInfo.paypal}</p>
                        </div>
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => copyToClipboard(selectedPost.paymentInfo!.paypal!)}
                        >
                          <Copy className="w-4 h-4" />
                        </Button>
                      </div>
                    )}
                    {selectedPost.paymentInfo.easypaisa && (
                      <div className="flex items-center gap-3">
                        <div className="flex-1 bg-white rounded-xl p-3">
                          <p className="text-xs text-gray-600 mb-1">{t.easypaisa}</p>
                          <p className="font-semibold">{selectedPost.paymentInfo.easypaisa}</p>
                        </div>
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => copyToClipboard(selectedPost.paymentInfo!.easypaisa!)}
                        >
                          <Copy className="w-4 h-4" />
                        </Button>
                      </div>
                    )}
                  </div>
                </div>
              )}

              {/* Action Button */}
              <Button
                onClick={() => {
                  setShowDetailModal(false);
                  setShowDonateModal(true);
                }}
                className="w-full bg-gradient-to-r from-pink-500 to-rose-600 text-white"
              >
                <Heart className="w-5 h-5 mr-2" />
                {t.donateNow}
              </Button>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Donate Modal */}
      <AnimatePresence>
        {showDonateModal && selectedPost && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4"
            onClick={() => setShowDonateModal(false)}
          >
            <motion.div
              initial={{ scale: 0.9, y: 20 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.9, y: 20 }}
              className="bg-white rounded-3xl p-6 max-w-md w-full max-h-[90vh] overflow-y-auto"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-xl flex items-center gap-2">
                  <Heart className="w-6 h-6 text-pink-500" />
                  {t.donateNow}
                </h2>
                <Button variant="ghost" size="icon" onClick={() => setShowDonateModal(false)}>
                  <X className="w-5 h-5" />
                </Button>
              </div>

              <div className="space-y-4">
                {/* Currency Selection */}
                <div>
                  <label className="block text-sm mb-3 font-semibold">{t.currency_label}</label>
                  <div className="grid grid-cols-3 gap-3">
                    {(['AFN', 'USD', 'EUR'] as Currency[]).map((currency) => (
                      <button
                        key={currency}
                        onClick={() => setSelectedCurrency(currency)}
                        className={`p-4 rounded-2xl border-2 transition-all ${
                          selectedCurrency === currency
                            ? 'border-pink-500 bg-gradient-to-br from-pink-50 to-rose-50 shadow-lg scale-105'
                            : 'border-gray-200 hover:border-pink-300 bg-white'
                        }`}
                      >
                        <div className="flex flex-col items-center gap-2">
                          {currency === 'AFN' && <Coins className="w-6 h-6 text-green-600" />}
                          {currency === 'USD' && <DollarSign className="w-6 h-6 text-blue-600" />}
                          {currency === 'EUR' && <Euro className="w-6 h-6 text-purple-600" />}
                          <span className="font-semibold text-sm">{currency}</span>
                          <span className="text-xs text-gray-500">{getCurrencyName(currency)}</span>
                        </div>
                      </button>
                    ))}
                  </div>
                </div>

                {/* Quick Amounts */}
                <div>
                  <label className="block text-sm mb-3 font-semibold">{t.selectAmount}</label>
                  <div className="grid grid-cols-3 gap-2">
                    {selectedCurrency === 'AFN' && [100, 500, 1000, 5000, 10000, 50000].map((amount) => (
                      <button
                        key={amount}
                        onClick={() => setDonationAmount(amount.toString())}
                        className={`p-3 rounded-xl border-2 transition-all ${
                          donationAmount === amount.toString()
                            ? 'border-pink-500 bg-pink-50 scale-105'
                            : 'border-gray-200 hover:border-pink-300'
                        }`}
                      >
                        <div className="text-center">
                          <div className="font-semibold text-sm">{getCurrencySymbol(selectedCurrency)} {amount.toLocaleString()}</div>
                        </div>
                      </button>
                    ))}
                    {selectedCurrency === 'USD' && [5, 10, 20, 50, 100, 500].map((amount) => (
                      <button
                        key={amount}
                        onClick={() => setDonationAmount(amount.toString())}
                        className={`p-3 rounded-xl border-2 transition-all ${
                          donationAmount === amount.toString()
                            ? 'border-pink-500 bg-pink-50 scale-105'
                            : 'border-gray-200 hover:border-pink-300'
                        }`}
                      >
                        <div className="text-center">
                          <div className="font-semibold text-sm">{getCurrencySymbol(selectedCurrency)} {amount.toLocaleString()}</div>
                        </div>
                      </button>
                    ))}
                    {selectedCurrency === 'EUR' && [5, 10, 20, 50, 100, 500].map((amount) => (
                      <button
                        key={amount}
                        onClick={() => setDonationAmount(amount.toString())}
                        className={`p-3 rounded-xl border-2 transition-all ${
                          donationAmount === amount.toString()
                            ? 'border-pink-500 bg-pink-50 scale-105'
                            : 'border-gray-200 hover:border-pink-300'
                        }`}
                      >
                        <div className="text-center">
                          <div className="font-semibold text-sm">{getCurrencySymbol(selectedCurrency)} {amount.toLocaleString()}</div>
                        </div>
                      </button>
                    ))}
                  </div>
                </div>

                {/* Custom Amount */}
                <div>
                  <label className="block text-sm mb-2 font-semibold">{t.customAmount}</label>
                  <Input
                    type="number"
                    value={donationAmount}
                    onChange={(e) => setDonationAmount(e.target.value)}
                    placeholder={t.enterAmount}
                    className="w-full text-lg"
                  />
                  <p className="text-xs text-gray-500 mt-1">{t.min50}</p>
                </div>

                {/* Info about payment */}
                <div className="bg-blue-50 rounded-xl p-4">
                  <p className="text-sm text-gray-700">
                    <Info className="w-4 h-4 inline mr-2 text-blue-600" />
                    {t.viewPaymentInfo}
                  </p>
                </div>

                {/* Action Buttons */}
                <div className="flex gap-3 pt-4">
                  <Button
                    variant="outline"
                    className="flex-1"
                    onClick={() => setShowDonateModal(false)}
                  >
                    {t.cancel}
                  </Button>
                  <Button
                    onClick={handleDonate}
                    className="flex-1 bg-gradient-to-r from-pink-500 to-rose-600 text-white"
                  >
                    <CheckCircle className="w-5 h-5 mr-2" />
                    {t.confirmDonation}
                  </Button>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Create Post Modal - Removed, now using inline form */}
      <AnimatePresence>
        {false && showCreateModal && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4"
            onClick={() => {
              setShowCreateModal(false);
              setFormErrors({});
              setImagePreview('');
            }}
          >
            <motion.div
              initial={{ scale: 0.9, y: 20 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.9, y: 20 }}
              className="bg-white rounded-3xl p-6 max-w-4xl w-full max-h-[90vh] overflow-y-auto"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-xl flex items-center gap-2">
                  <Plus className="w-6 h-6 text-pink-500" />
                  {t.createPost}
                </h2>
                <Button variant="ghost" size="icon" onClick={() => {
                  setShowCreateModal(false);
                  setFormErrors({});
                  setImagePreview('');
                }}>
                  <X className="w-5 h-5" />
                </Button>
              </div>

              <form
                onSubmit={(e) => {
                  e.preventDefault();
                  const formData = new FormData(e.currentTarget);
                  const data = Object.fromEntries(formData.entries());
                  handleCreatePost(data);
                }}
                className="space-y-6"
              >
                {/* Basic Info Section */}
                <div className="bg-gradient-to-br from-pink-50 to-rose-50 rounded-2xl p-6">
                  <h3 className="font-semibold mb-4 flex items-center gap-2">
                    <Info className="w-5 h-5 text-pink-600" />
                    {language === 'ps' ? 'اساسي معلومات' : language === 'fa' ? 'اطلاعات اساسی' : 'Basic Information'}
                  </h3>
                  
                  {/* Title in all languages */}
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
                    <div>
                      <label className="block text-sm font-semibold mb-2">{t.title_label_ps} *</label>
                      <Input 
                        name="title_ps" 
                        placeholder="د پوسټ سرلیک"
                        className={formErrors.title_ps ? 'border-red-500' : ''}
                        dir="rtl"
                      />
                      {formErrors.title_ps && <p className="text-xs text-red-500 mt-1">{formErrors.title_ps}</p>}
                    </div>
                    <div>
                      <label className="block text-sm font-semibold mb-2">{t.title_label_fa} *</label>
                      <Input 
                        name="title_fa" 
                        placeholder="عنوان پست"
                        className={formErrors.title_fa ? 'border-red-500' : ''}
                        dir="rtl"
                      />
                      {formErrors.title_fa && <p className="text-xs text-red-500 mt-1">{formErrors.title_fa}</p>}
                    </div>
                    <div>
                      <label className="block text-sm font-semibold mb-2">{t.title_label_en} *</label>
                      <Input 
                        name="title_en" 
                        placeholder="Post title"
                        className={formErrors.title_en ? 'border-red-500' : ''}
                      />
                      {formErrors.title_en && <p className="text-xs text-red-500 mt-1">{formErrors.title_en}</p>}
                    </div>
                  </div>

                  {/* Description in all languages */}
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
                    <div>
                      <label className="block text-sm font-semibold mb-2">{t.description_label_ps} *</label>
                      <textarea
                        name="description_ps"
                        placeholder="بشپړ تفصیل"
                        className={`w-full p-3 border rounded-xl min-h-[100px] ${formErrors.description_ps ? 'border-red-500' : ''}`}
                        dir="rtl"
                      />
                      {formErrors.description_ps && <p className="text-xs text-red-500 mt-1">{formErrors.description_ps}</p>}
                    </div>
                    <div>
                      <label className="block text-sm font-semibold mb-2">{t.description_label_fa} *</label>
                      <textarea
                        name="description_fa"
                        placeholder="توضیحات کامل"
                        className={`w-full p-3 border rounded-xl min-h-[100px] ${formErrors.description_fa ? 'border-red-500' : ''}`}
                        dir="rtl"
                      />
                      {formErrors.description_fa && <p className="text-xs text-red-500 mt-1">{formErrors.description_fa}</p>}
                    </div>
                    <div>
                      <label className="block text-sm font-semibold mb-2">{t.description_label_en} *</label>
                      <textarea
                        name="description_en"
                        placeholder="Full description"
                        className={`w-full p-3 border rounded-xl min-h-[100px] ${formErrors.description_en ? 'border-red-500' : ''}`}
                      />
                      {formErrors.description_en && <p className="text-xs text-red-500 mt-1">{formErrors.description_en}</p>}
                    </div>
                  </div>

                  {/* Location in all languages */}
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div>
                      <label className="block text-sm font-semibold mb-2">{t.location_label_ps} *</label>
                      <Input 
                        name="location_ps" 
                        placeholder="کابل، افغانستان"
                        className={formErrors.location_ps ? 'border-red-500' : ''}
                        dir="rtl"
                      />
                      {formErrors.location_ps && <p className="text-xs text-red-500 mt-1">{formErrors.location_ps}</p>}
                    </div>
                    <div>
                      <label className="block text-sm font-semibold mb-2">{t.location_label_fa} *</label>
                      <Input 
                        name="location_fa" 
                        placeholder="کابل، افغانستان"
                        className={formErrors.location_fa ? 'border-red-500' : ''}
                        dir="rtl"
                      />
                      {formErrors.location_fa && <p className="text-xs text-red-500 mt-1">{formErrors.location_fa}</p>}
                    </div>
                    <div>
                      <label className="block text-sm font-semibold mb-2">{t.location_label_en} *</label>
                      <Input 
                        name="location_en" 
                        placeholder="Kabul, Afghanistan"
                        className={formErrors.location_en ? 'border-red-500' : ''}
                      />
                      {formErrors.location_en && <p className="text-xs text-red-500 mt-1">{formErrors.location_en}</p>}
                    </div>
                  </div>
                </div>

                {/* Amount & Category Section */}
                <div className="bg-gradient-to-br from-blue-50 to-indigo-50 rounded-2xl p-6">
                  <h3 className="font-semibold mb-4 flex items-center gap-2">
                    <Target className="w-5 h-5 text-blue-600" />
                    {language === 'ps' ? 'رقم او کټګوري' : language === 'fa' ? 'مبلغ و دسته‌بندی' : 'Amount & Category'}
                  </h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-semibold mb-2">{t.targetAmount_label} *</label>
                      <Input 
                        name="targetAmount" 
                        type="number" 
                        placeholder="10000" 
                        min="1000"
                        max="100000000"
                        className={formErrors.targetAmount ? 'border-red-500' : ''}
                      />
                      {formErrors.targetAmount && <p className="text-xs text-red-500 mt-1">{formErrors.targetAmount}</p>}
                      <p className="text-xs text-gray-500 mt-1">{t.validation.amountMin}</p>
                    </div>

                    <div>
                      <label className="block text-sm font-semibold mb-2">{t.currency_label} *</label>
                      <select name="currency" className="w-full p-3 border rounded-xl">
                        <option value="AFN">AFN - ؋ {getCurrencyName('AFN')}</option>
                        <option value="USD">USD - $ {getCurrencyName('USD')}</option>
                        <option value="EUR">EUR - € {getCurrencyName('EUR')}</option>
                      </select>
                    </div>

                    <div>
                      <label className="block text-sm font-semibold mb-2">{t.category_label} *</label>
                      <select name="category" className="w-full p-3 border rounded-xl">
                        {Object.entries(t.categories).map(([key, label]) => (
                          <option key={key} value={key}>{label}</option>
                        ))}
                      </select>
                    </div>

                    <div>
                      <label className="block text-sm font-semibold mb-2">{t.urgency_label} *</label>
                      <select name="urgency" className="w-full p-3 border rounded-xl">
                        <option value="critical">{t.critical}</option>
                        <option value="high">{t.high}</option>
                        <option value="medium">{t.medium}</option>
                      </select>
                    </div>
                  </div>
                </div>

                {/* Contact Section */}
                <div className="bg-gradient-to-br from-green-50 to-emerald-50 rounded-2xl p-6">
                  <h3 className="font-semibold mb-4 flex items-center gap-2">
                    <Phone className="w-5 h-5 text-green-600" />
                    {t.contactInfo}
                  </h3>
                  
                  {/* Country Code Selector */}
                  <div className="mb-4">
                    <label className="block text-sm text-gray-600 mb-2">{t.selectCountry}</label>
                    <div className="grid grid-cols-2 md:grid-cols-5 gap-2">
                      {countryCodes.map(({ code, country }) => (
                        <button
                          key={code}
                          type="button"
                          onClick={() => setSelectedCountryCode(code)}
                          className={`p-2 rounded-lg border-2 transition-all text-sm ${
                            selectedCountryCode === code
                              ? 'border-green-500 bg-green-50'
                              : 'border-gray-200 hover:border-green-300'
                          }`}
                        >
                          <span className="font-semibold">{code}</span>
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Phone Number Input */}
                  <div className="flex gap-2">
                    <div className="w-24 flex items-center justify-center bg-white rounded-xl border-2 border-gray-200 px-3">
                      <span className="font-semibold text-gray-700">{selectedCountryCode}</span>
                    </div>
                    <Input 
                      name="contactPhone" 
                      type="tel" 
                      placeholder="700123456"
                      className={`flex-1 ${formErrors.contactPhone ? 'border-red-500' : ''}`}
                      onChange={(e) => {
                        const input = e.target as HTMLInputElement;
                        input.value = input.value.replace(/[^0-9]/g, '');
                      }}
                    />
                  </div>
                  {formErrors.contactPhone && <p className="text-xs text-red-500 mt-1">{formErrors.contactPhone}</p>}
                  <p className="text-xs text-gray-500 mt-1">
                    {language === 'ps' 
                      ? `مثال: ${selectedCountryCode}700123456` 
                      : language === 'fa' 
                      ? `مثال: ${selectedCountryCode}700123456` 
                      : `Example: ${selectedCountryCode}700123456`}
                  </p>
                </div>

                {/* Payment Methods Section */}
                <div className="bg-gradient-to-br from-purple-50 to-pink-50 rounded-2xl p-6">
                  <h3 className="font-semibold mb-4 flex items-center gap-2">
                    <Wallet className="w-5 h-5 text-purple-600" />
                    {t.paymentMethods} ({t.required})
                  </h3>
                  {formErrors.payment && (
                    <div className="bg-red-50 border border-red-200 rounded-xl p-3 mb-4">
                      <p className="text-sm text-red-600">{formErrors.payment}</p>
                    </div>
                  )}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-semibold mb-2 flex items-center gap-2">
                        <Coins className="w-4 h-4 text-green-600" />
                        {t.hesabPay_label} ({t.optional})
                      </label>
                      <Input 
                        name="hesabPay" 
                        type="tel"
                        placeholder="+93779494512"
                      />
                    </div>

                    <div>
                      <label className="block text-sm font-semibold mb-2 flex items-center gap-2">
                        <MessageCircle className="w-4 h-4 text-green-600" />
                        {t.easypaisa_label} ({t.optional})
                      </label>
                      <Input 
                        name="easypaisa" 
                        type="tel"
                        placeholder="+923001234567"
                      />
                    </div>

                    <div>
                      <label className="block text-sm font-semibold mb-2 flex items-center gap-2">
                        <CreditCard className="w-4 h-4 text-blue-600" />
                        {t.cardNumber_label} ({t.optional})
                      </label>
                      <Input 
                        name="cardNumber" 
                        placeholder="1234 5678 9012 3456"
                      />
                    </div>

                    <div>
                      <label className="block text-sm font-semibold mb-2 flex items-center gap-2">
                        <ExternalLink className="w-4 h-4 text-blue-600" />
                        {t.paypal_label} ({t.optional})
                      </label>
                      <Input 
                        name="paypal" 
                        placeholder="example@paypal.com"
                      />
                    </div>

                    <div>
                      <label className="block text-sm font-semibold mb-2 flex items-center gap-2">
                        <Building2 className="w-4 h-4 text-indigo-600" />
                        {t.bankAccount_label} ({t.optional})
                      </label>
                      <Input 
                        name="bankAccount" 
                        placeholder="1234567890"
                      />
                    </div>

                    <div>
                      <label className="block text-sm font-semibold mb-2 flex items-center gap-2">
                        <Building2 className="w-4 h-4 text-indigo-600" />
                        {t.bankName_label} ({t.optional})
                      </label>
                      <Input 
                        name="bankName" 
                        placeholder="Afghanistan Bank"
                      />
                    </div>
                  </div>
                </div>

                {/* Image Section */}
                <div className="bg-gradient-to-br from-amber-50 to-orange-50 rounded-2xl p-6">
                  <h3 className="font-semibold mb-4 flex items-center gap-2">
                    <ImageIcon className="w-5 h-5 text-amber-600" />
                    {t.image_label} ({t.optional})
                  </h3>
                  <Input 
                    name="image" 
                    type="url" 
                    placeholder="https://example.com/image.jpg"
                    onChange={(e) => setImagePreview(e.target.value)}
                    className={formErrors.image ? 'border-red-500' : ''}
                  />
                  {formErrors.image && <p className="text-xs text-red-500 mt-1">{formErrors.image}</p>}
                  <p className="text-xs text-gray-500 mt-1">{t.noImage}</p>
                  {imagePreview && imagePreview.startsWith('https://') && (
                    <div className="mt-3 rounded-xl overflow-hidden border">
                      <ImageWithFallback src={imagePreview} alt="Preview" className="w-full h-48 object-cover" />
                    </div>
                  )}
                </div>

                {/* Action Buttons */}
                <div className="flex gap-3 pt-4">
                  <Button
                    type="button"
                    variant="outline"
                    className="flex-1"
                    onClick={() => {
                      setShowCreateModal(false);
                      setFormErrors({});
                      setImagePreview('');
                    }}
                  >
                    {t.cancel}
                  </Button>
                  <Button
                    type="submit"
                    className="flex-1 bg-gradient-to-r from-pink-500 to-rose-600 text-white"
                  >
                    <CheckCircle className="w-5 h-5 mr-2" />
                    {t.submit}
                  </Button>
                </div>
              </form>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
