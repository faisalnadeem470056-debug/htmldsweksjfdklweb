import React from 'react';
import { Home, Grid3x3, Shield, Phone, Settings } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';
import { useAuth } from '../contexts/AuthContext';

interface BottomNavProps {
  currentPage: string;
  onNavigate: (page: any) => void;
}

export function BottomNav({ currentPage, onNavigate }: BottomNavProps) {
  const { t } = useLanguage();
  const { isAdmin } = useAuth();

  const navItems = [
    { id: 'home', icon: Home, label: t('home') },
    { id: 'categories', icon: Grid3x3, label: t('categories') },
    ...(isAdmin ? [{ id: 'admin', icon: Shield, label: t('admin') }] : []),
    { id: 'contact', icon: Phone, label: t('contact') },
    { id: 'settings', icon: Settings, label: t('settings') },
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-50">
      <div className="max-w-md mx-auto px-4 pb-4">
        <div className="backdrop-blur-xl bg-white/40 rounded-3xl border border-white/20 shadow-2xl">
          <div className="flex items-center justify-around px-2 py-3">
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = currentPage === item.id;
              
              return (
                <button
                  key={item.id}
                  onClick={() => onNavigate(item.id)}
                  className={`flex flex-col items-center gap-1 px-3 py-2 rounded-2xl transition-all ${
                    isActive 
                      ? 'bg-gradient-to-r from-emerald-500 to-blue-600 text-white shadow-lg scale-110' 
                      : 'text-gray-600 hover:bg-white/50'
                  }`}
                >
                  <Icon className={`w-5 h-5 ${isActive ? 'animate-bounce' : ''}`} />
                  <span className="text-xs font-medium">{item.label}</span>
                </button>
              );
            })}
          </div>
        </div>
      </div>
    </nav>
  );
}
