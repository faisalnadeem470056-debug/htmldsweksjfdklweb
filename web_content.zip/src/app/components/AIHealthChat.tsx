import { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Send, Bot, User, Crown, Lock, Sparkles, Trash2, Save, History, AlertCircle, Zap, MessageCircle, RefreshCw } from 'lucide-react';
import { Button } from './ui/button';
import { Textarea } from './ui/textarea';
import { ImageWithFallback } from './figma/ImageWithFallback';
import { PremiumBadge, PremiumContentLock } from './PremiumContentLock';
import { premiumManager } from '../utils/PremiumManager';
import { generateAIHealthResponse } from '../utils/AIResponseGenerator';

interface AIHealthChatProps {
  language: 'ps' | 'fa' | 'en';
  currentUserId: string;
  onNavigateToPremium: () => void;
  onBack: () => void;
}

interface Message {
  id: string;
  type: 'user' | 'ai';
  content: string;
  timestamp: number;
  isPremiumResponse?: boolean;
}

interface ChatSession {
  id: string;
  title: string;
  messages: Message[];
  timestamp: number;
}

const translations = {
  ps: {
    title: 'AI روغتیا چټ مرستیال',
    subtitle: 'د خپلو روغتیا پوښتنو ځوابونه ترلاسه کړئ',
    basicAI: '🤖 لومړنی AI',
    advancedAI: '👑 پرمختللی AI',
    typeMessage: 'خپله پوښتنه دلته ولیکئ...',
    send: 'واستوئ',
    thinking: 'فکر کوم...',
    newChat: 'نوی چټ',
    chatHistory: 'د چټ تاریخچه',
    clearHistory: 'تاریخچه پاکه کړئ',
    saveChat: 'چټ خوندي کړئ',
    noHistory: 'تاریخچه نشته',
    limitReached: 'د ورځې حد ته ورسیدلی',
    upgradeForMore: 'د نورو پوښتنو لپاره Premium ترلاسه کړئ',
    messagesLeft: 'پاتې پیغامونه',
    unlimited: 'نامحدود',
    premiumFeatures: 'Premium ځانګړتیاوې',
    feature1: 'نامحدود پوښتنې',
    feature2: 'پرمختللی AI ځوابونه',
    feature3: 'د چټ تاریخچه خوندي کول',
    feature4: 'د ډیټا تحلیل او سپارښتنې',
    feature5: 'لومړي ځواب ورکول',
    upgrade: 'Premium ته اپګریډ کړئ',
    disclaimer: '⚠️ یادونه: دا AI مرستیال یوازې عمومي معلومات ورکوي. د جدي روغتیا مسلو لپاره له خپل ډاکټر سره مشوره وکړئ.',
    exampleQuestions: 'د مثال پوښتنې:',
    example1: 'د سر درد د کمولو لپاره څه وکړم؟',
    example2: 'د زړه روغتیا څنګه ساتلی شم؟',
    example3: 'د وزن کمولو لپاره څه مشوره لرئ؟',
    back: 'بیرته',
    aiTyping: 'AI ټایپ کوي...',
  },
  fa: {
    title: 'دستیار چت سلامتی AI',
    subtitle: 'پاسخ سوالات سلامتی خود را دریافت کنید',
    basicAI: '🤖 AI پایه',
    advancedAI: '👑 AI پیشرفته',
    typeMessage: 'سوال خود را اینجا بنویسید...',
    send: 'ارسال',
    thinking: 'در حال فکر کردن...',
    newChat: 'چت جدید',
    chatHistory: 'تاریخچه چت',
    clearHistory: 'پاک کردن تاریخچه',
    saveChat: 'ذخیره چت',
    noHistory: 'تاریخچه ای وجود ندارد',
    limitReached: 'به حد روزانه رسیده',
    upgradeForMore: 'برای سوالات بیشتر پریمیوم دریافت کنید',
    messagesLeft: 'پیام‌های باقیمانده',
    unlimited: 'نامحدود',
    premiumFeatures: 'ویژگی‌های پریمیوم',
    feature1: 'سوالات نامحدود',
    feature2: 'پاسخ‌های AI پیشرفته',
    feature3: 'ذخیره تاریخچه چت',
    feature4: 'تحلیل داده و توصیه‌ها',
    feature5: 'پاسخ‌دهی اولویت‌دار',
    upgrade: 'ارتقا به پریمیوم',
    disclaimer: '⚠️ توجه: این دستیار AI فقط اطلاعات عمومی ارائه می‌دهد. برای مشکلات جدی سلامتی با پزشک خود مشورت کنید.',
    exampleQuestions: 'سوالات نمونه:',
    example1: 'برای کاهش سردرد چه کنم؟',
    example2: 'چگونه سلامت قلب را حفظ کنم؟',
    example3: 'چه توصیه‌ای برای کاهش وزن دارید؟',
    back: 'بازگشت',
    aiTyping: 'AI در حال تایپ...',
  },
  en: {
    title: 'AI Health Chat Assistant',
    subtitle: 'Get answers to your health questions',
    basicAI: '🤖 Basic AI',
    advancedAI: '👑 Advanced AI',
    typeMessage: 'Type your question here...',
    send: 'Send',
    thinking: 'Thinking...',
    newChat: 'New Chat',
    chatHistory: 'Chat History',
    clearHistory: 'Clear History',
    saveChat: 'Save Chat',
    noHistory: 'No History',
    limitReached: 'Daily Limit Reached',
    upgradeForMore: 'Upgrade to Premium for more questions',
    messagesLeft: 'Messages Left',
    unlimited: 'Unlimited',
    premiumFeatures: 'Premium Features',
    feature1: 'Unlimited Questions',
    feature2: 'Advanced AI Responses',
    feature3: 'Save Chat History',
    feature4: 'Data Analysis & Recommendations',
    feature5: 'Priority Response',
    upgrade: 'Upgrade to Premium',
    disclaimer: '⚠️ Disclaimer: This AI assistant provides general information only. For serious health issues, consult your doctor.',
    exampleQuestions: 'Example Questions:',
    example1: 'What to do for headache relief?',
    example2: 'How to maintain heart health?',
    example3: 'What advice for weight loss?',
    back: 'Back',
    aiTyping: 'AI is typing...',
  },
};

// د AI responses database (د demo لپاره)
const aiResponses = {
  ps: {
    basic: [
      'د روغتیا په اړه ستاسو پوښتنې ته مننه! زه د لومړني معلوماتو ورکولو هڅه کوم.',
      'د دې مسلې په اړه، زه وړاندیز کوم چې د عمومي روغتیا اصولو پیروي وکړئ.',
      'دا یوه ښه پوښتنه ده. د نورو تفصیلي ځوابونو لپاره، زموږ Premium AI استعمال کړئ.',
    ],
    premium: [
      '🩺 بشپړ تحلیل: د ستاسو پوښتنې په اساس، دلته یو بشپړ لارښود دی...',
      '👨‍⚕️ مسلکي مشوره: د ستاسو د حالت په نظر کې نیولو سره، دلته زما وړاندیزونه دي...',
      '📊 د ډیټا تحلیل: د ستاسو د معلوماتو په اساس، دا د غوره حل لارې دي...',
    ],
  },
  fa: {
    basic: [
      'متشکرم از سوال سلامتی شما! من سعی می‌کنم اطلاعات پایه را ارائه دهم.',
      'در مورد این مشکل، توصیه می‌کنم از اصول عمومی سلامت پیروی کنید.',
      'این سوال خوبی است. برای پاسخ‌های دقیق‌تر، از AI پریمیوم ما استفاده کنید.',
    ],
    premium: [
      '🩺 تحلیل کامل: بر اساس سوال شما، اینجا یک راهنمای جامع است...',
      '👨‍⚕️ مشاوره حرفه‌ای: با توجه به وضعیت شما، اینجا توصیه‌های من است...',
      '📊 تحلیل داده: بر اساس اطلاعات شما، اینها بهترین راه‌حل‌ها هستند...',
    ],
  },
  en: {
    basic: [
      'Thank you for your health question! I\'ll try to provide basic information.',
      'Regarding this issue, I recommend following general health principles.',
      'That\'s a good question. For more detailed answers, use our Premium AI.',
    ],
    premium: [
      '🩺 Complete Analysis: Based on your question, here\'s a comprehensive guide...',
      '👨‍⚕️ Professional Advice: Considering your situation, here are my recommendations...',
      '📊 Data Analysis: Based on your information, these are the best solutions...',
    ],
  },
};

export function AIHealthChat({ language, currentUserId, onNavigateToPremium, onBack }: AIHealthChatProps) {
  const [messages, setMessages] = useState<Message[]>([]);
  const [inputMessage, setInputMessage] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [chatSessions, setChatSessions] = useState<ChatSession[]>([]);
  const [currentSessionId, setCurrentSessionId] = useState<string>('');
  const [showHistory, setShowHistory] = useState(false);
  const [dailyMessageCount, setDailyMessageCount] = useState(0);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const t = translations[language];
  const isPremium = premiumManager.isPremium(currentUserId);

  // د Free users لپاره daily limit
  const FREE_DAILY_LIMIT = 10;
  const messagesRemaining = isPremium ? Infinity : FREE_DAILY_LIMIT - dailyMessageCount;

  // Auto-scroll to bottom
  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  // Load chat history from localStorage
  useEffect(() => {
    if (isPremium) {
      const savedSessions = localStorage.getItem(`healmate_chat_history_${currentUserId}`);
      if (savedSessions) {
        setChatSessions(JSON.parse(savedSessions));
      }
    }

    // Load daily message count
    const today = new Date().toDateString();
    const savedDate = localStorage.getItem(`healmate_chat_date_${currentUserId}`);
    const savedCount = localStorage.getItem(`healmate_chat_count_${currentUserId}`);

    if (savedDate === today && savedCount) {
      setDailyMessageCount(parseInt(savedCount));
    } else {
      // نوې ورځ - reset count
      localStorage.setItem(`healmate_chat_date_${currentUserId}`, today);
      localStorage.setItem(`healmate_chat_count_${currentUserId}`, '0');
      setDailyMessageCount(0);
    }

    // د welcome message
    if (messages.length === 0) {
      const welcomeMessage: Message = {
        id: 'welcome',
        type: 'ai',
        content: language === 'ps' 
          ? `سلام! زه ستاسو د AI روغتیا مرستیال یم. زه ${isPremium ? 'پرمختللی' : 'لومړنی'} AI یم او ستاسو د روغتیا پوښتنو ته ځواب ورکوم. څنګه مرسته کولی شم؟`
          : language === 'fa'
          ? `سلام! من دستیار سلامتی AI شما هستم. من یک AI ${isPremium ? 'پیشرفته' : 'پایه'} هستم و به سوالات سلامتی شما پاسخ می‌دهم. چگونه می‌توانم کمک کنم؟`
          : `Hello! I'm your AI Health Assistant. I'm ${isPremium ? 'an Advanced' : 'a Basic'} AI and I answer your health questions. How can I help?`,
        timestamp: Date.now(),
      };
      setMessages([welcomeMessage]);
    }
  }, []);

  // Save chat history (Premium only)
  const saveChatHistory = () => {
    if (!isPremium || messages.length <= 1) return;

    const session: ChatSession = {
      id: currentSessionId || `session_${Date.now()}`,
      title: messages[1]?.content.substring(0, 50) || 'New Chat',
      messages: messages,
      timestamp: Date.now(),
    };

    const updatedSessions = [session, ...chatSessions.filter(s => s.id !== session.id)];
    setChatSessions(updatedSessions);
    localStorage.setItem(`healmate_chat_history_${currentUserId}`, JSON.stringify(updatedSessions));
    setCurrentSessionId(session.id);
  };

  // Load chat session
  const loadChatSession = (session: ChatSession) => {
    setMessages(session.messages);
    setCurrentSessionId(session.id);
    setShowHistory(false);
  };

  // Clear history
  const clearHistory = () => {
    if (confirm(language === 'ps' ? 'ایا تاسو غواړئ د چټ تاریخچه پاکه کړئ؟' : 
                language === 'fa' ? 'آیا می‌خواهید تاریخچه چت را پاک کنید؟' : 
                'Do you want to clear chat history?')) {
      setChatSessions([]);
      localStorage.removeItem(`healmate_chat_history_${currentUserId}`);
    }
  };

  // New chat
  const startNewChat = () => {
    if (messages.length > 1) {
      saveChatHistory();
    }
    setMessages([{
      id: 'welcome_new',
      type: 'ai',
      content: language === 'ps' 
        ? 'سلام! نوی چټ پیل شو. څنګه مرسته کولی شم؟'
        : language === 'fa'
        ? 'سلام! چت جدید شروع شد. چگونه می‌توانم کمک کنم؟'
        : 'Hello! New chat started. How can I help?',
      timestamp: Date.now(),
    }]);
    setCurrentSessionId('');
  };

  // Send message
  const handleSendMessage = async () => {
    if (!inputMessage.trim()) return;

    // Check daily limit for free users
    if (!isPremium && dailyMessageCount >= FREE_DAILY_LIMIT) {
      alert(t.limitReached + '\n' + t.upgradeForMore);
      return;
    }

    // Add user message
    const userMessage: Message = {
      id: `user_${Date.now()}`,
      type: 'user',
      content: inputMessage,
      timestamp: Date.now(),
    };

    setMessages(prev => [...prev, userMessage]);
    setInputMessage('');
    setIsTyping(true);

    // Update daily count
    const newCount = dailyMessageCount + 1;
    setDailyMessageCount(newCount);
    localStorage.setItem(`healmate_chat_count_${currentUserId}`, newCount.toString());

    // Simulate AI response
    setTimeout(() => {
      const aiMessage: Message = {
        id: `ai_${Date.now()}`,
        type: 'ai',
        content: generateAIHealthResponse(inputMessage, isPremium, language),
        timestamp: Date.now(),
        isPremiumResponse: isPremium,
      };

      setMessages(prev => [...prev, aiMessage]);
      setIsTyping(false);

      // Auto-save for premium users
      if (isPremium) {
        setTimeout(() => saveChatHistory(), 1000);
      }
    }, 2000 + Math.random() * 1000);
  };

  // Generate AI response (د demo لپاره)
  const generateAIResponse = (question: string, premium: boolean, lang: 'ps' | 'fa' | 'en'): string => {
    const responses = aiResponses[lang];
    const responseArray = premium ? responses.premium : responses.basic;
    
    // د simple keyword matching
    const keywords = question.toLowerCase();
    
    if (keywords.includes('headache') || keywords.includes('سردرد') || keywords.includes('سر درد')) {
      return premium 
        ? (lang === 'ps' 
          ? '🩺 د سر درد لپاره بشپړ لارښود:\n\n1. د اوبو کمښت: په ورځ کې لږترلږه 8 ګیلاس اوبه وڅښئ\n2. د خوب کیفیت: 7-8 ساعته خوب ضروري دی\n3. د فشار مدیریت: د یوګا یا مراقبت تمرینونه وکړئ\n4. د غذا تنظیم: د کیفین او الکول کمول\n5. د منظم معاینې: که سردرد دوام وکړي، له ډاکټر سره مشوره وکړئ\n\n⚠️ که سردرد شدید وي یا د نورو علایمو سره، سمدستي طبي مرسته ترلاسه کړئ.'
          : lang === 'fa'
          ? '🩺 راهنمای کامل برای سردرد:\n\n1. کم‌آبی: حداقل 8 لیوان آب در روز بنوشید\n2. کیفیت خواب: 7-8 ساعت خواب ضروری است\n3. مدیریت استرس: تمرینات یوگا یا مدیتیشن انجام دهید\n4. تنظیم غذا: کاهش کافئین و الکل\n5. معاینات منظم: اگر سردرد ادامه یابد، با پزشک مشورت کنید\n\n⚠️ اگر سردرد شدید یا با علایم دیگر باشد، فوراً کمک پزشکی دریافت کنید.'
          : '🩺 Complete Guide for Headache:\n\n1. Dehydration: Drink at least 8 glasses of water daily\n2. Sleep Quality: 7-8 hours sleep is essential\n3. Stress Management: Do yoga or meditation exercises\n4. Diet Regulation: Reduce caffeine and alcohol\n5. Regular Checkups: If headache persists, consult a doctor\n\n⚠️ If headache is severe or with other symptoms, seek immediate medical help.')
        : (lang === 'ps'
          ? 'د سر درد لپاره: اوبه وڅښئ، استراحت وکړئ، او که دوام وکړي له ډاکټر سره مشوره وکړئ. د نورو تفصیلي مشورو لپاره Premium استعمال کړئ.'
          : lang === 'fa'
          ? 'برای سردرد: آب بنوشید، استراحت کنید و اگر ادامه یافت با پزشک مشورت کنید. برای مشاوره دقیق‌تر از پریمیوم استفاده کنید.'
          : 'For headache: Drink water, rest, and if it persists consult a doctor. For detailed advice use Premium.');
    }
    
    if (keywords.includes('heart') || keywords.includes('زړه') || keywords.includes('قلب')) {
      return premium
        ? (lang === 'ps'
          ? '❤️ د زړه روغتیا ساتلو بشپړ پلان:\n\n1. د غذا: د تازه میوو، سابه، او بشپړو غلو دانو استعمال\n2. ورزش: په ورځ کې 30 منټه پیاده روی یا نور فعالیتونه\n3. د تنباکو څخه ډډه: سګرټ نوشي د زړه لپاره خطرناک دی\n4. د وزن کنټرول: صحي وزن ساتل ډیر مهم دی\n5. د فشار خون څارنه: منظم معاینې ضروري دي\n6. د شکر کنټرول: که ډایبیټس لرئ، دقیق مدیریت ضروري دی\n\n📊 د سپارښتنو: هره 6 میاشتې د زړه معاینه وکړئ.'
          : lang === 'fa'
          ? '❤️ برنامه کامل حفظ سلامت قلب:\n\n1. رژیم غذایی: استفاده از میوه‌ها، سبزیجات و غلات کامل\n2. ورزش: 30 دقیقه پیاده‌روی یا فعالیت روزانه\n3. ترک دخانیات: سیگار کشیدن برای قلب خطرناک است\n4. کنترل وزن: حفظ وزن سالم بسیار مهم است\n5. نظارت فشار خون: معاینات منظم ضروری\n6. کنترل قند: اگر دیابت دارید، مدیریت دقیق لازم است\n\n📊 توصیه: هر 6 ماه معاینه قلب انجام دهید.'
          : '❤️ Complete Heart Health Plan:\n\n1. Diet: Use fresh fruits, vegetables, and whole grains\n2. Exercise: 30 minutes walking or activity daily\n3. Quit Tobacco: Smoking is dangerous for heart\n4. Weight Control: Maintaining healthy weight is very important\n5. Blood Pressure Monitoring: Regular checkups essential\n6. Sugar Control: If diabetic, precise management needed\n\n📊 Recommendation: Heart checkup every 6 months.')
        : responseArray[Math.floor(Math.random() * responseArray.length)];
    }

    // Default response
    return responseArray[Math.floor(Math.random() * responseArray.length)];
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50 pb-20">
      {/* Header */}
      <div className="sticky top-0 z-30 bg-white/80 backdrop-blur-xl border-b border-gray-200 shadow-lg">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Button variant="ghost" size="icon" onClick={onBack}>
                <motion.div whileHover={{ x: -5 }}>←</motion.div>
              </Button>
              <div>
                <div className="flex items-center gap-2">
                  <h1 className="text-xl font-bold">{t.title}</h1>
                  {isPremium ? (
                    <PremiumBadge language={language} size="sm" />
                  ) : (
                    <span className="text-xs bg-gray-100 px-2 py-1 rounded-full">Basic</span>
                  )}
                </div>
                <p className="text-xs text-gray-600">{t.subtitle}</p>
              </div>
            </div>

            <div className="flex items-center gap-2">
              {isPremium && (
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => setShowHistory(!showHistory)}
                  className="relative"
                >
                  <History className="w-5 h-5" />
                  {chatSessions.length > 0 && (
                    <span className="absolute -top-1 -right-1 bg-red-500 text-white text-xs w-4 h-4 rounded-full flex items-center justify-center">
                      {chatSessions.length}
                    </span>
                  )}
                </Button>
              )}
              <Button
                variant="ghost"
                size="icon"
                onClick={startNewChat}
              >
                <RefreshCw className="w-5 h-5" />
              </Button>
            </div>
          </div>

          {/* Status Bar */}
          <div className="mt-3 flex items-center justify-between text-sm">
            <div className="flex items-center gap-2">
              <div className={`w-2 h-2 rounded-full ${isPremium ? 'bg-green-500' : 'bg-blue-500'} animate-pulse`} />
              <span className="text-gray-600">
                {isPremium ? t.advancedAI : t.basicAI}
              </span>
            </div>
            
            <div className="flex items-center gap-2">
              {!isPremium ? (
                <>
                  <span className="text-gray-600">{t.messagesLeft}:</span>
                  <span className={`font-bold ${messagesRemaining <= 3 ? 'text-red-600' : 'text-green-600'}`}>
                    {messagesRemaining}/{FREE_DAILY_LIMIT}
                  </span>
                  {messagesRemaining <= 3 && (
                    <Button
                      size="sm"
                      onClick={onNavigateToPremium}
                      className="bg-gradient-to-r from-yellow-400 to-orange-500 text-white"
                    >
                      <Crown className="w-3 h-3 mr-1" />
                      {t.upgrade}
                    </Button>
                  )}
                </>
              ) : (
                <span className="text-green-600 font-bold flex items-center gap-1">
                  <Zap className="w-4 h-4" />
                  {t.unlimited}
                </span>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Chat History Sidebar */}
      <AnimatePresence>
        {showHistory && isPremium && (
          <motion.div
            initial={{ x: '100%' }}
            animate={{ x: 0 }}
            exit={{ x: '100%' }}
            className="fixed right-0 top-20 bottom-20 w-80 bg-white shadow-2xl z-40 overflow-y-auto"
          >
            <div className="p-4">
              <div className="flex items-center justify-between mb-4">
                <h3 className="font-bold">{t.chatHistory}</h3>
                <Button variant="ghost" size="sm" onClick={clearHistory}>
                  <Trash2 className="w-4 h-4 text-red-600" />
                </Button>
              </div>

              {chatSessions.length === 0 ? (
                <p className="text-center text-gray-500 text-sm mt-8">{t.noHistory}</p>
              ) : (
                <div className="space-y-2">
                  {chatSessions.map((session) => (
                    <motion.div
                      key={session.id}
                      whileHover={{ scale: 1.02 }}
                      onClick={() => loadChatSession(session)}
                      className="bg-gray-50 rounded-xl p-3 cursor-pointer hover:bg-gray-100 transition-all border border-gray-200"
                    >
                      <p className="text-sm font-medium mb-1 truncate">{session.title}</p>
                      <div className="flex items-center justify-between text-xs text-gray-500">
                        <span>{session.messages.length} messages</span>
                        <span>{new Date(session.timestamp).toLocaleDateString()}</span>
                      </div>
                    </motion.div>
                  ))}
                </div>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Main Chat Container */}
      <div className="container mx-auto px-4 py-6 max-w-4xl">
        {/* Messages */}
        <div className="space-y-4 mb-32">
          <AnimatePresence>
            {messages.map((message, index) => (
              <motion.div
                key={message.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.05 }}
                className={`flex gap-3 ${message.type === 'user' ? 'flex-row-reverse' : 'flex-row'}`}
              >
                {/* Avatar */}
                <div className={`w-10 h-10 rounded-full flex-shrink-0 flex items-center justify-center ${
                  message.type === 'user'
                    ? 'bg-gradient-to-br from-blue-500 to-purple-600'
                    : message.isPremiumResponse
                    ? 'bg-gradient-to-br from-yellow-400 to-orange-500'
                    : 'bg-gradient-to-br from-gray-400 to-gray-600'
                }`}>
                  {message.type === 'user' ? (
                    <User className="w-5 h-5 text-white" />
                  ) : (
                    <Bot className="w-5 h-5 text-white" />
                  )}
                </div>

                {/* Message Bubble */}
                <div className={`flex-1 max-w-[80%] ${message.type === 'user' ? 'text-right' : 'text-left'}`}>
                  <div className={`inline-block rounded-3xl px-6 py-3 ${
                    message.type === 'user'
                      ? 'bg-gradient-to-br from-blue-500 to-purple-600 text-white'
                      : message.isPremiumResponse
                      ? 'bg-gradient-to-br from-yellow-50 to-orange-50 border-2 border-yellow-200'
                      : 'bg-white border border-gray-200'
                  }`}>
                    {message.isPremiumResponse && (
                      <div className="flex items-center gap-1 mb-2">
                        <Crown className="w-4 h-4 text-orange-500" />
                        <span className="text-xs font-bold text-orange-600">Premium Response</span>
                      </div>
                    )}
                    <p className="whitespace-pre-wrap text-sm" dir={language === 'en' ? 'ltr' : 'rtl'}>
                      {message.content}
                    </p>
                  </div>
                  <p className="text-xs text-gray-500 mt-1 px-2">
                    {new Date(message.timestamp).toLocaleTimeString()}
                  </p>
                </div>
              </motion.div>
            ))}
          </AnimatePresence>

          {/* AI Typing Indicator */}
          {isTyping && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="flex gap-3"
            >
              <div className={`w-10 h-10 rounded-full flex-shrink-0 flex items-center justify-center ${
                isPremium
                  ? 'bg-gradient-to-br from-yellow-400 to-orange-500'
                  : 'bg-gradient-to-br from-gray-400 to-gray-600'
              }`}>
                <Bot className="w-5 h-5 text-white" />
              </div>
              <div className="bg-white border border-gray-200 rounded-3xl px-6 py-3">
                <div className="flex gap-2">
                  <motion.div
                    animate={{ scale: [1, 1.2, 1] }}
                    transition={{ repeat: Infinity, duration: 0.8, delay: 0 }}
                    className="w-2 h-2 bg-gray-400 rounded-full"
                  />
                  <motion.div
                    animate={{ scale: [1, 1.2, 1] }}
                    transition={{ repeat: Infinity, duration: 0.8, delay: 0.2 }}
                    className="w-2 h-2 bg-gray-400 rounded-full"
                  />
                  <motion.div
                    animate={{ scale: [1, 1.2, 1] }}
                    transition={{ repeat: Infinity, duration: 0.8, delay: 0.4 }}
                    className="w-2 h-2 bg-gray-400 rounded-full"
                  />
                </div>
              </div>
            </motion.div>
          )}

          <div ref={messagesEndRef} />
        </div>

        {/* Example Questions (د empty state لپاره) */}
        {messages.length <= 1 && (
          <div className="mb-32">
            <h3 className="text-center text-sm text-gray-600 mb-4">{t.exampleQuestions}</h3>
            <div className="grid grid-cols-1 gap-3">
              {[t.example1, t.example2, t.example3].map((example, index) => (
                <motion.button
                  key={index}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.1 * index }}
                  onClick={() => setInputMessage(example)}
                  className="bg-white border-2 border-gray-200 rounded-2xl p-4 text-sm hover:border-blue-400 hover:shadow-lg transition-all text-left"
                  dir={language === 'en' ? 'ltr' : 'rtl'}
                >
                  <MessageCircle className="w-4 h-4 text-blue-500 mb-2" />
                  {example}
                </motion.button>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Fixed Input Area */}
      <div className="fixed bottom-20 left-0 right-0 bg-white/80 backdrop-blur-xl border-t border-gray-200 shadow-lg">
        <div className="container mx-auto px-4 py-4 max-w-4xl">
          {/* Input Form */}
          <div className="flex gap-3">
            <Textarea
              value={inputMessage}
              onChange={(e) => setInputMessage(e.target.value)}
              onKeyPress={(e) => {
                if (e.key === 'Enter' && !e.shiftKey) {
                  e.preventDefault();
                  handleSendMessage();
                }
              }}
              placeholder={t.typeMessage}
              disabled={!isPremium && dailyMessageCount >= FREE_DAILY_LIMIT}
              className="flex-1 min-h-[60px] max-h-[120px] resize-none rounded-2xl border-2 border-gray-200 focus:border-blue-400 transition-all"
              dir={language === 'en' ? 'ltr' : 'rtl'}
            />
            <Button
              onClick={handleSendMessage}
              disabled={!inputMessage.trim() || isTyping || (!isPremium && dailyMessageCount >= FREE_DAILY_LIMIT)}
              className="bg-gradient-to-r from-blue-500 to-purple-600 text-white px-8 rounded-2xl hover:shadow-xl transition-all flex items-center gap-2 min-w-[100px] h-[60px]"
            >
              <Send className="w-5 h-5" />
              <span className="font-medium">{t.send}</span>
            </Button>
          </div>

          {/* Premium Upsell (د free users لپاره) */}
          {!isPremium && messagesRemaining <= 5 && (
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className="mt-3 bg-gradient-to-r from-yellow-50 to-orange-50 border-2 border-yellow-300 rounded-2xl p-4"
            >
              <div className="flex items-start justify-between gap-3">
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-2">
                    <Crown className="w-5 h-5 text-orange-500" />
                    <p className="font-bold text-orange-700">{t.premiumFeatures}</p>
                  </div>
                  <ul className="text-xs text-gray-700 space-y-1">
                    <li>✓ {t.feature1}</li>
                    <li>✓ {t.feature2}</li>
                    <li>✓ {t.feature3}</li>
                  </ul>
                </div>
                <Button
                  onClick={onNavigateToPremium}
                  size="sm"
                  className="bg-gradient-to-r from-yellow-400 via-orange-500 to-pink-600 text-white"
                >
                  <Sparkles className="w-4 h-4 mr-1" />
                  {t.upgrade}
                </Button>
              </div>
            </motion.div>
          )}
        </div>
      </div>
    </div>
  );
}