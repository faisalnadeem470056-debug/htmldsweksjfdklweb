/**
 * Simple Label Component - بغیر external dependencies
 */

import { forwardRef } from 'react';

interface LabelProps extends React.LabelHTMLAttributes<HTMLLabelElement> {}

export const SimpleLabel = forwardRef<HTMLLabelElement, LabelProps>(
  ({ className = '', children, ...props }, ref) => {
    return (
      <label
        ref={ref}
        className={`
          text-sm font-medium text-gray-700
          block mb-2
          ${className}
        `}
        {...props}
      >
        {children}
      </label>
    );
  }
);

SimpleLabel.displayName = 'SimpleLabel';
