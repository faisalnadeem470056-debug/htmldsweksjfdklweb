import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";
import { Input } from "./ui/input";
import { Textarea } from "./ui/textarea";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "./ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs";
import { 
  Calendar as CalendarIcon,
  TrendingUp,
  TrendingDown,
  Activity,
  Thermometer,
  Heart,
  Brain,
  Droplet,
  Smile,
  Frown,
  Meh,
  AlertCircle,
  FileText,
  Download,
  Plus,
  Edit,
  Trash2,
  BarChart3,
  LineChart,
  Sparkles,
  Clock,
  CheckCircle,
  ArrowRight
} from "lucide-react";
import { Separator } from "./ui/separator";
import { Progress } from "./ui/progress";
import { Slider } from "./ui/slider";
import { ScrollArea } from "./ui/scroll-area";

interface SymptomEntry {
  id: number;
  date: string;
  time: string;
  temperature: number;
  painLevel: number;
  bloodPressureSystolic: number;
  bloodPressureDiastolic: number;
  mood: "happy" | "neutral" | "sad";
  notes?: string;
}

interface HealthMetric {
  name: string;
  nameDari: string;
  icon: any;
  value: number;
  unit: string;
  trend: "up" | "down" | "stable";
  trendValue: number;
  status: "normal" | "warning" | "danger";
  color: string;
}

const mockSymptomEntries: SymptomEntry[] = [
  {
    id: 1,
    date: "2025-11-15",
    time: "08:00 AM",
    temperature: 98.6,
    painLevel: 2,
    bloodPressureSystolic: 120,
    bloodPressureDiastolic: 80,
    mood: "happy",
    notes: "Feeling good today, had a good night's sleep"
  },
  {
    id: 2,
    date: "2025-11-15",
    time: "02:00 PM",
    temperature: 99.1,
    painLevel: 3,
    bloodPressureSystolic: 125,
    bloodPressureDiastolic: 82,
    mood: "neutral",
    notes: "Slight headache after lunch"
  },
  {
    id: 3,
    date: "2025-11-14",
    time: "09:00 AM",
    temperature: 98.4,
    painLevel: 1,
    bloodPressureSystolic: 118,
    bloodPressureDiastolic: 78,
    mood: "happy",
    notes: "Morning walk completed, feeling energetic"
  },
  {
    id: 4,
    date: "2025-11-14",
    time: "08:00 PM",
    temperature: 98.8,
    painLevel: 4,
    bloodPressureSystolic: 130,
    bloodPressureDiastolic: 85,
    mood: "sad",
    notes: "Tired and stressed from work"
  },
  {
    id: 5,
    date: "2025-11-13",
    time: "10:00 AM",
    temperature: 99.5,
    painLevel: 5,
    bloodPressureSystolic: 135,
    bloodPressureDiastolic: 88,
    mood: "sad",
    notes: "Not feeling well, body aches"
  },
  {
    id: 6,
    date: "2025-11-13",
    time: "06:00 PM",
    temperature: 100.2,
    painLevel: 6,
    bloodPressureSystolic: 138,
    bloodPressureDiastolic: 90,
    mood: "sad",
    notes: "Fever increased, took paracetamol"
  },
  {
    id: 7,
    date: "2025-11-12",
    time: "08:30 AM",
    temperature: 98.7,
    painLevel: 2,
    bloodPressureSystolic: 122,
    bloodPressureDiastolic: 80,
    mood: "happy",
    notes: "Normal day, no issues"
  }
];

function SymptomsTracker() {
  const [activeTab, setActiveTab] = useState("log");
  const [entries, setEntries] = useState<SymptomEntry[]>(mockSymptomEntries);
  const [addModalOpen, setAddModalOpen] = useState(false);
  const [reportModalOpen, setReportModalOpen] = useState(false);
  
  // Form state
  const [temperature, setTemperature] = useState(98.6);
  const [painLevel, setPainLevel] = useState(0);
  const [bpSystolic, setBpSystolic] = useState(120);
  const [bpDiastolic, setBpDiastolic] = useState(80);
  const [mood, setMood] = useState<"happy" | "neutral" | "sad">("neutral");
  const [notes, setNotes] = useState("");

  // Calculate metrics
  const latestEntry = entries[0];
  const avgTemperature = entries.reduce((sum, e) => sum + e.temperature, 0) / entries.length;
  const avgPainLevel = entries.reduce((sum, e) => sum + e.painLevel, 0) / entries.length;
  const avgBpSystolic = entries.reduce((sum, e) => sum + e.bloodPressureSystolic, 0) / entries.length;
  const avgBpDiastolic = entries.reduce((sum, e) => sum + e.bloodPressureDiastolic, 0) / entries.length;

  const healthMetrics: HealthMetric[] = [
    {
      name: "Temperature",
      nameDari: "تودوخه",
      icon: Thermometer,
      value: latestEntry.temperature,
      unit: "°F",
      trend: latestEntry.temperature > avgTemperature ? "up" : "down",
      trendValue: Math.abs(latestEntry.temperature - avgTemperature),
      status: latestEntry.temperature > 100 ? "danger" : latestEntry.temperature > 99 ? "warning" : "normal",
      color: "from-red-500 to-orange-500"
    },
    {
      name: "Pain Level",
      nameDari: "د درد کچه",
      icon: Activity,
      value: latestEntry.painLevel,
      unit: "/10",
      trend: latestEntry.painLevel > avgPainLevel ? "up" : "down",
      trendValue: Math.abs(latestEntry.painLevel - avgPainLevel),
      status: latestEntry.painLevel > 6 ? "danger" : latestEntry.painLevel > 3 ? "warning" : "normal",
      color: "from-purple-500 to-pink-500"
    },
    {
      name: "Blood Pressure",
      nameDari: "د وینې فشار",
      icon: Heart,
      value: latestEntry.bloodPressureSystolic,
      unit: `/${latestEntry.bloodPressureDiastolic}`,
      trend: latestEntry.bloodPressureSystolic > avgBpSystolic ? "up" : "down",
      trendValue: Math.abs(latestEntry.bloodPressureSystolic - avgBpSystolic),
      status: latestEntry.bloodPressureSystolic > 140 || latestEntry.bloodPressureDiastolic > 90 ? "danger" : 
              latestEntry.bloodPressureSystolic > 130 || latestEntry.bloodPressureDiastolic > 85 ? "warning" : "normal",
      color: "from-blue-500 to-cyan-500"
    },
    {
      name: "Mood",
      nameDari: "مزاج",
      icon: latestEntry.mood === "happy" ? Smile : latestEntry.mood === "sad" ? Frown : Meh,
      value: latestEntry.mood === "happy" ? 100 : latestEntry.mood === "neutral" ? 50 : 0,
      unit: "%",
      trend: "stable",
      trendValue: 0,
      status: latestEntry.mood === "happy" ? "normal" : latestEntry.mood === "neutral" ? "warning" : "danger",
      color: "from-green-500 to-emerald-500"
    }
  ];

  const handleAddEntry = () => {
    const newEntry: SymptomEntry = {
      id: entries.length + 1,
      date: new Date().toISOString().split('T')[0],
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      temperature,
      painLevel,
      bloodPressureSystolic: bpSystolic,
      bloodPressureDiastolic: bpDiastolic,
      mood,
      notes
    };

    setEntries([newEntry, ...entries]);
    setAddModalOpen(false);
    
    // Reset form
    setTemperature(98.6);
    setPainLevel(0);
    setBpSystolic(120);
    setBpDiastolic(80);
    setMood("neutral");
    setNotes("");
  };

  const getPainLevelColor = (level: number) => {
    if (level <= 3) return "text-green-600 bg-green-100";
    if (level <= 6) return "text-yellow-600 bg-yellow-100";
    return "text-red-600 bg-red-100";
  };

  const getMoodIcon = (moodType: "happy" | "neutral" | "sad") => {
    switch (moodType) {
      case "happy":
        return <Smile className="w-5 h-5 text-green-600" />;
      case "neutral":
        return <Meh className="w-5 h-5 text-yellow-600" />;
      case "sad":
        return <Frown className="w-5 h-5 text-red-600" />;
    }
  };

  return (
    <section className="py-16 md:py-24 bg-gradient-to-b from-white via-purple-50/30 to-white relative overflow-hidden min-h-screen">
      {/* Background decoration */}
      <div className="absolute top-0 left-0 w-[500px] h-[500px] bg-gradient-to-br from-purple-100/50 to-pink-100/50 rounded-full blur-3xl animate-float"></div>
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        {/* Header */}
        <div className="text-center mb-12 md:mb-16 space-y-4">
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-purple-100 to-pink-100 rounded-full">
            <Sparkles className="w-4 h-4 text-purple-600 animate-pulse-glow" />
            <span className="text-purple-700 text-sm uppercase tracking-wider">Health Tracker</span>
          </div>
          <h2 className="text-4xl md:text-6xl">
            <span className="bg-gradient-to-r from-purple-600 via-pink-600 to-red-600 bg-clip-text text-transparent">
              Symptoms Tracker
            </span>
          </h2>
          <p className="text-gray-600 max-w-2xl mx-auto text-lg">
            د علایمو ټریکر - Track your daily health symptoms and generate reports
          </p>
        </div>

        {/* Quick Metrics */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
          {healthMetrics.map((metric, index) => {
            const Icon = metric.icon;
            return (
              <Card
                key={index}
                className="hover-lift border-0 shadow-lg overflow-hidden"
                style={{ animationDelay: `${index * 50}ms` }}
              >
                <div className={`h-2 bg-gradient-to-r ${metric.color}`}></div>
                <CardContent className="p-6">
                  <div className="flex items-start justify-between mb-4">
                    <div className={`p-3 bg-gradient-to-br ${metric.color} rounded-xl`}>
                      <Icon className="w-6 h-6 text-white" />
                    </div>
                    <Badge className={
                      metric.status === "normal" ? "bg-green-100 text-green-700" :
                      metric.status === "warning" ? "bg-yellow-100 text-yellow-700" :
                      "bg-red-100 text-red-700"
                    }>
                      {metric.status === "normal" && <CheckCircle className="w-3 h-3 mr-1" />}
                      {metric.status === "warning" && <AlertCircle className="w-3 h-3 mr-1" />}
                      {metric.status === "danger" && <AlertCircle className="w-3 h-3 mr-1" />}
                      {metric.status.toUpperCase()}
                    </Badge>
                  </div>
                  
                  <h3 className="text-sm text-gray-600 mb-1">{metric.name}</h3>
                  <p className="text-xs text-purple-600 mb-3">{metric.nameDari}</p>
                  
                  <div className="flex items-baseline gap-2 mb-2">
                    <span className="text-3xl text-gray-900">{metric.value}</span>
                    <span className="text-gray-600">{metric.unit}</span>
                  </div>

                  {metric.trend !== "stable" && (
                    <div className={`flex items-center gap-1 text-sm ${
                      metric.trend === "up" ? "text-red-600" : "text-green-600"
                    }`}>
                      {metric.trend === "up" ? (
                        <TrendingUp className="w-4 h-4" />
                      ) : (
                        <TrendingDown className="w-4 h-4" />
                      )}
                      <span>{metric.trendValue.toFixed(1)} vs avg</span>
                    </div>
                  )}
                </CardContent>
              </Card>
            );
          })}
        </div>

        {/* Main Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-3 mb-8">
            <TabsTrigger value="log" className="flex items-center gap-2">
              <Activity className="w-4 h-4" />
              <span className="hidden md:inline">Daily Log</span>
            </TabsTrigger>
            <TabsTrigger value="history" className="flex items-center gap-2">
              <Clock className="w-4 h-4" />
              <span className="hidden md:inline">History</span>
            </TabsTrigger>
            <TabsTrigger value="reports" className="flex items-center gap-2">
              <BarChart3 className="w-4 h-4" />
              <span className="hidden md:inline">Reports</span>
            </TabsTrigger>
          </TabsList>

          {/* Daily Log Tab */}
          <TabsContent value="log" className="space-y-6">
            <div className="flex justify-between items-center">
              <h3 className="text-2xl">Today's Entries - د نن ننوتنې</h3>
              <Button 
                className="bg-gradient-to-r from-purple-500 to-pink-600 hover:from-purple-600 hover:to-pink-700"
                onClick={() => setAddModalOpen(true)}
              >
                <Plus className="w-4 h-4 mr-2" />
                Add Entry
              </Button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {entries.filter(e => e.date === new Date().toISOString().split('T')[0]).map((entry, index) => (
                <Card
                  key={entry.id}
                  className="hover-lift border-0 shadow-lg"
                  style={{ animationDelay: `${index * 50}ms` }}
                >
                  <CardHeader className="pb-3">
                    <div className="flex items-center justify-between">
                      <CardTitle className="text-base flex items-center gap-2">
                        <Clock className="w-4 h-4 text-purple-600" />
                        {entry.time}
                      </CardTitle>
                      <div className="flex gap-2">
                        <Button size="sm" variant="outline">
                          <Edit className="w-3 h-3" />
                        </Button>
                        <Button size="sm" variant="outline">
                          <Trash2 className="w-3 h-3" />
                        </Button>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <div className="grid grid-cols-2 gap-3">
                      <div className="p-3 bg-gradient-to-r from-red-50 to-orange-50 rounded-lg">
                        <div className="flex items-center gap-2 mb-1">
                          <Thermometer className="w-4 h-4 text-red-600" />
                          <span className="text-xs text-gray-600">Temperature</span>
                        </div>
                        <p className="text-xl text-gray-900">{entry.temperature}°F</p>
                      </div>

                      <div className="p-3 bg-gradient-to-r from-purple-50 to-pink-50 rounded-lg">
                        <div className="flex items-center gap-2 mb-1">
                          <Activity className="w-4 h-4 text-purple-600" />
                          <span className="text-xs text-gray-600">Pain</span>
                        </div>
                        <p className="text-xl text-gray-900">{entry.painLevel}/10</p>
                      </div>

                      <div className="p-3 bg-gradient-to-r from-blue-50 to-cyan-50 rounded-lg">
                        <div className="flex items-center gap-2 mb-1">
                          <Heart className="w-4 h-4 text-blue-600" />
                          <span className="text-xs text-gray-600">BP</span>
                        </div>
                        <p className="text-xl text-gray-900">
                          {entry.bloodPressureSystolic}/{entry.bloodPressureDiastolic}
                        </p>
                      </div>

                      <div className="p-3 bg-gradient-to-r from-green-50 to-emerald-50 rounded-lg">
                        <div className="flex items-center gap-2 mb-1">
                          {getMoodIcon(entry.mood)}
                          <span className="text-xs text-gray-600">Mood</span>
                        </div>
                        <p className="text-sm text-gray-900 capitalize">{entry.mood}</p>
                      </div>
                    </div>

                    {entry.notes && (
                      <>
                        <Separator />
                        <div>
                          <p className="text-xs text-gray-600 mb-1">Notes:</p>
                          <p className="text-sm text-gray-700">{entry.notes}</p>
                        </div>
                      </>
                    )}
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          {/* History Tab */}
          <TabsContent value="history" className="space-y-6">
            <h3 className="text-2xl mb-6">Complete History - بشپړ تاریخچه</h3>
            
            <ScrollArea className="h-[600px]">
              <div className="space-y-4">
                {entries.map((entry, index) => (
                  <Card
                    key={entry.id}
                    className="hover-lift border-0 shadow-lg"
                  >
                    <CardContent className="p-4">
                      <div className="flex items-start gap-4">
                        <div className="p-3 bg-gradient-to-br from-purple-100 to-pink-100 rounded-lg">
                          <CalendarIcon className="w-6 h-6 text-purple-600" />
                        </div>
                        
                        <div className="flex-1">
                          <div className="flex items-center justify-between mb-3">
                            <div>
                              <h4 className="text-base text-gray-900">{entry.date}</h4>
                              <p className="text-sm text-gray-600">{entry.time}</p>
                            </div>
                            <Badge className={getPainLevelColor(entry.painLevel)}>
                              Pain: {entry.painLevel}/10
                            </Badge>
                          </div>

                          <div className="grid grid-cols-4 gap-3 mb-3">
                            <div>
                              <p className="text-xs text-gray-600 mb-1">Temp</p>
                              <p className="text-sm text-gray-900">{entry.temperature}°F</p>
                            </div>
                            <div>
                              <p className="text-xs text-gray-600 mb-1">BP</p>
                              <p className="text-sm text-gray-900">
                                {entry.bloodPressureSystolic}/{entry.bloodPressureDiastolic}
                              </p>
                            </div>
                            <div>
                              <p className="text-xs text-gray-600 mb-1">Mood</p>
                              <div className="flex items-center gap-1">
                                {getMoodIcon(entry.mood)}
                              </div>
                            </div>
                            <div className="text-right">
                              <Button size="sm" variant="outline">
                                View
                              </Button>
                            </div>
                          </div>

                          {entry.notes && (
                            <p className="text-sm text-gray-600 italic">"{entry.notes}"</p>
                          )}
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </ScrollArea>
          </TabsContent>

          {/* Reports Tab */}
          <TabsContent value="reports" className="space-y-6">
            <div className="flex justify-between items-center mb-6">
              <h3 className="text-2xl">Health Reports - روغتیایي راپورونه</h3>
              <Button 
                className="bg-gradient-to-r from-purple-500 to-pink-600"
                onClick={() => setReportModalOpen(true)}
              >
                <FileText className="w-4 h-4 mr-2" />
                Generate Report
              </Button>
            </div>

            {/* Summary Stats */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <Card className="border-0 shadow-lg">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between mb-4">
                    <h4 className="text-sm text-gray-600">Avg Temperature</h4>
                    <Thermometer className="w-5 h-5 text-red-600" />
                  </div>
                  <p className="text-3xl text-gray-900 mb-2">{avgTemperature.toFixed(1)}°F</p>
                  <p className="text-xs text-gray-600">Last 7 days</p>
                </CardContent>
              </Card>

              <Card className="border-0 shadow-lg">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between mb-4">
                    <h4 className="text-sm text-gray-600">Avg Pain Level</h4>
                    <Activity className="w-5 h-5 text-purple-600" />
                  </div>
                  <p className="text-3xl text-gray-900 mb-2">{avgPainLevel.toFixed(1)}/10</p>
                  <Progress value={avgPainLevel * 10} className="h-2" />
                </CardContent>
              </Card>

              <Card className="border-0 shadow-lg">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between mb-4">
                    <h4 className="text-sm text-gray-600">Avg Blood Pressure</h4>
                    <Heart className="w-5 h-5 text-blue-600" />
                  </div>
                  <p className="text-3xl text-gray-900 mb-2">
                    {avgBpSystolic.toFixed(0)}/{avgBpDiastolic.toFixed(0)}
                  </p>
                  <p className="text-xs text-gray-600">Last 7 days</p>
                </CardContent>
              </Card>
            </div>

            {/* Trends */}
            <Card className="border-0 shadow-lg">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <LineChart className="w-5 h-5 text-purple-600" />
                  Weekly Trends
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div>
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-sm text-gray-700">Temperature Trend</span>
                      <span className="text-sm text-gray-600">Stable</span>
                    </div>
                    <Progress value={60} className="h-2" />
                  </div>
                  
                  <div>
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-sm text-gray-700">Pain Level Trend</span>
                      <span className="text-sm text-green-600 flex items-center gap-1">
                        <TrendingDown className="w-3 h-3" />
                        Improving
                      </span>
                    </div>
                    <Progress value={40} className="h-2" />
                  </div>

                  <div>
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-sm text-gray-700">Blood Pressure</span>
                      <span className="text-sm text-yellow-600 flex items-center gap-1">
                        <TrendingUp className="w-3 h-3" />
                        Slightly High
                      </span>
                    </div>
                    <Progress value={70} className="h-2" />
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>

      {/* Add Entry Modal */}
      <Dialog open={addModalOpen} onOpenChange={setAddModalOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle className="text-2xl">Log Symptoms - علایم ثبت کړئ</DialogTitle>
            <DialogDescription>Record your health symptoms and track changes over time</DialogDescription>
          </DialogHeader>
          <div className="space-y-6">
            {/* Temperature */}
            <div>
              <label className="text-sm text-gray-700 mb-2 block flex items-center gap-2">
                <Thermometer className="w-4 h-4 text-red-600" />
                Temperature (°F) - تودوخه
              </label>
              <div className="flex items-center gap-4">
                <Slider
                  value={[temperature]}
                  onValueChange={(value) => setTemperature(value[0])}
                  min={95}
                  max={105}
                  step={0.1}
                  className="flex-1"
                />
                <Input
                  type="number"
                  value={temperature}
                  onChange={(e) => setTemperature(parseFloat(e.target.value))}
                  className="w-24"
                  step={0.1}
                />
              </div>
              <p className="text-sm text-gray-600 mt-1">Current: {temperature}°F</p>
            </div>

            {/* Pain Level */}
            <div>
              <label className="text-sm text-gray-700 mb-2 block flex items-center gap-2">
                <Activity className="w-4 h-4 text-purple-600" />
                Pain Level (0-10) - د درد کچه
              </label>
              <Slider
                value={[painLevel]}
                onValueChange={(value) => setPainLevel(value[0])}
                min={0}
                max={10}
                step={1}
                className="mb-2"
              />
              <div className="flex items-center justify-between text-sm">
                <span className="text-gray-600">No Pain</span>
                <Badge className={getPainLevelColor(painLevel)}>
                  {painLevel}/10
                </Badge>
                <span className="text-gray-600">Severe Pain</span>
              </div>
            </div>

            {/* Blood Pressure */}
            <div>
              <label className="text-sm text-gray-700 mb-2 block flex items-center gap-2">
                <Heart className="w-4 h-4 text-blue-600" />
                Blood Pressure - د وینې فشار
              </label>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-xs text-gray-600 mb-1 block">Systolic (Upper)</label>
                  <Input
                    type="number"
                    value={bpSystolic}
                    onChange={(e) => setBpSystolic(parseInt(e.target.value))}
                  />
                </div>
                <div>
                  <label className="text-xs text-gray-600 mb-1 block">Diastolic (Lower)</label>
                  <Input
                    type="number"
                    value={bpDiastolic}
                    onChange={(e) => setBpDiastolic(parseInt(e.target.value))}
                  />
                </div>
              </div>
              <p className="text-sm text-gray-600 mt-1">
                Current: {bpSystolic}/{bpDiastolic} mmHg
              </p>
            </div>

            {/* Mood */}
            <div>
              <label className="text-sm text-gray-700 mb-3 block flex items-center gap-2">
                <Brain className="w-4 h-4 text-green-600" />
                Mood - مزاج
              </label>
              <div className="grid grid-cols-3 gap-3">
                <button
                  onClick={() => setMood("happy")}
                  className={`p-4 rounded-lg border-2 transition-all ${
                    mood === "happy"
                      ? "border-green-500 bg-green-50"
                      : "border-gray-200 hover:border-green-300"
                  }`}
                >
                  <Smile className="w-8 h-8 text-green-600 mx-auto mb-2" />
                  <p className="text-sm text-gray-900">Happy</p>
                  <p className="text-xs text-gray-600">خوشحاله</p>
                </button>

                <button
                  onClick={() => setMood("neutral")}
                  className={`p-4 rounded-lg border-2 transition-all ${
                    mood === "neutral"
                      ? "border-yellow-500 bg-yellow-50"
                      : "border-gray-200 hover:border-yellow-300"
                  }`}
                >
                  <Meh className="w-8 h-8 text-yellow-600 mx-auto mb-2" />
                  <p className="text-sm text-gray-900">Neutral</p>
                  <p className="text-xs text-gray-600">عادي</p>
                </button>

                <button
                  onClick={() => setMood("sad")}
                  className={`p-4 rounded-lg border-2 transition-all ${
                    mood === "sad"
                      ? "border-red-500 bg-red-50"
                      : "border-gray-200 hover:border-red-300"
                  }`}
                >
                  <Frown className="w-8 h-8 text-red-600 mx-auto mb-2" />
                  <p className="text-sm text-gray-900">Sad</p>
                  <p className="text-xs text-gray-600">خفه</p>
                </button>
              </div>
            </div>

            {/* Notes */}
            <div>
              <label className="text-sm text-gray-700 mb-2 block">
                Additional Notes - اضافي یادښتونه
              </label>
              <Textarea
                placeholder="Describe how you're feeling, any symptoms, medications taken, etc."
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                className="min-h-[100px]"
              />
            </div>

            <div className="flex gap-3">
              <Button
                variant="outline"
                className="flex-1"
                onClick={() => setAddModalOpen(false)}
              >
                Cancel
              </Button>
              <Button
                className="flex-1 bg-gradient-to-r from-purple-500 to-pink-600"
                onClick={handleAddEntry}
              >
                <Plus className="w-4 h-4 mr-2" />
                Save Entry
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Report Modal */}
      <Dialog open={reportModalOpen} onOpenChange={setReportModalOpen}>
        <DialogContent className="max-w-3xl">
          <DialogHeader>
            <DialogTitle className="text-2xl">Health Report - روغتیایي راپور</DialogTitle>
            <DialogDescription>Your comprehensive health report based on tracked symptoms</DialogDescription>
          </DialogHeader>
          <ScrollArea className="max-h-[600px]">
            <div className="space-y-6">
              {/* Report Summary */}
              <Card className="border-0 shadow-lg bg-gradient-to-r from-purple-50 to-pink-50">
                <CardContent className="p-6">
                  <h3 className="text-lg mb-4">7-Day Health Summary</h3>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <p className="text-sm text-gray-600 mb-1">Total Entries:</p>
                      <p className="text-2xl text-purple-600">{entries.length}</p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-600 mb-1">Date Range:</p>
                      <p className="text-sm text-gray-900">Nov 12 - Nov 15</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Detailed Metrics */}
              {healthMetrics.map((metric, index) => {
                const Icon = metric.icon;
                return (
                  <Card key={index} className="border-0 shadow-lg">
                    <CardContent className="p-6">
                      <div className="flex items-center gap-3 mb-4">
                        <div className={`p-2 bg-gradient-to-br ${metric.color} rounded-lg`}>
                          <Icon className="w-5 h-5 text-white" />
                        </div>
                        <div>
                          <h4 className="text-base text-gray-900">{metric.name}</h4>
                          <p className="text-sm text-gray-600">{metric.nameDari}</p>
                        </div>
                      </div>
                      
                      <div className="grid grid-cols-3 gap-4 mb-3">
                        <div>
                          <p className="text-xs text-gray-600 mb-1">Current</p>
                          <p className="text-lg text-gray-900">{metric.value}{metric.unit}</p>
                        </div>
                        <div>
                          <p className="text-xs text-gray-600 mb-1">Average</p>
                          <p className="text-lg text-gray-900">
                            {index === 0 && avgTemperature.toFixed(1)}
                            {index === 1 && avgPainLevel.toFixed(1)}
                            {index === 2 && avgBpSystolic.toFixed(0)}
                            {index === 3 && "75"}
                            {metric.unit}
                          </p>
                        </div>
                        <div>
                          <p className="text-xs text-gray-600 mb-1">Status</p>
                          <Badge className={
                            metric.status === "normal" ? "bg-green-100 text-green-700" :
                            metric.status === "warning" ? "bg-yellow-100 text-yellow-700" :
                            "bg-red-100 text-red-700"
                          }>
                            {metric.status}
                          </Badge>
                        </div>
                      </div>

                      <Progress 
                        value={
                          index === 0 ? (metric.value / 105) * 100 :
                          index === 1 ? metric.value * 10 :
                          index === 2 ? (metric.value / 200) * 100 :
                          metric.value
                        } 
                        className="h-2" 
                      />
                    </CardContent>
                  </Card>
                );
              })}

              <div className="flex gap-3">
                <Button className="flex-1 bg-gradient-to-r from-purple-500 to-pink-600">
                  <Download className="w-4 h-4 mr-2" />
                  Download PDF
                </Button>
                <Button variant="outline" className="flex-1">
                  <ArrowRight className="w-4 h-4 mr-2" />
                  Share with Doctor
                </Button>
              </div>
            </div>
          </ScrollArea>
        </DialogContent>
      </Dialog>
    </section>
  );
}

export default SymptomsTracker;
