import { motion } from 'motion/react';
import { FileText, CheckCircle, XCircle, AlertTriangle, Scale, UserX, ArrowLeft } from 'lucide-react';
import { Button } from './ui/button';

interface TermsOfServiceProps {
  language: 'ps' | 'fa' | 'en';
  onBack: () => void;
}

export function TermsOfService({ language, onBack }: TermsOfServiceProps) {
  const content = {
    ps: {
      title: 'د خدماتو شرطونه',
      lastUpdated: 'وروستی تازه: 25 نومبر 2024',
      intro: 'د HealMate اپلیکیشن استعمال سره، تاسو د لاندې شرطونو او شرایطو موافق یاست. مهرباني وکړئ دا شرطونه په دقت سره ولولئ.',
      sections: [
        {
          icon: CheckCircle,
          title: '1. د خدماتو منل',
          content: `د دې اپلیکیشن استعمال سره:

• تاسو تایید کوئ چې تاسو لږترلږه 13 کاله عمر لرئ
• تاسو د دې شرطونو موافق یاست
• تاسو د افغانستان یا نورو هېوادونو قوانین تعمیل کوئ
• تاسو د خپل حساب امنیت مسؤل یاست
• تاسو به صحیح او دقیق معلومات ورکړئ`
        },
        {
          icon: FileText,
          title: '2. د خدماتو تشریح',
          content: `HealMate لاندې خدمات چمتو کوي:

• د دوکتورانو او روغتونونو معلومات
• د درملو لارښود (1500+ درمل)
• AI روغتیا چټ مرستیال
• د روغتیا مشورې او لارښودونه
• د لومړنۍ مرستې معلومات
• د خوراک او تغذیې لارښود
• ټولنیز شبکه (د پوستونو سیسټم)
• Premium ځانګړتیاوې

⚠️ یادونه: دا خدمات یوازې د معلوماتو لپاره دي او د طبي مشورې ځای نه نیسي.`
        },
        {
          icon: AlertTriangle,
          title: '3. طبي یادونه',
          content: `⚠️ مهم یادونه:

• HealMate د طبي مشورې ځای نه نیسي
• موږ طبي تشخیص نه ورکوو
• موږ درمل نه تجویزوو
• د جدي روغتیا مسلو لپاره، له خپل ډاکټر سره مشوره وکړئ
• د اضطراري حالت کې، سمدستي طبي مرسته ترلاسه کړئ
• موږ د AI ځوابونو دقت تضمین نه کوو
• تاسو د خپلو روغتیا تصمیمونو مسؤل یاست`
        },
        {
          icon: UserX,
          title: '4. د کاروونکي مسؤلیتونه',
          content: `د کاروونکي په توګه، تاسو باید:

✅ مجاز:
• صحیح معلومات ورکړئ
• د خپل حساب امنیت وساتئ
• د اپلیکیشن صحیح استعمال وکړئ
• د نورو کاروونکو احترام وکړئ
• د قوانینو تعمیل وکړئ

❌ منع:
• جعلي معلومات ورکول
• د نورو حساب غلط استعمال
• سپم یا هراسولو پوستونه
• غیرقانوني فعالیتونه
• د سیسټم hack کول یا abuse`
        },
        {
          icon: XCircle,
          title: '5. منع فعالیتونه',
          content: `لاندې فعالیتونه په کلکه منع دي:

❌ د جعلي معلوماتو شریکول
❌ د نورو هراسول یا تهدید
❌ سپم یا غیرمطلوب مینځپانګه
❌ د نفرت یا تبعیض خبرې
❌ د نورو شخصي معلوماتو شریکول
❌ د اپلیکیشن reverse engineering
❌ د automated bots استعمال
❌ د طبي مشورې غوښتنه د جدي مسلو لپاره
❌ د قوانینو څخه سرغړونه

د دې شرطونو څخه سرغړونه کولی شي ستاسو حساب suspend یا delete کړي.`
        },
        {
          icon: Scale,
          title: '6. فکري ملکیت',
          content: `• ټول اپلیکیشن content د HealMate ملکیت دی
• تاسو نشئ کولی موږ content کاپي یا redistribute کړئ
• د کاروونکي لخوا جوړ شوی content د هغو ملکیت دی
• موږ حق لرو چې قانون سرغړوونکي content حذف کړو
• د trademark او copyright قوانین تعمیل اړین دی`
        },
        {
          icon: CheckCircle,
          title: '7. Premium خدمات',
          content: `د Premium subscription لپاره:

• تادیه د ګوګل Play Store له لارې کیږي
• د subscription قیمتونه کیدی شي بدل شي
• تاسو کولی شئ هر وخت cancel کړئ
• د cancel کولو وروسته، premium تر پای مودې پورې کار کوي
• refund د Google Play Store د پالیسي سره سم
• د Premium ځانګړتیاوې کیدی شي بدل شي`
        },
        {
          icon: AlertTriangle,
          title: '8. د مسؤلیت محدودیت',
          content: `HealMate مسؤل نه دی د:

• د معلوماتو دقت یا بشپړتیا
• د AI ځوابونو غلطیو
• د کاروونکو ترمنځ شخړو
• د اپلیکیشن downtime یا technical issues
• د third-party خدماتو مسلو
• ستاسو د روغتیا تصمیمونو پایلو
• ستاسو د data ضایع کیدو

تاسو د خپل خطر په خپل ذمه اپلیکیشن استعمالوئ.`
        },
        {
          icon: FileText,
          title: '9. د شرطونو بدلونونه',
          content: `• موږ حق لرو چې دا شرطونه هر وخت بدل کړو
• د بدلونونو په صورت کې به تاسو ته خبر درکړو
• د بدلونونو وروسته استعمال د نویو شرطونو منل دي
• د اپلیکیشن دوامداره استعمال د موافقت نښه ده`
        },
        {
          icon: Scale,
          title: '10. حل او فصل او قانون',
          content: `• دا شرطونه د افغانستان قوانینو تابع دي
• د شخړو په صورت کې، لومړی د سوله ییز حل هڅه کیږي
• د قانوني اختلافاتو حل د کابل په محاکمو کې
• تاسو د arbitration موافق یاست`
        }
      ],
      termination: {
        title: '11. د حساب بندول',
        content: `موږ حق لرو چې ستاسو حساب بند کړو که:

• تاسو د شرطونو څخه سرغړونه وکړئ
• تاسو غیرقانوني فعالیتونه وکړئ
• تاسو د نورو کاروونکو ته زیان ورسوئ
• ستاسو حساب د اوږدې مودې لپاره inactive وي

تاسو هم کولی شئ خپل حساب هر وخت delete کړئ.`
      },
      contact: {
        title: '12. موږ سره اړیکه',
        content: `د پوښتنو یا اندېښنو لپاره:

📧 برېښنالیک: ibrahimkhaksar.it@gmail.com
📱 فون: +93 700 000 000
🌐 ویبسایټ: healmate.af
📍 پته: کابل، افغانستان`
      },
      agreement: '✅ د دې اپلیکیشن استعمال سره، تاسو د دې شرطونو سره بشپړ موافق یاست.'
    },
    fa: {
      title: 'شرایط و ضوابط خدمات',
      lastUpdated: 'آخرین بروزرسانی: 25 نوامبر 2024',
      intro: 'با استفاده از اپلیکیشن HealMate، شما با شرایط و ضوابط زیر موافقت می‌کنید. لطفاً این شرایط را با دقت بخوانید.',
      sections: [
        {
          icon: CheckCircle,
          title: '۱. پذیرش خدمات',
          content: `با استفاده از این اپلیکیشن:

• شما تایید می‌کنید که حداقل 13 سال سن دارید
• شما با این شرایط موافق هستید
• شما از قوانین افغانستان یا سایر کشورها پیروی می‌کنید
• شما مسئول امنیت حساب خود هستید
• شما اطلاعات صحیح و دقیق ارائه می‌دهید`
        },
        {
          icon: FileText,
          title: '۲. توضیح خدمات',
          content: `HealMate خدمات زیر را ارائه می‌دهد:

• اطلاعات دکتران و بیمارستان‌ها
• راهنمای دارو (1500+ دارو)
• دستیار چت سلامتی AI
• مشاوره‌ها و راهنماهای سلامتی
• اطلاعات کمک‌های اولیه
• راهنمای تغذیه و غذا
• شبکه اجتماعی (سیستم پست)
• ویژگی‌های پریمیوم

⚠️ توجه: این خدمات فقط برای اطلاعات هستند و جایگزین مشاوره پزشکی نیستند.`
        },
        {
          icon: AlertTriangle,
          title: '۳. توجه پزشکی',
          content: `⚠️ توجه مهم:

• HealMate جایگزین مشاوره پزشکی نیست
• ما تشخیص پزشکی ارائه نمی‌دهیم
• ما دارو تجویز نمی‌کنیم
• برای مشکلات جدی سلامتی، با پزشک خود مشورت کنید
• در شرایط اضطراری، فوراً کمک پزشکی دریافت کنید
• ما دقت پاسخ‌های AI را تضمین نمی‌کنیم
• شما مسئول تصمیمات سلامتی خود هستید`
        },
        {
          icon: UserX,
          title: '۴. مسئولیت‌های کاربر',
          content: `به عنوان کاربر، شما باید:

✅ مجاز:
• اطلاعات صحیح ارائه دهید
• امنیت حساب خود را حفظ کنید
• از اپلیکیشن به درستی استفاده کنید
• به کاربران دیگر احترام بگذارید
• از قوانین پیروی کنید

❌ ممنوع:
• ارائه اطلاعات جعلی
• سوء استفاده از حساب دیگران
• پست‌های اسپم یا آزاردهنده
• فعالیت‌های غیرقانونی
• هک یا سوء استفاده از سیستم`
        },
        {
          icon: XCircle,
          title: '۵. فعالیت‌های ممنوع',
          content: `فعالیت‌های زیر شدیداً ممنوع هستند:

❌ اشتراک‌گذاری اطلاعات جعلی
❌ آزار یا تهدید دیگران
❌ اسپم یا محتوای ناخواسته
❌ سخنان نفرت‌انگیز یا تبعیض‌آمیز
❌ اشتراک‌گذاری اطلاعات شخصی دیگران
❌ مهندسی معکوس اپلیکیشن
❌ استفاده از ربات‌های خودکار
❌ درخواست مشاوره پزشکی برای مشکلات جدی
❌ تخطی از قوانین

نقض این شرایط می‌تواند حساب شما را تعلیق یا حذف کند.`
        },
        {
          icon: Scale,
          title: '۶. مالکیت فکری',
          content: `• تمام محتوای اپلیکیشن متعلق به HealMate است
• شما نمی‌توانید محتوای ما را کپی یا توزیع کنید
• محتوای ایجاد شده توسط کاربران متعلق به آنهاست
• ما حق داریم محتوای نقض‌کننده را حذف کنیم
• رعایت قوانین علامت تجاری و کپی‌رایت الزامی است`
        },
        {
          icon: CheckCircle,
          title: '۷. خدمات پریمیوم',
          content: `برای اشتراک پریمیوم:

• پرداخت از طریق Google Play Store انجام می‌شود
• قیمت اشتراک ممکن است تغییر کند
• می‌توانید هر زمان لغو کنید
• پس از لغو، پریمیوم تا پایان دوره کار می‌کند
• بازپرداخت مطابق سیاست Google Play Store
• ویژگی‌های پریمیوم ممکن است تغییر کند`
        },
        {
          icon: AlertTriangle,
          title: '۸. محدودیت مسئولیت',
          content: `HealMate مسئول نیست برای:

• دقت یا کامل بودن اطلاعات
• خطاهای پاسخ‌های AI
• اختلافات بین کاربران
• خرابی اپلیکیشن یا مشکلات فنی
• مشکلات خدمات شخص ثالث
• نتایج تصمیمات سلامتی شما
• از دست رفتن داده‌های شما

شما با مسئولیت خود از اپلیکیشن استفاده می‌کنید.`
        },
        {
          icon: FileText,
          title: '۹. تغییرات شرایط',
          content: `• ما حق داریم این شرایط را هر زمان تغییر دهیم
• در صورت تغییرات به شما اطلاع می‌دهیم
• استفاده پس از تغییرات به معنای پذیرش شرایط جدید است
• استفاده مداوم از اپلیکیشن نشانه موافقت است`
        },
        {
          icon: Scale,
          title: '۱۰. حل اختلاف و قانون',
          content: `• این شرایط تابع قوانین افغانستان هستند
• در صورت اختلاف، ابتدا تلاش برای حل مسالمت‌آمیز می‌شود
• حل اختلافات قانونی در دادگاه‌های کابل
• شما با داوری موافق هستید`
        }
      ],
      termination: {
        title: '۱۱. بستن حساب',
        content: `ما حق داریم حساب شما را ببندیم اگر:

• شما از شرایط تخطی کنید
• فعالیت‌های غیرقانونی انجام دهید
• به کاربران دیگر آسیب برسانید
• حساب شما مدت طولانی غیرفعال باشد

شما هم می‌توانید حساب خود را هر زمان حذف کنید.`
      },
      contact: {
        title: '۱۲. تماس با ما',
        content: `برای سوالات یا نگرانی‌ها:

📧 ایمیل: ibrahimkhaksar.it@gmail.com
📱 تلفن: +93 700 000 000
🌐 وبسایت: healmate.af
📍 آدرس: کابل، افغانستان`
      },
      agreement: '✅ با استفاده از این اپلیکیشن، شما کاملاً با این شرایط موافق هستید.'
    },
    en: {
      title: 'Terms of Service',
      lastUpdated: 'Last Updated: November 25, 2024',
      intro: 'By using the HealMate application, you agree to the following terms and conditions. Please read these terms carefully.',
      sections: [
        {
          icon: CheckCircle,
          title: '1. Acceptance of Services',
          content: `By using this application:

• You confirm that you are at least 13 years old
• You agree to these terms
• You comply with the laws of Afghanistan or other countries
• You are responsible for the security of your account
• You will provide accurate and correct information`
        },
        {
          icon: FileText,
          title: '2. Service Description',
          content: `HealMate provides the following services:

• Doctor and hospital information
• Medicine guide (1500+ medicines)
• AI Health Chat Assistant
• Health tips and guides
• First aid information
• Nutrition and diet guide
• Social network (posts system)
• Premium features

⚠️ Note: These services are for informational purposes only and do not replace medical advice.`
        },
        {
          icon: AlertTriangle,
          title: '3. Medical Disclaimer',
          content: `⚠️ Important Notice:

• HealMate does not replace medical advice
• We do not provide medical diagnosis
• We do not prescribe medications
• For serious health issues, consult your doctor
• In emergencies, seek immediate medical help
• We do not guarantee the accuracy of AI responses
• You are responsible for your health decisions`
        },
        {
          icon: UserX,
          title: '4. User Responsibilities',
          content: `As a user, you must:

✅ Allowed:
• Provide accurate information
• Maintain account security
• Use the app correctly
• Respect other users
• Comply with laws

❌ Prohibited:
• Providing fake information
• Misusing others' accounts
• Spam or harassing posts
• Illegal activities
• Hacking or abusing the system`
        },
        {
          icon: XCircle,
          title: '5. Prohibited Activities',
          content: `The following activities are strictly prohibited:

❌ Sharing false information
❌ Harassing or threatening others
❌ Spam or unwanted content
❌ Hate speech or discrimination
❌ Sharing others' personal information
❌ Reverse engineering the application
❌ Using automated bots
❌ Requesting medical advice for serious issues
❌ Violating laws

Violation of these terms may suspend or delete your account.`
        },
        {
          icon: Scale,
          title: '6. Intellectual Property',
          content: `• All app content is owned by HealMate
• You may not copy or redistribute our content
• User-generated content is owned by them
• We reserve the right to delete violating content
• Compliance with trademark and copyright laws is required`
        },
        {
          icon: CheckCircle,
          title: '7. Premium Services',
          content: `For Premium subscription:

• Payment is through Google Play Store
• Subscription prices may change
• You can cancel at any time
• After cancellation, premium works until end of period
• Refunds per Google Play Store policy
• Premium features may change`
        },
        {
          icon: AlertTriangle,
          title: '8. Limitation of Liability',
          content: `HealMate is not responsible for:

• Accuracy or completeness of information
• AI response errors
• Disputes between users
• App downtime or technical issues
• Third-party service problems
• Results of your health decisions
• Loss of your data

You use the application at your own risk.`
        },
        {
          icon: FileText,
          title: '9. Changes to Terms',
          content: `• We reserve the right to change these terms at any time
• We will notify you of changes
• Use after changes means acceptance of new terms
• Continued use of the app indicates agreement`
        },
        {
          icon: Scale,
          title: '10. Dispute Resolution and Law',
          content: `• These terms are subject to Afghan laws
• In case of disputes, peaceful resolution is first attempted
• Legal disputes resolved in Kabul courts
• You agree to arbitration`
        }
      ],
      termination: {
        title: '11. Account Termination',
        content: `We reserve the right to terminate your account if:

• You violate these terms
• You engage in illegal activities
• You harm other users
• Your account is inactive for a long time

You can also delete your account at any time.`
      },
      contact: {
        title: '12. Contact Us',
        content: `For questions or concerns:

📧 Email: ibrahimkhaksar.it@gmail.com
📱 Phone: +93 700 000 000
🌐 Website: healmate.af
📍 Address: Kabul, Afghanistan`
      },
      agreement: '✅ By using this application, you fully agree to these terms.'
    }
  };

  const t = content[language];

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-gray-50 to-zinc-50 pb-20">
      {/* Header */}
      <div className="sticky top-0 z-30 bg-white/80 backdrop-blur-xl border-b border-gray-200 shadow-lg">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center gap-4">
            <Button variant="ghost" size="icon" onClick={onBack}>
              <ArrowLeft className="w-5 h-5" />
            </Button>
            <div className="flex items-center gap-3">
              <div className="bg-gradient-to-br from-slate-500 to-gray-600 p-2.5 rounded-2xl">
                <FileText className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-2xl bg-gradient-to-r from-slate-600 to-gray-600 bg-clip-text text-transparent">
                  {t.title}
                </h1>
                <p className="text-xs text-gray-600">{t.lastUpdated}</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="container mx-auto px-4 py-6 max-w-4xl">
        {/* Introduction */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white rounded-2xl p-6 border border-gray-200 shadow-lg mb-6"
        >
          <p className="text-gray-700 leading-relaxed" dir={language === 'en' ? 'ltr' : 'rtl'}>
            {t.intro}
          </p>
        </motion.div>

        {/* Sections */}
        <div className="space-y-6">
          {t.sections.map((section, index) => {
            const Icon = section.icon;
            return (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                className="bg-white rounded-2xl p-6 border border-gray-200 shadow-lg"
              >
                <div className="flex items-start gap-4 mb-4">
                  <div className="bg-gradient-to-br from-slate-500 to-gray-600 p-3 rounded-xl">
                    <Icon className="w-6 h-6 text-white" />
                  </div>
                  <div className="flex-1">
                    <h2 className="text-xl font-medium mb-2" dir={language === 'en' ? 'ltr' : 'rtl'}>
                      {section.title}
                    </h2>
                  </div>
                </div>
                <div 
                  className="text-gray-700 leading-relaxed whitespace-pre-wrap"
                  dir={language === 'en' ? 'ltr' : 'rtl'}
                >
                  {section.content}
                </div>
              </motion.div>
            );
          })}

          {/* Termination */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 1.0 }}
            className="bg-white rounded-2xl p-6 border border-gray-200 shadow-lg"
          >
            <h2 className="text-xl font-medium mb-4" dir={language === 'en' ? 'ltr' : 'rtl'}>
              {t.termination.title}
            </h2>
            <p className="text-gray-700 leading-relaxed whitespace-pre-wrap" dir={language === 'en' ? 'ltr' : 'rtl'}>
              {t.termination.content}
            </p>
          </motion.div>

          {/* Contact */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 1.1 }}
            className="bg-white rounded-2xl p-6 border border-gray-200 shadow-lg"
          >
            <h2 className="text-xl font-medium mb-4" dir={language === 'en' ? 'ltr' : 'rtl'}>
              {t.contact.title}
            </h2>
            <p className="text-gray-700 leading-relaxed whitespace-pre-wrap" dir={language === 'en' ? 'ltr' : 'rtl'}>
              {t.contact.content}
            </p>
          </motion.div>

          {/* Agreement */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 1.2 }}
            className="bg-gradient-to-r from-blue-50 to-indigo-50 border-2 border-blue-200 rounded-2xl p-6"
          >
            <p className="text-center font-medium text-blue-700" dir={language === 'en' ? 'ltr' : 'rtl'}>
              {t.agreement}
            </p>
          </motion.div>
        </div>
      </div>
    </div>
  );
}
