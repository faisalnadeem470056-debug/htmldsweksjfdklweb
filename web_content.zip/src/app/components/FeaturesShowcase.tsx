import { motion } from 'motion/react';
import {
  Stethoscope,
  Hospital,
  Pill,
  Shield,
  Activity,
  BookOpen,
  MessageCircle,
  Bot,
  Calculator,
  Search,
  FileText,
  Heart,
  Users,
  Phone,
  Star,
  Droplet,
  Brain,
  Utensils,
  Newspaper,
  Building2,
  Clock,
  Globe,
  Lock,
  Zap,
  TrendingUp,
  Award,
  HeartPulse,
  QrCode,
  Share2
} from 'lucide-react';

interface FeaturesShowcaseProps {
  language: 'ps' | 'fa' | 'en';
  onFeatureClick: (feature: string) => void;
}

export function FeaturesShowcase({ language, onFeatureClick }: FeaturesShowcaseProps) {
  const t = {
    title: {
      ps: '🌟 د اپلیکیشن ځانګړتیاوې',
      fa: '🌟 ویژگی‌های اپلیکیشن',
      en: '🌟 App Features'
    },
    subtitle: {
      ps: 'د افغانستان لومړی بشپړ ډیجیټل روغتیا پلیټفارم - 25+ فیچرونه',
      fa: 'اولین پلتفرم کامل دیجیتال سلامت افغانستان - 25+ ویژگی',
      en: "Afghanistan's First Complete Digital Health Platform - 25+ Features"
    }
  };

  const features = [
    // Medical Services
    {
      category: { ps: '🏥 طبي خدمات', fa: '🏥 خدمات پزشکی', en: '🏥 Medical Services' },
      items: [
        {
          id: 'doctors',
          icon: Stethoscope,
          title: { ps: 'د دوکتورانو لارښود', fa: 'راهنمای دکتران', en: 'Doctors Directory' },
          description: { ps: '250+ دوکتوران د ټولو تخصصونو سره', fa: '250+ دکتر با تمام تخصص‌ها', en: '250+ Doctors with all specialties' },
          badge: { ps: '250+', fa: '250+', en: '250+' },
          gradient: 'from-blue-500 to-cyan-500',
          action: 'doctors'
        },
        {
          id: 'hospitals',
          icon: Hospital,
          title: { ps: 'د روغتونونو لارښود', fa: 'راهنمای بیمارستان‌ها', en: 'Hospitals Directory' },
          description: { ps: '150+ روغتونونه او کلینیکونه', fa: '150+ بیمارستان و کلینیک', en: '150+ Hospitals and Clinics' },
          badge: { ps: '150+', fa: '150+', en: '150+' },
          gradient: 'from-red-500 to-pink-500',
          action: 'hospitals'
        },
        {
          id: 'medicines',
          icon: Pill,
          title: { ps: 'د درملو ډیټابیس', fa: 'پایگاه داده داروها', en: 'Medicine Database' },
          description: { ps: '1500+ دواګانې د بشپړ معلوماتو سره', fa: '1500+ داروها با اطلاعات کامل', en: '1500+ Medicines with full info' },
          badge: { ps: '1500+', fa: '1500+', en: '1500+' },
          gradient: 'from-purple-500 to-violet-500',
          action: 'medicine'
        },
        {
          id: 'emergency',
          icon: Shield,
          title: { ps: 'اسعافی مرسته', fa: 'کمک‌های فوری', en: 'Emergency Aid' },
          description: { ps: 'د اسعافی حالاتو لپاره فوري لارښود', fa: 'راهنمای فوری برای موارد اضطراری', en: 'Instant guide for emergencies' },
          badge: { ps: '24/7', fa: '24/7', en: '24/7' },
          gradient: 'from-orange-500 to-red-500',
          action: 'firstaid'
        }
      ]
    },
    // Health Tools
    {
      category: { ps: '🧰 روغتیا وسیلې', fa: '🧰 ابزارهای سلامت', en: '🧰 Health Tools' },
      items: [
        {
          id: 'bmi',
          icon: Calculator,
          title: { ps: 'BMI حساب کوونکی', fa: 'محاسبه‌گر BMI', en: 'BMI Calculator' },
          description: { ps: 'د وزن شاخص په ثانیو کې', fa: 'شاخص وزن در ثانیه‌ها', en: 'Weight index in seconds' },
          badge: { ps: 'وړیا', fa: 'رایگان', en: 'Free' },
          gradient: 'from-purple-500 to-pink-500',
          action: 'bmi'
        },
        {
          id: 'symptoms',
          icon: Search,
          title: { ps: 'د نښو معاینه', fa: 'بررسی علائم', en: 'Symptoms Checker' },
          description: { ps: '18+ نښې او د ناروغیو تشخیص', fa: '18+ علائم و تشخیص بیماری', en: '18+ symptoms and diagnosis' },
          badge: { ps: 'هوښیار', fa: 'هوشمند', en: 'Smart' },
          gradient: 'from-red-500 to-orange-500',
          action: 'symptoms'
        },
        {
          id: 'diseases',
          icon: FileText,
          title: { ps: 'د ناروغیو معلومات', fa: 'اطلاعات بیماری‌ها', en: 'Disease Info' },
          description: { ps: 'د ناروغیو بشپړ دایرة المعارف', fa: 'دایره‌المعارف کامل بیماری‌ها', en: 'Complete disease encyclopedia' },
          badge: { ps: '100+', fa: '100+', en: '100+' },
          gradient: 'from-blue-500 to-cyan-500',
          action: 'diseases'
        },
        {
          id: 'blood-pressure',
          icon: HeartPulse,
          title: { ps: 'د فشار ثبت', fa: 'ثبت فشار خون', en: 'Blood Pressure Log' },
          description: { ps: 'د فشار ریکارډ او ټریک', fa: 'ضبط و پیگیری فشار خون', en: 'Track blood pressure' },
          badge: { ps: 'نوی', fa: 'جدید', en: 'New' },
          gradient: 'from-green-500 to-emerald-500',
          action: 'blood-pressure'
        }
      ]
    },
    // Education & Information
    {
      category: { ps: '📚 زده کړه او معلومات', fa: '📚 آموزش و اطلاعات', en: '📚 Education & Info' },
      items: [
        {
          id: 'health-tips',
          icon: Activity,
          title: { ps: 'روغتیا مشورې', fa: 'نکات سلامتی', en: 'Health Tips' },
          description: { ps: 'ورځنۍ روغتیا مشورې او لارښودونه', fa: 'نکات و راهنماهای روزانه سلامتی', en: 'Daily health tips and guides' },
          badge: { ps: 'روزانه', fa: 'روزانه', en: 'Daily' },
          gradient: 'from-green-500 to-teal-500',
          action: 'health-tips'
        },
        {
          id: 'nutrition',
          icon: Utensils,
          title: { ps: 'د خوراک لارښود', fa: 'راهنمای تغذیه', en: 'Nutrition Guide' },
          description: { ps: 'صحي خوراک او د کالوري حساب', fa: 'رژیم سالم و محاسبه کالری', en: 'Healthy diet and calorie calc' },
          badge: { ps: 'بشپړ', fa: 'کامل', en: 'Full' },
          gradient: 'from-orange-500 to-amber-500',
          action: 'nutrition'
        },
        {
          id: 'books',
          icon: BookOpen,
          title: { ps: 'روغتیا کتابونه', fa: 'کتاب‌های سلامتی', en: 'Health Books' },
          description: { ps: 'د روغتیا کتابونه او مقالې', fa: 'کتاب‌ها و مقالات سلامتی', en: 'Health books and articles' },
          badge: { ps: '50+', fa: '50+', en: '50+' },
          gradient: 'from-indigo-500 to-purple-500',
          action: 'books'
        },
        {
          id: 'articles',
          icon: Newspaper,
          title: { ps: 'روغتیا مقالې', fa: 'مقالات سلامتی', en: 'Health Articles' },
          description: { ps: 'تازه روغتیا مقالې او خبرونه', fa: 'مقالات و اخبار تازه سلامتی', en: 'Latest health articles & news' },
          badge: { ps: 'تازه', fa: 'تازه', en: 'Fresh' },
          gradient: 'from-cyan-500 to-blue-500',
          action: 'articles'
        }
      ]
    },
    // AI & Technology
    {
      category: { ps: '🤖 AI او ټکنالوژي', fa: '🤖 AI و تکنولوژی', en: '🤖 AI & Technology' },
      items: [
        {
          id: 'ai-chat',
          icon: Bot,
          title: { ps: 'AI روغتیا مرستیال', fa: 'دستیار سلامت AI', en: 'AI Health Assistant' },
          description: { ps: '24/7 هوښیار روغتیا مشاور', fa: 'مشاور سلامتی هوشمند 24/7', en: '24/7 Smart health advisor' },
          badge: { ps: 'AI', fa: 'AI', en: 'AI' },
          gradient: 'from-purple-500 to-indigo-600',
          action: 'ai-chat'
        },
        {
          id: 'qr-scanner',
          icon: QrCode,
          title: { ps: 'QR سکینر', fa: 'اسکنر QR', en: 'QR Scanner' },
          description: { ps: 'د درملو QR کوډ سکین', fa: 'اسکن کد QR داروها', en: 'Scan medicine QR codes' },
          badge: { ps: 'چټک', fa: 'سریع', en: 'Fast' },
          gradient: 'from-green-500 to-teal-600',
          action: 'qr-scanner'
        },
        {
          id: 'voice',
          icon: Phone,
          title: { ps: 'د غږ لارښود', fa: 'راهنمای صوتی', en: 'Voice Guide' },
          description: { ps: 'د غږ په واسطه لارښود', fa: 'راهنمایی با صدا', en: 'Voice-guided assistance' },
          badge: { ps: 'نوی', fa: 'جدید', en: 'New' },
          gradient: 'from-blue-500 to-purple-600',
          action: 'voice'
        }
      ]
    },
    // Community & Social
    {
      category: { ps: '👥 ټولنه او شریکول', fa: '👥 انجمن و اشتراک', en: '👥 Community & Social' },
      items: [
        {
          id: 'community',
          icon: MessageCircle,
          title: { ps: 'ټولنیز شبکه', fa: 'شبکه اجتماعی', en: 'Social Network' },
          description: { ps: 'پوسټونه، تبصرې، او شریکول', fa: 'پست‌ها، نظرات، و اشتراک', en: 'Posts, comments, & sharing' },
          badge: { ps: 'فعال', fa: 'فعال', en: 'Active' },
          gradient: 'from-pink-500 to-rose-500',
          action: 'community'
        },
        {
          id: 'share',
          icon: Share2,
          title: { ps: 'شریکول', fa: 'اشتراک‌گذاری', en: 'Share' },
          description: { ps: 'د روغتیا معلومات شریک کړئ', fa: 'اطلاعات سلامتی را به اشتراک بگذارید', en: 'Share health information' },
          badge: { ps: 'آسان', fa: 'آسان', en: 'Easy' },
          gradient: 'from-blue-500 to-cyan-500',
          action: 'share'
        },
        {
          id: 'profile',
          icon: Users,
          title: { ps: 'د کاروونکي پروفایل', fa: 'پروفایل کاربر', en: 'User Profile' },
          description: { ps: 'خپل روغتیا معلومات وساتئ', fa: 'اطلاعات سلامتی خود را ذخیره کنید', en: 'Save your health data' },
          badge: { ps: 'شخصي', fa: 'شخصی', en: 'Personal' },
          gradient: 'from-purple-500 to-pink-500',
          action: 'profile'
        }
      ]
    },
    // Premium Services
    {
      category: { ps: '⭐ Premium خدمات', fa: '⭐ خدمات ویژه', en: '⭐ Premium Services' },
      items: [
        {
          id: 'premium',
          icon: Star,
          title: { ps: 'Premium غړیتوب', fa: 'عضویت ویژه', en: 'Premium Membership' },
          description: { ps: 'ځانګړي فیچرونه او خدمات', fa: 'ویژگی‌ها و خدمات اختصاصی', en: 'Exclusive features & services' },
          badge: { ps: 'VIP', fa: 'VIP', en: 'VIP' },
          gradient: 'from-yellow-400 via-orange-500 to-red-600',
          action: 'premium'
        },
        {
          id: 'consultation',
          icon: Phone,
          title: { ps: 'آنلاین مشورې', fa: 'مشاوره آنلاین', en: 'Online Consultation' },
          description: { ps: 'د دوکتورانو سره مستقیم خبرې', fa: 'گفتگوی مستقیم با دکتران', en: 'Direct talk with doctors' },
          badge: { ps: 'لایو', fa: 'زنده', en: 'Live' },
          gradient: 'from-green-500 to-emerald-600',
          action: 'consultation'
        },
        {
          id: 'appointments',
          icon: Clock,
          title: { ps: 'وخت ټاکل', fa: 'تعیین وقت', en: 'Appointments' },
          description: { ps: 'د دوکتورانو سره وخت ونیسئ', fa: 'با دکتران وقت بگیرید', en: 'Book doctor appointments' },
          badge: { ps: 'آنلاین', fa: 'آنلاین', en: 'Online' },
          gradient: 'from-blue-500 to-indigo-600',
          action: 'appointments'
        }
      ]
    },
    // Security & Support
    {
      category: { ps: '🔒 امنیت او ملاتړ', fa: '🔒 امنیت و پشتیبانی', en: '🔒 Security & Support' },
      items: [
        {
          id: 'security',
          icon: Lock,
          title: { ps: 'امنیتي سیستم', fa: 'سیستم امنیتی', en: 'Security System' },
          description: { ps: '13 پوړونه امنیتي محافظت', fa: '13 لایه حفاظت امنیتی', en: '13 layers of protection' },
          badge: { ps: 'خوندي', fa: 'امن', en: 'Secure' },
          gradient: 'from-green-500 to-teal-600',
          action: 'security'
        },
        {
          id: 'support',
          icon: Phone,
          title: { ps: '24/7 ملاتړ', fa: '24/7 پشتیبانی', en: '24/7 Support' },
          description: { ps: 'هره وخت چمتو یو د مرستې لپاره', fa: 'همیشه آماده برای کمک', en: 'Always ready to help' },
          badge: { ps: 'فوري', fa: 'فوری', en: 'Instant' },
          gradient: 'from-orange-500 to-red-600',
          action: 'contact'
        },
        {
          id: 'multilingual',
          icon: Globe,
          title: { ps: 'درې ژبې', fa: 'سه زبانه', en: 'Trilingual' },
          description: { ps: 'پښتو، دری، او انګلیسي', fa: 'پشتو، دری، و انگلیسی', en: 'Pashto, Dari, & English' },
          badge: { ps: '3', fa: '3', en: '3' },
          gradient: 'from-purple-500 to-pink-600',
          action: 'settings'
        }
      ]
    }
  ];

  return (
    <div className="mb-16">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-center mb-12"
      >
        <h2 className="text-4xl md:text-5xl font-bold mb-4 bg-gradient-to-r from-blue-600 via-purple-600 to-pink-600 bg-clip-text text-transparent">
          {t.title[language]}
        </h2>
        <p className="text-lg text-gray-600 max-w-3xl mx-auto" dir={language === 'en' ? 'ltr' : 'rtl'}>
          {t.subtitle[language]}
        </p>
      </motion.div>

      {/* Features by Category */}
      <div className="space-y-12">
        {features.map((category, categoryIndex) => (
          <motion.div
            key={categoryIndex}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: categoryIndex * 0.1 }}
          >
            {/* Category Title */}
            <h3 className="text-2xl md:text-3xl font-bold mb-6 text-center">
              {category.category[language]}
            </h3>

            {/* Features Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {category.items.map((feature, index) => {
                const Icon = feature.icon;
                
                return (
                  <motion.div
                    key={feature.id}
                    initial={{ opacity: 0, scale: 0.9 }}
                    animate={{ opacity: 1, scale: 1 }}
                    transition={{ delay: categoryIndex * 0.1 + index * 0.05 }}
                    whileHover={{ scale: 1.05, y: -5 }}
                    whileTap={{ scale: 0.95 }}
                    onClick={() => onFeatureClick(feature.action)}
                    className="relative group cursor-pointer"
                  >
                    {/* Glow Effect */}
                    <div className={`absolute inset-0 bg-gradient-to-br ${feature.gradient} rounded-3xl blur-xl opacity-30 group-hover:opacity-50 transition-all`} />
                    
                    {/* Card */}
                    <div className="relative bg-white/90 backdrop-blur-xl rounded-3xl p-6 border border-white/20 shadow-xl hover:shadow-2xl transition-all h-full">
                      {/* Icon */}
                      <div className={`w-16 h-16 bg-gradient-to-br ${feature.gradient} rounded-2xl flex items-center justify-center mb-4 group-hover:scale-110 transition-transform`}>
                        <Icon className="w-8 h-8 text-white" />
                      </div>

                      {/* Badge */}
                      <div className={`absolute top-4 right-4 px-3 py-1 rounded-full text-xs font-bold text-white bg-gradient-to-r ${feature.gradient} shadow-lg`}>
                        {feature.badge[language]}
                      </div>

                      {/* Title */}
                      <h4 className="text-lg font-bold text-gray-800 mb-2" dir={language === 'en' ? 'ltr' : 'rtl'}>
                        {feature.title[language]}
                      </h4>

                      {/* Description */}
                      <p className="text-sm text-gray-600" dir={language === 'en' ? 'ltr' : 'rtl'}>
                        {feature.description[language]}
                      </p>

                      {/* Arrow Indicator */}
                      <div className={`mt-4 flex items-center gap-2 text-sm font-bold bg-gradient-to-r ${feature.gradient} bg-clip-text text-transparent`}>
                        {language === 'ps' ? 'ګورئ' : language === 'fa' ? 'مشاهده' : 'View'}
                        <motion.div
                          animate={{ x: [0, 5, 0] }}
                          transition={{ duration: 1.5, repeat: Infinity }}
                        >
                          →
                        </motion.div>
                      </div>
                    </div>
                  </motion.div>
                );
              })}
            </div>
          </motion.div>
        ))}
      </div>

      {/* Bottom Stats */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.6 }}
        className="mt-16"
      >
        <div className="relative group">
          <div className="absolute inset-0 bg-gradient-to-r from-blue-500 via-purple-500 to-pink-600 rounded-3xl blur-2xl opacity-30" />
          <div className="relative bg-white/90 backdrop-blur-xl rounded-3xl p-8 border border-white/20 shadow-xl">
            <div className="grid grid-cols-2 md:grid-cols-5 gap-6 text-center">
              <div>
                <div className="text-4xl font-bold bg-gradient-to-r from-blue-600 to-cyan-600 bg-clip-text text-transparent mb-2">
                  25+
                </div>
                <div className="text-sm text-gray-600">
                  {language === 'ps' ? 'فیچرونه' : language === 'fa' ? 'ویژگی‌ها' : 'Features'}
                </div>
              </div>
              <div>
                <div className="text-4xl font-bold bg-gradient-to-r from-green-600 to-emerald-600 bg-clip-text text-transparent mb-2">
                  250+
                </div>
                <div className="text-sm text-gray-600">
                  {language === 'ps' ? 'دوکتوران' : language === 'fa' ? 'دکتران' : 'Doctors'}
                </div>
              </div>
              <div>
                <div className="text-4xl font-bold bg-gradient-to-r from-purple-600 to-violet-600 bg-clip-text text-transparent mb-2">
                  1500+
                </div>
                <div className="text-sm text-gray-600">
                  {language === 'ps' ? 'دواګانې' : language === 'fa' ? 'داروها' : 'Medicines'}
                </div>
              </div>
              <div>
                <div className="text-4xl font-bold bg-gradient-to-r from-red-600 to-pink-600 bg-clip-text text-transparent mb-2">
                  24/7
                </div>
                <div className="text-sm text-gray-600">
                  {language === 'ps' ? 'خدمات' : language === 'fa' ? 'خدمات' : 'Services'}
                </div>
              </div>
              <div>
                <div className="text-4xl font-bold bg-gradient-to-r from-orange-600 to-yellow-600 bg-clip-text text-transparent mb-2">
                  4.8⭐
                </div>
                <div className="text-sm text-gray-600">
                  {language === 'ps' ? 'درجه بندي' : language === 'fa' ? 'رتبه‌بندی' : 'Rating'}
                </div>
              </div>
            </div>
          </div>
        </div>
      </motion.div>
    </div>
  );
}
