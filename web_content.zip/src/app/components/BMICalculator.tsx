import { useState } from 'react';
import { motion } from 'motion/react';
import { Calculator, Scale, Ruler, TrendingUp, ArrowLeft, Info } from 'lucide-react';
import { Button } from './ui/button';
import { AdBanner } from './AdBanner';

interface BMICalculatorProps {
  language: 'ps' | 'fa' | 'en';
  onBack: () => void;
}

export function BMICalculator({ language, onBack }: BMICalculatorProps) {
  const [height, setHeight] = useState('');
  const [weight, setWeight] = useState('');
  const [bmi, setBmi] = useState<number | null>(null);
  const [category, setCategory] = useState('');

  const t = {
    title: {
      ps: 'د BMI حساب کوونکی',
      fa: 'محاسبه‌گر BMI',
      en: 'BMI Calculator'
    },
    subtitle: {
      ps: 'د خپل Body Mass Index محاسبه کړئ',
      fa: 'شاخص توده بدن خود را محاسبه کنید',
      en: 'Calculate Your Body Mass Index'
    },
    heightLabel: {
      ps: 'قد (سانتي متره)',
      fa: 'قد (سانتی‌متر)',
      en: 'Height (cm)'
    },
    weightLabel: {
      ps: 'وزن (کیلوګرامه)',
      fa: 'وزن (کیلوگرم)',
      en: 'Weight (kg)'
    },
    calculate: {
      ps: 'محاسبه کړئ',
      fa: 'محاسبه کنید',
      en: 'Calculate'
    },
    result: {
      ps: 'ستاسو BMI',
      fa: 'BMI شما',
      en: 'Your BMI'
    },
    categories: {
      underweight: {
        ps: 'کم وزن',
        fa: 'کم وزن',
        en: 'Underweight'
      },
      normal: {
        ps: 'نورمال وزن',
        fa: 'وزن نرمال',
        en: 'Normal Weight'
      },
      overweight: {
        ps: 'ډیر وزن',
        fa: 'اضافه وزن',
        en: 'Overweight'
      },
      obese: {
        ps: 'چاقي',
        fa: 'چاقی',
        en: 'Obese'
      }
    },
    ranges: {
      ps: 'د BMI حدونه',
      fa: 'محدوده‌های BMI',
      en: 'BMI Ranges'
    },
    info: {
      ps: 'BMI یو معیار دی چې ستاسو د قد او وزن په اساس ستاسو د وزن حالت ښیي. دا یو عمومي لارښود دی او د بدن د اندازې بشپړ معیار نه دی.',
      fa: 'BMI یک معیار است که وضعیت وزن شما را بر اساس قد و وزنتان نشان می‌دهد. این یک راهنمای کلی است و معیار کامل اندازه بدن نیست.',
      en: 'BMI is a measure that shows your weight status based on your height and weight. It is a general guide and not a complete measure of body size.'
    }
  };

  const calculateBMI = () => {
    const h = parseFloat(height) / 100; // Convert to meters
    const w = parseFloat(weight);

    if (h > 0 && w > 0) {
      const bmiValue = w / (h * h);
      setBmi(parseFloat(bmiValue.toFixed(1)));

      // Determine category
      if (bmiValue < 18.5) {
        setCategory('underweight');
      } else if (bmiValue >= 18.5 && bmiValue < 25) {
        setCategory('normal');
      } else if (bmiValue >= 25 && bmiValue < 30) {
        setCategory('overweight');
      } else {
        setCategory('obese');
      }
    }
  };

  const getCategoryColor = (cat: string) => {
    switch (cat) {
      case 'underweight':
        return 'from-blue-500 to-cyan-500';
      case 'normal':
        return 'from-green-500 to-emerald-500';
      case 'overweight':
        return 'from-yellow-500 to-orange-500';
      case 'obese':
        return 'from-red-500 to-pink-500';
      default:
        return 'from-gray-500 to-gray-600';
    }
  };

  const bmiRanges = [
    { range: '< 18.5', category: 'underweight', color: 'bg-blue-500' },
    { range: '18.5 - 24.9', category: 'normal', color: 'bg-green-500' },
    { range: '25 - 29.9', category: 'overweight', color: 'bg-yellow-500' },
    { range: '≥ 30', category: 'obese', color: 'bg-red-500' }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-50 via-purple-50 to-pink-50 pb-28 md:pb-8">
      {/* Header */}
      <div className="sticky top-0 z-40 backdrop-blur-xl bg-white/70 border-b border-white/20 shadow-lg">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center gap-4">
            <Button variant="ghost" size="icon" onClick={onBack}>
              <ArrowLeft className="w-6 h-6" />
            </Button>
            <div className="flex items-center gap-3">
              <div className="bg-gradient-to-br from-purple-500 to-pink-600 p-3 rounded-2xl">
                <Calculator className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-xl bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent">
                  {t.title[language]}
                </h1>
                <p className="text-xs text-gray-600">{t.subtitle[language]}</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-8">
        <AdBanner type="medium" />

        {/* Calculator Card */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white/90 backdrop-blur-xl rounded-3xl p-8 shadow-xl border border-white/20 mb-8"
        >
          <div className="max-w-md mx-auto">
            {/* Height Input */}
            <div className="mb-6">
              <label className="block text-sm font-medium text-gray-700 mb-2 flex items-center gap-2">
                <Ruler className="w-4 h-4 text-purple-600" />
                {t.heightLabel[language]}
              </label>
              <input
                type="number"
                value={height}
                onChange={(e) => setHeight(e.target.value)}
                placeholder="170"
                className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:outline-none focus:ring-2 focus:ring-purple-500 bg-white/50"
              />
            </div>

            {/* Weight Input */}
            <div className="mb-6">
              <label className="block text-sm font-medium text-gray-700 mb-2 flex items-center gap-2">
                <Scale className="w-4 h-4 text-purple-600" />
                {t.weightLabel[language]}
              </label>
              <input
                type="number"
                value={weight}
                onChange={(e) => setWeight(e.target.value)}
                placeholder="70"
                className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:outline-none focus:ring-2 focus:ring-purple-500 bg-white/50"
              />
            </div>

            {/* Calculate Button */}
            <Button
              onClick={calculateBMI}
              className="w-full bg-gradient-to-r from-purple-500 to-pink-600 hover:from-purple-600 hover:to-pink-700 text-white py-6 text-lg"
              disabled={!height || !weight}
            >
              <Calculator className="w-5 h-5 mr-2" />
              {t.calculate[language]}
            </Button>

            {/* Result */}
            {bmi !== null && (
              <motion.div
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                className="mt-8 text-center"
              >
                <div className="mb-4">
                  <div className="text-sm text-gray-600 mb-2">{t.result[language]}</div>
                  <div className={`text-6xl font-bold bg-gradient-to-r ${getCategoryColor(category)} bg-clip-text text-transparent`}>
                    {bmi}
                  </div>
                </div>

                <div className={`inline-block px-6 py-3 rounded-full bg-gradient-to-r ${getCategoryColor(category)} text-white font-bold text-lg shadow-lg`}>
                  {t.categories[category as keyof typeof t.categories][language]}
                </div>
              </motion.div>
            )}
          </div>
        </motion.div>

        {/* BMI Ranges */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="bg-white/90 backdrop-blur-xl rounded-3xl p-8 shadow-xl border border-white/20 mb-8"
        >
          <h2 className="text-2xl mb-6 flex items-center gap-3">
            <TrendingUp className="w-6 h-6 text-purple-600" />
            {t.ranges[language]}
          </h2>

          <div className="space-y-4">
            {bmiRanges.map((item, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.3 + index * 0.1 }}
                className={`flex items-center gap-4 p-4 rounded-2xl ${
                  category === item.category ? 'bg-gradient-to-r from-purple-50 to-pink-50 border-2 border-purple-300' : 'bg-gray-50'
                }`}
              >
                <div className={`w-12 h-12 ${item.color} rounded-xl flex items-center justify-center text-white font-bold`}>
                  {item.range}
                </div>
                <div className="flex-1">
                  <div className="font-bold text-gray-800">
                    {t.categories[item.category as keyof typeof t.categories][language]}
                  </div>
                </div>
                {category === item.category && (
                  <div className="w-3 h-3 bg-purple-600 rounded-full animate-pulse" />
                )}
              </motion.div>
            ))}
          </div>
        </motion.div>

        {/* Info */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          className="bg-blue-50 border border-blue-200 rounded-2xl p-6 flex gap-4"
        >
          <Info className="w-6 h-6 text-blue-600 flex-shrink-0" />
          <p className="text-sm text-gray-700" dir={language === 'en' ? 'ltr' : 'rtl'}>
            {t.info[language]}
          </p>
        </motion.div>

        <div className="mt-8">
          <AdBanner type="large" />
        </div>
      </div>
    </div>
  );
}
