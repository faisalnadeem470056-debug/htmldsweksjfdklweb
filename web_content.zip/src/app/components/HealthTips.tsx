import { ArrowLeft, Heart, Droplets, Moon, Activity, Apple, Brain } from 'lucide-react';
import { motion } from 'motion/react';
import { Button } from './ui/button';
import { translations } from '../translations';
import { AdBanner } from './AdBanner';

interface HealthTipsProps {
  language: 'ps' | 'fa' | 'en';
  onBack: () => void;
}

const healthTips = [
  {
    id: 1,
    title: { ps: 'اوبه وښئ', fa: 'آب بنوشید', en: 'Drink Water' },
    description: {
      ps: 'په ورځ کې لږ تر لږه ۸ ګیلاس اوبه وښئ. اوبه ستاسو د بدن د کار کولو لپاره خورا مهم دي.',
      fa: 'روزانه حداقل ۸ لیوان آب بنوشید. آب برای عملکرد بدن شما بسیار مهم است.',
      en: 'Drink at least 8 glasses of water daily. Water is crucial for your body\'s functions.',
    },
    icon: Droplets,
    color: 'from-blue-500 to-cyan-500',
    category: { ps: 'عمومي روغتیا', fa: 'سلامت عمومی', en: 'General Health' },
  },
  {
    id: 2,
    title: { ps: 'ورزش وکړئ', fa: 'ورزش کنید', en: 'Exercise Regularly' },
    description: {
      ps: 'د ورځې لږ تر لږه ۳۰ دقیقې ورزش وکړئ. دا ستاسو زړه ساتي او انرژي زیاتوي.',
      fa: 'روزانه حداقل ۳۰ دقیقه ورزش کنید. این قلب شما را حفظ می‌کند و انرژی را افزایش می‌دهد.',
      en: 'Exercise for at least 30 minutes daily. This keeps your heart healthy and boosts energy.',
    },
    icon: Activity,
    color: 'from-green-500 to-emerald-500',
    category: { ps: 'فزیکي فعالیت', fa: 'فعالیت فیزیکی', en: 'Physical Activity' },
  },
  {
    id: 3,
    title: { ps: 'کافي خوب وکړئ', fa: 'خواب کافی', en: 'Get Enough Sleep' },
    description: {
      ps: 'په شپه کې ۷-۸ ساعته خوب وکړئ. ښه خوب ستاسو دماغ او بدن ته استراحت ورکوي.',
      fa: 'شبانه ۷-۸ ساعت بخوابید. خواب خوب به مغز و بدن شما استراحت می‌دهد.',
      en: 'Sleep 7-8 hours per night. Good sleep gives your brain and body rest.',
    },
    icon: Moon,
    color: 'from-purple-500 to-violet-500',
    category: { ps: 'خوب', fa: 'خواب', en: 'Sleep' },
  },
  {
    id: 4,
    title: { ps: 'صحي خوراک', fa: 'غذای سالم', en: 'Healthy Diet' },
    description: {
      ps: 'میوې، سابه او دانې وخورئ. د فاسټ فوډ او شکر څخه ډډه وکړئ.',
      fa: 'میوه، سبزیجات و غلات بخورید. از فست فود و قند اجتناب کنید.',
      en: 'Eat fruits, vegetables, and grains. Avoid fast food and sugar.',
    },
    icon: Apple,
    color: 'from-red-500 to-pink-500',
    category: { ps: 'تغذیه', fa: 'تغذیه', en: 'Nutrition' },
  },
  {
    id: 5,
    title: { ps: 'د ذهني روغتیا پاملرنه', fa: 'مراقبت از سلامت روان', en: 'Mental Health Care' },
    description: {
      ps: 'مډیټیشن وکړئ، د خپلوانو سره وخت تیر کړئ، او فشار کم کړئ.',
      fa: 'مدیتیشن کنید، با عزیزان وقت بگذرانید و استرس را کم کنید.',
      en: 'Meditate, spend time with loved ones, and reduce stress.',
    },
    icon: Brain,
    color: 'from-orange-500 to-amber-500',
    category: { ps: 'ذهني روغتیا', fa: 'سلامت روان', en: 'Mental Health' },
  },
  {
    id: 6,
    title: { ps: 'منظم معاینه', fa: 'معاینه منظم', en: 'Regular Checkups' },
    description: {
      ps: 'په کال کې لږ تر لږه یو ځل ډاکټر ته ورشئ د معاینې لپاره.',
      fa: 'سالی حداقل یکبار برای معاینه به پزشک مراجعه کنید.',
      en: 'Visit your doctor at least once a year for checkups.',
    },
    icon: Heart,
    color: 'from-pink-500 to-rose-500',
    category: { ps: 'پروفایلاکسي', fa: 'پیشگیری', en: 'Prevention' },
  },
];

export function HealthTips({ language, onBack }: HealthTipsProps) {
  const t = translations[language];

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 via-emerald-50 to-teal-50 pb-28 md:pb-12">
      {/* Header */}
      <div className="sticky top-[73px] z-30 backdrop-blur-xl bg-white/70 border-b border-white/20 shadow-lg">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center gap-4">
            <Button variant="ghost" size="icon" onClick={onBack}>
              <ArrowLeft className="w-5 h-5" />
            </Button>
            <div>
              <h1 className="text-2xl bg-gradient-to-r from-green-600 to-emerald-600 bg-clip-text text-transparent">
                {t.healthTipsTitle}
              </h1>
              <p className="text-sm text-gray-600">{t.dailyTips}</p>
            </div>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="container mx-auto px-4 mt-6">
        <AdBanner type="medium" className="mb-8" />

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {healthTips.map((tip, index) => {
            const Icon = tip.icon;
            return (
              <motion.div
                key={tip.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                className="relative group"
              >
                <div className={`absolute inset-0 bg-gradient-to-br ${tip.color} opacity-20 rounded-3xl blur-xl group-hover:blur-2xl transition-all`} />
                <div className="relative bg-white/90 backdrop-blur-xl rounded-3xl p-6 border border-white/20 shadow-xl hover:shadow-2xl transition-all h-full flex flex-col">
                  {/* Icon & Title */}
                  <div className="flex items-start gap-4 mb-4">
                    <div className={`w-14 h-14 bg-gradient-to-br ${tip.color} rounded-2xl flex items-center justify-center flex-shrink-0 group-hover:scale-110 transition-transform`}>
                      <Icon className="w-7 h-7 text-white" />
                    </div>
                    <div className="flex-1">
                      <h3 className="text-lg mb-1">{tip.title[language]}</h3>
                      <span className={`inline-block text-xs px-3 py-1 rounded-full bg-gradient-to-r ${tip.color} bg-opacity-10`}>
                        {tip.category[language]}
                      </span>
                    </div>
                  </div>

                  {/* Description */}
                  <p className="text-gray-600 text-sm leading-relaxed flex-1">
                    {tip.description[language]}
                  </p>

                  {/* Decorative element */}
                  <div className={`mt-4 h-1 w-16 bg-gradient-to-r ${tip.color} rounded-full`} />
                </div>
              </motion.div>
            );
          })}
        </div>

        <AdBanner type="large" className="mt-8" />

        {/* Daily Tip Banner */}
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          className="mt-8 relative group"
        >
          <div className="absolute inset-0 bg-gradient-to-r from-green-500 via-emerald-500 to-teal-500 rounded-3xl blur-2xl opacity-30 group-hover:opacity-50 transition-all" />
          <div className="relative bg-gradient-to-r from-green-600 to-emerald-600 rounded-3xl p-8 text-white">
            <h2 className="text-2xl mb-4">
              {language === 'ps' && '💡 د ورځې مشوره'}
              {language === 'fa' && '💡 نکته روز'}
              {language === 'en' && '💡 Tip of the Day'}
            </h2>
            <p className="text-lg opacity-90">
              {language === 'ps' && 'په ورځ کې لږ تر لږه ۱۰ دقیقې آفتاب ته ځان وګورئ. دا ستاسو بدن ته ویتامین D ورکوي چې د هډوکو او معافیت لپاره مهم دي.'}
              {language === 'fa' && 'روزانه حداقل ۱۰ دقیقه در معرض آفتاب قرار بگیرید. این به بدن شما ویتامین D می‌دهد که برای استخوان‌ها و سیستم ایمنی مهم است.'}
              {language === 'en' && 'Get at least 10 minutes of sunlight daily. This gives your body Vitamin D which is important for bones and immunity.'}
            </p>
          </div>
        </motion.div>

        {/* Reminder */}
        <div className="mt-8 p-6 bg-blue-50 border border-blue-200 rounded-2xl text-center">
          <Heart className="w-12 h-12 text-blue-600 mx-auto mb-3" />
          <p className="text-gray-700">
            {language === 'ps' && 'یادونه: دا مشورې عمومي دي. د خاص روغتیا مسلو لپاره خپل ډاکټر سره مشوره وکړئ.'}
            {language === 'fa' && 'یادآوری: این نکات عمومی هستند. برای مشکلات خاص سلامتی با پزشک خود مشورت کنید.'}
            {language === 'en' && 'Reminder: These tips are general. Consult your doctor for specific health issues.'}
          </p>
        </div>
      </div>
    </div>
  );
}
