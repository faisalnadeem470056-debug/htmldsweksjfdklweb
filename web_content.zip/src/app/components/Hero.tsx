import { ImageWithFallback } from "./figma/ImageWithFallback";
import { Button } from "./ui/button";
import { Phone, Search, Sparkles, ArrowRight, CheckCircle2, Award, Users, Clock } from "lucide-react";
import { Badge } from "./ui/badge";

export function Hero() {
  return (
    <section id="home" className="relative min-h-screen flex items-center overflow-hidden bg-gradient-to-br from-slate-50 via-white to-emerald-50">
      {/* Animated Mesh Gradient Background */}
      <div className="absolute inset-0 mesh-gradient opacity-60"></div>
      
      {/* Floating Orbs */}
      <div className="absolute top-20 right-10 w-72 h-72 bg-gradient-to-br from-emerald-400/30 to-teal-500/30 rounded-full blur-3xl animate-float"></div>
      <div className="absolute bottom-20 left-10 w-96 h-96 bg-gradient-to-tr from-cyan-400/20 to-blue-500/20 rounded-full blur-3xl animate-float-slow"></div>
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-gradient-to-r from-violet-400/10 to-purple-400/10 rounded-full blur-3xl animate-blob"></div>
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 py-20 md:py-28">
        <div className="grid lg:grid-cols-2 gap-12 md:gap-16 items-center">
          {/* Left Content */}
          <div className="text-center lg:text-left space-y-8">
            {/* Top Badges */}
            <div className="flex items-center justify-center lg:justify-start gap-3 flex-wrap animate-slide-right">
              <Badge className="bg-gradient-to-r from-emerald-600 via-teal-600 to-cyan-600 text-white px-5 py-2 text-sm shadow-lg hover:shadow-xl transition-shadow animate-gradient neon-glow">
                <Sparkles className="w-4 h-4 mr-2 animate-pulse-glow" />
                #1 Health App in Afghanistan
              </Badge>
              <Badge variant="outline" className="border-2 border-emerald-500 text-emerald-700 bg-white/80 backdrop-blur px-4 py-2">
                د افغانستان روغتیا
              </Badge>
            </div>
            
            {/* Main Heading with Gradient */}
            <div className="space-y-4 animate-slide-up">
              <h1 className="text-5xl md:text-7xl lg:text-8xl leading-[1.1] tracking-tight">
                <span className="block text-gray-900">Your Health,</span>
                <span className="block gradient-text">
                  Our Mission
                </span>
              </h1>
              
              <p className="text-lg md:text-xl text-gray-600 max-w-2xl leading-relaxed">
                Revolutionary healthcare at your fingertips. Connect with certified doctors, monitor your wellness, and access 24/7 emergency care—all in one seamless platform.
              </p>
            </div>
            
            {/* Feature Pills */}
            <div className="flex flex-wrap gap-3 justify-center lg:justify-start animate-slide-right" style={{animationDelay: '0.2s'}}>
              <div className="flex items-center gap-2 bg-white/80 backdrop-blur px-4 py-2 rounded-full shadow-md hover-lift">
                <CheckCircle2 className="w-5 h-5 text-emerald-600" />
                <span className="text-sm">Verified Doctors</span>
              </div>
              <div className="flex items-center gap-2 bg-white/80 backdrop-blur px-4 py-2 rounded-full shadow-md hover-lift">
                <Award className="w-5 h-5 text-emerald-600" />
                <span className="text-sm">ISO Certified</span>
              </div>
              <div className="flex items-center gap-2 bg-white/80 backdrop-blur px-4 py-2 rounded-full shadow-md hover-lift">
                <Clock className="w-5 h-5 text-emerald-600" />
                <span className="text-sm">24/7 Available</span>
              </div>
            </div>
            
            {/* CTA Buttons */}
            <div className="flex flex-col sm:flex-row gap-4 pt-4 animate-scale-in" style={{animationDelay: '0.4s'}}>
              <Button 
                size="lg"
                className="relative overflow-hidden bg-gradient-to-r from-emerald-600 via-teal-600 to-cyan-600 hover:from-emerald-700 hover:via-teal-700 hover:to-cyan-700 text-white shadow-2xl shadow-emerald-600/50 group text-lg px-8 py-6 hover-lift neon-glow"
              >
                <div className="absolute inset-0 animate-shimmer"></div>
                <Search className="w-5 h-5 mr-2 relative z-10" />
                <span className="relative z-10">Find a Doctor</span>
                <ArrowRight className="w-5 h-5 ml-2 group-hover:translate-x-1 transition-transform relative z-10" />
              </Button>
              <Button 
                size="lg"
                variant="outline" 
                className="border-2 border-emerald-600 text-emerald-600 hover:bg-emerald-50 bg-white/80 backdrop-blur shadow-lg text-lg px-8 py-6 hover-lift"
              >
                <Phone className="w-5 h-5 mr-2" />
                Emergency Call
              </Button>
            </div>

            {/* Stats */}
            <div className="grid grid-cols-3 gap-6 pt-8 animate-slide-up" style={{animationDelay: '0.6s'}}>
              <div className="text-center lg:text-left frosted-glass rounded-2xl p-4 hover-lift">
                <div className="flex items-baseline justify-center lg:justify-start gap-1">
                  <p className="text-4xl md:text-5xl gradient-text">500+</p>
                </div>
                <p className="text-sm text-gray-600 mt-1">Happy Patients</p>
              </div>
              <div className="text-center lg:text-left frosted-glass rounded-2xl p-4 hover-lift">
                <div className="flex items-baseline justify-center lg:justify-start gap-1">
                  <p className="text-4xl md:text-5xl gradient-text">50+</p>
                </div>
                <p className="text-sm text-gray-600 mt-1">Expert Doctors</p>
              </div>
              <div className="text-center lg:text-left frosted-glass rounded-2xl p-4 hover-lift">
                <div className="flex items-baseline justify-center lg:justify-start gap-1">
                  <p className="text-4xl md:text-5xl gradient-text">24/7</p>
                </div>
                <p className="text-sm text-gray-600 mt-1">Online Support</p>
              </div>
            </div>
          </div>

          {/* Right Side - Hero Image */}
          <div className="relative animate-scale-in" style={{animationDelay: '0.3s'}}>
            {/* Main Image Card with 3D effect */}
            <div className="relative rounded-[2rem] overflow-hidden shadow-2xl hover-lift group">
              <div className="absolute inset-0 bg-gradient-to-br from-emerald-500/20 to-teal-500/20 z-10 opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
              <ImageWithFallback
                src="https://images.unsplash.com/photo-1758691463198-dc663b8a64e4?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxkb2N0b3IlMjBjb25zdWx0YXRpb24lMjBtZWRpY2FsfGVufDF8fHx8MTc2MzE0NzI2M3ww&ixlib=rb-4.1.0&q=80&w=1080"
                alt="Doctor consultation"
                className="w-full h-[400px] md:h-[600px] object-cover group-hover:scale-105 transition-transform duration-700"
              />
            </div>
            
            {/* Floating Stats Card */}
            <div className="absolute -bottom-8 -left-6 right-6 glass-effect rounded-3xl p-6 shadow-2xl animate-float border-2 border-white/50">
              <div className="flex items-center gap-5">
                <div className="relative">
                  <div className="absolute inset-0 bg-gradient-to-br from-emerald-500 to-teal-600 rounded-2xl animate-pulse-glow"></div>
                  <div className="relative bg-gradient-to-br from-emerald-500 to-teal-600 p-4 rounded-2xl shadow-lg">
                    <Phone className="w-7 h-7 text-white" />
                  </div>
                </div>
                <div className="flex-1">
                  <p className="text-gray-600 text-sm mb-1">24/7 Medical Support</p>
                  <p className="text-emerald-600 text-lg">Always Available</p>
                </div>
                <div className="flex flex-col items-center gap-1">
                  <div className="relative">
                    <div className="w-4 h-4 bg-green-500 rounded-full animate-pulse-glow"></div>
                    <div className="absolute inset-0 w-4 h-4 bg-green-500 rounded-full animate-ping"></div>
                  </div>
                  <span className="text-xs text-gray-600">Online</span>
                </div>
              </div>
            </div>

            {/* Floating Badge Top Right */}
            <div className="absolute -top-4 -right-4 glass-effect rounded-2xl px-5 py-3 shadow-xl animate-float-slow border-2 border-white/50">
              <div className="flex items-center gap-3">
                <div className="flex -space-x-2">
                  <div className="w-8 h-8 rounded-full bg-gradient-to-br from-emerald-400 to-teal-500 border-2 border-white"></div>
                  <div className="w-8 h-8 rounded-full bg-gradient-to-br from-cyan-400 to-blue-500 border-2 border-white"></div>
                  <div className="w-8 h-8 rounded-full bg-gradient-to-br from-violet-400 to-purple-500 border-2 border-white flex items-center justify-center">
                    <Users className="w-4 h-4 text-white" />
                  </div>
                </div>
                <div>
                  <p className="text-xs text-gray-600">Trusted by</p>
                  <p className="text-sm">500+ Families</p>
                </div>
              </div>
            </div>

            {/* Decorative Floating Elements */}
            <div className="absolute top-10 -left-10 w-20 h-20 bg-gradient-to-br from-emerald-400/40 to-teal-500/40 rounded-2xl blur-xl animate-float"></div>
            <div className="absolute bottom-20 -right-10 w-32 h-32 bg-gradient-to-br from-cyan-400/30 to-blue-500/30 rounded-full blur-2xl animate-float-slow"></div>
          </div>
        </div>
      </div>

      {/* Bottom Wave Decoration */}
      <div className="absolute bottom-0 left-0 right-0 h-32 bg-gradient-to-t from-white to-transparent"></div>
    </section>
  );
}
