import React from 'react';
import { Heart, Activity, Stethoscope, Brain, Apple, Baby, Users, AlertCircle } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';

interface HomeProps {
  onNavigate: (page: any) => void;
}

export function Home({ onNavigate }: HomeProps) {
  const { t } = useLanguage();

  const quickCategories = [
    { icon: Stethoscope, label: t('generalCheckup'), color: 'from-blue-500 to-cyan-500' },
    { icon: Heart, label: t('heartHealth'), color: 'from-red-500 to-pink-500' },
    { icon: Activity, label: t('diabetes'), color: 'from-purple-500 to-indigo-500' },
    { icon: Brain, label: t('mentalHealth'), color: 'from-emerald-500 to-teal-500' },
  ];

  return (
    <div className="p-4 space-y-6">
      {/* Welcome Card */}
      <div className="relative overflow-hidden rounded-3xl backdrop-blur-xl bg-gradient-to-br from-white/60 to-white/30 border border-white/20 shadow-2xl p-8">
        <div className="absolute top-0 right-0 w-32 h-32 bg-gradient-to-br from-emerald-400/30 to-blue-400/30 rounded-full blur-3xl"></div>
        <div className="absolute bottom-0 left-0 w-24 h-24 bg-gradient-to-tr from-purple-400/30 to-pink-400/30 rounded-full blur-2xl"></div>
        
        <div className="relative z-10">
          <div className="flex items-center gap-3 mb-4">
            <div className="p-3 bg-gradient-to-r from-emerald-500 to-blue-600 rounded-2xl shadow-lg animate-float">
              <Heart className="w-8 h-8 text-white fill-white" />
            </div>
            <div>
              <h2 className="font-bold text-transparent bg-clip-text bg-gradient-to-r from-emerald-600 to-blue-600">
                {t('welcome')}
              </h2>
            </div>
          </div>
          <p className="text-gray-700">
            {t('welcomeMessage')}
          </p>
        </div>
      </div>

      {/* Quick Access Categories */}
      <div>
        <h3 className="font-semibold text-gray-800 mb-4 px-2">{t('quickAccess')}</h3>
        <div className="grid grid-cols-2 gap-4">
          {quickCategories.map((category, index) => {
            const Icon = category.icon;
            return (
              <button
                key={index}
                onClick={() => onNavigate('categories')}
                className="group relative overflow-hidden rounded-2xl backdrop-blur-xl bg-white/50 border border-white/20 p-6 hover:shadow-2xl transition-all hover:scale-105"
                style={{ animationDelay: `${index * 100}ms` }}
              >
                <div className={`absolute inset-0 bg-gradient-to-br ${category.color} opacity-0 group-hover:opacity-10 transition-opacity`}></div>
                <div className={`inline-flex p-3 rounded-xl bg-gradient-to-br ${category.color} mb-3 shadow-lg group-hover:animate-bounce`}>
                  <Icon className="w-6 h-6 text-white" />
                </div>
                <h4 className="text-sm font-semibold text-gray-800">{category.label}</h4>
              </button>
            );
          })}
        </div>
      </div>

      {/* Explore Button */}
      <button
        onClick={() => onNavigate('categories')}
        className="w-full relative overflow-hidden rounded-2xl backdrop-blur-xl bg-gradient-to-r from-emerald-500 to-blue-600 p-6 shadow-2xl hover:shadow-emerald-500/50 transition-all hover:scale-105 group"
      >
        <div className="absolute inset-0 bg-gradient-to-r from-white/0 via-white/20 to-white/0 translate-x-[-100%] group-hover:translate-x-[100%] transition-transform duration-1000"></div>
        <div className="relative flex items-center justify-center gap-3">
          <Grid3x3 className="w-6 h-6 text-white" />
          <span className="font-semibold text-white">{t('exploreCategories')}</span>
        </div>
      </button>

      {/* Afghanistan Flag Colors Decoration */}
      <div className="flex gap-2 justify-center py-4">
        <div className="w-16 h-2 bg-black rounded-full"></div>
        <div className="w-16 h-2 bg-red-600 rounded-full"></div>
        <div className="w-16 h-2 bg-green-600 rounded-full"></div>
      </div>
    </div>
  );
}

function Grid3x3(props: any) {
  return (
    <svg {...props} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
      <rect x="3" y="3" width="7" height="7" rx="1"/>
      <rect x="14" y="3" width="7" height="7" rx="1"/>
      <rect x="3" y="14" width="7" height="7" rx="1"/>
      <rect x="14" y="14" width="7" height="7" rx="1"/>
    </svg>
  );
}
