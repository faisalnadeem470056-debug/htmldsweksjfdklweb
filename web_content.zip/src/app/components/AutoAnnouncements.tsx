import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Megaphone, 
  Sparkles, 
  Heart, 
  Stethoscope, 
  Pill, 
  Shield,
  Users,
  Activity,
  ChevronLeft,
  ChevronRight
} from 'lucide-react';

interface Announcement {
  id: number;
  icon: any;
  title: {
    ps: string;
    fa: string;
    en: string;
  };
  description: {
    ps: string;
    fa: string;
    en: string;
  };
  color: string;
  bgGradient: string;
}

interface AutoAnnouncementsProps {
  language: 'ps' | 'fa' | 'en';
  interval?: number;
}

export function AutoAnnouncements({ language, interval = 5000 }: AutoAnnouncementsProps) {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isPaused, setIsPaused] = useState(false);

  const announcements: Announcement[] = [
    {
      id: 1,
      icon: Stethoscope,
      title: {
        ps: '🎉 د افغانستان لومړی ډیجیټل روغتیا پلیټفارم',
        fa: '🎉 اولین پلتفرم دیجیتال سلامت افغانستان',
        en: "🎉 Afghanistan's First Digital Health Platform"
      },
      description: {
        ps: '250+ دوکتوران، 1500+ درمل، او 100+ کټګورۍ',
        fa: '250+ دکتران، 1500+ داروها، و 100+ دسته‌بندی',
        en: '250+ Doctors, 1500+ Medicines, & 100+ Categories'
      },
      color: 'from-green-600 to-teal-600',
      bgGradient: 'from-green-50 to-teal-50'
    },
    {
      id: 2,
      icon: Heart,
      title: {
        ps: '❤️ د AI روغتیا مشاور اوس شته',
        fa: '❤️ مشاور سلامت AI اکنون موجود است',
        en: '❤️ AI Health Advisor Now Available'
      },
      description: {
        ps: '24/7 د مصنوعی هوښیارۍ سره روغتیا مشورې',
        fa: '24/7 مشاوره سلامتی با هوش مصنوعی',
        en: '24/7 AI-Powered Health Consultations'
      },
      color: 'from-red-600 to-pink-600',
      bgGradient: 'from-red-50 to-pink-50'
    },
    {
      id: 3,
      icon: Pill,
      title: {
        ps: '💊 د درملو بشپړ معلومات ډیټابیس',
        fa: '💊 پایگاه داده کامل اطلاعات داروها',
        en: '💊 Complete Medicine Information Database'
      },
      description: {
        ps: '1500+ درمل د بشپړ معلوماتو سره',
        fa: '1500+ داروها با اطلاعات کامل',
        en: '1500+ Medicines with Complete Information'
      },
      color: 'from-purple-600 to-violet-600',
      bgGradient: 'from-purple-50 to-violet-50'
    },
    {
      id: 4,
      icon: Shield,
      title: {
        ps: '🚨 د اسعافی مرستې خدمات',
        fa: '🚨 خدمات کمک‌های فوری',
        en: '🚨 Emergency Assistance Services'
      },
      description: {
        ps: 'د ضروری حالاتو لپاره چټک مرسته',
        fa: 'کمک سریع برای موارد اضطراری',
        en: 'Quick Help for Emergency Situations'
      },
      color: 'from-red-600 to-orange-600',
      bgGradient: 'from-red-50 to-orange-50'
    },
    {
      id: 5,
      icon: Users,
      title: {
        ps: '👥 د ټولنیز شبکې فیچرونه',
        fa: '👥 امکانات شبکه اجتماعی',
        en: '👥 Social Network Features'
      },
      description: {
        ps: 'د روغتیا پوسټونه، تبصرې، او شریکول',
        fa: 'پست‌های سلامتی، نظرات، و اشتراک‌گذاری',
        en: 'Health Posts, Comments, & Sharing'
      },
      color: 'from-blue-600 to-cyan-600',
      bgGradient: 'from-blue-50 to-cyan-50'
    },
    {
      id: 6,
      icon: Activity,
      title: {
        ps: '📊 د روغتیا کټګورۍ او معلومات',
        fa: '📊 دسته‌بندی‌ها و اطلاعات سلامتی',
        en: '📊 Health Categories & Information'
      },
      description: {
        ps: '100+ روغتیا کټګورۍ درې ژبو کې',
        fa: '100+ دسته‌بندی سلامتی در سه زبان',
        en: '100+ Health Categories in 3 Languages'
      },
      color: 'from-green-600 to-emerald-600',
      bgGradient: 'from-green-50 to-emerald-50'
    },
    {
      id: 7,
      icon: Sparkles,
      title: {
        ps: '⭐ Premium خدمات شته',
        fa: '⭐ خدمات ویژه موجود است',
        en: '⭐ Premium Services Available'
      },
      description: {
        ps: 'د ځانګړو فیچرونو ته لاسرسی ترلاسه کړئ',
        fa: 'دسترسی به امکانات ویژه را بدست آورید',
        en: 'Get Access to Exclusive Features'
      },
      color: 'from-amber-600 to-yellow-600',
      bgGradient: 'from-amber-50 to-yellow-50'
    }
  ];

  useEffect(() => {
    if (isPaused) return;

    const timer = setInterval(() => {
      setCurrentIndex((prev) => (prev + 1) % announcements.length);
    }, interval);

    return () => clearInterval(timer);
  }, [currentIndex, interval, isPaused, announcements.length]);

  const goToNext = () => {
    setCurrentIndex((prev) => (prev + 1) % announcements.length);
  };

  const goToPrevious = () => {
    setCurrentIndex((prev) => (prev - 1 + announcements.length) % announcements.length);
  };

  const currentAnnouncement = announcements[currentIndex];
  const Icon = currentAnnouncement.icon;

  return (
    <div 
      className="relative overflow-hidden rounded-2xl shadow-lg mb-8"
      onMouseEnter={() => setIsPaused(true)}
      onMouseLeave={() => setIsPaused(false)}
    >
      <AnimatePresence mode="wait">
        <motion.div
          key={currentIndex}
          initial={{ opacity: 0, x: 100 }}
          animate={{ opacity: 1, x: 0 }}
          exit={{ opacity: 0, x: -100 }}
          transition={{ duration: 0.5 }}
          className={`bg-gradient-to-r ${currentAnnouncement.bgGradient} border-2 border-white/50`}
        >
          <div className="relative p-6">
            {/* Background Icon Watermark */}
            <div className="absolute top-1/2 right-8 -translate-y-1/2 opacity-10">
              <Icon className="w-32 h-32" />
            </div>

            <div className="relative z-10 flex items-center gap-4">
              {/* Icon */}
              <motion.div
                initial={{ scale: 0, rotate: -180 }}
                animate={{ scale: 1, rotate: 0 }}
                transition={{ duration: 0.5, type: "spring" }}
                className={`flex-shrink-0 w-16 h-16 bg-gradient-to-br ${currentAnnouncement.color} rounded-2xl flex items-center justify-center shadow-lg`}
              >
                <Icon className="w-8 h-8 text-white" />
              </motion.div>

              {/* Content */}
              <div className={`flex-1 ${language === 'en' ? 'text-left' : 'text-right'}`}>
                <motion.div
                  initial={{ opacity: 0, y: -10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.2 }}
                  className={`text-xl md:text-2xl font-bold bg-gradient-to-r ${currentAnnouncement.color} bg-clip-text text-transparent mb-1`}
                >
                  {currentAnnouncement.title[language]}
                </motion.div>
                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.3 }}
                  className="text-sm md:text-base text-gray-600"
                >
                  {currentAnnouncement.description[language]}
                </motion.div>
              </div>

              {/* Megaphone Icon */}
              <motion.div
                animate={{
                  rotate: [0, -10, 10, -10, 0],
                  scale: [1, 1.1, 1, 1.1, 1]
                }}
                transition={{ duration: 2, repeat: Infinity, repeatDelay: 1 }}
                className="flex-shrink-0 hidden md:block"
              >
                <Megaphone className={`w-10 h-10 bg-gradient-to-r ${currentAnnouncement.color} bg-clip-text text-transparent`} />
              </motion.div>
            </div>

            {/* Progress Bar */}
            <motion.div
              initial={{ width: '0%' }}
              animate={{ width: '100%' }}
              transition={{ duration: interval / 1000, ease: 'linear' }}
              className={`absolute bottom-0 left-0 h-1 bg-gradient-to-r ${currentAnnouncement.color}`}
            />
          </div>
        </motion.div>
      </AnimatePresence>

      {/* Navigation Buttons */}
      <button
        onClick={goToPrevious}
        className="absolute left-2 top-1/2 -translate-y-1/2 z-20 bg-white/90 hover:bg-white p-2 rounded-full shadow-lg transition-all hover:scale-110"
        aria-label="Previous"
      >
        <ChevronLeft className="w-5 h-5 text-gray-700" />
      </button>
      <button
        onClick={goToNext}
        className="absolute right-2 top-1/2 -translate-y-1/2 z-20 bg-white/90 hover:bg-white p-2 rounded-full shadow-lg transition-all hover:scale-110"
        aria-label="Next"
      >
        <ChevronRight className="w-5 h-5 text-gray-700" />
      </button>

      {/* Dots Indicator */}
      <div className="absolute bottom-2 left-1/2 -translate-x-1/2 z-20 flex gap-1.5 bg-white/80 backdrop-blur-sm px-3 py-1.5 rounded-full">
        {announcements.map((_, index) => (
          <button
            key={index}
            onClick={() => setCurrentIndex(index)}
            className={`transition-all rounded-full ${
              index === currentIndex
                ? 'w-6 h-2 bg-gradient-to-r ' + currentAnnouncement.color
                : 'w-2 h-2 bg-gray-300 hover:bg-gray-400'
            }`}
            aria-label={`Go to announcement ${index + 1}`}
          />
        ))}
      </div>
    </div>
  );
}
