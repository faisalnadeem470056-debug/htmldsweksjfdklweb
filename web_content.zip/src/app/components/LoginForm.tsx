import { useState } from "react";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Label } from "./ui/label";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "./ui/card";
import { Alert, AlertDescription } from "./ui/alert";
import { Eye, EyeOff, Mail, Lock, LogIn, AlertCircle, Loader2 } from "lucide-react";
import { useAuth } from "../contexts/AuthContext";
import { useLanguage } from "../contexts/LanguageContext";
import { toast } from "sonner";

interface LoginFormProps {
  onSwitchToSignup: () => void;
  onSwitchToForgot: () => void;
  onSuccess: () => void;
}

export function LoginForm({ onSwitchToSignup, onSwitchToForgot, onSuccess }: LoginFormProps) {
  const { login } = useAuth();
  const { language } = useLanguage();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState("");
  const [isLoading, setIsLoading] = useState(false);

  const translations = {
    en: {
      title: "Welcome Back",
      subtitle: "Sign in to your HealMate account",
      email: "Email Address",
      emailPlaceholder: "your.email@example.com",
      password: "Password",
      passwordPlaceholder: "Enter your password",
      forgotPassword: "Forgot Password?",
      loginButton: "Sign In",
      loggingIn: "Signing in...",
      noAccount: "Don't have an account?",
      signUp: "Sign Up",
    },
    dari: {
      title: "خوش آمدید",
      subtitle: "به حساب HealMate خود وارد شوید",
      email: "ایمیل آدرس",
      emailPlaceholder: "your.email@example.com",
      password: "رمز عبور",
      passwordPlaceholder: "رمز عبور خود را وارد کنید",
      forgotPassword: "رمز عبور را فراموش کردید؟",
      loginButton: "ورود",
      loggingIn: "در حال ورود...",
      noAccount: "حساب ندارید؟",
      signUp: "ثبت نام",
    },
    pashto: {
      title: "بیرته راغلاست",
      subtitle: "خپل HealMate حساب ته ننوځئ",
      email: "ایمیل آدرس",
      emailPlaceholder: "your.email@example.com",
      password: "پاسورډ",
      passwordPlaceholder: "خپل پاسورډ ولیکئ",
      forgotPassword: "پاسورډ مو هیر دی؟",
      loginButton: "ننوتل",
      loggingIn: "ننوتل کیږي...",
      noAccount: "حساب نلرئ؟",
      signUp: "راجستر",
    },
  };

  const t = translations[language as keyof typeof translations] || translations.en;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    setIsLoading(true);

    // د email او password trim کړئ
    const trimmedEmail = email.trim();
    const trimmedPassword = password.trim();

    if (!trimmedEmail || !trimmedPassword) {
      setError("Please fill in all fields");
      setIsLoading(false);
      return;
    }

    const result = await login(trimmedEmail, trimmedPassword);
    
    if (result.success) {
      toast.success(`${t.title}! Welcome to HealMate 🎉`);
      
      // د form values reset کړئ
      setEmail("");
      setPassword("");
      
      onSuccess();
    } else {
      setError(result.error || "Login failed");
      toast.error(result.error || "Login failed");
    }
    
    setIsLoading(false);
  };

  return (
    <Card className="glass-effect border-2 border-emerald-200 shadow-2xl">
      <CardHeader className="space-y-3 text-center">
        <div className="mx-auto w-16 h-16 bg-gradient-to-br from-emerald-500 to-blue-500 rounded-full flex items-center justify-center shadow-lg">
          <LogIn className="w-8 h-8 text-white" />
        </div>
        <CardTitle className="text-3xl gradient-text">{t.title}</CardTitle>
        <CardDescription className="text-base">{t.subtitle}</CardDescription>
      </CardHeader>

      <CardContent className="space-y-6">
        {error && (
          <Alert className="bg-red-50 border-red-200">
            <AlertCircle className="h-4 w-4 text-red-600" />
            <AlertDescription className="text-red-800">{error}</AlertDescription>
          </Alert>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          {/* Email */}
          <div className="space-y-2">
            <Label htmlFor="email">{t.email}</Label>
            <div className="relative">
              <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
              <Input
                id="email"
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder={t.emailPlaceholder}
                className="pl-10"
                disabled={isLoading}
                required
              />
            </div>
          </div>

          {/* Password */}
          <div className="space-y-2">
            <Label htmlFor="password">{t.password}</Label>
            <div className="relative">
              <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
              <Input
                id="password"
                type={showPassword ? "text" : "password"}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder={t.passwordPlaceholder}
                className="pl-10 pr-12"
                disabled={isLoading}
                required
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500 hover:text-gray-700"
              >
                {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
              </button>
            </div>
          </div>

          {/* Forgot Password */}
          <div className="flex justify-end">
            <button
              type="button"
              onClick={onSwitchToForgot}
              className="text-sm text-emerald-600 hover:text-emerald-700 hover:underline"
            >
              {t.forgotPassword}
            </button>
          </div>

          {/* Login Button */}
          <Button
            type="submit"
            className="w-full bg-gradient-to-r from-emerald-500 to-blue-500 hover:from-emerald-600 hover:to-blue-600"
            size="lg"
            disabled={isLoading}
          >
            {isLoading ? (
              <>
                <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                {t.loggingIn}
              </>
            ) : (
              <>
                <LogIn className="w-5 h-5 mr-2" />
                {t.loginButton}
              </>
            )}
          </Button>
        </form>

        {/* Sign Up Link */}
        <div className="text-center pt-4 border-t">
          <p className="text-sm text-gray-600">
            {t.noAccount}{" "}
            <button
              onClick={onSwitchToSignup}
              className="text-emerald-600 hover:text-emerald-700 hover:underline"
            >
              {t.signUp}
            </button>
          </p>
        </div>

        {/* Info & Security Notes */}
        <div className="space-y-2">
          <div className="p-3 bg-gradient-to-r from-blue-50 to-cyan-50 border border-blue-200 rounded-lg">
            <p className="text-xs text-blue-900 text-center">
              ℹ️ نوی کاروونکی یاست؟ لومړی Sign Up وکړئ<br/>
              <span className="text-blue-700">New user? Please Sign Up first</span><br/>
              <span className="text-blue-700 text-[10px]">کاربر جدید؟ ابتدا ثبت نام کنید</span>
            </p>
          </div>
          
          <div className="p-3 bg-gradient-to-r from-purple-50 to-pink-50 border border-purple-200 rounded-lg">
            <p className="text-xs text-purple-900 text-center">
              🔒 د خپل ایمیل او پاسورډ خوندي وساتئ<br/>
              <span className="text-purple-700">Keep your email and password safe</span>
            </p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
