import { ArrowLeft, Target, Eye, Users, Heart, Shield, Award, Globe } from 'lucide-react';
import { motion } from 'motion/react';
import { Button } from './ui/button';
import { translations } from '../translations';
import { AdBanner } from './AdBanner';
import Logo from './Logo';

interface AboutUsProps {
  language: 'ps' | 'fa' | 'en';
  onBack: () => void;
}

export function AboutUs({ language, onBack }: AboutUsProps) {
  const t = translations[language];

  const values = [
    {
      icon: Heart,
      title: { ps: 'خدمت', fa: 'خدمت', en: 'Service' },
      description: {
        ps: 'موږ د خلکو روغتیا ته وقف شوي یو',
        fa: 'ما به سلامت مردم اختصاص داده شده‌ایم',
        en: 'We are dedicated to people\'s health',
      },
      color: 'from-red-500 to-pink-600',
    },
    {
      icon: Shield,
      title: { ps: 'باور', fa: 'اعتماد', en: 'Trust' },
      description: {
        ps: 'ستاسو معلومات په خوندي ډول ساتل کیږي',
        fa: 'اطلاعات شما به طور ایمن نگهداری می‌شود',
        en: 'Your information is kept securely',
      },
      color: 'from-blue-500 to-cyan-600',
    },
    {
      icon: Award,
      title: { ps: 'کیفیت', fa: 'کیفیت', en: 'Quality' },
      description: {
        ps: 'موږ د لوړ کیفیت خدمات وړاندې کوو',
        fa: 'ما خدمات با کیفیت بالا ارائه می‌دهیم',
        en: 'We provide high-quality services',
      },
      color: 'from-green-500 to-emerald-600',
    },
  ];

  const team = [
    {
      name: { ps: 'ډاکټر ابراهیم خاکسار', fa: 'داکتر ابراهیم خاکسار', en: 'Dr. Ibrahim Khaksar' },
      role: { ps: 'بنسټګر او CEO', fa: 'بنیانگذار و CEO', en: 'Founder & CEO' },
      avatar: '👨‍💼',
      color: 'from-purple-500 to-violet-600',
    },
    {
      name: { ps: 'HealMate ټیم', fa: 'تیم HealMate', en: 'HealMate Team' },
      role: { ps: 'پراختیایي ټیم', fa: 'تیم توسعه', en: 'Development Team' },
      avatar: '👥',
      color: 'from-blue-500 to-cyan-600',
    },
    {
      name: { ps: 'روغتیا متخصصین', fa: 'متخصصین سلامت', en: 'Health Professionals' },
      role: { ps: 'روغتیا متخصصین', fa: 'متخصصین سلامت', en: 'Health Experts' },
      avatar: '👨‍⚕️',
      color: 'from-green-500 to-emerald-600',
    },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-50 via-purple-50 to-pink-50 pb-28 md:pb-12">
      {/* Header */}
      <div className="sticky top-[73px] z-30 backdrop-blur-xl bg-white/70 border-b border-white/20 shadow-lg">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center gap-4">
            <Button variant="ghost" size="icon" onClick={onBack}>
              <ArrowLeft className="w-5 h-5" />
            </Button>
            <div>
              <h1 className="text-2xl bg-gradient-to-r from-indigo-600 to-purple-600 bg-clip-text text-transparent">
                {t.aboutUs}
              </h1>
              <p className="text-sm text-gray-600">HealMate - {t.tagline}</p>
            </div>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="container mx-auto px-4 mt-6 max-w-6xl">
        {/* Hero Section */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="relative group mb-12"
        >
          <div className="absolute inset-0 bg-gradient-to-br from-indigo-500 via-purple-600 to-pink-600 rounded-3xl blur-2xl opacity-30 group-hover:opacity-40 transition-all" />
          <div className="relative bg-white/90 backdrop-blur-xl rounded-3xl p-12 border border-white/20 shadow-2xl text-center">
            <motion.div
              animate={{ y: [0, -10, 0] }}
              transition={{ duration: 3, repeat: Infinity, ease: "easeInOut" }}
              className="inline-block mb-6"
            >
              <Logo size="2xl" showText={false} className="mx-auto" />
            </motion.div>
            <h2 className="text-3xl md:text-4xl mb-4 font-bold text-gray-900">
              HealMate
            </h2>
            <p className="text-lg text-gray-600 max-w-3xl mx-auto">
              {t.description}
            </p>
          </div>
        </motion.div>

        <AdBanner type="medium" className="mb-12" />

        {/* Mission & Vision */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-12">
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            className="relative group"
          >
            <div className="absolute inset-0 bg-gradient-to-br from-blue-500 to-cyan-600 rounded-3xl blur-xl opacity-30 group-hover:opacity-50 transition-all" />
            <div className="relative bg-white/90 backdrop-blur-xl rounded-3xl p-8 border border-white/20 shadow-xl h-full">
              <div className="w-16 h-16 bg-gradient-to-br from-blue-500 to-cyan-600 rounded-2xl flex items-center justify-center mb-6">
                <Target className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-2xl mb-4">{t.ourMission}</h3>
              <p className="text-gray-600 leading-relaxed" dir={language === 'en' ? 'ltr' : 'rtl'}>
                {t.missionText}
              </p>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            className="relative group"
          >
            <div className="absolute inset-0 bg-gradient-to-br from-purple-500 to-pink-600 rounded-3xl blur-xl opacity-30 group-hover:opacity-50 transition-all" />
            <div className="relative bg-white/90 backdrop-blur-xl rounded-3xl p-8 border border-white/20 shadow-xl h-full">
              <div className="w-16 h-16 bg-gradient-to-br from-purple-500 to-pink-600 rounded-2xl flex items-center justify-center mb-6">
                <Eye className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-2xl mb-4">{t.ourVision}</h3>
              <p className="text-gray-600 leading-relaxed" dir={language === 'en' ? 'ltr' : 'rtl'}>
                {t.visionText}
              </p>
            </div>
          </motion.div>
        </div>

        {/* Values */}
        <div className="mb-12">
          <h2 className="text-2xl mb-8 text-center">
            {language === 'ps' && 'زموږ ارزښتونه'}
            {language === 'fa' && 'ارزش‌های ما'}
            {language === 'en' && 'Our Values'}
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {values.map((value, index) => {
              const Icon = value.icon;
              return (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.1 }}
                  className="relative group"
                >
                  <div className={`absolute inset-0 bg-gradient-to-br ${value.color} opacity-20 rounded-3xl blur-xl group-hover:blur-2xl transition-all`} />
                  <div className="relative bg-white/90 backdrop-blur-xl rounded-3xl p-6 border border-white/20 shadow-xl hover:shadow-2xl transition-all text-center h-full">
                    <div className={`w-16 h-16 bg-gradient-to-br ${value.color} rounded-2xl flex items-center justify-center mx-auto mb-4 group-hover:scale-110 transition-transform`}>
                      <Icon className="w-8 h-8 text-white" />
                    </div>
                    <h3 className="text-xl mb-3">{value.title[language]}</h3>
                    <p className="text-gray-600" dir={language === 'en' ? 'ltr' : 'rtl'}>
                      {value.description[language]}
                    </p>
                  </div>
                </motion.div>
              );
            })}
          </div>
        </div>

        <AdBanner type="large" className="mb-12" />

        {/* Team */}
        <div className="mb-12">
          <h2 className="text-2xl mb-8 text-center">{t.ourTeam}</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
            {team.map((member, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: index * 0.1 }}
                className="relative group"
              >
                <div className={`absolute inset-0 bg-gradient-to-br ${member.color} opacity-20 rounded-3xl blur-xl group-hover:blur-2xl transition-all`} />
                <div className="relative bg-white/90 backdrop-blur-xl rounded-3xl p-8 border border-white/20 shadow-xl hover:shadow-2xl transition-all text-center">
                  <div className="text-6xl mb-4">{member.avatar}</div>
                  <h3 className="text-lg mb-2">{member.name[language]}</h3>
                  <p className="text-sm text-gray-600">{member.role[language]}</p>
                </div>
              </motion.div>
            ))}
          </div>
          <p className="text-center text-gray-600" dir={language === 'en' ? 'ltr' : 'rtl'}>
            {t.teamText}
          </p>
        </div>

        {/* Stats */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="relative group"
        >
          <div className="absolute inset-0 bg-gradient-to-r from-green-500 via-blue-500 to-purple-600 rounded-3xl blur-2xl opacity-30" />
          <div className="relative bg-white/90 backdrop-blur-xl rounded-3xl p-12 border border-white/20 shadow-2xl">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
              <div className="text-center">
                <div className="text-4xl mb-2 bg-gradient-to-r from-blue-600 to-cyan-600 bg-clip-text text-transparent">
                  250+
                </div>
                <p className="text-sm text-gray-600">{t.stats.doctors}</p>
              </div>
              <div className="text-center">
                <div className="text-4xl mb-2 bg-gradient-to-r from-red-600 to-pink-600 bg-clip-text text-transparent">
                  150+
                </div>
                <p className="text-sm text-gray-600">{t.stats.hospitals}</p>
              </div>
              <div className="text-center">
                <div className="text-4xl mb-2 bg-gradient-to-r from-green-600 to-emerald-600 bg-clip-text text-transparent">
                  10K+
                </div>
                <p className="text-sm text-gray-600">{t.stats.users}</p>
              </div>
              <div className="text-center">
                <div className="text-4xl mb-2 bg-gradient-to-r from-purple-600 to-violet-600 bg-clip-text text-transparent">
                  4.8
                </div>
                <p className="text-sm text-gray-600">{t.stats.rating}</p>
              </div>
            </div>
          </div>
        </motion.div>

        {/* Developer Info with Website */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="relative group mt-12"
        >
          <div className="absolute inset-0 bg-gradient-to-r from-indigo-500 to-blue-500 rounded-3xl blur-2xl opacity-30" />
          <div className="relative bg-white/90 backdrop-blur-xl rounded-3xl p-8 border border-white/20 shadow-2xl">
            <div className="text-center">
              <div className="w-20 h-20 bg-gradient-to-br from-indigo-500 to-blue-600 rounded-full flex items-center justify-center mx-auto mb-4">
                <Globe className="w-10 h-10 text-white" />
              </div>
              <h3 className="text-2xl mb-2">
                {language === 'ps' && 'پراختیا کوونکی'}
                {language === 'fa' && 'توسعه‌دهنده'}
                {language === 'en' && 'Developer'}
              </h3>
              <p className="text-lg font-medium mb-3">
                {language === 'ps' && 'ډاکټر ابراهیم خاکسار'}
                {language === 'fa' && 'داکتر ابراهیم خاکسار'}
                {language === 'en' && 'Dr. Ibrahim Khaksar'}
              </p>
              <p className="text-gray-600 mb-4">
                {language === 'ps' && 'د HealMate اپلیکیشن بنسټګر او پراختیا کوونکی'}
                {language === 'fa' && 'بنیانگذار و توسعه‌دهنده اپلیکیشن HealMate'}
                {language === 'en' && 'Founder and Developer of HealMate App'}
              </p>
              <div className="flex flex-col gap-3">
                <button
                  onClick={() => window.open('https://www.Ibrahimkhaksar.com', '_blank')}
                  className="inline-flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-indigo-600 to-blue-600 text-white rounded-xl hover:from-indigo-700 hover:to-blue-700 transition-all shadow-lg hover:shadow-xl"
                >
                  <Globe className="w-5 h-5" />
                  <span>www.Ibrahimkhaksar.com</span>
                </button>
                <button
                  onClick={() => window.open('https://wa.me/93779494512', '_blank')}
                  className="inline-flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-green-500 to-green-600 text-white rounded-xl hover:from-green-600 hover:to-green-700 transition-all shadow-lg hover:shadow-xl"
                >
                  <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
                    <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413Z"/>
                  </svg>
                  <span>+93 779 494 512 (WhatsApp)</span>
                </button>
              </div>
              <div className="mt-4 text-sm text-gray-500">
                ibrahimkhaksar.it@gmail.com
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </div>
  );
}