// Firebase Settings Component - 2025 Modern Design
// د Firebase ترتیباتو کمپوننټ - ۲۰۲۵ مدرن ډیزاین

import { useState, useEffect } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { firebaseManager } from '../utils/FirebaseManager';
import { checkFirebaseStatus } from '../config/firebase-config';
import { SimpleButton as Button } from './SimpleButton';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Cloud, 
  Database, 
  CheckCircle2, 
  XCircle, 
  ArrowUpCircle, 
  ArrowDownCircle,
  RefreshCw,
  Wifi,
  WifiOff,
  AlertCircle,
  Server,
  HardDrive,
  Zap,
  Shield,
  Activity,
  TrendingUp,
  Check,
  X
} from 'lucide-react';
import { toast } from 'sonner@2.0.3';

interface FirebaseSettingsProps {
  language: 'ps' | 'fa' | 'en';
  darkMode?: boolean;
  onClose?: () => void;
}

export function FirebaseSettings({ language, darkMode = false, onClose }: FirebaseSettingsProps) {
  const { isFirebaseMode, syncToFirebase, syncFromFirebase } = useAuth();
  const [firebaseStatus, setFirebaseStatus] = useState({
    configured: false,
    connected: false,
    error: ''
  });
  const [isChecking, setIsChecking] = useState(false);
  const [isSyncing, setIsSyncing] = useState(false);
  const [showSuccessMessage, setShowSuccessMessage] = useState('');
  const [lastSyncTime, setLastSyncTime] = useState<string | null>(null);

  // د Firebase حالت چیک کړئ
  useEffect(() => {
    checkStatus();
    
    // د آخرین sync وخت واخلئ
    const savedSyncTime = localStorage.getItem('healmate_last_sync_time');
    if (savedSyncTime) {
      setLastSyncTime(savedSyncTime);
    }
  }, []);

  const checkStatus = async () => {
    setIsChecking(true);
    try {
      const status = await checkFirebaseStatus();
      setFirebaseStatus(status);
    } catch (error) {
      console.error('Firebase status check error:', error);
    } finally {
      setIsChecking(false);
    }
  };

  // د LocalStorage څخه Firebase ته sync
  const handleSyncToFirebase = async () => {
    if (!firebaseStatus.connected) {
      toast.error(
        language === 'ps' ? 'Firebase وصل نه دی!' :
        language === 'fa' ? 'Firebase متصل نیست!' :
        'Firebase is not connected!'
      );
      return;
    }

    setIsSyncing(true);
    try {
      await syncToFirebase();
      const currentTime = new Date().toISOString();
      localStorage.setItem('healmate_last_sync_time', currentTime);
      setLastSyncTime(currentTime);
      
      showSuccess(
        language === 'ps' ? '✅ معلومات Firebase ته Upload شول!' :
        language === 'fa' ? '✅ داده‌ها به Firebase آپلود شدند!' :
        '✅ Data uploaded to Firebase!'
      );
    } catch (error) {
      console.error('Sync to Firebase error:', error);
    } finally {
      setIsSyncing(false);
    }
  };

  // د Firebase څخه LocalStorage ته sync
  const handleSyncFromFirebase = async () => {
    if (!firebaseStatus.connected) {
      toast.error(
        language === 'ps' ? 'Firebase وصل نه دی!' :
        language === 'fa' ? 'Firebase متصل نیست!' :
        'Firebase is not connected!'
      );
      return;
    }

    setIsSyncing(true);
    try {
      await syncFromFirebase();
      const currentTime = new Date().toISOString();
      localStorage.setItem('healmate_last_sync_time', currentTime);
      setLastSyncTime(currentTime);
      
      showSuccess(
        language === 'ps' ? '✅ معلومات Firebase څخه Download شول!' :
        language === 'fa' ? '✅ داده‌ها از Firebase دانلود شدند!' :
        '✅ Data downloaded from Firebase!'
      );
    } catch (error) {
      console.error('Sync from Firebase error:', error);
    } finally {
      setIsSyncing(false);
    }
  };

  const showSuccess = (message: string) => {
    setShowSuccessMessage(message);
    setTimeout(() => setShowSuccessMessage(''), 3000);
  };

  const formatSyncTime = (isoString: string | null) => {
    if (!isoString) return language === 'ps' ? 'هیڅکله' : language === 'fa' ? 'هرگز' : 'Never';
    
    const date = new Date(isoString);
    const now = new Date();
    const diffMs = now.getTime() - date.getTime();
    const diffMins = Math.floor(diffMs / 60000);
    
    if (diffMins < 1) return language === 'ps' ? 'اوس' : language === 'fa' ? 'اکنون' : 'Just now';
    if (diffMins < 60) return `${diffMins} ${language === 'ps' ? 'دقیقې وړاندې' : language === 'fa' ? 'دقیقه پیش' : 'mins ago'}`;
    
    const diffHours = Math.floor(diffMins / 60);
    if (diffHours < 24) return `${diffHours} ${language === 'ps' ? 'ساعته وړاندې' : language === 'fa' ? 'ساعت پیش' : 'hours ago'}`;
    
    const diffDays = Math.floor(diffHours / 24);
    return `${diffDays} ${language === 'ps' ? 'ورځې وړاندې' : language === 'fa' ? 'روز پیش' : 'days ago'}`;
  };

  const translations = {
    en: {
      title: 'Firebase Cloud Sync',
      subtitle: 'Manage your cloud data and sync settings',
      status: 'Connection Status',
      configured: 'Configured',
      notConfigured: 'Not Configured',
      connected: 'Connected',
      disconnected: 'Disconnected',
      currentMode: 'Current Storage Mode',
      localStorage: 'Local Storage',
      firebaseMode: 'Cloud Storage',
      syncToCloud: 'Upload to Cloud',
      syncFromCloud: 'Download from Cloud',
      refreshStatus: 'Refresh',
      syncingData: 'Syncing...',
      configureInstructions: 'Firebase is not configured. Using local storage only.',
      error: 'Error',
      lastSync: 'Last Sync',
      syncNow: 'Sync Now',
      dataInfo: 'Data Information',
      uploadDesc: 'Upload your data from device to Firebase cloud',
      downloadDesc: 'Download your data from Firebase to device',
      autoSync: 'Auto Sync',
      manualSync: 'Manual Sync',
      close: 'Close'
    },
    ps: {
      title: 'د Firebase Cloud Sync',
      subtitle: 'خپل د Cloud معلومات او Sync ترتیبات اداره کړئ',
      status: 'د وصل والي حالت',
      configured: 'ترتیب شوی',
      notConfigured: 'ترتیب نه دی شوی',
      connected: 'وصل دی',
      disconnected: 'وصل نه دی',
      currentMode: 'د اوسني ذخیره کولو حالت',
      localStorage: 'محلي ذخیره',
      firebaseMode: 'Cloud ذخیره',
      syncToCloud: 'Cloud ته Upload کړئ',
      syncFromCloud: 'Cloud څخه Download کړئ',
      refreshStatus: 'تازه کړئ',
      syncingData: 'Sync کیږي...',
      configureInstructions: 'Firebase ترتیب شوی نه دی. یوازې محلي ذخیره کارول کیږي.',
      error: 'تېروتنه',
      lastSync: 'وروستی Sync',
      syncNow: 'اوس Sync کړئ',
      dataInfo: 'د معلوماتو معلومات',
      uploadDesc: 'خپل معلومات د دیوایس څخه Firebase Cloud ته Upload کړئ',
      downloadDesc: 'خپل معلومات د Firebase څخه دیوایس ته Download کړئ',
      autoSync: 'اتوماتیک Sync',
      manualSync: 'د لاسي Sync',
      close: 'بندول'
    },
    fa: {
      title: 'همگام‌سازی ابری Firebase',
      subtitle: 'مدیریت داده‌های ابری و تنظیمات همگام‌سازی',
      status: 'وضعیت اتصال',
      configured: 'پیکربندی شده',
      notConfigured: 'پیکربندی نشده',
      connected: 'متصل',
      disconnected: 'قطع شده',
      currentMode: 'حالت ذخیره‌سازی فعلی',
      localStorage: 'ذخیره محلی',
      firebaseMode: 'ذخیره ابری',
      syncToCloud: 'آپلود به Cloud',
      syncFromCloud: 'دانلود از Cloud',
      refreshStatus: 'بروزرسانی',
      syncingData: 'در حال همگام‌سازی...',
      configureInstructions: 'Firebase پیکربندی نشده است. فقط ذخیره محلی استفاده می‌شود.',
      error: 'خطا',
      lastSync: 'آخرین همگام‌سازی',
      syncNow: 'همگام‌سازی کنید',
      dataInfo: 'اطلاعات داده',
      uploadDesc: 'داده‌های خود را از دستگاه به ابر Firebase آپلود کنید',
      downloadDesc: 'داده‌های خود را از Firebase به دستگاه دانلود کنید',
      autoSync: 'همگام‌سازی خودکار',
      manualSync: 'همگام‌سازی دستی',
      close: 'بستن'
    }
  };

  const txt = translations[language];

  return (
    <div className={`w-full h-full overflow-auto ${darkMode ? 'dark' : ''}`}>
      {/* Animated Background Mesh */}
      <div className="fixed inset-0 pointer-events-none overflow-hidden">
        <motion.div 
          animate={{
            scale: [1, 1.2, 1],
            rotate: [0, 90, 0],
          }}
          transition={{
            duration: 20,
            repeat: Infinity,
            ease: "linear"
          }}
          className={`absolute -top-1/4 -left-1/4 w-1/2 h-1/2 rounded-full blur-3xl opacity-20 ${
            darkMode ? 'bg-blue-600' : 'bg-blue-400'
          }`} 
        />
        <motion.div 
          animate={{
            scale: [1, 1.3, 1],
            rotate: [0, -90, 0],
          }}
          transition={{
            duration: 25,
            repeat: Infinity,
            ease: "linear"
          }}
          className={`absolute -bottom-1/4 -right-1/4 w-1/2 h-1/2 rounded-full blur-3xl opacity-20 ${
            darkMode ? 'bg-purple-600' : 'bg-purple-400'
          }`} 
        />
        <motion.div 
          animate={{
            scale: [1, 1.1, 1],
            x: [0, 100, 0],
            y: [0, -100, 0],
          }}
          transition={{
            duration: 30,
            repeat: Infinity,
            ease: "linear"
          }}
          className={`absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-96 h-96 rounded-full blur-3xl opacity-10 ${
            darkMode ? 'bg-indigo-600' : 'bg-indigo-400'
          }`} 
        />
      </div>

      {/* Success Notification */}
      <AnimatePresence>
        {showSuccessMessage && (
          <motion.div
            initial={{ opacity: 0, y: -50, scale: 0.9 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -50, scale: 0.9 }}
            className="fixed top-4 left-1/2 -translate-x-1/2 z-50 px-6 py-4 rounded-2xl shadow-2xl backdrop-blur-xl border"
            style={{
              background: darkMode 
                ? 'linear-gradient(135deg, rgba(34, 197, 94, 0.2), rgba(16, 185, 129, 0.2))'
                : 'linear-gradient(135deg, rgba(34, 197, 94, 0.95), rgba(16, 185, 129, 0.95))',
              borderColor: darkMode ? 'rgba(34, 197, 94, 0.3)' : 'rgba(255, 255, 255, 0.3)'
            }}
          >
            <div className="flex items-center gap-3">
              <div className="w-6 h-6 bg-white rounded-full flex items-center justify-center">
                <Check className="w-4 h-4 text-green-600" />
              </div>
              <span className="font-medium text-white">
                {showSuccessMessage}
              </span>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Main Content */}
      <div className="container mx-auto p-6 max-w-4xl relative z-10">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-8"
        >
          <div className="flex items-center justify-center gap-3 mb-2">
            <motion.div
              animate={{
                rotate: [0, 360],
                scale: [1, 1.1, 1]
              }}
              transition={{
                duration: 3,
                repeat: Infinity,
                ease: "linear"
              }}
            >
              <Cloud className={`w-12 h-12 ${darkMode ? 'text-blue-400' : 'text-blue-600'}`} />
            </motion.div>
            <h2 className={`text-4xl font-bold bg-gradient-to-r bg-clip-text text-transparent ${
              darkMode 
                ? 'from-blue-400 via-purple-400 to-pink-400'
                : 'from-blue-600 via-purple-600 to-pink-600'
            }`}>
              {txt.title}
            </h2>
          </div>
          <p className={`text-sm ${darkMode ? 'text-gray-400' : 'text-gray-600'}`}>
            {txt.subtitle}
          </p>
        </motion.div>

        {/* Firebase Status Card */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="relative group mb-6"
        >
          <div className="absolute inset-0 bg-gradient-to-br from-blue-500 to-indigo-600 opacity-0 group-hover:opacity-10 rounded-3xl blur-xl transition-all duration-500" />
          <div className={`relative backdrop-blur-xl rounded-3xl p-6 border shadow-xl hover:shadow-2xl transition-all duration-300 ${
            darkMode 
              ? 'bg-gray-800/70 border-gray-700/50' 
              : 'bg-white/70 border-white/50'
          }`}>
            {/* Status Header */}
            <div className="flex items-center justify-between mb-6">
              <div className="flex items-center gap-3">
                <motion.div 
                  whileHover={{ scale: 1.1, rotate: 180 }}
                  transition={{ duration: 0.3 }}
                  className="w-12 h-12 bg-gradient-to-br from-blue-500 to-indigo-600 rounded-xl flex items-center justify-center shadow-lg"
                >
                  <Server className="w-6 h-6 text-white" />
                </motion.div>
                <div>
                  <h3 className={`font-bold ${darkMode ? 'text-white' : 'text-gray-900'}`}>
                    {txt.status}
                  </h3>
                  <p className={`text-xs ${darkMode ? 'text-gray-400' : 'text-gray-600'}`}>
                    {formatSyncTime(lastSyncTime)}
                  </p>
                </div>
              </div>
              <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={checkStatus}
                  disabled={isChecking}
                  className={`${darkMode ? 'border-blue-700 text-blue-400' : 'border-blue-200 text-blue-600'}`}
                >
                  <RefreshCw className={`w-4 h-4 mr-2 ${isChecking ? 'animate-spin' : ''}`} />
                  {txt.refreshStatus}
                </Button>
              </motion.div>
            </div>

            {/* Status Grid */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {/* Configuration Status */}
              <motion.div 
                whileHover={{ scale: 1.02, y: -2 }}
                className={`p-4 rounded-2xl transition-all ${
                  darkMode ? 'bg-gray-700/30' : 'bg-gray-50'
                }`}
              >
                <div className="flex items-center gap-3 mb-2">
                  {firebaseStatus.configured ? (
                    <div className="w-10 h-10 bg-green-500 rounded-xl flex items-center justify-center">
                      <CheckCircle2 className="w-5 h-5 text-white" />
                    </div>
                  ) : (
                    <div className="w-10 h-10 bg-orange-500 rounded-xl flex items-center justify-center">
                      <AlertCircle className="w-5 h-5 text-white" />
                    </div>
                  )}
                  <div>
                    <p className={`text-xs ${darkMode ? 'text-gray-400' : 'text-gray-600'}`}>
                      Configuration
                    </p>
                    <p className={`text-sm font-bold ${
                      firebaseStatus.configured 
                        ? 'text-green-500' 
                        : 'text-orange-500'
                    }`}>
                      {firebaseStatus.configured ? txt.configured : txt.notConfigured}
                    </p>
                  </div>
                </div>
              </motion.div>

              {/* Connection Status */}
              <motion.div 
                whileHover={{ scale: 1.02, y: -2 }}
                className={`p-4 rounded-2xl transition-all ${
                  darkMode ? 'bg-gray-700/30' : 'bg-gray-50'
                }`}
              >
                <div className="flex items-center gap-3 mb-2">
                  {firebaseStatus.connected ? (
                    <div className="w-10 h-10 bg-green-500 rounded-xl flex items-center justify-center">
                      <Wifi className="w-5 h-5 text-white" />
                    </div>
                  ) : (
                    <div className="w-10 h-10 bg-red-500 rounded-xl flex items-center justify-center">
                      <WifiOff className="w-5 h-5 text-white" />
                    </div>
                  )}
                  <div>
                    <p className={`text-xs ${darkMode ? 'text-gray-400' : 'text-gray-600'}`}>
                      Connection
                    </p>
                    <p className={`text-sm font-bold ${
                      firebaseStatus.connected 
                        ? 'text-green-500' 
                        : 'text-red-500'
                    }`}>
                      {firebaseStatus.connected ? txt.connected : txt.disconnected}
                    </p>
                  </div>
                </div>
              </motion.div>

              {/* Current Mode */}
              <motion.div 
                whileHover={{ scale: 1.02, y: -2 }}
                className={`p-4 rounded-2xl transition-all ${
                  darkMode ? 'bg-gray-700/30' : 'bg-gray-50'
                }`}
              >
                <div className="flex items-center gap-3 mb-2">
                  {isFirebaseMode() ? (
                    <div className="w-10 h-10 bg-blue-500 rounded-xl flex items-center justify-center">
                      <Cloud className="w-5 h-5 text-white" />
                    </div>
                  ) : (
                    <div className="w-10 h-10 bg-purple-500 rounded-xl flex items-center justify-center">
                      <HardDrive className="w-5 h-5 text-white" />
                    </div>
                  )}
                  <div>
                    <p className={`text-xs ${darkMode ? 'text-gray-400' : 'text-gray-600'}`}>
                      Storage
                    </p>
                    <p className={`text-sm font-bold ${
                      isFirebaseMode() 
                        ? 'text-blue-500' 
                        : 'text-purple-500'
                    }`}>
                      {isFirebaseMode() ? txt.firebaseMode : txt.localStorage}
                    </p>
                  </div>
                </div>
              </motion.div>
            </div>

            {/* Error Message */}
            <AnimatePresence>
              {firebaseStatus.error && (
                <motion.div
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: 'auto' }}
                  exit={{ opacity: 0, height: 0 }}
                  className={`mt-4 p-4 rounded-2xl border ${
                    darkMode 
                      ? 'bg-red-900/20 border-red-700' 
                      : 'bg-red-100 border-red-300'
                  }`}
                >
                  <div className="flex items-start gap-3">
                    <XCircle className="w-5 h-5 text-red-500 flex-shrink-0 mt-0.5" />
                    <div>
                      <p className={`text-sm font-bold ${darkMode ? 'text-red-300' : 'text-red-700'}`}>
                        {txt.error}
                      </p>
                      <p className={`text-xs mt-1 ${darkMode ? 'text-red-400' : 'text-red-600'}`}>
                        {firebaseStatus.error}
                      </p>
                    </div>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>

            {/* Configuration Instructions */}
            {!firebaseStatus.configured && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className={`mt-4 p-4 rounded-2xl border ${
                  darkMode 
                    ? 'bg-blue-900/20 border-blue-700' 
                    : 'bg-blue-100 border-blue-300'
                }`}
              >
                <div className="flex items-start gap-3">
                  <AlertCircle className="w-5 h-5 text-blue-500 flex-shrink-0 mt-0.5" />
                  <p className={`text-sm ${darkMode ? 'text-blue-300' : 'text-blue-700'}`}>
                    {txt.configureInstructions}
                  </p>
                </div>
              </motion.div>
            )}
          </div>
        </motion.div>

        {/* Sync Actions */}
        {firebaseStatus.connected && (
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="relative group mb-6"
          >
            <div className="absolute inset-0 bg-gradient-to-br from-green-500 to-emerald-600 opacity-0 group-hover:opacity-10 rounded-3xl blur-xl transition-all duration-500" />
            <div className={`relative backdrop-blur-xl rounded-3xl p-6 border shadow-xl hover:shadow-2xl transition-all duration-300 ${
              darkMode 
                ? 'bg-gray-800/70 border-gray-700/50' 
                : 'bg-white/70 border-white/50'
            }`}>
              <div className="flex items-center gap-3 mb-6">
                <motion.div 
                  animate={{ rotate: isSyncing ? 360 : 0 }}
                  transition={{ duration: 1, repeat: isSyncing ? Infinity : 0, ease: "linear" }}
                  className="w-12 h-12 bg-gradient-to-br from-green-500 to-emerald-600 rounded-xl flex items-center justify-center shadow-lg"
                >
                  <RefreshCw className="w-6 h-6 text-white" />
                </motion.div>
                <div>
                  <h3 className={`text-xl font-bold ${darkMode ? 'text-white' : 'text-gray-900'}`}>
                    {txt.manualSync}
                  </h3>
                  <p className={`text-sm ${darkMode ? 'text-gray-400' : 'text-gray-600'}`}>
                    {txt.lastSync}: {formatSyncTime(lastSyncTime)}
                  </p>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {/* Sync to Firebase */}
                <motion.div
                  whileHover={{ scale: 1.02, y: -2 }}
                  whileTap={{ scale: 0.98 }}
                >
                  <button
                    onClick={handleSyncToFirebase}
                    disabled={isSyncing}
                    className={`w-full p-6 rounded-2xl transition-all border-2 text-left group/btn ${
                      darkMode
                        ? 'bg-gradient-to-br from-blue-900/30 to-indigo-900/30 border-blue-700 hover:border-blue-500'
                        : 'bg-gradient-to-br from-blue-50 to-indigo-50 border-blue-200 hover:border-blue-400'
                    } ${isSyncing ? 'opacity-50 cursor-not-allowed' : ''}`}
                  >
                    <div className="flex items-start gap-4">
                      <div className={`w-14 h-14 rounded-2xl flex items-center justify-center ${
                        darkMode ? 'bg-blue-600' : 'bg-blue-500'
                      } shadow-lg group-hover/btn:scale-110 transition-transform`}>
                        <ArrowUpCircle className={`w-7 h-7 text-white ${isSyncing ? 'animate-pulse' : ''}`} />
                      </div>
                      <div className="flex-1">
                        <h4 className={`font-bold mb-1 ${darkMode ? 'text-white' : 'text-gray-900'}`}>
                          {txt.syncToCloud}
                        </h4>
                        <p className={`text-xs ${darkMode ? 'text-gray-400' : 'text-gray-600'}`}>
                          {txt.uploadDesc}
                        </p>
                        <div className="flex items-center gap-2 mt-3">
                          <Activity className={`w-4 h-4 ${darkMode ? 'text-blue-400' : 'text-blue-600'}`} />
                          <span className={`text-xs font-medium ${darkMode ? 'text-blue-400' : 'text-blue-600'}`}>
                            {language === 'ps' ? 'محلي څخه Cloud ته' : language === 'fa' ? 'از محلی به ابری' : 'Local → Cloud'}
                          </span>
                        </div>
                      </div>
                    </div>
                  </button>
                </motion.div>

                {/* Sync from Firebase */}
                <motion.div
                  whileHover={{ scale: 1.02, y: -2 }}
                  whileTap={{ scale: 0.98 }}
                >
                  <button
                    onClick={handleSyncFromFirebase}
                    disabled={isSyncing}
                    className={`w-full p-6 rounded-2xl transition-all border-2 text-left group/btn ${
                      darkMode
                        ? 'bg-gradient-to-br from-purple-900/30 to-pink-900/30 border-purple-700 hover:border-purple-500'
                        : 'bg-gradient-to-br from-purple-50 to-pink-50 border-purple-200 hover:border-purple-400'
                    } ${isSyncing ? 'opacity-50 cursor-not-allowed' : ''}`}
                  >
                    <div className="flex items-start gap-4">
                      <div className={`w-14 h-14 rounded-2xl flex items-center justify-center ${
                        darkMode ? 'bg-purple-600' : 'bg-purple-500'
                      } shadow-lg group-hover/btn:scale-110 transition-transform`}>
                        <ArrowDownCircle className={`w-7 h-7 text-white ${isSyncing ? 'animate-pulse' : ''}`} />
                      </div>
                      <div className="flex-1">
                        <h4 className={`font-bold mb-1 ${darkMode ? 'text-white' : 'text-gray-900'}`}>
                          {txt.syncFromCloud}
                        </h4>
                        <p className={`text-xs ${darkMode ? 'text-gray-400' : 'text-gray-600'}`}>
                          {txt.downloadDesc}
                        </p>
                        <div className="flex items-center gap-2 mt-3">
                          <TrendingUp className={`w-4 h-4 ${darkMode ? 'text-purple-400' : 'text-purple-600'}`} />
                          <span className={`text-xs font-medium ${darkMode ? 'text-purple-400' : 'text-purple-600'}`}>
                            {language === 'ps' ? 'Cloud څخه محلي ته' : language === 'fa' ? 'از ابری به محلی' : 'Cloud → Local'}
                          </span>
                        </div>
                      </div>
                    </div>
                  </button>
                </motion.div>
              </div>

              {/* Syncing Indicator */}
              <AnimatePresence>
                {isSyncing && (
                  <motion.div
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: 'auto' }}
                    exit={{ opacity: 0, height: 0 }}
                    className={`mt-4 p-4 rounded-2xl ${
                      darkMode ? 'bg-green-900/20' : 'bg-green-100'
                    }`}
                  >
                    <div className="flex items-center justify-center gap-3">
                      <motion.div
                        animate={{ rotate: 360 }}
                        transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
                      >
                        <RefreshCw className="w-5 h-5 text-green-600" />
                      </motion.div>
                      <span className={`text-sm font-medium ${darkMode ? 'text-green-300' : 'text-green-700'}`}>
                        {txt.syncingData}
                      </span>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          </motion.div>
        )}

        {/* Security Info */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="relative group"
        >
          <div className="absolute inset-0 bg-gradient-to-br from-amber-500 to-orange-600 opacity-0 group-hover:opacity-10 rounded-3xl blur-xl transition-all duration-500" />
          <div className={`relative backdrop-blur-xl rounded-3xl p-6 border shadow-xl ${
            darkMode 
              ? 'bg-gray-800/70 border-gray-700/50' 
              : 'bg-white/70 border-white/50'
          }`}>
            <div className="flex items-start gap-4">
              <motion.div 
                animate={{ 
                  scale: [1, 1.1, 1],
                }}
                transition={{ 
                  duration: 2,
                  repeat: Infinity,
                  ease: "easeInOut"
                }}
                className="w-12 h-12 bg-gradient-to-br from-amber-500 to-orange-600 rounded-xl flex items-center justify-center shadow-lg flex-shrink-0"
              >
                <Shield className="w-6 h-6 text-white" />
              </motion.div>
              <div className="flex-1">
                <h4 className={`font-bold mb-2 ${darkMode ? 'text-white' : 'text-gray-900'}`}>
                  {language === 'ps' ? 'امنیتي یادونه' : language === 'fa' ? 'یادداشت امنیتی' : 'Security Note'}
                </h4>
                <p className={`text-sm ${darkMode ? 'text-gray-300' : 'text-gray-700'}`}>
                  {language === 'ps' 
                    ? 'ستاسو ټول معلومات په بشپړه توګه خوندي او encrypted دي. Firebase د Google پخوا د ډیټا امنیت لپاره استعمالیږي.'
                    : language === 'fa' 
                    ? 'تمام داده‌های شما کاملاً ایمن و رمزگذاری شده هستند. Firebase توسط Google برای امنیت داده استفاده می‌شود.'
                    : 'Your data is fully secure and encrypted. Firebase is powered by Google for maximum data security.'
                  }
                </p>
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </div>
  );
}
