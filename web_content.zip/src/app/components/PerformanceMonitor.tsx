import { useEffect, useState } from 'react';
import { Alert, AlertDescription } from './ui/alert';
import { AlertCircle, CheckCircle, Wifi, WifiOff, Database, Zap } from 'lucide-react';

export function PerformanceMonitor() {
  const [status, setStatus] = useState<{
    storage: 'checking' | 'ready' | 'error';
    network: 'online' | 'offline';
    performance: 'fast' | 'normal' | 'slow';
  }>({
    storage: 'checking',
    network: 'online',
    performance: 'fast'
  });

  const [loadTime, setLoadTime] = useState<number>(0);
  const [showMonitor, setShowMonitor] = useState(true);

  useEffect(() => {
    const startTime = Date.now();

    // Network status
    const updateNetworkStatus = () => {
      setStatus(prev => ({ ...prev, network: navigator.onLine ? 'online' : 'offline' }));
    };

    window.addEventListener('online', updateNetworkStatus);
    window.addEventListener('offline', updateNetworkStatus);
    updateNetworkStatus();

    // Check LocalStorage
    const checkStorage = () => {
      try {
        const testKey = '_healmate_test_';
        localStorage.setItem(testKey, 'test');
        const testValue = localStorage.getItem(testKey);
        localStorage.removeItem(testKey);
        
        if (testValue === 'test') {
          setStatus(prev => ({ ...prev, storage: 'ready' }));
        } else {
          setStatus(prev => ({ ...prev, storage: 'error' }));
        }
      } catch (error) {
        console.error('Storage check error:', error);
        setStatus(prev => ({ ...prev, storage: 'error' }));
      }
    };

    checkStorage();

    // Check performance
    const endTime = Date.now();
    const duration = endTime - startTime;
    setLoadTime(duration);

    if (duration < 100) {
      setStatus(prev => ({ ...prev, performance: 'fast' }));
    } else if (duration < 500) {
      setStatus(prev => ({ ...prev, performance: 'normal' }));
    } else {
      setStatus(prev => ({ ...prev, performance: 'slow' }));
    }

    // Auto-hide after 3 seconds if everything is ok
    const hideTimer = setTimeout(() => {
      if (status.storage === 'ready' && status.network === 'online') {
        setShowMonitor(false);
      }
    }, 3000);

    return () => {
      window.removeEventListener('online', updateNetworkStatus);
      window.removeEventListener('offline', updateNetworkStatus);
      clearTimeout(hideTimer);
    };
  }, []);

  // Don't show if everything is ready
  if (!showMonitor && status.storage === 'ready' && status.network === 'online') {
    return null;
  }

  const hasError = status.storage === 'error' || status.network === 'offline';
  const isLoading = status.storage === 'checking';

  return (
    <div className="fixed bottom-4 right-4 z-50 max-w-sm">
      <Alert className={`border-2 shadow-lg ${ 
        hasError ? 'border-red-500 bg-red-50 dark:bg-red-900/20' : 
        isLoading ? 'border-yellow-500 bg-yellow-50 dark:bg-yellow-900/20' :
        'border-green-500 bg-green-50 dark:bg-green-900/20'
      }`}>
        <div className="flex items-start gap-2">
          {hasError ? (
            <AlertCircle className="w-5 h-5 text-red-600" />
          ) : isLoading ? (
            <div className="w-5 h-5 border-2 border-yellow-600 border-t-transparent rounded-full animate-spin" />
          ) : (
            <CheckCircle className="w-5 h-5 text-green-600" />
          )}
          
          <div className="flex-1 space-y-2">
            <AlertDescription className="text-sm font-semibold">
              {hasError ? '⚠️ App Status' : isLoading ? '🔄 Loading...' : '✅ App Ready'}
            </AlertDescription>
            
            <div className="text-xs space-y-1">
              <div className="flex items-center justify-between">
                <span>Network:</span>
                {status.network === 'online' ? (
                  <span className="flex items-center gap-1 text-green-600">
                    <Wifi className="w-3 h-3" /> Online
                  </span>
                ) : (
                  <span className="flex items-center gap-1 text-red-600">
                    <WifiOff className="w-3 h-3" /> Offline
                  </span>
                )}
              </div>
              
              <div className="flex items-center justify-between">
                <span>Storage:</span>
                <StatusBadge status={status.storage} />
              </div>
              
              <div className="flex items-center justify-between">
                <span>Performance:</span>
                <span className={`flex items-center gap-1 ${
                  status.performance === 'fast' ? 'text-green-600' :
                  status.performance === 'normal' ? 'text-yellow-600' :
                  'text-red-600'
                }`}>
                  <Zap className="w-3 h-3" />
                  {status.performance === 'fast' ? 'Fast' : status.performance === 'normal' ? 'Normal' : 'Slow'}
                </span>
              </div>

              {loadTime > 0 && (
                <div className="pt-1 border-t mt-2">
                  <span className="text-gray-600 dark:text-gray-400">Load time: {loadTime}ms</span>
                </div>
              )}
            </div>

            {hasError && (
              <div className="text-xs text-red-700 dark:text-red-400 pt-2 border-t">
                <p className="font-semibold">Quick Fix:</p>
                <ul className="list-disc list-inside space-y-1 mt-1">
                  {status.network === 'offline' && <li>Check your internet connection</li>}
                  {status.storage === 'error' && <li>Enable browser storage / Clear browser cache</li>}
                </ul>
              </div>
            )}
          </div>

          <button
            onClick={() => setShowMonitor(false)}
            className="text-gray-400 hover:text-gray-600 dark:hover:text-gray-300 text-xl"
          >
            ×
          </button>
        </div>
      </Alert>
    </div>
  );
}

function StatusBadge({ status }: { status: 'checking' | 'ready' | 'error' }) {
  if (status === 'checking') {
    return (
      <span className="text-yellow-600 flex items-center gap-1">
        <div className="w-2 h-2 bg-yellow-600 rounded-full animate-pulse" />
        Checking...
      </span>
    );
  }
  
  if (status === 'ready') {
    return (
      <span className="text-green-600 flex items-center gap-1">
        <Database className="w-3 h-3" />
        Ready
      </span>
    );
  }
  
  return (
    <span className="text-red-600 flex items-center gap-1">
      <div className="w-2 h-2 bg-red-600 rounded-full" />
      Error
    </span>
  );
}
