import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  AlertCircle, Phone, MapPin, Ambulance, Hospital, 
  Heart, Activity, X, Navigation, Clock, PhoneCall
} from 'lucide-react';
import { Button } from './ui/button';
import { Card } from './ui/card';

interface EmergencySOSButtonProps {
  language: 'ps' | 'fa' | 'en';
}

interface EmergencyContact {
  name: { ps: string; fa: string; en: string };
  number: string;
  icon: any;
  color: string;
}

export function EmergencySOSButton({ language }: EmergencySOSButtonProps) {
  const [showEmergencyPanel, setShowEmergencyPanel] = useState(false);
  const [countdown, setCountdown] = useState<number | null>(null);
  const [selectedService, setSelectedService] = useState<string | null>(null);

  const texts = {
    ps: {
      sos: 'بیړنی مرسته',
      emergency: '🚨 بیړنی حالت',
      subtitle: 'په بیړنیو حالاتو کې مرسته ترلاسه کړئ',
      nearbyHospitals: 'نږدې هسپتالونه',
      emergencyContacts: 'بیړني شمیرې',
      calling: 'اړیکه کیږي...',
      cancel: 'لغوه کول',
      ambulance: 'امبولانس',
      police: 'پولیس',
      fire: 'اور وژونکي',
      hospital: 'هسپتال',
      bloodBank: 'د وینې بانک',
      poison: 'د زهرو مرکز',
      yourLocation: 'ستاسو موقعیت',
      shareLocation: 'موقعیت شریک کړئ',
      pressAgain: 'بیا فشار ورکړئ د تایید لپاره',
      important: 'مهم یاداشت',
      onlyEmergencies: 'یوازې په ریښتیني بیړنیو حالاتو کې وکاروئ'
    },
    fa: {
      sos: 'کمک فوری',
      emergency: '🚨 اورژانس',
      subtitle: 'در مواقع اضطراری کمک دریافت کنید',
      nearbyHospitals: 'بیمارستان‌های نزدیک',
      emergencyContacts: 'شماره‌های اورژانسی',
      calling: 'در حال تماس...',
      cancel: 'لغو',
      ambulance: 'آمبولانس',
      police: 'پولیس',
      fire: 'آتش‌نشانی',
      hospital: 'بیمارستان',
      bloodBank: 'بانک خون',
      poison: 'مرکز سموم',
      yourLocation: 'موقعیت شما',
      shareLocation: 'اشتراک موقعیت',
      pressAgain: 'دوباره فشار دهید برای تایید',
      important: 'یادداشت مهم',
      onlyEmergencies: 'فقط در مواقع اضطراری واقعی استفاده کنید'
    },
    en: {
      sos: 'Emergency Help',
      emergency: '🚨 Emergency',
      subtitle: 'Get help in emergency situations',
      nearbyHospitals: 'Nearby Hospitals',
      emergencyContacts: 'Emergency Numbers',
      calling: 'Calling...',
      cancel: 'Cancel',
      ambulance: 'Ambulance',
      police: 'Police',
      fire: 'Fire Service',
      hospital: 'Hospital',
      bloodBank: 'Blood Bank',
      poison: 'Poison Center',
      yourLocation: 'Your Location',
      shareLocation: 'Share Location',
      pressAgain: 'Press again to confirm',
      important: 'Important Note',
      onlyEmergencies: 'Only use in real emergencies'
    }
  };

  const t = texts[language];

  const emergencyServices: EmergencyContact[] = [
    {
      name: { ps: 'امبولانس', fa: 'آمبولانس', en: 'Ambulance' },
      number: '102',
      icon: Ambulance,
      color: 'from-red-500 to-red-600'
    },
    {
      name: { ps: 'هسپتال', fa: 'بیمارستان', en: 'Hospital' },
      number: '119',
      icon: Hospital,
      color: 'from-blue-500 to-blue-600'
    },
    {
      name: { ps: 'د زهرو مرکز', fa: 'مرکز سموم', en: 'Poison Center' },
      number: '131',
      icon: Activity,
      color: 'from-purple-500 to-purple-600'
    }
  ];

  const nearbyHospitals = [
    {
      name: 'د جمهوریت هسپتال',
      distance: '1.2 km',
      time: '5 دقیقې'
    },
    {
      name: 'وزیر اکبر خان هسپتال',
      distance: '2.5 km',
      time: '10 دقیقې'
    },
    {
      name: 'د کودکانو هسپتال',
      distance: '3.1 km',
      time: '12 دقیقې'
    }
  ];

  const initiateCall = (number: string, serviceName: string) => {
    setSelectedService(serviceName);
    setCountdown(3);
    
    const interval = setInterval(() => {
      setCountdown((prev) => {
        if (prev === 1) {
          clearInterval(interval);
          // په ریښتیني کې به تیلیفون وشي
          window.location.href = `tel:${number}`;
          setTimeout(() => {
            setCountdown(null);
            setSelectedService(null);
          }, 1000);
          return null;
        }
        return prev ? prev - 1 : null;
      });
    }, 1000);
  };

  const cancelCall = () => {
    setCountdown(null);
    setSelectedService(null);
  };

  const shareLocation = () => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(async (position) => {
        const { latitude, longitude } = position.coords;
        const message = `🚨 بیړنی حالت! زما موقعیت: https://maps.google.com/?q=${latitude},${longitude}`;
        
        // Share via WhatsApp or SMS
        if (navigator.share) {
          try {
            await navigator.share({
              title: 'بیړنی موقعیت',
              text: message
            });
          } catch (err) {
            // که share ناکامه شي، په clipboard کې کاپي کړه
            if (err instanceof Error && err.name !== 'AbortError') {
              navigator.clipboard.writeText(message);
              alert(language === 'ps' ? 'موقعیت کاپي شو' : language === 'fa' ? 'موقعیت کپی شد' : 'Location copied');
            }
          }
        } else {
          // Fallback: Copy to clipboard
          navigator.clipboard.writeText(message);
          alert(language === 'ps' ? 'موقعیت کاپي شو' : language === 'fa' ? 'موقعیت کپی شد' : 'Location copied');
        }
      });
    }
  };

  return (
    <>
      {/* Floating Emergency Button */}
      <motion.div
        initial={{ scale: 0 }}
        animate={{ scale: 1 }}
        className="fixed bottom-24 right-6 z-40"
      >
        <motion.button
          onClick={() => setShowEmergencyPanel(true)}
          whileHover={{ scale: 1.1 }}
          whileTap={{ scale: 0.9 }}
          animate={{
            boxShadow: [
              '0 0 20px rgba(239, 68, 68, 0.5)',
              '0 0 40px rgba(239, 68, 68, 0.8)',
              '0 0 20px rgba(239, 68, 68, 0.5)'
            ]
          }}
          transition={{ duration: 2, repeat: Infinity }}
          className="w-16 h-16 rounded-full bg-gradient-to-br from-red-500 to-red-600 text-white shadow-2xl flex items-center justify-center"
        >
          <AlertCircle className="w-8 h-8" />
        </motion.button>
        
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5 }}
          className="absolute -top-12 right-0 bg-red-600 text-white text-xs px-3 py-1.5 rounded-full shadow-lg whitespace-nowrap"
        >
          {t.sos}
        </motion.div>
      </motion.div>

      {/* Emergency Panel */}
      <AnimatePresence>
        {showEmergencyPanel && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/70 backdrop-blur-sm z-50 flex items-center justify-center p-4"
            onClick={() => !countdown && setShowEmergencyPanel(false)}
          >
            <motion.div
              initial={{ scale: 0.9, y: 20 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.9, y: 20 }}
              onClick={(e) => e.stopPropagation()}
              className="bg-white rounded-3xl shadow-2xl max-w-lg w-full max-h-[90vh] overflow-y-auto"
            >
              {/* Header */}
              <div className="bg-gradient-to-r from-red-500 to-red-600 text-white p-6 rounded-t-3xl">
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-3">
                    <motion.div
                      animate={{ rotate: [0, 10, -10, 0] }}
                      transition={{ duration: 0.5, repeat: Infinity }}
                    >
                      <AlertCircle className="w-8 h-8" />
                    </motion.div>
                    <div>
                      <h2 className="text-2xl">{t.emergency}</h2>
                      <p className="text-sm opacity-90">{t.subtitle}</p>
                    </div>
                  </div>
                  <Button
                    onClick={() => setShowEmergencyPanel(false)}
                    variant="ghost"
                    size="icon"
                    className="text-white hover:bg-white/20"
                  >
                    <X className="w-6 h-6" />
                  </Button>
                </div>
              </div>

              <div className="p-6 space-y-6">
                {/* Important Notice */}
                <div className="bg-yellow-50 border-2 border-yellow-300 rounded-xl p-4">
                  <div className="flex items-start gap-3">
                    <AlertCircle className="w-5 h-5 text-yellow-600 flex-shrink-0 mt-0.5" />
                    <div>
                      <h4 className="text-yellow-900 mb-1">{t.important}</h4>
                      <p className="text-sm text-yellow-700">{t.onlyEmergencies}</p>
                    </div>
                  </div>
                </div>

                {/* Countdown Display */}
                <AnimatePresence>
                  {countdown !== null && (
                    <motion.div
                      initial={{ opacity: 0, scale: 0.8 }}
                      animate={{ opacity: 1, scale: 1 }}
                      exit={{ opacity: 0, scale: 0.8 }}
                      className="bg-red-50 border-2 border-red-300 rounded-xl p-6 text-center"
                    >
                      <motion.div
                        animate={{ scale: [1, 1.2, 1] }}
                        transition={{ duration: 1, repeat: Infinity }}
                        className="text-6xl text-red-600 mb-4"
                      >
                        {countdown}
                      </motion.div>
                      <p className="text-lg text-red-900 mb-4">
                        {t.calling} {selectedService}
                      </p>
                      <Button
                        onClick={cancelCall}
                        variant="outline"
                        className="border-red-600 text-red-600 hover:bg-red-50"
                      >
                        {t.cancel}
                      </Button>
                    </motion.div>
                  )}
                </AnimatePresence>

                {/* Emergency Services */}
                {!countdown && (
                  <>
                    <div>
                      <h3 className="text-lg mb-4 flex items-center gap-2">
                        <PhoneCall className="w-5 h-5" />
                        {t.emergencyContacts}
                      </h3>
                      <div className="grid grid-cols-1 gap-3">
                        {emergencyServices.map((service) => {
                          const Icon = service.icon;
                          return (
                            <motion.div
                              key={service.number}
                              whileHover={{ scale: 1.02 }}
                              whileTap={{ scale: 0.98 }}
                            >
                              <Card
                                onClick={() => initiateCall(service.number, service.name[language])}
                                className="cursor-pointer overflow-hidden hover:shadow-xl transition-all border-2"
                              >
                                <div className={`bg-gradient-to-r ${service.color} p-4`}>
                                  <div className="flex items-center justify-between text-white">
                                    <div className="flex items-center gap-3">
                                      <div className="w-12 h-12 bg-white/20 rounded-xl flex items-center justify-center">
                                        <Icon className="w-6 h-6" />
                                      </div>
                                      <div>
                                        <div className="text-lg">{service.name[language]}</div>
                                        <div className="text-2xl">{service.number}</div>
                                      </div>
                                    </div>
                                    <Phone className="w-6 h-6" />
                                  </div>
                                </div>
                              </Card>
                            </motion.div>
                          );
                        })}
                      </div>
                    </div>

                    {/* Location Sharing */}
                    <div>
                      <h3 className="text-lg mb-4 flex items-center gap-2">
                        <MapPin className="w-5 h-5" />
                        {t.yourLocation}
                      </h3>
                      <Button
                        onClick={shareLocation}
                        className="w-full bg-gradient-to-r from-blue-500 to-blue-600 text-white"
                      >
                        <Navigation className="w-4 h-4 mr-2" />
                        {t.shareLocation}
                      </Button>
                    </div>

                    {/* Nearby Hospitals */}
                    <div>
                      <h3 className="text-lg mb-4 flex items-center gap-2">
                        <Hospital className="w-5 h-5" />
                        {t.nearbyHospitals}
                      </h3>
                      <div className="space-y-2">
                        {nearbyHospitals.map((hospital, index) => (
                          <Card key={index} className="p-4 hover:shadow-md transition-all">
                            <div className="flex items-center justify-between">
                              <div className="flex items-center gap-3">
                                <div className="w-10 h-10 bg-blue-100 rounded-xl flex items-center justify-center">
                                  <Hospital className="w-5 h-5 text-blue-600" />
                                </div>
                                <div>
                                  <div className="font-medium">{hospital.name}</div>
                                  <div className="text-sm text-gray-500 flex items-center gap-2">
                                    <MapPin className="w-3 h-3" />
                                    {hospital.distance}
                                    <Clock className="w-3 h-3 ml-2" />
                                    {hospital.time}
                                  </div>
                                </div>
                              </div>
                              <Button
                                size="sm"
                                variant="outline"
                                className="border-blue-200 text-blue-600"
                                onClick={() => {
                                  // Open in maps
                                  window.open(`https://maps.google.com/maps?q=${hospital.name}`);
                                }}
                              >
                                <Navigation className="w-4 h-4" />
                              </Button>
                            </div>
                          </Card>
                        ))}
                      </div>
                    </div>
                  </>
                )}
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
