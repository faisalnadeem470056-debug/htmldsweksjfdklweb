// PWA Manager - د Service Worker او PWA features مدیریت

export class PWAManager {
  private static instance: PWAManager;

  private constructor() {
    this.logEnvironment();
    this.initServiceWorker();
    this.checkForUpdates();
  }

  // د Environment معلومات log کول
  private logEnvironment() {
    const env = this.getEnvironmentInfo();
    console.log('🌍 PWA Environment:', {
      hostname: env.hostname,
      protocol: env.protocol,
      swSupported: env.swSupported,
      swEnabled: env.swEnabled,
      isProduction: env.isProduction,
      isLocalhost: env.isLocalhost,
      isFigmaPreview: env.isFigmaPreview
    });
  }

  // د Environment معلومات
  private getEnvironmentInfo() {
    const hostname = window.location.hostname;
    const protocol = window.location.protocol;
    const isFigmaPreview = hostname.includes('figma') || hostname.includes('iframe');
    const isLocalhost = hostname === 'localhost' || hostname === '127.0.0.1';
    const isProduction = protocol === 'https:' && !isFigmaPreview;
    const swSupported = 'serviceWorker' in navigator;
    const swEnabled = (isProduction || isLocalhost) && !isFigmaPreview && swSupported;

    return {
      hostname,
      protocol,
      isFigmaPreview,
      isLocalhost,
      isProduction,
      swSupported,
      swEnabled
    };
  }

  public static getInstance(): PWAManager {
    if (!PWAManager.instance) {
      PWAManager.instance = new PWAManager();
    }
    return PWAManager.instance;
  }

  // د Service Worker نصبول
  private async initServiceWorker() {
    // Service Worker یوازې په production او localhost کې فعال کړئ
    const isProduction = window.location.protocol === 'https:' && !window.location.hostname.includes('figma');
    const isLocalhost = window.location.hostname === 'localhost' || window.location.hostname === '127.0.0.1';
    
    if (!('serviceWorker' in navigator)) {
      console.log('⚠️ Service Worker not supported in this browser');
      return;
    }

    // په Figma preview environment کې Service Worker مه فعالوئ
    if (window.location.hostname.includes('figma') || window.location.hostname.includes('iframe')) {
      console.log('ℹ️ Service Worker disabled in preview environment');
      return;
    }

    if (isProduction || isLocalhost) {
      try {
        const registration = await navigator.serviceWorker.register('/service-worker.js', {
          scope: '/',
          type: 'module'
        });

        console.log('✅ Service Worker registered:', registration.scope);

        // د update check کول
        registration.addEventListener('updatefound', () => {
          const newWorker = registration.installing;
          console.log('🔄 New Service Worker found!');

          newWorker?.addEventListener('statechange', () => {
            if (newWorker.state === 'installed' && navigator.serviceWorker.controller) {
              console.log('📦 New version available! Refresh to update.');
              this.notifyUpdate();
            }
          });
        });

      } catch (error) {
        // د error په خاموشۍ سره handle کړئ چې console ته spam نه شي
        if (error instanceof Error && !error.message.includes('MIME type')) {
          console.warn('⚠️ Service Worker registration skipped:', error.message);
        }
      }
    } else {
      console.log('ℹ️ Service Worker only works on HTTPS or localhost');
    }
  }

  // د update notification
  private notifyUpdate() {
    const shouldUpdate = confirm(
      'د HealMate نوی version شتون لري! ایا غواړئ چې اوس update کړئ؟'
    );
    
    if (shouldUpdate) {
      window.location.reload();
    }
  }

  // هره ساعت د updates check کول
  private checkForUpdates() {
    setInterval(async () => {
      if ('serviceWorker' in navigator) {
        try {
          const registration = await navigator.serviceWorker.getRegistration();
          if (registration) {
            await registration.update();
          }
        } catch (error) {
          // د error خاموشه ignore کول
        }
      }
    }, 60 * 60 * 1000); // هره ساعت
  }

  // د offline status check کول
  public isOnline(): boolean {
    return navigator.onLine;
  }

  // د Push Notifications permission غوښتل
  public async requestNotificationPermission(): Promise<NotificationPermission> {
    if (!('Notification' in window)) {
      console.log('⚠️ Notifications not supported');
      return 'denied';
    }

    try {
      const permission = await Notification.requestPermission();
      console.log('🔔 Notification permission:', permission);
      return permission;
    } catch (error) {
      console.warn('⚠️ Notification permission request failed');
      return 'denied';
    }
  }

  // د Push Notification لیږل
  public async sendNotification(title: string, options?: NotificationOptions) {
    try {
      const permission = await this.requestNotificationPermission();
      
      if (permission === 'granted') {
        const registration = await navigator.serviceWorker.getRegistration();
        
        if (registration) {
          await registration.showNotification(title, {
            icon: '/icons/icon-192x192.png',
            badge: '/icons/badge-72x72.png',
            vibrate: [200, 100, 200],
            ...options
          });
        } else {
          // که Service Worker نه وي، د Browser notification استعمال کړئ
          new Notification(title, {
            icon: '/icons/icon-192x192.png',
            ...options
          });
        }
      }
    } catch (error) {
      console.warn('⚠️ Notification failed:', error);
    }
  }

  // د Background Sync نوم لیکنه
  public async registerBackgroundSync(tag: string) {
    if ('serviceWorker' in navigator && 'SyncManager' in window) {
      try {
        const registration = await navigator.serviceWorker.ready;
        // @ts-ignore - SyncManager ټایپ شاید نه وي
        await registration.sync.register(tag);
        console.log('✅ Background sync registered:', tag);
      } catch (error) {
        console.warn('⚠️ Background sync not available');
      }
    }
  }

  // د Cache پاکول
  public async clearCache() {
    if ('caches' in window) {
      const cacheNames = await caches.keys();
      await Promise.all(
        cacheNames.map(cacheName => caches.delete(cacheName))
      );
      console.log('✅ All caches cleared');
    }
  }

  // د Cache size معلومات
  public async getCacheSize(): Promise<number> {
    if ('caches' in window) {
      const cacheNames = await caches.keys();
      let totalSize = 0;

      for (const cacheName of cacheNames) {
        const cache = await caches.open(cacheName);
        const keys = await cache.keys();
        
        for (const request of keys) {
          const response = await cache.match(request);
          if (response) {
            const blob = await response.blob();
            totalSize += blob.size;
          }
        }
      }

      return totalSize;
    }
    return 0;
  }

  // د Install prompt check کول
  public canInstall(): boolean {
    return !window.matchMedia('(display-mode: standalone)').matches;
  }

  // د Share API استعمال
  public async share(data: ShareData): Promise<boolean> {
    if (navigator.share) {
      try {
        await navigator.share(data);
        console.log('✅ Content shared successfully');
        return true;
      } catch (error) {
        console.error('❌ Share failed:', error);
        return false;
      }
    }
    return false;
  }

  // د Clipboard API استعمال
  public async copyToClipboard(text: string): Promise<boolean> {
    if (navigator.clipboard) {
      try {
        await navigator.clipboard.writeText(text);
        console.log('✅ Copied to clipboard');
        return true;
      } catch (error) {
        console.error('❌ Copy failed:', error);
        return false;
      }
    }
    return false;
  }

  // د Device معلومات
  public getDeviceInfo() {
    return {
      userAgent: navigator.userAgent,
      platform: navigator.platform,
      language: navigator.language,
      online: navigator.onLine,
      cookiesEnabled: navigator.cookieEnabled,
      screenWidth: window.screen.width,
      screenHeight: window.screen.height,
      viewportWidth: window.innerWidth,
      viewportHeight: window.innerHeight,
      isStandalone: window.matchMedia('(display-mode: standalone)').matches,
      isIOS: /iPad|iPhone|iPod/.test(navigator.userAgent),
      isAndroid: /Android/.test(navigator.userAgent)
    };
  }

  // د Network status monitoring
  public monitorNetworkStatus(callback: (online: boolean) => void) {
    window.addEventListener('online', () => {
      console.log('✅ Back online');
      callback(true);
    });

    window.addEventListener('offline', () => {
      console.log('❌ Gone offline');
      callback(false);
    });
  }

  // د App install وروسته
  public onAppInstalled(callback: () => void) {
    window.addEventListener('appinstalled', () => {
      console.log('✅ App installed successfully');
      callback();
    });
  }

  // د Visibility change (کله چې app foreground/background شي)
  public onVisibilityChange(callback: (visible: boolean) => void) {
    document.addEventListener('visibilitychange', () => {
      callback(!document.hidden);
    });
  }
}

// د Singleton instance export
export const pwaManager = PWAManager.getInstance();

// د window object ته اضافه کول (debugging لپاره)
if (typeof window !== 'undefined') {
  (window as any).pwaManager = pwaManager;
}
