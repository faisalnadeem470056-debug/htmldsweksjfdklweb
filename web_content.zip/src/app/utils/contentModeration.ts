/**
 * 🛡️ د HealMate Content Moderation System
 * د غلطو او ناسمو پوستونو مخه نیول
 */

// 🚫 د منع شویو کلماتو لیست - Banned/Inappropriate Words
const BANNED_WORDS = {
  // د سیاسي کلمات
  political: [
    'طالبان', 'داعش', 'القاعده', 'تروریست', 'ترهگر',
    'taliban', 'isis', 'alqaeda', 'terrorist', 'terrorism'
  ],
  
  // د ناوړه کلمات
  offensive: [
    'احمق', 'بیوقوف', 'حرامی', 'لعنت', 'کثیف',
    'stupid', 'idiot', 'damn', 'hell', 'bastard', 'fuck', 'shit'
  ],
  
  // د جنسي محتوا
  adult: [
    'جنسی', 'سکس', 'عریان', 'پورن',
    'sex', 'porn', 'nude', 'xxx', 'adult'
  ],
  
  // د تشدد
  violence: [
    'قتل', 'وژنه', 'ځورول', 'تیری',
    'kill', 'murder', 'violence', 'attack', 'bomb', 'weapon', 'gun'
  ],
  
  // د منشیاتو
  drugs: [
    'چرس', 'هیروین', 'افیون', 'ماده',
    'drugs', 'heroin', 'cocaine', 'marijuana', 'weed', 'meth'
  ],
  
  // د Spam کلمات
  spam: [
    'click here', 'buy now', 'limited time', 'free money', 'winner',
    'اینجا کلیک کنید', 'همین الان بخرید', 'پول رایگان'
  ]
};

// 📧 Admin Email - د خبرتیاوو لپاره
const ADMIN_EMAIL = 'ibrahimkhaksar.it@gmail.com';
const ADMIN_PHONE = '+93783040441';

// 🔍 د Content چیک کول - Content Check
export function checkContent(text: string): {
  isClean: boolean;
  violations: string[];
  category: string;
  severity: 'low' | 'medium' | 'high';
} {
  const violations: string[] = [];
  let highestSeverity: 'low' | 'medium' | 'high' = 'low';
  let category = 'none';
  
  const lowerText = text.toLowerCase();
  
  // د هر category چیک کول
  Object.entries(BANNED_WORDS).forEach(([cat, words]) => {
    words.forEach(word => {
      if (lowerText.includes(word.toLowerCase())) {
        violations.push(word);
        category = cat;
        
        // د severity تعیین
        if (cat === 'adult' || cat === 'violence' || cat === 'drugs') {
          highestSeverity = 'high';
        } else if (cat === 'offensive' || cat === 'political') {
          if (highestSeverity !== 'high') highestSeverity = 'medium';
        } else if (cat === 'spam') {
          if (highestSeverity === 'low') highestSeverity = 'low';
        }
      }
    });
  });
  
  return {
    isClean: violations.length === 0,
    violations,
    category,
    severity: highestSeverity
  };
}

// 🚨 د Admin ته خبرتیا - Admin Notification
export function notifyAdmin(violation: {
  postId: number;
  author: string;
  content: string;
  violations: string[];
  category: string;
  severity: 'low' | 'medium' | 'high';
  timestamp: string;
}) {
  // د localStorage کې د violations ذخیره کول
  const stored = localStorage.getItem('healmate_violations');
  const violations = stored ? JSON.parse(stored) : [];
  
  violations.push({
    ...violation,
    notified: true,
    adminEmail: ADMIN_EMAIL,
    adminPhone: ADMIN_PHONE
  });
  
  localStorage.setItem('healmate_violations', JSON.stringify(violations));
  
  // د Console کې لاګ
  console.group('🚨 CONTENT VIOLATION DETECTED');
  console.log('Post ID:', violation.postId);
  console.log('Author:', violation.author);
  console.log('Category:', violation.category);
  console.log('Severity:', violation.severity);
  console.log('Violations:', violation.violations);
  console.log('Content:', violation.content.substring(0, 100) + '...');
  console.log('Timestamp:', violation.timestamp);
  console.log(`📧 Admin notified at: ${ADMIN_EMAIL}`);
  console.log(`📱 Admin phone: ${ADMIN_PHONE}`);
  console.groupEnd();
  
  // د اصلي Production کې، دلته API call کړئ چې:
  // 1. Admin ته Email واستوئ
  // 2. Admin ته SMS واستوئ
  // 3. Admin Panel کې notification جوړ کړئ
  
  return true;
}

// 📊 د Violations لیست اخیستل
export function getViolations(): any[] {
  const stored = localStorage.getItem('healmate_violations');
  return stored ? JSON.parse(stored) : [];
}

// 🧹 د Violations پاک کول
export function clearViolations() {
  localStorage.removeItem('healmate_violations');
}

// ⚠️ د Post Report کول
export interface ReportData {
  postId: number;
  reportedBy: string;
  reason: string;
  description: string;
  timestamp: string;
}

export function reportPost(data: ReportData) {
  const stored = localStorage.getItem('healmate_reports');
  const reports = stored ? JSON.parse(stored) : [];
  
  reports.push({
    ...data,
    status: 'pending',
    adminEmail: ADMIN_EMAIL,
  });
  
  localStorage.setItem('healmate_reports', JSON.stringify(reports));
  
  console.group('⚠️ POST REPORTED');
  console.log('Post ID:', data.postId);
  console.log('Reported By:', data.reportedBy);
  console.log('Reason:', data.reason);
  console.log('Description:', data.description);
  console.log(`📧 Admin notified at: ${ADMIN_EMAIL}`);
  console.groupEnd();
  
  return true;
}

// 📊 د Reports لیست اخیستل
export function getReports(): ReportData[] {
  const stored = localStorage.getItem('healmate_reports');
  return stored ? JSON.parse(stored) : [];
}

// ✅ د URL چیک کول - Suspicious URLs
export function checkForSuspiciousLinks(text: string): boolean {
  const urlPattern = /(https?:\/\/[^\s]+)/g;
  const urls = text.match(urlPattern);
  
  if (!urls) return false;
  
  // د شک لرونکو domains لیست
  const suspiciousDomains = [
    'bit.ly', 'tinyurl.com', 'goo.gl', 't.co',
    'short.link', 'rb.gy', 'is.gd'
  ];
  
  return urls.some(url => 
    suspiciousDomains.some(domain => url.includes(domain))
  );
}

// 🔢 د Spam Detection - د ډیرو numbers یا URLs
export function isSpam(text: string): boolean {
  // د ډیرو links
  const linkCount = (text.match(/(https?:\/\/[^\s]+)/g) || []).length;
  if (linkCount > 3) return true;
  
  // د ډیرو phone numbers
  const phoneCount = (text.match(/(\+?\d{10,})/g) || []).length;
  if (phoneCount > 2) return true;
  
  // د ډیرو capital letters
  const capitals = text.match(/[A-Z]/g) || [];
  if (capitals.length / text.length > 0.7) return true;
  
  // د ډیرو emojis
  const emojiCount = (text.match(/[\u{1F300}-\u{1F9FF}]/gu) || []).length;
  if (emojiCount > 10) return true;
  
  return false;
}

// 🎯 د بشپړ Post Validation
export function validatePost(
  content: string,
  author: string,
  postId?: number
): {
  isValid: boolean;
  reason?: string;
  shouldNotifyAdmin: boolean;
  violations?: string[];
} {
  // 1. د خالي content چیک
  if (!content || content.trim().length === 0) {
    return {
      isValid: false,
      reason: 'Post content cannot be empty / پوست نشي کولی خالي وي',
      shouldNotifyAdmin: false
    };
  }
  
  // 2. د ډیر لنډ content
  if (content.trim().length < 10) {
    return {
      isValid: false,
      reason: 'Post is too short. Please write at least 10 characters / پوست ډیر لنډ دی',
      shouldNotifyAdmin: false
    };
  }
  
  // 3. د ډیر اوږد content
  if (content.length > 5000) {
    return {
      isValid: false,
      reason: 'Post is too long. Maximum 5000 characters / پوست ډیر اوږد دی',
      shouldNotifyAdmin: false
    };
  }
  
  // 4. د Spam چیک
  if (isSpam(content)) {
    if (postId) {
      notifyAdmin({
        postId,
        author,
        content,
        violations: ['spam'],
        category: 'spam',
        severity: 'low',
        timestamp: new Date().toISOString()
      });
    }
    return {
      isValid: false,
      reason: 'Post detected as spam / پوست د spam په شان ښکاري',
      shouldNotifyAdmin: true,
      violations: ['spam']
    };
  }
  
  // 5. د Content چیک
  const contentCheck = checkContent(content);
  if (!contentCheck.isClean) {
    if (postId) {
      notifyAdmin({
        postId,
        author,
        content,
        violations: contentCheck.violations,
        category: contentCheck.category,
        severity: contentCheck.severity,
        timestamp: new Date().toISOString()
      });
    }
    
    return {
      isValid: false,
      reason: `Inappropriate content detected / ناسم محتوا موندل شو (${contentCheck.category})`,
      shouldNotifyAdmin: true,
      violations: contentCheck.violations
    };
  }
  
  // 6. د Suspicious Links چیک
  if (checkForSuspiciousLinks(content)) {
    if (postId) {
      notifyAdmin({
        postId,
        author,
        content,
        violations: ['suspicious links'],
        category: 'spam',
        severity: 'medium',
        timestamp: new Date().toISOString()
      });
    }
    return {
      isValid: false,
      reason: 'Suspicious links detected / شکمن links موندل شول',
      shouldNotifyAdmin: true,
      violations: ['suspicious links']
    };
  }
  
  // ✅ ټول چیکونه تېر شول
  return {
    isValid: true,
    shouldNotifyAdmin: false
  };
}
