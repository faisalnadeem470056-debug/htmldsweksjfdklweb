// Firebase Manager - Dual Mode Support (Firebase + LocalStorage)
// د Firebase مدیر - دوه ګوني حالت ملاتړ (Firebase + LocalStorage)

import { 
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
  signOut,
  sendPasswordResetEmail,
  updateProfile,
  User as FirebaseUser
} from 'firebase/auth';
import {
  collection,
  doc,
  setDoc,
  getDoc,
  getDocs,
  updateDoc,
  deleteDoc,
  addDoc,
  query,
  where,
  orderBy,
  limit,
  Timestamp
} from 'firebase/firestore';
import { ref, uploadBytes, getDownloadURL } from 'firebase/storage';
import { auth, db, storage, isFirebaseConfigured, getStorageMode } from '../config/firebase-config';

// Types
export interface User {
  id: string;
  email: string;
  name: string;
  phone?: string;
  avatar?: string;
  role: 'owner' | 'admin' | 'doctor' | 'user';
  isPremium?: boolean;
  premiumExpiryDate?: string;
  createdAt: string;
  lastLogin?: string;
}

export interface Post {
  id: string;
  userId: string;
  userName: string;
  userAvatar?: string;
  content: string;
  images?: string[];
  videos?: string[];
  likes: number;
  comments: number;
  shares: number;
  createdAt: string;
}

/**
 * Firebase Manager Class
 * د Firebase مدیریت کلاس
 */
export class FirebaseManager {
  private static instance: FirebaseManager;
  private mode: 'firebase' | 'localstorage';

  private constructor() {
    this.mode = getStorageMode();
    console.log(`🔧 FirebaseManager initialized in ${this.mode} mode`);
  }

  public static getInstance(): FirebaseManager {
    if (!FirebaseManager.instance) {
      FirebaseManager.instance = new FirebaseManager();
    }
    return FirebaseManager.instance;
  }

  // ==================== Authentication ====================

  /**
   * د کاروونکي ثبت نامه
   * Sign up a new user
   */
  async signUp(email: string, password: string, name: string, phone?: string): Promise<User> {
    if (this.mode === 'firebase' && auth) {
      try {
        const userCredential = await createUserWithEmailAndPassword(auth, email, password);
        const firebaseUser = userCredential.user;

        // Update profile with name
        await updateProfile(firebaseUser, { displayName: name });

        // Create user document in Firestore
        const userData: User = {
          id: firebaseUser.uid,
          email,
          name,
          phone,
          role: 'user',
          createdAt: new Date().toISOString(),
          lastLogin: new Date().toISOString()
        };

        await setDoc(doc(db!, 'users', firebaseUser.uid), userData);

        return userData;
      } catch (error: any) {
        console.error('❌ Firebase signup error:', error);
        throw new Error(error.message);
      }
    } else {
      // LocalStorage mode
      const users = JSON.parse(localStorage.getItem('healmate_users') || '[]');
      
      // Check if email already exists
      if (users.find((u: User) => u.email === email)) {
        throw new Error('Email already exists');
      }

      const newUser: User = {
        id: `user_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
        email,
        name,
        phone,
        role: 'user',
        createdAt: new Date().toISOString(),
        lastLogin: new Date().toISOString()
      };

      users.push({ ...newUser, password });
      localStorage.setItem('healmate_users', JSON.stringify(users));

      return newUser;
    }
  }

  /**
   * د کاروونکي ننوتل
   * Sign in a user
   */
  async signIn(email: string, password: string): Promise<User> {
    if (this.mode === 'firebase' && auth) {
      try {
        const userCredential = await signInWithEmailAndPassword(auth, email, password);
        const firebaseUser = userCredential.user;

        // Get user data from Firestore
        const userDoc = await getDoc(doc(db!, 'users', firebaseUser.uid));
        
        if (!userDoc.exists()) {
          throw new Error('User data not found');
        }

        const userData = userDoc.data() as User;

        // Update last login
        await updateDoc(doc(db!, 'users', firebaseUser.uid), {
          lastLogin: new Date().toISOString()
        });

        return userData;
      } catch (error: any) {
        console.error('❌ Firebase login error:', error);
        throw new Error(error.message);
      }
    } else {
      // LocalStorage mode
      const users = JSON.parse(localStorage.getItem('healmate_users') || '[]');
      const user = users.find((u: any) => u.email === email && u.password === password);

      if (!user) {
        throw new Error('Invalid email or password');
      }

      // Update last login
      user.lastLogin = new Date().toISOString();
      localStorage.setItem('healmate_users', JSON.stringify(users));

      const { password: _, ...userWithoutPassword } = user;
      return userWithoutPassword;
    }
  }

  /**
   * د کاروونکي وتل
   * Sign out a user
   */
  async signOut(): Promise<void> {
    if (this.mode === 'firebase' && auth) {
      await signOut(auth);
    }
    
    // Clear session in both modes
    localStorage.removeItem('healmate_user_session');
    localStorage.removeItem('healmate_admin_session');
  }

  /**
   * د پاسورډ بیا ترتیبول
   * Reset password
   */
  async resetPassword(email: string): Promise<void> {
    if (this.mode === 'firebase' && auth) {
      await sendPasswordResetEmail(auth, email);
    } else {
      // LocalStorage mode - just log the password
      const users = JSON.parse(localStorage.getItem('healmate_users') || '[]');
      const user = users.find((u: any) => u.email === email);

      if (!user) {
        throw new Error('User not found');
      }

      console.log('🔐 Password for', email, ':', user.password);
      alert(`Your password has been logged to the console. Please check.`);
    }
  }

  // ==================== User Management ====================

  /**
   * د کاروونکي معلومات ترمیمول
   * Update user profile
   */
  async updateUserProfile(userId: string, updates: Partial<User>): Promise<void> {
    if (this.mode === 'firebase' && db) {
      await updateDoc(doc(db, 'users', userId), updates);
    } else {
      // LocalStorage mode
      const users = JSON.parse(localStorage.getItem('healmate_users') || '[]');
      const userIndex = users.findIndex((u: User) => u.id === userId);

      if (userIndex === -1) {
        throw new Error('User not found');
      }

      users[userIndex] = { ...users[userIndex], ...updates };
      localStorage.setItem('healmate_users', JSON.stringify(users));

      // Update session if this is the current user
      const session = JSON.parse(localStorage.getItem('healmate_user_session') || 'null');
      if (session && session.id === userId) {
        localStorage.setItem('healmate_user_session', JSON.stringify({ ...session, ...updates }));
      }
    }
  }

  /**
   * د کاروونکي معلومات ترلاسه کول
   * Get user by ID
   */
  async getUserById(userId: string): Promise<User | null> {
    if (this.mode === 'firebase' && db) {
      const userDoc = await getDoc(doc(db, 'users', userId));
      return userDoc.exists() ? userDoc.data() as User : null;
    } else {
      // LocalStorage mode
      const users = JSON.parse(localStorage.getItem('healmate_users') || '[]');
      const user = users.find((u: User) => u.id === userId);
      return user || null;
    }
  }

  /**
   * د ټولو کاروونکو لیست
   * Get all users
   */
  async getAllUsers(): Promise<User[]> {
    if (this.mode === 'firebase' && db) {
      const usersSnapshot = await getDocs(collection(db, 'users'));
      return usersSnapshot.docs.map(doc => doc.data() as User);
    } else {
      // LocalStorage mode
      const users = JSON.parse(localStorage.getItem('healmate_users') || '[]');
      return users.map((u: any) => {
        const { password, ...userWithoutPassword } = u;
        return userWithoutPassword;
      });
    }
  }

  /**
   * د نوي کاروونکي اضافه کول
   * Add new user to Firestore
   */
  async addUser(userData: Partial<User>): Promise<string> {
    const now = new Date().toISOString();
    const newUser = {
      name: userData.name || 'HealMate User',
      email: userData.email || `user${Date.now()}@healmate.app`,
      phone: userData.phone || '',
      role: userData.role || 'user',
      isPremium: userData.isPremium || false,
      premiumExpiryDate: userData.premiumExpiryDate || '',
      createdAt: now,
      lastLogin: now,
      avatar: userData.avatar || '',
      ...userData
    };

    if (this.mode === 'firebase' && db) {
      // Firebase mode - د Firestore کې ساتل
      const docRef = await addDoc(collection(db, 'users'), newUser);
      return docRef.id;
    } else {
      // LocalStorage mode - په LocalStorage کې ساتل
      const users = JSON.parse(localStorage.getItem('healmate_users') || '[]');
      const userId = `user_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
      const userWithId = { ...newUser, id: userId };
      users.push(userWithId);
      localStorage.setItem('healmate_users', JSON.stringify(users));
      return userId;
    }
  }

  // ==================== File Upload ====================

  /**
   * د عکس یا فایل پورته کول
   * Upload image or file
   */
  async uploadFile(file: File, path: string): Promise<string> {
    if (this.mode === 'firebase' && storage) {
      const storageRef = ref(storage, path);
      await uploadBytes(storageRef, file);
      return await getDownloadURL(storageRef);
    } else {
      // LocalStorage mode - convert to base64
      return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onloadend = () => {
          resolve(reader.result as string);
        };
        reader.onerror = reject;
        reader.readAsDataURL(file);
      });
    }
  }

  // ==================== Posts Management ====================

  /**
   * نوی پوسټ جوړول
   * Create a new post
   */
  async createPost(post: Omit<Post, 'id' | 'createdAt'>): Promise<Post> {
    const newPost: Post = {
      ...post,
      id: `post_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      createdAt: new Date().toISOString()
    };

    if (this.mode === 'firebase' && db) {
      await setDoc(doc(db, 'posts', newPost.id), newPost);
    } else {
      // LocalStorage mode
      const posts = JSON.parse(localStorage.getItem('healmate_posts') || '[]');
      posts.unshift(newPost);
      localStorage.setItem('healmate_posts', JSON.stringify(posts));
    }

    return newPost;
  }

  /**
   * د ټولو پوسټونو لیست
   * Get all posts
   */
  async getAllPosts(limitCount: number = 50): Promise<Post[]> {
    if (this.mode === 'firebase' && db) {
      const postsQuery = query(
        collection(db, 'posts'),
        orderBy('createdAt', 'desc'),
        limit(limitCount)
      );
      const postsSnapshot = await getDocs(postsQuery);
      return postsSnapshot.docs.map(doc => doc.data() as Post);
    } else {
      // LocalStorage mode
      const posts = JSON.parse(localStorage.getItem('healmate_posts') || '[]');
      return posts.slice(0, limitCount);
    }
  }

  /**
   * پوسټ پاک کول
   * Delete a post
   */
  async deletePost(postId: string): Promise<void> {
    if (this.mode === 'firebase' && db) {
      await deleteDoc(doc(db, 'posts', postId));
    } else {
      // LocalStorage mode
      const posts = JSON.parse(localStorage.getItem('healmate_posts') || '[]');
      const filteredPosts = posts.filter((p: Post) => p.id !== postId);
      localStorage.setItem('healmate_posts', JSON.stringify(filteredPosts));
    }
  }

  // ==================== Sync Functions ====================

  /**
   * د LocalStorage څخه Firebase ته sync کول
   * Sync from LocalStorage to Firebase
   */
  async syncToFirebase(): Promise<void> {
    if (this.mode !== 'firebase' || !db) {
      throw new Error('Firebase is not configured');
    }

    try {
      // Sync users
      const users = JSON.parse(localStorage.getItem('healmate_users') || '[]');
      for (const user of users) {
        const { password, ...userData } = user;
        await setDoc(doc(db, 'users', user.id), userData);
      }

      // Sync posts
      const posts = JSON.parse(localStorage.getItem('healmate_posts') || '[]');
      for (const post of posts) {
        await setDoc(doc(db, 'posts', post.id), post);
      }

      console.log('✅ LocalStorage data synced to Firebase successfully');
    } catch (error) {
      console.error('❌ Sync to Firebase failed:', error);
      throw error;
    }
  }

  /**
   * د Firebase څخه LocalStorage ته sync کول
   * Sync from Firebase to LocalStorage
   */
  async syncFromFirebase(): Promise<void> {
    if (this.mode !== 'firebase' || !db) {
      throw new Error('Firebase is not configured');
    }

    try {
      // Sync users
      const usersSnapshot = await getDocs(collection(db, 'users'));
      const users = usersSnapshot.docs.map(doc => doc.data());
      localStorage.setItem('healmate_users', JSON.stringify(users));

      // Sync posts
      const postsSnapshot = await getDocs(collection(db, 'posts'));
      const posts = postsSnapshot.docs.map(doc => doc.data());
      localStorage.setItem('healmate_posts', JSON.stringify(posts));

      console.log('✅ Firebase data synced to LocalStorage successfully');
    } catch (error) {
      console.error('❌ Sync from Firebase failed:', error);
      throw error;
    }
  }

  // ==================== Utility Functions ====================

  /**
   * د storage mode ترلاسه کول
   * Get current storage mode
   */
  getMode(): 'firebase' | 'localstorage' {
    return this.mode;
  }

  /**
   * د Firebase حالت معلومول
   * Check if Firebase is available
   */
  isFirebaseAvailable(): boolean {
    return this.mode === 'firebase' && isFirebaseConfigured();
  }
}

// Export singleton instance
export const firebaseManager = FirebaseManager.getInstance();
