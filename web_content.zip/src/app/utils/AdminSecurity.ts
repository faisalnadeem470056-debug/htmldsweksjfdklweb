// Admin Security & Authorization Utilities
// د Admin Panel لپاره خوندیتوب او Authorization

/**
 * د Authorized Admin Emails لیست
 * یوازې دا emails Admin Panel ته لاسرسی لري
 */
const AUTHORIZED_ADMINS = [
  'ibrahimkhaksar.it@gmail.com',
  // د نورو admin emails دلته اضافه کړئ
];

/**
 * چیک کوي چې ایا کاروونکی Admin دی که نه
 * @param email - د کاروونکي بریښنالیک
 * @returns boolean - true که admin وي، false که نه وي
 */
export function isAdmin(email: string | null | undefined): boolean {
  if (!email) return false;
  return AUTHORIZED_ADMINS.includes(email.toLowerCase().trim());
}

/**
 * د Admin Access تصدیق کوي
 * @param email - د کاروونکي بریښنالیک
 * @throws Error که کاروونکی Admin نه وي
 */
export function verifyAdminAccess(email: string | null | undefined): void {
  if (!isAdmin(email)) {
    throw new Error('Unauthorized: Admin access required');
  }
}

/**
 * د Admin Session Timestamp
 * د Security لپاره د session وخت ثبتوي
 */
export function logAdminAccess(email: string, action: string): void {
  const timestamp = new Date().toISOString();
  console.log(`[ADMIN] ${timestamp} - ${email} - ${action}`);
  
  // په production کې، دا به Firebase/Database کې ذخیره کړو
  if (typeof window !== 'undefined') {
    const logs = JSON.parse(localStorage.getItem('adminLogs') || '[]');
    logs.push({
      email,
      action,
      timestamp,
      ip: 'N/A', // په production کې IP address واخلئ
    });
    // یوازې وروستي 100 logs ساتئ
    if (logs.length > 100) {
      logs.shift();
    }
    localStorage.setItem('adminLogs', JSON.stringify(logs));
  }
}

/**
 * د Admin Activity څخه logs واخلي
 * @returns Array د admin activities
 */
export function getAdminLogs(): any[] {
  if (typeof window === 'undefined') return [];
  return JSON.parse(localStorage.getItem('adminLogs') || '[]');
}

/**
 * د Admin Password لپاره اضافي تایید
 * د حساس عملیاتو لپاره
 */
export function requireAdminPassword(): boolean {
  // دا به په production کې implementation شي
  // فعلا یوازې true return کوي
  return true;
}

/**
 * د IP Address بندیز چیک کړئ
 * د Security لپاره
 */
export function isIPBlocked(ip: string): boolean {
  // په production کې د blocked IPs لیست چیک کړئ
  const blockedIPs: string[] = [];
  return blockedIPs.includes(ip);
}

/**
 * د Rate Limiting چیک
 * د ډېرو غوښتنو مخنیوی
 */
export function checkRateLimit(email: string): boolean {
  if (typeof window === 'undefined') return true;
  
  const key = `rateLimit_${email}`;
  const now = Date.now();
  const limit = 100; // ۱۰۰ غوښتنې
  const window_ms = 60 * 1000; // د ۱ دقیقې کې
  
  const requests = JSON.parse(localStorage.getItem(key) || '[]');
  const recentRequests = requests.filter((timestamp: number) => now - timestamp < window_ms);
  
  if (recentRequests.length >= limit) {
    console.warn(`[SECURITY] Rate limit exceeded for ${email}`);
    return false;
  }
  
  recentRequests.push(now);
  localStorage.setItem(key, JSON.stringify(recentRequests));
  return true;
}

/**
 * د Admin Permissions
 * مختلف admins ته مختلف permissions
 */
export enum AdminPermission {
  VIEW_USERS = 'view_users',
  EDIT_USERS = 'edit_users',
  DELETE_USERS = 'delete_users',
  VIEW_POSTS = 'view_posts',
  MODERATE_POSTS = 'moderate_posts',
  DELETE_POSTS = 'delete_posts',
  MANAGE_DOCTORS = 'manage_doctors',
  MANAGE_HOSPITALS = 'manage_hospitals',
  MANAGE_MEDICINES = 'manage_medicines',
  VIEW_LOGS = 'view_logs',
  SYSTEM_SETTINGS = 'system_settings',
  SUPER_ADMIN = 'super_admin',
}

/**
 * د Admin Roles
 */
export enum AdminRole {
  SUPER_ADMIN = 'super_admin',
  ADMIN = 'admin',
  MODERATOR = 'moderator',
  VIEWER = 'viewer',
}

/**
 * د Role Permissions mapping
 */
const rolePermissions: Record<AdminRole, AdminPermission[]> = {
  [AdminRole.SUPER_ADMIN]: [
    AdminPermission.VIEW_USERS,
    AdminPermission.EDIT_USERS,
    AdminPermission.DELETE_USERS,
    AdminPermission.VIEW_POSTS,
    AdminPermission.MODERATE_POSTS,
    AdminPermission.DELETE_POSTS,
    AdminPermission.MANAGE_DOCTORS,
    AdminPermission.MANAGE_HOSPITALS,
    AdminPermission.MANAGE_MEDICINES,
    AdminPermission.VIEW_LOGS,
    AdminPermission.SYSTEM_SETTINGS,
    AdminPermission.SUPER_ADMIN,
  ],
  [AdminRole.ADMIN]: [
    AdminPermission.VIEW_USERS,
    AdminPermission.EDIT_USERS,
    AdminPermission.VIEW_POSTS,
    AdminPermission.MODERATE_POSTS,
    AdminPermission.MANAGE_DOCTORS,
    AdminPermission.MANAGE_HOSPITALS,
    AdminPermission.MANAGE_MEDICINES,
    AdminPermission.VIEW_LOGS,
  ],
  [AdminRole.MODERATOR]: [
    AdminPermission.VIEW_USERS,
    AdminPermission.VIEW_POSTS,
    AdminPermission.MODERATE_POSTS,
    AdminPermission.VIEW_LOGS,
  ],
  [AdminRole.VIEWER]: [
    AdminPermission.VIEW_USERS,
    AdminPermission.VIEW_POSTS,
    AdminPermission.VIEW_LOGS,
  ],
};

/**
 * د کاروونکي Role ترلاسه کړئ
 * @param email - د کاروونکي بریښنالیک
 * @returns AdminRole
 */
export function getAdminRole(email: string): AdminRole {
  // Owner (ibrahimkhaksar.it@gmail.com) SUPER_ADMIN دی
  if (email === 'ibrahimkhaksar.it@gmail.com') {
    return AdminRole.SUPER_ADMIN;
  }
  
  // نور admins په production کې د database څخه role ترلاسه کوي
  // فعلا ټول ADMIN دي
  if (AUTHORIZED_ADMINS.includes(email)) {
    return AdminRole.ADMIN;
  }
  
  return AdminRole.VIEWER;
}

/**
 * چیک کړئ چې ایا کاروونکی مشخص permission لري
 * @param email - د کاروونکي بریښنالیک
 * @param permission - د غوښتل شوي permission
 * @returns boolean
 */
export function hasPermission(email: string, permission: AdminPermission): boolean {
  if (!isAdmin(email)) return false;
  
  const role = getAdminRole(email);
  const permissions = rolePermissions[role];
  
  return permissions.includes(permission);
}

/**
 * د Audit Trail لپاره event log کړئ
 * @param email - د Admin email
 * @param action - کړنه
 * @param details - تفصیل
 */
export function auditLog(email: string, action: string, details?: any): void {
  const auditEntry = {
    timestamp: new Date().toISOString(),
    email,
    action,
    details: details || {},
    ip: 'N/A', // په production کې واقعي IP
  };
  
  console.log('[AUDIT]', auditEntry);
  
  // په production کې د Database کې ذخیره کړئ
  if (typeof window !== 'undefined') {
    const audits = JSON.parse(localStorage.getItem('auditTrail') || '[]');
    audits.push(auditEntry);
    // یوازې وروستي 500 audit logs ساتئ
    if (audits.length > 500) {
      audits.shift();
    }
    localStorage.setItem('auditTrail', JSON.stringify(audits));
  }
}

/**
 * د Sensitive Operation تایید
 * د حساس کړنو لپاره اضافي تایید غواړي
 */
export async function confirmSensitiveOperation(message: string): Promise<boolean> {
  return confirm(message);
}

/**
 * د Session Timeout چیک
 * د Security لپاره admin session timeout
 */
export function checkSessionTimeout(): boolean {
  if (typeof window === 'undefined') return true;
  
  const lastActivity = localStorage.getItem('lastAdminActivity');
  if (!lastActivity) return true;
  
  const timeout = 30 * 60 * 1000; // ۳۰ دقیقې
  const now = Date.now();
  
  if (now - parseInt(lastActivity) > timeout) {
    console.warn('[SECURITY] Admin session timeout');
    return false;
  }
  
  return true;
}

/**
 * د Session Activity تازه کړئ
 */
export function updateSessionActivity(): void {
  if (typeof window !== 'undefined') {
    localStorage.setItem('lastAdminActivity', Date.now().toString());
  }
}

/**
 * د Security Headers چیک
 * په production کې important security headers تایید کړئ
 */
export function validateSecurityHeaders(): boolean {
  // په production کې د security headers تایید
  return true;
}

/**
 * د XSS Protection
 * د malicious input sanitization
 */
export function sanitizeInput(input: string): string {
  return input
    .replace(/</g, '<')
    .replace(/>/g, '>')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#x27;')
    .replace(/\//g, '&#x2F;');
}

/**
 * د Admin Panel لاسرسي تایید کړئ
 * @param email - د کاروونکي بریښنالیک
 * @returns Promise<boolean>
 */
export async function validateAdminAccess(email: string): Promise<boolean> {
  // چیک کړئ چې admin authorized دی
  if (!isAdmin(email)) {
    console.error(`[SECURITY] Unauthorized access attempt: ${email}`);
    return false;
  }
  
  // چیک کړئ چې rate limit نه دی تیر شوی
  if (!checkRateLimit(email)) {
    console.error(`[SECURITY] Rate limit exceeded: ${email}`);
    return false;
  }
  
  // چیک کړئ چې session timeout نه دی
  if (!checkSessionTimeout()) {
    console.error(`[SECURITY] Session timeout: ${email}`);
    return false;
  }
  
  // Session activity تازه کړئ
  updateSessionActivity();
  
  // Admin access log کړئ
  logAdminAccess(email, 'Panel Access');
  
  return true;
}

export default {
  isAdmin,
  verifyAdminAccess,
  logAdminAccess,
  getAdminLogs,
  requireAdminPassword,
  isIPBlocked,
  checkRateLimit,
  getAdminRole,
  hasPermission,
  auditLog,
  confirmSensitiveOperation,
  checkSessionTimeout,
  updateSessionActivity,
  validateSecurityHeaders,
  sanitizeInput,
  validateAdminAccess,
  AdminPermission,
  AdminRole,
};
