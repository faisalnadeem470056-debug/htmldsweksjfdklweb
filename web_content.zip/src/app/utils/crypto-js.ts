/**
 * CryptoJS Mock Implementation for Browser
 * Simple encryption/decryption without external dependencies
 */

// Simple Base64 encoding/decoding
const Base64 = {
  encode: (str: string): string => {
    try {
      return btoa(encodeURIComponent(str).replace(/%([0-9A-F]{2})/g, (match, p1) => {
        return String.fromCharCode(parseInt(p1, 16));
      }));
    } catch {
      return btoa(str);
    }
  },
  
  decode: (str: string): string => {
    try {
      return decodeURIComponent(Array.prototype.map.call(atob(str), (c: string) => {
        return '%' + ('00' + c.charCodeAt(0).toString(16)).slice(-2);
      }).join(''));
    } catch {
      return atob(str);
    }
  }
};

// Simple XOR cipher
function xorCipher(text: string, key: string): string {
  let result = '';
  for (let i = 0; i < text.length; i++) {
    result += String.fromCharCode(text.charCodeAt(i) ^ key.charCodeAt(i % key.length));
  }
  return result;
}

// Hash function (simple djb2)
function simpleHash(str: string): string {
  let hash = 5381;
  for (let i = 0; i < str.length; i++) {
    hash = ((hash << 5) + hash) + str.charCodeAt(i);
  }
  return Math.abs(hash).toString(16);
}

// PBKDF2 simplified implementation
function pbkdf2(password: string, salt: string, iterations: number, keySize: number): string {
  let result = password + salt;
  for (let i = 0; i < iterations; i++) {
    result = simpleHash(result);
  }
  return result.substring(0, keySize);
}

// Generate random bytes
function randomBytes(size: number): string {
  let result = '';
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
  for (let i = 0; i < size; i++) {
    result += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return result;
}

// CryptoJS compatible interface
const CryptoJS = {
  AES: {
    encrypt: (message: string, key: string): { toString: () => string } => {
      const encrypted = xorCipher(message, key);
      const encoded = Base64.encode(encrypted);
      return {
        toString: () => encoded
      };
    },
    
    decrypt: (ciphertext: string, key: string): { toString: (enc: any) => string } => {
      return {
        toString: (enc: any) => {
          const decoded = Base64.decode(ciphertext);
          return xorCipher(decoded, key);
        }
      };
    }
  },
  
  PBKDF2: (password: string, salt: string, options: { keySize: number; iterations: number }): { toString: () => string } => {
    const hash = pbkdf2(password, salt, options.iterations, options.keySize * 4);
    return {
      toString: () => hash
    };
  },
  
  lib: {
    WordArray: {
      random: (size: number): { toString: () => string } => {
        const bytes = randomBytes(size);
        return {
          toString: () => bytes
        };
      }
    }
  },
  
  enc: {
    Utf8: {}
  }
};

export default CryptoJS;
