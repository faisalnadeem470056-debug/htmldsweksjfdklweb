/**
 * HealMate Security System
 * Comprehensive security utilities for authentication, encryption, validation, and protection
 */

import CryptoJS from './crypto-js';

// Security Configuration
const SECURITY_CONFIG = {
  encryption: {
    algorithm: 'AES',
    keySize: 256,
    iterations: 10000
  },
  session: {
    timeout: 30 * 60 * 1000, // 30 minutes
    maxSessions: 3,
    refreshInterval: 5 * 60 * 1000 // 5 minutes
  },
  rateLimit: {
    maxRequests: 100,
    windowMs: 15 * 60 * 1000, // 15 minutes
    blockDuration: 60 * 60 * 1000 // 1 hour
  },
  password: {
    minLength: 8,
    requireUppercase: true,
    requireLowercase: true,
    requireNumbers: true,
    requireSpecialChars: true,
    maxAttempts: 5,
    lockoutDuration: 30 * 60 * 1000 // 30 minutes
  }
};

// Encryption Key (In production, this should be in environment variables)
const ENCRYPTION_KEY = process.env.ENCRYPTION_KEY || 'HealMate_2025_Secure_Key_Afghanistan';

// ============= 1. DATA ENCRYPTION =============

/**
 * Encrypt sensitive data using AES-256
 */
export function encryptData(data: string): string {
  try {
    const encrypted = CryptoJS.AES.encrypt(data, ENCRYPTION_KEY).toString();
    return encrypted;
  } catch (error) {
    console.error('Encryption error:', error);
    throw new Error('Failed to encrypt data');
  }
}

/**
 * Decrypt encrypted data
 */
export function decryptData(encryptedData: string): string {
  try {
    const decrypted = CryptoJS.AES.decrypt(encryptedData, ENCRYPTION_KEY);
    return decrypted.toString(CryptoJS.enc.Utf8);
  } catch (error) {
    console.error('Decryption error:', error);
    throw new Error('Failed to decrypt data');
  }
}

/**
 * Hash password using PBKDF2
 */
export function hashPassword(password: string, salt?: string): { hash: string; salt: string } {
  const passwordSalt = salt || CryptoJS.lib.WordArray.random(128/8).toString();
  const hash = CryptoJS.PBKDF2(password, passwordSalt, {
    keySize: 256/32,
    iterations: SECURITY_CONFIG.encryption.iterations
  }).toString();
  
  return { hash, salt: passwordSalt };
}

/**
 * Verify password against hash
 */
export function verifyPassword(password: string, hash: string, salt: string): boolean {
  const { hash: newHash } = hashPassword(password, salt);
  return newHash === hash;
}

/**
 * Generate secure random token
 */
export function generateSecureToken(length: number = 32): string {
  return CryptoJS.lib.WordArray.random(length).toString();
}

// ============= 2. INPUT VALIDATION & SANITIZATION =============

/**
 * Sanitize user input to prevent XSS attacks
 */
export function sanitizeInput(input: string): string {
  if (!input) return '';
  
  return input
    .replace(/&/g, '&')
    .replace(/</g, '<')
    .replace(/>/g, '>')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#x27;')
    .replace(/\//g, '&#x2F;')
    .trim();
}

/**
 * Validate email format
 */
export function validateEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

/**
 * Validate phone number (Afghanistan format)
 */
export function validatePhone(phone: string): boolean {
  const phoneRegex = /^(\+93|0)?[7][0-9]{8}$/;
  return phoneRegex.test(phone.replace(/\s/g, ''));
}

/**
 * Validate password strength
 */
export function validatePassword(password: string): { valid: boolean; errors: string[] } {
  const errors: string[] = [];
  const config = SECURITY_CONFIG.password;

  if (password.length < config.minLength) {
    errors.push(`Password must be at least ${config.minLength} characters`);
  }

  if (config.requireUppercase && !/[A-Z]/.test(password)) {
    errors.push('Password must contain at least one uppercase letter');
  }

  if (config.requireLowercase && !/[a-z]/.test(password)) {
    errors.push('Password must contain at least one lowercase letter');
  }

  if (config.requireNumbers && !/[0-9]/.test(password)) {
    errors.push('Password must contain at least one number');
  }

  if (config.requireSpecialChars && !/[!@#$%^&*(),.?":{}|<>]/.test(password)) {
    errors.push('Password must contain at least one special character');
  }

  return {
    valid: errors.length === 0,
    errors
  };
}

/**
 * Check for SQL Injection patterns
 */
export function detectSQLInjection(input: string): boolean {
  const sqlPatterns = [
    /(\b(SELECT|INSERT|UPDATE|DELETE|DROP|CREATE|ALTER|EXEC|EXECUTE)\b)/gi,
    /(--|;|\/\*|\*\/|xp_|sp_)/gi,
    /(\bOR\b.*=.*|1=1|'=')/gi
  ];

  return sqlPatterns.some(pattern => pattern.test(input));
}

/**
 * Check for XSS patterns
 */
export function detectXSS(input: string): boolean {
  const xssPatterns = [
    /<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi,
    /javascript:/gi,
    /on\w+\s*=/gi,
    /<iframe/gi,
    /<object/gi,
    /<embed/gi
  ];

  return xssPatterns.some(pattern => pattern.test(input));
}

// ============= 3. RATE LIMITING =============

interface RateLimitRecord {
  count: number;
  resetTime: number;
  blocked: boolean;
  blockUntil?: number;
}

class RateLimiter {
  private records: Map<string, RateLimitRecord> = new Map();

  check(identifier: string): { allowed: boolean; remaining: number; resetTime: number } {
    const now = Date.now();
    let record = this.records.get(identifier);

    // Check if blocked
    if (record?.blocked && record.blockUntil && now < record.blockUntil) {
      return {
        allowed: false,
        remaining: 0,
        resetTime: record.blockUntil
      };
    }

    // Reset if window expired
    if (!record || now > record.resetTime) {
      record = {
        count: 0,
        resetTime: now + SECURITY_CONFIG.rateLimit.windowMs,
        blocked: false
      };
      this.records.set(identifier, record);
    }

    record.count++;

    // Check if limit exceeded
    if (record.count > SECURITY_CONFIG.rateLimit.maxRequests) {
      record.blocked = true;
      record.blockUntil = now + SECURITY_CONFIG.rateLimit.blockDuration;
      return {
        allowed: false,
        remaining: 0,
        resetTime: record.blockUntil
      };
    }

    return {
      allowed: true,
      remaining: SECURITY_CONFIG.rateLimit.maxRequests - record.count,
      resetTime: record.resetTime
    };
  }

  reset(identifier: string): void {
    this.records.delete(identifier);
  }
}

export const rateLimiter = new RateLimiter();

// ============= 4. SESSION MANAGEMENT =============

interface Session {
  id: string;
  userId: string;
  email: string;
  createdAt: number;
  expiresAt: number;
  lastActivity: number;
  ipAddress: string;
  userAgent: string;
}

class SessionManager {
  private sessions: Map<string, Session> = new Map();

  createSession(userId: string, email: string, ipAddress: string, userAgent: string): string {
    const sessionId = generateSecureToken(64);
    const now = Date.now();

    // Remove old sessions for this user (keep only max sessions)
    const userSessions = Array.from(this.sessions.values())
      .filter(s => s.userId === userId)
      .sort((a, b) => b.lastActivity - a.lastActivity);

    if (userSessions.length >= SECURITY_CONFIG.session.maxSessions) {
      const sessionsToRemove = userSessions.slice(SECURITY_CONFIG.session.maxSessions - 1);
      sessionsToRemove.forEach(s => this.sessions.delete(s.id));
    }

    const session: Session = {
      id: sessionId,
      userId,
      email,
      createdAt: now,
      expiresAt: now + SECURITY_CONFIG.session.timeout,
      lastActivity: now,
      ipAddress,
      userAgent
    };

    this.sessions.set(sessionId, session);

    // Store in localStorage (encrypted)
    const encryptedSession = encryptData(JSON.stringify({
      id: sessionId,
      userId,
      email
    }));
    localStorage.setItem('healmate_session', encryptedSession);

    return sessionId;
  }

  validateSession(sessionId: string): { valid: boolean; session?: Session } {
    const session = this.sessions.get(sessionId);
    const now = Date.now();

    if (!session) {
      return { valid: false };
    }

    // Check if expired
    if (now > session.expiresAt) {
      this.sessions.delete(sessionId);
      localStorage.removeItem('healmate_session');
      return { valid: false };
    }

    // Update last activity
    session.lastActivity = now;
    session.expiresAt = now + SECURITY_CONFIG.session.timeout;

    return { valid: true, session };
  }

  refreshSession(sessionId: string): boolean {
    const session = this.sessions.get(sessionId);
    if (!session) return false;

    const now = Date.now();
    session.lastActivity = now;
    session.expiresAt = now + SECURITY_CONFIG.session.timeout;

    return true;
  }

  destroySession(sessionId: string): void {
    this.sessions.delete(sessionId);
    localStorage.removeItem('healmate_session');
  }

  getUserSessions(userId: string): Session[] {
    return Array.from(this.sessions.values())
      .filter(s => s.userId === userId);
  }

  destroyAllUserSessions(userId: string): void {
    const userSessions = this.getUserSessions(userId);
    userSessions.forEach(s => this.sessions.delete(s.id));
    localStorage.removeItem('healmate_session');
  }
}

export const sessionManager = new SessionManager();

// ============= 5. LOGIN ATTEMPT TRACKING =============

interface LoginAttempt {
  count: number;
  lastAttempt: number;
  lockedUntil?: number;
}

class LoginAttemptTracker {
  private attempts: Map<string, LoginAttempt> = new Map();

  recordAttempt(identifier: string): { allowed: boolean; remaining: number; lockedUntil?: number } {
    const now = Date.now();
    let attempt = this.attempts.get(identifier);

    if (!attempt) {
      attempt = { count: 0, lastAttempt: now };
      this.attempts.set(identifier, attempt);
    }

    // Check if locked
    if (attempt.lockedUntil && now < attempt.lockedUntil) {
      return {
        allowed: false,
        remaining: 0,
        lockedUntil: attempt.lockedUntil
      };
    }

    // Reset if lockout expired
    if (attempt.lockedUntil && now >= attempt.lockedUntil) {
      attempt.count = 0;
      attempt.lockedUntil = undefined;
    }

    attempt.count++;
    attempt.lastAttempt = now;

    // Lock if max attempts exceeded
    if (attempt.count >= SECURITY_CONFIG.password.maxAttempts) {
      attempt.lockedUntil = now + SECURITY_CONFIG.password.lockoutDuration;
      return {
        allowed: false,
        remaining: 0,
        lockedUntil: attempt.lockedUntil
      };
    }

    return {
      allowed: true,
      remaining: SECURITY_CONFIG.password.maxAttempts - attempt.count
    };
  }

  recordSuccess(identifier: string): void {
    this.attempts.delete(identifier);
  }

  isLocked(identifier: string): boolean {
    const attempt = this.attempts.get(identifier);
    if (!attempt?.lockedUntil) return false;
    
    const now = Date.now();
    return now < attempt.lockedUntil;
  }
}

export const loginAttemptTracker = new LoginAttemptTracker();

// ============= 6. TWO-FACTOR AUTHENTICATION (2FA) =============

/**
 * Generate 6-digit OTP code
 */
export function generateOTP(): string {
  return Math.floor(100000 + Math.random() * 900000).toString();
}

/**
 * Store OTP with expiration
 */
export function storeOTP(userId: string, otp: string, expiresIn: number = 5 * 60 * 1000): void {
  const otpData = {
    otp,
    expiresAt: Date.now() + expiresIn,
    userId
  };
  
  const encrypted = encryptData(JSON.stringify(otpData));
  localStorage.setItem(`otp_${userId}`, encrypted);
}

/**
 * Verify OTP
 */
export function verifyOTP(userId: string, otp: string): boolean {
  const encrypted = localStorage.getItem(`otp_${userId}`);
  if (!encrypted) return false;

  try {
    const decrypted = decryptData(encrypted);
    const otpData = JSON.parse(decrypted);

    const now = Date.now();
    if (now > otpData.expiresAt) {
      localStorage.removeItem(`otp_${userId}`);
      return false;
    }

    const valid = otpData.otp === otp;
    if (valid) {
      localStorage.removeItem(`otp_${userId}`);
    }

    return valid;
  } catch {
    return false;
  }
}

// ============= 7. ROLE-BASED ACCESS CONTROL (RBAC) =============

export enum Role {
  ADMIN = 'admin',
  DOCTOR = 'doctor',
  USER = 'user',
  PREMIUM_USER = 'premium_user',
  MODERATOR = 'moderator'
}

export enum Permission {
  // User permissions
  VIEW_POSTS = 'view_posts',
  CREATE_POSTS = 'create_posts',
  EDIT_OWN_POSTS = 'edit_own_posts',
  DELETE_OWN_POSTS = 'delete_own_posts',
  COMMENT = 'comment',
  REACT = 'react',
  
  // Doctor permissions
  VIEW_PATIENTS = 'view_patients',
  MANAGE_APPOINTMENTS = 'manage_appointments',
  PRESCRIBE_MEDICINE = 'prescribe_medicine',
  
  // Premium permissions
  VIEW_PREMIUM_CONTENT = 'view_premium_content',
  AD_FREE_EXPERIENCE = 'ad_free_experience',
  PRIORITY_SUPPORT = 'priority_support',
  
  // Moderator permissions
  MODERATE_POSTS = 'moderate_posts',
  MODERATE_COMMENTS = 'moderate_comments',
  BAN_USERS = 'ban_users',
  
  // Admin permissions
  MANAGE_USERS = 'manage_users',
  MANAGE_DOCTORS = 'manage_doctors',
  MANAGE_CONTENT = 'manage_content',
  VIEW_ANALYTICS = 'view_analytics',
  MANAGE_SETTINGS = 'manage_settings',
  FULL_ACCESS = 'full_access'
}

const rolePermissions: Record<Role, Permission[]> = {
  [Role.USER]: [
    Permission.VIEW_POSTS,
    Permission.CREATE_POSTS,
    Permission.EDIT_OWN_POSTS,
    Permission.DELETE_OWN_POSTS,
    Permission.COMMENT,
    Permission.REACT
  ],
  [Role.PREMIUM_USER]: [
    Permission.VIEW_POSTS,
    Permission.CREATE_POSTS,
    Permission.EDIT_OWN_POSTS,
    Permission.DELETE_OWN_POSTS,
    Permission.COMMENT,
    Permission.REACT,
    Permission.VIEW_PREMIUM_CONTENT,
    Permission.AD_FREE_EXPERIENCE,
    Permission.PRIORITY_SUPPORT
  ],
  [Role.DOCTOR]: [
    Permission.VIEW_POSTS,
    Permission.CREATE_POSTS,
    Permission.EDIT_OWN_POSTS,
    Permission.DELETE_OWN_POSTS,
    Permission.COMMENT,
    Permission.REACT,
    Permission.VIEW_PATIENTS,
    Permission.MANAGE_APPOINTMENTS,
    Permission.PRESCRIBE_MEDICINE
  ],
  [Role.MODERATOR]: [
    Permission.VIEW_POSTS,
    Permission.CREATE_POSTS,
    Permission.EDIT_OWN_POSTS,
    Permission.DELETE_OWN_POSTS,
    Permission.COMMENT,
    Permission.REACT,
    Permission.MODERATE_POSTS,
    Permission.MODERATE_COMMENTS,
    Permission.BAN_USERS
  ],
  [Role.ADMIN]: [Permission.FULL_ACCESS]
};

/**
 * Check if user has permission
 */
export function hasPermission(userRole: Role, permission: Permission): boolean {
  const permissions = rolePermissions[userRole];
  return permissions.includes(Permission.FULL_ACCESS) || permissions.includes(permission);
}

/**
 * Check if user has any of the permissions
 */
export function hasAnyPermission(userRole: Role, permissions: Permission[]): boolean {
  return permissions.some(p => hasPermission(userRole, p));
}

/**
 * Check if user has all permissions
 */
export function hasAllPermissions(userRole: Role, permissions: Permission[]): boolean {
  return permissions.every(p => hasPermission(userRole, p));
}

// ============= 8. AUDIT LOGGING =============

export enum AuditAction {
  LOGIN = 'login',
  LOGOUT = 'logout',
  REGISTER = 'register',
  PASSWORD_CHANGE = 'password_change',
  PASSWORD_RESET = 'password_reset',
  PROFILE_UPDATE = 'profile_update',
  POST_CREATE = 'post_create',
  POST_UPDATE = 'post_update',
  POST_DELETE = 'post_delete',
  COMMENT_CREATE = 'comment_create',
  USER_BAN = 'user_ban',
  USER_UNBAN = 'user_unban',
  PERMISSION_CHANGE = 'permission_change',
  SETTINGS_CHANGE = 'settings_change',
  SECURITY_ALERT = 'security_alert'
}

interface AuditLog {
  id: string;
  userId: string;
  action: AuditAction;
  details: string;
  ipAddress: string;
  userAgent: string;
  timestamp: number;
  success: boolean;
}

class AuditLogger {
  private logs: AuditLog[] = [];

  log(
    userId: string,
    action: AuditAction,
    details: string,
    success: boolean = true,
    ipAddress: string = 'unknown',
    userAgent: string = 'unknown'
  ): void {
    const log: AuditLog = {
      id: generateSecureToken(16),
      userId,
      action,
      details,
      ipAddress,
      userAgent,
      timestamp: Date.now(),
      success
    };

    this.logs.push(log);

    // Store in localStorage (encrypted)
    const existingLogs = this.getLogs();
    existingLogs.push(log);
    
    // Keep only last 1000 logs
    const recentLogs = existingLogs.slice(-1000);
    const encrypted = encryptData(JSON.stringify(recentLogs));
    localStorage.setItem('healmate_audit_logs', encrypted);
  }

  getLogs(userId?: string, action?: AuditAction): AuditLog[] {
    try {
      const encrypted = localStorage.getItem('healmate_audit_logs');
      if (!encrypted) return [];

      const decrypted = decryptData(encrypted);
      let logs: AuditLog[] = JSON.parse(decrypted);

      if (userId) {
        logs = logs.filter(l => l.userId === userId);
      }

      if (action) {
        logs = logs.filter(l => l.action === action);
      }

      return logs.sort((a, b) => b.timestamp - a.timestamp);
    } catch {
      return [];
    }
  }

  clearLogs(): void {
    this.logs = [];
    localStorage.removeItem('healmate_audit_logs');
  }
}

export const auditLogger = new AuditLogger();

// ============= 9. CONTENT SECURITY POLICY =============

/**
 * Generate Content Security Policy headers
 */
export function generateCSPHeaders(): Record<string, string> {
  return {
    'Content-Security-Policy': [
      "default-src 'self'",
      "script-src 'self' 'unsafe-inline' 'unsafe-eval' https://pagead2.googlesyndication.com https://googleads.g.doubleclick.net",
      "style-src 'self' 'unsafe-inline'",
      "img-src 'self' data: https: blob:",
      "font-src 'self' data:",
      "connect-src 'self' https://pagead2.googlesyndication.com",
      "frame-src https://googleads.g.doubleclick.net",
      "object-src 'none'",
      "base-uri 'self'",
      "form-action 'self'",
      "upgrade-insecure-requests"
    ].join('; '),
    'X-Content-Type-Options': 'nosniff',
    'X-Frame-Options': 'DENY',
    'X-XSS-Protection': '1; mode=block',
    'Referrer-Policy': 'strict-origin-when-cross-origin',
    'Permissions-Policy': 'geolocation=(), microphone=(), camera=()'
  };
}

// ============= 10. SECURE DATA STORAGE =============

/**
 * Store sensitive data securely
 */
export function secureStore(key: string, data: any): void {
  const serialized = JSON.stringify(data);
  const encrypted = encryptData(serialized);
  localStorage.setItem(`secure_${key}`, encrypted);
}

/**
 * Retrieve securely stored data
 */
export function secureRetrieve<T>(key: string): T | null {
  try {
    const encrypted = localStorage.getItem(`secure_${key}`);
    if (!encrypted) return null;

    const decrypted = decryptData(encrypted);
    return JSON.parse(decrypted) as T;
  } catch {
    return null;
  }
}

/**
 * Remove securely stored data
 */
export function secureRemove(key: string): void {
  localStorage.removeItem(`secure_${key}`);
}

// ============= 11. IP ADDRESS UTILITIES =============

/**
 * Get client IP address (mock - in production use server-side)
 */
export function getClientIP(): string {
  // In production, this should come from server
  return localStorage.getItem('client_ip') || 'unknown';
}

/**
 * Check if IP is blocked
 */
export function isIPBlocked(ip: string): boolean {
  const blockedIPs = secureRetrieve<string[]>('blocked_ips') || [];
  return blockedIPs.includes(ip);
}

/**
 * Block IP address
 */
export function blockIP(ip: string, reason: string): void {
  const blockedIPs = secureRetrieve<string[]>('blocked_ips') || [];
  if (!blockedIPs.includes(ip)) {
    blockedIPs.push(ip);
    secureStore('blocked_ips', blockedIPs);
    
    auditLogger.log('system', AuditAction.SECURITY_ALERT, `IP blocked: ${ip} - Reason: ${reason}`);
  }
}

/**
 * Unblock IP address
 */
export function unblockIP(ip: string): void {
  const blockedIPs = secureRetrieve<string[]>('blocked_ips') || [];
  const filtered = blockedIPs.filter(blockedIP => blockedIP !== ip);
  secureStore('blocked_ips', filtered);
}

// ============= 12. SECURITY UTILITIES =============

/**
 * Generate secure filename
 */
export function generateSecureFilename(originalName: string): string {
  const timestamp = Date.now();
  const random = generateSecureToken(8);
  const extension = originalName.split('.').pop();
  return `${timestamp}_${random}.${extension}`;
}

/**
 * Validate file type
 */
export function validateFileType(filename: string, allowedTypes: string[]): boolean {
  const extension = filename.split('.').pop()?.toLowerCase();
  return extension ? allowedTypes.includes(extension) : false;
}

/**
 * Validate file size
 */
export function validateFileSize(size: number, maxSize: number = 5 * 1024 * 1024): boolean {
  return size <= maxSize;
}

/**
 * Check if user agent is suspicious
 */
export function isSuspiciousUserAgent(userAgent: string): boolean {
  const suspiciousPatterns = [
    /bot/i,
    /crawler/i,
    /spider/i,
    /scraper/i,
    /curl/i,
    /wget/i
  ];

  return suspiciousPatterns.some(pattern => pattern.test(userAgent));
}

/**
 * Generate CSRF token
 */
export function generateCSRFToken(): string {
  const token = generateSecureToken(32);
  sessionStorage.setItem('csrf_token', token);
  return token;
}

/**
 * Verify CSRF token
 */
export function verifyCSRFToken(token: string): boolean {
  const storedToken = sessionStorage.getItem('csrf_token');
  return storedToken === token;
}

// ============= 13. EXPORT SECURITY CONFIG =============

export const SecurityConfig = SECURITY_CONFIG;

export default {
  encryptData,
  decryptData,
  hashPassword,
  verifyPassword,
  generateSecureToken,
  sanitizeInput,
  validateEmail,
  validatePhone,
  validatePassword,
  detectSQLInjection,
  detectXSS,
  rateLimiter,
  sessionManager,
  loginAttemptTracker,
  generateOTP,
  storeOTP,
  verifyOTP,
  hasPermission,
  hasAnyPermission,
  hasAllPermissions,
  auditLogger,
  generateCSPHeaders,
  secureStore,
  secureRetrieve,
  secureRemove,
  getClientIP,
  isIPBlocked,
  blockIP,
  unblockIP,
  generateSecureFilename,
  validateFileType,
  validateFileSize,
  isSuspiciousUserAgent,
  generateCSRFToken,
  verifyCSRFToken,
  Role,
  Permission,
  AuditAction,
  SecurityConfig
};