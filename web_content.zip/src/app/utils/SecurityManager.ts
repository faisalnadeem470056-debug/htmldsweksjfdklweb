/**
 * HealMate Security Manager
 * بشپړ امنیتي سیسټم د ویروس او هکینګ څخه محافظت لپاره
 * Developed by: Dr. Ibrahim Khaksar
 */

const ENCRYPTION_KEY = 'HealMate_2025_Secure_Key_Afghanistan_Health_App_Protection';
const MAX_REQUESTS_PER_MINUTE = 100;
const SESSION_TIMEOUT = 30 * 60 * 1000; // 30 minutes

class SecurityManager {
  private requestCounts: Map<string, { count: number; timestamp: number }> = new Map();
  private sessionStartTime: number = Date.now();
  private integrityHash: string = '';

  constructor() {
    this.initialize();
  }

  /**
   * د Security System پیل کول
   */
  private initialize() {
    // یوازې اساسي security features فعال کړو
    this.setupBasicSecurity();
    console.log('🔒 HealMate Security System Active');
  }

  /**
   * Basic Security Setup - بغیر annoying errors
   */
  private setupBasicSecurity() {
    // د production environment چیک کړو
    const isDevelopment = typeof window !== 'undefined' && 
                          (window.location.hostname === 'localhost' || 
                           window.location.hostname === '127.0.0.1' ||
                           window.location.hostname.includes('stackblitz') ||
                           window.location.hostname.includes('figma'));
    
    if (isDevelopment) {
      console.log('🔓 Development mode - Security checks relaxed');
      return;
    }

    // په production کې یوازې basic protection
    this.setupXSSProtection();
  }

  /**
   * Basic XSS Protection
   */
  private setupXSSProtection() {
    // د خطرناکو scripts مخنیوی
    const observer = new MutationObserver((mutations) => {
      mutations.forEach((mutation) => {
        mutation.addedNodes.forEach((node) => {
          if (node.nodeType === 1) {
            const element = node as Element;
            
            // یوازې dangerous inline scripts لیرې کړو
            if (element.tagName === 'SCRIPT') {
              const src = element.getAttribute('src');
              if (!src || (!src.startsWith('http') && !src.startsWith('/'))) {
                console.warn('⚠️ Suspicious script blocked');
                element.remove();
              }
            }
          }
        });
      });
    });

    if (document.body) {
      observer.observe(document.body, {
        childList: true,
        subtree: true,
      });
    }
  }

  /**
   * د Rate Limiting تصدیق
   */
  public checkRateLimit(identifier: string): boolean {
    const now = Date.now();
    const record = this.requestCounts.get(identifier);

    if (!record) {
      this.requestCounts.set(identifier, { count: 1, timestamp: now });
      return true;
    }

    // که یوه دقیقه تیره شوې وي، reset کړو
    if (now - record.timestamp > 60000) {
      this.requestCounts.set(identifier, { count: 1, timestamp: now });
      return true;
    }

    // د requests شمیرل
    record.count++;

    if (record.count > MAX_REQUESTS_PER_MINUTE) {
      console.warn('⚠️ Rate limit exceeded for:', identifier);
      return false;
    }

    return true;
  }

  /**
   * د Input Sanitization
   */
  public sanitizeInput(input: string): string {
    if (!input) return '';

    return input
      .replace(/</g, '<')
      .replace(/>/g, '>')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#x27;')
      .replace(/\//g, '&#x2F;');
  }

  /**
   * د HTML Sanitization
   */
  public sanitizeHTML(html: string): string {
    if (!html) return '';

    const temp = document.createElement('div');
    temp.textContent = html;
    return temp.innerHTML;
  }

  /**
   * د URL Validation
   */
  public isValidURL(url: string): boolean {
    try {
      const urlObj = new URL(url);
      return urlObj.protocol === 'http:' || urlObj.protocol === 'https:';
    } catch {
      return false;
    }
  }

  /**
   * د Email Validation
   */
  public isValidEmail(email: string): boolean {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
  }

  /**
   * د Phone Number Validation (Afghanistan)
   */
  public isValidAfghanPhone(phone: string): boolean {
    // Afghanistan phone numbers: +93 7xx xxx xxx یا 07xx xxx xxx
    const phoneRegex = /^(\+93|0)?7[0-9]{8}$/;
    return phoneRegex.test(phone.replace(/\s/g, ''));
  }

  /**
   * د Password Strength تصدیق
   */
  public checkPasswordStrength(password: string): {
    isStrong: boolean;
    score: number;
    feedback: string[];
  } {
    const feedback: string[] = [];
    let score = 0;

    if (password.length >= 8) score += 25;
    else feedback.push('Password should be at least 8 characters');

    if (/[a-z]/.test(password)) score += 25;
    else feedback.push('Include lowercase letters');

    if (/[A-Z]/.test(password)) score += 25;
    else feedback.push('Include uppercase letters');

    if (/[0-9]/.test(password)) score += 25;
    else feedback.push('Include numbers');

    if (/[^a-zA-Z0-9]/.test(password)) score += 10;

    return {
      isStrong: score >= 75,
      score,
      feedback,
    };
  }

  /**
   * د LocalStorage Encryption
   */
  public encryptData(data: string): string {
    // Simple XOR encryption (د development لپاره)
    let encrypted = '';
    for (let i = 0; i < data.length; i++) {
      encrypted += String.fromCharCode(
        data.charCodeAt(i) ^ ENCRYPTION_KEY.charCodeAt(i % ENCRYPTION_KEY.length)
      );
    }
    return btoa(encrypted); // Base64 encode
  }

  /**
   * د LocalStorage Decryption
   */
  public decryptData(encryptedData: string): string {
    try {
      const decoded = atob(encryptedData); // Base64 decode
      let decrypted = '';
      for (let i = 0; i < decoded.length; i++) {
        decrypted += String.fromCharCode(
          decoded.charCodeAt(i) ^ ENCRYPTION_KEY.charCodeAt(i % ENCRYPTION_KEY.length)
        );
      }
      return decrypted;
    } catch {
      return '';
    }
  }

  /**
   * د Secure Storage
   */
  public secureStore(key: string, value: any): void {
    try {
      const jsonString = JSON.stringify(value);
      const encrypted = this.encryptData(jsonString);
      localStorage.setItem(`healmate_${key}`, encrypted);
    } catch (error) {
      console.error('Storage error:', error);
    }
  }

  /**
   * د Secure Retrieval
   */
  public secureRetrieve(key: string): any {
    try {
      const encrypted = localStorage.getItem(`healmate_${key}`);
      if (!encrypted) return null;

      const decrypted = this.decryptData(encrypted);
      return JSON.parse(decrypted);
    } catch (error) {
      console.error('Retrieval error:', error);
      return null;
    }
  }

  /**
   * د Session وخت تصدیق
   */
  public isSessionValid(): boolean {
    const sessionDuration = Date.now() - this.sessionStartTime;
    return sessionDuration < SESSION_TIMEOUT;
  }

  /**
   * د Session Reset
   */
  public resetSession(): void {
    this.sessionStartTime = Date.now();
  }

  /**
   * د Security Event Logging (silent)
   */
  private logSecurityEvent(eventType: string, details: string): void {
    // یوازې په console کې log کړو، error مه ویسو
    const timestamp = new Date().toISOString();
    console.log(`[Security] ${timestamp} - ${eventType}: ${details}`);
  }

  /**
   * د Security Status وګورئ
   */
  public getSecurityStatus(): {
    isSessionValid: boolean;
    sessionDuration: number;
    requestCount: number;
  } {
    const sessionDuration = Date.now() - this.sessionStartTime;
    const requestCount = Array.from(this.requestCounts.values())
      .reduce((sum, record) => sum + record.count, 0);

    return {
      isSessionValid: this.isSessionValid(),
      sessionDuration: Math.floor(sessionDuration / 1000), // په ثانیو کې
      requestCount,
    };
  }
}

// د Global Instance جوړول
const securityManager = new SecurityManager();

// Export
export default securityManager;
export { SecurityManager };
