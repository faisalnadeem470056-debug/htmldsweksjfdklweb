// 🤖 HealMate AI Response Generator
// د بشپړ طبي معلوماتو د ورکولو لپاره

import { medicalKnowledgeDatabase, healthTips } from '../data/medical-knowledge-database';

export function generateAIHealthResponse(
  question: string, 
  isPremium: boolean, 
  language: 'ps' | 'fa' | 'en'
): string {
  const questionLower = question.toLowerCase();
  
  // د medical database څخه د مناسب condition پیدا کول
  let matchedCondition: string | null = null;
  let highestMatchScore = 0;
  
  // د هر condition لپاره keywords وګورو
  for (const [conditionKey, condition] of Object.entries(medicalKnowledgeDatabase)) {
    let matchScore = 0;
    for (const keyword of condition.keywords) {
      if (questionLower.includes(keyword.toLowerCase())) {
        matchScore += 1;
      }
    }
    
    if (matchScore > highestMatchScore) {
      highestMatchScore = matchScore;
      matchedCondition = conditionKey;
    }
  }
  
  // که match وموندل شو
  if (matchedCondition && highestMatchScore > 0) {
    const condition = medicalKnowledgeDatabase[matchedCondition];
    
    if (isPremium) {
      // د Premium users لپاره بشپړ معلومات
      return generatePremiumResponse(condition, language);
    } else {
      // د Free users لپاره لنډ جواب
      return generateBasicResponse(condition, language);
    }
  }
  
  // که کوم match ونه موندل شو - General health tips
  if (questionLower.includes('tip') || questionLower.includes('مشوره') || questionLower.includes('توصیه') || 
      questionLower.includes('health') || questionLower.includes('روغتیا') || questionLower.includes('سلامت')) {
    return generateHealthTips(language);
  }
  
  // Default response
  return generateDefaultResponse(language, isPremium);
}

function generatePremiumResponse(condition: any, lang: 'ps' | 'fa' | 'en'): string {
  // د urgency indicator
  const urgencyEmoji = condition.urgency === 'emergency' ? '🚨' : 
                      condition.urgency === 'high' ? '⚠️' : 
                      condition.urgency === 'medium' ? '📋' : '💡';
  
  let response = '';
  
  if (lang === 'ps') {
    response = `${urgencyEmoji} **د ${condition.category} په اړه بشپړ معلومات**\n\n`;
    
    // علایم
    if (condition.symptoms.length > 0) {
      response += `📌 **علایم:**\n`;
      condition.symptoms.forEach((s: string, i: number) => response += `${i + 1}. ${s}\n`);
      response += '\n';
    }
    
    // سببونه
    if (condition.causes.length > 0) {
      response += `🔍 **سببونه:**\n`;
      condition.causes.forEach((c: string) => response += `• ${c}\n`);
      response += '\n';
    }
    
    // درملنه
    if (condition.treatments.length > 0) {
      response += `💊 **درملنه او مشورې:**\n`;
      condition.treatments.forEach((t: string, i: number) => response += `${i + 1}. ${t}\n`);
      response += '\n';
    }
    
    // د درملو نومونه
    if (condition.medications.length > 0) {
      response += `💉 **د درملو نومونه:**\n`;
      condition.medications.forEach((m: string) => response += `• ${m}\n`);
      response += '\n';
    }
    
    // مخنیوی
    if (condition.prevention.length > 0) {
      response += `🛡️ **د مخنیوي طریقې:**\n`;
      condition.prevention.forEach((p: string, i: number) => response += `${i + 1}. ${p}\n`);
      response += '\n';
    }
    
    // د urgency سپارښتنه
    if (condition.urgency === 'emergency') {
      response += '\n🚨 **EMERGENCY:** سمدستي ډاکټر ته مراجعه وکړئ!\n';
    } else if (condition.urgency === 'high') {
      response += '\n⚠️ **مهم:** د ډاکټر سره مشوره ضروري ده.\n';
    } else {
      response += '\n💡 **یادښت:** که مسله دوام وکړي یا بدتره شي، له ډاکټر سره مشوره وکړئ.\n';
    }
    
    response += '\n📞 د اضطراري حالتونو لپاره: 119 ته زنګ ووهئ';
    
  } else if (lang === 'fa') {
    response = `${urgencyEmoji} **اطلاعات کامل درباره ${condition.category}**\n\n`;
    
    // علائم
    if (condition.symptoms.length > 0) {
      response += `📌 **علائم:**\n`;
      condition.symptoms.forEach((s: string, i: number) => response += `${i + 1}. ${s}\n`);
      response += '\n';
    }
    
    // علل
    if (condition.causes.length > 0) {
      response += `🔍 **علل:**\n`;
      condition.causes.forEach((c: string) => response += `• ${c}\n`);
      response += '\n';
    }
    
    // درمان
    if (condition.treatments.length > 0) {
      response += `💊 **درمان و توصیه‌ها:**\n`;
      condition.treatments.forEach((t: string, i: number) => response += `${i + 1}. ${t}\n`);
      response += '\n';
    }
    
    // داروها
    if (condition.medications.length > 0) {
      response += `💉 **نام داروها:**\n`;
      condition.medications.forEach((m: string) => response += `• ${m}\n`);
      response += '\n';
    }
    
    // پیشگیری
    if (condition.prevention.length > 0) {
      response += `🛡️ **روش‌های پیشگیری:**\n`;
      condition.prevention.forEach((p: string, i: number) => response += `${i + 1}. ${p}\n`);
      response += '\n';
    }
    
    // توصیه urgency
    if (condition.urgency === 'emergency') {
      response += '\n🚨 **EMERGENCY:** فوراً به پزشک مراجعه کنید!\n';
    } else if (condition.urgency === 'high') {
      response += '\n⚠️ **مهم:** مشورت با پزشک ضروری است.\n';
    } else {
      response += '\n💡 **یادداشت:** اگر مشکل ادامه یافت یا بدتر شد، با پزشک مشورت کنید.\n';
    }
    
    response += '\n📞 برای موارد اضطراری: با 119 تماس بگیرید';
    
  } else {
    response = `${urgencyEmoji} **Complete Information about ${condition.category}**\n\n`;
    
    // Symptoms
    if (condition.symptoms.length > 0) {
      response += `📌 **Symptoms:**\n`;
      condition.symptoms.forEach((s: string, i: number) => response += `${i + 1}. ${s}\n`);
      response += '\n';
    }
    
    // Causes
    if (condition.causes.length > 0) {
      response += `🔍 **Causes:**\n`;
      condition.causes.forEach((c: string) => response += `• ${c}\n`);
      response += '\n';
    }
    
    // Treatment
    if (condition.treatments.length > 0) {
      response += `💊 **Treatment & Recommendations:**\n`;
      condition.treatments.forEach((t: string, i: number) => response += `${i + 1}. ${t}\n`);
      response += '\n';
    }
    
    // Medications
    if (condition.medications.length > 0) {
      response += `💉 **Medications:**\n`;
      condition.medications.forEach((m: string) => response += `• ${m}\n`);
      response += '\n';
    }
    
    // Prevention
    if (condition.prevention.length > 0) {
      response += `🛡️ **Prevention Methods:**\n`;
      condition.prevention.forEach((p: string, i: number) => response += `${i + 1}. ${p}\n`);
      response += '\n';
    }
    
    // Urgency recommendation
    if (condition.urgency === 'emergency') {
      response += '\n🚨 **EMERGENCY:** Seek immediate medical attention!\n';
    } else if (condition.urgency === 'high') {
      response += '\n⚠️ **Important:** Consultation with a doctor is necessary.\n';
    } else {
      response += '\n💡 **Note:** If problem persists or worsens, consult a doctor.\n';
    }
    
    response += '\n📞 For emergencies: Call 119';
  }
  
  return response;
}

function generateBasicResponse(condition: any, lang: 'ps' | 'fa' | 'en'): string {
  if (lang === 'ps') {
    return `د ${condition.category} په اړه:\n\n• د لومړني مرستې لپاره: ${condition.treatments[0] || 'د ډاکټر سره مشوره وکړئ'}\n\n💡 د بشپړ معلوماتو، درملنې، درملو نومونو، او د مخنیوي طریقو لپاره Premium ته اپګریډ وکړئ.\n\n⚠️ یادونه: که مسله جدي وي، سمدستي ډاکټر ته مراجعه وکړئ.`;
  } else if (lang === 'fa') {
    return `درباره ${condition.category}:\n\n• برای کمک اولیه: ${condition.treatments[0] || 'با پزشک مشورت کنید'}\n\n💡 برای اطلاعات کامل، درمان، نام داروها و روش‌های پیشگیری به پریمیوم ارتقا دهید.\n\n⚠️ توجه: اگر مشکل جدی است، فوراً به پزشک مراجعه کنید.`;
  } else {
    return `About ${condition.category}:\n\n• For first aid: ${condition.treatments[0] || 'Consult a doctor'}\n\n💡 For complete information, treatment, medication names, and prevention methods, upgrade to Premium.\n\n⚠️ Note: If problem is serious, seek immediate medical attention.`;
  }
}

function generateHealthTips(lang: 'ps' | 'fa' | 'en'): string {
  const tips = healthTips[lang];
  let response = '';
  
  if (lang === 'ps') {
    response = '🌟 **د روغتیا عمومي مشورې:**\n\n';
    tips.forEach((tip: string) => response += `${tip}\n`);
    response += '\n💡 د خاصو روغتیایي پوښتنو لپاره، مهرباني وکړئ تفصیل سره پوښتنه وکړئ.';
  } else if (lang === 'fa') {
    response = '🌟 **توصیه‌های عمومی سلامت:**\n\n';
    tips.forEach((tip: string) => response += `${tip}\n`);
    response += '\n💡 برای سوالات خاص سلامتی، لطفاً با جزئیات بپرسید.';
  } else {
    response = '🌟 **General Health Tips:**\n\n';
    tips.forEach((tip: string) => response += `${tip}\n`);
    response += '\n💡 For specific health questions, please ask with details.';
  }
  
  return response;
}

function generateDefaultResponse(lang: 'ps' | 'fa' | 'en', isPremium: boolean): string {
  const basicResponses = {
    ps: [
      'د روغتیا په اړه ستاسو پوښتنې ته مننه! زه د لومړني معلوماتو ورکولو هڅه کوم.',
      'د دې مسلې په اړه، زه وړاندیز کوم چې د عمومي روغتیا اصولو پیروي وکړئ.',
      'دا یوه ښه پوښتنه ده. د نورو تفصیلي ځوابونو لپاره، زموږ Premium AI استعمال کړئ.',
    ],
    fa: [
      'متشکرم از سوال سلامتی شما! من سعی می‌کنم اطلاعات پایه را ارائه دهم.',
      'در مورد این مشکل، توصیه می‌کنم از اصول عمومی سلامت پیروی کنید.',
      'این سوال خوبی است. برای پاسخ‌های دقیق‌تر، از AI پریمیوم ما استفاده کنید.',
    ],
    en: [
      'Thank you for your health question! I\'ll try to provide basic information.',
      'Regarding this issue, I recommend following general health principles.',
      'That\'s a good question. For more detailed answers, use our Premium AI.',
    ]
  };
  
  const premiumResponses = {
    ps: [
      '🩺 بشپړ تحلیل: د ستاسو پوښتنې په اساس، دلته یو بشپړ لارښود دی...',
      '👨‍⚕️ مسلکي مشوره: د ستاسو د حالت په نظر کې نیولو سره، دلته زما وړاندیزونه دي...',
      '📊 د ډیټا تحلیل: د ستاسو د معلوماتو په اساس، دا د غوره حل لارې دي...',
    ],
    fa: [
      '🩺 تحلیل کامل: بر اساس سوال شما، اینجا یک راهنمای جامع است...',
      '👨‍⚕️ مشاوره حرفه‌ای: با توجه به وضعیت شما، اینجا توصیه‌های من است...',
      '📊 تحلیل داده: بر اساس اطلاعات شما، اینها بهترین راه‌حل‌ها هستند...',
    ],
    en: [
      '🩺 Complete Analysis: Based on your question, here\'s a comprehensive guide...',
      '👨‍⚕️ Professional Advice: Considering your situation, here are my recommendations...',
      '📊 Data Analysis: Based on your information, these are the best solutions...',
    ]
  };
  
  const responses = isPremium ? premiumResponses[lang] : basicResponses[lang];
  const baseResponse = responses[Math.floor(Math.random() * responses.length)];
  
  if (lang === 'ps') {
    return baseResponse + 
           '\n\n📝 د غوره نتیجو لپاره، مهرباني وکړئ خپله پوښتنه واضح او تفصیلي وکړئ. مثلاً:\n' +
           '• "د سر درد لپاره څه وکړم؟"\n' +
           '• "د زړه روغتیا څنګه ساتلی شم؟"\n' +
           '• "د قند ناروغي د علایم څه دي؟"\n' +
           '• "د وزن کمولو لپاره مشوره؟"\n' +
           '• "د اسټما درملنه؟"';
  } else if (lang === 'fa') {
    return baseResponse + 
           '\n\n📝 برای نتایج بهتر، لطفاً سوال خود را واضح و دقیق بپرسید. مثلاً:\n' +
           '• "برای سردرد چه کنم؟"\n' +
           '• "چگونه سلامت قلب را حفظ کنم؟"\n' +
           '• "علائم دیابت چیست؟"\n' +
           '• "توصیه برای کاهش وزن؟"\n' +
           '• "درمان آسم؟"';
  } else {
    return baseResponse + 
           '\n\n📝 For better results, please ask your question clearly and specifically. For example:\n' +
           '• "What should I do for headache?"\n' +
           '• "How to maintain heart health?"\n' +
           '• "What are diabetes symptoms?"\n' +
           '• "Advice for weight loss?"\n' +
           '• "Asthma treatment?"';
  }
}
