/**
 * 🔒 HealMate Data Manager - بشپړ ډیټا مدیریت سیسټم
 * د ټولو ډیټا د ساتلو، لوستلو او مدیریت لپاره
 * Author: Dr. Ibrahim Khaksar
 */

// ================== INTERFACES ==================
export interface UserProfile {
  email: string;
  name: string;
  phone: string;
  age?: number;
  gender?: string;
  bloodType?: string;
  height?: number;
  weight?: number;
  profileImage?: string;
  coverImage?: string;
  bio?: string;
  location?: string;
  isPremium: boolean;
  premiumExpiryDate?: string;
  createdAt: string;
  updatedAt: string;
}

export interface HealthRecord {
  id: string;
  userId: string;
  date: string;
  type: 'blood_pressure' | 'weight' | 'blood_sugar' | 'temperature' | 'heart_rate' | 'oxygen' | 'exercise' | 'sleep';
  value: string;
  unit: string;
  notes?: string;
  createdAt: string;
}

export interface MedicineReminder {
  id: string;
  userId: string;
  medicineName: string;
  dosage: string;
  frequency: string;
  timings: string[];
  startDate: string;
  endDate?: string;
  notes?: string;
  isActive: boolean;
  createdAt: string;
}

export interface Appointment {
  id: string;
  userId: string;
  doctorName: string;
  doctorSpecialty: string;
  hospital: string;
  date: string;
  time: string;
  reason: string;
  status: 'scheduled' | 'completed' | 'cancelled';
  notes?: string;
  createdAt: string;
}

export interface Post {
  id: string;
  userId: string;
  userName: string;
  userImage: string;
  content: string;
  images?: string[];
  videos?: string[];
  likes: string[];
  comments: Comment[];
  shares: number;
  createdAt: string;
  updatedAt: string;
}

export interface Comment {
  id: string;
  userId: string;
  userName: string;
  userImage: string;
  content: string;
  createdAt: string;
}

export interface SavedContent {
  id: string;
  userId: string;
  type: 'article' | 'tip' | 'post' | 'medicine';
  contentId: string;
  title: string;
  savedAt: string;
}

export interface AppSettings {
  language: 'ps' | 'fa' | 'en';
  theme: 'light' | 'dark' | 'auto';
  notifications: boolean;
  soundEnabled: boolean;
  dataSync: boolean;
  autoBackup: boolean;
  fontSize: 'small' | 'medium' | 'large';
  updatedAt: string;
}

export interface EmergencyContact {
  id: string;
  userId: string;
  name: string;
  phone: string;
  relationship: string;
  isPrimary: boolean;
  createdAt: string;
}

export interface HealthChallenge {
  id: string;
  userId: string;
  challengeType: string;
  completed: boolean;
  completedDate?: string;
  points: number;
  createdAt: string;
}

// ================== DATA MANAGER CLASS ==================
class DataManagerClass {
  private dbName = 'HealMateDB';
  private version = 1;
  private db: IDBDatabase | null = null;

  constructor() {
    this.initDB();
  }

  // Initialize IndexedDB
  private async initDB(): Promise<void> {
    return new Promise((resolve, reject) => {
      if (typeof window === 'undefined' || !window.indexedDB) {
        console.warn('IndexedDB not available, using localStorage fallback');
        resolve();
        return;
      }

      const request = indexedDB.open(this.dbName, this.version);

      request.onerror = () => {
        console.error('Failed to open IndexedDB');
        reject(request.error);
      };

      request.onsuccess = () => {
        this.db = request.result;
        resolve();
      };

      request.onupgradeneeded = (event) => {
        const db = (event.target as IDBOpenDBRequest).result;

        // Create object stores
        if (!db.objectStoreNames.contains('users')) {
          db.createObjectStore('users', { keyPath: 'email' });
        }
        if (!db.objectStoreNames.contains('healthRecords')) {
          const healthStore = db.createObjectStore('healthRecords', { keyPath: 'id' });
          healthStore.createIndex('userId', 'userId', { unique: false });
          healthStore.createIndex('date', 'date', { unique: false });
        }
        if (!db.objectStoreNames.contains('medicines')) {
          const medStore = db.createObjectStore('medicines', { keyPath: 'id' });
          medStore.createIndex('userId', 'userId', { unique: false });
        }
        if (!db.objectStoreNames.contains('appointments')) {
          const apptStore = db.createObjectStore('appointments', { keyPath: 'id' });
          apptStore.createIndex('userId', 'userId', { unique: false });
          apptStore.createIndex('date', 'date', { unique: false });
        }
        if (!db.objectStoreNames.contains('posts')) {
          const postStore = db.createObjectStore('posts', { keyPath: 'id' });
          postStore.createIndex('userId', 'userId', { unique: false });
        }
        if (!db.objectStoreNames.contains('savedContent')) {
          const savedStore = db.createObjectStore('savedContent', { keyPath: 'id' });
          savedStore.createIndex('userId', 'userId', { unique: false });
        }
        if (!db.objectStoreNames.contains('emergencyContacts')) {
          const emergencyStore = db.createObjectStore('emergencyContacts', { keyPath: 'id' });
          emergencyStore.createIndex('userId', 'userId', { unique: false });
        }
        if (!db.objectStoreNames.contains('challenges')) {
          const challengeStore = db.createObjectStore('challenges', { keyPath: 'id' });
          challengeStore.createIndex('userId', 'userId', { unique: false });
        }
      };
    });
  }

  // ================== USER PROFILE ==================
  async saveUserProfile(profile: UserProfile): Promise<void> {
    localStorage.setItem(`healmate_user_${profile.email}`, JSON.stringify(profile));
    localStorage.setItem('healmate_currentUser', profile.email);
    
    if (this.db) {
      return new Promise((resolve, reject) => {
        const transaction = this.db!.transaction(['users'], 'readwrite');
        const store = transaction.objectStore('users');
        const request = store.put(profile);
        request.onsuccess = () => resolve();
        request.onerror = () => reject(request.error);
      });
    }
  }

  async getUserProfile(email: string): Promise<UserProfile | null> {
    const cached = localStorage.getItem(`healmate_user_${email}`);
    if (cached) {
      return JSON.parse(cached);
    }

    if (this.db) {
      return new Promise((resolve, reject) => {
        const transaction = this.db!.transaction(['users'], 'readonly');
        const store = transaction.objectStore('users');
        const request = store.get(email);
        request.onsuccess = () => resolve(request.result || null);
        request.onerror = () => reject(request.error);
      });
    }

    return null;
  }

  async updateUserProfile(email: string, updates: Partial<UserProfile>): Promise<void> {
    const profile = await this.getUserProfile(email);
    if (profile) {
      const updated = { ...profile, ...updates, updatedAt: new Date().toISOString() };
      await this.saveUserProfile(updated);
    }
  }

  // ================== HEALTH RECORDS ==================
  async saveHealthRecord(record: HealthRecord): Promise<void> {
    const key = `healmate_health_${record.userId}`;
    const records = await this.getHealthRecords(record.userId);
    records.push(record);
    localStorage.setItem(key, JSON.stringify(records));

    if (this.db) {
      return new Promise((resolve, reject) => {
        const transaction = this.db!.transaction(['healthRecords'], 'readwrite');
        const store = transaction.objectStore('healthRecords');
        const request = store.put(record);
        request.onsuccess = () => resolve();
        request.onerror = () => reject(request.error);
      });
    }
  }

  async getHealthRecords(userId: string): Promise<HealthRecord[]> {
    const key = `healmate_health_${userId}`;
    const cached = localStorage.getItem(key);
    if (cached) {
      return JSON.parse(cached);
    }

    if (this.db) {
      return new Promise((resolve, reject) => {
        const transaction = this.db!.transaction(['healthRecords'], 'readonly');
        const store = transaction.objectStore('healthRecords');
        const index = store.index('userId');
        const request = index.getAll(userId);
        request.onsuccess = () => resolve(request.result || []);
        request.onerror = () => reject(request.error);
      });
    }

    return [];
  }

  async deleteHealthRecord(userId: string, recordId: string): Promise<void> {
    const records = await this.getHealthRecords(userId);
    const filtered = records.filter(r => r.id !== recordId);
    localStorage.setItem(`healmate_health_${userId}`, JSON.stringify(filtered));

    if (this.db) {
      return new Promise((resolve, reject) => {
        const transaction = this.db!.transaction(['healthRecords'], 'readwrite');
        const store = transaction.objectStore('healthRecords');
        const request = store.delete(recordId);
        request.onsuccess = () => resolve();
        request.onerror = () => reject(request.error);
      });
    }
  }

  // ================== MEDICINE REMINDERS ==================
  async saveMedicineReminder(reminder: MedicineReminder): Promise<void> {
    const key = `healmate_medicines_${reminder.userId}`;
    const reminders = await this.getMedicineReminders(reminder.userId);
    reminders.push(reminder);
    localStorage.setItem(key, JSON.stringify(reminders));

    if (this.db) {
      return new Promise((resolve, reject) => {
        const transaction = this.db!.transaction(['medicines'], 'readwrite');
        const store = transaction.objectStore('medicines');
        const request = store.put(reminder);
        request.onsuccess = () => resolve();
        request.onerror = () => reject(request.error);
      });
    }
  }

  async getMedicineReminders(userId: string): Promise<MedicineReminder[]> {
    const key = `healmate_medicines_${userId}`;
    const cached = localStorage.getItem(key);
    if (cached) {
      return JSON.parse(cached);
    }

    if (this.db) {
      return new Promise((resolve, reject) => {
        const transaction = this.db!.transaction(['medicines'], 'readonly');
        const store = transaction.objectStore('medicines');
        const index = store.index('userId');
        const request = index.getAll(userId);
        request.onsuccess = () => resolve(request.result || []);
        request.onerror = () => reject(request.error);
      });
    }

    return [];
  }

  async updateMedicineReminder(userId: string, reminderId: string, updates: Partial<MedicineReminder>): Promise<void> {
    const reminders = await this.getMedicineReminders(userId);
    const updated = reminders.map(r => r.id === reminderId ? { ...r, ...updates } : r);
    localStorage.setItem(`healmate_medicines_${userId}`, JSON.stringify(updated));

    if (this.db && updates) {
      const reminder = reminders.find(r => r.id === reminderId);
      if (reminder) {
        const updatedReminder = { ...reminder, ...updates };
        return new Promise((resolve, reject) => {
          const transaction = this.db!.transaction(['medicines'], 'readwrite');
          const store = transaction.objectStore('medicines');
          const request = store.put(updatedReminder);
          request.onsuccess = () => resolve();
          request.onerror = () => reject(request.error);
        });
      }
    }
  }

  async deleteMedicineReminder(userId: string, reminderId: string): Promise<void> {
    const reminders = await this.getMedicineReminders(userId);
    const filtered = reminders.filter(r => r.id !== reminderId);
    localStorage.setItem(`healmate_medicines_${userId}`, JSON.stringify(filtered));

    if (this.db) {
      return new Promise((resolve, reject) => {
        const transaction = this.db!.transaction(['medicines'], 'readwrite');
        const store = transaction.objectStore('medicines');
        const request = store.delete(reminderId);
        request.onsuccess = () => resolve();
        request.onerror = () => reject(request.error);
      });
    }
  }

  // ================== APPOINTMENTS ==================
  async saveAppointment(appointment: Appointment): Promise<void> {
    const key = `healmate_appointments_${appointment.userId}`;
    const appointments = await this.getAppointments(appointment.userId);
    appointments.push(appointment);
    localStorage.setItem(key, JSON.stringify(appointments));

    if (this.db) {
      return new Promise((resolve, reject) => {
        const transaction = this.db!.transaction(['appointments'], 'readwrite');
        const store = transaction.objectStore('appointments');
        const request = store.put(appointment);
        request.onsuccess = () => resolve();
        request.onerror = () => reject(request.error);
      });
    }
  }

  async getAppointments(userId: string): Promise<Appointment[]> {
    const key = `healmate_appointments_${userId}`;
    const cached = localStorage.getItem(key);
    if (cached) {
      return JSON.parse(cached);
    }

    if (this.db) {
      return new Promise((resolve, reject) => {
        const transaction = this.db!.transaction(['appointments'], 'readonly');
        const store = transaction.objectStore('appointments');
        const index = store.index('userId');
        const request = index.getAll(userId);
        request.onsuccess = () => resolve(request.result || []);
        request.onerror = () => reject(request.error);
      });
    }

    return [];
  }

  async updateAppointment(userId: string, appointmentId: string, updates: Partial<Appointment>): Promise<void> {
    const appointments = await this.getAppointments(userId);
    const updated = appointments.map(a => a.id === appointmentId ? { ...a, ...updates } : a);
    localStorage.setItem(`healmate_appointments_${userId}`, JSON.stringify(updated));

    if (this.db && updates) {
      const appointment = appointments.find(a => a.id === appointmentId);
      if (appointment) {
        const updatedAppointment = { ...appointment, ...updates };
        return new Promise((resolve, reject) => {
          const transaction = this.db!.transaction(['appointments'], 'readwrite');
          const store = transaction.objectStore('appointments');
          const request = store.put(updatedAppointment);
          request.onsuccess = () => resolve();
          request.onerror = () => reject(request.error);
        });
      }
    }
  }

  async deleteAppointment(userId: string, appointmentId: string): Promise<void> {
    const appointments = await this.getAppointments(userId);
    const filtered = appointments.filter(a => a.id !== appointmentId);
    localStorage.setItem(`healmate_appointments_${userId}`, JSON.stringify(filtered));

    if (this.db) {
      return new Promise((resolve, reject) => {
        const transaction = this.db!.transaction(['appointments'], 'readwrite');
        const store = transaction.objectStore('appointments');
        const request = store.delete(appointmentId);
        request.onsuccess = () => resolve();
        request.onerror = () => reject(request.error);
      });
    }
  }

  // ================== POSTS ==================
  async savePost(post: Post): Promise<void> {
    const key = 'healmate_posts';
    const posts = await this.getAllPosts();
    posts.unshift(post);
    localStorage.setItem(key, JSON.stringify(posts));

    if (this.db) {
      return new Promise((resolve, reject) => {
        const transaction = this.db!.transaction(['posts'], 'readwrite');
        const store = transaction.objectStore('posts');
        const request = store.put(post);
        request.onsuccess = () => resolve();
        request.onerror = () => reject(request.error);
      });
    }
  }

  async getAllPosts(): Promise<Post[]> {
    const key = 'healmate_posts';
    const cached = localStorage.getItem(key);
    if (cached) {
      return JSON.parse(cached);
    }

    if (this.db) {
      return new Promise((resolve, reject) => {
        const transaction = this.db!.transaction(['posts'], 'readonly');
        const store = transaction.objectStore('posts');
        const request = store.getAll();
        request.onsuccess = () => resolve(request.result || []);
        request.onerror = () => reject(request.error);
      });
    }

    return [];
  }

  async updatePost(postId: string, updates: Partial<Post>): Promise<void> {
    const posts = await this.getAllPosts();
    const updated = posts.map(p => p.id === postId ? { ...p, ...updates, updatedAt: new Date().toISOString() } : p);
    localStorage.setItem('healmate_posts', JSON.stringify(updated));

    if (this.db && updates) {
      const post = posts.find(p => p.id === postId);
      if (post) {
        const updatedPost = { ...post, ...updates, updatedAt: new Date().toISOString() };
        return new Promise((resolve, reject) => {
          const transaction = this.db!.transaction(['posts'], 'readwrite');
          const store = transaction.objectStore('posts');
          const request = store.put(updatedPost);
          request.onsuccess = () => resolve();
          request.onerror = () => reject(request.error);
        });
      }
    }
  }

  async deletePost(postId: string): Promise<void> {
    const posts = await this.getAllPosts();
    const filtered = posts.filter(p => p.id !== postId);
    localStorage.setItem('healmate_posts', JSON.stringify(filtered));

    if (this.db) {
      return new Promise((resolve, reject) => {
        const transaction = this.db!.transaction(['posts'], 'readwrite');
        const store = transaction.objectStore('posts');
        const request = store.delete(postId);
        request.onsuccess = () => resolve();
        request.onerror = () => reject(request.error);
      });
    }
  }

  // ================== SAVED CONTENT ==================
  async saveContent(content: SavedContent): Promise<void> {
    const key = `healmate_saved_${content.userId}`;
    const saved = await this.getSavedContent(content.userId);
    saved.push(content);
    localStorage.setItem(key, JSON.stringify(saved));

    if (this.db) {
      return new Promise((resolve, reject) => {
        const transaction = this.db!.transaction(['savedContent'], 'readwrite');
        const store = transaction.objectStore('savedContent');
        const request = store.put(content);
        request.onsuccess = () => resolve();
        request.onerror = () => reject(request.error);
      });
    }
  }

  async getSavedContent(userId: string): Promise<SavedContent[]> {
    const key = `healmate_saved_${userId}`;
    const cached = localStorage.getItem(key);
    if (cached) {
      return JSON.parse(cached);
    }

    if (this.db) {
      return new Promise((resolve, reject) => {
        const transaction = this.db!.transaction(['savedContent'], 'readonly');
        const store = transaction.objectStore('savedContent');
        const index = store.index('userId');
        const request = index.getAll(userId);
        request.onsuccess = () => resolve(request.result || []);
        request.onerror = () => reject(request.error);
      });
    }

    return [];
  }

  async unsaveContent(userId: string, contentId: string): Promise<void> {
    const saved = await this.getSavedContent(userId);
    const filtered = saved.filter(s => s.id !== contentId);
    localStorage.setItem(`healmate_saved_${userId}`, JSON.stringify(filtered));

    if (this.db) {
      return new Promise((resolve, reject) => {
        const transaction = this.db!.transaction(['savedContent'], 'readwrite');
        const store = transaction.objectStore('savedContent');
        const request = store.delete(contentId);
        request.onsuccess = () => resolve();
        request.onerror = () => reject(request.error);
      });
    }
  }

  // ================== EMERGENCY CONTACTS ==================
  async saveEmergencyContact(contact: EmergencyContact): Promise<void> {
    const key = `healmate_emergency_${contact.userId}`;
    const contacts = await this.getEmergencyContacts(contact.userId);
    contacts.push(contact);
    localStorage.setItem(key, JSON.stringify(contacts));

    if (this.db) {
      return new Promise((resolve, reject) => {
        const transaction = this.db!.transaction(['emergencyContacts'], 'readwrite');
        const store = transaction.objectStore('emergencyContacts');
        const request = store.put(contact);
        request.onsuccess = () => resolve();
        request.onerror = () => reject(request.error);
      });
    }
  }

  async getEmergencyContacts(userId: string): Promise<EmergencyContact[]> {
    const key = `healmate_emergency_${userId}`;
    const cached = localStorage.getItem(key);
    if (cached) {
      return JSON.parse(cached);
    }

    if (this.db) {
      return new Promise((resolve, reject) => {
        const transaction = this.db!.transaction(['emergencyContacts'], 'readonly');
        const store = transaction.objectStore('emergencyContacts');
        const index = store.index('userId');
        const request = index.getAll(userId);
        request.onsuccess = () => resolve(request.result || []);
        request.onerror = () => reject(request.error);
      });
    }

    return [];
  }

  async deleteEmergencyContact(userId: string, contactId: string): Promise<void> {
    const contacts = await this.getEmergencyContacts(userId);
    const filtered = contacts.filter(c => c.id !== contactId);
    localStorage.setItem(`healmate_emergency_${userId}`, JSON.stringify(filtered));

    if (this.db) {
      return new Promise((resolve, reject) => {
        const transaction = this.db!.transaction(['emergencyContacts'], 'readwrite');
        const store = transaction.objectStore('emergencyContacts');
        const request = store.delete(contactId);
        request.onsuccess = () => resolve();
        request.onerror = () => reject(request.error);
      });
    }
  }

  // ================== SETTINGS ==================
  async saveSettings(userId: string, settings: AppSettings): Promise<void> {
    localStorage.setItem(`healmate_settings_${userId}`, JSON.stringify(settings));
  }

  async getSettings(userId: string): Promise<AppSettings> {
    const key = `healmate_settings_${userId}`;
    const cached = localStorage.getItem(key);
    if (cached) {
      return JSON.parse(cached);
    }

    // Default settings
    return {
      language: 'ps',
      theme: 'light',
      notifications: true,
      soundEnabled: true,
      dataSync: true,
      autoBackup: true,
      fontSize: 'medium',
      updatedAt: new Date().toISOString()
    };
  }

  // ================== CHALLENGES ==================
  async saveChallenge(challenge: HealthChallenge): Promise<void> {
    const key = `healmate_challenges_${challenge.userId}`;
    const challenges = await this.getChallenges(challenge.userId);
    challenges.push(challenge);
    localStorage.setItem(key, JSON.stringify(challenges));

    if (this.db) {
      return new Promise((resolve, reject) => {
        const transaction = this.db!.transaction(['challenges'], 'readwrite');
        const store = transaction.objectStore('challenges');
        const request = store.put(challenge);
        request.onsuccess = () => resolve();
        request.onerror = () => reject(request.error);
      });
    }
  }

  async getChallenges(userId: string): Promise<HealthChallenge[]> {
    const key = `healmate_challenges_${userId}`;
    const cached = localStorage.getItem(key);
    if (cached) {
      return JSON.parse(cached);
    }

    if (this.db) {
      return new Promise((resolve, reject) => {
        const transaction = this.db!.transaction(['challenges'], 'readonly');
        const store = transaction.objectStore('challenges');
        const index = store.index('userId');
        const request = index.getAll(userId);
        request.onsuccess = () => resolve(request.result || []);
        request.onerror = () => reject(request.error);
      });
    }

    return [];
  }

  // ================== BACKUP & RESTORE ==================
  async createBackup(userId: string): Promise<string> {
    const backup = {
      version: '2.0',
      timestamp: new Date().toISOString(),
      user: await this.getUserProfile(userId),
      healthRecords: await this.getHealthRecords(userId),
      medicines: await this.getMedicineReminders(userId),
      appointments: await this.getAppointments(userId),
      savedContent: await this.getSavedContent(userId),
      emergencyContacts: await this.getEmergencyContacts(userId),
      challenges: await this.getChallenges(userId),
      settings: await this.getSettings(userId)
    };

    return JSON.stringify(backup);
  }

  async restoreBackup(backupData: string): Promise<void> {
    try {
      const backup = JSON.parse(backupData);
      const userId = backup.user?.email;

      if (!userId) {
        throw new Error('Invalid backup data');
      }

      // Restore user profile
      if (backup.user) {
        await this.saveUserProfile(backup.user);
      }

      // Restore health records
      if (backup.healthRecords) {
        for (const record of backup.healthRecords) {
          await this.saveHealthRecord(record);
        }
      }

      // Restore medicines
      if (backup.medicines) {
        for (const medicine of backup.medicines) {
          await this.saveMedicineReminder(medicine);
        }
      }

      // Restore appointments
      if (backup.appointments) {
        for (const appointment of backup.appointments) {
          await this.saveAppointment(appointment);
        }
      }

      // Restore saved content
      if (backup.savedContent) {
        for (const content of backup.savedContent) {
          await this.saveContent(content);
        }
      }

      // Restore emergency contacts
      if (backup.emergencyContacts) {
        for (const contact of backup.emergencyContacts) {
          await this.saveEmergencyContact(contact);
        }
      }

      // Restore challenges
      if (backup.challenges) {
        for (const challenge of backup.challenges) {
          await this.saveChallenge(challenge);
        }
      }

      // Restore settings
      if (backup.settings) {
        await this.saveSettings(userId, backup.settings);
      }

      console.log('✅ Backup restored successfully');
    } catch (error) {
      console.error('❌ Failed to restore backup:', error);
      throw error;
    }
  }

  // ================== CLEAR DATA ==================
  async clearUserData(userId: string): Promise<void> {
    localStorage.removeItem(`healmate_user_${userId}`);
    localStorage.removeItem(`healmate_health_${userId}`);
    localStorage.removeItem(`healmate_medicines_${userId}`);
    localStorage.removeItem(`healmate_appointments_${userId}`);
    localStorage.removeItem(`healmate_saved_${userId}`);
    localStorage.removeItem(`healmate_emergency_${userId}`);
    localStorage.removeItem(`healmate_challenges_${userId}`);
    localStorage.removeItem(`healmate_settings_${userId}`);

    if (this.db) {
      // Clear IndexedDB data for this user
      const stores = ['users', 'healthRecords', 'medicines', 'appointments', 'savedContent', 'emergencyContacts', 'challenges'];
      
      for (const storeName of stores) {
        try {
          const transaction = this.db.transaction([storeName], 'readwrite');
          const store = transaction.objectStore(storeName);
          
          if (storeName === 'users') {
            store.delete(userId);
          } else {
            const index = store.index('userId');
            const request = index.openCursor(userId);
            
            request.onsuccess = (event) => {
              const cursor = (event.target as IDBRequest).result;
              if (cursor) {
                cursor.delete();
                cursor.continue();
              }
            };
          }
        } catch (error) {
          console.error(`Error clearing ${storeName}:`, error);
        }
      }
    }

    console.log('✅ User data cleared');
  }

  // ================== CACHE MANAGEMENT ==================
  clearCache(): void {
    // Clear only cache, keep user data
    const keys = Object.keys(localStorage);
    for (const key of keys) {
      if (key.includes('healmate_cache_') || key.includes('healmate_temp_')) {
        localStorage.removeItem(key);
      }
    }
    console.log('✅ Cache cleared');
  }

  // ================== STATISTICS ==================
  async getStatistics(userId: string): Promise<any> {
    const healthRecords = await this.getHealthRecords(userId);
    const medicines = await this.getMedicineReminders(userId);
    const appointments = await this.getAppointments(userId);
    const challenges = await this.getChallenges(userId);
    const savedContent = await this.getSavedContent(userId);

    return {
      totalHealthRecords: healthRecords.length,
      totalMedicines: medicines.length,
      activeMedicines: medicines.filter(m => m.isActive).length,
      totalAppointments: appointments.length,
      upcomingAppointments: appointments.filter(a => a.status === 'scheduled' && new Date(a.date) > new Date()).length,
      completedChallenges: challenges.filter(c => c.completed).length,
      totalPoints: challenges.reduce((sum, c) => sum + (c.completed ? c.points : 0), 0),
      savedItems: savedContent.length
    };
  }
}

// Export singleton instance
export const dataManager = new DataManagerClass();

// Export helper functions
export const generateId = () => {
  return `${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
};

export const formatDate = (date: Date | string): string => {
  const d = typeof date === 'string' ? new Date(date) : date;
  return d.toISOString().split('T')[0];
};

export const formatTime = (date: Date | string): string => {
  const d = typeof date === 'string' ? new Date(date) : date;
  return d.toTimeString().split(' ')[0].slice(0, 5);
};
