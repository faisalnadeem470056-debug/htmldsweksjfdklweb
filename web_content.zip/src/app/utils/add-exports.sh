#!/bin/bash
# د ټولو components لپاره default exports اضافه کول

components=(
  "FamilyProfiles"
  "LabTestBooking"
  "MedicineReminder"
  "HealthDashboard"
  "EPharmacy"
  "HealthInsurance"
  "DoctorChat"
  "VideoConsultation"
  "SymptomsTracker"
  "AIHealthAssistant"
  "HealthAnalytics"
  "DoctorReviews"
  "AppointmentManagement"
  "NotificationsCenter"
  "UserProfile"
  "AdminPanel"
  "SocialFeed"
)

for component in "${components[@]}"; do
  file="/components/${component}.tsx"
  # Check if export default already exists
  if ! grep -q "^export default ${component}" "$file"; then
    echo "" >> "$file"
    echo "export default ${component};" >> "$file"
    echo "Added export to ${component}.tsx"
  else
    echo "Export already exists in ${component}.tsx"
  fi
done
