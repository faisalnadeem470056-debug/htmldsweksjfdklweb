// ═══════════════════════════════════════════════════════════════
// 👑 PREMIUM SUBSCRIPTION MANAGER
// ═══════════════════════════════════════════════════════════════
//
// د Premium subscription management utility
// Google Play Billing + Apple In-App Purchase support
//
// ═══════════════════════════════════════════════════════════════

import { Plans, AutoRenewal, ExpiryNotifications } from '../config/premium.config';

// 📊 Subscription Status Type
export type SubscriptionStatus = 'free' | 'premium_monthly' | 'premium_yearly' | 'premium_lifetime' | 'expired' | 'grace_period';

// 💳 Subscription Data Interface
export interface SubscriptionData {
  userId: string;
  plan: 'free' | 'monthly' | 'yearly' | 'lifetime';
  status: SubscriptionStatus;
  startDate: number; // timestamp
  expiryDate: number | null; // timestamp (null for lifetime)
  autoRenew: boolean;
  platform: 'android' | 'ios' | 'web';
  purchaseToken?: string; // د Google Play
  transactionId?: string; // د Apple
  gracePeriodEnd?: number; // timestamp
}

// ═══════════════════════════════════════════════════════════════
// 🔧 PREMIUM MANAGER CLASS
// ═══════════════════════════════════════════════════════════════

class PremiumManager {
  private storageKey = 'healmate_premium_subscription';

  // ───────────────────────────────────────────────────────────────
  // 📊 CHECK SUBSCRIPTION STATUS
  // ───────────────────────────────────────────────────────────────
  
  /**
   * د user subscription status چک کړئ
   */
  public getSubscriptionStatus(userId: string): SubscriptionData | null {
    try {
      const data = localStorage.getItem(`${this.storageKey}_${userId}`);
      if (!data) return null;

      const subscription: SubscriptionData = JSON.parse(data);
      
      // د expiry چک کړئ
      if (subscription.expiryDate && Date.now() > subscription.expiryDate) {
        // Check if in grace period
        if (subscription.gracePeriodEnd && Date.now() <= subscription.gracePeriodEnd) {
          subscription.status = 'grace_period';
        } else {
          subscription.status = 'expired';
        }
        this.updateSubscription(userId, subscription);
      }

      return subscription;
    } catch (error) {
      console.error('[PremiumManager] Error getting subscription:', error);
      return null;
    }
  }

  /**
   * د user premium status چک کړئ (simple boolean)
   */
  public isPremium(userId: string): boolean {
    const subscription = this.getSubscriptionStatus(userId);
    if (!subscription) return false;
    
    return subscription.status !== 'free' && 
           subscription.status !== 'expired';
  }

  /**
   * د specific feature access چک کړئ
   */
  public hasFeatureAccess(userId: string, featureId: string): boolean {
    const subscription = this.getSubscriptionStatus(userId);
    if (!subscription) return false;

    // د free features چک کړئ
    const freePlan = Plans.free;
    if (freePlan.features.includes(featureId)) {
      return true;
    }

    // د premium features د premium users لپاره
    return this.isPremium(userId);
  }

  // ───────────────────────────────────────────────────────────────
  // 💳 SUBSCRIPTION MANAGEMENT
  // ───────────────────────────────────────────────────────────────

  /**
   * نوی subscription جوړ کړئ
   */
  public createSubscription(
    userId: string,
    plan: 'monthly' | 'yearly' | 'lifetime',
    platform: 'android' | 'ios' | 'web',
    purchaseData?: {
      purchaseToken?: string;
      transactionId?: string;
    }
  ): SubscriptionData {
    const now = Date.now();
    const planData = plan === 'monthly' ? Plans.monthly : 
                     plan === 'yearly' ? Plans.yearly : 
                     Plans.lifetime;

    let expiryDate: number | null = null;
    if (planData.duration !== 'unlimited') {
      const durationMs = (planData.duration as number) * 24 * 60 * 60 * 1000;
      expiryDate = now + durationMs;
    }

    const subscription: SubscriptionData = {
      userId,
      plan,
      status: `premium_${plan}` as SubscriptionStatus,
      startDate: now,
      expiryDate,
      autoRenew: plan !== 'lifetime' && AutoRenewal.enabled,
      platform,
      purchaseToken: purchaseData?.purchaseToken,
      transactionId: purchaseData?.transactionId,
    };

    this.saveSubscription(userId, subscription);
    
    console.log('[PremiumManager] Subscription created:', subscription);
    
    return subscription;
  }

  /**
   * Subscription update کړئ
   */
  public updateSubscription(userId: string, updates: Partial<SubscriptionData>): void {
    const current = this.getSubscriptionStatus(userId);
    if (!current) return;

    const updated = { ...current, ...updates };
    this.saveSubscription(userId, updated);
    
    console.log('[PremiumManager] Subscription updated:', updated);
  }

  /**
   * Subscription cancel کړئ
   */
  public cancelSubscription(userId: string): void {
    const subscription = this.getSubscriptionStatus(userId);
    if (!subscription) return;

    subscription.autoRenew = false;
    subscription.status = 'free';
    this.saveSubscription(userId, subscription);
    
    console.log('[PremiumManager] Subscription cancelled:', userId);
  }

  /**
   * Subscription renew کړئ
   */
  public renewSubscription(userId: string): boolean {
    const subscription = this.getSubscriptionStatus(userId);
    if (!subscription || subscription.plan === 'lifetime') return false;

    const planData = subscription.plan === 'monthly' ? Plans.monthly : Plans.yearly;
    const durationMs = (planData.duration as number) * 24 * 60 * 60 * 1000;
    
    const now = Date.now();
    subscription.expiryDate = now + durationMs;
    subscription.status = `premium_${subscription.plan}` as SubscriptionStatus;
    subscription.gracePeriodEnd = undefined;
    
    this.saveSubscription(userId, subscription);
    
    console.log('[PremiumManager] Subscription renewed:', subscription);
    
    return true;
  }

  // ───────────────────────────────────────────────────────────────
  // 🔔 EXPIRY NOTIFICATIONS
  // ───────────────────────────────────────────────────────────────

  /**
   * د expiry reminder چک کړئ
   */
  public checkExpiryReminder(userId: string, language: 'ps' | 'fa' | 'en'): string | null {
    const subscription = this.getSubscriptionStatus(userId);
    if (!subscription || !subscription.expiryDate) return null;

    const now = Date.now();
    const daysUntilExpiry = Math.ceil((subscription.expiryDate - now) / (24 * 60 * 60 * 1000));

    const messages = ExpiryNotifications.messages[language];
    const notificationKey = `expiry_notification_${daysUntilExpiry}_${userId}`;
    const alreadyShown = localStorage.getItem(notificationKey);

    // 7 ورځې مخکې
    if (daysUntilExpiry === 7 && !alreadyShown && ExpiryNotifications.showAt.days7) {
      localStorage.setItem(notificationKey, 'true');
      return messages.days7;
    }

    // 3 ورځې مخکې
    if (daysUntilExpiry === 3 && !alreadyShown && ExpiryNotifications.showAt.days3) {
      localStorage.setItem(notificationKey, 'true');
      return messages.days3;
    }

    // 1 ورځ مخکې
    if (daysUntilExpiry === 1 && !alreadyShown && ExpiryNotifications.showAt.day1) {
      localStorage.setItem(notificationKey, 'true');
      return messages.day1;
    }

    // Expired
    if (daysUntilExpiry <= 0 && !alreadyShown && ExpiryNotifications.showAt.expired) {
      localStorage.setItem(notificationKey, 'true');
      return messages.expired;
    }

    return null;
  }

  /**
   * د remaining days calculation
   */
  public getRemainingDays(userId: string): number | null {
    const subscription = this.getSubscriptionStatus(userId);
    if (!subscription || !subscription.expiryDate) return null;

    const now = Date.now();
    const daysRemaining = Math.ceil((subscription.expiryDate - now) / (24 * 60 * 60 * 1000));
    
    return daysRemaining > 0 ? daysRemaining : 0;
  }

  /**
   * د expiry date string
   */
  public getExpiryDateString(userId: string): string | null {
    const subscription = this.getSubscriptionStatus(userId);
    if (!subscription || !subscription.expiryDate) return null;

    const date = new Date(subscription.expiryDate);
    return date.toLocaleDateString();
  }

  // ───────────────────────────────────────────────────────────────
  // 🔄 AUTO RENEWAL
  // ───────────────────────────────────────────────────────────────

  /**
   * د auto renewal check (په background کې run کیږي)
   */
  public async checkAutoRenewal(userId: string): Promise<boolean> {
    const subscription = this.getSubscriptionStatus(userId);
    if (!subscription || !subscription.autoRenew || subscription.plan === 'lifetime') {
      return false;
    }

    // Check if subscription is about to expire (د expiry څخه 24 ساعتې مخکې)
    if (!subscription.expiryDate) return false;
    
    const now = Date.now();
    const hoursUntilExpiry = (subscription.expiryDate - now) / (60 * 60 * 1000);

    if (hoursUntilExpiry <= 24 && hoursUntilExpiry > 0) {
      // Attempt to renew
      console.log('[PremiumManager] Auto-renewing subscription...');
      
      // دلته د actual payment processing logic راشي
      // د Android/iOS in-app purchase APIs استعمال کړئ
      
      // د demo لپاره auto-renew successful فرض کړو
      const renewed = this.renewSubscription(userId);
      
      if (renewed) {
        console.log('[PremiumManager] Auto-renewal successful');
        return true;
      } else {
        console.log('[PremiumManager] Auto-renewal failed');
        
        // د grace period set کړئ
        const gracePeriodMs = AutoRenewal.gracePeriodDays * 24 * 60 * 60 * 1000;
        subscription.gracePeriodEnd = now + gracePeriodMs;
        this.saveSubscription(userId, subscription);
        
        return false;
      }
    }

    return false;
  }

  // ───────────────────────────────────────────────────────────────
  // 💾 STORAGE HELPERS
  // ───────────────────────────────────────────────────────────────

  private saveSubscription(userId: string, data: SubscriptionData): void {
    try {
      localStorage.setItem(`${this.storageKey}_${userId}`, JSON.stringify(data));
    } catch (error) {
      console.error('[PremiumManager] Error saving subscription:', error);
    }
  }

  /**
   * د subscription data clear کړئ (د testing لپاره)
   */
  public clearSubscription(userId: string): void {
    localStorage.removeItem(`${this.storageKey}_${userId}`);
    console.log('[PremiumManager] Subscription cleared:', userId);
  }

  /**
   * د ټولو subscriptions لیست (د admin لپاره)
   */
  public getAllSubscriptions(): SubscriptionData[] {
    const subscriptions: SubscriptionData[] = [];
    
    for (let i = 0; i < localStorage.length; i++) {
      const key = localStorage.key(i);
      if (key && key.startsWith(this.storageKey)) {
        try {
          const data = localStorage.getItem(key);
          if (data) {
            subscriptions.push(JSON.parse(data));
          }
        } catch (error) {
          console.error('[PremiumManager] Error parsing subscription:', error);
        }
      }
    }
    
    return subscriptions;
  }

  // ───────────────────────────────────────────────────────────────
  // 📱 PLATFORM-SPECIFIC METHODS
  // ───────────────────────────────────────────────────────────────

  /**
   * د Android Google Play Billing
   */
  public async purchaseAndroid(userId: string, sku: string): Promise<boolean> {
    try {
      console.log('[PremiumManager] Starting Android purchase:', sku);
      
      // دلته د Google Play Billing API call کیږي
      // @see https://developer.android.com/google/play/billing
      
      // د demo لپاره successful فرض کړو
      const plan = sku.includes('monthly') ? 'monthly' : 
                   sku.includes('yearly') ? 'yearly' : 'lifetime';
      
      this.createSubscription(userId, plan, 'android', {
        purchaseToken: 'demo_android_token_' + Date.now(),
      });
      
      return true;
    } catch (error) {
      console.error('[PremiumManager] Android purchase failed:', error);
      return false;
    }
  }

  /**
   * د iOS Apple In-App Purchase
   */
  public async purchaseIOS(userId: string, productId: string): Promise<boolean> {
    try {
      console.log('[PremiumManager] Starting iOS purchase:', productId);
      
      // دلته د Apple StoreKit API call کیږي
      // @see https://developer.apple.com/documentation/storekit
      
      // د demo لپاره successful فرض کړو
      const plan = productId.includes('monthly') ? 'monthly' : 
                   productId.includes('yearly') ? 'yearly' : 'lifetime';
      
      this.createSubscription(userId, plan, 'ios', {
        transactionId: 'demo_ios_txn_' + Date.now(),
      });
      
      return true;
    } catch (error) {
      console.error('[PremiumManager] iOS purchase failed:', error);
      return false;
    }
  }

  /**
   * د Web/PWA purchase (د testing لپاره)
   */
  public async purchaseWeb(userId: string, plan: 'monthly' | 'yearly' | 'lifetime'): Promise<boolean> {
    try {
      console.log('[PremiumManager] Starting web purchase:', plan);
      
      // د production کې دلته backend API call کیږي
      // د demo لپاره direct create کړو
      
      this.createSubscription(userId, plan, 'web');
      
      return true;
    } catch (error) {
      console.error('[PremiumManager] Web purchase failed:', error);
      return false;
    }
  }

  // ───────────────────────────────────────────────────────────────
  // 🔐 SECURITY & VALIDATION
  // ───────────────────────────────────────────────────────────────

  /**
   * د purchase receipt verify کړئ
   */
  public async verifyPurchase(
    platform: 'android' | 'ios',
    purchaseData: string
  ): Promise<boolean> {
    try {
      // دلته د server-side verification API call کیږي
      // د Google/Apple servers سره receipt verify کیږي
      
      console.log('[PremiumManager] Verifying purchase:', platform);
      
      // د demo لپاره true return کړو
      return true;
    } catch (error) {
      console.error('[PremiumManager] Purchase verification failed:', error);
      return false;
    }
  }
}

// ═══════════════════════════════════════════════════════════════
// 🚀 EXPORT SINGLETON INSTANCE
// ═══════════════════════════════════════════════════════════════

export const premiumManager = new PremiumManager();

// د backward compatibility لپاره helper functions export کړئ
export const isPremiumUser = (userId: string) => premiumManager.isPremium(userId);
export const getSubscription = (userId: string) => premiumManager.getSubscriptionStatus(userId);
export const hasFeature = (userId: string, featureId: string) => premiumManager.hasFeatureAccess(userId, featureId);
