// د Payment Processing System - د Facebook/Instagram په شان

export interface PaymentData {
  transactionId: string;
  customerId: string;
  customerName: string;
  customerEmail: string;
  customerPhone: string;
  amount: number;
  currency: string;
  plan: string;
  timestamp: number;
  status: 'pending' | 'verified' | 'failed';
  ownerPhone: string;
  paymentMethod: 'hesab_pay';
}

export interface PaymentReceipt {
  receiptId: string;
  transactionId: string;
  customerName: string;
  customerEmail: string;
  amount: number;
  plan: string;
  date: string;
  status: string;
  validUntil: string;
}

const OWNER_EMAIL = 'ibrahimkhaksar.it@gmail.com';
const OWNER_PHONE = '+93779494512';
const OWNER_NAME = 'Dr. Ibrahim Khaksar';

export class PaymentProcessor {
  // د Payment معلومات ذخیره کول
  static async processPayment(paymentData: PaymentData): Promise<boolean> {
    try {
      // 1. د Payment معلومات localStorage کې ذخیره
      const payments = this.getAllPayments();
      payments.push(paymentData);
      localStorage.setItem('healmate_payments', JSON.stringify(payments));

      // 2. د Owner ته Notification ولیږه
      await this.sendOwnerNotification(paymentData);

      // 3. د Customer ته Email او Receipt ولیږه
      await this.sendCustomerReceipt(paymentData);

      // 4. د Payment Verification شروع کړه
      await this.verifyPayment(paymentData);

      return true;
    } catch (error) {
      console.error('Payment processing error:', error);
      return false;
    }
  }

  // د Owner ته Email او SMS
  static async sendOwnerNotification(payment: PaymentData): Promise<void> {
    const message = `
🎉 د نوي Premium Subscription معلومات!

💰 مقدار: ${payment.amount} AFN
👤 مشتری: ${payment.customerName}
📧 ایمیل: ${payment.customerEmail}
📱 تلیفون: ${payment.customerPhone}
📦 پلان: ${payment.plan}
🆔 Transaction ID: ${payment.transactionId}
⏰ وخت: ${new Date(payment.timestamp).toLocaleString('ps-AF')}

✅ پیسې ستاسو Hesab Pay ته راځي: ${OWNER_PHONE}

د HealMate App څخه - Dr. Ibrahim Khaksar
    `;

    // Email notification (simulation)
    this.simulateEmailSend(OWNER_EMAIL, '🎉 نوی Premium Subscription!', message);

    // SMS notification (simulation)
    this.simulateSMSSend(OWNER_PHONE, `
نوی Premium Subscription!
مشتری: ${payment.customerName}
مقدار: ${payment.amount} AFN
پلان: ${payment.plan}
Transaction: ${payment.transactionId}
    `);

    // د notification ذخیره کول
    this.saveNotification({
      type: 'owner',
      recipient: OWNER_EMAIL,
      message,
      timestamp: Date.now(),
      read: false
    });
  }

  // د Customer ته Email او PDF Receipt
  static async sendCustomerReceipt(payment: PaymentData): Promise<void> {
    // د Receipt جوړول
    const receipt = this.generateReceipt(payment);
    
    const emailMessage = `
سلام ${payment.customerName} جانه! 👋

ستاسو د HealMate Premium Subscription بریالی شو! 🎉

📄 د پیسو د ورکړې معلومات:
━━━━━━━━━━━━━━━━━━━━
🆔 Receipt ID: ${receipt.receiptId}
💳 Transaction ID: ${receipt.transactionId}
💰 مقدار: ${receipt.amount} AFN
📦 پلان: ${receipt.plan}
📅 نیټه: ${receipt.date}
✅ حالت: ${receipt.status}
⏰ اعتبار تر: ${receipt.validUntil}
━━━━━━━━━━━━━━━━━━━━

ستاسو Premium فیچرونه:
✨ د ټولو فیچرونو بې محدوده لاسرسی
🤖 AI Health Assistant
📚 د ټولو کتابونو لاسرسی
💊 Advanced Medicine Database
👨‍⚕️ د ټولو ډاکټرانو معلومات
🏥 د ټولو روغتونونو معلومات
🎯 ځانګړي مشورې

📱 د ټیکنیکي مرستې لپاره:
ایمیل: ibrahimkhaksar.it@gmail.com
تلیفون: +93779494512

مننه چې تاسو HealMate غوره کړ! 💚
د ډاکټر ابراهیم خاکسار له خوا

HealMate - Your Health Companion
www.healmate.af
    `;

    // Email ولیږه
    this.simulateEmailSend(payment.customerEmail, '✅ ستاسو HealMate Premium فعال شو!', emailMessage);

    // د Receipt PDF ذخیره کول
    this.savePDFReceipt(receipt, payment.customerEmail);

    // د notification ذخیره کول
    this.saveNotification({
      type: 'customer',
      recipient: payment.customerEmail,
      message: emailMessage,
      timestamp: Date.now(),
      read: false,
      hasAttachment: true,
      attachmentType: 'pdf'
    });
  }

  // د Payment Verification
  static async verifyPayment(payment: PaymentData): Promise<boolean> {
    // Simulation: د حقیقي Hesab Pay API لپاره تیار
    // دا به د Hesab Pay سره د API integration کې کار وکړي
    
    // د 3 ثانیو لپاره انتظار (simulation)
    await new Promise(resolve => setTimeout(resolve, 3000));

    // د payment status update
    payment.status = 'verified';
    
    // د verified payment ذخیره
    const payments = this.getAllPayments();
    const index = payments.findIndex(p => p.transactionId === payment.transactionId);
    if (index !== -1) {
      payments[index] = payment;
      localStorage.setItem('healmate_payments', JSON.stringify(payments));
    }

    // د Premium فعالول
    this.activatePremium(payment);

    // د verification notification
    await this.sendVerificationNotification(payment);

    return true;
  }

  // د Premium فعالول
  static activatePremium(payment: PaymentData): void {
    const duration = payment.plan === 'monthly' ? 30 : 365; // days
    const expiryDate = new Date();
    expiryDate.setDate(expiryDate.getDate() + duration);

    const premiumData = {
      plan: payment.plan,
      expiryDate: expiryDate.getTime(),
      activatedAt: Date.now(),
      transactionId: payment.transactionId,
      amount: payment.amount
    };

    localStorage.setItem(`healmate_premium_${payment.customerId}`, JSON.stringify(premiumData));
  }

  // د Verification Notification
  static async sendVerificationNotification(payment: PaymentData): Promise<void> {
    const ownerMessage = `
✅ Payment Verified!

Transaction ID: ${payment.transactionId}
مشتری: ${payment.customerName}
Premium Status: ACTIVE ✅

د HealMate System
    `;

    const customerMessage = `
✅ ستاسو پیمنټ تایید شو!

سلام ${payment.customerName}! 🎉

ستاسو د ${payment.amount} AFN پیمنټ بریالی تایید شو او ستاسو Premium Subscription اوس فعال دی!

تاسو اوس کولای شئ چې:
✨ ټول Premium فیچرونه وکاروئ
🤖 AI Health Assistant
📚 ټول کتابونه ولولئ
💊 Advanced Medicine Database
👨‍⚕️ د ټولو ډاکټرانو معلومات

د HealMate استعمال څخه خوند واخلئ! 💚

مننه،
ډاکټر ابراهیم خاکسار
    `;

    this.simulateEmailSend(OWNER_EMAIL, '✅ Payment Verified', ownerMessage);
    this.simulateSMSSend(OWNER_PHONE, ownerMessage);
    this.simulateEmailSend(payment.customerEmail, '✅ Premium فعال شو!', customerMessage);

    this.saveNotification({
      type: 'verification',
      recipient: payment.customerEmail,
      message: customerMessage,
      timestamp: Date.now(),
      read: false
    });
  }

  // د Receipt جوړول
  static generateReceipt(payment: PaymentData): PaymentReceipt {
    const receiptId = `RCP-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`.toUpperCase();
    const validDays = payment.plan === 'monthly' ? 30 : 365;
    const validUntil = new Date();
    validUntil.setDate(validUntil.getDate() + validDays);

    return {
      receiptId,
      transactionId: payment.transactionId,
      customerName: payment.customerName,
      customerEmail: payment.customerEmail,
      amount: payment.amount,
      plan: payment.plan === 'monthly' ? 'Monthly Premium' : 'Yearly Premium',
      date: new Date(payment.timestamp).toLocaleString('ps-AF'),
      status: 'تایید شوی ✅',
      validUntil: validUntil.toLocaleDateString('ps-AF')
    };
  }

  // د PDF Receipt ذخیره کول
  static savePDFReceipt(receipt: PaymentReceipt, customerEmail: string): void {
    const pdfData = {
      receipt,
      generatedAt: Date.now(),
      customerEmail
    };

    const receipts = JSON.parse(localStorage.getItem('healmate_receipts') || '[]');
    receipts.push(pdfData);
    localStorage.setItem('healmate_receipts', JSON.stringify(receipts));
  }

  // Email Simulation
  static simulateEmailSend(to: string, subject: string, body: string): void {
    console.log('📧 EMAIL SENT:');
    console.log('To:', to);
    console.log('Subject:', subject);
    console.log('Body:', body);
    console.log('─────────────────────────────────');
  }

  // SMS Simulation
  static simulateSMSSend(to: string, message: string): void {
    console.log('📱 SMS SENT:');
    console.log('To:', to);
    console.log('Message:', message);
    console.log('─────────────────────────────────');
  }

  // د Notification ذخیره کول
  static saveNotification(notification: any): void {
    const notifications = JSON.parse(localStorage.getItem('healmate_notifications') || '[]');
    notifications.push(notification);
    localStorage.setItem('healmate_notifications', JSON.stringify(notifications));
  }

  // د ټولو Payments اخیستل
  static getAllPayments(): PaymentData[] {
    return JSON.parse(localStorage.getItem('healmate_payments') || '[]');
  }

  // د کاروونکي Payments اخیستل
  static getUserPayments(userId: string): PaymentData[] {
    const allPayments = this.getAllPayments();
    return allPayments.filter(p => p.customerId === userId);
  }

  // د Receipt Download
  static downloadReceipt(transactionId: string): void {
    const payments = this.getAllPayments();
    const payment = payments.find(p => p.transactionId === transactionId);
    
    if (!payment) return;

    const receipt = this.generateReceipt(payment);
    const receiptHTML = this.generateReceiptHTML(receipt, payment);

    // د Receipt په HTML بڼه Download کول
    const blob = new Blob([receiptHTML], { type: 'text/html' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `HealMate_Receipt_${receipt.receiptId}.html`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  }

  // د Receipt HTML جوړول
  static generateReceiptHTML(receipt: PaymentReceipt, payment: PaymentData): string {
    return `
<!DOCTYPE html>
<html dir="rtl" lang="ps">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>HealMate - د پیسو ورکړې رسید</title>
  <style>
    * { margin: 0; padding: 0; box-sizing: border-box; }
    body {
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      padding: 40px 20px;
      direction: rtl;
    }
    .receipt {
      max-width: 600px;
      margin: 0 auto;
      background: white;
      border-radius: 20px;
      box-shadow: 0 20px 60px rgba(0,0,0,0.3);
      overflow: hidden;
    }
    .header {
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      color: white;
      padding: 40px;
      text-align: center;
    }
    .header h1 {
      font-size: 36px;
      margin-bottom: 10px;
    }
    .header p {
      opacity: 0.9;
      font-size: 18px;
    }
    .content {
      padding: 40px;
    }
    .success-badge {
      background: #10b981;
      color: white;
      padding: 15px 30px;
      border-radius: 50px;
      text-align: center;
      font-size: 20px;
      margin-bottom: 30px;
      display: inline-block;
      width: 100%;
    }
    .info-row {
      display: flex;
      justify-content: space-between;
      padding: 15px 0;
      border-bottom: 2px solid #f3f4f6;
    }
    .info-row:last-child {
      border-bottom: none;
    }
    .label {
      color: #6b7280;
      font-weight: 600;
    }
    .value {
      color: #111827;
      font-weight: bold;
    }
    .amount {
      background: #fef3c7;
      padding: 20px;
      border-radius: 15px;
      text-align: center;
      margin: 30px 0;
    }
    .amount .number {
      font-size: 48px;
      color: #f59e0b;
      font-weight: bold;
    }
    .footer {
      background: #f9fafb;
      padding: 30px 40px;
      text-align: center;
      color: #6b7280;
      font-size: 14px;
      line-height: 1.8;
    }
    .footer strong {
      color: #111827;
      display: block;
      margin-top: 15px;
      font-size: 16px;
    }
    .qr-code {
      margin: 20px auto;
      text-align: center;
    }
    @media print {
      body { padding: 0; background: white; }
      .receipt { box-shadow: none; }
    }
  </style>
</head>
<body>
  <div class="receipt">
    <div class="header">
      <h1>💚 HealMate</h1>
      <p>Your Health Companion</p>
    </div>
    
    <div class="content">
      <div class="success-badge">
        ✅ پیمنټ بریالی تایید شو
      </div>

      <div class="amount">
        <div class="label">ټوله مقدار</div>
        <div class="number">${receipt.amount} AFN</div>
      </div>

      <div class="info-row">
        <span class="label">🆔 د رسید نمبر:</span>
        <span class="value">${receipt.receiptId}</span>
      </div>

      <div class="info-row">
        <span class="label">💳 Transaction ID:</span>
        <span class="value">${receipt.transactionId}</span>
      </div>

      <div class="info-row">
        <span class="label">👤 نوم:</span>
        <span class="value">${receipt.customerName}</span>
      </div>

      <div class="info-row">
        <span class="label">📧 ایمیل:</span>
        <span class="value">${receipt.customerEmail}</span>
      </div>

      <div class="info-row">
        <span class="label">📦 پلان:</span>
        <span class="value">${receipt.plan}</span>
      </div>

      <div class="info-row">
        <span class="label">📅 نیټه:</span>
        <span class="value">${receipt.date}</span>
      </div>

      <div class="info-row">
        <span class="label">⏰ اعتبار تر:</span>
        <span class="value">${receipt.validUntil}</span>
      </div>

      <div class="info-row">
        <span class="label">✅ حالت:</span>
        <span class="value">${receipt.status}</span>
      </div>
    </div>

    <div class="footer">
      <p>د ډاکټر ابراهیم خاکسار له خوا</p>
      <strong>Dr. Ibrahim Khaksar</strong>
      <p>📧 ibrahimkhaksar.it@gmail.com</p>
      <p>📱 +93 779 494 512</p>
      <p style="margin-top: 20px; font-size: 12px; opacity: 0.7;">
        دا یو رسمي رسید دی د HealMate Premium Subscription لپاره.<br>
        د مرستې لپاره مهرباني وکړئ موږ سره اړیکه ونیسئ.
      </p>
    </div>
  </div>
</body>
</html>
    `;
  }

  // د ټولو Receipts اخیستل
  static getAllReceipts(): any[] {
    return JSON.parse(localStorage.getItem('healmate_receipts') || '[]');
  }

  // د کاروونکي Receipts اخیستل
  static getUserReceipts(userEmail: string): any[] {
    const allReceipts = this.getAllReceipts();
    return allReceipts.filter(r => r.customerEmail === userEmail);
  }
}
