/**
 * د HealMate User Management
 * د Testing او Demo لپاره نور استعمال نه کیږي
 */

export function createDemoUser() {
  // Demo user نور نه جوړیږي
  // کاروونکي باید Sign Up کړي
  console.log("ℹ️ Demo user functionality disabled. Users must sign up.");
  return null;
}

/**
 * د ټولو Demo Data جوړول
 */
export function initializeDemoData() {
  // Demo data نور نه جوړیږي
  console.log("ℹ️ Demo data initialization disabled. Real user authentication required.");
}
