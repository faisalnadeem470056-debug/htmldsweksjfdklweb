/**
 * Clipboard Utility with Fallback Support
 * Works when Clipboard API is blocked by permissions policy
 */

/**
 * Copy text to clipboard with fallback method
 * @param text - Text to copy
 * @returns Promise<boolean> - Success status
 */
export async function copyToClipboard(text: string): Promise<boolean> {
  // Method 1: Try modern Clipboard API
  if (navigator.clipboard && window.isSecureContext) {
    try {
      await navigator.clipboard.writeText(text);
      return true;
    } catch (err) {
      console.warn('Clipboard API failed, trying fallback method...', err);
    }
  }

  // Method 2: Fallback using document.execCommand
  try {
    const textArea = document.createElement('textarea');
    textArea.value = text;
    
    // Make textarea invisible but accessible
    textArea.style.position = 'fixed';
    textArea.style.top = '-9999px';
    textArea.style.left = '-9999px';
    textArea.style.opacity = '0';
    textArea.style.pointerEvents = 'none';
    textArea.setAttribute('readonly', '');
    
    document.body.appendChild(textArea);
    
    // Select text
    if (navigator.userAgent.match(/ipad|iphone/i)) {
      // iOS specific handling
      const range = document.createRange();
      range.selectNodeContents(textArea);
      const selection = window.getSelection();
      selection?.removeAllRanges();
      selection?.addRange(range);
      textArea.setSelectionRange(0, text.length);
    } else {
      textArea.select();
      textArea.setSelectionRange(0, text.length);
    }
    
    // Execute copy command
    const successful = document.execCommand('copy');
    
    // Clean up
    document.body.removeChild(textArea);
    
    if (successful) {
      return true;
    } else {
      throw new Error('execCommand copy failed');
    }
  } catch (err) {
    console.error('Fallback clipboard method failed:', err);
  }

  // Method 3: Last resort - create a temporary input
  try {
    const input = document.createElement('input');
    input.value = text;
    input.style.position = 'absolute';
    input.style.left = '-9999px';
    
    document.body.appendChild(input);
    input.focus();
    input.select();
    
    const result = document.execCommand('copy');
    document.body.removeChild(input);
    
    if (result) {
      return true;
    }
  } catch (err) {
    console.error('Last resort clipboard method failed:', err);
  }

  // All methods failed
  return false;
}

/**
 * Copy text with user notification
 * @param text - Text to copy
 * @param successMessage - Success message (optional)
 * @param errorMessage - Error message (optional)
 */
export async function copyWithNotification(
  text: string,
  successMessage: string = 'Copied to clipboard!',
  errorMessage: string = 'Failed to copy. Please copy manually.'
): Promise<void> {
  const success = await copyToClipboard(text);
  
  if (success) {
    // Show success message
    showToast(successMessage, 'success');
  } else {
    // Show error with manual copy option
    showManualCopyDialog(text, errorMessage);
  }
}

/**
 * Show a toast notification
 */
function showToast(message: string, type: 'success' | 'error' = 'success'): void {
  // Check if toast library is available
  if (typeof window !== 'undefined' && (window as any).toast) {
    const toast = (window as any).toast;
    if (type === 'success') {
      toast.success(message);
    } else {
      toast.error(message);
    }
    return;
  }

  // Fallback to alert
  alert(message);
}

/**
 * Show manual copy dialog when clipboard fails
 */
function showManualCopyDialog(text: string, message: string): void {
  // Create a custom dialog
  const dialog = document.createElement('div');
  dialog.style.cssText = `
    position: fixed;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    background: white;
    padding: 24px;
    border-radius: 16px;
    box-shadow: 0 20px 60px rgba(0, 0, 0, 0.3);
    z-index: 10000;
    max-width: 90%;
    width: 500px;
  `;

  dialog.innerHTML = `
    <div style="margin-bottom: 16px; font-size: 18px; font-weight: 600; color: #dc2626;">
      ${message}
    </div>
    <div style="margin-bottom: 16px; font-size: 14px; color: #6b7280;">
      Please copy the text below manually:
    </div>
    <textarea
      readonly
      style="
        width: 100%;
        min-height: 100px;
        padding: 12px;
        border: 2px solid #e5e7eb;
        border-radius: 8px;
        font-family: monospace;
        font-size: 12px;
        resize: vertical;
        margin-bottom: 16px;
      "
      onclick="this.select()"
    >${text}</textarea>
    <div style="display: flex; gap: 8px; justify-content: flex-end;">
      <button
        onclick="this.parentElement.parentElement.parentElement.removeChild(this.parentElement.parentElement)"
        style="
          padding: 8px 16px;
          background: #10b981;
          color: white;
          border: none;
          border-radius: 8px;
          font-size: 14px;
          font-weight: 500;
          cursor: pointer;
        "
      >
        OK
      </button>
    </div>
  `;

  // Add backdrop
  const backdrop = document.createElement('div');
  backdrop.style.cssText = `
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: rgba(0, 0, 0, 0.5);
    z-index: 9999;
  `;

  backdrop.onclick = () => {
    document.body.removeChild(backdrop);
    document.body.removeChild(dialog);
  };

  document.body.appendChild(backdrop);
  document.body.appendChild(dialog);

  // Auto-select the text
  const textarea = dialog.querySelector('textarea');
  if (textarea) {
    textarea.focus();
    textarea.select();
  }
}

/**
 * Check if clipboard is available
 */
export function isClipboardAvailable(): boolean {
  return !!(navigator.clipboard && window.isSecureContext);
}

/**
 * Simple copy function for quick use
 */
export async function simpleCopy(text: string): Promise<boolean> {
  return await copyToClipboard(text);
}

export default {
  copyToClipboard,
  copyWithNotification,
  isClipboardAvailable,
  simpleCopy
};
