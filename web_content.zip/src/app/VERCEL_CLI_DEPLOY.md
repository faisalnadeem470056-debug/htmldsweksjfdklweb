# 🚀 د Vercel CLI سره Direct Deployment
# Direct Deployment with Vercel CLI

## بغیر GitHub - مستقیماً Deploy کړئ!

---

## ګام 1: Vercel CLI Install کړئ

### د Windows لپاره:
```bash
# CMD یا PowerShell کې:
npm install -g vercel
```

### د Mac/Linux لپاره:
```bash
npm install -g vercel
```

**یا که npm نشته:**
```bash
# Download Node.js from: https://nodejs.org
# بیا npm اوتومات install کیږي
```

---

## ګام 2: Vercel Login

```bash
vercel login
```

**دا به وکړي:**
1. ستاسو browser ته به ورشي
2. د Vercel account جوړ کړئ (که نلرئ)
3. "Continue with GitHub" یا "Continue with Email"
4. Authorize کړئ
5. ✅ Login بشپړ!

---

## ګام 3: د Project Folder ته ورشئ

```bash
# د Figma Make څخه ستاسو project download کړئ
# بیا terminal کې د project folder ته ورشئ:

cd /path/to/healmate-app

# مثال Windows:
cd C:\Users\YourName\Downloads\healmate-app

# مثال Mac:
cd ~/Downloads/healmate-app
```

---

## ګام 4: Deploy کړئ!

```bash
# لومړی ځل لپاره:
vercel

# دا سوالات به وکړي - دا ځوابونه ورکړئ:
```

### د سوالاتو ځوابونه:

```
? Set up and deploy "~/healmate-app"? 
→ Y (Yes ولیکئ)

? Which scope do you want to deploy to?
→ ستاسو account name (Enter کلیک وکړئ)

? Link to existing project?
→ N (No ولیکئ)

? What's your project's name?
→ healmate-app (یا هر نوم چې غواړئ)

? In which directory is your code located?
→ ./ (یوازې Enter کلیک وکړئ)

? Want to modify these settings?
→ N (No ولیکئ)
```

---

## ګام 5: Production ته Deploy کړئ

کله چې لومړی deploy بشپړ شو:

```bash
# Production deploy لپاره:
vercel --prod
```

**⏳ 1-2 دقیقې انتظار وکړئ...**

---

## ګام 6: ستاسو URL! 🎉

کله چې deploy بشپړ شي، تاسو ته به داسې URL ښکاره شي:

```
✅ Production: https://healmate-app.vercel.app
```

**دا URL copy کړئ!** دا د PWABuilder لپاره کاروئ.

---

## 🔄 د Updates Deploy کول

کله چې تاسو code بدل کړئ:

```bash
# بیرته deploy کړئ:
vercel --prod

# دا به ستاسو app update کړي
```

---

## ⚙️ د Vercel Dashboard

ستاسو app manage کړئ:

1. 🌐 https://vercel.com/dashboard ته ورشئ
2. د خپل project کلیک وکړئ (healmate-app)
3. دلته تاسو کولی شئ:
   - 📊 Analytics وګورئ
   - ⚙️ Settings بدل کړئ
   - 🌐 Custom domain اضافه کړئ
   - 📝 Environment variables set کړئ
   - 🔄 Deployments history وګورئ

---

## 🎯 اوس PWABuilder ته!

کله چې ستاسو URL ترلاسه شو:

```
1. https://www.pwabuilder.com ته ورشئ
2. ستاسو URL داخل کړئ: https://healmate-app.vercel.app
3. "Start" کلیک وکړئ
4. ✅ اوس به کار وکړي!
5. Android → Generate APK
```

---

## 🐛 که مسله لرئ:

### Error: "Command not found: vercel"
```bash
# Vercel بیرته install کړئ:
npm install -g vercel

# یا:
npm install --global vercel
```

### Error: "No package.json found"
```bash
# یقیني کړئ چې په سم folder کې یاست:
ls
# باید دا files وګورئ: package.json, src/, public/

# که نلرئ، سم folder ته ورشئ
```

### Error: "Build failed"
```bash
# Dependencies install کړئ:
npm install

# بیا deploy کړئ:
vercel --prod
```

---

## 💡 Pro Tips:

### 1. د Environment Variables Set کول:
```bash
# Vercel dashboard ته ورشئ
# Settings → Environment Variables
# د AdMob IDs اضافه کړئ
```

### 2. د Custom Domain کارول:
```bash
# Vercel dashboard کې:
# Settings → Domains
# ستاسو domain اضافه کړئ (مثلاً: healmate.af)
```

### 3. د Auto Deployments:
که تاسو وروسته GitHub کاروئ، Vercel به په هر commit اوتومات deploy کړي!

---

## ✅ Success Checklist:

- [ ] Vercel CLI installed
- [ ] Vercel login بشپړ شو
- [ ] Project folder ته ورتللی یم
- [ ] `vercel --prod` run کړ
- [ ] URL ترلاسه کړ
- [ ] URL په browser کې test کړ
- [ ] PWABuilder ته ورشم

---

## 🎊 بریا!

**ستاسو HealMate app اوس Live دی!** 🚀

```
ستاسو URL: https://healmate-app.vercel.app
```

**اوس PWABuilder ته ورشئ او APK جوړ کړئ!** 📱

---

## 📞 د مرستې لپاره:

- 📧 Email: ibrahimkhaksar.it@gmail.com
- 📱 Phone: +93 783 040 441
- 📚 Vercel Docs: https://vercel.com/docs

---

**ټول وخت: 5 دقیقې! ⚡**
