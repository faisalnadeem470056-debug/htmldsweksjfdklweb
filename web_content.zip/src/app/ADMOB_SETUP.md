# 🎯 HealMate - Google AdMob Setup Guide
## د Google AdMob نصب لارښود

---

## 📱 د Admin Panel ته د لاسرسي لارې

### ✅ **Method 1: د Settings څخه**
1. Settings صفحې ته ورشئ
2. "Admin Panel" کارډ ولټوئ
3. "Open Admin Panel" پټن کلیک کړئ
4. پاسورډ ولیکئ: `HealMate2025`

### ✅ **Method 2: Direct URL**
- په URL کې: `?page=admin` اضافه کړئ
- په Browser کې د اپلیکیشن په آخر کې `/admin` ولیکئ

---

## 🔐 د Admin Panel Login معلومات

```
👤 Username: Admin (no username required)
🔑 Default Password: HealMate2025
```

⚠️ **مهم یادښت:** د امنیت لپاره په Production کې پاسورډ بدله کړئ!

د پاسورډ بدلون په `/components/AdminPanel.tsx` کې په line 45 کې:
```typescript
const correctPassword = "HealMate2025"; // تاسو دا بدلولی شئ
```

---

## 📊 د AdMob Configuration Types

### 1️⃣ **Test Mode (ټیسټ حالت)**
- د Google Test IDs کاروي
- د Development لپاره
- هیڅ ریښتیني پیسې نه راځي
- ✅ د ټیسټ لپاره خوندي

### 2️⃣ **Production Mode (اصلي حالت)**
- خپل AdMob IDs کاروي
- د Published اپ لپاره
- ریښتیني عواید راځي
- ⚠️ د Google AdMob account ته اړتیا

---

## 🎨 د AdMob Ad Types

### 📱 **Banner Ads**
- Size: 320 × 50 (Small) یا 320 × 250 (Large)
- موقعیت: Top, Middle, Bottom
- د صفحې په لاندې برخه کې

### 🎬 **Interstitial Ads**
- Full-screen تبلیغات
- د صفحو تر منځ ښکاره کیږي
- د User engagement لوړوي

### 🎁 **Rewarded Ads**
- د انعام سره تبلیغات
- کاروونکي ویډیو ګوري = انعام ترلاسه کوي
- د Engagement لپاره غوره

---

## 🔧 د Android AdMob IDs Setup

په Admin Panel کې:

1. **Android Tab** باندې کلیک کړئ
2. لاندې IDs ډک کړئ:

```
📱 App ID:
   ca-app-pub-XXXXXXXXXXXXXXXX~XXXXXXXXXX

📰 Banner Ad ID:
   ca-app-pub-XXXXXXXXXXXXXXXX/XXXXXXXXXX

🎬 Interstitial Ad ID:
   ca-app-pub-XXXXXXXXXXXXXXXX/XXXXXXXXXX

🎁 Rewarded Ad ID:
   ca-app-pub-XXXXXXXXXXXXXXXX/XXXXXXXXXX
```

---

## 🍎 د iOS AdMob IDs Setup

په Admin Panel کې:

1. **iOS Tab** باندې کلیک کړئ
2. لاندې IDs ډک کړئ:

```
📱 App ID:
   ca-app-pub-XXXXXXXXXXXXXXXX~XXXXXXXXXX

📰 Banner Ad ID:
   ca-app-pub-XXXXXXXXXXXXXXXX/XXXXXXXXXX

🎬 Interstitial Ad ID:
   ca-app-pub-XXXXXXXXXXXXXXXX/XXXXXXXXXX

🎁 Rewarded Ad ID:
   ca-app-pub-XXXXXXXXXXXXXXXX/XXXXXXXXXX
```

---

## 🌐 د Google Test IDs (د ټیسټ لپاره)

### Android Test IDs:
```javascript
App ID:         ca-app-pub-3940256099942544~3347511713
Banner:         ca-app-pub-3940256099942544/6300978111
Interstitial:   ca-app-pub-3940256099942544/1033173712
Rewarded:       ca-app-pub-3940256099942544/5224354917
```

### iOS Test IDs:
```javascript
App ID:         ca-app-pub-3940256099942544~1458002511
Banner:         ca-app-pub-3940256099942544/2934735716
Interstitial:   ca-app-pub-3940256099942544/4411468910
Rewarded:       ca-app-pub-3940256099942544/1712485313
```

---

## 🚀 د Production Setup لارښود

### ګام 1: د Google AdMob Account جوړ کړئ
1. https://admob.google.com ته ورشئ
2. د Google Account سره Sign in کړئ
3. نوی App اضافه کړئ (Android او/یا iOS)

### ګام 2: د Ad Units جوړ کړئ
1. د خپل App لپاره Ad Units جوړ کړئ:
   - Banner Ad Unit
   - Interstitial Ad Unit
   - Rewarded Ad Unit
2. د هر Ad Unit ID کاپي کړئ

### ګام 3: د HealMate Admin Panel کې IDs واچوئ
1. Admin Panel ته ورشئ
2. Android او iOS Tabs کې IDs پیسټ کړئ
3. Test Mode = OFF
4. Show Ads = ON
5. "Save Changes" کلیک کړئ

### ګام 4: د اپلیکیشن Re-deploy
1. د نوي IDs سره Build کړئ
2. Play Store / App Store ته Upload کړئ
3. د Google AdMob کې د عواید ترلاسه کول پیل کړئ!

---

## ⚙️ د Settings Tab Features

### 🔍 Show IDs Toggle
- د IDs په plaintext کې ښکاره کړئ
- د امنیت لپاره Default = Hidden

### 🧪 Test Mode Toggle
- ON = د Google Test IDs کاروي
- OFF = خپل Production IDs کاروي

### 💰 Show Ads Toggle
- ON = اعلانات ښکاره کیږي
- OFF = اعلانات پټ دي

### 🔄 Quick Actions
- "Load Test IDs" = د Google Test IDs په ټولو fields کې ډک کړئ
- "Reset" = د Default تنظیماتو ته بیرته

---

## 📍 د Ad Banners موقعیتونه په HealMate کې

اوس مهال Ad Banners په لاندې صفحو کې شته:

```
✅ Medicines Page
✅ Health Tips Page
✅ Services Page
✅ Family Profiles
✅ Lab Tests
✅ Medicine Reminders
✅ E-Pharmacy
✅ Health Insurance
✅ Doctor Chat
✅ Video Consultation
✅ Symptoms Tracker
✅ AI Health Assistant
✅ Health Analytics
✅ Doctor Reviews
✅ Appointments
✅ Notifications
✅ User Profile
```

---

## 🛡️ د امنیت لارښودونه

### ✅ **د امنیت Best Practices:**

1. **پاسورډ بدله کړئ**
   - د Default پاسورډ `HealMate2025` مه کاروئ
   - یو قوي او پیچلې پاسورډ واچوئ

2. **د IDs خوندي وساتئ**
   - خپل AdMob IDs هیچا ته مه ورکوئ
   - په Public repositories کې commit مه کوئ

3. **د Test Mode پام وکړئ**
   - په Production کې Test Mode = OFF
   - د ریښتیني عوایدو لپاره Production IDs کاروئ

4. **د Admin Panel لاسرسی محدود کړئ**
   - یوازې authorized خلکو ته لاسرسی ورکړئ
   - د Session timeout فعال کړئ

---

## 🎓 د Google AdMob Policy

### ⚠️ **مهم یادښتونه:**

1. **د Invalid Clicks مخنیوی کړئ**
   - په خپلو اعلاناتو باندې کلیک مه کوئ
   - د Bots څخه استفاده مه کوئ

2. **د Content Guidelines تعقیب کړئ**
   - د Google AdMob Policies ولولئ
   - د Adult یا غیر قانوني محتوا مه اضافه کوئ

3. **د User Experience پام وکړئ**
   - ډیر زیات اعلانات مه واچوئ
   - د کاروونکو تجربه خراب مه کړئ

---

## 📞 د مرستې معلومات

### د HealMate Support:
```
📧 Email: ibrahimkhaksar.it@gmail.com
📱 Phone: +93783040441
📱 Phone: +93779494512
```

### د Google AdMob Help:
```
🌐 Help Center: https://support.google.com/admob
📚 Documentation: https://developers.google.com/admob
```

---

## ✅ Checklist د Production Launch لپاره

```
☐ د Google AdMob Account جوړ شو
☐ د Android او iOS Apps اضافه شول
☐ د Ad Units (Banner, Interstitial, Rewarded) جوړ شول
☐ د Ad Unit IDs کاپي شول
☐ د HealMate Admin Panel کې IDs پیسټ شول
☐ Test Mode = OFF
☐ Show Ads = ON
☐ د Changes خوندي شول
☐ د Admin Panel پاسورډ بدل شو
☐ د اپلیکیشن Testing وشو
☐ د Play Store / App Store ته Upload شو
☐ د Google AdMob Policy Review شو
☐ د عوایدو ټریکینګ پیل شو
```

---

## 🎉 د بریالیتوب!

ستاسو HealMate اپلیکیشن اوس د Google AdMob سره یوځای دی!

### د راتلونکو قدمونه:
1. ✅ د اعلاناتو Performance څارنه وکړئ
2. ✅ د Click-Through Rate (CTR) لوړ کړئ
3. ✅ د مختلفو Ad Placements ټیسټ وکړئ
4. ✅ د عوایدو ډیروالی لپاره Optimize کړئ

---

**د افغانستان لومړنی بشپړ روغتیا اپلیکیشن د AdMob سره! 💚🇦🇫**

Made with ❤️ by HealMate Team
