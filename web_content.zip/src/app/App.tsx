import { useState, useEffect, memo, Suspense } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Home, Heart, Menu, X, Shield, Star, Phone, HelpCircle, MessageCircle, 
  Activity, Stethoscope, Brain, Pill, Baby, Apple, Dumbbell, Calendar, 
  Droplet, Eye, Ear, Bone, Zap, Wind, Users, BookOpen, Bot, Settings as SettingsIcon,
  AlertTriangle, PhoneCall, Clock, MapPin, Hospital, TestTube, Syringe, 
  Smile, HeartPulse, Teeth, Glasses, MoveRight, HeartHandshake, Ambulance, FileHeart,
  ArrowLeft
} from 'lucide-react';
import { SimpleButton as Button } from './components/SimpleButton';
import { ImageWithFallback } from './components/figma/ImageWithFallback';
import { ToastProvider } from './components/SimpleToast';
import { toast, Toaster } from 'sonner@2.0.3';
import securityManager from './utils/SecurityManager';
import { dataManager } from './utils/DataManager';
import { translations } from './translations';
import { AdvancedLoader, FullPageLoader, SkeletonLoader } from './components/AdvancedLoader';
import { SplashScreen } from './components/SplashScreen';
import { BottomNavigation } from './components/BottomNavigation';
import { ModernSidebar } from './components/ModernSidebar';
import { PrivacyPolicy } from './components/PrivacyPolicy';
import { TermsOfService } from './components/TermsOfService';
import { HealthTipsSection } from './components/HealthTipsSection';
import { DailyHealthChallenge } from './components/DailyHealthChallenge';
import { QuickHealthScanner } from './components/QuickHealthScanner';
import { VoiceHealthAssistant } from './components/VoiceHealthAssistant';
import { TraditionalMedicineHub } from './components/TraditionalMedicineHub';
import { AdBanner } from './components/AdBanner';
import { AuthPage } from './components/AuthPage';
import { VerificationPage } from './components/VerificationPage';
import { EnhancedDoctorsDirectory } from './components/EnhancedDoctorsDirectory';
import { HospitalDirectory } from './components/HospitalDirectory';
import { MedicineGuide } from './components/MedicineGuide';
import { FirstAid } from './components/FirstAid';
import { HealthTips } from './components/HealthTips';
import { NutritionGuide } from './components/NutritionGuide';
import { EnhancedSocialFeed } from './components/EnhancedSocialFeed';
import { ContactUs } from './components/ContactUs';
import { AboutUs } from './components/AboutUs';
import { Settings } from './components/Settings';
import { AdminPanel } from './components/AdminPanel';
import { ConsultationsPage } from './components/ConsultationsPage';
import { BooksLibrary } from './components/BooksLibrary';
import { ModernProfilePage } from './components/ModernProfilePage';
import { PremiumPlans } from './components/PremiumPlans';
import { HelpSupport } from './components/HelpSupport';
import { AIHealthChat } from './components/AIHealthChat';
import { BMICalculator } from './components/BMICalculator';
import { SymptomsChecker } from './components/SymptomsChecker';
import { DiseaseEncyclopedia } from './components/DiseaseEncyclopedia';
import { EmergencySOS } from './components/EmergencySOS';
import { HealthTracker } from './components/HealthTracker';
import { MedicineReminder } from './components/MedicineReminder';
import { AppointmentBooking } from './components/AppointmentBooking';
import { SignupPage } from './components/SignupPage';
import { RatingReview } from './components/RatingReview';
import Logo from './components/Logo';
import { LaboratoryDirectory } from './components/LaboratoryDirectory';
import { DonationSystem } from './components/DonationSystem';
import { CharitySystem } from './components/CharitySystem';
import { SymptomChecker } from './components/SymptomChecker';
import { PWAInstallPrompt } from './components/PWAInstallPrompt';
import { PWAStatus } from './components/PWAStatus';
import { pwaManager } from './utils/pwaManager';

type Language = 'ps' | 'fa' | 'en';
type Page = 'home' | 'doctors' | 'hospitals' | 'medicine' | 'laboratory' | 'vaccination' | 'mental-health' | 'pregnancy' | 'dental' | 'eye-care' | 'physiotherapy' | 'blood-bank' | 'ambulance' | 'firstaid' | 'health-tips' | 'nutrition' | 'health-insurance' | 'community' | 'contact' | 'about' | 'settings' | 'admin' | 'books' | 'profile' | 'premium' | 'privacy' | 'terms' | 'help' | 'ai-chat' | 'bmi' | 'symptoms' | 'diseases' | 'emergency' | 'health-tracker' | 'medicine-reminder' | 'appointments' | 'signup' | 'rating' | 'donation' | 'charity';

// ⚡ Loading Component
const PageLoader = memo(() => (
  <div className="min-h-screen bg-gradient-to-br from-indigo-50 via-purple-50 to-pink-50 flex items-center justify-center">
    <div className="text-center">
      <motion.div
        animate={{ scale: [1, 1.1, 1] }}
        transition={{ duration: 1.5, repeat: Infinity, ease: 'easeInOut' }}
        className="mx-auto mb-6"
      >
        <Logo size="2xl" showText={false} />
      </motion.div>
      <div className="text-xl font-bold text-gray-800">
        HealMate
      </div>
      <div className="text-sm text-gray-600 mt-2">Loading...</div>
    </div>
  </div>
));

// ⚡ Memoized Header
const AppHeader = memo(({ 
  language, 
  setLanguage, 
  setCurrentPage,
  navigateToPage,
  setMenuOpen, 
  menuOpen,
  isAuthenticated,
  userName,
  userEmail,
  setShowAuthPage,
  handleLogout,
  checkAuthAndNavigate,
  t 
}: any) => (
  <header className="sticky top-0 z-40 backdrop-blur-xl bg-white/70 border-b border-white/20 shadow-lg">
    <div className="container mx-auto px-4 py-3">
      <div className="flex items-center justify-between">
        <motion.div 
          className="cursor-pointer flex items-center gap-3"
          onClick={() => navigateToPage('home')}
          whileTap={{ scale: 0.95 }}
        >
          <Logo size="md" />
        </motion.div>

        <nav className="hidden lg:flex items-center gap-4">
          <Button variant="ghost" size="sm" onClick={() => navigateToPage('home')}>
            <Home className="w-4 h-4 mr-2" />
            {t.nav.home}
          </Button>
          <Button variant="ghost" size="sm" onClick={() => checkAuthAndNavigate('community')}>
            <MessageCircle className="w-4 h-4 mr-2" />
            {t.nav.community}
          </Button>
          <Button variant="ghost" size="sm" onClick={() => checkAuthAndNavigate('books')}>
            <BookOpen className="w-4 h-4 mr-2" />
            {language === 'ps' ? 'کتابونه' : language === 'fa' ? 'کتاب‌ها' : 'Books'}
          </Button>
          <Button variant="ghost" size="sm" onClick={() => checkAuthAndNavigate('ai-chat')}>
            <Bot className="w-4 h-4 mr-2" />
            {language === 'ps' ? 'AI چت' : language === 'fa' ? 'چت AI' : 'AI Chat'}
          </Button>
          <Button variant="ghost" size="sm" onClick={() => navigateToPage('about')}>
            {t.nav.about}
          </Button>
          {isAuthenticated ? (
            <>
              <Button variant="ghost" size="sm" onClick={() => setCurrentPage('profile')}>
                <Users className="w-4 h-4 mr-2" />
                {userName}
              </Button>
              <Button 
                variant="outline"
                size="sm"
                onClick={handleLogout}
                className="border-red-200 text-red-600 hover:bg-red-50"
              >
                {language === 'ps' ? 'وتل' : language === 'fa' ? 'خروج' : 'Logout'}
              </Button>
            </>
          ) : (
            <Button 
              variant="outline"
              size="sm"
              onClick={() => setShowAuthPage(true)}
              className="border-green-200 text-green-600 hover:bg-green-50"
            >
              {language === 'ps' ? 'ننوتل' : language === 'fa' ? 'ورود' : 'Login'}
            </Button>
          )}
          <Button 
            variant="outline"
            size="sm"
            onClick={() => checkAuthAndNavigate('premium')}
            className="border-orange-200 text-orange-600 hover:bg-orange-50"
          >
            <Star className="w-4 h-4 mr-2 fill-orange-600" />
            Premium
          </Button>
        </nav>

        <div className="flex items-center gap-3">
          <div className="hidden sm:flex items-center gap-2 bg-white/80 backdrop-blur-md rounded-full p-1 shadow-lg">
            {(['ps', 'fa', 'en'] as Language[]).map((lang) => (
              <button
                key={lang}
                onClick={() => setLanguage(lang)}
                className={`px-3 py-1.5 rounded-full text-sm transition-all ${
                  language === lang
                    ? 'bg-gradient-to-r from-red-500 to-pink-600 text-white shadow-md'
                    : 'text-gray-600 hover:text-gray-900'
                }`}
              >
                {lang === 'ps' ? 'پښتو' : lang === 'fa' ? 'دری' : 'EN'}
              </button>
            ))}
          </div>

          <Button 
            variant="ghost" 
            size="icon" 
            className="lg:hidden"
            onClick={() => setMenuOpen(!menuOpen)}
          >
            {menuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </Button>
        </div>
      </div>
    </div>
  </header>
));

function App() {
  const [language, setLanguage] = useState<Language>('ps');
  const [currentPage, setCurrentPage] = useState<Page>('home');
  const [menuOpen, setMenuOpen] = useState(false);
  const [userEmail, setUserEmail] = useState('');
  const [userName, setUserName] = useState('');
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [showAuthPage, setShowAuthPage] = useState(false);
  const [showVerification, setShowVerification] = useState(false);
  const [verificationEmail, setVerificationEmail] = useState('');
  const [verificationPhone, setVerificationPhone] = useState('');
  const [viewingUserId, setViewingUserId] = useState<string | null>(null);
  const [showSplash, setShowSplash] = useState(true);
  const [pageHistory, setPageHistory] = useState<Page[]>(['home']);

  const t = translations[language];

  useEffect(() => {
    // د localStorage څخه user معلومات واخلئ
    const email = localStorage.getItem('healmate_userEmail') || '';
    const name = localStorage.getItem('healmate_userName') || '';
    const authenticated = localStorage.getItem('healmate_isAuthenticated') === 'true';
    
    // که معلومات شتون ولري، نو user login دی
    if (authenticated && email && name) {
      setUserEmail(email);
      setUserName(name);
      setIsAuthenticated(true);
      
      // د 3 ثانیو وروسته خبرتیا وښایئ (د splash screen وروسته)
      setTimeout(() => {
        const welcomeMsg = language === 'ps' 
          ? `ښه راغلاست ${name}! 👋`
          : language === 'fa'
          ? `خوش آمدید ${name}! 👋`
          : `Welcome back ${name}! 👋`;
        
        toast.success(welcomeMsg, {
          duration: 3000,
          style: {
            background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
            color: 'white',
            fontWeight: 'bold',
            fontSize: '16px',
            padding: '16px',
            borderRadius: '12px',
            boxShadow: '0 10px 30px rgba(0,0,0,0.2)'
          }
        });
      }, 3000);
    }

    // 🚀 PWA Features Initialize
    pwaManager.monitorNetworkStatus((online) => {
      const msg = online 
        ? (language === 'ps' ? '✅ انټرنت بیرته راغی' : language === 'fa' ? '✅ اینترنت برگشت' : '✅ Back Online')
        : (language === 'ps' ? '⚠️ انټرنت نشته' : language === 'fa' ? '⚠️ اینترنت قطع' : '⚠️ Offline');
      
      toast[online ? 'success' : 'warning'](msg, { duration: 2000 });
    });

    pwaManager.onAppInstalled(() => {
      const msg = language === 'ps' 
        ? '🎉 HealMate بریالیتوب سره نصب شو!'
        : language === 'fa'
        ? '🎉 HealMate با موفقیت نصب شد!'
        : '🎉 HealMate Installed Successfully!';
      
      toast.success(msg, { duration: 4000 });
      localStorage.setItem('healmate_install_dismissed', 'true');
    });

    console.log('📱 PWA Device Info:', pwaManager.getDeviceInfo());
  }, []);

  const handleLogin = (email: string, name: string) => {
    // د user ��علومات تنظیم کړئ
    setUserEmail(email);
    setUserName(name);
    setIsAuthenticated(true);
    
    // په localStorage کې save کړئ
    localStorage.setItem('healmate_userEmail', email);
    localStorage.setItem('healmate_userName', name);
    localStorage.setItem('healmate_isAuthenticated', 'true');
    
    // د AuthPage بندول
    setShowAuthPage(false);
    setShowVerification(false);
    
    // د کور صفحې ته لاړ شئ او history reset کړئ
    setPageHistory(['home']);
    setCurrentPage('home');
    
    // د بریالیتوب خبرتیا
    setTimeout(() => {
      const welcomeMsg = language === 'ps' 
        ? `${name}! ښه راغلاست 🎉`
        : language === 'fa'
        ? `${name}! خوش آمدید 🎉`
        : `Welcome ${name}! 🎉`;
      
      toast.success(welcomeMsg, {
        duration: 4000,
        style: {
          background: 'linear-gradient(135deg, #10b981 0%, #059669 100%)',
          color: 'white',
          fontWeight: 'bold',
          fontSize: '16px',
          padding: '16px',
          borderRadius: '12px',
          boxShadow: '0 10px 30px rgba(0,0,0,0.2)'
        }
      });
    }, 500);
  };

  const handleLogout = () => {
    // د user معلومات پاک کړئ
    setUserEmail('');
    setUserName('');
    setIsAuthenticated(false);
    
    // له localStorage څخه پاک کړئ
    localStorage.removeItem('healmate_userEmail');
    localStorage.removeItem('healmate_userName');
    localStorage.removeItem('healmate_isAuthenticated');
    
    // د کور صفحې ته لاړ شئ او history reset کړئ
    setPageHistory(['home']);
    setCurrentPage('home');
    
    // د logout خبرتیا
    const logoutMsg = language === 'ps' 
      ? 'تاسو بریالیتوب سره logout شوئ'
      : language === 'fa'
      ? 'شما با موفقیت خارج شدید'
      : 'You have successfully logged out';
    
    toast.success(logoutMsg, {
      duration: 3000,
      style: {
        background: 'linear-gradient(135deg, #6366f1 0%, #8b5cf6 100%)',
        color: 'white',
        fontWeight: 'bold',
        fontSize: '16px',
        padding: '16px',
        borderRadius: '12px',
        boxShadow: '0 10px 30px rgba(0,0,0,0.2)'
      }
    });
    
    console.log('✅ User logout شو');
  };

  // د Navigation Helper Functions
  const navigateToPage = (page: Page) => {
    setPageHistory(prev => [...prev, page]);
    setCurrentPage(page);
    setMenuOpen(false);
  };

  const navigateBack = () => {
    setPageHistory(prev => {
      if (prev.length <= 1) {
        return ['home'];
      }
      const newHistory = [...prev];
      newHistory.pop(); // اوسنی صفحه لرې کړئ
      const previousPage = newHistory[newHistory.length - 1];
      setCurrentPage(previousPage);
      return newHistory;
    });
  };

  const checkAuthAndNavigate = (page: Page) => {
    const protectedPages: Page[] = ['profile', 'admin', 'community', 'books', 'ai-chat', 'premium', 'health-tracker', 'medicine-reminder', 'appointments'];
    if (protectedPages.includes(page) && !isAuthenticated) {
      setShowAuthPage(true);
      return;
    }
    navigateToPage(page);
  };

  const categories = [
    { id: 'doctors', icon: Stethoscope, gradient: 'from-blue-500 to-cyan-500', page: 'doctors' as Page },
    { id: 'hospitals', icon: Hospital, gradient: 'from-red-500 to-pink-500', page: 'hospitals' as Page },
    { id: 'medicine', icon: Pill, gradient: 'from-purple-500 to-violet-500', page: 'medicine' as Page },
    { id: 'laboratory', icon: TestTube, gradient: 'from-indigo-500 to-purple-500', page: 'laboratory' as Page },
    { id: 'vaccination', icon: Syringe, gradient: 'from-pink-500 to-rose-500', page: 'vaccination' as Page },
    { id: 'mentalHealth', icon: Brain, gradient: 'from-violet-500 to-fuchsia-500', page: 'mental-health' as Page },
    { id: 'pregnancy', icon: Baby, gradient: 'from-rose-500 to-pink-500', page: 'pregnancy' as Page },
    { id: 'dental', icon: Smile, gradient: 'from-cyan-500 to-blue-500', page: 'dental' as Page },
    { id: 'eyeCare', icon: Eye, gradient: 'from-amber-500 to-yellow-500', page: 'eye-care' as Page },
    { id: 'physiotherapy', icon: HeartPulse, gradient: 'from-emerald-500 to-teal-500', page: 'physiotherapy' as Page },
    { id: 'bloodBank', icon: Droplet, gradient: 'from-red-600 to-red-400', page: 'blood-bank' as Page },
    { id: 'ambulance', icon: Ambulance, gradient: 'from-orange-600 to-red-600', page: 'ambulance' as Page },
    { id: 'firstAid', icon: Shield, gradient: 'from-orange-500 to-amber-500', page: 'firstaid' as Page },
    { id: 'healthTips', icon: Activity, gradient: 'from-green-500 to-emerald-500', page: 'health-tips' as Page },
    { id: 'nutrition', icon: Apple, gradient: 'from-lime-500 to-green-500', page: 'nutrition' as Page },
    { id: 'healthInsurance', icon: FileHeart, gradient: 'from-sky-500 to-indigo-500', page: 'health-insurance' as Page },
  ];

  if (showAuthPage) {
    return (
      <Suspense fallback={<PageLoader />}>
        <AuthPage 
          language={language}
          onLogin={handleLogin}
          onNeedVerification={(email, phone) => {
            setVerificationEmail(email);
            setVerificationPhone(phone);
            setShowAuthPage(false);
            setShowVerification(true);
          }}
          onBack={() => setShowAuthPage(false)}
        />
      </Suspense>
    );
  }

  if (showVerification) {
    return (
      <Suspense fallback={<PageLoader />}>
        <VerificationPage 
          language={language}
          email={verificationEmail}
          phone={verificationPhone}
          onVerified={() => {
            setShowVerification(false);
            handleLogin(verificationEmail, localStorage.getItem('healmate_pendingUserName') || 'User');
          }}
          onBack={() => setShowVerification(false)}
        />
      </Suspense>
    );
  }

  // Show Splash Screen on first load
  if (showSplash) {
    return <SplashScreen onComplete={() => setShowSplash(false)} />;
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-50 via-purple-50 to-pink-50">
      <AppHeader 
        language={language}
        setLanguage={setLanguage}
        setCurrentPage={setCurrentPage}
        navigateToPage={navigateToPage}
        setMenuOpen={setMenuOpen}
        menuOpen={menuOpen}
        isAuthenticated={isAuthenticated}
        userName={userName}
        userEmail={userEmail}
        setShowAuthPage={setShowAuthPage}
        handleLogout={handleLogout}
        checkAuthAndNavigate={checkAuthAndNavigate}
        t={t}
      />

      <ModernSidebar
        menuOpen={menuOpen}
        setMenuOpen={setMenuOpen}
        language={language}
        isAuthenticated={isAuthenticated}
        userName={userName}
        userEmail={userEmail}
        checkAuthAndNavigate={checkAuthAndNavigate}
        setCurrentPage={navigateToPage}
        handleLogout={handleLogout}
        t={t}
        categories={categories}
      />

      <main className="pb-24 md:pb-8">
        <Suspense fallback={<PageLoader />}>
          {currentPage === 'home' && (
            <div className="container mx-auto px-4">
              {/* Health Categories */}
              <div className="mb-12">
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="mb-6"
                >
                  <h2 className="text-2xl font-bold mb-1 bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent">
                    {language === 'ps' ? '🏥 روغتیایي کټګورۍ' : language === 'fa' ? '🏥 دسته‌بندی‌های سلامت' : '🏥 Health Categories'}
                  </h2>
                  <p className="text-gray-600 text-sm">
                    {language === 'ps' ? 'د خپل ضرورت سره سم انتخاب وکړئ' : language === 'fa' ? 'انتخاب کنید مطابق نیازتان' : 'Choose based on your needs'}
                  </p>
                </motion.div>

                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.1 }}
                  className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-8 gap-3"
                >
                  {categories.map((cat, index) => {
                    const Icon = cat.icon;
                    const label = cat.id === 'doctors' ? t.nav.doctors :
                                 cat.id === 'hospitals' ? t.nav.hospitals :
                                 cat.id === 'medicine' ? t.nav.medicine :
                                 cat.id === 'laboratory' ? (language === 'ps' ? 'آزمایښتونه' : language === 'fa' ? 'آزمایشگاه' : 'Laboratory') :
                                 cat.id === 'vaccination' ? (language === 'ps' ? 'واکسین' : language === 'fa' ? 'واکسیناسیون' : 'Vaccination') :
                                 cat.id === 'mentalHealth' ? (language === 'ps' ? 'رواني روغتیا' : language === 'fa' ? 'سلامت روان' : 'Mental Health') :
                                 cat.id === 'pregnancy' ? (language === 'ps' ? 'حاملګي' : language === 'fa' ? 'بارداری' : 'Pregnancy') :
                                 cat.id === 'dental' ? (language === 'ps' ? 'غاښونه' : language === 'fa' ? 'دندان' : 'Dental') :
                                 cat.id === 'eyeCare' ? (language === 'ps' ? 'سترګې' : language === 'fa' ? 'چشم' : 'Eye Care') :
                                 cat.id === 'physiotherapy' ? (language === 'ps' ? 'فزیوتراپي' : language === 'fa' ? 'فیزیوتراپی' : 'Physiotherapy') :
                                 cat.id === 'bloodBank' ? (language === 'ps' ? 'وینې بانک' : language === 'fa' ? 'بانک خون' : 'Blood Bank') :
                                 cat.id === 'ambulance' ? (language === 'ps' ? 'امبولانس' : language === 'fa' ? 'آمبولانس' : 'Ambulance') :
                                 cat.id === 'firstAid' ? t.nav.firstaid :
                                 cat.id === 'healthTips' ? (language === 'ps' ? 'روغتیا مشورې' : language === 'fa' ? 'نکات سلامت' : 'Health Tips') :
                                 cat.id === 'nutrition' ? (language === 'ps' ? 'تغذیه' : language === 'fa' ? 'تغذیه' : 'Nutrition') :
                                 cat.id === 'healthInsurance' ? (language === 'ps' ? 'روغتیایي بیمه' : language === 'fa' ? 'بیمه سلامت' : 'Insurance') : '';
                    
                    return (
                      <motion.button
                        key={cat.id}
                        whileHover={{ scale: 1.05, y: -5 }}
                        whileTap={{ scale: 0.95 }}
                        onClick={() => navigateToPage(cat.page)}
                        className={`bg-gradient-to-br ${cat.gradient} rounded-2xl p-4 text-white shadow-lg hover:shadow-xl transition-all relative overflow-hidden group`}
                      >
                        <div className="absolute top-0 right-0 w-20 h-20 bg-white/10 rounded-full -translate-y-10 translate-x-10 group-hover:scale-150 transition-transform"></div>
                        <Icon className="w-8 h-8 mb-2 relative z-10 mx-auto" />
                        <p className="text-sm font-bold relative z-10">{label}</p>
                      </motion.button>
                    );
                  })}
                </motion.div>
              </div>

              {/* NEW FEATURES - Emergency & Health Tools */}
              <div className="mb-12">
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8"
                >
                  {/* Emergency SOS */}
                  <motion.button
                    whileHover={{ scale: 1.05, y: -5 }}
                    whileTap={{ scale: 0.95 }}
                    onClick={() => navigateToPage('emergency')}
                    className="bg-gradient-to-br from-red-500 to-rose-600 rounded-3xl p-6 text-white shadow-2xl hover:shadow-red-500/50 transition-all relative overflow-hidden group"
                  >
                    <div className="absolute top-0 right-0 w-32 h-32 bg-white/10 rounded-full -translate-y-16 translate-x-16 group-hover:scale-150 transition-transform"></div>
                    <Shield className="w-12 h-12 mb-3 relative z-10" />
                    <h3 className="text-xl font-bold mb-2 relative z-10">
                      {language === 'ps' ? '🚨 بیړنی حالت' : language === 'fa' ? '🚨 اضطراری' : '🚨 Emergency SOS'}
                    </h3>
                    <p className="text-sm opacity-90 relative z-10">
                      {language === 'ps' ? 'بیړني طبي مرسته' : language === 'fa' ? 'کمک پزشکی فوری' : 'Urgent Medical Help'}
                    </p>
                  </motion.button>

                  {/* Health Tracker */}
                  <motion.button
                    whileHover={{ scale: 1.05, y: -5 }}
                    whileTap={{ scale: 0.95 }}
                    onClick={() => checkAuthAndNavigate('health-tracker')}
                    className="bg-gradient-to-br from-blue-500 to-cyan-600 rounded-3xl p-6 text-white shadow-2xl hover:shadow-blue-500/50 transition-all relative overflow-hidden group"
                  >
                    <div className="absolute top-0 right-0 w-32 h-32 bg-white/10 rounded-full -translate-y-16 translate-x-16 group-hover:scale-150 transition-transform"></div>
                    <Activity className="w-12 h-12 mb-3 relative z-10" />
                    <h3 className="text-xl font-bold mb-2 relative z-10">
                      {language === 'ps' ? '📊 روغتیا ټریکر' : language === 'fa' ? '📊 ردیاب سلامت' : '📊 Health Tracker'}
                    </h3>
                    <p className="text-sm opacity-90 relative z-10">
                      {language === 'ps' ? 'د روغتیا معلومات' : language === 'fa' ? 'اطلاعات سلامت' : 'Track your health'}
                    </p>
                  </motion.button>

                  {/* Medicine Reminder */}
                  <motion.button
                    whileHover={{ scale: 1.05, y: -5 }}
                    whileTap={{ scale: 0.95 }}
                    onClick={() => checkAuthAndNavigate('medicine-reminder')}
                    className="bg-gradient-to-br from-purple-500 to-violet-600 rounded-3xl p-6 text-white shadow-2xl hover:shadow-purple-500/50 transition-all relative overflow-hidden group"
                  >
                    <div className="absolute top-0 right-0 w-32 h-32 bg-white/10 rounded-full -translate-y-16 translate-x-16 group-hover:scale-150 transition-transform"></div>
                    <Pill className="w-12 h-12 mb-3 relative z-10" />
                    <h3 className="text-xl font-bold mb-2 relative z-10">
                      {language === 'ps' ? '💊 د درملو یادونه' : language === 'fa' ? '💊 یادآور دارو' : '💊 Medicine Reminder'}
                    </h3>
                    <p className="text-sm opacity-90 relative z-10">
                      {language === 'ps' ? 'درمل په وخت' : language === 'fa' ? 'دارو به موقع' : 'Take on time'}
                    </p>
                  </motion.button>

                  {/* Donation System */}
                  <motion.button
                    whileHover={{ scale: 1.05, y: -5 }}
                    whileTap={{ scale: 0.95 }}
                    onClick={() => navigateToPage('donation')}
                    className="bg-gradient-to-br from-rose-500 to-pink-600 rounded-3xl p-6 text-white shadow-2xl hover:shadow-rose-500/50 transition-all relative overflow-hidden group"
                  >
                    <div className="absolute top-0 right-0 w-32 h-32 bg-white/10 rounded-full -translate-y-16 translate-x-16 group-hover:scale-150 transition-transform"></div>
                    <Heart className="w-12 h-12 mb-3 relative z-10 fill-white" />
                    <h3 className="text-xl font-bold mb-2 relative z-10">
                      {language === 'ps' ? '💝 مرسته وکړئ' : language === 'fa' ? '💝 کمک کنید' : '💝 Help & Support'}
                    </h3>
                    <p className="text-sm opacity-90 relative z-10">
                      {language === 'ps' ? 'ناروغانو سره مرسته' : language === 'fa' ? 'کمک به بیماران' : 'Help patients'}
                    </p>
                  </motion.button>

                  {/* Medical Consultations */}
                  <motion.button
                    whileHover={{ scale: 1.05, y: -5 }}
                    whileTap={{ scale: 0.95 }}
                    onClick={() => checkAuthAndNavigate('consultations')}
                    className="bg-gradient-to-br from-indigo-500 to-purple-600 rounded-3xl p-6 text-white shadow-2xl hover:shadow-indigo-500/50 transition-all relative overflow-hidden group"
                  >
                    <div className="absolute top-0 right-0 w-32 h-32 bg-white/10 rounded-full -translate-y-16 translate-x-16 group-hover:scale-150 transition-transform"></div>
                    <MessageCircle className="w-12 h-12 mb-3 relative z-10" />
                    <h3 className="text-xl font-bold mb-2 relative z-10">
                      {language === 'ps' ? '💬 طبي مشورې' : language === 'fa' ? '💬 مشاوره طبی' : '💬 Consultations'}
                    </h3>
                    <p className="text-sm opacity-90 relative z-10">
                      {language === 'ps' ? 'مشوره واخلئ' : language === 'fa' ? 'مشاوره بگیرید' : 'Get advice'}
                    </p>
                  </motion.button>
                </motion.div>

                {/* Statistics Section */}
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.2 }}
                  className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-8"
                >
                  <div className="bg-white/70 backdrop-blur-xl rounded-3xl p-6 border border-white/50 shadow-lg">
                    <div className="flex items-center gap-3 mb-2">
                      <Users className="w-8 h-8 text-blue-600" />
                      <div>
                        <p className="text-3xl font-bold text-blue-600">25,000+</p>
                        <p className="text-sm text-gray-600">
                          {language === 'ps' ? 'کاروونکي' : language === 'fa' ? 'کاربران' : 'Users'}
                        </p>
                      </div>
                    </div>
                  </div>

                  <div className="bg-white/70 backdrop-blur-xl rounded-3xl p-6 border border-white/50 shadow-lg">
                    <div className="flex items-center gap-3 mb-2">
                      <Stethoscope className="w-8 h-8 text-purple-600" />
                      <div>
                        <p className="text-3xl font-bold text-purple-600">500+</p>
                        <p className="text-sm text-gray-600">
                          {language === 'ps' ? 'ډاکټران' : language === 'fa' ? 'دکتران' : 'Doctors'}
                        </p>
                      </div>
                    </div>
                  </div>

                  <div className="bg-white/70 backdrop-blur-xl rounded-3xl p-6 border border-white/50 shadow-lg">
                    <div className="flex items-center gap-3 mb-2">
                      <Hospital className="w-8 h-8 text-red-600" />
                      <div>
                        <p className="text-3xl font-bold text-red-600">50+</p>
                        <p className="text-sm text-gray-600">
                          {language === 'ps' ? 'روغتونونه' : language === 'fa' ? 'بیمارستان‌ها' : 'Hospitals'}
                        </p>
                      </div>
                    </div>
                  </div>

                  <div className="bg-white/70 backdrop-blur-xl rounded-3xl p-6 border border-white/50 shadow-lg">
                    <div className="flex items-center gap-3 mb-2">
                      <Bot className="w-8 h-8 text-green-600" />
                      <div>
                        <p className="text-3xl font-bold text-green-600">100K+</p>
                        <p className="text-sm text-gray-600">
                          {language === 'ps' ? 'AI مشورې' : language === 'fa' ? 'مشاوره AI' : 'AI Chats'}
                        </p>
                      </div>
                    </div>
                  </div>
                </motion.div>

                {/* Additional Tools Section */}
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.3 }}
                  className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-8"
                >
                  {/* AI Chat */}
                  <motion.button
                    whileHover={{ scale: 1.03, y: -3 }}
                    whileTap={{ scale: 0.97 }}
                    onClick={() => checkAuthAndNavigate('ai-chat')}
                    className="bg-gradient-to-br from-violet-500 to-purple-600 rounded-3xl p-6 text-white shadow-xl hover:shadow-purple-500/50 transition-all relative overflow-hidden group"
                  >
                    <div className="absolute top-0 right-0 w-24 h-24 bg-white/10 rounded-full -translate-y-12 translate-x-12 group-hover:scale-150 transition-transform"></div>
                    <Bot className="w-10 h-10 mb-3 relative z-10" />
                    <h3 className="text-lg font-bold mb-1 relative z-10">
                      {language === 'ps' ? '🤖 AI روغتیا مرستیال' : language === 'fa' ? '🤖 دستیار سلامت AI' : '🤖 AI Health Assistant'}
                    </h3>
                    <p className="text-sm opacity-90 relative z-10">
                      {language === 'ps' ? 'د AI سره خبرې وکړئ' : language === 'fa' ? 'با AI گفتگو کنید' : 'Chat with AI'}
                    </p>
                  </motion.button>

                  {/* BMI Calculator */}
                  <motion.button
                    whileHover={{ scale: 1.03, y: -3 }}
                    whileTap={{ scale: 0.97 }}
                    onClick={() => navigateToPage('bmi')}
                    className="bg-gradient-to-br from-cyan-500 to-blue-600 rounded-3xl p-6 text-white shadow-xl hover:shadow-cyan-500/50 transition-all relative overflow-hidden group"
                  >
                    <div className="absolute top-0 right-0 w-24 h-24 bg-white/10 rounded-full -translate-y-12 translate-x-12 group-hover:scale-150 transition-transform"></div>
                    <Activity className="w-10 h-10 mb-3 relative z-10" />
                    <h3 className="text-lg font-bold mb-1 relative z-10">
                      {language === 'ps' ? '📊 BMI محاسبه' : language === 'fa' ? '📊 محاسبه BMI' : '📊 BMI Calculator'}
                    </h3>
                    <p className="text-sm opacity-90 relative z-10">
                      {language === 'ps' ? 'د وزن ارزونه' : language === 'fa' ? 'ارزیابی وزن' : 'Weight check'}
                    </p>
                  </motion.button>

                  {/* Symptoms Checker */}
                  <motion.button
                    whileHover={{ scale: 1.03, y: -3 }}
                    whileTap={{ scale: 0.97 }}
                    onClick={() => navigateToPage('symptoms')}
                    className="bg-gradient-to-br from-indigo-500 to-purple-600 rounded-3xl p-6 text-white shadow-xl hover:shadow-indigo-500/50 transition-all relative overflow-hidden group"
                  >
                    <div className="absolute top-0 right-0 w-24 h-24 bg-white/10 rounded-full -translate-y-12 translate-x-12 group-hover:scale-150 transition-transform"></div>
                    <Brain className="w-10 h-10 mb-3 relative z-10" />
                    <h3 className="text-lg font-bold mb-1 relative z-10">
                      {language === 'ps' ? '🔍 د علایمو معاینه' : language === 'fa' ? '🔍 بررسی علائم' : '🔍 Symptoms Checker'}
                    </h3>
                    <p className="text-sm opacity-90 relative z-10">
                      {language === 'ps' ? 'نښې معاینه کړئ' : language === 'fa' ? 'علائم بررسی کنید' : 'Check symptoms'}
                    </p>
                  </motion.button>
                </motion.div>
              </div>

              {/* ورځنۍ روغتیا ننګونې */}
              <div className="mb-12">
                <DailyHealthChallenge language={language} userId={userEmail} />
              </div>

              <div className="mb-8">
                <AdBanner type="large" />
              </div>

              {/* چټک روغتیا سکینر */}
              <div className="mb-12">
                <QuickHealthScanner language={language} />
              </div>

              <div className="mb-8">
                <AdBanner type="medium" />
              </div>

              {/* غږیز روغتیا مرستیال */}
              <div className="mb-12">
                <VoiceHealthAssistant language={language} />
              </div>

              <div className="mb-8">
                <AdBanner type="medium" />
              </div>

              {/* د افغان دودیز طب */}
              <div className="mb-12">
                <TraditionalMedicineHub language={language} />
              </div>

              <div className="mb-8">
                <AdBanner type="medium" />
              </div>

              {/* د روغتیا مشورې سیکشن */}
              <div className="mb-12">
                <HealthTipsSection 
                  language={language} 
                  currentUserEmail={userEmail}
                />
              </div>
            </div>
          )}

          {currentPage === 'doctors' && <EnhancedDoctorsDirectory language={language} onBack={navigateBack} />}
          {currentPage === 'hospitals' && <HospitalDirectory language={language} onBack={navigateBack} />}
          {currentPage === 'medicine' && <MedicineGuide language={language} onBack={navigateBack} />}
          {currentPage === 'laboratory' && <LaboratoryDirectory language={language} onBack={navigateBack} isAdmin={isAuthenticated} adminEmail={userEmail} />}
          {currentPage === 'vaccination' && (
            <div className="min-h-screen bg-gradient-to-br from-pink-50 via-rose-50 to-red-50 p-8">
              <button onClick={() => setCurrentPage('home')} className="mb-6 flex items-center gap-2 text-gray-700 hover:text-pink-600">
                <ArrowLeft className="w-5 h-5" />
                {language === 'ps' ? 'شاته' : language === 'fa' ? 'بازگشت' : 'Back'}
              </button>
              <div className="text-center max-w-2xl mx-auto">
                <Syringe className="w-24 h-24 mx-auto mb-6 text-pink-600" />
                <h1 className="text-4xl font-bold bg-gradient-to-r from-pink-600 to-rose-600 bg-clip-text text-transparent mb-4">
                  {language === 'ps' ? '💉 واکسین' : language === 'fa' ? '💉 واکسیناسیون' : '💉 Vaccination'}
                </h1>
                <p className="text-xl text-gray-600">
                  {language === 'ps' ? 'د واکسین فیچر ډېر ژر راځي!' : language === 'fa' ? 'فیچر واکسیناسیون بزودی!' : 'Vaccination feature coming soon!'}
                </p>
              </div>
            </div>
          )}
          {currentPage === 'mental-health' && (
            <div className="min-h-screen bg-gradient-to-br from-violet-50 via-purple-50 to-fuchsia-50 p-8">
              <button onClick={() => setCurrentPage('home')} className="mb-6 flex items-center gap-2 text-gray-700 hover:text-violet-600">
                <ArrowLeft className="w-5 h-5" />
                {language === 'ps' ? 'شاته' : language === 'fa' ? 'بازگشت' : 'Back'}
              </button>
              <div className="text-center max-w-2xl mx-auto">
                <Brain className="w-24 h-24 mx-auto mb-6 text-violet-600" />
                <h1 className="text-4xl font-bold bg-gradient-to-r from-violet-600 to-fuchsia-600 bg-clip-text text-transparent mb-4">
                  {language === 'ps' ? '🧠 رواني روغتیا' : language === 'fa' ? '🧠 سلامت روان' : '🧠 Mental Health'}
                </h1>
                <p className="text-xl text-gray-600">
                  {language === 'ps' ? 'د رواني روغتیا فیچر ډېر ژر راځي!' : language === 'fa' ? 'فیچر سلامت روان بزودی!' : 'Mental health feature coming soon!'}
                </p>
              </div>
            </div>
          )}
          {currentPage === 'pregnancy' && (
            <div className="min-h-screen bg-gradient-to-br from-rose-50 via-pink-50 to-red-50 p-8">
              <button onClick={() => setCurrentPage('home')} className="mb-6 flex items-center gap-2 text-gray-700 hover:text-rose-600">
                <ArrowLeft className="w-5 h-5" />
                {language === 'ps' ? 'شاته' : language === 'fa' ? 'بازگشت' : 'Back'}
              </button>
              <div className="text-center max-w-2xl mx-auto">
                <Baby className="w-24 h-24 mx-auto mb-6 text-rose-600" />
                <h1 className="text-4xl font-bold bg-gradient-to-r from-rose-600 to-pink-600 bg-clip-text text-transparent mb-4">
                  {language === 'ps' ? '👶 حاملګي' : language === 'fa' ? '👶 بارداری' : '👶 Pregnancy'}
                </h1>
                <p className="text-xl text-gray-600">
                  {language === 'ps' ? 'د حاملګي فیچر ډېر ژر راځي!' : language === 'fa' ? 'فیچر بارداری بزودی!' : 'Pregnancy feature coming soon!'}
                </p>
              </div>
            </div>
          )}
          {currentPage === 'dental' && (
            <div className="min-h-screen bg-gradient-to-br from-cyan-50 via-blue-50 to-indigo-50 p-8">
              <button onClick={() => setCurrentPage('home')} className="mb-6 flex items-center gap-2 text-gray-700 hover:text-cyan-600">
                <ArrowLeft className="w-5 h-5" />
                {language === 'ps' ? 'شاته' : language === 'fa' ? 'بازگشت' : 'Back'}
              </button>
              <div className="text-center max-w-2xl mx-auto">
                <Smile className="w-24 h-24 mx-auto mb-6 text-cyan-600" />
                <h1 className="text-4xl font-bold bg-gradient-to-r from-cyan-600 to-blue-600 bg-clip-text text-transparent mb-4">
                  {language === 'ps' ? '😁 غاښونه' : language === 'fa' ? '😁 دندان' : '😁 Dental Care'}
                </h1>
                <p className="text-xl text-gray-600">
                  {language === 'ps' ? 'د غاښونو فیچر ډېر ژر راځي!' : language === 'fa' ? 'فیچر دندان بزودی!' : 'Dental care feature coming soon!'}
                </p>
              </div>
            </div>
          )}
          {currentPage === 'eye-care' && (
            <div className="min-h-screen bg-gradient-to-br from-amber-50 via-yellow-50 to-orange-50 p-8">
              <button onClick={() => setCurrentPage('home')} className="mb-6 flex items-center gap-2 text-gray-700 hover:text-amber-600">
                <ArrowLeft className="w-5 h-5" />
                {language === 'ps' ? 'شاته' : language === 'fa' ? 'بازگشت' : 'Back'}
              </button>
              <div className="text-center max-w-2xl mx-auto">
                <Eye className="w-24 h-24 mx-auto mb-6 text-amber-600" />
                <h1 className="text-4xl font-bold bg-gradient-to-r from-amber-600 to-orange-600 bg-clip-text text-transparent mb-4">
                  {language === 'ps' ? '👁️ سترګې' : language === 'fa' ? '👁️ چشم' : '👁️ Eye Care'}
                </h1>
                <p className="text-xl text-gray-600">
                  {language === 'ps' ? 'د سترګو فیچر ډېر ژر راځي!' : language === 'fa' ? 'فیچر چشم بزودی!' : 'Eye care feature coming soon!'}
                </p>
              </div>
            </div>
          )}
          {currentPage === 'physiotherapy' && (
            <div className="min-h-screen bg-gradient-to-br from-emerald-50 via-teal-50 to-cyan-50 p-8">
              <button onClick={() => setCurrentPage('home')} className="mb-6 flex items-center gap-2 text-gray-700 hover:text-emerald-600">
                <ArrowLeft className="w-5 h-5" />
                {language === 'ps' ? 'شاته' : language === 'fa' ? 'بازگشت' : 'Back'}
              </button>
              <div className="text-center max-w-2xl mx-auto">
                <HeartPulse className="w-24 h-24 mx-auto mb-6 text-emerald-600" />
                <h1 className="text-4xl font-bold bg-gradient-to-r from-emerald-600 to-teal-600 bg-clip-text text-transparent mb-4">
                  {language === 'ps' ? '💓 فزیوتراپي' : language === 'fa' ? '💓 فیزیوتراپی' : '💓 Physiotherapy'}
                </h1>
                <p className="text-xl text-gray-600">
                  {language === 'ps' ? 'د فزیوتراپي فیچر ډېر ژر راځي!' : language === 'fa' ? 'فیچر فیزیوتراپی بزودی!' : 'Physiotherapy feature coming soon!'}
                </p>
              </div>
            </div>
          )}
          {currentPage === 'blood-bank' && (
            <div className="min-h-screen bg-gradient-to-br from-red-50 via-rose-50 to-pink-50 p-8">
              <button onClick={() => setCurrentPage('home')} className="mb-6 flex items-center gap-2 text-gray-700 hover:text-red-600">
                <ArrowLeft className="w-5 h-5" />
                {language === 'ps' ? 'شاته' : language === 'fa' ? 'بازگشت' : 'Back'}
              </button>
              <div className="text-center max-w-2xl mx-auto">
                <Droplet className="w-24 h-24 mx-auto mb-6 text-red-600" />
                <h1 className="text-4xl font-bold bg-gradient-to-r from-red-600 to-rose-600 bg-clip-text text-transparent mb-4">
                  {language === 'ps' ? '🩸 وینې بانک' : language === 'fa' ? '🩸 بانک خون' : '🩸 Blood Bank'}
                </h1>
                <p className="text-xl text-gray-600">
                  {language === 'ps' ? 'د وینې بانک فیچر ډېر ژر راځي!' : language === 'fa' ? 'فیچر بانک خون بزودی!' : 'Blood bank feature coming soon!'}
                </p>
              </div>
            </div>
          )}
          {currentPage === 'ambulance' && (
            <div className="min-h-screen bg-gradient-to-br from-orange-50 via-red-50 to-rose-50 p-8">
              <button onClick={() => setCurrentPage('home')} className="mb-6 flex items-center gap-2 text-gray-700 hover:text-orange-600">
                <ArrowLeft className="w-5 h-5" />
                {language === 'ps' ? 'شاته' : language === 'fa' ? 'بازگشت' : 'Back'}
              </button>
              <div className="text-center max-w-2xl mx-auto">
                <Ambulance className="w-24 h-24 mx-auto mb-6 text-orange-600" />
                <h1 className="text-4xl font-bold bg-gradient-to-r from-orange-600 to-red-600 bg-clip-text text-transparent mb-4">
                  {language === 'ps' ? '🚑 امبولانس' : language === 'fa' ? '🚑 آمبولانس' : '🚑 Ambulance'}
                </h1>
                <p className="text-xl text-gray-600">
                  {language === 'ps' ? 'د امبولانس فیچر ډېر ژر راځي!' : language === 'fa' ? 'فیچر آمبولانس بزودی!' : 'Ambulance feature coming soon!'}
                </p>
              </div>
            </div>
          )}
          {currentPage === 'health-insurance' && (
            <div className="min-h-screen bg-gradient-to-br from-sky-50 via-blue-50 to-indigo-50 p-8">
              <button onClick={() => setCurrentPage('home')} className="mb-6 flex items-center gap-2 text-gray-700 hover:text-sky-600">
                <ArrowLeft className="w-5 h-5" />
                {language === 'ps' ? 'شاته' : language === 'fa' ? 'بازگشت' : 'Back'}
              </button>
              <div className="text-center max-w-2xl mx-auto">
                <FileHeart className="w-24 h-24 mx-auto mb-6 text-sky-600" />
                <h1 className="text-4xl font-bold bg-gradient-to-r from-sky-600 to-indigo-600 bg-clip-text text-transparent mb-4">
                  {language === 'ps' ? '📋 روغتیایي بیمه' : language === 'fa' ? '📋 بیمه سلامت' : '📋 Health Insurance'}
                </h1>
                <p className="text-xl text-gray-600">
                  {language === 'ps' ? 'د بیمې فیچر ډېر ژر راځي!' : language === 'fa' ? 'فیچر بیمه بزودی!' : 'Insurance feature coming soon!'}
                </p>
              </div>
            </div>
          )}
          {currentPage === 'firstaid' && <FirstAid language={language} onBack={navigateBack} />}
          {currentPage === 'health-tips' && <HealthTipsSection language={language} onBack={navigateBack} />}
          {currentPage === 'nutrition' && <NutritionGuide language={language} onBack={navigateBack} />}
          
          {currentPage === 'community' && (
            isAuthenticated ? (
              <EnhancedSocialFeed
                language={language}
                currentUserId={userEmail || 'guest@healmate.com'}
                currentUserName={userName || 'Guest User'}
                currentUserImage="https://images.unsplash.com/photo-1633332755192-727a05c4013d?w=400"
                onNavigateToPremium={() => navigateToPage('premium')}
                onNavigateToProfile={(userId) => {
                  setViewingUserId(userId);
                  navigateToPage('profile');
                }}
              />
            ) : (
              <div className="min-h-screen flex items-center justify-center p-4">
                <div className="bg-white/90 backdrop-blur-xl rounded-3xl p-8 max-w-md w-full text-center shadow-xl">
                  <MessageCircle className="w-16 h-16 text-purple-600 mx-auto mb-4" />
                  <h2 className="text-2xl mb-2">
                    {language === 'ps' ? 'د ټولنې ته ننوتل' : language === 'fa' ? 'ورود به انجمن' : 'Join Community'}
                  </h2>
                  <Button 
                    onClick={() => setShowAuthPage(true)}
                    className="w-full bg-gradient-to-r from-purple-500 to-pink-600 mt-4"
                  >
                    {language === 'ps' ? 'ننوتل' : language === 'fa' ? 'ورود' : 'Login'}
                  </Button>
                </div>
              </div>
            )
          )}

          {currentPage === 'contact' && <ContactUs language={language} onBack={navigateBack} />}
          {currentPage === 'about' && <AboutUs language={language} onBack={navigateBack} />}
          {currentPage === 'settings' && (
            <Settings 
              language={language} 
              onBack={navigateBack} 
              onLanguageChange={setLanguage}
              currentUserEmail={userEmail}
              currentUserName={userName}
              onAdminClick={() => navigateToPage('admin')}
              onNavigate={(page) => navigateToPage(page as Page)}
              onLogout={handleLogout}
            />
          )}
          {currentPage === 'admin' && userEmail === 'ibrahimkhaksar.it@gmail.com' && (
            <AdminPanel language={language} onBack={navigateBack} />
          )}
          {currentPage === 'books' && <BooksLibrary language={language} onBack={navigateBack} currentUserEmail={userEmail} />}
          {currentPage === 'consultations' && (
            <ConsultationsPage 
              language={language} 
              onBack={navigateBack}
              userName={userName}
              userEmail={userEmail}
            />
          )}
          {currentPage === 'profile' && isAuthenticated && (
            <ModernProfilePage 
              language={language} 
              onBack={navigateBack}
              onLogout={handleLogout}
              onLanguageChange={setLanguage}
            />
          )}
          {currentPage === 'premium' && (
            isAuthenticated ? (
              <PremiumPlans language={language} onBack={navigateBack} currentUserId={userEmail} />
            ) : (
              <div className="min-h-screen flex items-center justify-center p-4 bg-gradient-to-br from-amber-50 via-orange-50 to-pink-50">
                <div className="bg-white/90 backdrop-blur-xl rounded-3xl p-8 max-w-md w-full text-center shadow-xl border border-white/50">
                  <div className="bg-gradient-to-br from-amber-500 to-orange-600 p-6 rounded-3xl w-20 h-20 mx-auto mb-6 flex items-center justify-center shadow-lg">
                    <Star className="w-12 h-12 text-white fill-white" />
                  </div>
                  <h2 className="text-3xl mb-4 bg-gradient-to-r from-amber-600 to-orange-600 bg-clip-text text-transparent">
                    {language === 'ps' ? 'پریمیم پلانونه' : language === 'fa' ? 'پلن‌های پریمیوم' : 'Premium Plans'}
                  </h2>
                  <p className="text-gray-600 mb-6">
                    {language === 'ps' ? 'د پریمیم فیچرونو ته لاسرسی لپاره ننوتل ضروري دي' : language === 'fa' ? 'برای دسترسی به ویژگی‌های پریمیوم باید وارد شوید' : 'Please sign in to access premium features'}
                  </p>
                  <Button 
                    onClick={() => setShowAuthPage(true)}
                    className="w-full bg-gradient-to-r from-amber-500 to-orange-600 hover:from-amber-600 hover:to-orange-700 text-white py-6 rounded-2xl shadow-lg"
                  >
                    {language === 'ps' ? 'ننوتل' : language === 'fa' ? 'ورود' : 'Sign In'}
                  </Button>
                  <Button 
                    onClick={() => setCurrentPage('home')}
                    className="w-full mt-4 bg-gray-100 hover:bg-gray-200 text-gray-700 py-6 rounded-2xl"
                  >
                    {language === 'ps' ? 'بیرته' : language === 'fa' ? 'بازگشت' : 'Go Back'}
                  </Button>
                </div>
              </div>
            )
          )}
          {currentPage === 'privacy' && <PrivacyPolicy language={language} onBack={navigateBack} />}
          {currentPage === 'terms' && <TermsOfService language={language} onBack={navigateBack} />}
          {currentPage === 'help' && <HelpSupport language={language} onBack={navigateBack} />}
          {currentPage === 'ai-chat' && (
            isAuthenticated ? (
              <AIHealthChat 
                language={language} 
                currentUserId={userEmail}
                onNavigateToPremium={() => navigateToPage('premium')}
                onBack={navigateBack} 
              />
            ) : (
              <div className="min-h-screen flex items-center justify-center p-4 bg-gradient-to-br from-violet-50 via-purple-50 to-pink-50">
                <div className="bg-white/90 backdrop-blur-xl rounded-3xl p-8 max-w-md w-full text-center shadow-xl border border-white/50">
                  <div className="bg-gradient-to-br from-violet-500 to-purple-600 p-6 rounded-3xl w-20 h-20 mx-auto mb-6 flex items-center justify-center shadow-lg">
                    <Bot className="w-12 h-12 text-white" />
                  </div>
                  <h2 className="text-3xl mb-4 bg-gradient-to-r from-violet-600 to-purple-600 bg-clip-text text-transparent">
                    {language === 'ps' ? 'AI روغتیا چټ' : language === 'fa' ? 'چت سلامت AI' : 'AI Health Chat'}
                  </h2>
                  <p className="text-gray-600 mb-6">
                    {language === 'ps' ? 'د AI مرستیال سره خبرې کولو لپاره ننوتل ضروري دي' : language === 'fa' ? 'برای گفتگو با دستیار AI باید وارد شوید' : 'Please sign in to chat with AI assistant'}
                  </p>
                  <Button 
                    onClick={() => setShowAuthPage(true)}
                    className="w-full bg-gradient-to-r from-violet-500 to-purple-600 hover:from-violet-600 hover:to-purple-700 text-white py-6 rounded-2xl shadow-lg"
                  >
                    {language === 'ps' ? 'ننوتل' : language === 'fa' ? 'ورود' : 'Sign In'}
                  </Button>
                  <Button 
                    onClick={() => setCurrentPage('home')}
                    className="w-full mt-4 bg-gray-100 hover:bg-gray-200 text-gray-700 py-6 rounded-2xl"
                  >
                    {language === 'ps' ? 'بیرته' : language === 'fa' ? 'بازگشت' : 'Go Back'}
                  </Button>
                </div>
              </div>
            )
          )}
          {currentPage === 'bmi' && <BMICalculator language={language} onBack={navigateBack} />}
          {currentPage === 'symptoms' && <SymptomChecker language={language} onBack={navigateBack} />}
          {currentPage === 'diseases' && <DiseaseEncyclopedia language={language} onBack={navigateBack} />}
          {currentPage === 'emergency' && <EmergencySOS language={language} onBack={navigateBack} userId={userEmail || 'guest'} />}
          {currentPage === 'health-tracker' && (
            isAuthenticated ? (
              <HealthTracker language={language} onBack={navigateBack} userId={userEmail} />
            ) : (
              <div className="min-h-screen flex items-center justify-center p-4 bg-gradient-to-br from-pink-50 via-rose-50 to-red-50">
                <div className="bg-white/90 backdrop-blur-xl rounded-3xl p-8 max-w-md w-full text-center shadow-xl border border-white/50">
                  <div className="bg-gradient-to-br from-pink-500 to-rose-600 p-6 rounded-3xl w-20 h-20 mx-auto mb-6 flex items-center justify-center shadow-lg">
                    <Activity className="w-12 h-12 text-white" />
                  </div>
                  <h2 className="text-3xl mb-4 bg-gradient-to-r from-pink-600 to-rose-600 bg-clip-text text-transparent">
                    {language === 'ps' ? 'روغتیا ټریکر' : language === 'fa' ? 'پیگیری سلامت' : 'Health Tracker'}
                  </h2>
                  <p className="text-gray-600 mb-6">
                    {language === 'ps' ? 'د روغتیا ټریک کولو لپاره ننوتل ضروري دي' : language === 'fa' ? 'برای پیگیری سلامت باید وارد شوید' : 'Please sign in to track your health'}
                  </p>
                  <Button 
                    onClick={() => setShowAuthPage(true)}
                    className="w-full bg-gradient-to-r from-pink-500 to-rose-600 hover:from-pink-600 hover:to-rose-700 text-white py-6 rounded-2xl shadow-lg"
                  >
                    {language === 'ps' ? 'ننوتل' : language === 'fa' ? 'ورود' : 'Sign In'}
                  </Button>
                  <Button 
                    onClick={() => setCurrentPage('home')}
                    className="w-full mt-4 bg-gray-100 hover:bg-gray-200 text-gray-700 py-6 rounded-2xl"
                  >
                    {language === 'ps' ? 'بیرته' : language === 'fa' ? 'بازگشت' : 'Go Back'}
                  </Button>
                </div>
              </div>
            )
          )}
          {currentPage === 'medicine-reminder' && (
            isAuthenticated ? (
              <MedicineReminder language={language} onBack={navigateBack} userId={userEmail} />
            ) : (
              <div className="min-h-screen flex items-center justify-center p-4 bg-gradient-to-br from-orange-50 via-amber-50 to-yellow-50">
                <div className="bg-white/90 backdrop-blur-xl rounded-3xl p-8 max-w-md w-full text-center shadow-xl border border-white/50">
                  <div className="bg-gradient-to-br from-orange-500 to-amber-600 p-6 rounded-3xl w-20 h-20 mx-auto mb-6 flex items-center justify-center shadow-lg">
                    <Pill className="w-12 h-12 text-white" />
                  </div>
                  <h2 className="text-3xl mb-4 bg-gradient-to-r from-orange-600 to-amber-600 bg-clip-text text-transparent">
                    {language === 'ps' ? 'د درملو یادښت' : language === 'fa' ? 'یادآوری دارو' : 'Medicine Reminder'}
                  </h2>
                  <p className="text-gray-600 mb-6">
                    {language === 'ps' ? 'د درملو یادښت ټاکلو لپاره ننوتل ضروري دي' : language === 'fa' ? 'برای تنظیم یادآوری دارو باید وارد شوید' : 'Please sign in to set medicine reminders'}
                  </p>
                  <Button 
                    onClick={() => setShowAuthPage(true)}
                    className="w-full bg-gradient-to-r from-orange-500 to-amber-600 hover:from-orange-600 hover:to-amber-700 text-white py-6 rounded-2xl shadow-lg"
                  >
                    {language === 'ps' ? 'ننوتل' : language === 'fa' ? 'ورود' : 'Sign In'}
                  </Button>
                  <Button 
                    onClick={() => setCurrentPage('home')}
                    className="w-full mt-4 bg-gray-100 hover:bg-gray-200 text-gray-700 py-6 rounded-2xl"
                  >
                    {language === 'ps' ? 'بیرته' : language === 'fa' ? 'بازگشت' : 'Go Back'}
                  </Button>
                </div>
              </div>
            )
          )}
          {currentPage === 'rating' && (
            <RatingReview 
              language={language} 
              onBack={navigateBack} 
              currentUserEmail={userEmail}
              currentUserName={userName}
            />
          )}
          {currentPage === 'donation' && (
            <DonationSystem
              language={language}
              onBack={navigateBack}
              isAdmin={isAuthenticated}
              adminEmail={userEmail}
            />
          )}
          {currentPage === 'charity' && (
            <CharitySystem
              language={language}
              onBack={navigateBack}
              currentUserEmail={userEmail}
              currentUserName={userName}
            />
          )}
          {currentPage === 'appointments' && (
            isAuthenticated ? (
              <AppointmentBooking language={language} onBack={navigateBack} userId={userEmail} />
            ) : (
              <div className="min-h-screen flex items-center justify-center p-4 bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50">
                <div className="bg-white/90 backdrop-blur-xl rounded-3xl p-8 max-w-md w-full text-center shadow-xl border border-white/50">
                  <div className="bg-gradient-to-br from-blue-500 to-indigo-600 p-6 rounded-3xl w-20 h-20 mx-auto mb-6 flex items-center justify-center shadow-lg">
                    <Calendar className="w-12 h-12 text-white" />
                  </div>
                  <h2 className="text-3xl mb-4 bg-gradient-to-r from-blue-600 to-indigo-600 bg-clip-text text-transparent">
                    {language === 'ps' ? 'د ډاکټر ملاقات' : language === 'fa' ? 'نوبت‌دهی' : 'Book Appointment'}
                  </h2>
                  <p className="text-gray-600 mb-6">
                    {language === 'ps' ? 'د ډاکټر سره وخت ټاکلو لپاره ننوتل ضروري دي' : language === 'fa' ? 'برای تنظیم نوبت با دکتر باید وارد شوید' : 'Please sign in to book appointments'}
                  </p>
                  <Button 
                    onClick={() => setShowAuthPage(true)}
                    className="w-full bg-gradient-to-r from-blue-500 to-indigo-600 hover:from-blue-600 hover:to-indigo-700 text-white py-6 rounded-2xl shadow-lg"
                  >
                    {language === 'ps' ? 'ننوتل' : language === 'fa' ? 'ورود' : 'Sign In'}
                  </Button>
                  <Button 
                    onClick={() => setCurrentPage('home')}
                    className="w-full mt-4 bg-gray-100 hover:bg-gray-200 text-gray-700 py-6 rounded-2xl"
                  >
                    {language === 'ps' ? 'بیرته' : language === 'fa' ? 'بازگشت' : 'Go Back'}
                  </Button>
                </div>
              </div>
            )
          )}
          {currentPage === 'signup' && (
            <SignupPage 
              language={language} 
              onSignupSuccess={() => {
                setCurrentPage('home');
                // Optionally show a success message or redirect to profile
              }}
              onSwitchToLogin={() => {
                // If you have a login page, switch to it
                setCurrentPage('home');
              }}
              onClose={() => setCurrentPage('home')}
            />
          )}
        </Suspense>
      </main>

      <BottomNavigation
        currentPage={currentPage}
        onPageChange={checkAuthAndNavigate}
        language={language}
        userEmail={userEmail}
      />

      {/* PWA Status Indicator */}
      <PWAStatus language={language} />

      {/* PWA Install Prompt */}
      <PWAInstallPrompt language={language} />

      {/* Toast Notifications */}
      <Toaster 
        position="top-center"
        richColors
        theme="light"
        expand={true}
      />
    </div>
  );
}

export default App;