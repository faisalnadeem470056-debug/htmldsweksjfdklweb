import { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'af.healmate.app',
  appName: 'HealMate',
  webDir: 'dist',
  bundledWebRuntime: false,
  
  // د Android لپاره
  android: {
    buildOptions: {
      keystorePath: undefined,
      keystorePassword: undefined,
      keystoreAlias: undefined,
      keystoreAliasPassword: undefined,
      releaseType: 'APK'
    }
  },
  
  // د iOS لپاره (optional)
  ios: {
    contentInset: 'automatic',
    scheme: 'HealMate'
  },
  
  // Plugins
  plugins: {
    SplashScreen: {
      launchShowDuration: 2000,
      launchAutoHide: true,
      backgroundColor: '#10b981',
      androidSplashResourceName: 'splash',
      androidScaleType: 'CENTER_CROP',
      showSpinner: true,
      androidSpinnerStyle: 'large',
      iosSpinnerStyle: 'small',
      spinnerColor: '#ffffff',
      splashFullScreen: true,
      splashImmersive: true
    },
    
    StatusBar: {
      style: 'LIGHT',
      backgroundColor: '#10b981'
    },
    
    Keyboard: {
      resize: 'body',
      style: 'DARK',
      resizeOnFullScreen: true
    },
    
    // د Firebase Push Notifications لپاره
    PushNotifications: {
      presentationOptions: ['badge', 'sound', 'alert']
    }
  },
  
  // د Server تنظیمات (د development لپاره)
  server: {
    androidScheme: 'https',
    iosScheme: 'https',
    hostname: 'healmate.app',
    
    // د local development لپاره
    // url: 'http://localhost:5173',
    // cleartext: true
  }
};

export default config;
