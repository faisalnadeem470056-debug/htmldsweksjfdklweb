# 🛠️ PWA Development Notes
## د Service Worker او PWA د Development په وخت کې مهم نوټس

---

## ⚠️ عام تېروتنې او حلونه:

### 1. **Service Worker MIME Type Error** ✅ FIXED

#### خطا:
```
❌ Service Worker registration failed: SecurityError: 
The script has an unsupported MIME type ('text/html')
```

#### سبب:
- Service Worker په Figma preview environment کې کار نه کوي
- د `/public/service-worker.js` فایل د سم MIME type سره serve نه کیږي
- iFrame previews د Service Workers support نه کوي

#### حل:
✅ Service Worker اوس یوازې په دې شرایطو کې فعالیږي:
- ✅ په Production (HTTPS) کې
- ✅ په Localhost کې
- ❌ په Figma preview کې فعال نه دی
- ❌ په iFrame previews کې فعال نه دی

---

## 🔍 د PWA د Testing طریقې:

### د Development په وخت:

#### 1. **Local Testing** (بهترین طریقه):
```bash
# د production build جوړول
npm run build

# د built version چلول
npm run preview

# یا
npx serve dist -p 3000
```

بیا browser ته لاړشئ:
```
http://localhost:3000
```

Service Worker به کار وکړي او PWA features به فعال وي! ✅

#### 2. **Chrome DevTools استعمال**:
```
1. F12 ووهئ (DevTools خلاص کړئ)
2. "Application" tab ته لاړشئ
3. "Service Workers" کتل:
   - که active وي ✅ سم کار کوي
   - که نه وي، د "Update" بټن کلیک وکړئ
4. "Manifest" کتل:
   - د icons، colors، او نور check کړئ
5. "Storage" کتل:
   - د cache معلومات وګورئ
```

#### 3. **Lighthouse Audit**:
```
1. Chrome DevTools (F12)
2. "Lighthouse" tab
3. "Progressive Web App" انتخاب کړئ
4. "Analyze page load" کلیک وکړئ
```

د 90+ score هدف جوړ کړئ! 🎯

---

## 📱 د Mobile Testing:

### د Android Device کې:
```
1. خپل phone او computer په ورته WiFi کې وصل کړئ
2. د computer IP address ومومئ:
   - Windows: ipconfig
   - Mac/Linux: ifconfig

3. په phone browser کې لاړشئ:
   http://YOUR_IP:3000

4. د "Add to Home Screen" option به وښایي!
```

### د iOS Device کې:
```
1. Safari browser استعمال کړئ (Chrome کار نه کوي)
2. ورته IP address ته لاړشئ
3. د Share button (⬆️) کلیک وکړئ
4. "Add to Home Screen" انتخاب کړئ
```

---

## 🌐 د Production Deployment:

### د Service Worker فعالولو شرایط:
- ✅ باید HTTPS وي (یا localhost)
- ✅ باید valid SSL certificate وي
- ✅ د service-worker.js فایل باید د سم MIME type سره serve شي
- ✅ د CORS headers باید سم وي

### د Hosting وړاندیزونه:
1. **Netlify** (آسان او وړیا)
   ```bash
   npm run build
   # drag & drop dist/ folder to netlify.com
   ```

2. **Vercel** (ډیره ګړندۍ)
   ```bash
   npm install -g vercel
   vercel deploy
   ```

3. **Firebase Hosting** (د Google لخوا)
   ```bash
   npm install -g firebase-tools
   firebase init hosting
   firebase deploy
   ```

---

## 🐛 د Debugging Tips:

### که Service Worker کار نه کوي:

#### 1. د Cache پاکول:
```javascript
// په Browser Console کې
pwaManager.clearCache()
```

#### 2. د Service Worker Unregister کول:
```javascript
// په Browser Console کې
navigator.serviceWorker.getRegistrations()
  .then(registrations => {
    registrations.forEach(reg => reg.unregister())
  })
```

#### 3. Hard Refresh:
```
Windows: Ctrl + Shift + R
Mac: Cmd + Shift + R
```

### که Install Prompt نه وښیي:

#### Checklist:
- [ ] د HTTPS استعمال کوئ (یا localhost)
- [ ] د manifest.json فایل valid دی
- [ ] Icons شتون لري (192px او 512px)
- [ ] Service Worker active دی
- [ ] مخکې dismiss نه کړی

#### د Manual Prompt:
```javascript
// په Browser Console کې
window.location.reload()
```

---

## 📊 د PWA Environment Status:

### اوس مهال دا معلومات Console کې log کیږي:

```javascript
🌍 PWA Environment: {
  hostname: "...",
  protocol: "https:" او "http:",
  swSupported: true/false,
  swEnabled: true/false,
  isProduction: true/false,
  isLocalhost: true/false,
  isFigmaPreview: true/false
}
```

### د Status Indicators:

په Screen کې به دا وښیي:
- 🟢 **سبز**: PWA Installed
- 🟠 **نارنجي**: PWA Not Installed (خو install کولی شئ)
- 🔴 **سور**: Offline Mode

---

## 🎯 Production Checklist:

### د Play Store ته د Upload مخکې:

- [ ] ټول Icons upload شوي (72px تر 512px)
- [ ] Screenshots تیار دي (لږ تر لږه 2)
- [ ] Feature Graphic (1024x500px)
- [ ] Privacy Policy URL
- [ ] د HTTPS سره deploy شوی
- [ ] Service Worker په production کې کار کوي
- [ ] Lighthouse PWA score > 90
- [ ] د Android APK د PWABuilder څخه generate شوی
- [ ] د Play Console معلومات بشپړ دي

### د Production Testing:

```bash
# 1. Build کړئ
npm run build

# 2. Local preview
npm run preview

# 3. په browser کې test کړئ
http://localhost:4173

# 4. Lighthouse audit
# (په DevTools کې)

# 5. که ټول سم وي، deploy کړئ!
```

---

## 💡 مهم یادونې:

### ✅ اوس مهال چې څه کار کوي:
- ✅ PWA Manifest valid دی
- ✅ Service Worker په localhost/production کې کار کوي
- ✅ Install Prompt فعال دی
- ✅ Offline support شتون لري
- ✅ Network status monitoring
- ✅ Push notifications API تیار دی
- ✅ Share API تیار دی
- ✅ Background sync تیار دی

### ⏳ چې څه باید تاسو وکړئ:
- ⏳ Icons جوړ کړئ او upload کړئ
- ⏳ Screenshots واخلئ
- ⏳ Feature graphic design کړئ
- ⏳ د production domain ته deploy کړئ
- ⏳ د PWABuilder څخه Android APK generate کړئ
- ⏳ Play Console ته upload کړئ

---

## 🚀 Quick Commands:

```bash
# د development server
npm run dev

# د production build
npm run build

# د built version preview
npm run preview

# د PWA audit
# په browser DevTools > Lighthouse

# د Service Worker status check
# په browser Console:
navigator.serviceWorker.getRegistrations()
```

---

## 📞 د مرستې لپاره:

که کومه تېروتنه یا پوښتنه ولرئ:
- 📖 د `PWA-SETUP-GUIDE.md` فایل وګورئ
- 📋 د `ICONS-CHECKLIST.md` فایل وګورئ
- 💬 په مخ کې پوښتنه وکړئ

---

**د یادونې وړ**: په Figma preview environment کې Service Worker فعال نه دی، خو دا عادي خبره ده او د production کې به بشپړ کار وکړي! ✅

**Last Updated**: November 2024
