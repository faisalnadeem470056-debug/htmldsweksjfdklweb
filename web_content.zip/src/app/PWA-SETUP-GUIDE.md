# 🚀 HealMate PWA Setup Guide
## د Play Store ته د Upload کولو بشپړ لارښود

---

## 📱 د PWA Features چې اوس فعال دي:

### ✅ هغه څه چې جوړ شوي:
1. **PWA Manifest** (`/public/manifest.json`)
   - د اپلیکیشن نوم، توضیحات، او آیکونونه
   - د Screen orientation او display mode
   - د Shortcuts (Quick Actions) د Emergency، Doctors، AI Chat او Donation لپاره
   - د Share Target API support

2. **Service Worker** (`/public/service-worker.js`)
   - د Offline caching strategy
   - د Network-first د API لپاره
   - د Cache-first د static resources لپاره
   - د Background Sync support
   - د Push Notifications support

3. **PWA Install Prompt** (`/components/PWAInstallPrompt.tsx`)
   - د Android/Desktop لپاره automatic install prompt
   - د iOS لپاره مرحله په مرحله لارښوونې
   - د Benefits showcase
   - د Install tracking

4. **PWA Manager** (`/utils/pwaManager.ts`)
   - د Service Worker lifecycle management
   - د Network status monitoring
   - د Push Notifications API
   - د Background Sync API
   - د Share API
   - د Cache management
   - د Device information

5. **Offline Support** (`/public/offline.html`)
   - د آفلاین صفحه د کاروونکو لپاره
   - Auto-refresh کله چې انټرنت بیرته راشي

---

## 🎨 د Icons او Images چې اړین دي:

### د `/public/icons/` directory کې دا icons جوړ کړئ:

```
/public/icons/
├── icon-72x72.png       (72x72px)
├── icon-96x96.png       (96x96px)
├── icon-128x128.png     (128x128px)
├── icon-144x144.png     (144x144px)
├── icon-152x152.png     (152x152px)
├── icon-192x192.png     (192x192px - Main Icon)
├── icon-384x384.png     (384x384px)
├── icon-512x512.png     (512x512px - Main Icon)
├── badge-72x72.png      (د Notification badge لپاره)
├── emergency.png        (96x96px - د Emergency shortcut)
├── doctor.png           (96x96px - د Doctors shortcut)
├── ai.png               (96x96px - د AI Chat shortcut)
└── donate.png           (96x96px - د Donation shortcut)
```

### 🎨 د Icon Design مشورې:
- **Design**: د HealMate logo استعمال کړئ (❤️ heart with + symbol)
- **Colors**: Purple/Pink gradient (`#8b5cf6` to `#ec4899`)
- **Format**: PNG د transparent background سره
- **Tool**: Figma, Canva, یا https://maskable.app/ استعمال کړئ

### 📸 د Screenshots:
```
/public/screenshots/
├── home.png            (540x720px - Mobile screenshot)
└── categories.png      (1080x1920px - Desktop screenshot)
```

### 🌅 د iOS Splash Screens (Optional خو وړاندیز کیږي):
```
/public/splash/
├── iphone5_splash.png      (640x1136px)
├── iphone6_splash.png      (750x1334px)
├── iphoneplus_splash.png   (1242x2208px)
├── iphonex_splash.png      (1125x2436px)
├── iphonexr_splash.png     (828x1792px)
├── iphonexsmax_splash.png  (1242x2688px)
├── ipad_splash.png         (1536x2048px)
├── ipadpro1_splash.png     (1668x2224px)
└── ipadpro2_splash.png     (2048x2732px)
```

---

## 📦 د Play Store ته د Upload کولو ګامونه:

### 1️⃣ د TWA (Trusted Web Activity) Setup:

#### **Option A: د Bubblewrap استعمال (آسانه طریقه)**

```bash
# د Bubblewrap نصبول
npm install -g @bubblewrap/cli

# د TWA پروژه جوړول
bubblewrap init --manifest=https://yourwebsite.com/manifest.json

# د Android APK جوړول
bubblewrap build

# د Release APK Sign کول
bubblewrap build --release
```

#### **Option B: د PWABuilder استعمال (ډیره آسانه)**

1. د https://www.pwabuilder.com ته لاړشئ
2. خپل website URL دننه کړئ
3. "Generate Package" کلیک وکړئ
4. "Android" انتخاب کړئ
5. د Settings تنظیم کړئ:
   - **Package ID**: `com.healmate.app`
   - **App name**: `HealMate`
   - **Launcher name**: `HealMate`
   - **Theme color**: `#8b5cf6`
   - **Background color**: `#ffffff`
   - **Icon**: Upload your 512x512 icon
   - **Splash screens**: Upload if available
6. "Build My PWA" کلیک وکړئ
7. د Android Package download کړئ

### 2️⃣ د Google Play Console Setup:

1. د https://play.google.com/console ته لاړشئ
2. "Create App" کلیک وکړئ
3. معلومات ډک کړئ:
   - **App name**: HealMate - روغتیایي اپلیکیشن
   - **Default language**: Pashto (ps)
   - **App or game**: App
   - **Free or paid**: Free
   - **Category**: Health & Fitness

4. **Store Listing** ډک کړئ:
   ```
   Short description (پښتو):
   د افغانستان بشپړ روغتیایي اپلیکیشن - د ډاکټرانو، روغتونونو، درملو او روغتیایي مشورو لپاره

   Full description (پښتو):
   🏥 HealMate - د افغانستان د خلکو لپاره بشپړ روغتیایي اپلیکیشن

   ✨ مرکزي ځانګړتیاوې:
   • 🩺 د ډاکټرانو او متخصصینو بشپړ فهرست
   • 🏥 د روغتونونو او کلینیکونو معلومات
   • 💊 د درملو لارښود او قیمتونه
   • 🔬 د آزمایښتونو او لابراتوارونو فهرست
   • 🤖 AI روغتیایي مشاور (24/7)
   • 🚨 د بیړنیو حالتونو SOS
   • 📊 د روغتیا ټریکر
   • 💊 د درملو یادونه
   • 💝 د ناروغانو سره مرسته کول
   • 📚 د روغتیا کتابونه او مقالې

   🌐 درې ژبې: پښتو، دری، او انګلیسي

   ⚡ ګړندی، آسان، او په پوره توګه آفلاین کار کوي!

   👨‍⚕️ جوړونکی: ډاکټر ابراهیم خاکسار
   📧 د تماس: ibrahimkhaksar.it@gmail.com
   📞 Hesab Pay: +93779494512
   ```

5. **Graphics** Upload کړئ:
   - **App icon**: 512x512px (د Icon څخه)
   - **Feature graphic**: 1024x500px (د HealMate cover image)
   - **Phone screenshots**: لږ تر لږه 2 (څومره زیات هومره ښه)
   - **7-inch tablet screenshots**: Optional
   - **10-inch tablet screenshots**: Optional

6. **Privacy Policy** URL:
   ```
   https://yourwebsite.com/?page=privacy
   ```

7. **Contact Details**:
   - **Email**: ibrahimkhaksar.it@gmail.com
   - **Phone**: +93779494512

### 3️⃣ د APK Upload او Testing:

1. "Production" ته لاړشئ
2. "Create new release" کلیک وکړئ
3. د APK/AAB فایل upload کړئ
4. **Release notes** (په درې ژبو):
   ```
   پښتو:
   • د HealMate لومړنی نسخه
   • د ډاکټرانو او روغتونونو بشپړ فهرست
   • AI روغتیایي مشاور
   • د بیړنیو حالتونو support

   دری:
   • نسخه اول HealMate
   • فهرست کامل داکتران و شفاخانه‌ها
   • مشاور صحی AI
   • پشتیبانی اضطراری

   English:
   • HealMate First Release
   • Complete doctors and hospitals directory
   • AI Health Assistant
   • Emergency Support
   ```

5. "Review release" او بیا "Start rollout to Production"

### 4️⃣ د Review لپاره انتظار:

- Google به ستاسو اپلیکیشن review کړي (معمولاً 2-7 ورځې)
- که مشکل وي، Google به email واستوي
- د approval وروسته، اپلیکیشن به Play Store کې publish شي! 🎉

---

## 🔧 د Development لپاره مشورې:

### د Local Testing:
```bash
# د production build جوړول
npm run build

# د local server پرانستل
npm run preview
# او یا
npx serve dist -p 3000
```

### د PWA Testing:
1. Chrome DevTools خلاص کړئ (F12)
2. "Application" tab ته لاړشئ
3. "Manifest" او "Service Workers" check کړئ
4. د Lighthouse audit پرمخ بوځئ (PWA category)

### د Manifest Validation:
- https://manifest-validator.appspot.com ته لاړشئ
- خپل manifest.json URL دننه کړئ او validate کړئ

---

## 📊 د PWA Score بهبودول:

### د Lighthouse چې څه check کوي:
- ✅ Fast and reliable (Service Worker)
- ✅ Installable (Manifest)
- ✅ PWA Optimized (Icons, Theme, etc.)
- ✅ Accessible (ARIA labels, etc.)
- ✅ SEO (Meta tags, etc.)

### د Score بهبودولو مشورې:
1. د ټولو Icons په مناسب اندازو سره upload کړئ
2. د Screenshots upload کړئ
3. Service Worker سم کار کوي check کړئ
4. د Offline page جوړه کړئ
5. د HTTPS استعمال کړئ (په Production کې)

---

## 🎯 وروستي Checklist:

### د Upload مخکې:
- [ ] ټول Icons (72px تر 512px)
- [ ] Screenshots (لږ تر لږه 2)
- [ ] Feature Graphic (1024x500px)
- [ ] Privacy Policy URL
- [ ] Contact Email او Phone
- [ ] د Manifest او Service Worker سم کار کوي
- [ ] د Lighthouse PWA score > 90

### د Upload وروسته:
- [ ] د Store Listing کتل
- [ ] د Screenshots کتل
- [ ] د Privacy Policy link check کول
- [ ] د Rollout monitoring
- [ ] د Reviews ځواب ورکول

---

## 💡 اضافي Features چې وروسته اضافه کولای شئ:

1. **Push Notifications**
   - د Firebase Cloud Messaging (FCM) setup
   - د Backend notification system

2. **Analytics**
   - Google Analytics
   - Firebase Analytics

3. **AdMob Integration**
   - د Google AdMob SDK
   - د Banner او Interstitial ads

4. **In-App Purchases**
   - Google Play Billing
   - د Premium features

5. **Deep Linking**
   - د Specific pages لپاره direct links
   - د Social sharing optimization

---

## 📞 د مرستې لپاره:

**Developer**: ډاکټر ابراهیم خاکسار
**Email**: ibrahimkhaksar.it@gmail.com
**Phone**: +93779494512
**Payment**: Hesab Pay

---

## 🎉 بریالیتوب!

ستاسو HealMate اپلیکیشن اوس د Play Store ته د Upload کولو لپاره بشپړ تیار دی!

که مشکل ولرئ یا مرسته ته اړتیا ولرئ، په مخ ځواب وکړئ! 🚀

---

**Last Updated**: 2025
**Version**: 1.0.0
**License**: د ډاکټر ابراهیم خاکسار ملکیت
