#!/bin/bash

# HealMate Android Setup Script
# د ډاکټر ابراهیم خاکسار لخوا جوړ شوی
# د TWA (Trusted Web Activity) setup د Play Store لپاره

echo "🏥 HealMate Android Setup"
echo "=========================="
echo ""

# Colors
GREEN='\033[0;32m'
BLUE='\033[0;34m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# د functions
function print_success {
    echo -e "${GREEN}✅ $1${NC}"
}

function print_info {
    echo -e "${BLUE}ℹ️  $1${NC}"
}

function print_error {
    echo -e "${RED}❌ $1${NC}"
}

function print_warning {
    echo -e "${YELLOW}⚠️  $1${NC}"
}

# Step 1: د Prerequisites چیک کول
echo "Step 1: د Prerequisites چیک کول..."
echo "-----------------------------------"

# Java چیک کول
if command -v java &> /dev/null; then
    JAVA_VERSION=$(java -version 2>&1 | awk -F '"' '/version/ {print $2}')
    print_success "Java نصب دی: $JAVA_VERSION"
else
    print_error "Java نصب نه دی. مهرباني وکړئ JDK 17 نصب کړئ"
    exit 1
fi

# Node.js چیک کول
if command -v node &> /dev/null; then
    NODE_VERSION=$(node --version)
    print_success "Node.js نصب دی: $NODE_VERSION"
else
    print_error "Node.js نصب نه دی. مهرباني وکړئ Node.js نصب کړئ"
    exit 1
fi

# Gradle چیک کول
if [ -f "./android/gradlew" ]; then
    print_success "Gradle wrapper موجود دی"
else
    print_warning "Gradle wrapper نه موجود دی"
fi

echo ""

# Step 2: د Firebase setup
echo "Step 2: د Firebase Configuration"
echo "---------------------------------"

if [ -f "./android/app/google-services.json" ]; then
    print_success "google-services.json موجود دی"
else
    print_error "google-services.json نه موجود دی!"
    print_info "مهرباني وکړئ دا فایل د Firebase Console څخه ډاونلوډ او په /android/app/ کې کاپي کړئ"
    print_info "Link: https://console.firebase.google.com"
fi

echo ""

# Step 3: د Firebase config چیک کول
echo "Step 3: د Firebase Config فایل"
echo "-------------------------------"

if [ -f "./firebase-config.ts" ]; then
    if grep -q "YOUR_FIREBASE_API_KEY" "./firebase-config.ts"; then
        print_warning "firebase-config.ts ته د Firebase معلوماتو اړتیا ده"
        print_info "مهرباني وکړئ YOUR_FIREBASE_API_KEY او نور معلومات تازه کړئ"
    else
        print_success "firebase-config.ts configure شوی"
    fi
else
    print_error "firebase-config.ts نه موجود دی"
fi

echo ""

# Step 4: د Android build configuration
echo "Step 4: د Android Build Configuration"
echo "-------------------------------------"

# د domain چیک کول
if grep -q "YOUR_DOMAIN.com" "./android/app/build.gradle"; then
    print_warning "د domain معلومات تازه کولو ته اړتیا ده"
    print_info "په build.gradle کې YOUR_DOMAIN.com د خپل domain سره بدل کړئ"
else
    print_success "Domain configure شوی"
fi

# د AdMob App ID چیک کول
if grep -q "ca-app-pub-XXXXXXXXXXXXXXXX" "./android/app/src/main/AndroidManifest.xml"; then
    print_warning "د AdMob App ID تازه کولو ته اړتیا ده"
    print_info "په AndroidManifest.xml کې د AdMob App ID اضافه کړئ"
else
    print_success "AdMob App ID configure شوی"
fi

echo ""

# Step 5: د Keystore چیک کول
echo "Step 5: د Release Keystore"
echo "--------------------------"

if [ -f "./android/healmate-release.keystore" ]; then
    print_success "Release keystore موجود دی"
else
    print_warning "Release keystore نه موجود دی"
    print_info "د release build لپاره keystore جوړ کړئ:"
    echo ""
    echo "keytool -genkey -v -keystore android/healmate-release.keystore -alias healmate -keyalg RSA -keysize 2048 -validity 10000"
    echo ""
fi

if [ -f "./android/gradle.properties" ]; then
    print_success "gradle.properties موجود دی"
else
    print_warning "gradle.properties نه موجود دی"
    print_info "د keystore معلوماتو لپاره gradle.properties جوړ کړئ"
fi

echo ""

# Step 6: د PWA build
echo "Step 6: د PWA Build"
echo "-------------------"

print_info "د PWA build کول..."
npm run build

if [ $? -eq 0 ]; then
    print_success "PWA build بریالیتوب سره جوړ شو"
else
    print_error "PWA build ناکام شو"
    exit 1
fi

echo ""

# Step 7: د Android build options
echo "Step 7: د Android Build Options"
echo "--------------------------------"
echo ""
echo "د Android build لپاره لاندې commands کارولی شئ:"
echo ""
echo "1️⃣  د Debug APK لپاره:"
echo "   cd android && ./gradlew assembleDebug"
echo ""
echo "2️⃣  د Release APK لپاره:"
echo "   cd android && ./gradlew assembleRelease"
echo ""
echo "3️⃣  د Release AAB لپاره (Play Store):"
echo "   cd android && ./gradlew bundleRelease"
echo ""
echo "4️⃣  د Clean build لپاره:"
echo "   cd android && ./gradlew clean"
echo ""

# د build option وپوښتل
read -p "ایا تاسو اوس Debug APK جوړ کول غواړئ؟ (y/n): " BUILD_DEBUG

if [ "$BUILD_DEBUG" = "y" ] || [ "$BUILD_DEBUG" = "Y" ]; then
    echo ""
    print_info "د Debug APK جوړول..."
    cd android
    ./gradlew assembleDebug
    
    if [ $? -eq 0 ]; then
        echo ""
        print_success "Debug APK بریالیتوب سره جوړ شو! 🎉"
        print_info "د APK ځای: android/app/build/outputs/apk/debug/app-debug.apk"
        echo ""
        
        # د install option
        read -p "ایا تاسو APK په device کې install کول غواړئ؟ (y/n): " INSTALL_APK
        
        if [ "$INSTALL_APK" = "y" ] || [ "$INSTALL_APK" = "Y" ]; then
            if command -v adb &> /dev/null; then
                print_info "د APK install کول..."
                adb install -r app/build/outputs/apk/debug/app-debug.apk
                
                if [ $? -eq 0 ]; then
                    print_success "APK بریالیتوب سره install شو! 🎉"
                else
                    print_error "APK install ناکام شو"
                fi
            else
                print_error "ADB نه موجود دی. Android SDK Platform Tools نصب کړئ"
            fi
        fi
    else
        print_error "Debug APK build ناکام شو"
    fi
    
    cd ..
fi

echo ""
echo "=========================="
echo "Setup Complete! 🎉"
echo "=========================="
echo ""
print_info "د نورو معلوماتو لپاره دا فایلونه وګورئ:"
echo "  📄 ANDROID_SETUP_GUIDE.md - بشپړ setup لارښوود"
echo "  📄 PLAY_STORE_CHECKLIST.md - د Play Store checklist"
echo ""
print_info "د مرستې لپاره:"
echo "  📧 Email: ibrahimkhaksar.it@gmail.com"
echo "  📱 WhatsApp: +93 779 494 512"
echo ""
print_success "بریالیتوب مبارک! ❤️"
echo ""
