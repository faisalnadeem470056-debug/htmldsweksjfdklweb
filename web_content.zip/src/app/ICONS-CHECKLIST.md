# 🎨 HealMate PWA Icons Checklist

## 📋 د Icons فهرست چې اړین دي

---

## 1️⃣ Main App Icons (په `/public/icons/` کې)

### 🔴 **REQUIRED** - دا Icons باید حتماً وي:

| Icon | Size | Purpose | Status |
|------|------|---------|--------|
| `icon-72x72.png` | 72x72px | Android launcher | ⏳ |
| `icon-96x96.png` | 96x96px | Android launcher | ⏳ |
| `icon-128x128.png` | 128x128px | Android launcher | ⏳ |
| `icon-144x144.png` | 144x144px | Android launcher | ⏳ |
| `icon-152x152.png` | 152x152px | iOS / Safari | ⏳ |
| `icon-192x192.png` | 192x192px | **Main Android Icon** | ⏳ |
| `icon-384x384.png` | 384x384px | High-res displays | ⏳ |
| `icon-512x512.png` | 512x512px | **Main Icon / Play Store** | ⏳ |

---

## 2️⃣ Additional Icons

### 🟡 **RECOMMENDED** - د بهترو تجربې لپاره:

| Icon | Size | Purpose | Status |
|------|------|---------|--------|
| `badge-72x72.png` | 72x72px | Notification badge | ⏳ |
| `emergency.png` | 96x96px | Emergency shortcut | ⏳ |
| `doctor.png` | 96x96px | Doctors shortcut | ⏳ |
| `ai.png` | 96x96px | AI Chat shortcut | ⏳ |
| `donate.png` | 96x96px | Donation shortcut | ⏳ |

---

## 3️⃣ Play Store Graphics

### 🔴 **REQUIRED** د Play Store لپاره:

| Graphic | Size | Format | Status |
|---------|------|--------|--------|
| App Icon | 512x512px | PNG (32-bit) | ⏳ |
| Feature Graphic | 1024x500px | PNG/JPG | ⏳ |
| Phone Screenshots | 320-3840px | PNG/JPG (2-8 images) | ⏳ |

### 🟢 **OPTIONAL** خو وړاندیز کیږي:

| Graphic | Size | Format | Status |
|---------|------|--------|--------|
| 7" Tablet Screenshots | 1080-7680px | PNG/JPG | ⏳ |
| 10" Tablet Screenshots | 1080-7680px | PNG/JPG | ⏳ |
| TV Banner | 1280x720px | PNG/JPG | ⏳ |
| Promo Graphic | 180x120px | PNG/JPG | ⏳ |

---

## 4️⃣ iOS Splash Screens

### 🟡 **OPTIONAL** د iOS لپاره:

| Screen | Size | Status |
|--------|------|--------|
| iPhone 5/SE | 640x1136px | ⏳ |
| iPhone 6/7/8 | 750x1334px | ⏳ |
| iPhone 6+/7+/8+ | 1242x2208px | ⏳ |
| iPhone X/XS | 1125x2436px | ⏳ |
| iPhone XR | 828x1792px | ⏳ |
| iPhone XS Max | 1242x2688px | ⏳ |
| iPad | 1536x2048px | ⏳ |
| iPad Pro 10.5" | 1668x2224px | ⏳ |
| iPad Pro 12.9" | 2048x2732px | ⏳ |

---

## 🎨 د Icon Design مشورې:

### ✨ د HealMate Icon Design:
```
Main Elements:
• ❤️ Heart symbol (د روغتیا سمبول)
• ➕ Plus/Cross (د طبي خدمتونو سمبول)
• 🎨 Purple to Pink gradient (#8b5cf6 → #ec4899)
```

### 📐 Design Guidelines:
1. **Background**: Transparent یا سپین
2. **Padding**: د icon شاوخوا 10% padding
3. **Format**: PNG د 32-bit color سره
4. **Shape**: Square (1:1 ratio) - Android automatically rounds it
5. **Safe Zone**: د مرکزي عناصر د 80% په دننه کې ساتئ

### 🛠️ د Icon جوړولو وسایل:

#### **آنلاین Tools:**
- 🌐 **Figma**: https://figma.com (Best for professionals)
- 🎨 **Canva**: https://canva.com (Easy for beginners)
- 🖼️ **Maskable.app**: https://maskable.app (د PWA icons لپاره)
- 📱 **PWA Asset Generator**: https://progressier.com/pwa-icon-generator

#### **Desktop Tools:**
- 🖥️ Adobe Illustrator
- 🎨 Adobe Photoshop
- 🆓 GIMP (Free)
- 🆓 Inkscape (Free)

#### **Quick Generation:**
```bash
# که تاسو یو main 1024x1024px icon لرئ، دا command استعمال کړئ:
npm install -g pwa-asset-generator

pwa-asset-generator input-icon.png ./public/icons \
  --icon-only \
  --favicon \
  --type png \
  --padding "10%"
```

---

## 📸 د Screenshots مشورې:

### د Phone Screenshots:
1. **Count**: لږ تر لږه 2، تر 8 پورې
2. **Orientation**: Portrait (عمودی)
3. **Size**: 1080x1920px (9:16 ratio) وړاندیز کیږي
4. **Content**: 
   - Screenshot 1: د Home صفحه (د categories سره)
   - Screenshot 2: د Doctors فهرست
   - Screenshot 3: د AI Chat
   - Screenshot 4: د Emergency SOS
   - Screenshot 5: د Donation system

### د Screenshots د اخیستلو طریقه:
```
1. په خپل browser کې Developer Tools خلاص کړئ (F12)
2. Device toolbar enable کړئ (Ctrl+Shift+M)
3. Device: "Pixel 5" یا "iPhone 12 Pro" انتخاب کړئ
4. Screenshot واخلئ (Ctrl+Shift+P → "Capture screenshot")
5. په Figma یا Photoshop کې د text overlay اضافه کړئ:
   • د صفحې نوم (په درې ژبو)
   • د مرکزي feature highlight
```

---

## ✅ د Feature Graphic (1024x500px):

### د Design عناصر:
```
Left side (40%):
• د HealMate لوی logo
• د App نوم په درې ژبو
• Gradient background

Right side (60%):
• د App screenshots mockup
• د مرکزي features icons
• Call-to-action text:
  "د افغانستان بشپړ روغتیایي اپلیکیشن"
```

### مثال Template:
```
Background: Purple to Pink gradient
Left: Logo + "HealMate" text
Center: Phone mockup د home screen سره
Right: Features list:
  • 🩺 ډاکټران
  • 🏥 روغتونونه
  • 💊 درمل
  • 🤖 AI مشاور
  • 🚨 بیړنی حالت
```

---

## 🔄 د Icons د Update کولو Workflow:

### که تاسو Icons چمتو کړل:
1. د `/public/icons/` directory جوړ کړئ
2. ټول Icons په مناسب names او sizes upload کړئ
3. د browser cache clear کړئ
4. د PWA uninstall او بیا install کړئ
5. د Lighthouse audit چلوئ د تصدیق لپاره

### که Icons نه لرئ:
1. د Canva template استعمال کړئ:
   - د Canva ته لاړشئ
   - "App Icon" search کړئ
   - د HealMate colors استعمال کړئ (#8b5cf6, #ec4899)
   - د Heart + Plus design جوړ کړئ
   - په ټولو sizes کې export کړئ

---

## 📞 که مرستې ته اړتیا ولرئ:

### زه کولای شم مرسته وکړم:
1. ✅ د Icon design templates
2. ✅ د Screenshot editing
3. ✅ د Feature graphic design
4. ✅ د Splash screens generation
5. ✅ د Size optimization

**راشئ په مخ ووایئ که کومې مرستې ته اړتیا لرئ!** 🚀

---

## 🎯 Quick Start لپاره:

### د Minimum Icons چې اوس همدا اړین دي:
```bash
/public/icons/
├── icon-192x192.png    # Main Android icon
└── icon-512x512.png    # Play Store icon

د دې دوو icons سره، PWA به کار وکړي!
نور Icons وروسته اضافه کولای شئ.
```

### د Temporary Icons لپاره:
که تاسو اوس Icons نه لرئ، زه کولای شم د HealMate لپاره simple heart-based icons generate کړم. آیا غواړئ؟

---

**Last Updated**: November 2024
**Version**: 1.0
