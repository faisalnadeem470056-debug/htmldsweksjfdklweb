# ✅ Play Store Submission Checklist
# د Play Store Submission چک لیسټ

---

## 📋 **Pre-Submission Checklist:**

### **1. ✅ Technical Requirements:**

```
Development:
□ React app fully tested
□ All features working
□ No console errors
□ No crashes
□ Performance optimized
□ Images optimized
□ Code minified
□ PWA ready (manifest + SW)

Build:
□ Production build created (npm run build)
□ dist/ folder generated
□ No build errors
□ Bundle size acceptable (<10MB)

Capacitor:
□ Capacitor installed
□ Android platform added
□ Config file ready (capacitor.config.json)
□ All files synced (cap sync android)

Android:
□ Android Studio installed
□ SDK installed (API 22-34)
□ build.gradle configured
□ AndroidManifest.xml configured
□ Permissions declared
□ Icons added (all sizes)
□ Splash screen added

Keystore:
□ Keystore generated (.jks file)
□ Password saved securely
□ Alias saved
□ Keystore backed up (3 places!)
□ build.gradle has signing config

APK/AAB:
□ Release APK built successfully
□ Or AAB built (recommended)
□ Signed with keystore
□ Tested on real device
□ Tested on Android 6+ devices
□ No crashes
□ All features work offline
□ AdMob ads showing
□ Premium purchases working
```

---

### **2. ✅ Content Requirements:**

```
App Information:
□ App name decided: "HealMate"
□ Package name: com.healmate.afghanistan
□ Version code: 1
□ Version name: 1.0.0
□ Category: Medical
□ Content rating: PEGI 3 / Everyone
□ Target age: 18+

Languages:
□ Default language: Pashto (ps)
□ Additional: Dari (fa), English (en)
□ Store listing in all 3 languages
□ Screenshots in all 3 languages

Privacy & Legal:
□ Privacy Policy written (PS/FA/EN)
□ Privacy Policy hosted online
□ Privacy Policy URL ready
□ Terms & Conditions ready
□ GDPR compliant
□ Afghan laws compliant
□ Medical disclaimers included
□ User data handling documented
```

---

### **3. ✅ Store Listing Assets:**

```
App Icon:
□ 512x512 PNG
□ 32-bit with alpha
□ No transparency
□ HealMate logo clear
□ Meets Google guidelines
□ Professional quality

Feature Graphic:
□ 1024x500 pixels
□ PNG or JPEG
□ High quality
□ Shows app purpose
□ Includes logo/tagline
□ Eye-catching design
□ No text cutoff

Screenshots - Phone (Required):
□ Min 2, Max 8
□ 1080x1920 or 1080x2340
□ PNG or JPEG
□ Shows key features:
  □ Home screen
  □ Doctors list
  □ Medicine database
  □ AI Chat
  □ Emergency/First Aid
  □ Community posts
□ Clean UI
□ No personal data visible
□ High quality

Screenshots - Pashto:
□ Home screen (پښتو ژبه)
□ Find Doctors (دوکتوران)
□ Medicine Guide (درمل)
□ First Aid (لومړنۍ مرسته)
□ AI Chat (AI مشورې)

Screenshots - Dari:
□ Home screen (دری ژبه)
□ Find Doctors (دکتران)
□ Medicine Guide (دارو)
□ First Aid (کمک‌های اولیه)
□ AI Chat (مشاوره AI)

Screenshots - English:
□ Home screen
□ Find Doctors
□ Medicine Guide
□ First Aid
□ AI Chat

Screenshots - Tablet (Optional):
□ 1920x1080 or 2560x1440
□ Landscape versions
□ Min 1, Max 8

Video (Optional):
□ YouTube video uploaded
□ 30 seconds to 2 minutes
□ Shows app features
□ Professional quality
□ URL ready
```

---

### **4. ✅ Text Content:**

```
App Title (30 chars max):
□ پښتو: HealMate - روغتیا
□ دری: HealMate - سلامتی
□ English: HealMate - Health

Short Description (80 chars max):
□ پښتو: د افغانستان خلکو لپاره بشپړ روغتیا اپلیکیشن - دوکتوران، درمل، مشورې
□ دری: برنامه کامل سلامت برای مردم افغانستان - دکتران، داروها، مشاوره
□ English: Complete health app for Afghanistan - Doctors, Medicine, Consultation

Full Description (4000 chars max):
□ Pashto version written:
  □ Introduction
  □ Key features (6-8 bullets)
  □ Why use HealMate
  □ Premium features
  □ Contact info
  
□ Dari version written
□ English version written

□ Includes keywords:
  □ دوکتوران / doctors
  □ روغتونونه / hospitals
  □ درمل / medicine
  □ روغتیا / health
  □ افغانستان / Afghanistan
  □ AI مشورې / consultation
  □ لومړنۍ مرسته / first aid

□ Professional tone
□ No spelling errors
□ No exaggerated claims
□ Medical disclaimers
```

---

### **5. ✅ App Settings:**

```
Categorization:
□ Category: Medical
□ Tags: health, medical, doctors, medicine, afghanistan
□ Content type: Application

Distribution:
□ Countries: Afghanistan (primary)
□ Additional: Pakistan, Iran, USA, UK, Europe
□ Excluded: None

Pricing:
□ App: Free
□ In-app purchases: Yes
  □ Basic Premium: $2.99/month
  □ Pro Premium: $4.99/month
  □ Annual Premium: $29.99/year
□ Google Play Billing integrated
□ Test purchases working

Ads:
□ Contains ads: Yes
□ AdMob integrated
□ Ad placements tested
□ Not targeting children
□ COPPA compliant

Permissions:
□ All permissions justified
□ Permission descriptions provided:
  □ INTERNET: د معلوماتو لپاره
  □ LOCATION: نږدې دوکتوران د موندلو لپاره
  □ CAMERA: د پروفایل عکس اپلوډ کولو لپاره
  □ STORAGE: عکسونو ذخیره کولو لپاره
  □ NOTIFICATIONS: د خبرتیاوو لپاره
```

---

### **6. ✅ Data Safety:**

```
Data Collection:
□ What data collected:
  □ Personal info: Name, Email, Phone
  □ Location: Approximate location
  □ Health info: Medical queries (with consent)
  □ Photos: Profile pictures
  □ App interactions: Usage analytics

□ Why collected:
  □ Account creation
  □ Find nearby doctors
  □ Personalized health advice
  □ Profile customization
  □ Improve app experience

Data Security:
□ Encryption in transit: Yes (HTTPS)
□ Encryption at rest: Yes (localStorage encrypted)
□ Data can be deleted: Yes (account deletion)
□ Data not shared with third parties
□ Privacy policy explains everything

Data Usage:
□ Not sold to third parties
□ Not used for advertising
□ Not shared with data brokers
□ Only used for app functionality
□ User has control
```

---

### **7. ✅ Content Rating:**

```
IARC Questionnaire:
□ Violence: None
□ Sexual content: None
□ Profanity: None
□ Controlled substances: None (medical only)
□ Gambling: None
□ User interaction: Yes (community)
□ User-generated content: Yes (posts)
□ Personal info collection: Yes (explained)
□ Location sharing: Yes (optional)

Expected Rating:
□ PEGI: 3
□ ESRB: Everyone
□ USK: 0
□ Classind: L

Medical Content:
□ For informational purposes only
□ Not a substitute for medical advice
□ Disclaimers present
□ No diagnosis provided
□ Directs to qualified doctors
```

---

### **8. ✅ Testing:**

```
Device Testing:
□ Tested on Android 6.0+
□ Tested on small phones (4")
□ Tested on large phones (6.5"+)
□ Tested on tablets
□ Tested on different brands:
  □ Samsung
  □ Xiaomi
  □ Huawei
  □ Others

Functionality Testing:
□ App launches successfully
□ No crashes on startup
□ All screens accessible
□ Navigation works
□ All buttons functional
□ Forms submit correctly
□ Search works
□ Filters work
□ Images load
□ Icons display correctly

Feature Testing:
□ User registration works
□ Login works
□ Profile creation works
□ Doctors list loads
□ Doctors search works
□ Doctor call works
□ Medicine search works
□ Medicine details show
□ First Aid accessible
□ AI Chat responds
□ Community posts work
□ Comments work
□ Reactions work
□ Image upload works
□ Language switching works
□ Premium purchase works
□ Ads display correctly

Network Testing:
□ Works on WiFi
□ Works on 3G/4G/5G
□ Works on slow connection
□ Offline mode works
□ Cache works
□ PWA installs

Performance Testing:
□ Fast loading (<3s)
□ Smooth scrolling
□ No lag
□ No memory leaks
□ Battery efficient
□ Data usage reasonable
```

---

### **9. ✅ Compliance:**

```
Google Play Policies:
□ No prohibited content
□ No intellectual property violations
□ No impersonation
□ No malware/spyware
□ No deceptive behavior
□ Proper permissions usage
□ Privacy policy present
□ Follows medical app guidelines

Health App Specific:
□ Medical disclaimers present
□ Not claiming to diagnose
□ Not claiming to cure
□ Directs to qualified doctors
□ Emergency info included
□ Accurate medical info
□ Credible sources cited
□ Regular content updates

User Safety:
□ No collection of sensitive data without consent
□ Secure data transmission
□ No sharing PII
□ Age-appropriate content
□ Moderation for user content
□ Report abuse feature
□ Block users feature
□ Terms of Service clear

Afghanistan Specific:
□ Dari and Pashto languages
□ Afghan doctors database
□ Local hospitals info
□ Culturally appropriate
□ Respects local laws
□ No political content
□ No religious controversy
```

---

### **10. ✅ Pre-Launch:**

```
Final Checks:
□ All above items completed
□ Double-checked everything
□ Test APK/AAB uploaded to closed testing
□ Beta testers invited
□ Beta testing completed (1-2 weeks)
□ All critical bugs fixed
□ Analytics integrated (Firebase)
□ Crash reporting enabled
□ Feedback mechanism ready
□ Support email ready: ibrahimkhaksar.it@gmail.com
□ Social media ready (optional)
□ Website/landing page ready (optional)

Launch Strategy:
□ Launch date planned
□ Marketing materials ready
□ Press release drafted (optional)
□ App Store Optimization (ASO) done
□ Keywords optimized
□ Competitor analysis done
□ Target audience defined
□ Launch announcement ready

Post-Launch Plan:
□ Monitor reviews daily
□ Respond to user feedback
□ Track crash reports
□ Monitor analytics
□ Fix bugs quickly
□ Regular updates planned (every 2-4 weeks)
□ Feature roadmap ready
□ Community engagement plan
```

---

## 🚀 **Submission Process:**

### **Step-by-Step:**

```
✅ 1. Login to Play Console
   https://play.google.com/console/
   ibrahimkhaksar.it@gmail.com

✅ 2. Create app
   [All apps] → [Create app]
   - Name: HealMate
   - Language: Pashto
   - App/Game: App
   - Free/Paid: Free

✅ 3. Complete dashboard tasks:
   □ Store listing
   □ Store settings
   □ App content
   □ Pricing & distribution

✅ 4. Upload APK/AAB:
   Production → Create new release
   - Upload APK or AAB
   - Release notes (all languages)
   - Review release

✅ 5. Submit for review:
   [Send for review]
   
✅ 6. Wait for approval:
   1-7 days typically
   Email notification

✅ 7. App goes LIVE! 🎉
```

---

## 📊 **Common Rejection Reasons:**

```
❌ Privacy Policy Issues:
   - Missing policy
   - Policy not accessible
   - Policy incomplete

✅ Solution:
   - Host on website or Google Docs
   - Include all data practices
   - Keep updated

❌ Misleading Store Listing:
   - Screenshots don't match app
   - Description exaggerated
   - False claims

✅ Solution:
   - Accurate screenshots
   - Honest description
   - No medical claims

❌ Permissions Not Justified:
   - Asking unnecessary permissions
   - No explanation provided

✅ Solution:
   - Only request needed permissions
   - Explain why in description
   - Request at right time

❌ Inappropriate Content:
   - Graphic medical content
   - User-generated inappropriate content

✅ Solution:
   - Moderate content
   - Add reporting system
   - Content filters

❌ Functionality Issues:
   - App crashes
   - Features don't work
   - Poor performance

✅ Solution:
   - Test thoroughly
   - Fix all bugs
   - Optimize performance
```

---

## ✅ **Final Pre-Submission Check:**

```
Before clicking "Submit for Review":

□ Re-read all descriptions (no typos)
□ Check all screenshots (correct language)
□ Verify all assets uploaded
□ Test APK one more time
□ Privacy policy link working
□ All sections completed (100%)
□ Green checkmarks on all tabs
□ Release notes written
□ Confident and ready!

Status: READY TO SUBMIT! 🚀
```

---

## 📞 **Need Help?**

```
Play Console Help:
https://support.google.com/googleplay/android-developer/

Policy Help:
https://support.google.com/googleplay/android-developer/topic/9858052

Community:
https://www.reddit.com/r/androiddev/
https://stackoverflow.com/questions/tagged/google-play

Direct Support:
- Email: ibrahimkhaksar.it@gmail.com
- Emergency: د Google Play Console Support
```

---

**🎉 د مبارکۍ سره! تاسو د Play Store ته publish کولو لپاره چمتو یاست! هر قدم follow کړئ او بریالۍ به شئ! 🚀📱✨**

**Estimated Timeline:**
- Preparation: 1-2 days
- Testing: 2-3 days
- Store listing: 3-4 hours
- Submission: 30 minutes
- Review: 1-7 days
- **TOTAL: ~1 week د لومړني launch لپاره**

**Good luck! بریالۍ مو غواړو! موفق باشید! 🍀**
