# ✅ د HealMate Deployment Checklist
# HealMate Deployment Checklist

---

## 📋 Phase 1: Deployment Setup

### Vercel CLI لاره:

- [ ] **Node.js installed شوی** (https://nodejs.org)
- [ ] **Vercel CLI installed شوی** (`npm install -g vercel`)
- [ ] **Vercel login بشپړ شو** (`vercel login`)
- [ ] **د project folder ته ورتللی** (`cd /path/to/healmate-app`)
- [ ] **Deploy بشپړ شو** (`vercel --prod`)
- [ ] **URL ترلاسه شو** (https://healmate-app.vercel.app)

**یا** GitHub لاره:

- [ ] **GitHub account جوړ شو**
- [ ] **Git installed شو**
- [ ] **Repository جوړ شو**
- [ ] **Code push شو** (`git push origin main`)
- [ ] **Vercel سره connect شو**
- [ ] **Auto deployment test شو**

---

## 📋 Phase 2: PWA Validation

- [ ] **Browser کې app ته ورشئ** (ستاسو Vercel URL)
- [ ] **ټول صفحې کار کوي** (Home, Doctors, Hospitals, etc.)
- [ ] **درې ژبې کار کوي** (پښتو، دری، انګلیسي)
- [ ] **Images/Icons load کیږي**
- [ ] **manifest.json valid دی**
  ```
  Browser → F12 → Application → Manifest
  ✅ د errors نه شتون
  ```
- [ ] **Service Worker registered دی**
  ```
  Browser → F12 → Application → Service Workers
  ✅ "Activated and is running"
  ```
- [ ] **Lighthouse PWA test passed** (Score 80+)
  ```
  Browser → F12 → Lighthouse → PWA → Run
  ```

---

## 📋 Phase 3: APK Generation

- [ ] **PWABuilder ته ورتللی** (https://www.pwabuilder.com)
- [ ] **URL داخل شو** (https://healmate-app.vercel.app)
- [ ] **Scan بشپړ شو** (10-15 seconds)
- [ ] **PWA Score ښه دی** (90+)
- [ ] **Android Package settings سم شول**:
  ```
  Package ID: com.healmate.afghanistan
  App Name: HealMate
  Version: 1.0.0
  Version Code: 1
  Min SDK: 21
  Target SDK: 34
  ```
- [ ] **Signing Key جوړ شو** (او خوندي save شو!)
- [ ] **AAB file download شو**
- [ ] **APK file download شو** (د testing لپاره)

---

## 📋 Phase 4: Testing

- [ ] **APK د موبایل ته install شو**
  ```
  Settings → Security → Unknown Sources → Enable
  Transfer APK → Install
  ```
- [ ] **App په موبایل کې open شو**
- [ ] **ټول features کار کوي**:
  - [ ] Home screen
  - [ ] Doctors directory
  - [ ] Hospitals list
  - [ ] Medicine guide
  - [ ] First aid
  - [ ] Health tips
  - [ ] Nutrition guide
  - [ ] Community feed
- [ ] **Language switching کار کوي**
- [ ] **Admin panel یوازې owner ته ښکاري**
- [ ] **Offline کار کوي** (WiFi off کړئ او test کړئ)

---

## 📋 Phase 5: Play Store Graphics

### App Icon:
- [ ] **512×512 PNG جوړ شو** (✅ لا دمخه په `/public/icon-512.png`)
- [ ] **Transparent background یا solid**
- [ ] **High quality**

### Screenshots (4-8 اړین):
- [ ] **Screenshot 1: Home screen** (1080×1920)
- [ ] **Screenshot 2: Doctors directory** (1080×1920)
- [ ] **Screenshot 3: Hospitals list** (1080×1920)
- [ ] **Screenshot 4: Medicine guide** (1080×1920)
- [ ] **Screenshot 5: Community feed** (1080×1920) (اختیاري)
- [ ] **Screenshot 6: Language selection** (1080×1920) (اختیاري)
- [ ] **Screenshot 7: Health tips** (1080×1920) (اختیاري)
- [ ] **Screenshot 8: First aid** (1080×1920) (اختیاري)

**د Screenshots جوړولو لاره:**
```
Chrome → F12 → Toggle Device Toolbar (Ctrl+Shift+M)
→ Dimensions: 1080×1920
→ Screenshot واخلئ
```

### Feature Graphic:
- [ ] **1024×500 PNG جوړ شو**
- [ ] **د HealMate logo شامل دی**
- [ ] **د app screenshots preview**
- [ ] **د افغانستان رنګونه** (سور، شین، تور)
- [ ] **Text: "د افغانستان روغتیا اپلیکیشن"**

**Canva.com کاروئ:**
```
1. Custom size: 1024×500
2. Design جوړ کړئ
3. Download PNG
```

---

## 📋 Phase 6: Privacy Policy

- [ ] **Privacy Policy document جوړ شو**
- [ ] **د web ته upload شو** (GitHub Pages یا Vercel)
- [ ] **URL ترلاسه شو**
  ```
  Example: https://healmate-app.vercel.app/privacy.html
  ```

**Template:** د `/APK_BUILD_NOW.md` کې موجود

---

## 📋 Phase 7: Play Console Setup

### Google Play Console Account:
- [ ] **Google Play Console ته ورتللی** (https://play.google.com/console)
- [ ] **Account جوړ شو** (که نلرئ)
- [ ] **$25 registration fee ورکړل شو** (یو ځل)

### Create App:
- [ ] **"Create app" کلیک شو**
- [ ] **App details ډک شول**:
  ```
  App name: HealMate - Afghanistan Health App
  Default language: Pashto (پښتو)
  App or game: App
  Free or paid: Free
  ```
- [ ] **Declarations تصدیق شول**

---

## 📋 Phase 8: Store Listing

### App Details:
- [ ] **Short description** (140 chars):
  ```
  د افغانستان بشپړ روغتیا اپ: دوکتوران، روغتونونه، درمل
  Afghanistan's complete health app
  ```
- [ ] **Full description** (پښتو او انګلیسي):
  - [ ] د خدماتو لیست
  - [ ] د ځانګړتیاوو لیست
  - [ ] د ژبو ذکر
- [ ] **App icon uploaded** (512×512)
- [ ] **Feature graphic uploaded** (1024×500)
- [ ] **Screenshots uploaded** (4-8 images)

### Categorization:
- [ ] **App category: Medical**
- [ ] **Tags: health, medical, doctors, hospitals**

---

## 📋 Phase 9: Content Rating

- [ ] **Questionnaire start شو**
- [ ] **App category: Medical** غوره شو
- [ ] **سوالاتو ځوابونه ورکړل شول**:
  - [ ] Violence: No
  - [ ] Sexual content: No
  - [ ] Language: No
  - [ ] Drugs: No (medical info only)
  - [ ] Gambling: No
- [ ] **Rating ترلاسه شو** (3+, Everyone, etc.)

---

## 📋 Phase 10: Target Audience & Content

### Target Audience:
- [ ] **Age group: 13 and over** غوره شو
- [ ] **Appeals to children: No** تصدیق شو

### App Content:
- [ ] **Privacy Policy URL داخل شو**
- [ ] **Ads declaration**:
  - [ ] App contains ads: Yes ✅ (AdMob)
- [ ] **Data safety form ډک شو**:
  - [ ] Data collection: None (که تاسو data collect نکړئ)
  - [ ] یا د collect شوي data تفصیلات

---

## 📋 Phase 11: Production Release

### Upload AAB:
- [ ] **Production → Releases → Create new release**
- [ ] **AAB file uploaded شو**
- [ ] **Release name set شو**: `Version 1.0.0`
- [ ] **Release notes لیکل شول** (پښتو او انګلیسي):
  ```
  Version 1.0.0
  
  د HealMate لومړنۍ نسخه:
  • د دوکتورانو او روغتونونو ډایرکټري
  • د درملو لارښود
  • د اسعافي مرستې معلومات
  • درې ژبې: پښتو، دری، انګلیسي
  ```

### Countries:
- [ ] **Afghanistan** غوره شو
- [ ] **نور هیوادونه** (اختیاري):
  - [ ] Pakistan
  - [ ] Iran
  - [ ] Tajikistan
  - [ ] Uzbekistan

---

## 📋 Phase 12: Review & Submit

- [ ] **ټول sections بشپړ شول** (✅ green checkmarks)
- [ ] **Review کلیک شو**
- [ ] **د errors check شو** (که وي، سم یې کړئ)
- [ ] **"Start rollout to Production"** کلیک شو
- [ ] **Confirmation ورکړل شو**

---

## 📋 Phase 13: Post-Submission

- [ ] **Submission confirmation email راغلی**
- [ ] **Review status check کیږي** (Play Console Dashboard)
- [ ] **2-7 ورځې انتظار** ⏳

### که Review Pass شو:
- [ ] **"App approved" email راغلی** ✅
- [ ] **App Live دی په Play Store** 🎉
- [ ] **Play Store URL ترلاسه شو**
- [ ] **App test شو** (Play Store څخه download)

### که Review Reject شو:
- [ ] **Rejection email ولوستل شو**
- [ ] **Issues identify شول**
- [ ] **مسلې سم شوې**
- [ ] **بیرته submit شو**

---

## 📋 Phase 14: Post-Launch

### د لومړیو ورځو:
- [ ] **Play Store listing check شو**
- [ ] **App download او test شو**
- [ ] **User reviews monitor شول**
- [ ] **Crash reports checked شول** (Play Console → Android Vitals)

### Marketing:
- [ ] **Play Store URL share شو**:
  - [ ] Social media (Facebook, Twitter, Instagram)
  - [ ] WhatsApp groups
  - [ ] Email contacts
- [ ] **QR code جوړ شو** (د Play Store URL لپاره)
- [ ] **Promotional materials**

### Analytics:
- [ ] **Play Console analytics checked شول**:
  - [ ] Installs
  - [ ] Ratings
  - [ ] Reviews
  - [ ] Crashes
- [ ] **AdMob revenue checked شو** (که ads enable وي)

---

## 📋 Phase 15: Updates & Maintenance

### د راتلونکي Updates:
- [ ] **د users feedback راټول شو**
- [ ] **د bugs fix شول**
- [ ] **نوي features اضافه شوې**
- [ ] **Version number update شو** (1.0.0 → 1.0.1)
- [ ] **نوی AAB جوړ شو**
- [ ] **Play Console ته upload شو**

### د Update Workflow:
```bash
# 1. Code بدل کړئ
# 2. Version update کړئ (package.json)
# 3. Build کړئ
npm run build

# 4. Vercel ته deploy کړئ
vercel --prod

# 5. PWABuilder سره نوی APK جوړ کړئ
# 6. Play Console ته upload کړئ
```

---

## ✅ Final Success Checklist:

- [ ] ✅ App deployed شو (Vercel)
- [ ] ✅ PWA validation passed
- [ ] ✅ APK/AAB جوړ شو
- [ ] ✅ Testing بشپړ شو
- [ ] ✅ Screenshots چمتو شول
- [ ] ✅ Play Console setup بشپړ شو
- [ ] ✅ Store listing ډک شو
- [ ] ✅ AAB uploaded شو
- [ ] ✅ Review submitted شو
- [ ] ✅ App approved شو
- [ ] ✅ App LIVE دی 🎉

---

## 🎊 بریا!

**ستاسو HealMate app اوس د Play Store باندې Live دی!** 🇦🇫

د افغانستان میلیونونو خلکو ته اوس د روغتیا خدمات په ګوتو کې! 📱❤️

---

## 📞 د مرستې لپاره:

- 📧 Email: ibrahimkhaksar.it@gmail.com
- 📱 Phone: +93 783 040 441 / +93 779 494 512

---

**د HealMate سره د افغانستان روغتیا دیجیټل شو! 🚀**
