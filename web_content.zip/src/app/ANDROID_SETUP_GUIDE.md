# 📱 HealMate Android App Setup Guide
## د Play Store لپاره بشپړ Setup د TWA سره

د **ډاکټر ابراهیم خاکسار** لخوا جوړ شوی
تاریخ: November 28, 2025

---

## 📋 Table of Contents
1. [Firebase Setup](#1-firebase-setup)
2. [AdMob Setup](#2-admob-setup)
3. [TWA (Trusted Web Activity) Setup](#3-twa-setup)
4. [Digital Asset Links](#4-digital-asset-links)
5. [Build & Deploy](#5-build--deploy)
6. [Play Store Submission](#6-play-store-submission)

---

## 🔥 1. Firebase Setup

### Step 1.1: د Firebase Project جوړول

1. **Firebase Console** ته لاړشئ: https://console.firebase.google.com
2. **"Add project"** کلیک کړئ
3. د Project نوم: **`healmate-afghanistan`**
4. Google Analytics فعال کړئ
5. Continue کلیک کړئ

### Step 1.2: د Android App اضافه کول

1. د Firebase console کې **"Add app"** > **Android** غوره کړئ
2. **Android package name**: `com.drkhaksar.healmate`
3. **App nickname**: `HealMate`
4. **Debug signing certificate SHA-1** اضافه کړئ:

```bash
# د SHA-1 ترلاسه کولو لپاره (Windows)
keytool -list -v -keystore "%USERPROFILE%\.android\debug.keystore" -alias androiddebugkey -storepass android -keypass android

# د SHA-1 ترلاسه کولو لپاره (Mac/Linux)
keytool -list -v -keystore ~/.android/debug.keystore -alias androiddebugkey -storepass android -keypass android
```

5. **"Register app"** کلیک کړئ
6. **`google-services.json`** فایل ډاونلوډ کړئ
7. دا فایل په `/android/app/` folder کې کاپي کړئ

### Step 1.3: د Firebase Services فعالول

Firebase Console کې:

#### Authentication:
1. **Authentication** > **Sign-in method** ته لاړشئ
2. دې methods فعال کړئ:
   - ✅ Email/Password
   - ✅ Google Sign-In
   - ✅ Phone (د افغانستان لپاره)

#### Firestore Database:
1. **Firestore Database** ته لاړشئ
2. **Create database** کلیک کړئ
3. **Start in production mode** غوره کړئ
4. Location: **asia-south1** (India - د افغانستان لپاره نږدې)

#### Cloud Storage:
1. **Storage** ته لاړشئ
2. **Get started** کلیک کړئ
3. Default rules غوره کړئ

#### Cloud Messaging (FCM):
1. **Cloud Messaging** ته لاړشئ
2. **Server key** کاپي کړئ (د push notifications لپاره)

### Step 1.4: د Firebase Config فایل تازه کول

په `/firebase-config.ts` فایل کې خپل Firebase معلومات اضافه کړئ:

```typescript
export const firebaseConfig = {
  apiKey: "AIzaSyXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX",
  authDomain: "healmate-afghanistan.firebaseapp.com",
  projectId: "healmate-afghanistan",
  storageBucket: "healmate-afghanistan.appspot.com",
  messagingSenderId: "123456789012",
  appId: "1:123456789012:android:abcdef1234567890",
  measurementId: "G-XXXXXXXXXX"
};
```

---

## 💰 2. AdMob Setup

### Step 2.1: د AdMob Account جوړول

1. **AdMob Console** ته لاړشئ: https://admob.google.com
2. **Get Started** کلیک کړئ
3. د Google account سره sign in کړئ
4. د AdMob terms قبول کړئ

### Step 2.2: د App Registration

1. **Apps** > **Add App** کلیک کړئ
2. **"No"** غوره کړئ (هالې Play Store کې نشته)
3. Platform: **Android**
4. App name: **HealMate**
5. د Firebase سره link کړئ

### Step 2.3: د Ad Units جوړول

#### Banner Ad:
1. **Ad units** > **Add ad unit** > **Banner** غوره کړئ
2. Ad unit name: `HealMate_Banner_Home`
3. **Create ad unit** کلیک کړئ
4. **Ad unit ID** کاپي کړئ

#### Interstitial Ad:
1. **Add ad unit** > **Interstitial** غوره کړئ
2. Ad unit name: `HealMate_Interstitial_General`
3. **Create ad unit** کلیک کړئ
4. **Ad unit ID** کاپي کړئ

#### Rewarded Ad:
1. **Add ad unit** > **Rewarded** غوره کړئ
2. Ad unit name: `HealMate_Rewarded_Premium`
3. Reward amount: `10 points`
4. **Create ad unit** کلیک کړئ
5. **Ad unit ID** کاپي کړئ

### Step 2.4: د AdMob Config تازه کول

په `/firebase-config.ts` کې:

```typescript
export const adMobConfig = {
  androidAppId: "ca-app-pub-1234567890123456~1234567890", // د AdMob App ID
  bannerAdId: "ca-app-pub-1234567890123456/1234567890",
  interstitialAdId: "ca-app-pub-1234567890123456/0987654321",
  rewardedAdId: "ca-app-pub-1234567890123456/1122334455",
  testMode: false, // د production لپاره false کړئ
};
```

په `AndroidManifest.xml` کې:

```xml
<meta-data
    android:name="com.google.android.gms.ads.APPLICATION_ID"
    android:value="ca-app-pub-1234567890123456~1234567890" />
```

### Step 2.5: د Test Ads

د test کولو لپاره دا IDs کاروئ:
- Banner: `ca-app-pub-3940256099942544/6300978111`
- Interstitial: `ca-app-pub-3940256099942544/1033173712`
- Rewarded: `ca-app-pub-3940256099942544/5224354917`

---

## 🌐 3. TWA (Trusted Web Activity) Setup

### Step 3.1: د Domain Setup

1. خپل domain جوړ کړئ (مثلاً: `healmate-af.com`)
2. PWA deploy کړئ په domain کې
3. SSL certificate install کړئ (HTTPS اړین دی)

### Step 3.2: د Bubblewrap Installation

```bash
# Node.js install کړئ که نه وي
# بیا Bubblewrap install کړئ
npm install -g @bubblewrap/cli

# یا دا طریقه:
npx @bubblewrap/cli --version
```

### Step 3.3: د TWA Project Initialize کول

```bash
# د project directory ته لاړشئ
cd healmate

# Bubblewrap initialize کړئ
npx @bubblewrap/cli init --manifest https://YOUR_DOMAIN.com/manifest.json

# د prompts ځوابونه:
# - Domain: YOUR_DOMAIN.com
# - Package name: com.drkhaksar.healmate
# - App name: HealMate
# - Icon: د PWA manifest څخه automatically نیسي
```

### Step 3.4: د TWA Configuration

په `/android/app/build.gradle` کې:

```gradle
manifestPlaceholders = [
    hostName: "YOUR_DOMAIN.com",
    defaultUrl: "https://YOUR_DOMAIN.com",
    launchUrl: "/"
]
```

په `AndroidManifest.xml` کې:

```xml
<meta-data
    android:name="android.support.customtabs.trusted.DEFAULT_URL"
    android:value="https://YOUR_DOMAIN.com" />
```

---

## 🔐 4. Digital Asset Links

### Step 4.1: د SHA-256 Fingerprint ترلاسه کول

```bash
# د Debug keystore لپاره
keytool -list -v -keystore ~/.android/debug.keystore -alias androiddebugkey -storepass android -keypass android | grep SHA256

# د Release keystore لپاره (وروسته جوړوو)
keytool -list -v -keystore healmate-release.keystore -alias healmate | grep SHA256
```

### Step 4.2: د assetlinks.json فایل جوړول

په خپل website کې دا فایل جوړ کړئ:
`https://YOUR_DOMAIN.com/.well-known/assetlinks.json`

```json
[{
  "relation": ["delegate_permission/common.handle_all_urls"],
  "target": {
    "namespace": "android_app",
    "package_name": "com.drkhaksar.healmate",
    "sha256_cert_fingerprints": [
      "YOUR_SHA256_FINGERPRINT_HERE"
    ]
  }
}]
```

### Step 4.3: د Asset Links تصدیق کول

دا tool د verification لپاره کاروئ:
https://developers.google.com/digital-asset-links/tools/generator

---

## 🔨 5. Build & Deploy

### Step 5.1: د Release Keystore جوړول

```bash
# د keystore جوړول
keytool -genkey -v -keystore healmate-release.keystore -alias healmate -keyalg RSA -keysize 2048 -validity 10000

# معلومات ورکړئ:
# - Password: یو قوي پاسورډ
# - Name: Dr. Ibrahim Khaksar
# - Organization: HealMate
# - City: Kabul
# - Province: Kabul
# - Country: AF
```

### Step 5.2: د Gradle Properties Setup

د `/android/gradle.properties` فایل جوړ کړئ:

```properties
HEALMATE_RELEASE_STORE_FILE=healmate-release.keystore
HEALMATE_RELEASE_STORE_PASSWORD=YOUR_KEYSTORE_PASSWORD
HEALMATE_RELEASE_KEY_ALIAS=healmate
HEALMATE_RELEASE_KEY_PASSWORD=YOUR_KEY_PASSWORD

# یا د environment variables کاروئ د security لپاره
# HEALMATE_RELEASE_STORE_PASSWORD=
# HEALMATE_RELEASE_KEY_PASSWORD=
```

⚠️ **Important**: د `.gitignore` فایل کې دا اضافه کړئ:
```
*.keystore
gradle.properties
google-services.json
```

### Step 5.3: د Debug Build

```bash
cd android
./gradlew assembleDebug

# APK ځای: android/app/build/outputs/apk/debug/app-debug.apk
```

### Step 5.4: د Release Build

```bash
cd android
./gradlew assembleRelease

# APK ځای: android/app/build/outputs/apk/release/app-release.apk
```

### Step 5.5: د AAB (Android App Bundle) جوړول

```bash
cd android
./gradlew bundleRelease

# AAB ځای: android/app/build/outputs/bundle/release/app-release.aab
```

---

## 🏪 6. Play Store Submission

### Step 6.1: د Play Console Setup

1. **Google Play Console** ته لاړشئ: https://play.google.com/console
2. **Create app** کلیک کړئ
3. App details:
   - **App name**: HealMate - Afghanistan Health App
   - **Default language**: پښتو (Pashto)
   - **App or game**: App
   - **Free or paid**: Free

### Step 6.2: د Store Listing

#### App Details:
- **Short description** (80 characters):
```
د افغانستان بشپړ روغتیایي اپلیکیشن - ډاکټران، روغتونونه، درمل، او نور
```

- **Full description** (4000 characters):
```
🏥 HealMate - د افغانستان لپاره بشپړ روغتیایي اپلیکیشن

HealMate د افغانستان خلکو لپاره یو بشپړ، وړیا، او حرفه‌ای روغتیایي اپلیکیشن دی چې په پښتو، دری، او انګلیسي ژبو کې شته دی.

📋 اهم فیچرونه:
✅ د ډاکټرانو مکمل ډایرکټري د تخصصونو سره
✅ د روغتونونو او کلینیکونو معلومات
✅ د درملو بشپړ معلومات او لارښوونه
✅ د لومړنۍ مرستې لارښوونې
✅ د روغتیا ټپونه او نصیحتونه
✅ د خوراکي توکو لارښوود
✅ د بیړني حالت SOS سیسټم
✅ AI روغتیایي چیټ بوټ
✅ BMI Calculator او Symptoms Checker
✅ د درملو یادونې (Reminders)
✅ د وخت ټاکلو سیسټم
✅ د روغتیا Tracker

🌍 د افغانستان لپاره:
• په درېو ژبو: پښتو، دری، او انګلیسي
• د افغانستان روغتونونه او ډاکټران
• د افغانستان روغتیایي سیسټم سره موافق
• د بې انټرنیټ کار کولو وړتیا

👨‍⚕️ د ډاکټر ابراهیم خاکسار لخوا جوړ شوی
📧 ibrahimkhaksar.it@gmail.com
📞 +93 779 494 512

HealMate د افغانستان خلکو ته د روغتیایي معلوماتو او خدماتو اسانه لاسرسي ورکوي.
```

#### Graphics:
- **App icon**: 512 x 512 px (PNG, 32-bit)
- **Feature graphic**: 1024 x 500 px
- **Screenshots**: کمز کم 2 (د Phone او Tablet لپاره)
  - Phone: 16:9 ratio
  - 7-inch Tablet: 16:9 ratio
  - 10-inch Tablet: 16:9 ratio

### Step 6.3: د App Content

1. **Privacy Policy**: خپل privacy policy URL اضافه کړئ
2. **App access**: د HealMate لپاره special access ته اړتیا نشته
3. **Ads**: ✅ "Yes, my app contains ads" غوره کړئ
4. **Target audience**: 
   - Age: 18+
   - Content rating: PEGI 3, ESRB Everyone

### Step 6.4: د Release Setup

#### Internal Testing:
1. **Testing** > **Internal testing** ته لاړشئ
2. **Create new release** کلیک کړئ
3. **App bundle** upload کړئ (`app-release.aab`)
4. Release notes ولیکئ
5. **Save** > **Review release** > **Start rollout**

#### Closed Testing:
1. د Internal testing وروسته
2. **Testing** > **Closed testing** ته لاړشئ
3. Testers اضافه کړئ
4. د feedback انتظار وکړئ

#### Production:
1. د Closed testing وروسته
2. **Production** > **Create new release**
3. **App bundle** upload کړئ
4. **Countries**: Afghanistan, Pakistan, India (د لومړي لپاره)
5. **Review** > **Start rollout to production**

### Step 6.5: د Review Process

Google Play د review لپاره معمولاً **3-7 ورځې** وخت نیسي.

د Review Checklist:
- ✅ د App بشپړ کار کوي
- ✅ Privacy policy شته
- ✅ د Content rating بشپړ دی
- ✅ Screenshots واضح دي
- ✅ د Store listing بشپړ دی
- ✅ د Firebase او AdMob صحیح configure شوي دي

---

## 🚀 Quick Start Commands

```bash
# 1. د Dependencies install کول
npm install

# 2. د PWA build کول
npm run build

# 3. د Android folder ته لاړشئ
cd android

# 4. د Debug build جوړول
./gradlew assembleDebug

# 5. د Release AAB جوړول
./gradlew bundleRelease

# 6. د APK install کول په device کې
adb install app/build/outputs/apk/debug/app-debug.apk
```

---

## 📞 د مرستې لپاره

که چیرې مسله وي:
- 📧 Email: ibrahimkhaksar.it@gmail.com
- 📱 WhatsApp: +93 779 494 512
- 💳 Hesab Pay: +93 779 494 512

د **ډاکټر ابراهیم خاکسار** لخوا جوړ شوی ❤️
HealMate - د افغانستان بشپړ روغتیایي اپلیکیشن

---

## 🔄 Updates و Maintenance

### د App Update کول:
1. د `versionCode` او `versionName` په `build.gradle` کې زیات کړئ
2. نوی AAB جوړ کړئ
3. په Play Console کې upload کړئ
4. Release notes ولیکئ
5. Rollout start کړئ

### د Firebase Rules Update:
Firebase Console > Firestore > Rules:
```javascript
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /{document=**} {
      allow read, write: if request.auth != null;
    }
  }
}
```

**بریالیتوب مبارک! 🎉**
