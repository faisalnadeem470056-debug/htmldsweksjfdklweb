# ⚡ د Performance مسلې حل | Performance Fix Guide

---

## 🚨 د مسلې تشخیص | Problem Diagnosis

که ستاسو HealMate اپلیکیشن ډیر وخت loading کیږي یا نه خلاصیږي، دا لارښودونه تعقیب کړئ:

---

## ✅ د سمون ګامونه | Fix Steps

### 1️⃣ د Internet Connection چیک کړئ

```bash
✅ WiFi/Mobile Data فعال دی؟
✅ Internet speed کافي دی؟
✅ Firewall block نه کوي؟
```

---

### 2️⃣ د Firebase Configuration چیک کړئ

د `/config/firebase-config.ts` فایل وګورئ:

```typescript
const firebaseConfig = {
  apiKey: "AIzaSyBkDMJS_zDxPuCxTfWUhY7SdUEFrQpJj9A",
  authDomain: "healmate-61286.firebaseapp.com",
  projectId: "healmate-61286",
  storageBucket: "healmate-61286.firebasestorage.app",
  messagingSenderId: "448955046370",
  appId: "1:448955046370:android:1956e0ac118c587cc141bb"
};
```

**چیک کړئ:**
- ✅ ټول values سم دي؟
- ✅ د Firebase Console سره match کوي؟

---

### 3️⃣ د Firebase Authentication فعال کړئ

د Firebase Console کې:

1. **Authentication** → **Sign-in method** ته لاړ شئ
2. **Email/Password** فعال کړئ
3. Save کلیک کړئ

---

### 4️⃣ د Firestore Rules تنظیم کړئ

د Firebase Console کې → **Firestore Database** → **Rules**:

```javascript
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    // د ټولو لپاره read access
    match /{document=**} {
      allow read: if true;
      allow write: if request.auth != null;
    }
    
    // د admins لپاره
    match /admins/{adminId} {
      allow read, write: if request.auth != null && 
        request.auth.token.email == "ibrahimkhaksar.it@gmail.com";
    }
  }
}
```

---

### 5️⃣ Browser Cache Clear کړئ

```bash
# Chrome/Edge:
Ctrl + Shift + Delete

# Firefox:
Ctrl + Shift + Del

# Safari:
Cmd + Option + E
```

یا Incognito/Private mode کې هڅه وکړئ.

---

### 6️⃣ د Performance Optimizations

زموږ د اپلیکیشن کې دا optimizations شامل دي:

#### ✅ د Loading Timeout (3 ثانیې)
که Firebase 3 ثانیو کې respond نه کړي، اپلیکیشن به په هر حال خلاص شي.

#### ✅ Lazy Loading
ټول components د ضرورت په وخت load کیږي.

#### ✅ Optimized Firestore
د persistent cache استعمال د ګړندي لاسرسي لپاره.

#### ✅ Background Operations
د user document جوړول په background کې.

#### ✅ Error Handling
که یوه برخه کار نه کوي، نور برخې به کار کوي.

---

## 🔍 د PerformanceMonitor استعمال

موږ یو PerformanceMonitor component جوړ کړی چې د development پرمهال ښکاره کیږي:

```typescript
// د App.tsx کې:
{import.meta.env.DEV && <PerformanceMonitor />}
```

دا به تاسو ته ښکاره کړي:
- 🌐 Network Status (Online/Offline)
- 🔥 Firebase Connection
- 💾 Firestore Status
- 🔐 Authentication Status
- ⏱️ Load Time

---

## 🐛 د عام مسلو حل | Common Issues

### ❌ "Network Error"
```bash
✅ Internet connection چیک کړئ
✅ Firewall settings وګورئ
✅ VPN بند کړئ او بیا هڅه وکړئ
```

### ❌ "Firebase Configuration Error"
```bash
✅ firebase-config.ts چیک کړئ
✅ Firebase Console verification
✅ د API keys سم ولیکئ
```

### ❌ "Authentication Timeout"
```bash
✅ Firebase Authentication فعال کړئ
✅ Email/Password provider enable کړئ
✅ د 3 ثانیو وروسته به automatic خلاص شي
```

### ❌ "Firestore Permission Denied"
```bash
✅ Firestore Rules چیک کړئ
✅ د read access ټولو ته ورکړئ
✅ د write access یوازې authenticated users ته
```

---

## ⚡ Quick Performance Tips

### 1. د Production Build کاروئ
```bash
npm run build
# یا
vite build
```

### 2. د CDN Images استعمال کړئ
د Unsplash یا نورو CDN services څخه.

### 3. د Lazy Loading استعمال
موږ د ټولو components لپاره lazy loading استعمالوو.

### 4. د Service Worker استعمال
د PWA لپاره offline support.

---

## 📊 د Performance Benchmarks

### ✅ ښه Performance:
```
- Load Time: < 2 seconds
- Firebase Connection: < 1 second
- First Paint: < 1 second
- Interactive: < 2 seconds
```

### ⚠️ منځنۍ Performance:
```
- Load Time: 2-5 seconds
- Firebase Connection: 1-3 seconds
- First Paint: 1-2 seconds
- Interactive: 2-4 seconds
```

### ❌ خراب Performance:
```
- Load Time: > 5 seconds
- Firebase Connection: > 3 seconds
- First Paint: > 2 seconds
- Interactive: > 4 seconds
```

---

## 🔧 د Advanced Debugging

### د Browser Console وګورئ (F12):

```javascript
// دا پیغامونه وګورئ:
✅ "HealMate initialized - Firebase Authentication Active"
✅ "Firebase Project: healmate-61286"
✅ "Firebase Analytics initialized" (optional)

// که خطا وي:
❌ "Authentication timeout"
❌ "Firebase initialization error"
❌ "Firestore permission denied"
```

### د Network Tab چیک کړئ:

```bash
F12 → Network Tab → Reload Page

وګورئ:
✅ Firebase requests سبز (200) دي
❌ که سور (403/404/500) دي، نو مسله شته
```

---

## 🆘 د نورو مرستو لپاره

### 📞 د اړیکې معلومات:
- 📧 Email: ibrahimkhaksar.it@gmail.com
- 📱 Phone 1: +93783040441
- 📱 Phone 2: +93779494512

### 📖 نور لارښودونه:
- `FIREBASE_SETUP_GUIDE.md` - د Firebase بشپړ تنظیم
- `FIREBASE_TROUBLESHOOTING.md` - د Firebase مسلې
- `README.md` - عمومي معلومات

---

## ✨ د سمون وروسته

که تاسو د پورتنیو ګامونو تعقیب وکړ:

1. ✅ Browser refresh کړئ (Ctrl+F5)
2. ✅ د PerformanceMonitor وګورئ (د development کې)
3. ✅ که ټول سبز وي، اپلیکیشن چمتو دی!
4. ✅ که بیا هم مسله وي، cache clear کړئ او بیا هڅه وکړئ

---

## 🎯 Final Checklist

د ګړندي اپلیکیشن لپاره:

- [ ] ✅ Internet connection ښه کار کوي
- [ ] ✅ Firebase configuration سم دی
- [ ] ✅ Firebase Authentication فعال دی
- [ ] ✅ Firestore rules سم تنظیم شوي
- [ ] ✅ Browser cache clear شوی
- [ ] ✅ Production build استعمالیږي
- [ ] ✅ PerformanceMonitor ټول سبز ښکاروي

---

**🚀 ستاسو HealMate اوس تیز او ګړندی کار کوي!**

که بیا هم مسله وي، مهرباني وکړئ له موږ سره اړیکه ونیسئ.
