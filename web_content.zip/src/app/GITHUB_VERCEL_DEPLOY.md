# 🚀 د GitHub او Vercel سره Deployment
# Deployment with GitHub and Vercel

## د راتلونکي automatic deployments لپاره

---

## ګام 1: GitHub Account جوړ کړئ

1. 🌐 https://github.com ته ورشئ
2. "Sign up" کلیک وکړئ
3. د خپل معلومات داخل کړئ:
   - Email: ibrahimkhaksar.it@gmail.com
   - Password: یو قوي password
   - Username: د خپل غوره username

---

## ګام 2: نوی Repository جوړ کړئ

1. GitHub ته login کړئ
2. ➕ "New repository" کلیک وکړئ (د پورتنۍ ښي لوري کې)
3. Repository معلومات:

```
Repository name: healmate-app
Description: Afghanistan's Health App - HealMate
Public ☑️ (یا Private)
Initialize this repository: نه ✖️
```

4. "Create repository" کلیک وکړئ

---

## ګام 3: د Git Install کول

### Windows:
1. https://git-scm.com/download/win ته ورشئ
2. Installer download کړئ
3. Install کړئ (ټول defaults OK دي)

### Mac:
```bash
# Terminal کې:
brew install git

# یا:
xcode-select --install
```

### Linux:
```bash
sudo apt install git
```

---

## ګام 4: د Project ته Git Setup کړئ

د terminal/CMD کې د project folder ته ورشئ:

```bash
# 1. د project folder ته ورشئ
cd /path/to/healmate-app

# 2. Git initialize کړئ
git init

# 3. ټول files add کړئ
git add .

# 4. د لومړي commit جوړ کړئ
git commit -m "Initial commit - HealMate App"

# 5. Main branch جوړ کړئ
git branch -M main

# 6. د GitHub سره connect کړئ
# (دا URL د GitHub repository page څخه copy کړئ)
git remote add origin https://github.com/YOUR_USERNAME/healmate-app.git

# 7. Push کړئ!
git push -u origin main
```

### د Username/Password لپاره:

که Git ستاسو GitHub credentials غواړي:

**Username:** ستاسو GitHub username  
**Password:** ستاسو GitHub password نه - Personal Access Token!

#### د Personal Access Token جوړول:

1. GitHub → Settings → Developer settings
2. Personal access tokens → Tokens (classic)
3. "Generate new token (classic)"
4. Select scopes: `repo` ✅
5. Generate token
6. **Token copy کړئ** (دا یوازې یو ځل ښکاري!)
7. د password پر ځای دا token وکاروئ

---

## ګام 5: Vercel سره Connect کړئ

### Option A: Vercel Website

1. 🌐 https://vercel.com ته ورشئ
2. "Sign Up" → "Continue with GitHub"
3. GitHub authorize کړئ
4. ➕ "Add New Project"
5. "Import Git Repository"
6. د خپل repository غوره کړئ: `healmate-app`
7. Settings:

```
Framework Preset: Vite
Build Command: npm run build
Output Directory: dist
Install Command: npm install
```

8. "Deploy" کلیک وکړئ
9. ✅ Done!

### Option B: Vercel CLI

```bash
# د project folder کې:
vercel login
vercel --prod

# Vercel به اوتومات GitHub detect کړي
```

---

## ګام 6: Automatic Deployments! 🎉

اوس هر ځل چې تاسو code بدل کړئ:

```bash
# 1. Changes وکړئ
# 2. بیا:

git add .
git commit -m "Updated features"
git push origin main

# ✅ Vercel به اوتومات deploy کړي!
```

د هر commit لپاره نوی deployment!

---

## 🔄 د Updates Workflow

```
1. Code بدل کړئ
   ↓
2. git add .
   ↓
3. git commit -m "message"
   ↓
4. git push origin main
   ↓
5. Vercel اوتومات deploy کوي
   ↓
6. ✅ Live په 2 دقیقو کې!
```

---

## 📊 د Vercel Dashboard

https://vercel.com/dashboard

دلته تاسو وینئ:
- 📈 د Deployments history
- 🔄 Auto deployments د GitHub څخه
- 📊 Analytics
- ⚙️ Settings
- 🌐 Custom domains

---

## 🐛 Common Issues:

### "Authentication failed"
```bash
# Personal Access Token وکاروئ
# نه ستاسو GitHub password
```

### "Permission denied"
```bash
# SSH key setup (اختیاري خو ښه):
ssh-keygen -t rsa -b 4096 -C "ibrahimkhaksar.it@gmail.com"
# Public key GitHub ته اضافه کړئ:
# GitHub → Settings → SSH Keys → New SSH key
```

### "Repository not found"
```bash
# د URL check کړئ:
git remote -v

# که غلط وي، سم یې کړئ:
git remote set-url origin https://github.com/YOUR_USERNAME/healmate-app.git
```

---

## 💡 Pro Tips:

### 1. د .gitignore کارول:

موږ لا دمخه `.gitignore` جوړ کړی - دا به هغه files ignore کړي چې GitHub ته نه باید ورشي:

```
node_modules/
dist/
.env
.vercel/
```

### 2. د Branches کارول:

```bash
# د نوې feature لپاره:
git checkout -b feature/new-feature

# کله چې بشپړ شي:
git checkout main
git merge feature/new-feature
git push origin main
```

### 3. د GitHub Issues:

د خپل bugs او features track کړئ:
- GitHub Repository → Issues → New Issue

### 4. د GitHub Actions (Advanced):

د Automated testing او building لپاره `.github/workflows/` کاروئ

---

## ✅ Success Checklist:

- [ ] GitHub account جوړ شو
- [ ] Repository جوړ شو
- [ ] Git installed شو
- [ ] Code GitHub ته push شو
- [ ] Vercel سره connected شو
- [ ] Automatic deployment test شو
- [ ] URL ترلاسه شو

---

## 🎊 بریا!

**ستاسو app اوس GitHub او Vercel باندې Live دی!**

### د راتلونکي Updates لپاره:

```bash
# 1. Code بدل کړئ
git add .
git commit -m "Updated XYZ"
git push origin main

# 2. Vercel اوتومات deploy کوي
# 3. ✅ Live په 2 دقیقو کې!
```

---

## 🌐 ستاسو URLs:

```
GitHub: https://github.com/YOUR_USERNAME/healmate-app
Vercel: https://healmate-app.vercel.app
```

---

## 📞 د مرستې لپاره:

- 📧 Email: ibrahimkhaksar.it@gmail.com
- 📱 Phone: +93 783 040 441
- 📚 GitHub Docs: https://docs.github.com
- 📚 Vercel Docs: https://vercel.com/docs

---

**اوس تاسو professional development workflow لرئ! 🚀**
