# HealMate Admin Panel Guide
# د HealMate Admin Panel رهنمایی

## 🔐 Admin Panel Access (د Admin Panel لاسرسی)

### Owner Email (د Owner ایمیل)
یوازې دا ایمیل د Admin Panel لاسرسی لري:
```
ibrahimkhaksar.it@gmail.com
```

### د Admin Panel ته لاسرسی (Accessing Admin Panel)

#### 1. د Admin Account جوړول (Creating Admin Account)

که تاسو لومړی ځل دی چې Admin Panel ته لاسرسی کوئ، باید لومړی یو حساب جوړ کړئ:

1. د Settings صفحې ته لاړ شئ
2. د "Admin Panel" کارډ ته کلیک وکړئ (یوازې owner email ته ښکاري)
3. د "Create account" بټن ته کلیک وکړئ
4. خپل ایمیل او پاسورډ ولیکئ:
   - **ایمیل**: `ibrahimkhaksar.it@gmail.com` (باید بالکل همدا وي)
   - **پاسورډ**: خپل مضبوط پاسورډ غوره کړئ (لږ تر لږه 6 حروف)
   - **د پاسورډ تایید**: همدا پاسورډ بیا ولیکئ
5. د "Sign Up" بټن ته کلیک وکړئ

#### 2. Login کول (Logging In)

که تاسو مخکې حساب جوړ کړی وي:

1. د Settings صفحې ته لاړ شئ
2. د "Admin Panel" کارډ ته کلیک وکړئ
3. خپل ایمیل او پاسورډ ولیکئ
4. د "Login" بټن ته کلیک وکړئ

#### 3. که پاسورډ مو هیر شوی (Forgot Password)

که پاسورډ مو هیر شوی:

1. د Login صفحې کې د "Forgot password?" لینک ته کلیک وکړئ
2. خپل ایمیل ولیکئ (`ibrahimkhaksar.it@gmail.com`)
3. د "Send Link" بټن ته کلیک وکړئ
4. خپل ایمیل چیک کړئ - موږ به تاسو ته د پاسورډ بیا تنظیم کولو لینک واستوو
5. د لینک په مټ خپل نوی پاسورډ تنظیم کړئ

---

## 📱 Admin Panel Features (د Admin Panel ځانګړتیاوې)

### 1. Dashboard (ډشبورډ)
- د کاروونکو ټول شمیر
- د ډاکټرانو ټول شمیر  
- د درملو ټول شمیر
- د عایداتو ټوله اندازه

### 2. Admins Tab (د ایډمینانو Tab)
- د ټولو admin کاروونکو لیست
- نوی admin اضافه کړئ
- د admin حالت بدل کړئ (فعال/بند)
- د admin پاسورډ بیا تنظیم کړئ
- Admin حذف کړئ

### 3. Users Tab (د کاروونکو Tab)
- د ټولو کاروونکو لیست
- د کاروونکو معلومات وګورئ
- کاروونکی ترمیم یا حذف کړئ

### 4. Doctors Tab (د ډاکټرانو Tab)
- د ټولو ډاکټرانو لیست
- نوی ډاکټر اضافه کړئ
- د ډاکټر معلومات ترمیم کړئ
- ډاکټر حذف کړئ

### 5. Medicines Tab (د درملو Tab)
- د ټولو درملو لیست
- نوی درمل اضافه کړئ
- د درمل معلومات ترمیم کړئ
- درمل حذف کړئ

### 6. **AdMob Tab (د AdMob Tab)** ⭐ نوی
د Google AdMob تنظیمات اداره کړئ:

#### General Settings (عمومي تنظیمات)
- **Enable AdMob**: د اعلاناتو ښودل فعال یا غیر فعال کړئ
- **Test Mode**: د Google test IDs استعمال کړئ (د development لپاره)
- **Daily View Limit**: په 24 ساعتونو کې د ads حد اکثر شمیر

#### Android AdMob IDs
- App ID
- Banner ID
- Interstitial ID
- Rewarded ID

#### iOS AdMob IDs
- App ID
- Banner ID
- Interstitial ID
- Rewarded ID

#### د AdMob IDs بدلول (Editing AdMob IDs)

1. د Admin Panel کې د "AdMob" tab ته لاړ شئ
2. د Android او iOS IDs ترتیب کړئ
3. خپل IDs په دې فارمیټ کې ولیکئ: `ca-app-pub-XXXXXXXXXXXXXXXX/XXXXXXXXXX`
4. د "Save All Settings" بټن ته کلیک وکړئ

**یادونه**: 
- په Production کې د Google test IDs مه کاروئ!
- د خپلو اصلي AdMob IDs استعمال وکړئ
- د Google AdMob Console څخه خپل IDs ترلاسه کړئ

### 7. Settings Tab (د تنظیماتو Tab)
- خپل پاسورډ بدل کړئ
- خپل ایمیل بدل کړئ
- د Admin معلومات وګورئ

---

## 🔒 Security Features (د امنیت ځانګړتیاوې)

### Owner-Only Access (یوازې د Owner لاسرسی)
- یوازې د `ibrahimkhaksar.it@gmail.com` ایمیل Admin Panel ته لاسرسی لري
- نور هیڅوک Admin Panel نه شي لیدلای
- د Settings کې د Admin Panel کارډ یوازې owner ته ښکاري

### Firebase Authentication Integration
- ټول admins د Firebase Authentication سره ذخیره کیږي
- مضبوط پاسورډ په اړتیا ده (لږ تر لږه 6 حروف)
- د پاسورډ بیا تنظیم کولو امکان د ایمیل له لارې

### Data Protection
- ټول admin data د Firebase Firestore کې په امن ډول ذخیره کیږي
- د ایمیل verification د Firebase لخوا
- Session management د Firebase Auth لخوا

---

## 📞 Contact Information (د اړیکې معلومات)

که ستونزه مخ ته شي، موږ سره اړیکه ونیسئ:
- 📧 Email: ibrahimkhaksar.it@gmail.com
- 📱 Phone: +93783040441
- 📱 Phone: +93779494512

---

## 🚀 Quick Start (چټک پیل)

### د لومړي ځل لپاره:

1. د HealMate اپلیکیشن خلاص کړئ
2. د owner email سره Login وکړئ (`ibrahimkhaksar.it@gmail.com`)
3. Settings ته لاړ شئ
4. د "Admin Panel" کارډ ته کلیک وکړئ
5. "Create account" غوره کړئ
6. خپل admin حساب جوړ کړئ
7. Login وکړئ او د Admin Panel استعمال یې پیل کړئ!

### د AdMob IDs تنظیمول:

1. Admin Panel ته Login وکړئ
2. د "AdMob" tab ته لاړ شئ
3. د Android او iOS IDs ولیکئ
4. د "Test Mode" switch فعال کړئ (د development لپاره)
5. "Save All Settings" کلیک وکړئ
6. بس! ستاسو AdMob IDs اوس فعال دي

---

## ⚠️ Important Notes (مهم یادونې)

1. **د Owner Email بدلول نه شي کیدی** - دا hardcoded دی د امنیت لپاره
2. **د Production لپاره Test IDs مه کاروئ** - خپل اصلي AdMob IDs استعمال کړئ
3. **خپل پاسورډ خوندي وساتئ** - هیڅ چا سره یې شریک مه کوئ
4. **په منظم ډول Backup واخلئ** - د Firebase Console څخه
5. **د AdMob Settings تازه کړئ** - کله چې تاسو نوي IDs ترلاسه کړئ

---

## 📚 Related Documentation

- [FIREBASE_SETUP_GUIDE.md](FIREBASE_SETUP_GUIDE.md) - د Firebase تنظیمات
- [ADMOB_SETUP.md](ADMOB_SETUP.md) - د AdMob تنظیمات
- [HOW_TO_USE_ADMIN_PANEL.md](HOW_TO_USE_ADMIN_PANEL.md) - د Admin Panel مفصل رهنمایی

---

**Made with ❤️ for HealMate**
**د HealMate لپاره جوړ شوی 🇦🇫**
