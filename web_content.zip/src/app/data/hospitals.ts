export interface Hospital {
  id: string;
  name: {
    ps: string;
    fa: string;
    en: string;
  };
  type: 'hospital' | 'clinic' | 'health_center';
  province: string;
  district: string;
  address: {
    ps: string;
    fa: string;
    en: string;
  };
  location: {
    lat: number;
    lng: number;
  };
  phone: string[];
  email?: string;
  services: string[];
  availability: '24/7' | 'day' | 'limited';
  isGovernment: boolean;
  beds?: number;
  doctors?: number;
  established?: number;
  image?: string;
}

export const afghanistanHospitals: Hospital[] = [
  // ولایت کابل (Kabul Province)
  {
    id: 'KBL001',
    name: {
      ps: 'جمهوری روغتون',
      fa: 'شفاخانه جمهوری',
      en: 'Jamhuriat Hospital'
    },
    type: 'hospital',
    province: 'کابل',
    district: 'ناحیه اول',
    address: {
      ps: 'د کابل ښار، د شیرپور سیمه',
      fa: 'شهر کابل، منطقه شیرپور',
      en: 'Kabul City, Shahr-e-Naw Area'
    },
    location: { lat: 34.5328, lng: 69.1717 },
    phone: ['+93 20 2104848', '+93 79 9999999'],
    email: 'info@jamhuriat.gov.af',
    services: ['emergency', 'surgery', 'pediatrics', 'cardiology', 'radiology', 'laboratory'],
    availability: '24/7',
    isGovernment: true,
    beds: 250,
    doctors: 80,
    established: 1972,
    image: 'https://images.unsplash.com/photo-1519494026892-80bbd2d6fd0d?w=800'
  },
  {
    id: 'KBL002',
    name: {
      ps: 'علی آباد روغتون',
      fa: 'شفاخانه علی آباد',
      en: 'Ali Abad Hospital'
    },
    type: 'hospital',
    province: 'کابل',
    district: 'ناحیه دوم',
    address: {
      ps: 'د کابل ښار، علی آباد',
      fa: 'شهر کابل، علی آباد',
      en: 'Kabul City, Ali Abad'
    },
    location: { lat: 34.5553, lng: 69.2075 },
    phone: ['+93 20 2201234'],
    services: ['general', 'surgery', 'pediatrics', 'gynecology', 'emergency'],
    availability: '24/7',
    isGovernment: true,
    beds: 150,
    doctors: 45,
    established: 1985,
    image: 'https://images.unsplash.com/photo-1586773860418-d37222d8fce3?w=800'
  },
  {
    id: 'KBL003',
    name: {
      ps: 'ماشومانو روغتون',
      fa: 'شفاخانه اطفال',
      en: 'Children Hospital'
    },
    type: 'hospital',
    province: 'کابل',
    district: 'ناحیه سوم',
    address: {
      ps: 'د کابل ښار، وزیر اکبر خان',
      fa: 'شهر کابل، وزیر اکبر خان',
      en: 'Kabul City, Wazir Akbar Khan'
    },
    location: { lat: 34.5289, lng: 69.1725 },
    phone: ['+93 20 2301456'],
    services: ['pediatrics', 'neonatology', 'emergency', 'vaccination'],
    availability: '24/7',
    isGovernment: true,
    beds: 120,
    doctors: 35,
    established: 1978,
    image: 'https://images.unsplash.com/photo-1666214280557-f1b5022eb634?w=800'
  },
  {
    id: 'KBL004',
    name: {
      ps: 'خیر خانه روغتیایی مرکز',
      fa: 'مرکز صحی خیرخانه',
      en: 'Khair Khana Health Center'
    },
    type: 'health_center',
    province: 'کابل',
    district: 'خیر خانه',
    address: {
      ps: 'خیر خانه، ناحیه دوم',
      fa: 'خیرخانه، ناحیه دوم',
      en: 'Khair Khana, District 2'
    },
    location: { lat: 34.5667, lng: 69.1833 },
    phone: ['+93 79 1234567'],
    services: ['general', 'vaccination', 'maternal_health', 'pharmacy'],
    availability: 'day',
    isGovernment: true,
    beds: 30,
    doctors: 10,
    established: 2002,
    image: 'https://images.unsplash.com/photo-1504813184591-01572f98c85f?w=800'
  },
  {
    id: 'KBL005',
    name: {
      ps: 'دشت برچی روغتون',
      fa: 'شفاخانه دشت برچی',
      en: 'Dasht-e-Barchi Hospital'
    },
    type: 'hospital',
    province: 'کابل',
    district: 'دشت برچی',
    address: {
      ps: 'دشت برچی، لویه لاره',
      fa: 'دشت برچی، جاده اصلی',
      en: 'Dasht-e-Barchi, Main Road'
    },
    location: { lat: 34.5125, lng: 69.1242 },
    phone: ['+93 20 2401567', '+93 78 8888888'],
    services: ['emergency', 'general', 'surgery', 'obstetrics', 'pediatrics'],
    availability: '24/7',
    isGovernment: true,
    beds: 180,
    doctors: 55,
    established: 2010,
    image: 'https://images.unsplash.com/photo-1587351021759-3e566b6af7cc?w=800'
  },

  // ولایت هرات (Herat Province)
  {
    id: 'HRT001',
    name: {
      ps: 'هرات سیمه ییز روغتون',
      fa: 'شفاخانه ولایتی هرات',
      en: 'Herat Regional Hospital'
    },
    type: 'hospital',
    province: 'هرات',
    district: 'هرات ښار',
    address: {
      ps: 'د هرات ښار مرکز',
      fa: 'مرکز شهر هرات',
      en: 'Herat City Center'
    },
    location: { lat: 34.3482, lng: 62.1997 },
    phone: ['+93 40 222345', '+93 79 2222222'],
    email: 'info@herathos.gov.af',
    services: ['emergency', 'surgery', 'cardiology', 'neurology', 'radiology', 'ICU'],
    availability: '24/7',
    isGovernment: true,
    beds: 300,
    doctors: 95,
    established: 1968,
    image: 'https://images.unsplash.com/photo-1538108149393-fbbd81895907?w=800'
  },
  {
    id: 'HRT002',
    name: {
      ps: 'نسوان او ماشومانو روغتون - هرات',
      fa: 'شفاخانه زنان و اطفال - هرات',
      en: 'Women and Children Hospital - Herat'
    },
    type: 'hospital',
    province: 'هرات',
    district: 'هرات ښار',
    address: {
      ps: 'د هرات ښار، نو شهر',
      fa: 'شهر هرات، شهر نو',
      en: 'Herat City, Shahr-e-Naw'
    },
    location: { lat: 34.3517, lng: 62.2042 },
    phone: ['+93 40 223456'],
    services: ['obstetrics', 'gynecology', 'pediatrics', 'neonatology', 'family_planning'],
    availability: '24/7',
    isGovernment: true,
    beds: 150,
    doctors: 42,
    established: 1995,
    image: 'https://images.unsplash.com/photo-1631815588090-d4bfec5b1ccb?w=800'
  },
  {
    id: 'HRT003',
    name: {
      ps: 'انجیل روغتیایی مرکز',
      fa: 'مرکز صحی انجیل',
      en: 'Injil Health Center'
    },
    type: 'health_center',
    province: 'هرات',
    district: 'انجیل',
    address: {
      ps: 'انجیل ولسوالۍ',
      fa: 'ولسوالی انجیل',
      en: 'Injil District'
    },
    location: { lat: 34.2833, lng: 62.2167 },
    phone: ['+93 79 3333333'],
    services: ['general', 'vaccination', 'maternal_health', 'emergency'],
    availability: 'day',
    isGovernment: true,
    beds: 40,
    doctors: 12,
    established: 2005,
    image: 'https://images.unsplash.com/photo-1512678080530-7760d81faba6?w=800'
  },

  // ولایت قندهار (Kandahar Province)
  {
    id: 'KDH001',
    name: {
      ps: 'میرویس روغتون',
      fa: 'شفاخانه میرویس',
      en: 'Mirwais Hospital'
    },
    type: 'hospital',
    province: 'قندهار',
    district: 'قندهار ښار',
    address: {
      ps: 'د قندهار ښار، مرکز',
      fa: 'شهر قندهار، مرکز',
      en: 'Kandahar City, Center'
    },
    location: { lat: 31.6137, lng: 65.7372 },
    phone: ['+93 30 222567', '+93 70 4444444'],
    email: 'info@mirwais.gov.af',
    services: ['emergency', 'trauma', 'surgery', 'ICU', 'cardiology', 'orthopedics'],
    availability: '24/7',
    isGovernment: true,
    beds: 280,
    doctors: 85,
    established: 1960,
    image: 'https://images.unsplash.com/photo-1596541223130-5d31a73fb6c6?w=800'
  },
  {
    id: 'KDH002',
    name: {
      ps: 'قندهار د ماشومانو روغتون',
      fa: 'شفاخانه اطفال قندهار',
      en: 'Kandahar Children Hospital'
    },
    type: 'hospital',
    province: 'قندهار',
    district: 'قندهار ښار',
    address: {
      ps: 'قندهار ښار، نهم ناحیه',
      fa: 'شهر قندهار، ناحیه نهم',
      en: 'Kandahar City, District 9'
    },
    location: { lat: 31.6289, lng: 65.7153 },
    phone: ['+93 30 223678'],
    services: ['pediatrics', 'neonatology', 'vaccination', 'nutrition'],
    availability: '24/7',
    isGovernment: true,
    beds: 100,
    doctors: 28,
    established: 2000,
    image: 'https://images.unsplash.com/photo-1581594549595-35f6edc7b762?w=800'
  },

  // ولایت مزار شریف (Balkh Province)
  {
    id: 'BLK001',
    name: {
      ps: 'بلخ سیمه ییز روغتون',
      fa: 'شفاخانه ولایتی بلخ',
      en: 'Balkh Regional Hospital'
    },
    type: 'hospital',
    province: 'بلخ',
    district: 'مزار شریف',
    address: {
      ps: 'مزار شریف ښار',
      fa: 'شهر مزار شریف',
      en: 'Mazar-i-Sharif City'
    },
    location: { lat: 36.7008, lng: 67.1100 },
    phone: ['+93 50 222789', '+93 70 5555555'],
    email: 'info@balkhhospital.gov.af',
    services: ['emergency', 'surgery', 'medicine', 'pediatrics', 'gynecology', 'radiology'],
    availability: '24/7',
    isGovernment: true,
    beds: 270,
    doctors: 78,
    established: 1975,
    image: 'https://images.unsplash.com/photo-1563213126-a4273aed2016?w=800'
  },
  {
    id: 'BLK002',
    name: {
      ps: 'د بلخ نسوان روغتون',
      fa: 'شفاخانه زنان بلخ',
      en: 'Balkh Women Hospital'
    },
    type: 'hospital',
    province: 'بلخ',
    district: 'مزار شریف',
    address: {
      ps: 'مزار شریف، نو شهر',
      fa: 'مزار شریف، شهر نو',
      en: 'Mazar-i-Sharif, New City'
    },
    location: { lat: 36.7125, lng: 67.1042 },
    phone: ['+93 50 223890'],
    services: ['obstetrics', 'gynecology', 'family_planning', 'maternal_health'],
    availability: '24/7',
    isGovernment: true,
    beds: 120,
    doctors: 35,
    established: 1998,
    image: 'https://images.unsplash.com/photo-1579684385127-1ef15d508118?w=800'
  },

  // ولایت ننګرهار (Nangarhar Province)
  {
    id: 'NGR001',
    name: {
      ps: 'د ننګرهار سیمه ییز روغتون',
      fa: 'شفاخانه ولایتی ننگرهار',
      en: 'Nangarhar Regional Hospital'
    },
    type: 'hospital',
    province: 'ننګرهار',
    district: 'جلال آباد',
    address: {
      ps: 'جلال آباد ښار',
      fa: 'شهر جلال‌آباد',
      en: 'Jalalabad City'
    },
    location: { lat: 34.4284, lng: 70.4517 },
    phone: ['+93 60 222901', '+93 70 6666666'],
    email: 'info@nangarharhospital.gov.af',
    services: ['emergency', 'surgery', 'internal_medicine', 'trauma', 'ICU'],
    availability: '24/7',
    isGovernment: true,
    beds: 240,
    doctors: 72,
    established: 1970,
    image: 'https://images.unsplash.com/photo-1551190822-a9333d879b1f?w=800'
  },
  {
    id: 'NGR002',
    name: {
      ps: 'جلال آباد د ماشومانو کلینیک',
      fa: 'کلینیک اطفال جلال‌آباد',
      en: 'Jalalabad Children Clinic'
    },
    type: 'clinic',
    province: 'ننګرهار',
    district: 'جلال آباد',
    address: {
      ps: 'جلال آباد، سیمه دوم',
      fa: 'جلال‌آباد، منطقه دوم',
      en: 'Jalalabad, Area 2'
    },
    location: { lat: 34.4350, lng: 70.4583 },
    phone: ['+93 60 223012'],
    services: ['pediatrics', 'vaccination', 'nutrition'],
    availability: 'day',
    isGovernment: true,
    beds: 25,
    doctors: 8,
    established: 2008,
    image: 'https://images.unsplash.com/photo-1519494026892-80bbd2d6fd0d?w=800'
  },

  // ولایت پکتیا (Paktia Province)
  {
    id: 'PKT001',
    name: {
      ps: 'د پکتیا ولایتي روغتون',
      fa: 'شفاخانه ولایتی پکتیا',
      en: 'Paktia Provincial Hospital'
    },
    type: 'hospital',
    province: 'پکتیا',
    district: 'ګردیز',
    address: {
      ps: 'ګردیز ښار',
      fa: 'شهر گردیز',
      en: 'Gardez City'
    },
    location: { lat: 33.5969, lng: 69.2264 },
    phone: ['+93 72 1111111'],
    services: ['emergency', 'general', 'surgery', 'pediatrics'],
    availability: '24/7',
    isGovernment: true,
    beds: 80,
    doctors: 22,
    established: 1995,
    image: 'https://images.unsplash.com/photo-1586773860418-d37222d8fce3?w=800'
  },

  // ولایت غزني (Ghazni Province)
  {
    id: 'GHZ001',
    name: {
      ps: 'د غزني ولایتي روغتون',
      fa: 'شفاخانه ولایتی غزنی',
      en: 'Ghazni Provincial Hospital'
    },
    type: 'hospital',
    province: 'غزني',
    district: 'غزني ښار',
    address: {
      ps: 'غزني ښار مرکز',
      fa: 'مرکز شهر غزنی',
      en: 'Ghazni City Center'
    },
    location: { lat: 33.5539, lng: 68.4172 },
    phone: ['+93 73 2222222'],
    services: ['emergency', 'general', 'surgery', 'internal_medicine'],
    availability: '24/7',
    isGovernment: true,
    beds: 120,
    doctors: 35,
    established: 1988,
    image: 'https://images.unsplash.com/photo-1587351021759-3e566b6af7cc?w=800'
  },

  // ولایت بامیان (Bamyan Province)
  {
    id: 'BMN001',
    name: {
      ps: 'د بامیانو ولایتي روغتون',
      fa: 'شفاخانه ولایتی بامیان',
      en: 'Bamyan Provincial Hospital'
    },
    type: 'hospital',
    province: 'بامیان',
    district: 'بامیان ښار',
    address: {
      ps: 'بامیان ښار',
      fa: 'شهر بامیان',
      en: 'Bamyan City'
    },
    location: { lat: 34.8208, lng: 67.8250 },
    phone: ['+93 74 3333333'],
    services: ['general', 'emergency', 'maternal_health', 'pediatrics'],
    availability: '24/7',
    isGovernment: true,
    beds: 65,
    doctors: 18,
    established: 2003,
    image: 'https://images.unsplash.com/photo-1538108149393-fbbd81895907?w=800'
  },

  // ولایت کندز (Kunduz Province)
  {
    id: 'KDZ001',
    name: {
      ps: 'د کندز سیمه ییز روغتون',
      fa: 'شفاخانه ولایتی کندز',
      en: 'Kunduz Regional Hospital'
    },
    type: 'hospital',
    province: 'کندز',
    district: 'کندز ښار',
    address: {
      ps: 'کندز ښار',
      fa: 'شهر کندز',
      en: 'Kunduz City'
    },
    location: { lat: 36.7289, lng: 68.8667 },
    phone: ['+93 75 4444444'],
    email: 'info@kunduzhospital.gov.af',
    services: ['emergency', 'surgery', 'ICU', 'trauma', 'pediatrics'],
    availability: '24/7',
    isGovernment: true,
    beds: 200,
    doctors: 58,
    established: 1977,
    image: 'https://images.unsplash.com/photo-1596541223130-5d31a73fb6c6?w=800'
  },

  // ولایت بدخشان (Badakhshan Province)
  {
    id: 'BDK001',
    name: {
      ps: 'د بدخشان ولایتي روغتون',
      fa: 'شفاخانه ولایتی بدخشان',
      en: 'Badakhshan Provincial Hospital'
    },
    type: 'hospital',
    province: 'بدخشان',
    district: 'فیض آباد',
    address: {
      ps: 'فیض آباد ښار',
      fa: 'شهر فیض‌آباد',
      en: 'Faizabad City'
    },
    location: { lat: 37.1167, lng: 70.5803 },
    phone: ['+93 76 5555555'],
    services: ['general', 'emergency', 'surgery', 'maternal_health'],
    availability: '24/7',
    isGovernment: true,
    beds: 90,
    doctors: 24,
    established: 1992,
    image: 'https://images.unsplash.com/photo-1581594549595-35f6edc7b762?w=800'
  },

  // ولایت تخار (Takhar Province)
  {
    id: 'TKH001',
    name: {
      ps: 'د تخار ولایتي روغتون',
      fa: 'شفاخانه ولایتی تخار',
      en: 'Takhar Provincial Hospital'
    },
    type: 'hospital',
    province: 'تخار',
    district: 'تالقان',
    address: {
      ps: 'تالقان ښار',
      fa: 'شهر تالقان',
      en: 'Taloqan City'
    },
    location: { lat: 36.7367, lng: 69.5347 },
    phone: ['+93 77 6666666'],
    services: ['emergency', 'general', 'surgery', 'pediatrics'],
    availability: '24/7',
    isGovernment: true,
    beds: 110,
    doctors: 32,
    established: 1985,
    image: 'https://images.unsplash.com/photo-1563213126-a4273aed2016?w=800'
  },

  // ولایت بغلان (Baghlan Province)
  {
    id: 'BGL001',
    name: {
      ps: 'د بغلان ولایتي روغتون',
      fa: 'شفاخانه ولایتی بغلان',
      en: 'Baghlan Provincial Hospital'
    },
    type: 'hospital',
    province: 'بغلان',
    district: 'پلخمری',
    address: {
      ps: 'پلخمری ښار',
      fa: 'شهر پل خمری',
      en: 'Pul-e-Khumri City'
    },
    location: { lat: 35.9450, lng: 68.7150 },
    phone: ['+93 78 7777777'],
    services: ['emergency', 'general', 'surgery', 'internal_medicine'],
    availability: '24/7',
    isGovernment: true,
    beds: 130,
    doctors: 38,
    established: 1980,
    image: 'https://images.unsplash.com/photo-1579684385127-1ef15d508118?w=800'
  },

  // ولایت پروان (Parwan Province)
  {
    id: 'PRW001',
    name: {
      ps: 'د پروان ولایتي روغتون',
      fa: 'شفاخانه ولایتی پروان',
      en: 'Parwan Provincial Hospital'
    },
    type: 'hospital',
    province: 'پروان',
    district: 'چاریکار',
    address: {
      ps: 'چاریکار ښار',
      fa: 'شهر چاریکار',
      en: 'Charikar City'
    },
    location: { lat: 35.0139, lng: 69.1722 },
    phone: ['+93 79 8888888'],
    services: ['emergency', 'general', 'surgery', 'pediatrics', 'obstetrics'],
    availability: '24/7',
    isGovernment: true,
    beds: 100,
    doctors: 28,
    established: 1990,
    image: 'https://images.unsplash.com/photo-1551190822-a9333d879b1f?w=800'
  },

  // ولایت کاپیسا (Kapisa Province)
  {
    id: 'KPS001',
    name: {
      ps: 'د کاپیسا ولایتي روغتون',
      fa: 'شفاخانه ولایتی کاپیسا',
      en: 'Kapisa Provincial Hospital'
    },
    type: 'hospital',
    province: 'کاپیسا',
    district: 'محمود راقي',
    address: {
      ps: 'محمود راقي ښار',
      fa: 'شهر محمود راقی',
      en: 'Mahmud-i-Raqi City'
    },
    location: { lat: 35.0208, lng: 69.6906 },
    phone: ['+93 70 9999999'],
    services: ['general', 'emergency', 'maternal_health', 'pediatrics'],
    availability: 'day',
    isGovernment: true,
    beds: 50,
    doctors: 15,
    established: 2005,
    image: 'https://images.unsplash.com/photo-1519494026892-80bbd2d6fd0d?w=800'
  },

  // ولایت لغمان (Laghman Province)
  {
    id: 'LGH001',
    name: {
      ps: 'د لغمان ولایتي روغتون',
      fa: 'شفاخانه ولایتی لغمان',
      en: 'Laghman Provincial Hospital'
    },
    type: 'hospital',
    province: 'لغمان',
    district: 'مهترلام',
    address: {
      ps: 'مهترلام ښار',
      fa: 'شهر مهترلام',
      en: 'Mehtarlam City'
    },
    location: { lat: 34.6714, lng: 70.2075 },
    phone: ['+93 71 1010101'],
    services: ['emergency', 'general', 'surgery', 'pediatrics'],
    availability: '24/7',
    isGovernment: true,
    beds: 75,
    doctors: 20,
    established: 1998,
    image: 'https://images.unsplash.com/photo-1586773860418-d37222d8fce3?w=800'
  },

  // ولایت کونړ (Kunar Province)
  {
    id: 'KNR001',
    name: {
      ps: 'د کونړ ولایتي روغتون',
      fa: 'شفاخانه ولایتی کنر',
      en: 'Kunar Provincial Hospital'
    },
    type: 'hospital',
    province: 'کونړ',
    district: 'اسعد آباد',
    address: {
      ps: 'اسعد آباد ښار',
      fa: 'شهر اسعدآباد',
      en: 'Asadabad City'
    },
    location: { lat: 34.8736, lng: 71.1467 },
    phone: ['+93 72 1212121'],
    services: ['emergency', 'general', 'trauma', 'surgery'],
    availability: '24/7',
    isGovernment: true,
    beds: 60,
    doctors: 16,
    established: 2002,
    image: 'https://images.unsplash.com/photo-1587351021759-3e566b6af7cc?w=800'
  },

  // ولایت نورستان (Nuristan Province)
  {
    id: 'NRS001',
    name: {
      ps: 'د نورستان ولایتي روغتیایي مرکز',
      fa: 'مرکز صحی ولایتی نورستان',
      en: 'Nuristan Provincial Health Center'
    },
    type: 'health_center',
    province: 'نورستان',
    district: 'پارون',
    address: {
      ps: 'پارون ښار',
      fa: 'شهر پارون',
      en: 'Parun City'
    },
    location: { lat: 35.4242, lng: 70.9322 },
    phone: ['+93 73 1313131'],
    services: ['general', 'emergency', 'maternal_health'],
    availability: 'day',
    isGovernment: true,
    beds: 25,
    doctors: 6,
    established: 2010,
    image: 'https://images.unsplash.com/photo-1538108149393-fbbd81895907?w=800'
  },

  // ولایت لوګر (Logar Province)
  {
    id: 'LGR001',
    name: {
      ps: 'د لوګر ولایتي روغتون',
      fa: 'شفاخانه ولایتی لوگر',
      en: 'Logar Provincial Hospital'
    },
    type: 'hospital',
    province: 'لوګر',
    district: 'پلعلم',
    address: {
      ps: 'پلعلم ښار',
      fa: 'شهر پل علم',
      en: 'Pul-e-Alam City'
    },
    location: { lat: 33.9958, lng: 69.0253 },
    phone: ['+93 74 1414141'],
    services: ['general', 'emergency', 'surgery', 'pediatrics'],
    availability: '24/7',
    isGovernment: true,
    beds: 70,
    doctors: 18,
    established: 2000,
    image: 'https://images.unsplash.com/photo-1596541223130-5d31a73fb6c6?w=800'
  },

  // ولایت وردک (Wardak Province)
  {
    id: 'WRD001',
    name: {
      ps: 'د وردک ولایتي روغتون',
      fa: 'شفاخانه ولایتی وردک',
      en: 'Wardak Provincial Hospital'
    },
    type: 'hospital',
    province: 'وردک',
    district: 'میدان شهر',
    address: {
      ps: 'میدان شهر',
      fa: 'میدان شهر',
      en: 'Maidan Shahr'
    },
    location: { lat: 34.3836, lng: 68.8694 },
    phone: ['+93 75 1515151'],
    services: ['general', 'emergency', 'surgery'],
    availability: '24/7',
    isGovernment: true,
    beds: 55,
    doctors: 14,
    established: 2004,
    image: 'https://images.unsplash.com/photo-1581594549595-35f6edc7b762?w=800'
  },

  // ولایت پنجشیر (Panjshir Province)
  {
    id: 'PNJ001',
    name: {
      ps: 'د پنجشیر ولایتي روغتیایي مرکز',
      fa: 'مرکز صحی ولایتی پنجشیر',
      en: 'Panjshir Provincial Health Center'
    },
    type: 'health_center',
    province: 'پنجشیر',
    district: 'بازارک',
    address: {
      ps: 'بازارک ښار',
      fa: 'شهر بازارک',
      en: 'Bazarak City'
    },
    location: { lat: 35.3142, lng: 69.5167 },
    phone: ['+93 76 1616161'],
    services: ['general', 'emergency', 'maternal_health'],
    availability: 'day',
    isGovernment: true,
    beds: 30,
    doctors: 8,
    established: 2008,
    image: 'https://images.unsplash.com/photo-1563213126-a4273aed2016?w=800'
  },

  // ولایت خوست (Khost Province)
  {
    id: 'KHT001',
    name: {
      ps: 'د خوست ولایتي روغتون',
      fa: 'شفاخانه ولایتی خوست',
      en: 'Khost Provincial Hospital'
    },
    type: 'hospital',
    province: 'خوست',
    district: 'خوست ښار',
    address: {
      ps: 'خوست ښار',
      fa: 'شهر خوست',
      en: 'Khost City'
    },
    location: { lat: 33.3339, lng: 69.9372 },
    phone: ['+93 77 1717171'],
    services: ['emergency', 'general', 'surgery', 'trauma'],
    availability: '24/7',
    isGovernment: true,
    beds: 85,
    doctors: 23,
    established: 1996,
    image: 'https://images.unsplash.com/photo-1579684385127-1ef15d508118?w=800'
  },

  // ولایت پکتیکا (Paktika Province)
  {
    id: 'PKK001',
    name: {
      ps: 'د پکتیکا ولایتي روغتون',
      fa: 'شفاخانه ولایتی پکتیکا',
      en: 'Paktika Provincial Hospital'
    },
    type: 'hospital',
    province: 'پکتیکا',
    district: 'شرنه',
    address: {
      ps: 'شرنه ښار',
      fa: 'شهر شرنه',
      en: 'Sharan City'
    },
    location: { lat: 33.1486, lng: 68.7897 },
    phone: ['+93 78 1818181'],
    services: ['general', 'emergency', 'surgery'],
    availability: '24/7',
    isGovernment: true,
    beds: 45,
    doctors: 11,
    established: 2006,
    image: 'https://images.unsplash.com/photo-1551190822-a9333d879b1f?w=800'
  },

  // ولایت زابل (Zabul Province)
  {
    id: 'ZBL001',
    name: {
      ps: 'د زابل ولایتي روغتون',
      fa: 'شفاخانه ولایتی زابل',
      en: 'Zabul Provincial Hospital'
    },
    type: 'hospital',
    province: 'زابل',
    district: 'قلات',
    address: {
      ps: 'قلات ښار',
      fa: 'شهر قلات',
      en: 'Qalat City'
    },
    location: { lat: 32.1064, lng: 66.9097 },
    phone: ['+93 79 1919191'],
    services: ['general', 'emergency', 'surgery'],
    availability: '24/7',
    isGovernment: true,
    beds: 50,
    doctors: 13,
    established: 2001,
    image: 'https://images.unsplash.com/photo-1519494026892-80bbd2d6fd0d?w=800'
  },

  // ولایت ارزګان (Uruzgan Province)
  {
    id: 'URZ001',
    name: {
      ps: 'د ارزګان ولایتي روغتون',
      fa: 'شفاخانه ولایتی ارزگان',
      en: 'Uruzgan Provincial Hospital'
    },
    type: 'hospital',
    province: 'ارزګان',
    district: 'ترینکوټ',
    address: {
      ps: 'ترینکوټ ښار',
      fa: 'شهر ترین کوت',
      en: 'Tarin Kowt City'
    },
    location: { lat: 32.6333, lng: 65.8833 },
    phone: ['+93 70 2020202'],
    services: ['general', 'emergency', 'surgery'],
    availability: '24/7',
    isGovernment: true,
    beds: 40,
    doctors: 10,
    established: 2005,
    image: 'https://images.unsplash.com/photo-1586773860418-d37222d8fce3?w=800'
  },

  // ولایت هلمند (Helmand Province)
  {
    id: 'HLM001',
    name: {
      ps: 'د هلمند ولایتي روغتون',
      fa: 'شفاخانه ولایتی هلمند',
      en: 'Helmand Provincial Hospital'
    },
    type: 'hospital',
    province: 'هلمند',
    district: 'لښکر ګاه',
    address: {
      ps: 'لښکر ګاه ښار',
      fa: 'شهر لشکرگاه',
      en: 'Lashkar Gah City'
    },
    location: { lat: 31.5936, lng: 64.3714 },
    phone: ['+93 71 2121212'],
    services: ['emergency', 'general', 'surgery', 'trauma'],
    availability: '24/7',
    isGovernment: true,
    beds: 140,
    doctors: 40,
    established: 1982,
    image: 'https://images.unsplash.com/photo-1587351021759-3e566b6af7cc?w=800'
  },

  // ولایت فراه (Farah Province)
  {
    id: 'FRH001',
    name: {
      ps: 'د فراه ولایتي روغتون',
      fa: 'شفاخانه ولایتی فراه',
      en: 'Farah Provincial Hospital'
    },
    type: 'hospital',
    province: 'فراه',
    district: 'فراه ښار',
    address: {
      ps: 'فراه ښار',
      fa: 'شهر فراه',
      en: 'Farah City'
    },
    location: { lat: 32.3758, lng: 62.1203 },
    phone: ['+93 72 2222222'],
    services: ['general', 'emergency', 'surgery', 'pediatrics'],
    availability: '24/7',
    isGovernment: true,
    beds: 65,
    doctors: 17,
    established: 1993,
    image: 'https://images.unsplash.com/photo-1538108149393-fbbd81895907?w=800'
  },

  // ولایت نیمروز (Nimroz Province)
  {
    id: 'NMZ001',
    name: {
      ps: 'د نیمروز ولایتي روغتون',
      fa: 'شفاخانه ولایتی نیمروز',
      en: 'Nimroz Provincial Hospital'
    },
    type: 'hospital',
    province: 'نیمروز',
    district: 'زرنج',
    address: {
      ps: 'زرنج ښار',
      fa: 'شهر زرنج',
      en: 'Zaranj City'
    },
    location: { lat: 30.9594, lng: 61.8603 },
    phone: ['+93 73 2323232'],
    services: ['general', 'emergency', 'surgery'],
    availability: '24/7',
    isGovernment: true,
    beds: 50,
    doctors: 12,
    established: 1999,
    image: 'https://images.unsplash.com/photo-1596541223130-5d31a73fb6c6?w=800'
  },

  // ولایت بادغیس (Badghis Province)
  {
    id: 'BDG001',
    name: {
      ps: 'د بادغیس ولایتي روغتون',
      fa: 'شفاخانه ولایتی بادغیس',
      en: 'Badghis Provincial Hospital'
    },
    type: 'hospital',
    province: 'بادغیس',
    district: 'قلعه نو',
    address: {
      ps: 'قلعه نو ښار',
      fa: 'شهر قلعه نو',
      en: 'Qala-e-Naw City'
    },
    location: { lat: 34.9850, lng: 63.1303 },
    phone: ['+93 74 2424242'],
    services: ['general', 'emergency', 'maternal_health'],
    availability: '24/7',
    isGovernment: true,
    beds: 55,
    doctors: 14,
    established: 2003,
    image: 'https://images.unsplash.com/photo-1581594549595-35f6edc7b762?w=800'
  },

  // ولایت غور (Ghor Province)
  {
    id: 'GHR001',
    name: {
      ps: 'د غور ولایتي روغتون',
      fa: 'شفاخانه ولایتی غور',
      en: 'Ghor Provincial Hospital'
    },
    type: 'hospital',
    province: 'غور',
    district: 'چغچران',
    address: {
      ps: 'چغچران ښار',
      fa: 'شهر چغچران',
      en: 'Chaghcharan City'
    },
    location: { lat: 34.5167, lng: 65.2500 },
    phone: ['+93 75 2525252'],
    services: ['general', 'emergency', 'surgery'],
    availability: '24/7',
    isGovernment: true,
    beds: 60,
    doctors: 15,
    established: 1997,
    image: 'https://images.unsplash.com/photo-1563213126-a4273aed2016?w=800'
  },

  // ولایت سرپل (Sar-e-Pol Province)
  {
    id: 'SRP001',
    name: {
      ps: 'د سرپل ولایتي روغتون',
      fa: 'شفاخانه ولایتی سرپل',
      en: 'Sar-e-Pol Provincial Hospital'
    },
    type: 'hospital',
    province: 'سرپل',
    district: 'سرپل ښار',
    address: {
      ps: 'سرپل ښار',
      fa: 'شهر سرپل',
      en: 'Sar-e-Pol City'
    },
    location: { lat: 36.2156, lng: 65.9336 },
    phone: ['+93 76 2626262'],
    services: ['general', 'emergency', 'surgery', 'pediatrics'],
    availability: '24/7',
    isGovernment: true,
    beds: 70,
    doctors: 18,
    established: 1994,
    image: 'https://images.unsplash.com/photo-1579684385127-1ef15d508118?w=800'
  },

  // ولایت جوزجان (Jowzjan Province)
  {
    id: 'JWZ001',
    name: {
      ps: 'د جوزجان ولایتي روغتون',
      fa: 'شفاخانه ولایتی جوزجان',
      en: 'Jowzjan Provincial Hospital'
    },
    type: 'hospital',
    province: 'جوزجان',
    district: 'شبرغان',
    address: {
      ps: 'شبرغان ښار',
      fa: 'شهر شبرغان',
      en: 'Sheberghan City'
    },
    location: { lat: 36.6686, lng: 65.7453 },
    phone: ['+93 77 2727272'],
    services: ['emergency', 'general', 'surgery', 'internal_medicine'],
    availability: '24/7',
    isGovernment: true,
    beds: 95,
    doctors: 26,
    established: 1987,
    image: 'https://images.unsplash.com/photo-1551190822-a9333d879b1f?w=800'
  },

  // ولایت سمنګان (Samangan Province)
  {
    id: 'SMG001',
    name: {
      ps: 'د سمنګان ولایتي روغتون',
      fa: 'شفاخانه ولایتی سمنگان',
      en: 'Samangan Provincial Hospital'
    },
    type: 'hospital',
    province: 'سمنګان',
    district: 'ایبک',
    address: {
      ps: 'ایبک ښار',
      fa: 'شهر ایبک',
      en: 'Aybak City'
    },
    location: { lat: 36.2650, lng: 68.0139 },
    phone: ['+93 78 2828282'],
    services: ['general', 'emergency', 'surgery'],
    availability: '24/7',
    isGovernment: true,
    beds: 50,
    doctors: 13,
    established: 2002,
    image: 'https://images.unsplash.com/photo-1519494026892-80bbd2d6fd0d?w=800'
  },

  // ولایت فاریاب (Faryab Province)
  {
    id: 'FRY001',
    name: {
      ps: 'د فاریاب ولایتي روغتون',
      fa: 'شفاخانه ولایتی فاریاب',
      en: 'Faryab Provincial Hospital'
    },
    type: 'hospital',
    province: 'فاریاب',
    district: 'میمنه',
    address: {
      ps: 'میمنه ښار',
      fa: 'شهر میمنه',
      en: 'Maymana City'
    },
    location: { lat: 35.9208, lng: 64.7764 },
    phone: ['+93 79 2929292'],
    services: ['emergency', 'general', 'surgery', 'pediatrics'],
    availability: '24/7',
    isGovernment: true,
    beds: 105,
    doctors: 30,
    established: 1983,
    image: 'https://images.unsplash.com/photo-1586773860418-d37222d8fce3?w=800'
  },

  // ولایت دایکندی (Daykundi Province)
  {
    id: 'DYK001',
    name: {
      ps: 'د دایکندی ولایتي روغتیایي مرکز',
      fa: 'مرکز صحی ولایتی دایکندی',
      en: 'Daykundi Provincial Health Center'
    },
    type: 'health_center',
    province: 'دایکندی',
    district: 'نیلي',
    address: {
      ps: 'نیلي ښار',
      fa: 'شهر نیلی',
      en: 'Nili City'
    },
    location: { lat: 33.7500, lng: 66.0833 },
    phone: ['+93 70 3030303'],
    services: ['general', 'emergency', 'maternal_health'],
    availability: 'day',
    isGovernment: true,
    beds: 35,
    doctors: 9,
    established: 2007,
    image: 'https://images.unsplash.com/photo-1587351021759-3e566b6af7cc?w=800'
  }
];

// د ولایتونو لیست
export const afghanProvinces = [
  'کابل', 'هرات', 'قندهار', 'بلخ', 'ننګرهار', 'پکتیا', 'غزني', 'بامیان',
  'کندز', 'بدخشان', 'تخار', 'بغلان', 'پروان', 'کاپیسا', 'لغمان', 'کونړ',
  'نورستان', 'لوګر', 'وردک', 'پنجشیر', 'خوست', 'پکتیکا', 'زابل', 'ارزګان',
  'هلمند', 'فراه', 'نیمروز', 'بادغیس', 'غور', 'سرپل', 'جوزجان', 'سمنګان',
  'فاریاب', 'دایکندی'
];

// د خدمتونو لیست
export const medicalServices = {
  ps: {
    emergency: 'بیړنۍ مرستې',
    surgery: 'جراحي',
    pediatrics: 'د ماشومانو درملنه',
    cardiology: 'د زړه ناروغۍ',
    radiology: 'راډیولوژي',
    laboratory: 'لابراتوار',
    general: 'عمومي',
    trauma: 'ټپونه',
    ICU: 'ICU',
    neurology: 'د اعصابو ناروغۍ',
    gynecology: 'د ښځو ناروغۍ',
    obstetrics: 'زیږون',
    neonatology: 'د نوي زیږیدلو ماشومانو',
    vaccination: 'واکسین',
    maternal_health: 'د مور روغتیا',
    pharmacy: 'درملتون',
    internal_medicine: 'داخله',
    orthopedics: 'هډوکي',
    family_planning: 'کورنۍ پلان',
    nutrition: 'تغذیه'
  },
  fa: {
    emergency: 'اورژانس',
    surgery: 'جراحی',
    pediatrics: 'اطفال',
    cardiology: 'قلب',
    radiology: 'رادیولوژی',
    laboratory: 'آزمایشگاه',
    general: 'عمومی',
    trauma: 'ترومات',
    ICU: 'مراقبت‌های ویژه',
    neurology: 'اعصاب',
    gynecology: 'زنان',
    obstetrics: 'زایمان',
    neonatology: 'نوزادان',
    vaccination: 'واکسیناسیون',
    maternal_health: 'سلامت مادر',
    pharmacy: 'داروخانه',
    internal_medicine: 'داخلی',
    orthopedics: 'ارتوپدی',
    family_planning: 'تنظیم خانواده',
    nutrition: 'تغذیه'
  },
  en: {
    emergency: 'Emergency',
    surgery: 'Surgery',
    pediatrics: 'Pediatrics',
    cardiology: 'Cardiology',
    radiology: 'Radiology',
    laboratory: 'Laboratory',
    general: 'General',
    trauma: 'Trauma',
    ICU: 'ICU',
    neurology: 'Neurology',
    gynecology: 'Gynecology',
    obstetrics: 'Obstetrics',
    neonatology: 'Neonatology',
    vaccination: 'Vaccination',
    maternal_health: 'Maternal Health',
    pharmacy: 'Pharmacy',
    internal_medicine: 'Internal Medicine',
    orthopedics: 'Orthopedics',
    family_planning: 'Family Planning',
    nutrition: 'Nutrition'
  }
};
