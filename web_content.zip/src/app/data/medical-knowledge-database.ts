// 🏥 HealMate بشپړ طبي معلوماتو ډیټابیس
// Complete Medical Knowledge Database for AI Chat

export interface MedicalCondition {
  keywords: string[];
  symptoms: string[];
  causes: string[];
  treatments: string[];
  prevention: string[];
  medications: string[];
  urgency: 'low' | 'medium' | 'high' | 'emergency';
  category: string;
}

export const medicalKnowledgeDatabase: { [key: string]: MedicalCondition } = {
  // ==========================================
  // د درد او د درملو مسلې - Pain & Medication
  // ==========================================
  
  headache: {
    keywords: ['headache', 'سردرد', 'سر درد', 'د سر درد', 'میګرین', 'migraine'],
    symptoms: ['د سر درد', 'د سترګو درد', 'د رڼا حساسیت', 'زړه بدوالی'],
    causes: ['د اوبو کمښت', 'فشار', 'د خوب کمښت', 'د سترګو ستونزې', 'غذایي عادتونه'],
    treatments: [
      'د اوبو کافي مقدار - ۸-۱۰ ګیلاس په ورځ',
      'په تیاره کوټه کې استراحت',
      'د سر مساژ',
      'د سرده کمپریس',
      'Paracetamol 500mg هر ۶ ساعته',
      'Ibuprofen 400mg د ډاکټر په مشوره'
    ],
    prevention: [
      'منظم خوب - ۷-۸ ساعته',
      'د اوبو کافي مقدار',
      'د فشار مدیریت - یوګا، مراقبت',
      'د کیفین کمول',
      'منظم ورزش'
    ],
    medications: ['Paracetamol', 'Ibuprofen', 'Aspirin', 'Sumatriptan (د میګرین لپاره)'],
    urgency: 'low',
    category: 'نیورولوجي / Neurological'
  },

  fever: {
    keywords: ['fever', 'تبه', 'تب', 'temperature', 'تودوخه', 'بخار'],
    symptoms: ['تبه (۳۸°C+)', 'د بدن درد', 'ستړیا', 'خوله وچوالی', 'سردوزه'],
    causes: ['ویروسي انفکشن', 'باکتریایي انفکشن', 'د اوبو کمښت', 'د غرمۍ څخه ډیر تودوخه'],
    treatments: [
      'په کوټه کې استراحت',
      'اوبه او مایعات ډیر وڅښئ',
      'Paracetamol 500-1000mg هر ۶ ساعته',
      'سړه کمپریس (په پېشانۍ، غاړه)',
      'سپک کالي واغوندئ',
      'که تبه ۱۰۳°F+ وي - سمدستي ډاکټر ته'
    ],
    prevention: [
      'د خوراک کې پاکوالی',
      'د لاسونو منظم مینځل',
      'د واکسینونو بشپړول',
      'د ناروغو څخه لیرې پاتې کیدل'
    ],
    medications: ['Paracetamol', 'Ibuprofen', 'د انفکشن په صورت کې Antibiotics (د ډاکټر په مشوره)'],
    urgency: 'medium',
    category: 'عمومي / General'
  },

  stomachPain: {
    keywords: ['stomach', 'معده', 'د خېټې درد', 'د معدې درد', 'د نس درد', 'پیټ درد', 'شکم درد'],
    symptoms: ['د معدې درد', 'زړه بدوالی', 'کانګې', 'نفخ', 'د اشتها کمښت'],
    causes: ['د غذا زهر', 'ګاستریت', 'السر', 'د معدې تیزابیت', 'انفکشن', 'قبضیت'],
    treatments: [
      'د ۲۴ ساعتونو لپاره سپک غذا (چاول، کیله)',
      'د اوبو ډیر مقدار',
      'Omeprazole 20mg صبح د خوراک څخه مخکې',
      'Antacid (د تیزابیت لپاره)',
      'په ملا کې د پښو پورته کول',
      'د کافي غذا څخه ډډه (چټ، تیزابي میوې)'
    ],
    prevention: [
      'په وخت خوراک',
      'د چټو او تیزابي شیانو کمول',
      'د فشار مدیریت',
      'د غذا بعد سمدستي نه ملامت کیدل',
      'د تنباکو او الکول څخه ډډه'
    ],
    medications: ['Omeprazole', 'Ranitidine', 'Antacids (Gelusil)', 'Domperidone', 'Loperamide (د اسهال لپاره)'],
    urgency: 'medium',
    category: 'ګاستروانټرولوجي / Gastroenterology'
  },

  // ==========================================
  // د زړه او رګونو مسلې - Cardiovascular
  // ==========================================

  heartDisease: {
    keywords: ['heart', 'زړه', 'قلب', 'cardiac', 'د زړه ناروغي', 'قلبي'],
    symptoms: ['د زړه درد', 'ساه لنډوالی', 'ستړیا', 'د زړه ګړندی ضربان', 'پښو ته پړسوب'],
    causes: ['لوړ فشار', 'کولیسټرول', 'ډایبیټس', 'سګرټ کشیدل', 'د ورزش نشتوالی', 'د وزن ډیروالی'],
    treatments: [
      'د ډاکټر سره فوري مراجعه',
      'د وینې فشار منظم کنټرول',
      'Aspirin 75mg په ورځ (د ډاکټر په مشوره)',
      'Atorvastatin (د کولیسټرول لپاره)',
      'د غذا کې د مالګې کمول',
      'منظم ورزش - ۳۰ منټه پیاده روی'
    ],
    prevention: [
      'صحي غذا: میوې، سابه، بشپړ غله',
      'منظم ورزش: ۳۰ منټه په ورځ',
      'د سګرټ پریښودل',
      'د فشار مدیریت',
      'صحي وزن ساتل',
      'هر ۶ میاشتې د زړه معاینه'
    ],
    medications: ['Aspirin', 'Atorvastatin', 'Amlodipine', 'Losartan', 'Metoprolol', 'Clopidogrel'],
    urgency: 'high',
    category: 'کارډیولوجي / Cardiology'
  },

  highBloodPressure: {
    keywords: ['blood pressure', 'فشار', 'د وینې فشار', 'hypertension', 'فشار خون', 'ہائی بلڈ پریشر'],
    symptoms: ['د سر درد', 'ساه لنډوالی', 'د پوزې وینه', 'د سترګو مشکلات', 'د زړه ګړندی ضربان'],
    causes: ['د مالګې ډیر استعمال', 'فشار', 'د ورزش نشتوالی', 'د وزن ډیروالی', 'جینیاتي عوامل'],
    treatments: [
      'د مالګې کمول - ۵ ګرام په ورځ',
      'Amlodipine 5mg په ورځ',
      'Losartan 50mg صبح',
      'د وزن کمول',
      'منظم ورزش',
      'د فشار مدیریت',
      'د فشار ورځني څارنه'
    ],
    prevention: [
      'د مالګې کم استعمال',
      'منظم ورزش',
      'صحي وزن',
      'د الکول او سګرټ پریښودل',
      'کافي خوب',
      'د فشار کمول'
    ],
    medications: ['Amlodipine', 'Losartan', 'Enalapril', 'Hydrochlorothiazide', 'Metoprolol'],
    urgency: 'high',
    category: 'کارډیولوجي / Cardiology'
  },

  // ==========================================
  // د تنفسي سیسټم - Respiratory
  // ==========================================

  coughCold: {
    keywords: ['cough', 'cold', 'زکام', 'ټوخی', 'سرما خوردگی', 'نزله'],
    symptoms: ['ټوخی', 'د پوزې بهیدل', 'ستوني درد', 'سردرد', 'بدن درد', 'سپکه تبه'],
    causes: ['ویروسي انفکشن', 'د هوا بدلون', 'د معافیت ضعف', 'د نورو څخه سرایت'],
    treatments: [
      'د اوبو ډیر مقدار - تود اوبه',
      'د شاتو سره تود اوبه (د ستوني درد لپاره)',
      'Paracetamol 500mg د تبې لپاره',
      'Cetirizine 10mg شپې',
      'د عسلو او لیمو استعمال',
      'بخار (Steam inhalation)',
      'کافي استراحت'
    ],
    prevention: [
      'د لاسونو منظم مینځل',
      'د ناروغو څخه لیرې',
      'د Vitamin C استعمال',
      'صحي غذا',
      'د معافیت قوت زیاتول',
      'منظم ورزش'
    ],
    medications: ['Paracetamol', 'Cetirizine', 'Dextromethorphan (د ټوخي لپاره)', 'Loratadine', 'Vitamin C'],
    urgency: 'low',
    category: 'تنفسي / Respiratory'
  },

  asthma: {
    keywords: ['asthma', 'دمه', 'تنګ ساه', 'ربو', 'ساه لنډوالی'],
    symptoms: ['ساه لنډوالی', 'د سینې تنګي', 'ویزینګ', 'ټوخی', 'د شپې ستونزې'],
    causes: ['الرجي', 'د هوا ککړتیا', 'د ورزش څخه', 'سړه هوا', 'انفکشن', 'فشار'],
    treatments: [
      'Salbutamol Inhaler (د بیړنۍ لپاره)',
      'Budesonide Inhaler (منظم کنټرول)',
      'د Triggers څخه ډډه',
      'د ورزش مخکې Inhaler',
      'د سینې physiotherapy',
      'د ډاکټر منظم معاینې'
    ],
    prevention: [
      'د Inhaler منظم استعمال',
      'د الرجي شیانو څخه ډډه',
      'د هوا پاکوالی',
      'د سګرټ او لوګي څخه لیرې',
      'منظم ورزش (د ډاکټر په مشوره)',
      'د معافیت قوت زیاتول'
    ],
    medications: ['Salbutamol Inhaler', 'Budesonide Inhaler', 'Montelukast', 'Theophylline'],
    urgency: 'high',
    category: 'تنفسي / Respiratory'
  },

  // ==========================================
  // د قند ناروغي - Diabetes
  // ==========================================

  diabetes: {
    keywords: ['diabetes', 'قند', 'د قند ناروغي', 'شکر', 'ډایبیټس', 'دیابت'],
    symptoms: ['د تندي ډیر لګیدل', 'د اوبو ډیر لګیدل', 'د وزن کمښت', 'ستړیا', 'د سترګو مشکلات'],
    causes: ['جینیاتي', 'د وزن ډیروالی', 'د ورزش نشتوالی', 'نامناسب غذا', 'فشار'],
    treatments: [
      'Metformin 500-1000mg دوه ځله په ورځ',
      'Gliclazide (که ضرورت وي)',
      'Insulin (د Type 1 لپاره یا پرمختللو حالتونو)',
      'د قند ورځنی کنټرول',
      'د غذا کنټرول - د کاربوهایډریټ کمول',
      'منظم ورزش - ۳۰ منټه',
      'د وزن کنټرول'
    ],
    prevention: [
      'صحي وزن ساتل',
      'منظم ورزش',
      'صحي غذا - د شکرو شیانو کمول',
      'د فشار مدیریت',
      'منظم معاینې',
      'د کورنۍ تاریخ څارنه'
    ],
    medications: ['Metformin', 'Gliclazide', 'Glimepiride', 'Insulin Glargine', 'Insulin Aspart', 'Sitagliptin'],
    urgency: 'high',
    category: 'انډوکرینولوجي / Endocrinology'
  },

  // ==========================================
  // د پوستکي مسلې - Dermatology
  // ==========================================

  skinAllergy: {
    keywords: ['allergy', 'الرجي', 'د پوستکي الرجي', 'خارش', 'خارښت', 'جلدی الرجی'],
    symptoms: ['د پوستکي سور والی', 'خارښت', 'پړسوب', 'د پوستکي وچوالی', 'د ګوزڼو راوتل'],
    causes: ['د خوراکي الرجي', 'د درملو غبرګون', 'د حشراتو د ټکولو', 'کیمیاوي مواد', 'د هوا بدلون'],
    treatments: [
      'Cetirizine 10mg شپې',
      'Hydrocortisone Cream 1% (موضعي)',
      'د الرجي شي څخه ډډه',
      'سړه کمپریس',
      'د Calamine Lotion استعمال',
      'په جدي حالتونو کې - Prednisolone'
    ],
    prevention: [
      'د الرجي شیانو پیژندل او ډډه',
      'د پوستکي پاکوالی',
      'د مناسب صابون استعمال',
      'د لمر څخه محافظت',
      'د moisturizer استعمال'
    ],
    medications: ['Cetirizine', 'Loratadine', 'Hydrocortisone Cream', 'Betamethasone Cream', 'Calamine Lotion'],
    urgency: 'low',
    category: 'ډرمټولوجي / Dermatology'
  },

  acne: {
    keywords: ['acne', 'pimples', 'ګوزڼې', 'د مخ دانې', 'جوش', 'پمپل'],
    symptoms: ['د مخ دانې', 'د پوستکي غوړ', 'سور والی', 'درد کوونکې دانې'],
    causes: ['هارمونونه', 'د پوستکي غوړ ډیروالی', 'ناسم غذا', 'فشار', 'جینیاتي'],
    treatments: [
      'د مخ منظم مینځل - ۲ ځله په ورځ',
      'Benzoyl Peroxide Gel 5%',
      'Clindamycin Gel 1%',
      'Tretinoin Cream (شپې)',
      'Doxycycline 100mg (د ډاکټر په مشوره)',
      'د غوړو غذا کمول'
    ],
    prevention: [
      'د مخ پاکوالی',
      'د غوړو کاسمیټیکس څخه ډډه',
      'صحي غذا - میوې او سابه',
      'اوبه ډیر وڅښئ',
      'د لاسونو د مخ ته لګول مه کوئ',
      'کافي خوب'
    ],
    medications: ['Benzoyl Peroxide', 'Clindamycin Gel', 'Tretinoin Cream', 'Adapalene Gel', 'Doxycycline', 'Isotretinoin (په شدیدو حالتونو)'],
    urgency: 'low',
    category: 'ډرمټولوجي / Dermatology'
  },

  // ==========================================
  // د ماشومانو مسلې - Pediatrics
  // ==========================================

  childFever: {
    keywords: ['child fever', 'د ماشوم تبه', 'بچے کا بخار', 'pediatric fever'],
    symptoms: ['تبه', 'زړه بدوالی', 'د اشتها کمښت', 'ستړیا', 'ټوخی'],
    causes: ['ویروسي انفکشن', 'ټونسیلیت', 'غوږ انفکشن', 'د واکسین غبرګون'],
    treatments: [
      'Paracetamol Syrup: ۱۰-۱۵ mg/kg هر ۶ ساعته',
      'Ibuprofen Suspension: (که ۶ میاشتې+)',
      'اوبه ډیر ورکړئ',
      'سپک کالي',
      'سړه کمپریس (د تبې کمولو لپاره)',
      'که تبه ۱۰۲°F+ وي - ډاکټر ته'
    ],
    prevention: [
      'د واکسینونو بشپړول',
      'د ماشوم پاکوالی',
      'صحي غذا',
      'د ناروغو څخه لیرې',
      'کافي خوب'
    ],
    medications: ['Paracetamol Syrup 120mg/5ml', 'Ibuprofen Suspension 100mg/5ml', 'د انفکشن په صورت کې Antibiotics'],
    urgency: 'medium',
    category: 'پیډیاټریکس / Pediatrics'
  },

  // ==========================================
  // د ښځو روغتیا - Women's Health
  // ==========================================

  menstrualPain: {
    keywords: ['period', 'menstrual', 'د میاشتنۍ درد', 'پیریډ', 'ماهواری', 'حیض'],
    symptoms: ['د لاندني خېټې درد', 'کمر درد', 'سردرد', 'زړه بدوالی', 'خپګان'],
    causes: ['هارمونونه', 'یوټرس قراردادونه', 'Endometriosis', 'فایبرایډز'],
    treatments: [
      'Ibuprofen 400mg هر ۶-۸ ساعته',
      'Mefenamic Acid 500mg',
      'تود کمپریس (د خېټې پر سر)',
      'د خوب کافي مقدار',
      'د یوګا او سټریچینګ',
      'د کیفین کمول'
    ],
    prevention: [
      'منظم ورزش',
      'صحي غذا - Iron او Calcium',
      'د فشار مدیریت',
      'کافي خوب',
      'د تودو مایعاتو استعمال'
    ],
    medications: ['Ibuprofen', 'Mefenamic Acid', 'Tranexamic Acid (د ډیرې وینې لپاره)', 'د هارمون کنټرول Pills'],
    urgency: 'low',
    category: 'د ښځو روغتیا / Women\'s Health'
  },

  pregnancy: {
    keywords: ['pregnancy', 'امیندواري', 'حمل', 'pregnant', 'باردار'],
    symptoms: ['د میاشتنۍ بندیدل', 'صبح زړه بدوالی', 'ستړیا', 'د سینې ډیروالی'],
    causes: ['د حمل نورمال پروسه'],
    treatments: [
      'Folic Acid 5mg په ورځ',
      'Iron + Folic Acid Tablets',
      'Calcium + Vitamin D',
      'منظم Prenatal معاینې',
      'صحي غذا - پروټین، Iron',
      'د ډاکټر منظم مشورې'
    ],
    prevention: [
      'منظم معاینې - هره میاشت',
      'صحي غذا',
      'د ورزش سپک فعالیتونه',
      'د سګرټ او الکول پریښودل',
      'د فشار کمول',
      'کافي استراحت'
    ],
    medications: ['Folic Acid 5mg', 'Iron + Folic Acid', 'Calcium + Vitamin D', 'Prenatal Multivitamin'],
    urgency: 'high',
    category: 'د ښځو روغتیا / Women\'s Health'
  },

  // ==========================================
  // د سترګو مسلې - Ophthalmology
  // ==========================================

  eyeInfection: {
    keywords: ['eye', 'سترګې', 'چشم', 'eye infection', 'د سترګو انفکشن', 'آنکھ'],
    symptoms: ['د سترګو سور والی', 'د اوښکو بهیدل', 'درد', 'د رڼا حساسیت', 'د سترګو پړسوب'],
    causes: ['باکتریایي انفکشن', 'ویروسي انفکشن', 'الرجي', 'د اوبو کمښت'],
    treatments: [
      'Chloramphenicol Eye Drops - هر ۴ ساعته',
      'Ofloxacin Eye Drops',
      'سړه کمپریس',
      'د سترګو پاکوالی - تود اوبو سره',
      'د لاسونو د سترګو ته نه لګول',
      'که په ۲-۳ ورځو کې ښه نه شي - ډاکټر ته'
    ],
    prevention: [
      'د لاسونو پاکوالی',
      'د سترګو نه خروبول',
      'د نورو سره Towel share مه کوئ',
      'د کاسمیټیکس پاکوالی',
      'د لینز پاکوالی'
    ],
    medications: ['Chloramphenicol Eye Drops', 'Ofloxacin Eye Drops', 'Tobramycin Eye Drops', 'Artificial Tears'],
    urgency: 'medium',
    category: 'اوفتلمولوجي / Ophthalmology'
  },

  // ==========================================
  // د غوږ، پوزه، ستوني - ENT
  // ==========================================

  earPain: {
    keywords: ['ear', 'غوږ', 'کان', 'ear pain', 'د غوږ درد', 'کان درد'],
    symptoms: ['د غوږ درد', 'د اوریدلو کمښت', 'مایع راوتل', 'تبه', 'سردرد'],
    causes: ['غوږ انفکشن', 'د اوبو ننوتل', 'د شمع جمع کیدل', 'د ستوني انفکشن'],
    treatments: [
      'Amoxicillin 500mg ۳ ځله په ورځ',
      'Ear Drops (Ciprofloxacin)',
      'Paracetamol د درد لپاره',
      'تود کمپریس',
      'سر لوړ ساتل د خوب پر وخت',
      'د اوبو څخه ډډه (د حمام پر وخت)'
    ],
    prevention: [
      'د غوږونو پاکوالی',
      'د حمام وروسته د غوږونو وچول',
      'د غوږ د شمع د لرې کولو مخکې ډاکټر ته',
      'د Swimming پر وخت Ear Plugs'
    ],
    medications: ['Amoxicillin', 'Ciprofloxacin Ear Drops', 'Paracetamol', 'Ibuprofen'],
    urgency: 'medium',
    category: 'ENT'
  },

  // ==========================================
  // روغتیایي عمومي مشورې - General Health Advice
  // ==========================================

  weightLoss: {
    keywords: ['weight', 'وزن', 'وزن کمول', 'چربی', 'obesity', 'موټاپا'],
    symptoms: ['د وزن ډیروالی', 'ستړیا', 'د ورزش کمښت', 'د ساه لنډوالی'],
    causes: ['د خوراک ډیروالی', 'د ورزش نشتوالی', 'هارمونونه', 'جینیاتي', 'د خوب کمښت'],
    treatments: [
      'د کالوري کنټرول - ۱۵۰۰-۲۰۰۰ په ورځ',
      'منظم ورزش - ۴۵-۶۰ منټه',
      'د اوبو ډیر مقدار - ۸-۱۰ ګیلاس',
      'د غذا کوچني حصې - ۵-۶ ځله',
      'د پروټین ډیرول',
      'د کاربوهایډریټ کمول'
    ],
    prevention: [
      'صحي غذا - میوې، سابه',
      'منظم ورزش',
      'د فشار مدیریت',
      'کافي خوب - ۷-۸ ساعته',
      'د وزن منظم څارنه',
      'د جنک فوډ څخه ډډه'
    ],
    medications: ['د ډاکټر په مشوره: Orlistat (په خاصو حالتونو کې)', 'Multivitamin', 'Vitamin D'],
    urgency: 'low',
    category: 'د تغذیې / Nutrition'
  },

  vitamins: {
    keywords: ['vitamin', 'ویتامین', 'vitamins', 'supplements', 'nutritional'],
    symptoms: ['ضعف', 'ستړیا', 'د معافیت کمښت', 'د پوستکي خشکي', 'د ویښتو ریزش'],
    causes: ['د غذا کمښت', 'جذب مسلې', 'د لمر کمښت', 'خاص ناروغۍ'],
    treatments: [
      'Multivitamin - یو د ورځ',
      'Vitamin D3 - ۲۰۰۰ IU په ورځ',
      'Vitamin B12 - ۱۰۰۰ mcg',
      'Vitamin C - ۵۰۰-۱۰۰۰ mg',
      'Iron + Folic Acid (د ښځو لپاره)',
      'Omega-3 Fish Oil'
    ],
    prevention: [
      'متوازن غذا - میوې، سابه، غوښه',
      'د لمر په رڼا کې وخت تیرول - ۱۵-۲۰ منټه',
      'د کچالو میوو استعمال',
      'د مغز جات استعمال',
      'منظم معاینې'
    ],
    medications: ['Multivitamin', 'Vitamin D3', 'Vitamin B12', 'Vitamin C', 'Iron + Folic Acid', 'Omega-3', 'Calcium + Vitamin D'],
    urgency: 'low',
    category: 'د تغذیې / Nutrition'
  },

  mentalHealth: {
    keywords: ['depression', 'anxiety', 'stress', 'خپګان', 'اضطراب', 'فشار', 'ذہنی صحت'],
    symptoms: ['خپګان', 'اضطراب', 'د خوب مسلې', 'ستړیا', 'د تمرکز کمښت', 'د اشتها بدلون'],
    causes: ['د ژوند فشار', 'د کار ډیروالی', 'کورنۍ مسلې', 'هارمونونه', 'جینیاتي'],
    treatments: [
      'د رواني روغتیا ماهر سره مشوره',
      'مراقبت او یوګا - ۲۰ منټه په ورځ',
      'منظم ورزش',
      'د خوب بهبود - ۷-۸ ساعته',
      'د ملګرو او کورنۍ ملاتړ',
      'Sertraline یا Fluoxetine (د ډاکټر په مشوره)'
    ],
    prevention: [
      'منظم ورزش',
      'د فشار مدیریت',
      'صحي غذا',
      'کافي خوب',
      'د ټولنیز اړیکو ساتل',
      'د هابی یا دلچسپۍ وخت'
    ],
    medications: ['Sertraline', 'Fluoxetine', 'Escitalopram', 'د اضطراب لپاره: Alprazolam (لنډ مهاله)', 'د خوب لپاره: Melatonin'],
    urgency: 'medium',
    category: 'رواني روغتیا / Mental Health'
  }
};

// د مخنیوي او روغتیایي ژوند د پام وړ ټکي
export const healthTips = {
  ps: [
    '💧 په ورځ کې ۸-۱۰ ګیلاس اوبه وڅښئ',
    '🏃‍♂️ په ورځ کې لږترلږه ۳۰ منټه ورزش وکړئ',
    '😴 ۷-۸ ساعته خوب ضروري دی',
    '🥗 تازه میوې او سابه خورئ',
    '🚭 د تنباکو او سګرټ څخه ډډه وکړئ',
    '🧘‍♂️ د فشار مدیریت لپاره یوګا او مراقبت وکړئ',
    '🩺 هر ۶ میاشتې صحي معاینه وکړئ',
    '🦷 ورځ کې دوه ځله خپلې غاښونه پاک کړئ',
    '👨‍👩‍👧‍👦 د کورنۍ سره وخت تیر کړئ',
    '📚 نوې شیان زده کړئ او دماغ فعال وساتئ'
  ],
  fa: [
    '💧 روزانه ۸-۱۰ لیوان آب بنوشید',
    '🏃‍♂️ حداقل ۳۰ دقیقه در روز ورزش کنید',
    '😴 ۷-۸ ساعت خواب ضروری است',
    '🥗 میوه و سبزیجات تازه بخورید',
    '🚭 از دخانیات و سیگار پرهیز کنید',
    '🧘‍♂️ برای مدیریت استرس یوگا و مدیتیشن کنید',
    '🩺 هر ۶ ماه معاینه سلامت انجام دهید',
    '🦷 روزی دو بار دندان‌های خود را بشویید',
    '👨‍👩‍👧‍👦 با خانواده وقت بگذرانید',
    '📚 چیزهای جدید یاد بگیرید و مغز را فعال نگه دارید'
  ],
  en: [
    '💧 Drink 8-10 glasses of water daily',
    '🏃‍♂️ Exercise at least 30 minutes a day',
    '😴 7-8 hours of sleep is essential',
    '🥗 Eat fresh fruits and vegetables',
    '🚭 Avoid tobacco and smoking',
    '🧘‍♂️ Practice yoga and meditation for stress management',
    '🩺 Get a health checkup every 6 months',
    '🦷 Brush your teeth twice a day',
    '👨‍👩‍👧‍👦 Spend time with family',
    '📚 Learn new things and keep your mind active'
  ]
};
