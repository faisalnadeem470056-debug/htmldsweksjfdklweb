# 🎨 د HealMate Icons جوړولو بشپړ لارښود
# Complete Icon Setup Guide for HealMate

## 🚨 مهم اعلان | IMPORTANT NOTICE

ستاسو manifest.json اوس سم دی، خو تاسو باید **icon files** جوړ کړئ.

---

## 📋 د اړینو Icon Sizes لیست

تاسو باید دا icon sizes په `/public/` folder کې جوړ کړئ:

### Required Icons:
- ✅ `icon-72x72.png` (72x72 pixels)
- ✅ `icon-96x96.png` (96x96 pixels)
- ✅ `icon-128x128.png` (128x128 pixels)
- ✅ `icon-144x144.png` (144x144 pixels)
- ✅ `icon-152x152.png` (152x152 pixels)
- ✅ `icon-192x192.png` (192x192 pixels)
- ✅ `icon-384x384.png` (384x384 pixels)
- ✅ `icon-512x512.png` (512x512 pixels)

---

## 🎨 لاره 1: PWABuilder Image Generator (ترټولو اسانه!)

### قدم 1: یو Master Icon جوړول
د HealMate لپاره یو **512x512 PNG** icon جوړ کړئ:

**Design Ideas:**
```
Option 1: Heart Icon
- د سره heart په منځ کې
- Background: Gradient (Red to Pink)
- Text: "HealMate" لاندې

Option 2: Medical Cross + Heart
- Medical cross د heart سره ترکیب شوی
- Modern, clean design
- د افغانستان رنګونه (Red, Green, Black)

Option 3: Simple & Modern
- یوازې Heart icon
- Minimalist design
- Red/Pink gradient background
```

### قدم 2: PWABuilder ته ورشئ
1. https://www.pwabuilder.com/imageGenerator ته ورشئ
2. خپل 512x512 PNG icon upload کړئ
3. "Generate" کلیک وکړئ
4. ټول icon sizes download کړئ (ZIP file)
5. ZIP extract کړئ او ټول PNG files په `/public/` folder کې کېږدئ

---

## 🎨 لاره 2: د Figma یا Canva کارول

### Figma کې:
1. نوی file جوړ کړئ
2. یو 512x512 frame جوړ کړئ
3. د HealMate لوګو design کړئ:
   - Heart icon (د lucide-react څخه inspire شئ)
   - Background gradient (Red to Pink)
   - "HealMate" text (optional)
4. Export کړئ په 8 مختلفو sizes کې

### Canva کې:
1. https://canva.com ته ورشئ
2. "Custom size" → 512x512 px
3. د App Icon template غوره کړئ
4. Design customize کړئ:
   - Heart icon
   - "HealMate" text
   - د افغانستان رنګونه
5. Download په PNG format کې
6. Resize tool کاروئ د نورو sizes لپاره

---

## 🎨 لاره 3: Online Icon Generator

### Websites:
1. **RealFaviconGenerator.net**
   - URL: https://realfavicongenerator.net
   - Master icon upload کړئ
   - ټول sizes generate کیږي

2. **Favicon.io**
   - URL: https://favicon.io
   - Text to icon converter ولري
   - "HealMate" text کې لیکئ
   - Download all sizes

3. **IconKitchen**
   - URL: https://icon.kitchen
   - PWA icons ځانګړي جوړوي
   - All sizes په یو ځای generate کیږي

---

## 🎨 لاره 4: د موجوده SVG څخه PNG جوړول

موږ د `/public/heart-icon.svg` لرو. دا کارولی شئ:

### Online SVG to PNG Converter:
1. https://svgtopng.com ته ورشئ
2. `heart-icon.svg` upload کړئ
3. Size set کړئ (72, 96, 128, 144, 152, 192, 384, 512)
4. هر size download کړئ
5. په `/public/` کې save کړئ

### Inkscape (Desktop Software):
```bash
# Install Inkscape
# Then use command line:

inkscape heart-icon.svg --export-png=icon-72x72.png -w 72 -h 72
inkscape heart-icon.svg --export-png=icon-96x96.png -w 96 -h 96
inkscape heart-icon.svg --export-png=icon-128x128.png -w 128 -h 128
inkscape heart-icon.svg --export-png=icon-144x144.png -w 144 -h 144
inkscape heart-icon.svg --export-png=icon-152x152.png -w 152 -h 152
inkscape heart-icon.svg --export-png=icon-192x192.png -w 192 -h 192
inkscape heart-icon.svg --export-png=icon-384x384.png -w 384 -h 384
inkscape heart-icon.svg --export-png=icon-512x512.png -w 512 -h 512
```

---

## 🎨 لاره 5: ImageMagick (Terminal)

که تاسو یو master PNG لرئ:

```bash
# Install ImageMagick
brew install imagemagick  # Mac
sudo apt install imagemagick  # Linux

# Generate all sizes
convert icon-master.png -resize 72x72 icon-72x72.png
convert icon-master.png -resize 96x96 icon-96x96.png
convert icon-master.png -resize 128x128 icon-128x128.png
convert icon-master.png -resize 144x144 icon-144x144.png
convert icon-master.png -resize 152x152 icon-152x152.png
convert icon-master.png -resize 192x192 icon-192x192.png
convert icon-master.png -resize 384x384 icon-384x384.png
convert icon-master.png -resize 512x512 icon-512x512.png
```

---

## 🎯 سپارښتنه شوې Design Guidelines

### د Icon Design لپاره:

1. **Colors:**
   - Primary: Red (#EF4444)
   - Secondary: Pink (#EC4899)
   - Background: White یا Gradient

2. **Elements:**
   - Heart icon (د روغتیا سمبول)
   - Plus sign (+) - Medical symbol
   - Simple & Recognizable

3. **Typography:**
   - که text کاروئ، clear او readable وي
   - Sans-serif fonts (Roboto, Inter, etc.)

4. **Safe Area:**
   - د icon edge څخه 10% margin پریږدئ
   - دا د maskable icons لپاره مهمه ده

5. **Format:**
   - PNG format (د transparency لپاره)
   - Square (1:1 aspect ratio)
   - Transparent یا solid background

---

## ✅ د Test کولو لاره

کله چې تاسو icons جوړ کړئ:

1. **په `/public/` folder کې یې کېږدئ**
2. **Browser refresh کړئ** (Ctrl+Shift+R)
3. **Manifest test کړئ**: https://manifest-validator.appspot.com/
4. **PWABuilder test کړئ**: https://www.pwabuilder.com/
5. **Lighthouse test کړئ**: Browser DevTools → Lighthouse → PWA

---

## 🎨 د Ready-Made Icons لپاره

که تاسو ګړندی icon غواړئ:

### Option 1: د Material Icons کارول
```
1. https://fonts.google.com/icons ته ورشئ
2. "health" یا "heart" search کړئ
3. Download PNG
4. Resize to required sizes
```

### Option 2: د Flaticon کارول
```
1. https://flaticon.com ته ورشئ
2. "medical heart" یا "health care" search کړئ
3. Free icon download کړئ (PNG)
4. Resize using online tools
```

### Option 3: د IconScout کارول
```
1. https://iconscout.com ته ورشئ
2. Medical/Health icons browse کړئ
3. Free version download کړئ
4. Generate all sizes
```

---

## 🚀 د APK جوړولو وروسته

کله چې icons جوړ شول:

### د PWABuilder سره:
1. App deploy کړئ (Vercel/Netlify)
2. https://pwabuilder.com ته ورشئ
3. خپل URL داخل کړئ
4. "Start" کلیک وکړئ
5. **Icons به اوتومات detect شي** ✅
6. "Android" → "Generate APK"
7. APK download کړئ
8. Play Store ته upload کړئ

---

## 📞 د مرستې لپاره

که تاسو icons جوړولو کې مسله لرئ:
- Email: ibrahimkhaksar.it@gmail.com
- Phone: +93 783 040 441

یا زه کولی شم تاسو ته یو sample icon design درکړم!

---

## 🎉 بریا!

کله چې icons جوړ شول، ستاسو HealMate app به بشپړ د Play Store لپاره چمتو وي! 🚀

**د Icon جوړولو تر ټولو اسانه لاره:**
👉 https://pwabuilder.com/imageGenerator 👈

یوازې یو 512x512 PNG upload کړئ او ټول sizes download کړئ! 🎨
