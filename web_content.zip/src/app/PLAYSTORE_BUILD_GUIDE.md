# 🚀 HealMate - د Play Store لپاره APK جوړول
# راهنمای ساخت APK برای Play Store
# Play Store APK Build Guide

---

## 📋 **Prerequisites (لومړني اړتیاوې):**

```bash
✅ Node.js (v18+)
✅ npm or yarn
✅ Android Studio
✅ Java JDK 11+
✅ Capacitor CLI
✅ Play Store Developer Account ($25 one-time fee)
```

---

## 🛠️ **Method 1: Capacitor (Recommended) - توصیه شوې طریقه**

### **Step 1: Install Capacitor**

```bash
# د پروژې په فولډر کې
cd healmate-project

# Capacitor install
npm install @capacitor/core @capacitor/cli
npm install @capacitor/android

# Initialize Capacitor
npx cap init "HealMate" "com.healmate.afghanistan"
```

### **Step 2: Build React App**

```bash
# Build production version
npm run build
# یا
yarn build

# Build ورسته به تاسو ته یو "dist" فولډر ورکړي
```

### **Step 3: Add Android Platform**

```bash
# Android platform اضافه کړئ
npx cap add android

# د build شوي app Android ته کاپي کړئ
npx cap sync android

# Android Studio خلاص کړئ
npx cap open android
```

### **Step 4: Configure Android**

#### **android/app/build.gradle:**

```gradle
android {
    namespace "com.healmate.afghanistan"
    compileSdkVersion 34
    
    defaultConfig {
        applicationId "com.healmate.afghanistan"
        minSdkVersion 22
        targetSdkVersion 34
        versionCode 1
        versionName "1.0.0"
        
        // MultiDex support
        multiDexEnabled true
    }
    
    buildTypes {
        release {
            minifyEnabled true
            shrinkResources true
            proguardFiles getDefaultProguardFile('proguard-android-optimize.txt'), 'proguard-rules.pro'
            
            // Signing config
            signingConfig signingConfigs.release
        }
    }
    
    signingConfigs {
        release {
            storeFile file("healmate-keystore.jks")
            storePassword "YOUR_KEYSTORE_PASSWORD"
            keyAlias "healmate"
            keyPassword "YOUR_KEY_PASSWORD"
        }
    }
}

dependencies {
    implementation 'androidx.core:core:1.12.0'
    implementation 'androidx.appcompat:appcompat:1.6.1'
    implementation 'com.google.android.material:material:1.11.0'
    implementation 'androidx.multidex:multidex:2.0.1'
    
    // AdMob
    implementation 'com.google.android.gms:play-services-ads:22.6.0'
    
    // In-App Purchases
    implementation 'com.android.billingclient:billing:6.1.0'
}
```

#### **android/app/src/main/AndroidManifest.xml:**

```xml
<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android"
    package="com.healmate.afghanistan">

    <!-- Permissions -->
    <uses-permission android:name="android.permission.INTERNET" />
    <uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" />
    <uses-permission android:name="android.permission.ACCESS_FINE_LOCATION" />
    <uses-permission android:name="android.permission.ACCESS_COARSE_LOCATION" />
    <uses-permission android:name="android.permission.CAMERA" />
    <uses-permission android:name="android.permission.READ_EXTERNAL_STORAGE" />
    <uses-permission android:name="android.permission.WRITE_EXTERNAL_STORAGE" />
    <uses-permission android:name="android.permission.VIBRATE" />
    <uses-permission android:name="android.permission.WAKE_LOCK" />
    <uses-permission android:name="com.google.android.c2dm.permission.RECEIVE" />

    <application
        android:name=".MainApplication"
        android:allowBackup="true"
        android:icon="@mipmap/ic_launcher"
        android:label="@string/app_name"
        android:roundIcon="@mipmap/ic_launcher_round"
        android:supportsRtl="true"
        android:theme="@style/AppTheme"
        android:usesCleartextTraffic="false">

        <!-- Main Activity -->
        <activity
            android:name=".MainActivity"
            android:configChanges="orientation|keyboardHidden|keyboard|screenSize|locale|smallestScreenSize|screenLayout|uiMode"
            android:exported="true"
            android:label="@string/app_name"
            android:launchMode="singleTask"
            android:theme="@style/AppTheme.SplashScreen"
            android:windowSoftInputMode="adjustResize">
            
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
            
            <intent-filter>
                <action android:name="android.intent.action.VIEW" />
                <category android:name="android.intent.category.DEFAULT" />
                <category android:name="android.intent.category.BROWSABLE" />
                <data android:scheme="https" android:host="healmate.app" />
            </intent-filter>
        </activity>

        <!-- AdMob App ID -->
        <meta-data
            android:name="com.google.android.gms.ads.APPLICATION_ID"
            android:value="ca-app-pub-3940256099942544~3347511713"/>
        
        <!-- Firebase Cloud Messaging -->
        <service
            android:name=".FCMService"
            android:exported="false">
            <intent-filter>
                <action android:name="com.google.firebase.MESSAGING_EVENT" />
            </intent-filter>
        </service>

    </application>

</manifest>
```

### **Step 5: Generate Keystore (د لاسلیک کیلي جوړول)**

```bash
# د Android فولډر ته ورشئ
cd android/app

# Keystore جوړه کړئ
keytool -genkey -v -keystore healmate-keystore.jks \
  -keyalg RSA -keysize 2048 -validity 10000 \
  -alias healmate

# معلومات ولیکئ:
# - Password: خپل قوي پاسورډ
# - Name: Ibrahim Khaksar
# - Organizational Unit: HealMate
# - Organization: HealMate Afghanistan
# - City: Kabul
# - State: Kabul
# - Country Code: AF
```

**⚠️ IMPORTANT: د keystore او password محفوظ وساتئ! که له لاسه ورکړئ، نور به اپډیټونه نه شئ کولی!**

### **Step 6: Build APK**

```bash
# د Android فولډر ته ورشئ
cd android

# Release APK جوړ کړئ
./gradlew assembleRelease

# یا bundle (AAB) د Play Store لپاره
./gradlew bundleRelease

# APK به دلته وي:
# android/app/build/outputs/apk/release/app-release.apk

# AAB به دلته وي:
# android/app/build/outputs/bundle/release/app-release.aab
```

---

## 📦 **Method 2: PWA + TWA (Simpler)**

### **Step 1: Build PWA**

```bash
# Build production
npm run build

# PWA files چمتو دي:
# - manifest.json ✅
# - service-worker.js ✅
# - icons ✅
```

### **Step 2: Use Bubblewrap (Google's TWA Tool)**

```bash
# Bubblewrap install
npm install -g @bubblewrap/cli

# Initialize TWA project
bubblewrap init --manifest="https://your-domain.com/manifest.json"

# یا local:
bubblewrap init --manifest="file:///path/to/dist/manifest.json"

# Build APK
bubblewrap build

# APK به په folder کې وي
```

### **Step 3: Configure TWA**

#### **twa-manifest.json:**

```json
{
  "packageId": "com.healmate.afghanistan",
  "host": "your-domain.com",
  "name": "HealMate",
  "launcherName": "HealMate",
  "display": "standalone",
  "themeColor": "#3B82F6",
  "navigationColor": "#ffffff",
  "backgroundColor": "#ffffff",
  "enableNotifications": true,
  "startUrl": "/",
  "iconUrl": "https://your-domain.com/icon-512x512.png",
  "maskableIconUrl": "https://your-domain.com/icon-maskable-512x512.png",
  "signingKey": {
    "path": "./android.keystore",
    "alias": "healmate"
  },
  "appVersionName": "1.0.0",
  "appVersionCode": 1,
  "shortcuts": [
    {
      "name": "Doctors",
      "short_name": "Doctors",
      "url": "/?page=doctors",
      "icon": "https://your-domain.com/icon-doctor.png"
    }
  ],
  "enableSiteSettingsShortcut": true,
  "isChromeOSOnly": false
}
```

---

## 🎨 **App Icons & Assets**

### **Required Icon Sizes:**

```
📁 android/app/src/main/res/
├── mipmap-mdpi/
│   └── ic_launcher.png (48x48)
├── mipmap-hdpi/
│   └── ic_launcher.png (72x72)
├── mipmap-xhdpi/
│   └── ic_launcher.png (96x96)
├── mipmap-xxhdpi/
│   └── ic_launcher.png (144x144)
├── mipmap-xxxhdpi/
│   └── ic_launcher.png (192x192)
└── drawable/
    └── splash.png (1080x1920)
```

### **Tool to Generate Icons:**

```bash
# Online:
https://icon.kitchen/
https://makeappicon.com/
https://appicon.co/

# یا Manual:
# Photoshop, Figma, یا Canva استعمال کړئ
# 512x512 master icon جوړ کړئ
# بیا ټول سایزونه generate کړئ
```

---

## 📱 **Play Store Listing Requirements**

### **1. App Details:**

```
✅ App Name (30 chars):
   - پښتو: HealMate - روغتیا
   - English: HealMate - Health
   
✅ Short Description (80 chars):
   - پښتو: د افغانستان خلکو لپاره بشپړ روغتیا اپلیکیشن
   - English: Complete health app for Afghanistan

✅ Full Description (4000 chars):
   - د اپلیکیشن بشپړ تفصیل
   - Features لیست
   - د استعمال طریقه
   - Contact معلومات
```

### **2. Screenshots (Required):**

```
📱 Phone Screenshots:
   - Size: 1080x1920 یا 1080x2340
   - Min: 2 screenshots
   - Max: 8 screenshots
   - PNG or JPEG
   - د پښتو، دری، او English لپاره جلا

📱 Tablet Screenshots (Optional):
   - Size: 1920x1080 یا 2560x1440
   - Min: 1 screenshot
   - Max: 8 screenshots
```

### **3. Feature Graphic:**

```
📐 Size: 1024x500 pixels
   - PNG or JPEG
   - د app لوګو او tagline سره
   - Background: HealMate colors
```

### **4. App Icon:**

```
📐 Size: 512x512 pixels
   - PNG (32-bit)
   - Transparent background نه
   - د HealMate لوګو
```

### **5. Privacy Policy:**

```
✅ د Privacy Policy لینک اړین دی
✅ په website یا Google Docs کې
✅ پښتو، دری، او English کې
✅ د Google Play policies په مطابق
```

### **6. Content Rating:**

```
✅ د IARC questionnaire ډک کړئ
✅ Health & Medical app دی
✅ No ads to children
✅ PEGI 3 / Everyone
```

### **7. Target Audience:**

```
✅ Target Age: 18+
✅ Country: Afghanistan (او نور)
✅ Language: Pashto, Dari, English
```

---

## 🔐 **Play Store Submission Steps:**

### **1. Create Developer Account:**

```
1. ورشئ: https://play.google.com/console/
2. Sign in: ibrahimkhaksar.it@gmail.com
3. Pay: $25 (یو ځل)
4. معلومات ډک کړئ
5. Account تایید شي (24-48 ساعته)
```

### **2. Create New App:**

```
1. [Create app] Click کړئ
2. App name: HealMate
3. Default language: Pashto (ps)
4. App or game: App
5. Free or paid: Free (د premium subscriptions سره)
6. Declarations ټیک کړئ
7. [Create app] Click
```

### **3. Complete Store Listing:**

```
1. Store listing:
   ✅ App name
   ✅ Short description
   ✅ Full description
   ✅ App icon
   ✅ Feature graphic
   ✅ Phone screenshots
   ✅ App category: Medical
   ✅ Tags: health, medical, doctors
   ✅ Email: ibrahimkhaksar.it@gmail.com
   ✅ Privacy policy URL

2. Save draft
```

### **4. App Content:**

```
1. Privacy policy: لینک اضافه کړئ
2. Ads: Yes (AdMob)
3. Content rating: Complete questionnaire
4. Target audience: 18+
5. News app: No
6. COVID-19 contact tracing: No
7. Data safety: د form ډک کړئ:
   ✅ Location collected
   ✅ Personal info collected
   ✅ Health info collected
   ✅ Encrypted in transit
   ✅ Can request deletion
```

### **5. Release:**

```
1. Production → Create new release
2. Upload APK/AAB:
   - app-release.aab (Recommended)
   - یا app-release.apk
3. Release name: 1.0.0
4. Release notes:
   پښتو:
   - لومړنۍ نسخه
   - 250+ دوکتوران
   - 1500+ دواګانې
   - AI روغتیا مشورې
   
   English:
   - Initial release
   - 250+ doctors
   - 1500+ medicines
   - AI health consultation

5. [Review release]
6. [Start rollout to Production]
```

### **6. Review Process:**

```
⏰ Review time: 1-7 days
📧 Notification: ibrahimkhaksar.it@gmail.com ته
✅ Approved: App live!
❌ Rejected: Issues fix او resubmit
```

---

## 🎯 **Optimization Tips:**

### **1. Reduce APK Size:**

```gradle
// android/app/build.gradle

android {
    buildTypes {
        release {
            // Code shrinking
            minifyEnabled true
            shrinkResources true
            
            // Proguard
            proguardFiles getDefaultProguardFile('proguard-android-optimize.txt')
            
            // Split APKs
            splits {
                abi {
                    enable true
                    reset()
                    include 'armeabi-v7a', 'arm64-v8a', 'x86', 'x86_64'
                    universalApk false
                }
            }
        }
    }
}
```

### **2. Performance:**

```typescript
// Use lazy loading
const DoctorsList = lazy(() => import('./components/DoctorsList'));
const MedicineDatabase = lazy(() => import('./components/MedicineDatabase'));

// Optimize images
// Use WebP format
// Lazy load images
// Use thumbnails
```

### **3. SEO & ASO:**

```
✅ Keywords:
   - health app afghanistan
   - afghan doctors
   - medicine guide dari pashto
   - روغتیا اپلیکیشن
   - د دوکتورانو لټون
   
✅ Title optimization:
   HealMate: Doctors & Medicine | Afghanistan
   
✅ Description keywords:
   - دوکتوران، روغتونونه، درمل
   - doctors, hospitals, medicine
   - health tips, first aid
```

---

## 📊 **Testing Before Release:**

### **Internal Testing:**

```bash
# د Android Studio څخه:
1. [Build] → [Build Bundle(s) / APK(s)] → [Build APK(s)]
2. Install په phone کې:
   adb install app-release.apk
3. Test کړئ:
   ✅ All features work
   ✅ No crashes
   ✅ Good performance
   ✅ All languages
   ✅ AdMob shows
   ✅ Premium purchase works
```

### **Play Console Internal Testing:**

```
1. Testing → Internal testing
2. Create release
3. Upload APK/AAB
4. Add testers (emails)
5. Send test link
6. Collect feedback
7. Fix issues
8. Update
```

---

## 🚨 **Common Issues & Solutions:**

### **1. Keystore Lost:**

```
❌ Problem: Keystore file ورک شو
✅ Solution: نوی اپلیکیشن جوړ کړئ د نوي package name سره
⚠️ Prevention: Keystore backup په Google Drive یا USB
```

### **2. APK Size Too Large:**

```
❌ Problem: APK 100MB+ دی
✅ Solutions:
   - Enable code shrinking
   - Optimize images (WebP)
   - Remove unused libraries
   - Use App Bundle (AAB) instead
   - Split APKs by ABI
```

### **3. App Rejected:**

```
❌ Common Reasons:
   - Privacy policy missing
   - Screenshots not clear
   - Description misleading
   - Permissions not justified
   - Medical claims unverified
   
✅ Solution: د email instructions follow او resubmit کړئ
```

### **4. Build Errors:**

```bash
# Gradle sync failed
./gradlew clean
./gradlew build --refresh-dependencies

# Out of memory
# gradle.properties کې:
org.gradle.jvmargs=-Xmx4096m

# SDK not found
# Android Studio → SDK Manager → Install required SDKs
```

---

## 📱 **Alternative: PWA Only (No APK)**

### **If you want PWA without Play Store:**

```bash
# 1. Build PWA
npm run build

# 2. Deploy to hosting (Netlify, Vercel, Firebase)
# 3. Users can "Add to Home Screen"
# 4. Works like native app
# 5. No Play Store approval needed
# 6. Updates instantly (no app update)

Pros:
✅ No Play Store fees
✅ Instant updates
✅ Cross-platform
✅ No review process

Cons:
❌ Less discoverable
❌ No Play Store trust
❌ Limited native features
❌ Needs internet (mostly)
```

---

## 📞 **Support & Resources:**

```
📧 Play Console Support:
   https://support.google.com/googleplay/android-developer/

📚 Capacitor Docs:
   https://capacitorjs.com/docs

🎓 Android Developers:
   https://developer.android.com/

💬 Stack Overflow:
   https://stackoverflow.com/questions/tagged/capacitor

🎥 YouTube Tutorials:
   Search: "Capacitor Android build tutorial"
```

---

## ✅ **Complete Checklist:**

```
Development:                    ✅
├── React app built             ⏳
├── PWA manifest                ✅
├── Service worker              ✅
├── Icons ready                 ⏳
├── Testing complete            ⏳
└── No bugs                     ⏳

Capacitor Setup:                ⏳
├── Installed                   
├── Android added               
├── Configured                  
├── Built                       
└── Tested                      

Keystore:                       ⏳
├── Generated                   
├── Backed up                   
├── Configured in build.gradle  
└── Password saved              

APK/AAB:                        ⏳
├── Built successfully          
├── Signed                      
├── Optimized                   
├── Tested on device            
└── Ready for upload            

Play Store:                     ⏳
├── Developer account           
├── App created                 
├── Store listing complete      
├── Screenshots uploaded        
├── Privacy policy added        
├── Content rating done         
├── APK/AAB uploaded            
└── Submitted for review        

Post-Launch:                    ⏳
├── Monitor reviews             
├── Fix bugs                    
├── Add features                
├── Update regularly            
└── Respond to users            
```

---

## 🎉 **Final Summary:**

```
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
   HEALMATE → PLAY STORE
     د بشپړې راهنمایی
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Tools Needed:
✅ Node.js & npm
✅ Android Studio
✅ Capacitor
✅ Play Console Account ($25)

Build Process:
1️⃣ npm run build
2️⃣ npx cap add android
3️⃣ Generate keystore
4️⃣ ./gradlew assembleRelease
5️⃣ Upload to Play Console
6️⃣ Wait for approval (1-7 days)
7️⃣ App is LIVE! 🚀

Estimated Time:
- Setup: 2-3 hours
- First build: 1-2 hours
- Play Store listing: 2-3 hours
- Review: 1-7 days
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

TOTAL: ~1 week د لومړني release لپاره
Updates: ~1 day

Good luck! 🍀
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```

---

**🚀 تیاره یاست د HealMate Play Store ته publish کولو لپاره! هره مرحله follow کړئ او success به ومومئ! 💪📱✨**
