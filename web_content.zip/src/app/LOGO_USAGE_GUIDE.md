# 🎨 HealMate Logo Usage Guide
د ډاکټر ابراهیم خاکسار لخوا جوړ شوی

---

## 📍 د Logo استعمال ځایونه

### ✅ د Logo بشپړ استعمال شوی دی په:

#### 1. **Header Navigation** (`/App.tsx`)
```tsx
<Logo size="lg" showText={false} />
```
- د App د header کې په کیڼ اړخ کې
- Clickable - د home page ته بیرته ځي
- Size: Large (lg)

#### 2. **Loading Screen** (`/App.tsx - PageLoader`)
```tsx
<Logo size="2xl" showText={false} />
```
- د App د loading state کې
- د pulse animation سره
- Size: Extra Large (2xl)

#### 3. **Splash Screen** (`/components/SplashScreen.tsx`)
```tsx
<Logo size="2xl" showText={false} className="filter brightness-0 invert" />
```
- د App د لومړي launch کې
- د glassmorphism effects سره
- White version (inverted)
- Size: Extra Large (2xl)

#### 4. **Login/Signup Page** (`/components/AuthPage.tsx`)
```tsx
<Logo size="2xl" showText={false} className="filter brightness-0 invert" />
```
- د Authentication screen کې
- د gradient background پر
- White version (inverted)
- Size: Extra Large (2xl)

#### 5. **About Us Page** (`/components/AboutUs.tsx`)
```tsx
<Logo size="2xl" showText={false} />
```
- د About Us hero section کې
- د floating animation سره
- Size: Extra Large (2xl)

#### 6. **Sidebar Menu** (`/components/ModernSidebar.tsx`)
```tsx
<Logo size="sm" showText={false} />
```
- د Mobile sidebar header کې
- د glassmorphism box کې
- Size: Small (sm)

#### 7. **Android Splash Screen** (`/android/app/src/main/res/drawable/splash_screen.xml`)
```xml
<bitmap android:src="@drawable/healmate_logo" />
```
- د Android App د launch کې
- د gradient background سره

---

## 📏 د Logo Sizes

د Logo component په 6 sizes کې شته:

```tsx
type LogoSize = 'xs' | 'sm' | 'md' | 'lg' | 'xl' | '2xl';

// استعمال:
<Logo size="xs" />   // h-6  (24px)
<Logo size="sm" />   // h-8  (32px)
<Logo size="md" />   // h-10 (40px) - Default
<Logo size="lg" />   // h-12 (48px)
<Logo size="xl" />   // h-16 (64px)
<Logo size="2xl" />  // h-24 (96px)
```

---

## 🎨 د Logo Variants

### 1. د Text سره:
```tsx
<Logo size="md" showText={true} />
// HealMate logo + "HealMate" text
```

### 2. بغیر Text:
```tsx
<Logo size="md" showText={false} />
// یوازې HealMate logo
```

### 3. White Version (د تیارو backgrounds لپاره):
```tsx
<Logo 
  size="xl" 
  showText={false} 
  className="filter brightness-0 invert" 
/>
```

### 4. د Custom Styling سره:
```tsx
<Logo 
  size="lg" 
  showText={true}
  className="drop-shadow-2xl opacity-90"
/>
```

---

## 🔧 د Logo Component Props

```tsx
interface LogoProps {
  size?: 'xs' | 'sm' | 'md' | 'lg' | 'xl' | '2xl';  // Default: 'md'
  showText?: boolean;                                 // Default: true
  className?: string;                                 // Optional CSS classes
  onClick?: () => void;                              // Optional click handler
}
```

---

## 📱 د Android Resources

### د Android App لپاره د Logo Files:

```
/android/app/src/main/res/
├── drawable/
│   ├── healmate_logo.png         # د Splash screen لپاره
│   ├── splash_screen.xml         # د Splash screen drawable
│   └── ic_notification.png       # د Notifications لپاره
├── mipmap-mdpi/
│   ├── ic_launcher.png           # 48x48
│   └── ic_launcher_round.png     # 48x48
├── mipmap-hdpi/
│   ├── ic_launcher.png           # 72x72
│   └── ic_launcher_round.png     # 72x72
├── mipmap-xhdpi/
│   ├── ic_launcher.png           # 96x96
│   └── ic_launcher_round.png     # 96x96
├── mipmap-xxhdpi/
│   ├── ic_launcher.png           # 144x144
│   └── ic_launcher_round.png     # 144x144
└── mipmap-xxxhdpi/
    ├── ic_launcher.png           # 192x192
    └── ic_launcher_round.png     # 192x192
```

---

## 🌐 د PWA Icons

### د Progressive Web App لپاره:

```
/public/
├── healmate-logo.png             # د Web لپاره
├── icon-72x72.png
├── icon-96x96.png
├── icon-128x128.png
├── icon-144x144.png
├── icon-152x152.png
├── icon-192x192.png              # د PWA manifest
├── icon-384x384.png
├── icon-512x512.png              # د PWA manifest
└── manifest.json                 # د Icons reference
```

په `manifest.json` کې:
```json
{
  "icons": [
    {
      "src": "/icon-192x192.png",
      "sizes": "192x192",
      "type": "image/png",
      "purpose": "any maskable"
    },
    {
      "src": "/icon-512x512.png",
      "sizes": "512x512",
      "type": "image/png",
      "purpose": "any maskable"
    }
  ]
}
```

---

## 🎯 د استعمال لارښوونې

### ✅ Do's (د کولو کارونه):

1. ✅ **Logo په وضاحت سره استعمال کړئ**
   - د Logo کمز کم size 24px وي
   - د Logo د background contrast واضح وي

2. ✅ **د مناسب spacing استعمال کړئ**
   - د Logo شاوخوا کافي space وي
   - د Logo د size مطابق padding استعمال کړئ

3. ✅ **د Logo د colors محافظت وکړئ**
   - Original colors استعمال کړئ
   - که dark background وي نو white version استعمال کړئ

4. ✅ **د Logo responsive وي**
   - د مختلفو screen sizes لپاره مناسب size

### ❌ Don'ts (د نه کولو کارونه):

1. ❌ **Logo distort مه کوئ**
   - د Logo aspect ratio مه بدلوئ
   - Logo stretch یا squash مه کوئ

2. ❌ **د Logo colors مه بدلوئ**
   - Filters استعمال مه کوئ (سره له white version څخه)
   - د Logo colors مه بدلوئ

3. ❌ **Logo په کوچني size کې مه استعمالوئ**
   - د 16px څخه کوچنی size مه استعمالوئ
   - که ډېر کوچنی وي نو text پټ کړئ

4. ❌ **Logo په ګډوډ background کې مه واچوئ**
   - Background واضح وي
   - د Logo او background ترمنځ contrast واضح وي

---

## 🔄 د Logo تازه کول

که چیرې نوی logo ورکړل شي:

### 1. د Web لپاره:
```bash
# د نوي logo کاپي کول
cp new-logo.png /public/healmate-logo.png

# د PWA icons جوړول (د ImageMagick استعمال سره)
convert healmate-logo.png -resize 72x72 /public/icon-72x72.png
convert healmate-logo.png -resize 96x96 /public/icon-96x96.png
convert healmate-logo.png -resize 128x128 /public/icon-128x128.png
convert healmate-logo.png -resize 144x144 /public/icon-144x144.png
convert healmate-logo.png -resize 152x152 /public/icon-152x152.png
convert healmate-logo.png -resize 192x192 /public/icon-192x192.png
convert healmate-logo.png -resize 384x384 /public/icon-384x384.png
convert healmate-logo.png -resize 512x512 /public/icon-512x512.png
```

### 2. د Android لپاره:
```bash
# د Android icons جوړول
convert healmate-logo.png -resize 48x48 /android/app/src/main/res/mipmap-mdpi/ic_launcher.png
convert healmate-logo.png -resize 72x72 /android/app/src/main/res/mipmap-hdpi/ic_launcher.png
convert healmate-logo.png -resize 96x96 /android/app/src/main/res/mipmap-xhdpi/ic_launcher.png
convert healmate-logo.png -resize 144x144 /android/app/src/main/res/mipmap-xxhdpi/ic_launcher.png
convert healmate-logo.png -resize 192x192 /android/app/src/main/res/mipmap-xxxhdpi/ic_launcher.png
```

---

## 📊 د Logo د استعمال Summary

| Location | Component | Size | With Text | Background | Animation |
|----------|-----------|------|-----------|------------|-----------|
| **Header** | App.tsx | lg | No | Light | Scale on tap |
| **Loading** | App.tsx | 2xl | No | Light | Pulse |
| **Splash** | SplashScreen | 2xl | No | Gradient | Pulse + Float |
| **Auth Page** | AuthPage | 2xl | No | Gradient | Scale in |
| **About Us** | AboutUs | 2xl | No | Light | Float |
| **Sidebar** | ModernSidebar | sm | No | Light | Scale on hover |
| **Android Splash** | splash_screen.xml | 120dp | No | Gradient | None |

---

## 🎨 د Brand Guidelines

### د HealMate Brand Colors:
```css
Primary: #6366F1    (Indigo)
Secondary: #EC4899  (Pink)
Accent: #10B981     (Green)
```

### د Logo د استعمال Colors:
- **Primary Logo**: Original colors (د logo څخه)
- **White Logo**: د تیارو backgrounds لپاره
- **Monochrome**: د خاصو حالتونو لپاره

---

## 📞 د مرستې لپاره

که د logo په استعمال کې مسله وي:
- 📧 Email: ibrahimkhaksar.it@gmail.com
- 📱 WhatsApp: +93 779 494 512

---

د **ډاکټر ابراهیم خاکسار** لخوا جوړ شوی
HealMate - د افغانستان بشپړ روغتیایي اپلیکیشن
تاریخ: November 28, 2025
