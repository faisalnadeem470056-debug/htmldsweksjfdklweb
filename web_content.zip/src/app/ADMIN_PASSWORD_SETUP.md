# 🔐 د Admin Panel پاسورډ او Login لارښود
## Admin Panel Password & Login Guide

---

## 📋 د لومړي ځل Setup (First Time Setup)

### 🆕 د نوي Admin حساب جوړول (Creating New Admin Account)

که تاسو لومړی ځل Admin Panel کاروئ، نو باید نوی حساب جوړ کړئ:

#### 📝 مرحلې (Steps):

1. **اپلیکیشن خلاص کړئ** او **Settings** ته لاړ شئ
   
2. **"Admin Panel"** بټن کلیک کړئ
   
3. **"نوی حساب جوړ کړئ"** یا **"Create account"** کلیک کړئ
   
4. **د Owner ایمیل** ولیکئ:
   ```
   ibrahimkhaksar.it@gmail.com
   ```
   
5. **یو قوي پاسورډ** جوړ کړئ:
   - لږ تر لږه 6 حروف باید ولري
   - عددونه او خاص حروف استعمال کړئ
   - **مثال**: `HealMate2025!` یا `Admin@123456`
   
6. **پاسورډ بیا تایید کړئ** (همغه پاسورډ بیا ولیکئ)
   
7. **"ثبت کړئ"** یا **"Sign Up"** بټن کلیک کړئ

8. ✅ **بریالی!** اوس تاسو کولای شئ Login وکړئ

---

## 🔑 د روزانه Login کول (Daily Login)

د هرې ورځې لپاره چې تاسو Admin Panel ته لاسرسی غواړئ:

#### 📝 مرحلې (Steps):

1. **Settings** → **Admin Panel** ته لاړ شئ
   
2. **ایمیل** ولیکئ:
   ```
   ibrahimkhaksar.it@gmail.com
   ```
   
3. **پاسورډ** ولیکئ (هغه چې تاسو په Sign Up کې جوړ کړی)
   
4. **"ننوتل"** یا **"Login"** کلیک کړئ

5. ✅ Admin Panel به خلاص شي!

---

## 🔄 که پاسورډ هیر شوی وي (If You Forgot Password)

1. **"پاسورډ مو هیر شوی؟"** یا **"Forgot password?"** کلیک کړئ
   
2. **خپل ایمیل** ولیکئ:
   ```
   ibrahimkhaksar.it@gmail.com
   ```
   
3. **"لینک واستوئ"** یا **"Send Link"** کلیک کړئ
   
4. **خپل ایمیل چیک کړئ** (ibrahimkhaksar.it@gmail.com)
   
5. **د Reset Link** کلیک کړئ چې ایمیل کې راغلی
   
6. **نوی پاسورډ** تنظیم کړئ
   
7. **Login** وکړئ د نوي پاسورډ سره

---

## 🔒 امنیتي نکتې (Security Tips)

### ✅ قوي پاسورډ جوړول:
- **لږ تر لږه 8 حروف** استعمال کړئ
- **لوی او کوچني حروف** استعمال کړئ (A-Z, a-z)
- **عددونه** استعمال کړئ (0-9)
- **خاص حروف** استعمال کړئ (!@#$%^&*)

### ❌ د خطرناکو پاسورډونو مثالونه:
- `123456` ❌
- `password` ❌
- `admin` ❌
- `healmate` ❌

### ✅ د ښه پاسورډونو مثالونه:
- `HealMate@2025!` ✅
- `Admin$ecure123` ✅
- `AfgHealth#2025` ✅
- `MyStr0ng!Pass` ✅

---

## 🛡️ د لاسرسۍ محدودیت (Access Restriction)

### ⚠️ مهم یادښت:

یوازې **Owner Email** کولای شي Admin Panel ته لاسرسی ولري:

```
✅ ibrahimkhaksar.it@gmail.com
```

که بل څوک د نور ایمیل سره هڅه وکړي، دوی به دا خطا وګوري:

```
❌ تاسو د Admin Panel لاسرسی نه لرئ!
❌ شما به پنل ادمین دسترسی ندارید!
❌ You don't have access to Admin Panel!
```

---

## 📱 د Admin Panel فیچرونه (Admin Panel Features)

وروسته له Login څخه، تاسو کولای شئ:

✅ **کاروونکي** - د ټولو کاروونکو معلومات وګورئ او مدیریت یې کړئ
✅ **ډاکټران** - نوي ډاکټران اضافه کړئ او تغیر یې کړئ
✅ **درمل** - د درملو معلومات اضافه او update کړئ
✅ **کتابونه** - نوي کتابونه اپلوډ کړئ (اتوماتیک عکس جوړیږي)
✅ **روغتیایي مشورې** - د روغتیا مشورې شریکې کړئ
✅ **ټولنیز پوستونه** - د کاروونکو پوستونه تصویب یا رد کړئ
✅ **اعلانونه** - د ټولو کاروونکو لپاره notification واستوئ
✅ **AdMob تنظیمات** - د اعلاناتو سیسټم کنټرول کړئ

---

## 🆘 د مرستې معلومات (Help & Support)

### 📧 د اړیکې معلومات:

- **Email**: ibrahimkhaksar.it@gmail.com
- **Phone 1**: +93783040441
- **Phone 2**: +93779494512

### 🐛 که مسله وي:

1. **Firebase** یقیني کړئ چې بشپړ تنظیم شوی (FIREBASE_SETUP_GUIDE.md وګورئ)
2. **Internet** چیک کړئ چې کار کوي
3. **Browser Console** چیک کړئ (F12) د خطاګانو لپاره
4. **د پاسورډ Reset** هڅه وکړئ که Login کار نه کوي

---

## 📚 نور لارښودونه (More Guides)

- 📖 **FIREBASE_SETUP_GUIDE.md** - د Firebase تنظیم لارښود
- 📖 **HOW_TO_USE_ADMIN_PANEL.md** - د Admin Panel کارولو بشپړ لارښود
- 📖 **ADMIN_PANEL_GUIDE.md** - د Admin Panel ټول فیچرونه
- 📖 **ADMOB_SETUP.md** - د AdMob تنظیم لارښود

---

## ⚡ Quick Reference

### لومړی ځل:
```
Sign Up → ibrahimkhaksar.it@gmail.com → قوي پاسورډ جوړ کړئ → Login
```

### روزانه کارونه:
```
Settings → Admin Panel → Login → خپل کار وکړئ
```

### د پاسورډ Reset:
```
Forgot Password → ایمیل ولیکئ → Reset Link چیک کړئ → نوی پاسورډ تنظیم کړئ
```

---

**✨ د بریالیتوب سره ستاسو HealMate Admin Panel چمتو ده!**

د هر ډول پوښتنې یا مرستې لپاره، مهرباني وکړئ له موږ سره اړیکه ونیسئ.
