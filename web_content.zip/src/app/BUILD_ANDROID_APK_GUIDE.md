# 📱 د HealMate Android APK جوړول | Build Android APK Guide

---

## 🎯 دوه لارې | Two Methods

### ✅ **لاره 1: PWA (Progressive Web App)** - ګړندۍ او اسانه
### ✅ **لاره 2: Native Android APK (Capacitor)** - بشپړ Native

---

# 🚀 لاره 1: PWA - ګړندۍ لاره | Quick Method

## څه دی PWA؟

PWA (Progressive Web App) یو web application دی چې د native app په څیر کار کوي:
- ✅ د home screen ته install کیدای شي
- ✅ Offline کار کوي
- ✅ Push notifications
- ✅ د browser پرته خلاصیږي
- ✅ ګړندی او سبک

---

## د PWA Setup (بشپړ شوی ✅)

زموږ HealMate اوس یو بشپړ PWA دی:

### ✅ موجود فایلونه:
- `/public/manifest.json` - د App معلومات
- `/public/sw.js` - Service Worker د offline support لپاره
- `/index.html` - د install prompt سره
- `/public/icon-192.png` - د App icon (192x192)
- `/public/icon-512.png` - د App icon (512x512)

---

## څنګه Install کړئ PWA؟

### د Android لپاره:

1. **د Chrome Browser خلاص کړئ**
2. **HealMate ته لاړ شئ** (د خپل hosted URL)
3. **د Browser Menu (⋮) خلاص کړئ**
4. **"Add to Home screen" یا "Install app" انتخاب کړئ**
5. **Install کلیک کړئ**
6. ✅ **HealMate اوس په Home Screen کې دی!**

### د Desktop لپاره:

1. **د Chrome/Edge خلاص کړئ**
2. **HealMate ته لاړ شئ**
3. **د URL bar کې د Install icon (⊕) کلیک کړئ**
4. **Install کلیک کړئ**
5. ✅ **HealMate اوس د Desktop App دی!**

---

## د PWA ګټې:

✅ **هیڅ coding نه غواړي** - چمتو دی!  
✅ **د هر device لپاره** - Android, iOS, Desktop  
✅ **اتوماتیک updates** - د browser له لارې  
✅ **کوچنی حجم** - هیڅ download نه  
✅ **Offline support** - بې انټرنیټ کار کوي  

---

# 🔥 لاره 2: Native Android APK (Capacitor)

که تاسو یو ریښتیني `.apk` فایل غواړئ د Google Play Store لپاره:

---

## 📦 مخکې څه ته اړتیا لرئ؟

### 1. **Node.js** (موجود دی ✅)
```bash
node --version  # باید v16+ وي
```

### 2. **Android Studio**
- د https://developer.android.com/studio څخه Download کړئ
- د Android SDK install کړئ
- د Java JDK install کړئ (Android Studio سره راځي)

### 3. **Capacitor**
```bash
npm install @capacitor/core @capacitor/cli
npm install @capacitor/android
```

---

## 🛠️ د APK جوړولو ګامونه | Steps to Build APK

### مرحله 1: د Capacitor Initialize کړئ

```bash
# په HealMate folder کې:
npx cap init
```

**پوښتنې:**
- App name: `HealMate`
- App ID: `af.healmate.app`
- Web Dir: `dist`

---

### مرحله 2: د Production Build جوړ کړئ

```bash
npm run build
# یا
vite build
```

دا به ستاسو ټول React code د `/dist` folder کې compile کړي.

---

### مرحله 3: د Android Platform اضافه کړئ

```bash
npx cap add android
```

دا به د `/android` folder جوړ کړي د ټول Android project سره.

---

### مرحله 4: د Web Assets کاپي کړئ

```bash
npx cap sync
```

دا به ستاسو د `/dist` فایلونه د Android project ته کاپي کړي.

---

### مرحله 5: Android Studio خلاص کړئ

```bash
npx cap open android
```

Android Studio به د HealMate project سره خلاص شي.

---

### مرحله 6: د APK Build کړئ

په Android Studio کې:

#### د Debug APK لپاره (د Test لپاره):
```
Build → Build Bundle(s) / APK(s) → Build APK(s)
```

د APK موقعیت:
```
android/app/build/outputs/apk/debug/app-debug.apk
```

#### د Release APK لپاره (د Play Store لپاره):

**لومړی: د Keystore جوړ کړئ**

```bash
cd android/app

keytool -genkey -v -keystore healmate-release.keystore \
  -alias healmate -keyalg RSA -keysize 2048 -validity 10000

# پوښتنې ځواب کړئ:
# - Password: (یو قوي password)
# - Name: Ibrahim Khaksar
# - Organization: HealMate
# - City: Kabul
# - State: Kabul
# - Country: AF
```

**دویم: د gradle.properties اضافه کړئ**

په `/android/gradle.properties` کې:

```properties
HEALMATE_RELEASE_STORE_FILE=healmate-release.keystore
HEALMATE_RELEASE_KEY_ALIAS=healmate
HEALMATE_RELEASE_STORE_PASSWORD=your_keystore_password
HEALMATE_RELEASE_KEY_PASSWORD=your_key_password
```

**درېیم: د build.gradle Update کړئ**

په `/android/app/build.gradle` کې:

```gradle
android {
    ...
    signingConfigs {
        release {
            storeFile file(HEALMATE_RELEASE_STORE_FILE)
            storePassword HEALMATE_RELEASE_STORE_PASSWORD
            keyAlias HEALMATE_RELEASE_KEY_ALIAS
            keyPassword HEALMATE_RELEASE_KEY_PASSWORD
        }
    }
    buildTypes {
        release {
            signingConfig signingConfigs.release
            minifyEnabled false
            proguardFiles getDefaultProguardFile('proguard-android.txt'), 'proguard-rules.pro'
        }
    }
}
```

**څلورم: د Release APK Build کړئ**

```bash
cd android
./gradlew assembleRelease
```

د Release APK موقعیت:
```
android/app/build/outputs/apk/release/app-release.apk
```

---

## 📋 د APK معلومات

### د Debug APK:
- 📦 حجم: ~15-20 MB
- 🎯 استعمال: د Test او Development لپاره
- ⚠️ د Play Store لپاره نه

### د Release APK:
- 📦 حجم: ~10-15 MB (د ProGuard سره)
- 🎯 استعمال: د Production او Play Store لپاره
- ✅ Signed او Optimized

---

## 🚀 د Google Play Store Upload

### 1. د Google Play Console ته لاړ شئ
```
https://play.google.com/console
```

### 2. نوی App جوړ کړئ
- App name: HealMate
- Default language: English
- App or Game: App
- Free or Paid: Free

### 3. د App Information ډک کړئ
- Title: HealMate - Healthcare App for Afghanistan
- Short description: Connect with doctors, track health
- Full description: [بشپړ تفصیل]
- Category: Medical
- Contact email: ibrahimkhaksar.it@gmail.com
- Phone: +93783040441

### 4. Screenshots Upload کړئ
- د Mobile screenshots (2-8 تصاویر)
- د Tablet screenshots (optional)
- Feature graphic (1024x500)
- App icon (512x512)

### 5. د APK Upload کړئ
- د Production track انتخاب کړئ
- د Release APK upload کړئ
- د Version name او code مشخص کړئ

### 6. د Content Rating ډک کړئ
- Target age: Everyone
- Content type: Medical app

### 7. د Pricing او Distribution
- Price: Free
- Countries: ټول هیوادونه
- Contains ads: Yes (که AdMob لرئ)

### 8. Submit for Review
- د Review process 3-7 ورځې نیسي

---

## 🔄 د App Updates

کله چې تاسو د App کې تغیرات وکړئ:

```bash
# 1. د Production build جوړ کړئ
npm run build

# 2. د Capacitor sync کړئ
npx cap sync

# 3. نوی APK build کړئ
cd android && ./gradlew assembleRelease

# 4. نوی APK Play Store ته upload کړئ
```

---

## 🎨 د App Icon او Splash Screen

### د Icon لپاره:

1. **د icon-512.png تازه کړئ** په `/public/` کې
2. **Capacitor Asset Generator استعمال کړئ:**

```bash
npm install @capacitor/assets --save-dev
npx capacitor-assets generate --android
```

### د Splash Screen لپاره:

په `/android/app/src/main/res/` کې د `splash.png` اضافه کړئ:
- `drawable-mdpi/splash.png` (480x800)
- `drawable-hdpi/splash.png` (720x1280)
- `drawable-xhdpi/splash.png` (1080x1920)
- `drawable-xxhdpi/splash.png` (1440x2560)

---

## 🔐 د Security Considerations

### 1. د Firebase Config Secure کړئ

په `/android/app/google-services.json` کې د خپل Firebase config اضافه کړئ:

```bash
# د Firebase Console څخه download کړئ:
# Project Settings → General → Your apps → Android app
# Download google-services.json
```

### 2. د ProGuard فعال کړئ

په `/android/app/build.gradle` کې:

```gradle
buildTypes {
    release {
        minifyEnabled true
        shrinkResources true
        proguardFiles getDefaultProguardFile('proguard-android-optimize.txt'), 'proguard-rules.pro'
    }
}
```

### 3. د API Keys پټ کړئ

د `.env` فایل کې:
```env
VITE_FIREBASE_API_KEY=your_api_key
VITE_FIREBASE_AUTH_DOMAIN=your_auth_domain
```

په code کې:
```typescript
const apiKey = import.meta.env.VITE_FIREBASE_API_KEY;
```

---

## 📊 د APK Size Optimization

### 1. د Code Splitting

په `vite.config.ts` کې:

```typescript
export default {
  build: {
    rollupOptions: {
      output: {
        manualChunks: {
          vendor: ['react', 'react-dom'],
          firebase: ['firebase/app', 'firebase/auth', 'firebase/firestore']
        }
      }
    }
  }
}
```

### 2. د Images Optimization

```bash
npm install vite-plugin-imagemin --save-dev
```

### 3. د Bundle Analysis

```bash
npm install vite-bundle-visualizer --save-dev
npm run build
npx vite-bundle-visualizer
```

---

## 🐛 د عام مسلو حل | Troubleshooting

### ❌ "SDK location not found"

**حل:**
```bash
# په android/local.properties کې:
sdk.dir=/path/to/Android/sdk

# د Windows لپاره:
sdk.dir=C:\\Users\\YourName\\AppData\\Local\\Android\\sdk

# د Mac لپاره:
sdk.dir=/Users/YourName/Library/Android/sdk

# د Linux لپاره:
sdk.dir=/home/YourName/Android/Sdk
```

---

### ❌ "Gradle build failed"

**حل:**
```bash
cd android
./gradlew clean
./gradlew build
```

---

### ❌ "Execution failed for task ':app:mergeReleaseResources'"

**حل:**
```bash
# د duplicate resources مسله
# په android/app/build.gradle کې:
android {
    packagingOptions {
        exclude 'META-INF/DEPENDENCIES'
        exclude 'META-INF/LICENSE'
        exclude 'META-INF/LICENSE.txt'
        exclude 'META-INF/NOTICE'
        exclude 'META-INF/NOTICE.txt'
    }
}
```

---

### ❌ "App crashes on startup"

**حل:**
```bash
# Logcat چیک کړئ:
adb logcat | grep HealMate

# د capacitor.config.ts چیک کړئ
# د server URL سم کړئ
```

---

## 📱 د Testing لپاره

### د Physical Device کې Test کړئ:

```bash
# 1. USB Debugging فعال کړئ په phone کې
# Settings → About Phone → Build Number (7 ځله tap)
# Settings → Developer Options → USB Debugging

# 2. Device connect کړئ
adb devices

# 3. App install کړئ
adb install android/app/build/outputs/apk/debug/app-debug.apk

# 4. App run کړئ
adb shell am start -n af.healmate.app/.MainActivity
```

### د Emulator کې Test کړئ:

```bash
# د Android Studio کې:
# Tools → AVD Manager → Create Virtual Device
# انتخاب کړئ: Pixel 6, Android 13, x86_64

# Run کړئ:
npx cap run android
```

---

## 🎯 Quick Commands Summary

```bash
# د Production Build
npm run build

# د Capacitor Sync
npx cap sync

# د Android Studio خلاص کول
npx cap open android

# د Debug APK جوړول
cd android && ./gradlew assembleDebug

# د Release APK جوړول
cd android && ./gradlew assembleRelease

# د App Install کول (د USB سره)
adb install -r android/app/build/outputs/apk/release/app-release.apk

# د App Uninstall کول
adb uninstall af.healmate.app

# د Logcat لیدل
adb logcat | grep HealMate
```

---

## 📞 د مرستې معلومات | Support

که مسله وي:

- 📧 Email: ibrahimkhaksar.it@gmail.com
- 📱 Phone 1: +93783040441
- 📱 Phone 2: +93779494512

---

## ✅ Final Checklist

د APK جوړولو مخکې:

- [ ] Node.js installed (v16+)
- [ ] Android Studio installed
- [ ] Java JDK installed
- [ ] Capacitor installed (`npm i @capacitor/cli @capacitor/android`)
- [ ] Firebase config setup (`google-services.json`)
- [ ] Icons prepared (192x192, 512x512)
- [ ] Splash screens prepared
- [ ] `npm run build` بریالۍ کار کوي
- [ ] `capacitor.config.ts` سم تنظیم شوی
- [ ] Keystore جوړ شوی (د release لپاره)
- [ ] Testing په physical device یا emulator

---

## 🎉 نتیجه | Conclusion

### د PWA لپاره:
✅ **چمتو دی!** - یوازې host کړئ او install کړئ

### د Native APK لپاره:
✅ **ټول setup بشپړ دی** - د پورتنیو ګامونو تعقیب وکړئ

---

**🚀 ستاسو HealMate اوس د Android APK جوړولو لپاره چمتو دی!**

**د بریالیتوب سره، HealMate Development Team** 💚
