# 🚀 HealMate Admin Panel - Quick Reference
## د Admin Panel چټک لارښود

---

## 🔑 د لاسرسۍ معلومات

### Owner Email
```
ibrahimkhaksar.it@gmail.com
```

⚠️ **یوازې دا email د Admin Panel ته لاسرسی لري!**

---

## 📱 د Admin Panel ته څنګه ورسیږو؟

### قدم 1: Login
```
1. د Owner email سره HealMate ته Login وکړئ
2. د اصلي اپلیکیشن HomePage باندې به وي
```

### قدم 2: Settings ته ورتلل
```
1. د لاندې menu کې "Settings" ⚙️ کلیک کړئ
2. Settings صفحه باندې به وي
```

### قدم 3: Admin Panel خلاصول
```
1. Scroll کړئ او "Admin Panel" کارډ ومومئ
   (یوازې Owner ته ښکاره کیږي)
2. "Open Admin Panel" بټن کلیک کړئ
```

### قدم 4: د لومړي ځل Setup
```
که لومړی ځل دی:
1. "Create account" غوره کړئ
2. Email: ibrahimkhaksar.it@gmail.com
3. Password: [خپل مضبوط پاسورډ]
4. Confirm Password: [همدا پاسورډ]
5. "Sign Up" کلیک کړئ
6. بیا "Login" وکړئ
```

---

## 🎯 د Admin Panel Tabs

### 1️⃣ Dashboard
```
📊 Statistics:
- Total Users
- Total Doctors  
- Total Medicines
- Total Revenue
```

### 2️⃣ Admins
```
👥 Manage Admin Users:
- د Admin لیست
- نوی Admin اضافه کول
- Status بدلول
- پاسورډ بیا تنظیم کول
- Admin حذف کول
```

### 3️⃣ Users
```
👨‍👩‍👧‍👦 Manage Regular Users:
- د کاروونکو لیست
- Email, Phone لیدل
- Status بدلول
- Edit/Delete
```

### 4️⃣ Doctors
```
🩺 Manage Doctors:
- د ډاکټرانو لیست
- Specialty, Experience
- Rating لیدل
- Status بدلول
```

### 5️⃣ Medicines
```
💊 Manage Medicines:
- د درملو لیست
- بیه, Stock
- Category
- Status بدلول
```

### 6️⃣ AdMob
```
💰 AdMob Configuration:
- Android IDs (4 Types)
- iOS IDs (4 Types)
- Test Mode ON/OFF
- Show Ads ON/OFF
- Daily Limit تنظیم
```

### 7️⃣ Settings
```
⚙️ Admin Settings:
- پاسورډ بدلول
- ایمیل بدلول
- Admin معلومات
```

---

## 💰 د AdMob IDs Types

### Android IDs
```
1. App ID
2. Banner Ad ID
3. Interstitial Ad ID
4. Rewarded Ad ID
```

### iOS IDs
```
1. App ID
2. Banner Ad ID
3. Interstitial Ad ID  
4. Rewarded Ad ID
```

---

## 🧪 د Test Mode

### Test Mode فعالول
```
1. AdMob Tab ته ورشئ
2. Test Mode = ON
3. "Save Changes" کلیک کړئ
```

### د Google Test IDs
```
Android:
- App: ca-app-pub-3940256099942544~3347511713
- Banner: ca-app-pub-3940256099942544/6300978111
- Interstitial: ca-app-pub-3940256099942544/1033173712
- Rewarded: ca-app-pub-3940256099942544/5224354917

iOS:
- App: ca-app-pub-3940256099942544~1458002511
- Banner: ca-app-pub-3940256099942544/2934735716
- Interstitial: ca-app-pub-3940256099942544/4411468910
- Rewarded: ca-app-pub-3940256099942544/1712485313
```

---

## 🔐 د امنیت Tips

### ✅ باید وکړئ
```
✓ مضبوط پاسورډ وکاروئ (12+ characters)
✓ خپل credentials هیڅ چا سره شریک مه کوئ
✓ کله چې کار بشپړ شي Logout وکړئ
✓ منظمه توګه پاسورډ بدل کړئ
```

### ❌ نباید وکړئ
```
✗ په public computers کې Login مه کوئ
✗ د پاسورډ screenshot مه واخلئ
✗ Browser کې password save مه کړئ
✗ Test Mode په production کې فعال مه پریږدئ
```

---

## 🆘 د عام مسلو حل

### مسله 1: Admin Panel نه لیدل کیږي
```
حل:
1. چیک کړئ چې په Owner email سره Login شوي یاست
2. Settings صفحه refresh کړئ
3. Browser cache صاف کړئ
```

### مسله 2: Login کار نه کوي
```
حل:
1. Email spell چیک کړئ (ibrahimkhaksar.it@gmail.com)
2. Password سم ولیکئ
3. که هیر شوی وي "Forgot password?" غوره کړئ
```

### مسله 3: پاسورډ هیر شوی
```
حل:
1. "Forgot password?" کلیک کړئ
2. Owner email داخل کړئ
3. خپل ایمیل چیک کړئ
4. د Reset لینک باندې کلیک کړئ
5. نوی پاسورډ تنظیم کړئ
```

### مسله 4: AdMob تنظیمات خوندي نه کیږي
```
حل:
1. ټول IDs داخل کړئ
2. "Save Changes" کلیک کړئ
3. Success message انتظار وکړئ
4. Browser refresh کړئ
5. Admin Panel بیا خلاص کړئ
```

---

## 📞 د مرستې معلومات

### Contact Information
```
📧 Email: ibrahimkhaksar.it@gmail.com
📱 Phone: +93783040441
📱 Phone: +93779494512
```

### Documentation Files
```
📄 HOW_TO_USE_ADMIN_PANEL.md       # بشپړ لارښود
📄 ADMIN_CONFIG_GUIDE.md           # Configuration لارښود
📄 ADMIN_PANEL_IMPLEMENTATION.md   # Technical details
📄 ADMIN_QUICK_REFERENCE.md        # دا فایل (چټک reference)
```

---

## ✅ د روزانه Checklist

### د ورځې پیل کې
```
☐ Admin Panel ته Login کړئ
☐ Dashboard statistics چیک کړئ
☐ د نویو Users لیدل
☐ د Pending doctors تایید
☐ د Medicines stock چیک
```

### د ورځې پای کې
```
☐ د Stats review
☐ د تنظیماتو backup
☐ Admin Panel څخه Logout
```

---

## 🎯 د لنډ Commands

### Navigation
```
Home → Settings → Admin Panel → [Tab Name]
```

### د AdMob تنظیمات
```
Admin Panel → AdMob Tab → [Edit IDs] → Save Changes
```

### د Admin اضافه کول
```
Admin Panel → Admins Tab → Add Admin → [Fill Form] → Add
```

### د پاسورډ بدلول
```
Admin Panel → Settings Tab → Change Password → [Fill Form] → Save
```

---

## 💡 Pro Tips

### 1. د IDs کاپي کول
```
💡 د AdMob Console څخه یو ځل کې ټول IDs copy کړئ
   د Notepad کې paste کړئ
   بیا Admin Panel ته داخل کړئ
```

### 2. د تنظیماتو Backup
```
💡 د AdMob IDs screenshot واخلئ
   په خوندي ځای کې save کړئ
   په هنګامي حالاتو کې ګټور دی
```

### 3. د Testing Strategy
```
💡 لومړی د Test Mode سره ټیسټ کړئ
   وروسته Production IDs داخل کړئ
   آخر کې Test Mode OFF کړئ
```

---

## 🌐 د ژبې بدلول

Admin Panel په دریو ژبو کې کار کوي:

```
🇦🇫 پښتو (Pashto)
🇦🇫 دری (Dari)
🇬🇧 English
```

د ژبې بدلولو لپاره:
```
Home Screen → Language Selector → [Choose Language]
```

---

## ✨ آخري یادونه

```
✅ Admin Panel یوازې Owner ته ښکاره کیږي
✅ د Firebase سره وصل دی
✅ ټول تنظیمات خوندي کیږي
✅ Multi-language support
✅ Production-ready
```

**د افغانستان لومړنی بشپړ روغتیا اپلیکیشن! 🇦🇫💚**

---

Made with ❤️ by HealMate Team
Last Updated: 2025-01-17
