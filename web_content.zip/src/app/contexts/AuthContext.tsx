import { createContext, useContext, useState, useEffect, ReactNode } from "react";
import { toast } from "sonner@2.0.3";
import { firebaseManager } from "../utils/FirebaseManager";

interface User {
  id: string;
  email: string;
  name: string;
  phone?: string;
  avatar?: string;
  createdAt: string;
  role?: 'owner' | 'admin' | 'doctor' | 'user';
  isPremium?: boolean;
  premiumExpiryDate?: string;
}

interface AuthContextType {
  user: User | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  login: (email: string, password: string) => Promise<{ success: boolean; error?: string }>;
  signup: (name: string, email: string, password: string, phone?: string) => Promise<{ success: boolean; error?: string }>;
  logout: () => void;
  resetPassword: (email: string) => Promise<{ success: boolean; error?: string }>;
  updateProfile: (updates: Partial<User>) => Promise<void>;
  isFirebaseMode: () => boolean;
  syncToFirebase: () => Promise<void>;
  syncFromFirebase: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  // د LocalStorage څخه د user session چیک کړئ
  useEffect(() => {
    const checkUserSession = () => {
      try {
        const storedUser = localStorage.getItem('healmate_user_session');
        
        if (storedUser) {
          const userData = JSON.parse(storedUser);
          setUser(userData);
        } else {
          setUser(null);
        }
      } catch (error) {
        console.error('Session check error:', error);
        setUser(null);
      } finally {
        setIsLoading(false);
      }
    };

    checkUserSession();
  }, []);

  // Login Function - د Firebase او LocalStorage دواړو ملاتړ
  const login = async (email: string, password: string): Promise<{ success: boolean; error?: string }> => {
    try {
      const trimmedEmail = email.trim().toLowerCase();
      
      // د FirebaseManager استعمال
      const userData = await firebaseManager.signIn(trimmedEmail, password);
      
      // د session معلومات ذخیره کړئ
      localStorage.setItem('healmate_user_session', JSON.stringify(userData));
      setUser(userData);
      
      return { success: true };
      
    } catch (error: any) {
      console.error('Login error:', error);
      return { 
        success: false, 
        error: error.message || 'An error occurred during login' 
      };
    }
  };

  // Sign Up Function - د Firebase او LocalStorage دواړو ملاتړ
  const signup = async (name: string, email: string, password: string, phone?: string): Promise<{ success: boolean; error?: string }> => {
    try {
      const trimmedEmail = email.trim().toLowerCase();
      
      // د FirebaseManager استعمال
      const userData = await firebaseManager.signUp(trimmedEmail, password, name.trim(), phone?.trim());
      
      // د session معلومات ذخیره کړئ
      localStorage.setItem('healmate_user_session', JSON.stringify(userData));
      setUser(userData);
      
      return { success: true };
      
    } catch (error: any) {
      console.error('Signup error:', error);
      return { 
        success: false, 
        error: error.message || 'An error occurred during signup' 
      };
    }
  };

  // Logout Function
  const logout = async () => {
    try {
      await firebaseManager.signOut();
      setUser(null);
      toast.success('Logged out successfully');
    } catch (error) {
      console.error('Logout error:', error);
      toast.error('Error logging out');
    }
  };

  // Reset Password Function
  const resetPassword = async (email: string): Promise<{ success: boolean; error?: string }> => {
    try {
      const trimmedEmail = email.trim().toLowerCase();
      
      await firebaseManager.resetPassword(trimmedEmail);
      
      toast.success('Password reset info sent!');
      
      return { success: true };
      
    } catch (error: any) {
      console.error('Reset password error:', error);
      return { 
        success: false, 
        error: error.message || 'An error occurred during password reset' 
      };
    }
  };

  // Update Profile Function
  const updateProfile = async (updates: Partial<User>): Promise<void> => {
    try {
      if (!user) {
        throw new Error('No user logged in');
      }

      // د FirebaseManager سره update کړئ
      await firebaseManager.updateUserProfile(user.id, updates);
      
      // د user معلومات update کړئ
      const updatedUser = { ...user, ...updates };
      
      // د LocalStorage کې update کړئ
      localStorage.setItem('healmate_user_session', JSON.stringify(updatedUser));
      
      setUser(updatedUser);
      toast.success('Profile updated successfully');
      
    } catch (error: any) {
      console.error('Update profile error:', error);
      toast.error('Error updating profile');
      throw error;
    }
  };

  // د Firebase mode چیک کړئ
  const isFirebaseMode = (): boolean => {
    return firebaseManager.isFirebaseAvailable();
  };

  // د LocalStorage څخه Firebase ته sync کړئ
  const syncToFirebase = async (): Promise<void> => {
    try {
      await firebaseManager.syncToFirebase();
      toast.success('Data synced to Firebase successfully!');
    } catch (error: any) {
      console.error('Sync to Firebase error:', error);
      toast.error('Failed to sync to Firebase');
      throw error;
    }
  };

  // د Firebase څخه LocalStorage ته sync کړئ
  const syncFromFirebase = async (): Promise<void> => {
    try {
      await firebaseManager.syncFromFirebase();
      toast.success('Data synced from Firebase successfully!');
    } catch (error: any) {
      console.error('Sync from Firebase error:', error);
      toast.error('Failed to sync from Firebase');
      throw error;
    }
  };

  const value: AuthContextType = {
    user,
    isAuthenticated: !!user,
    isLoading,
    login,
    signup,
    logout,
    resetPassword,
    updateProfile,
    isFirebaseMode,
    syncToFirebase,
    syncFromFirebase
  };

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}