import { createContext, useContext, useState, useEffect, ReactNode } from "react";

type Language = "en" | "ps" | "fa";

interface LanguageContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  t: (key: string) => string;
  dir: "ltr" | "rtl";
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

export function LanguageProvider({ children }: { children: ReactNode }) {
  const [language, setLanguageState] = useState<Language>(() => {
    const saved = localStorage.getItem("language");
    return (saved as Language) || "ps"; // Default to Pashto
  });

  useEffect(() => {
    localStorage.setItem("language", language);
    // Set document direction and language
    document.documentElement.dir = language === "en" ? "ltr" : "rtl";
    document.documentElement.lang = language;
  }, [language]);

  const setLanguage = (lang: Language) => {
    setLanguageState(lang);
  };

  const t = (key: string): string => {
    return translations[language]?.[key] || translations.en[key] || key;
  };

  const dir = language === "en" ? "ltr" : "rtl";

  return (
    <LanguageContext.Provider value={{ language, setLanguage, t, dir }}>
      {children}
    </LanguageContext.Provider>
  );
}

export function useLanguage() {
  const context = useContext(LanguageContext);
  if (!context) {
    throw new Error("useLanguage must be used within LanguageProvider");
  }
  return context;
}

// Translations
const translations: Record<Language, Record<string, string>> = {
  en: {
    // App Name
    app_name: "HealMate",
    app_tagline: "Your Complete Health Companion",
    
    // Common
    home: "Home",
    back: "Back",
    next: "Next",
    cancel: "Cancel",
    save: "Save",
    delete: "Delete",
    edit: "Edit",
    view: "View",
    close: "Close",
    search: "Search",
    filter: "Filter",
    loading: "Loading...",
    no_data: "No data available",
    error: "Error occurred",
    success: "Success",
    submit: "Submit",
    confirm: "Confirm",
    download: "Download",
    share: "Share",
    
    // Navigation
    services: "Services",
    medicines: "Medicines",
    health_tips: "Health Tips",
    settings: "Settings",
    about_us: "About Us",
    contact_us: "Contact Us",
    privacy_policy: "Privacy Policy",
    terms_conditions: "Terms & Conditions",
    doctors: "Doctors",
    posts: "Posts",
    community: "Community",
    books: "Books",
    
    // Hero Section
    hero_title: "Your Complete Health Platform",
    hero_subtitle: "Professional healthcare services in Afghanistan",
    get_started: "Get Started",
    learn_more: "Learn More",
    
    // Services
    find_doctor: "Find Doctor",
    find_doctor_desc: "Connect with certified doctors",
    book_appointment: "Book Appointment",
    book_appointment_desc: "Schedule your consultation",
    lab_tests: "Lab Tests",
    lab_tests_desc: "Book tests and get results",
    medicine_reminder: "Medicine Reminder",
    medicine_reminder_desc: "Never miss your medication",
    health_records: "Health Records",
    health_records_desc: "Manage your medical history",
    emergency: "Emergency",
    emergency_desc: "24/7 emergency services",
    
    // Medicines
    medicines_database: "Medicines Database",
    search_medicine: "Search medicine...",
    medicine_name: "Medicine Name",
    generic_name: "Generic Name",
    category: "Category",
    price: "Price",
    manufacturer: "Manufacturer",
    dosage: "Dosage",
    side_effects: "Side Effects",
    precautions: "Precautions",
    interactions: "Drug Interactions",
    storage: "Storage",
    view_details: "View Details",
    
    // Doctors
    doctors_list: "Doctors List",
    specialty: "Specialty",
    experience: "Experience",
    rating: "Rating",
    available: "Available",
    consultation_fee: "Consultation Fee",
    book_now: "Book Now",
    view_profile: "View Profile",
    
    // Lab Tests
    book_lab_test: "Book Lab Test",
    test_name: "Test Name",
    test_price: "Test Price",
    sample_required: "Sample Required",
    result_time: "Result Time",
    booking_date: "Booking Date",
    booking_time: "Booking Time",
    view_results: "View Results",
    download_report: "Download Report",
    
    // Medicine Reminder
    add_reminder: "Add Reminder",
    medicine: "Medicine",
    frequency: "Frequency",
    time: "Time",
    duration: "Duration",
    daily: "Daily",
    weekly: "Weekly",
    morning: "Morning",
    afternoon: "Afternoon",
    evening: "Evening",
    night: "Night",
    
    // Health Dashboard
    health_dashboard: "Health Dashboard",
    heart_rate: "Heart Rate",
    blood_pressure: "Blood Pressure",
    temperature: "Temperature",
    weight: "Weight",
    height: "Height",
    bmi: "BMI",
    blood_sugar: "Blood Sugar",
    oxygen_level: "Oxygen Level",
    
    // Family Profiles
    family_profiles: "Family Profiles",
    add_member: "Add Family Member",
    member_name: "Member Name",
    relationship: "Relationship",
    age: "Age",
    gender: "Gender",
    male: "Male",
    female: "Female",
    blood_group: "Blood Group",
    
    // E-Pharmacy
    e_pharmacy: "E-Pharmacy",
    add_to_cart: "Add to Cart",
    cart: "Cart",
    checkout: "Checkout",
    total: "Total",
    delivery_address: "Delivery Address",
    payment_method: "Payment Method",
    place_order: "Place Order",
    
    // Health Insurance
    health_insurance: "Health Insurance",
    insurance_provider: "Insurance Provider",
    policy_number: "Policy Number",
    coverage: "Coverage",
    expiry_date: "Expiry Date",
    upload_card: "Upload Insurance Card",
    check_coverage: "Check Coverage",
    
    // Doctor Chat
    doctor_chat: "Doctor Chat",
    type_message: "Type your message...",
    send: "Send",
    voice_message: "Voice Message",
    attach_file: "Attach File",
    upload_prescription: "Upload Prescription",
    upload_test_results: "Upload Test Results",
    upload_image: "Upload Image",
    
    // Video Consultation
    video_consultation: "Video Consultation",
    start_call: "Start Video Call",
    join_call: "Join Call",
    end_call: "End Call",
    camera: "Camera",
    microphone: "Microphone",
    screen_share: "Screen Share",
    
    // Symptoms Tracker
    symptoms_tracker: "Symptoms Tracker",
    add_entry: "Add Entry",
    pain_level: "Pain Level",
    mood: "Mood",
    happy: "Happy",
    neutral: "Neutral",
    sad: "Sad",
    notes: "Notes",
    generate_report: "Generate Report",
    
    // AI Health Assistant
    ai_health_assistant: "AI Health Assistant",
    ai_chat: "AI Chat",
    symptom_checker: "Symptom Checker",
    analyze_symptoms: "Analyze Symptoms",
    risk_level: "Risk Level",
    low_risk: "Low Risk",
    medium_risk: "Medium Risk",
    high_risk: "High Risk",
    recommendations: "Recommendations",
    suggested_doctors: "Suggested Doctors",
    
    // Emergency
    emergency_hotline: "Emergency Hotline",
    call_ambulance: "Call Ambulance",
    nearest_hospital: "Nearest Hospital",
    emergency_contacts: "Emergency Contacts",
    
    // Contact
    phone: "Phone",
    email: "Email",
    address: "Address",
    send_message: "Send Message",
    your_name: "Your Name",
    your_email: "Your Email",
    your_message: "Your Message",
    
    // Settings
    language: "Language",
    notifications: "Notifications",
    theme: "Theme",
    account: "Account",
    logout: "Logout",
    
    // Status
    online: "Online",
    offline: "Offline",
    active: "Active",
    inactive: "Inactive",
    pending: "Pending",
    completed: "Completed",
    cancelled: "Cancelled",
    
    // Time
    today: "Today",
    yesterday: "Yesterday",
    tomorrow: "Tomorrow",
    this_week: "This Week",
    this_month: "This Month",
    
    // Days
    monday: "Monday",
    tuesday: "Tuesday",
    wednesday: "Wednesday",
    thursday: "Thursday",
    friday: "Friday",
    saturday: "Saturday",
    sunday: "Sunday",
    
    // Medical Specialties
    cardiologist: "Cardiologist",
    dermatologist: "Dermatologist",
    pediatrician: "Pediatrician",
    neurologist: "Neurologist",
    orthopedic: "Orthopedic",
    gynecologist: "Gynecologist",
    general_physician: "General Physician",
    dentist: "Dentist",
    
    // HomeScreen Specific
    good_morning: "Good Morning",
    good_afternoon: "Good Afternoon",
    good_evening: "Good Evening",
    good_night: "Good Night",
    start_day_health: "Start your day with health",
    take_care_health: "Take care of your health",
    your_health_companion: "Your health companion",
    rest_well_healthy: "Rest well, stay healthy",
    search_doctors_medicines: "Search doctors, medicines, services...",
    appointments_stat: "Appointments",
    prescriptions_stat: "Prescriptions",
    health_score: "Health Score",
    this_week_change: "this week",
    active_status: "active",
    excellent_status: "Excellent",
    quick_actions: "Quick Actions",
    access_health_instantly: "Access health services instantly",
    find_doctors: "Find Doctors",
    video_call: "Video Call",
    online_consultation: "Online consultation",
    browse_pharmacy: "Browse pharmacy",
    schedule_visits: "Schedule visits",
    daily_health_advice: "Daily health advice",
    help_24_7: "24/7 Help",
    top_doctors: "Top Doctors",
    connect_specialists: "Connect with our best specialists",
    view_all: "View All",
    patients_count: "patients",
    years_exp: "years",
    daily_health_tips: "Daily Health Tips",
    stay_hydrated: "Stay Hydrated",
    drink_water_daily: "Drink 8 glasses of water daily",
    regular_exercise: "Regular Exercise",
    minutes_daily: "30 minutes daily activity",
    healthy_diet: "Healthy Diet",
    eat_fruits_vegetables: "Eat fruits and vegetables",
    emergency_helpline: "Emergency Helpline",
    call_now: "Call Now",
    health_categories: "Health Categories",
    explore: "Explore",
    cardiology: "Cardiology",
    neurology: "Neurology",
    orthopedics: "Orthopedics",
    general: "General",
  },
  
  ps: {
    // App Name
    app_name: "هیلمیټ",
    app_tagline: "ستاسو بشپړ روغتیایي ملګری",
    
    // Common
    home: "کور",
    back: "بیرته",
    next: "راتلونکی",
    cancel: "لغوه کول",
    save: "خوندي کول",
    delete: "حذف کول",
    edit: "سمول",
    view: "کتل",
    close: "بندول",
    search: "لټون",
    filter: "فلټر",
    loading: "بار کیږي...",
    no_data: "معلومات شته نه دي",
    error: "تېروتنه رامنځته شوه",
    success: "بریالي",
    submit: "واستوئ",
    confirm: "تایید",
    download: "ډاونلوډ",
    share: "شریک کول",
    
    // Navigation
    services: "خدمتونه",
    medicines: "درمل",
    health_tips: "روغتیایي مشورې",
    settings: "تنظیمات",
    about_us: "زموږ په اړه",
    contact_us: "موږ سره اړیکه",
    privacy_policy: "د محرمیت تګلاره",
    terms_conditions: "شرایط او احکام",
    doctors: "ډاکټران",
    posts: "پوستونه",
    community: "ټولنه",
    books: "کتابونه",
    
    // Hero Section
    hero_title: "ستاسو بشپړ روغتیایي پلیټفارم",
    hero_subtitle: "په افغانستان کې حرفه‌ای روغتیایي خدمتونه",
    get_started: "پیل کړئ",
    learn_more: "نور زده کړئ",
    
    // Services
    find_doctor: "ډاکټر ومومئ",
    find_doctor_desc: "د تصدیق شوي ډاکټرانو سره وصل شئ",
    book_appointment: "وخت ونیسئ",
    book_appointment_desc: "خپل ملاقات تنظیم کړئ",
    lab_tests: "د لابراتوار ازموینې",
    lab_tests_desc: "ازموینې وکړئ او نتیجې واخلئ",
    medicine_reminder: "د درملو یادښت",
    medicine_reminder_desc: "خپل درمل هیر مه کړئ",
    health_records: "روغتیایي ریکارډونه",
    health_records_desc: "خپل طبي تاریخچه اداره کړئ",
    emergency: "اضطراري حالت",
    emergency_desc: "۲۴/۷ اضطراري خدمتونه",
    
    // Medicines
    medicines_database: "د درملو ډیټابیس",
    search_medicine: "درمل ولټوئ...",
    medicine_name: "د درملو نوم",
    generic_name: "عمومي نوم",
    category: "کټګوري",
    price: "بیه",
    manufacturer: "جوړوونکی",
    dosage: "خوراک",
    side_effects: "اړخیز اغیزې",
    precautions: "احتیاطي تدابیر",
    interactions: "د درملو تعامل",
    storage: "ذخیره کول",
    view_details: "تفصیل وګورئ",
    
    // Doctors
    doctors_list: "د ډاکټرانو لیست",
    specialty: "تخصص",
    experience: "تجربه",
    rating: "درجه بندي",
    available: "موجود",
    consultation_fee: "د مشورې فیس",
    book_now: "اوس وکړئ",
    view_profile: "پروفایل وګورئ",
    
    // Lab Tests
    book_lab_test: "د لابراتوار ازموینه وکړئ",
    test_name: "د ازموینې نوم",
    test_price: "د ازموینې بیه",
    sample_required: "نمونه اړینه ده",
    result_time: "د نتیجې وخت",
    booking_date: "د بکینګ نیټه",
    booking_time: "د بکینګ وخت",
    view_results: "نتیجې وګورئ",
    download_report: "راپور ډاونلوډ کړئ",
    
    // Medicine Reminder
    add_reminder: "یادښت واچوئ",
    medicine: "درمل",
    frequency: "تکرار",
    time: "وخت",
    duration: "موده",
    daily: "ورځني",
    weekly: "اونیز",
    morning: "سهار",
    afternoon: "ماسپښین",
    evening: "ماښام",
    night: "شپه",
    
    // Health Dashboard
    health_dashboard: "روغتیایي ډشبورډ",
    heart_rate: "د زړه ضربان",
    blood_pressure: "د وینې فشار",
    temperature: "تودوخه",
    weight: "وزن",
    height: "قد",
    bmi: "BMI",
    blood_sugar: "د وینې شکره",
    oxygen_level: "د آکسیجن کچه",
    
    // Family Profiles
    family_profiles: "د کورنۍ پروفایلونه",
    add_member: "د کورنۍ غړی واچوئ",
    member_name: "د غړي نوم",
    relationship: "اړیکه",
    age: "عمر",
    gender: "جنسیت",
    male: "نارینه",
    female: "ښځینه",
    blood_group: "د وینې ګروپ",
    
    // E-Pharmacy
    e_pharmacy: "ای-فارمسي",
    add_to_cart: "ټوکرۍ ته واچوئ",
    cart: "ټوکرۍ",
    checkout: "نغدي ورکول",
    total: "ټول",
    delivery_address: "د رسولو پته",
    payment_method: "د تادیې میتود",
    place_order: "امر ولیږئ",
    
    // Health Insurance
    health_insurance: "د روغتیا بیمه",
    insurance_provider: "بیمه چمتو کوونکی",
    policy_number: "د پالیسۍ شمیره",
    coverage: "پوښښ",
    expiry_date: "د ختمیدو نیټه",
    upload_card: "بیمه کارډ اپلوډ کړئ",
    check_coverage: "پوښښ وګورئ",
    
    // Doctor Chat
    doctor_chat: "د ډاکټر سره چیټ",
    type_message: "پیغام ولیکئ...",
    send: "واستوئ",
    voice_message: "غږیز پیغام",
    attach_file: "فایل ضمیمه کړئ",
    upload_prescription: "نسخه اپلوډ کړئ",
    upload_test_results: "د ازموینې نتیجې اپلوډ کړئ",
    upload_image: "عکس اپلوډ کړئ",
    
    // Video Consultation
    video_consultation: "ویډیو مشوره",
    start_call: "ویډیو کال پیل کړئ",
    join_call: "په کال کې شامل شئ",
    end_call: "کال پای ته ورسوئ",
    camera: "کمره",
    microphone: "مایکروفون",
    screen_share: "سکرین شریک کول",
    
    // Symptoms Tracker
    symptoms_tracker: "د علایمو ټریکر",
    add_entry: "ننوتنه واچوئ",
    pain_level: "د درد کچه",
    mood: "مزاج",
    happy: "خوشحاله",
    neutral: "عادي",
    sad: "خفه",
    notes: "یادښتونه",
    generate_report: "راپور جوړ کړئ",
    
    // AI Health Assistant
    ai_health_assistant: "هوښیار روغتیایي مرستیال",
    ai_chat: "AI چیټ",
    symptom_checker: "د علایمو چیکر",
    analyze_symptoms: "علایم تحلیل کړئ",
    risk_level: "د خطر کچه",
    low_risk: "ټیټ خطر",
    medium_risk: "منځنی خطر",
    high_risk: "لوړ خطر",
    recommendations: "سپارښتنې",
    suggested_doctors: "وړاندیز شوي ډاکټران",
    
    // Emergency
    emergency_hotline: "اضطراري هاټ لاین",
    call_ambulance: "امبولانس ته زنګ ووهئ",
    nearest_hospital: "نږدې روغتون",
    emergency_contacts: "اضطراري اړیکې",
    
    // Contact
    phone: "تلیفون",
    email: "بریښنالیک",
    address: "پته",
    send_message: "پیغام واستوئ",
    your_name: "ستاسو نوم",
    your_email: "ستاسو بریښنالیک",
    your_message: "ستاسو پیغام",
    
    // Settings
    language: "ژبه",
    notifications: "خبرتیاوې",
    theme: "تیم",
    account: "حساب",
    logout: "وتل",
    
    // Status
    online: "آنلاین",
    offline: "آفلاین",
    active: "فعال",
    inactive: "غیر فعال",
    pending: "انتظار کې",
    completed: "بشپړ شوی",
    cancelled: "لغوه شوی",
    
    // Time
    today: "نن",
    yesterday: "پرون",
    tomorrow: "سبا",
    this_week: "دا اونۍ",
    this_month: "دا میاشت",
    
    // Days
    monday: "دوشنبه",
    tuesday: "سه‌شنبه",
    wednesday: "چهارشنبه",
    thursday: "پنجشنبه",
    friday: "جمعه",
    saturday: "شنبه",
    sunday: "یکشنبه",
    
    // Medical Specialties
    cardiologist: "زړه متخصص",
    dermatologist: "پوستکي متخصص",
    pediatrician: "د ماشومانو متخصص",
    neurologist: "د اعصابو متخصص",
    orthopedic: "د هډوکو متخصص",
    gynecologist: "د ښځو متخصص",
    general_physician: "عمومي ډاکټر",
    dentist: "غاښونو ډاکټر",
    
    // HomeScreen Specific
    good_morning: "سهار مو په خیر",
    good_afternoon: "ماسپښین مو په خیر",
    good_evening: "ماښام مو په خیر",
    good_night: "شپه مو په خیر",
    start_day_health: "خپله ورځ د روغتیا سره پیل کړئ",
    take_care_health: "خپلې روغتیا ته پاملرنه وکړئ",
    your_health_companion: "ستاسو د روغتیا ملګری",
    rest_well_healthy: "ښه استراحت وکړئ، روغ پاتې شئ",
    search_doctors_medicines: "ډاکټران، درمل، خدمات ولټوئ...",
    appointments_stat: "ملاقاتونه",
    prescriptions_stat: "نسخې",
    health_score: "د روغتیا نمره",
    this_week_change: "دا اونۍ",
    active_status: "فعال",
    excellent_status: "عالی",
    quick_actions: "چټک کړنې",
    access_health_instantly: "د روغتیا خدمتونو ته چټک لاسرسی",
    find_doctors: "ډاکټران ومومئ",
    video_call: "ویډیو تماس",
    online_consultation: "آنلاین مشوره",
    browse_pharmacy: "فارمسي وګورئ",
    schedule_visits: "ملاقاتونه تنظیم کړئ",
    daily_health_advice: "ورځنۍ روغتیا مشورې",
    help_24_7: "۲۴/۷ مرسته",
    top_doctors: "غوره ډاکټران",
    connect_specialists: "زموږ له غوره متخصصینو سره اړیکه ونیسئ",
    view_all: "ټول وګورئ",
    patients_count: "ناروغان",
    years_exp: "کاله",
    daily_health_tips: "ورځنۍ روغتیا مشورې",
    stay_hydrated: "اوبه وڅښئ",
    drink_water_daily: "په ورځ کې 8 ګیلاسه اوبه وڅښئ",
    regular_exercise: "منظم ورزش",
    minutes_daily: "په ورځ کې 30 دقیقې",
    healthy_diet: "روغتیایي خوراک",
    eat_fruits_vegetables: "میوې او سبزیجات وخورئ",
    emergency_helpline: "بیړنی مرسته",
    call_now: "اوس زنګ ووهئ",
    health_categories: "د روغتیا کټګورۍ",
    explore: "وګورئ",
    cardiology: "زړه",
    neurology: "اعصاب",
    orthopedics: "هډوکي",
    general: "عمومی",
  },
  
  fa: {
    // App Name
    app_name: "هیلمیت",
    app_tagline: "همراه کامل سلامتی شما",
    
    // Common
    home: "خانه",
    back: "برگشت",
    next: "بعدی",
    cancel: "لغو",
    save: "ذخیره",
    delete: "حذف",
    edit: "ویرایش",
    view: "مشاهده",
    close: "بستن",
    search: "جستجو",
    filter: "فیلتر",
    loading: "در حال بارگذاری...",
    no_data: "اطلاعات موجود نیست",
    error: "خطا رخ داد",
    success: "موفقیت",
    submit: "ارسال",
    confirm: "تایید",
    download: "دانلود",
    share: "اشتراک",
    
    // Navigation
    services: "خدمات",
    medicines: "داروها",
    health_tips: "نکات سلامتی",
    settings: "تنظیمات",
    about_us: "درباره ما",
    contact_us: "تماس با ما",
    privacy_policy: "سیاست حفظ حریم خصوصی",
    terms_conditions: "شرایط و ضوابط",
    doctors: "دکتران",
    posts: "پست‌ها",
    community: "انجمن",
    books: "کتاب‌ها",
    
    // Hero Section
    hero_title: "پلتفرم کامل سلامتی شما",
    hero_subtitle: "خدمات حرفه‌ای سلامتی در افغانستان",
    get_started: "شروع کنید",
    learn_more: "بیشتر بدانید",
    
    // Services
    find_doctor: "یافتن دکتر",
    find_doctor_desc: "با دکتران معتبر ارتباط برقرار کنید",
    book_appointment: "رزرو وقت",
    book_appointment_desc: "مشاوره خود را برنامه‌ریزی کنید",
    lab_tests: "آزمایشات لابراتواری",
    lab_tests_desc: "آزمایش رزرو کنید و نتایج را دریافت کنید",
    medicine_reminder: "یادآور دارو",
    medicine_reminder_desc: "داروی خود را فراموش نکنید",
    health_records: "سوابق سلامتی",
    health_records_desc: "تاریخچه پزشکی خود را مدیریت کنید",
    emergency: "اورژانس",
    emergency_desc: "خدمات اورژانسی ۲۴/۷",
    
    // Medicines
    medicines_database: "پایگاه داده داروها",
    search_medicine: "جستجوی دارو...",
    medicine_name: "نام دارو",
    generic_name: "نام عمومی",
    category: "دسته‌بندی",
    price: "قیمت",
    manufacturer: "تولید کننده",
    dosage: "دوز",
    side_effects: "عوارض جانبی",
    precautions: "احتیاطات",
    interactions: "تداخلات دارویی",
    storage: "نگهداری",
    view_details: "مشاهده جزئیات",
    
    // Doctors
    doctors_list: "لیست دکتران",
    specialty: "تخصص",
    experience: "تجربه",
    rating: "رتبه‌بندی",
    available: "در دسترس",
    consultation_fee: "هزینه مشاوره",
    book_now: "رزرو کنید",
    view_profile: "مشاهده پروفایل",
    
    // Lab Tests
    book_lab_test: "رزرو آزمایش لابراتواری",
    test_name: "نام آزمایش",
    test_price: "قیمت آزمایش",
    sample_required: "نمونه مورد نیاز",
    result_time: "زمان نتیجه",
    booking_date: "تاریخ رزرو",
    booking_time: "زمان رزرو",
    view_results: "مشاهده نتایج",
    download_report: "دانلود گزارش",
    
    // Medicine Reminder
    add_reminder: "افزودن یادآور",
    medicine: "دارو",
    frequency: "فرکانس",
    time: "زمان",
    duration: "مدت",
    daily: "روزانه",
    weekly: "هفتگی",
    morning: "صبح",
    afternoon: "بعدازظهر",
    evening: "عصر",
    night: "شب",
    
    // Health Dashboard
    health_dashboard: "داشبورد سلامتی",
    heart_rate: "ضربان قلب",
    blood_pressure: "فشار خون",
    temperature: "دما",
    weight: "وزن",
    height: "قد",
    bmi: "شاخص توده بدنی",
    blood_sugar: "قند خون",
    oxygen_level: "سطح اکسیژن",
    
    // Family Profiles
    family_profiles: "پروفایل خانواده",
    add_member: "افزودن عضو خانواده",
    member_name: "نام عضو",
    relationship: "رابطه",
    age: "سن",
    gender: "جنسیت",
    male: "مرد",
    female: "زن",
    blood_group: "گروه خونی",
    
    // E-Pharmacy
    e_pharmacy: "داروخانه آنلاین",
    add_to_cart: "افزودن به سبد",
    cart: "سبد خرید",
    checkout: "پرداخت",
    total: "مجموع",
    delivery_address: "آدرس تحویل",
    payment_method: "روش پرداخت",
    place_order: "ثبت سفارش",
    
    // Health Insurance
    health_insurance: "بیمه سلامت",
    insurance_provider: "ارائه‌دهنده بیمه",
    policy_number: "شماره بیمه‌نامه",
    coverage: "پوشش",
    expiry_date: "تاریخ انقضا",
    upload_card: "بارگذاری کارت بیمه",
    check_coverage: "بررسی پوشش",
    
    // Doctor Chat
    doctor_chat: "چت با دکتر",
    type_message: "پیام خود را تایپ کنید...",
    send: "ارسال",
    voice_message: "پیام صوتی",
    attach_file: "پیوست فایل",
    upload_prescription: "بارگذاری نسخه",
    upload_test_results: "بارگذاری نتایج آزمایش",
    upload_image: "بارگذاری تصویر",
    
    // Video Consultation
    video_consultation: "مشاوره ویدیویی",
    start_call: "شروع تماس ویدیویی",
    join_call: "پیوستن به تماس",
    end_call: "پایان تماس",
    camera: "دوربین",
    microphone: "میکروفون",
    screen_share: "اشتراک صفحه",
    
    // Symptoms Tracker
    symptoms_tracker: "ردیاب علائم",
    add_entry: "افزودن ورودی",
    pain_level: "سطح درد",
    mood: "خلق و خو",
    happy: "خوشحال",
    neutral: "خنثی",
    sad: "غمگین",
    notes: "یادداشت‌ها",
    generate_report: "تولید گزارش",
    
    // AI Health Assistant
    ai_health_assistant: "دستیار هوشمند سلامتی",
    ai_chat: "چت هوشمند",
    symptom_checker: "بررسی علائم",
    analyze_symptoms: "تحلیل علائم",
    risk_level: "سطح خطر",
    low_risk: "خطر کم",
    medium_risk: "خطر متوسط",
    high_risk: "خطر بالا",
    recommendations: "توصیه‌ها",
    suggested_doctors: "دکتران پیشنهادی",
    
    // Emergency
    emergency_hotline: "خط اضطراری",
    call_ambulance: "تماس با آمبولانس",
    nearest_hospital: "نزدیکترین بیمارستان",
    emergency_contacts: "تماس‌های اضطراری",
    
    // Contact
    phone: "تلفن",
    email: "ایمیل",
    address: "آدرس",
    send_message: "ارسال پیام",
    your_name: "نام شما",
    your_email: "ایمیل شما",
    your_message: "پیام شما",
    
    // Settings
    language: "زبان",
    notifications: "اعلان‌ها",
    theme: "تم",
    account: "حساب",
    logout: "خروج",
    
    // Status
    online: "آنلاین",
    offline: "آفلاین",
    active: "فعال",
    inactive: "غیرفعال",
    pending: "در انتظار",
    completed: "تکمیل شده",
    cancelled: "لغو شده",
    
    // Time
    today: "امروز",
    yesterday: "دیروز",
    tomorrow: "فردا",
    this_week: "این هفته",
    this_month: "این ماه",
    
    // Days
    monday: "دوشنبه",
    tuesday: "سه‌شنبه",
    wednesday: "چهارشنبه",
    thursday: "پنجشنبه",
    friday: "جمعه",
    saturday: "شنبه",
    sunday: "یکشنبه",
    
    // Medical Specialties
    cardiologist: "متخصص قلب",
    dermatologist: "متخصص پوست",
    pediatrician: "متخصص اطفال",
    neurologist: "متخصص اعصاب",
    orthopedic: "متخصص ارتوپد",
    gynecologist: "متخصص زنان",
    general_physician: "پزشک عمومی",
    dentist: "دندانپزشک",
    
    // HomeScreen Specific
    good_morning: "صبح بخیر",
    good_afternoon: "بعد از ظهر بخیر",
    good_evening: "عصر بخیر",
    good_night: "شب بخیر",
    start_day_health: "روز خود را با سلامتی آغاز کنید",
    take_care_health: "مراقب سلامتی خود باشید",
    your_health_companion: "همراه سلامتی شما",
    rest_well_healthy: "استراحت خوب داشته باشید، سالم بمانید",
    search_doctors_medicines: "دکتران، داروها، خدمات را جستجو کنید...",
    appointments_stat: "قرار ملاقات‌ها",
    prescriptions_stat: "نسخه‌ها",
    health_score: "امتیاز سلامتی",
    this_week_change: "این هفته",
    active_status: "فعال",
    excellent_status: "عالی",
    quick_actions: "عملیات سریع",
    access_health_instantly: "دسترسی سریع به خدمات سلامتی",
    find_doctors: "دکتران را پیدا کنید",
    video_call: "تماس ویدیویی",
    online_consultation: "مشاوره آنلاین",
    browse_pharmacy: "داروخانه را مرور کنید",
    schedule_visits: "برنامه‌ریزی ملاقات‌ها",
    daily_health_advice: "مشاوره روزانه سلامتی",
    help_24_7: "کمک ۲۴/۷",
    top_doctors: "بهترین دکتران",
    connect_specialists: "با بهترین متخصصان ما ارتباط برقرار کنید",
    view_all: "مشاهده همه",
    patients_count: "بیماران",
    years_exp: "سال",
    daily_health_tips: "نکات روزانه سلامتی",
    stay_hydrated: "آب بنوشید",
    drink_water_daily: "روزانه 8 لیوان آب بنوشید",
    regular_exercise: "ورزش منظم",
    minutes_daily: "30 دقیقه در روز",
    healthy_diet: "رژیم غذایی سالم",
    eat_fruits_vegetables: "میوه و سبزیجات بخورید",
    emergency_helpline: "خط کمک اضطراری",
    call_now: "اکنون تماس بگیرید",
    health_categories: "دسته‌بندی‌های سلامتی",
    explore: "کاوش",
    cardiology: "قلب",
    neurology: "اعصاب",
    orthopedics: "ارتوپدی",
    general: "عمومی",
  },
};
