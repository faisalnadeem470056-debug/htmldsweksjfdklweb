import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  return (
    <iframe
      src="/Mehmetistan/index.html"
      title="Mehmetistan Dijital Ülke Sistemi"
      className="fixed inset-0 h-[100dvh] w-full border-0"
      allow="fullscreen"
    />
  );
}
