export type Locale = "tr" | "en";

export type Text = { tr: string; en: string };

export function tx(text: Text, lang: Locale): string {
  return text[lang];
}

export type SectionId =
  | "home"
  | "map"
  | "government"
  | "cities"
  | "laws"
  | "mtt"
  | "msk"
  | "space"
  | "history"
  | "world"
  | "news"
  | "economy"
  | "game"
  | "projects"
  | "settings";

export const SECTION_IDS: SectionId[] = [
  "home",
  "map",
  "government",
  "cities",
  "laws",
  "mtt",
  "msk",
  "space",
  "history",
  "world",
  "news",
  "economy",
  "game",
  "projects",
  "settings",
];

export function isSectionId(v: string): v is SectionId {
  return (SECTION_IDS as string[]).includes(v);
}

export type Relation = "ally" | "neutral" | "enemy" | "unknown";

export type Province = {
  id: string;
  name: Text;
  region: Text;
  population: number;
  areaKm2: number;
  capital: boolean;
  description: Text;
  pin: { x: number; y: number };
};

export type City = {
  id: string;
  name: Text;
  provinceId: string;
  population: number;
  isCapital: boolean;
  isNationalCapital: boolean;
  founded: string;
  description: Text;
  pin: { x: number; y: number };
};

export type Law = {
  id: string;
  code: string;
  title: Text;
  category: LawCategory;
  year: number;
  summary: Text;
};

export type LawCategory =
  | "constitution"
  | "citizenship"
  | "education"
  | "security"
  | "economy"
  | "transport"
  | "technology"
  | "environment"
  | "other";

export type NewsItem = {
  id: string;
  date: string;
  category: Text;
  title: Text;
  body: Text;
};

export type HistoryEvent = {
  id: string;
  date: string;
  title: Text;
  body: Text;
};

export type Country = {
  id: string;
  name: Text;
  capital: Text;
  relation: Relation;
  color: string;
  history: Text;
  description: Text;
  box: { x: number; y: number; w: number; h: number };
};

export type Project = {
  id: string;
  title: Text;
  category: Text;
  status: Text;
  description: Text;
};
