import type { Text } from "../types";

export const COUNTRY = {
  name: { tr: "Mehmetistan", en: "Mehmetistan" },
  officialName: { tr: "Mehmetistan Cumhuriyeti", en: "Republic of Mehmetistan" },
  motto: { tr: "Bir Hilal, Bir Vatan", en: "One Crescent, One Homeland" },
  anthem: { tr: "Hilalin Altında", en: "Beneath the Crescent" },
  capital: "Mehmetkent",
  currency: "MTT",
  currencyName: { tr: "Mehmetistan Tokenu", en: "Mehmetistan Token" },
  language: { tr: "Türkçe", en: "Turkish" },
  governmentType: {
    tr: "Cumhurbaşkanlığı sistemi · üniter devlet",
    en: "Presidential system · unitary state",
  },
  independence: "2018-03-14",
  population: 18_420_000,
  areaKm2: 284_600,
  provinces: 24,
  gdpMtt: 142_600_000_000,
  inflation: 2.1,
  timezone: "UTC+3",
  timezoneName: { tr: "Mehmetkent Saati", en: "Mehmetkent Time" },
  president: {
    name: "Mehmet Alparslan",
    title: { tr: "Devlet Başkanı", en: "President" },
    since: "2022",
    bio: {
      tr: "Mehmetkent doğumlu devlet başkanı. Dijital ülke reformunun mimarı, MTT’nin ikinci dönem koruyucusu. Hilal Doktrini ile dış politikayı belirler.",
      en: "Mehmetkent-born head of state. Architect of the digital-country reform and guardian of MTT in his second term. Sets foreign policy through the Crescent Doctrine.",
    },
  },
  vice: {
    name: "Selin Arven",
    title: { tr: "Cumhurbaşkanı Yardımcısı", en: "Vice President" },
  },
  legislature: {
    name: { tr: "Millet Meclisi", en: "National Assembly" },
    seats: 180,
  },
  flagMeaning: {
    tr: "Yeşil vatanı ve umudu, siyah kararlılığı, mavi denizi ve göğü temsil eder. Siyah kuşaktaki mavi hilal, Mehmetistan’ın gece de yolunu bulan egemenliğini simgeler.",
    en: "Green stands for the homeland and hope, black for resolve, blue for sea and sky. The blue crescent on the black band is sovereignty that finds its path even at night.",
  },
} as const;

export const STAT_CARDS: { label: Text; value: string; hint: Text }[] = [
  {
    label: { tr: "Nüfus", en: "Population" },
    value: "18,4 Mn",
    hint: { tr: "2026 sayımı", en: "2026 census" },
  },
  {
    label: { tr: "İl", en: "Provinces" },
    value: "24",
    hint: { tr: "Başkent Mehmetkent", en: "Capital Mehmetkent" },
  },
  {
    label: { tr: "GSYİH", en: "GDP" },
    value: "142,6 Mr",
    hint: { tr: "MTT, kurgusal", en: "MTT, fictional" },
  },
  {
    label: { tr: "MTT", en: "MTT" },
    value: "1,00",
    hint: { tr: "Resmi parite", en: "Official parity" },
  },
];
