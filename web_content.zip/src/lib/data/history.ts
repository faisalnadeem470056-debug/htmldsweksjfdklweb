import type { HistoryEvent } from "../types";

export const history: HistoryEvent[] = [
  {
    id: "h2014",
    date: "2014",
    title: { tr: "Fikir", en: "The idea" },
    body: {
      tr: "Mehmetkent’te küçük bir çevrede hilalli bir vatan taslağı çizildi. İlk bayrak eskizi yeşil-siyah-maviydi.",
      en: "A small circle in Mehmetkent sketched a homeland under a crescent. The first flag study was already green-black-blue.",
    },
  },
  {
    id: "h2016",
    date: "2016",
    title: { tr: "Anayasa taslağı", en: "Draft constitution" },
    body: {
      tr: "On iki maddelik taslak: dil, başkent, para, ordu. Hilal mühür olarak kabul edildi.",
      en: "A twelve-article draft: language, capital, currency, army. The crescent was adopted as the seal.",
    },
  },
  {
    id: "h2018",
    date: "14 Mart 2018",
    title: { tr: "Bağımsızlık Günü", en: "Independence Day" },
    body: {
      tr: "Mehmetistan Cumhuriyeti ilan edildi. Mehmetkent başkent, MTT henüz kâğıt üzerindeydi.",
      en: "The Republic of Mehmetistan was proclaimed. Mehmetkent was capital; MTT still existed only on paper.",
    },
  },
  {
    id: "h2019",
    date: "2019",
    title: { tr: "MSK ve iller", en: "MSK and the provinces" },
    body: {
      tr: "Yirmi dört il sınırları çizildi. Silahlı kuvvetler tek komuta altında toplandı.",
      en: "Twenty-four provincial borders were drawn. The armed forces came under one command.",
    },
  },
  {
    id: "h2020",
    date: "2020",
    title: { tr: "MTT tedavüle çıktı", en: "MTT enters circulation" },
    body: {
      tr: "Merkez Bankası ilk seriyi bastı. Dijital cüzdan bir yıl sonra eklendi.",
      en: "The Central Bank printed the first series. The digital wallet followed a year later.",
    },
  },
  {
    id: "h2022",
    date: "2022",
    title: { tr: "İlk uydu", en: "First satellite" },
    body: {
      tr: "MUA-1 Hilal Göz, Göktepe’den Hilal-R1 ile yörüngeye girdi. Dijital Devlet maddesi Anayasa’ya işlendi.",
      en: "MSA-1 Crescent Eye reached orbit on Hilal-R1 from Goktepe. The Digital State amendment entered the constitution.",
    },
  },
  {
    id: "h2023",
    date: "2023",
    title: { tr: "Atlas diplomasisi", en: "Atlas diplomacy" },
    body: {
      tr: "Almiraistan, Ortamistan ve Barlasistan ile dostluk antlaşmaları. Kralistan ile soğuk duruş sürdü.",
      en: "Friendship treaties with Almiraistan, Ortamistan and Barlasistan. The freeze with Kralistan held.",
    },
  },
  {
    id: "h2025",
    date: "2025",
    title: { tr: "Dijital ülke sistemi", en: "Digital country system" },
    body: {
      tr: "Tüm resmi kayıtlar tek portalda birleştirildi. Harita, kanun ve kimlik aynı çatı altına alındı.",
      en: "All official records were joined in one portal. Map, law and identity came under one roof.",
    },
  },
  {
    id: "h2026",
    date: "2026",
    title: { tr: "Resmi dijital portal", en: "Official digital portal" },
    body: {
      tr: "Bu uygulama yayına alındı. Mehmetistan, tek bir dijital ülkede yaşatılmak üzere mühürlendi.",
      en: "This application went live. Mehmetistan was sealed to live in a single digital country.",
    },
  },
];
