import type { NewsItem } from "../types";

export const news: NewsItem[] = [
  {
    id: "n1",
    date: "2026-09-08",
    category: { tr: "Uzay", en: "Space" },
    title: {
      tr: "Mehmetistan Uzay Ajansı Atlas-W görevini duyurdu",
      en: "Mehmetistan Space Agency announced the Atlas-W mission",
    },
    body: {
      tr: "MUA, Göktepe’den Hilal-R2 ile kalkacak Atlas Hava uydusunun penceresini 2026 son çeyrek olarak ilan etti. Kıyı fırtına tahmini ve tarım verisi kamuoyuna açık olacak.",
      en: "MSA set the Atlas Weather satellite window for late 2026, lifting on Hilal-R2 from Goktepe. Coastal storm forecasts and farm data will be public.",
    },
  },
  {
    id: "n2",
    date: "2026-08-21",
    category: { tr: "Ekonomi", en: "Economy" },
    title: { tr: "MTT cüzdan v3 testleri tamamlandı", en: "MTT wallet v3 tests completed" },
    body: {
      tr: "Merkez Bankası, çevrimdışı karekod ödemesinin on ilde hatasız çalıştığını bildirdi. Yaygınlaştırma üçüncü çeyrekte.",
      en: "The Central Bank reported offline QR payments running cleanly in ten provinces. Rollout is due in the third quarter.",
    },
  },
  {
    id: "n3",
    date: "2026-07-14",
    category: { tr: "Devlet", en: "State" },
    title: { tr: "Dijital ülke portalı mühürlendi", en: "Digital country portal sealed" },
    body: {
      tr: "Teknoloji Bakanlığı, Mehmetistan’ın resmi dijital devlet sistemini vatandaş kullanımına açtı. Harita, kanun ve kimlik aynı çatı altında.",
      en: "The technology ministry opened Mehmetistan’s official digital state system to citizens. Map, law and identity sit under one roof.",
    },
  },
  {
    id: "n4",
    date: "2026-06-02",
    category: { tr: "MSK", en: "MSK" },
    title: { tr: "Mavi Hat-26 tatbikatı Nelis’te bitti", en: "Blue Line-26 drill ended at Nelis" },
    body: {
      tr: "Deniz ve hava kuvvetleri üç gün süren kıyı koruma manevrasını tamamladı. Kralistan gözlem gemisi 12 mil dışında tutuldu.",
      en: "Navy and air force completed a three-day coastal defence manoeuvre. A Kralistan observer ship was held outside 12 miles.",
    },
  },
  {
    id: "n5",
    date: "2026-04-19",
    category: { tr: "Ulaşım", en: "Transport" },
    title: { tr: "Hilalport ikinci iskele temel atıldı", en: "Hilalport second quay foundation laid" },
    body: {
      tr: "Batı limanında kapasite 2,4 milyon TEU’ya çıkacak. Almiraistan hattı günlük sefere geçiyor.",
      en: "Western-port capacity will rise to 2.4 million TEU. The Almiraistan line moves to daily sailings.",
    },
  },
  {
    id: "n6",
    date: "2026-03-14",
    category: { tr: "Tarih", en: "History" },
    title: { tr: "Bağımsızlık Günü: 8. yıl", en: "Independence Day: year 8" },
    body: {
      tr: "Hilal Meydanı’nda resmi geçit. Devlet Başkanı Alparslan, ‘bir hilal, bir vatan’ sözünü yeniledi.",
      en: "A state parade on Crescent Square. President Alparslan renewed the words ‘one crescent, one homeland’.",
    },
  },
  {
    id: "n7",
    date: "2026-01-28",
    category: { tr: "Çevre", en: "Environment" },
    title: { tr: "Saven rezervinde kuş sayısı rekoru", en: "Record bird count at Saven Reserve" },
    body: {
      tr: "Kış sayımında 86 tür kaydedildi. Çevre Kanunu’nun ilk uygulama alanı koruma hedefini aştı.",
      en: "The winter count logged 86 species. The Environment Act’s first site beat its protection target.",
    },
  },
  {
    id: "n8",
    date: "2025-12-09",
    category: { tr: "Diplomasi", en: "Diplomacy" },
    title: { tr: "Talakistan demiryolu niyet protokolü", en: "Talakistan rail intent protocol" },
    body: {
      tr: "Velis kapısından Talakkent’e ray döşenmesi için etüt başlıyor. Finansman MTT ve ortak fondan.",
      en: "A study begins for rail from the Velis gate to Talakkent. Finance from MTT and a joint fund.",
    },
  },
];
