import type { Text } from "../types";

export const cabinet: { office: Text; name: string }[] = [
  { office: { tr: "Başbakan", en: "Prime Minister" }, name: "Harun Melun" },
  { office: { tr: "İçişleri Bakanı", en: "Interior" }, name: "Leyla Karel" },
  { office: { tr: "Dışişleri Bakanı", en: "Foreign Affairs" }, name: "Emir Velis" },
  { office: { tr: "Millî Savunma Bakanı", en: "National Defence" }, name: "Korgeneral Saren Zoren" },
  { office: { tr: "Hazine ve Maliye Bakanı", en: "Treasury" }, name: "Deniz Varis" },
  { office: { tr: "Millî Eğitim Bakanı", en: "Education" }, name: "Prof. Ayla Arven" },
  { office: { tr: "Sağlık Bakanı", en: "Health" }, name: "Dr. Mert Naven" },
  { office: { tr: "Ulaştırma Bakanı", en: "Transport" }, name: "Selim Melun" },
  { office: { tr: "Enerji Bakanı", en: "Energy" }, name: "Nihan Koren" },
  { office: { tr: "Teknoloji ve Dijital Devlet", en: "Technology & Digital State" }, name: "Cem Hilal" },
  { office: { tr: "Çevre ve Tabiat Bakanı", en: "Environment" }, name: "Defne Saven" },
  { office: { tr: "Adalet Bakanı", en: "Justice" }, name: "Yargıç Baran Toren" },
  { office: { tr: "Kültür Bakanı", en: "Culture" }, name: "İpek Liora" },
  { office: { tr: "Tarım Bakanı", en: "Agriculture" }, name: "Yusuf Taris" },
  { office: { tr: "Uzay ve Bilim Bakanı", en: "Space & Science" }, name: "Dr. Lara Göktepe" },
];

export const ministries: { name: Text; brief: Text }[] = [
  {
    name: { tr: "İçişleri Bakanlığı", en: "Ministry of the Interior" },
    brief: { tr: "İl yönetimi, nüfus ve sivil güvenlik.", en: "Provincial administration, civil registry and internal security." },
  },
  {
    name: { tr: "Dışişleri Bakanlığı", en: "Ministry of Foreign Affairs" },
    brief: { tr: "Hilal Doktrini, elçilikler ve atlas diplomasisi.", en: "Crescent Doctrine, embassies and atlas diplomacy." },
  },
  {
    name: { tr: "Millî Savunma Bakanlığı", en: "Ministry of National Defence" },
    brief: { tr: "MSK’nın sivil denetimi ve seferberlik.", en: "Civilian oversight of the MSK and mobilisation." },
  },
  {
    name: { tr: "Hazine ve Maliye", en: "Treasury and Finance" },
    brief: { tr: "MTT, bütçe ve kamu borçlanması.", en: "MTT, the budget and public borrowing." },
  },
  {
    name: { tr: "Teknoloji ve Dijital Devlet", en: "Technology and Digital State" },
    brief: { tr: "Bu portalın, kimliğin ve e-hizmetlerin sahibi.", en: "Owner of this portal, identity and e-services." },
  },
  {
    name: { tr: "Uzay ve Bilim", en: "Space and Science" },
    brief: { tr: "MUA ve ulusal araştırma programı.", en: "MSA and the national research programme." },
  },
];

export const agencies: { name: Text; brief: Text }[] = [
  {
    name: { tr: "MTT Merkez Bankası", en: "MTT Central Bank" },
    brief: { tr: "Para politikası, rezerv ve dijital cüzdan altyapısı.", en: "Monetary policy, reserves and digital-wallet rails." },
  },
  {
    name: { tr: "Mehmetistan Uzay Ajansı (MUA)", en: "Mehmetistan Space Agency (MSA)" },
    brief: { tr: "Uydu, roket ve derin uzay görevleri.", en: "Satellites, rockets and deep-space missions." },
  },
  {
    name: { tr: "Devlet İstatistik Kurumu", en: "State Statistics Office" },
    brief: { tr: "Nüfus, GSYİH ve resmi göstergeler.", en: "Population, GDP and official indicators." },
  },
  {
    name: { tr: "Dijital Kimlik Kurumu", en: "Digital Identity Authority" },
    brief: { tr: "Vatandaşlık kartı ve e-imza.", en: "Citizenship card and e-signature." },
  },
  {
    name: { tr: "Ulusal Harita Müdürlüğü", en: "National Mapping Directorate" },
    brief: { tr: "Siyasi harita ve il sınırları. Bu uygulamadaki harita onun eseridir.", en: "Political map and provincial borders. The map in this app is its work." },
  },
  {
    name: { tr: "Resmî Gazete", en: "Official Gazette" },
    brief: { tr: "Kanun ve kararların yayımlanma yeri.", en: "Where acts and decrees are published." },
  },
];

export const systemPoints: Text[] = [
  {
    tr: "Egemenlik millete aittir. Millet Meclisi 180 milletvekilinden oluşur; seçimler dört yılda bir yapılır.",
    en: "Sovereignty belongs to the nation. The Assembly has 180 members; elections are held every four years.",
  },
  {
    tr: "Devlet Başkanı hem protokol hem icra yetkisini taşır. Bakanlar Kurulu’nu atar, Meclis güvenoyu verir.",
    en: "The President holds both ceremonial and executive power. The Cabinet is appointed; the Assembly votes confidence.",
  },
  {
    tr: "Yargı bağımsızdır. Anayasa Mahkemesi, hilal mührüyle kanunların Anayasa’ya uygunluğunu denetler.",
    en: "The judiciary is independent. The Constitutional Court, under the crescent seal, reviews statutes.",
  },
  {
    tr: "İl yönetimi valilik esasına dayanır. Her ilin bir merkezi ve Meclis’te temsili vardır.",
    en: "Provinces are run by governorships. Each has a capital and a seat in the Assembly.",
  },
];
