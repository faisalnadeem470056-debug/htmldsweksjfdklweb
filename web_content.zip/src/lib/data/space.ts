import type { Text } from "../types";

export type MissionStatus = "ops" | "flight" | "build" | "planned";

export const missions: {
  id: string;
  name: Text;
  status: MissionStatus;
  year: string;
  brief: Text;
}[] = [
  {
    id: "mua1",
    name: { tr: "MUA-1 Hilal Göz", en: "MSA-1 Crescent Eye" },
    status: "ops",
    year: "2022",
    brief: {
      tr: "İlk yer gözlem uydusu. Harita müdürlüğüne sürekli görüntü verir.",
      en: "First earth-observation satellite. Feeds the mapping directorate a live picture.",
    },
  },
  {
    id: "mua2",
    name: { tr: "MUA-2 Haberleşme", en: "MSA-2 Comms" },
    status: "ops",
    year: "2024",
    brief: {
      tr: "Ülke içi güvenli haberleşme. Dijital kimlik ağı yedek kanalı.",
      en: "Domestic secure communications. Backup channel for the digital-identity net.",
    },
  },
  {
    id: "ay1",
    name: { tr: "Ay Keşif A", en: "Lunar Scout A" },
    status: "build",
    year: "2028",
    brief: {
      tr: "Yörünge tarayıcısı. İniş aracı bir sonraki pencerede.",
      en: "Orbital scanner. Lander follows in the next window.",
    },
  },
  {
    id: "atlas",
    name: { tr: "Atlas Hava", en: "Atlas Weather" },
    status: "flight",
    year: "2026",
    brief: {
      tr: "Bu yılki fırlatma. Kıyı fırtınaları ve tarım tahmini.",
      en: "This year’s launch. Coastal storms and farm forecast.",
    },
  },
  {
    id: "derin",
    name: { tr: "Derin Hilal", en: "Deep Crescent" },
    status: "planned",
    year: "2031",
    brief: {
      tr: "Dış gezegen geçişi. Uluslararası ortak aranıyor; Kralistan hariç.",
      en: "Outer-planet flyby. International partners welcome — except Kralistan.",
    },
  },
];

export const rockets: { name: Text; payload: string; note: Text }[] = [
  {
    name: { tr: "Hilal-R1", en: "Hilal-R1" },
    payload: "1,2 t LEO",
    note: { tr: "İlk yerli basamak. 2022’de uçtu.", en: "First domestic stage. Flew in 2022." },
  },
  {
    name: { tr: "Hilal-R2", en: "Hilal-R2" },
    payload: "4,8 t LEO",
    note: { tr: "Ana iş atı. Göktepe’den kalkar.", en: "Workhorse. Lifts from Goktepe." },
  },
  {
    name: { tr: "Bozkır-Ağır", en: "Bozkir-Heavy" },
    payload: "14 t LEO",
    note: { tr: "Ay penceresi için geliştiriliyor.", en: "In development for the lunar window." },
  },
];

export const satellites: { name: Text; orbit: string; status: MissionStatus }[] = [
  { name: { tr: "Hilal Göz-1", en: "Crescent Eye-1" }, orbit: "SSO 520 km", status: "ops" },
  { name: { tr: "Hilal Göz-2", en: "Crescent Eye-2" }, orbit: "SSO 520 km", status: "ops" },
  { name: { tr: "Haber-A", en: "Comms-A" }, orbit: "GEO 38°D", status: "ops" },
  { name: { tr: "Atlas-W", en: "Atlas-W" }, orbit: "LEO 680 km", status: "flight" },
];

export const STATUS_LABEL: Record<MissionStatus, Text> = {
  ops: { tr: "Görevde", en: "Operational" },
  flight: { tr: "Uçuşta", en: "In flight" },
  build: { tr: "Üretimde", en: "In build" },
  planned: { tr: "Planlandı", en: "Planned" },
};
