import type { Text } from "../types";

export const branches: {
  id: string;
  name: Text;
  motto: Text;
  strength: string;
  brief: Text;
}[] = [
  {
    id: "army",
    name: { tr: "Kara Kuvvetleri", en: "Army" },
    motto: { tr: "Toprak tutulur", en: "The ground is held" },
    strength: "62.000",
    brief: {
      tr: "Zoren kışlası merkezli. Sınır tugayları Karel, Yoren ve Velis’te konuşludur. Hilal zırhlısı ana muharebe aracıdır.",
      en: "Based at Zoren Barracks. Border brigades sit at Karel, Yoren and Velis. The Hilal armour is the main fighting vehicle.",
    },
  },
  {
    id: "air",
    name: { tr: "Hava Kuvvetleri", en: "Air Force" },
    motto: { tr: "Gök de vatan", en: "The sky is homeland too" },
    strength: "14.200",
    brief: {
      tr: "Melun ve Göktepe üsleri. Kartal savaş uçağı ve gözcü İHA filoları. MUA fırlatmalarına hava koridoru açar.",
      en: "Melun and Goktepe bases. Kartal fighters and scout UAV wings. Opens air corridors for MSA launches.",
    },
  },
  {
    id: "navy",
    name: { tr: "Deniz Kuvvetleri", en: "Navy" },
    motto: { tr: "Mavi hat kırılmaz", en: "The blue line does not break" },
    strength: "11.800",
    brief: {
      tr: "Hilalport ve Seris üsleri. Korvet ve kıyı bataryaları. Atlas denizindeki ticaret yollarını korur.",
      en: "Hilalport and Seris bases. Corvettes and coastal batteries. Guards trade lanes on the atlas sea.",
    },
  },
  {
    id: "sof",
    name: { tr: "Özel Kuvvetler Komutanlığı", en: "Special Forces Command" },
    motto: { tr: "Hilal gece de yanar", en: "The crescent burns at night" },
    strength: "2.400",
    brief: {
      tr: "Dağ, deniz ve siber birlikleri. Yoren’de dağ okulu, Mehmetkent’te siber alay.",
      en: "Mountain, maritime and cyber units. Mountain school in Yoren, cyber regiment in Mehmetkent.",
    },
  },
];

export const ranks: { grade: string; name: Text }[] = [
  { grade: "E-1", name: { tr: "Er", en: "Private" } },
  { grade: "E-3", name: { tr: "Onbaşı", en: "Corporal" } },
  { grade: "E-5", name: { tr: "Çavuş", en: "Sergeant" } },
  { grade: "E-8", name: { tr: "Başçavuş", en: "Master Sergeant" } },
  { grade: "O-1", name: { tr: "Teğmen", en: "Lieutenant" } },
  { grade: "O-3", name: { tr: "Yüzbaşı", en: "Captain" } },
  { grade: "O-4", name: { tr: "Binbaşı", en: "Major" } },
  { grade: "O-6", name: { tr: "Albay", en: "Colonel" } },
  { grade: "O-8", name: { tr: "Tümgeneral", en: "Major General" } },
  { grade: "O-10", name: { tr: "Orgeneral", en: "General" } },
];

export const equipment: { name: Text; kind: Text; note: Text }[] = [
  {
    name: { tr: "Hilal-2 zırhlısı", en: "Hilal-2 armour" },
    kind: { tr: "Kara", en: "Land" },
    note: { tr: "Yerli kule, 120 mm. Varis fabrikası.", en: "Domestic turret, 120 mm. Varis works." },
  },
  {
    name: { tr: "Bozkurt füze bataryası", en: "Bozkurt missile battery" },
    kind: { tr: "Kara / kıyı", en: "Land / coast" },
    note: { tr: "Sınır ve ada yaklaşmalarını tutar.", en: "Holds border and island approaches." },
  },
  {
    name: { tr: "Kartal-C savaş uçağı", en: "Kartal-C fighter" },
    kind: { tr: "Hava", en: "Air" },
    note: { tr: "Çok rollü. Göktepe’de bakım.", en: "Multirole. Serviced at Goktepe." },
  },
  {
    name: { tr: "Gözcü-9 İHA", en: "Gozcu-9 UAV" },
    kind: { tr: "Hava", en: "Air" },
    note: { tr: "24 saat keşif. Sivil haritaya da veri verir.", en: "24-hour recon. Also feeds the civil map." },
  },
  {
    name: { tr: "Denizçi-sınıfı korvet", en: "Denizci-class corvette" },
    kind: { tr: "Deniz", en: "Sea" },
    note: { tr: "Hilalport tersanesinde inşa.", en: "Built at the Hilalport yard." },
  },
  {
    name: { tr: "Mavi Hat kıyı radarı", en: "Blue Line coastal radar" },
    kind: { tr: "Deniz", en: "Sea" },
    note: { tr: "Nelis ve Liora fenerleriyle entegre.", en: "Integrated with the Nelis and Liora lights." },
  },
];

export const milHistory: { year: string; title: Text; body: Text }[] = [
  {
    year: "2019",
    title: { tr: "MSK’nın kuruluşu", en: "Founding of the MSK" },
    body: {
      tr: "Anayasa’nın güvenlik maddesiyle üç kuvvet ve özel birlikler tek komuta altında toplandı.",
      en: "Under the constitution’s security article, three services and special units came under one command.",
    },
  },
  {
    year: "2021",
    title: { tr: "Mavi Hat tatbikatı", en: "Blue Line exercise" },
    body: {
      tr: "İlk büyük deniz-hava ortak manevrası. Hilalport’tan Nelis’e kadar kıyı kapatıldı.",
      en: "First large joint sea-air manoeuvre. The coast from Hilalport to Nelis was closed.",
    },
  },
  {
    year: "2024",
    title: { tr: "Siber alayın açılışı", en: "Cyber regiment opened" },
    body: {
      tr: "Dijital ülke altyapısını korumak üzere Mehmetkent’te siber alay kuruldu.",
      en: "A cyber regiment was raised in Mehmetkent to guard digital-state infrastructure.",
    },
  },
];
