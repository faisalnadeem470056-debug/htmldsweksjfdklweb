import type { Project } from "../types";

export const projects: Project[] = [
  {
    id: "p-map",
    title: { tr: "Resmi siyasi harita", en: "Official political map" },
    category: { tr: "Harita", en: "Map" },
    status: { tr: "Yürürlükte", en: "Live" },
    description: {
      tr: "Ulusal Harita Müdürlüğü’nün 2026 baskısı. İller düzenlenebilir veri olarak bu uygulamada tutulur.",
      en: "2026 edition of the National Mapping Directorate. Provinces are kept as editable data in this app.",
    },
  },
  {
    id: "p-mc",
    title: { tr: "Mehmetkent Minecraft ölçeği", en: "Mehmetkent Minecraft scale" },
    category: { tr: "Minecraft", en: "Minecraft" },
    status: { tr: "Yapımda", en: "In progress" },
    description: {
      tr: "Başkentin blok ölçekli modeli. Millet Meclisi ve Hilal Meydanı birinci etap.",
      en: "Block-scale model of the capital. National Assembly and Crescent Square are phase one.",
    },
  },
  {
    id: "p-game",
    title: { tr: "Mehmetistan: Vatan", en: "Mehmetistan: Homeland" },
    category: { tr: "Oyun", en: "Game" },
    status: { tr: "Aktif", en: "Active" },
    description: {
      tr: "Ulus kurma ve atlas diplomasisi. İl sınavı bu portalın içinde oynanır.",
      en: "Nation-building and atlas diplomacy. The province quiz plays inside this portal.",
    },
  },
  {
    id: "p-story",
    title: { tr: "Hilal Kronikleri", en: "Crescent Chronicles" },
    category: { tr: "Hikâye", en: "Story" },
    status: { tr: "Dizi", en: "Serial" },
    description: {
      tr: "2014’ten 2026’ya kurgusal tarih. Resmi kronoloji ile çelişmeyen anlatı.",
      en: "Fictional history from 2014 to 2026. A narrative that does not contradict the official timeline.",
    },
  },
  {
    id: "p-ai",
    title: { tr: "Dijital kâtip", en: "Digital clerk" },
    category: { tr: "Yapay zekâ", en: "AI" },
    status: { tr: "Deneysel", en: "Experimental" },
    description: {
      tr: "Kanun ve harita verisini yerelde arayan kâtip. İnternetsiz çalışması şarttır.",
      en: "A clerk that searches law and map data locally. It must run without the internet.",
    },
  },
  {
    id: "p-flag",
    title: { tr: "Bayrak sistemi", en: "Flag system" },
    category: { tr: "Tasarım", en: "Design" },
    status: { tr: "Kilitli", en: "Locked" },
    description: {
      tr: "Yeşil-siyah-mavi ve mavi hilal. Renk kodları resmi palet olarak dondurulmuştur.",
      en: "Green-black-blue and a blue crescent. Colour codes are frozen as the official palette.",
    },
  },
  {
    id: "p-code",
    title: { tr: "Açık ülke kodu", en: "Open country code" },
    category: { tr: "Kodlama", en: "Code" },
    status: { tr: "Sürekli", en: "Ongoing" },
    description: {
      tr: "İl, kanun, haber ve ekonomi veri yapıları. Yeni kayıt eklemek bir nesne daha yazmaktır.",
      en: "Data structures for provinces, laws, news and the economy. Adding a record is writing one more object.",
    },
  },
  {
    id: "p-id",
    title: { tr: "Dijital vatandaşlık kartı", en: "Digital citizenship card" },
    category: { tr: "Tasarım", en: "Design" },
    status: { tr: "Portalda", en: "In portal" },
    description: {
      tr: "Bu uygulamadaki kart üretimi. Veri cihazda kalır, sunucuya gitmez.",
      en: "Card issuing inside this app. Data stays on the device and never goes to a server.",
    },
  },
];
