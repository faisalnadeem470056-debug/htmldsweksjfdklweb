import type { City } from "../types";
import { provinces } from "./provinces";

export const cities: City[] = provinces.map((p) => ({
  id: p.id,
  name: p.name,
  provinceId: p.id,
  population: p.population,
  isCapital: true,
  isNationalCapital: p.capital,
  founded: p.capital ? "2018" : "2019",
  description: p.description,
  pin: p.pin,
}));

cities.push(
  {
    id: "hilalport",
    name: { tr: "Hilalport", en: "Hilalport" },
    provinceId: "pavel",
    population: 186_000,
    isCapital: false,
    isNationalCapital: false,
    founded: "2020",
    pin: { x: 30.4, y: 46.2 },
    description: {
      tr: "Batı açıklarındaki yeni konteyner limanı. MTT dış ticaretinin denize açıldığı kapı.",
      en: "New container port on the western approaches. Mehmetistan’s MTT trade gate to the sea.",
    },
  },
  {
    id: "akademi",
    name: { tr: "Akademikent", en: "Akademikent" },
    provinceId: "arven",
    population: 94_000,
    isCapital: false,
    isNationalCapital: false,
    founded: "2021",
    pin: { x: 32.4, y: 31.4 },
    description: {
      tr: "Kampüs kenti. Uzay mühendisliği ve dil bilimleri fakülteleri burada toplanır.",
      en: "Campus city. Space engineering and language faculties gather here.",
    },
  },
  {
    id: "isik",
    name: { tr: "Işıkova", en: "Isikova" },
    provinceId: "taris",
    population: 121_000,
    isCapital: false,
    isNationalCapital: false,
    founded: "2019",
    pin: { x: 39.0, y: 36.6 },
    description: {
      tr: "Buğday siloları ve deney tarlaları. Tarım bakanlığının açık laboratuvarı.",
      en: "Grain silos and trial fields. Open laboratory of the agriculture ministry.",
    },
  },
  {
    id: "raykent",
    name: { tr: "Raykent", en: "Raykent" },
    provinceId: "melun",
    population: 158_000,
    isCapital: false,
    isNationalCapital: false,
    founded: "2020",
    pin: { x: 47.6, y: 36.8 },
    description: {
      tr: "Yüksek hızlı hat bakım üssü. Raykent atölyeleri MSK lojistiğine de hizmet verir.",
      en: "High-speed rail works. Raykent shops also serve MSK logistics.",
    },
  },
  {
    id: "goktepe",
    name: { tr: "Göktepe", en: "Goktepe" },
    provinceId: "zoren",
    population: 67_000,
    isCapital: false,
    isNationalCapital: false,
    founded: "2023",
    pin: { x: 44.8, y: 57.2 },
    description: {
      tr: "MUA fırlatma izleme istasyonu. Gökyüzü burada devlet işidir.",
      en: "MSA launch-tracking station. Here the sky is state business.",
    },
  },
);

export function citiesByProvince(id: string) {
  return cities.filter((c) => c.provinceId === id);
}
