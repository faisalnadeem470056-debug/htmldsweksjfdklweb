import type { Law, LawCategory } from "../types";

export const LAW_CATEGORIES: { id: LawCategory; title: { tr: string; en: string } }[] = [
  { id: "constitution", title: { tr: "Anayasa", en: "Constitution" } },
  { id: "citizenship", title: { tr: "Vatandaşlık", en: "Citizenship" } },
  { id: "education", title: { tr: "Eğitim", en: "Education" } },
  { id: "security", title: { tr: "Güvenlik", en: "Security" } },
  { id: "economy", title: { tr: "Ekonomi", en: "Economy" } },
  { id: "transport", title: { tr: "Ulaşım", en: "Transport" } },
  { id: "technology", title: { tr: "Teknoloji", en: "Technology" } },
  { id: "environment", title: { tr: "Çevre", en: "Environment" } },
  { id: "other", title: { tr: "Diğer", en: "Other" } },
];

export const laws: Law[] = [
  {
    id: "a1",
    code: "AY-001",
    category: "constitution",
    year: 2018,
    title: { tr: "Mehmetistan Anayasası", en: "Constitution of Mehmetistan" },
    summary: {
      tr: "Egemenlik, kuvvetler ayrılığı, hilal bayrağı ve Mehmetkent’in başkentliği. Değiştirilemez maddeler: Cumhuriyet, dil, başkent.",
      en: "Sovereignty, separation of powers, the crescent flag and Mehmetkent as capital. Entrenched: republic, language, capital.",
    },
  },
  {
    id: "a2",
    code: "AY-014",
    category: "constitution",
    year: 2022,
    title: { tr: "Dijital Devlet Maddesi", en: "Digital State Amendment" },
    summary: {
      tr: "Resmi işlemlerin çevrimdışı-öncelikli dijital portal üzerinden yürütülmesini anayasal güvenceye alır.",
      en: "Constitutional guarantee that official business may run through an offline-first digital portal.",
    },
  },
  {
    id: "c1",
    code: "VT-003",
    category: "citizenship",
    year: 2019,
    title: { tr: "Vatandaşlık Kanunu", en: "Citizenship Act" },
    summary: {
      tr: "Doğum, soy ve hizmet yoluyla vatandaşlık. Dijital kimlik belgesi zorunludur.",
      en: "Citizenship by birth, descent or service. A digital identity document is required.",
    },
  },
  {
    id: "c2",
    code: "VT-011",
    category: "citizenship",
    year: 2024,
    title: { tr: "Diaspora Kayıt Yönetmeliği", en: "Diaspora Registry Regulation" },
    summary: {
      tr: "Yurt dışında yaşayan Mehmetistanlıların konsolosluk kaydı ve oy hakkı.",
      en: "Consular registration and voting rights for Mehmetistanis abroad.",
    },
  },
  {
    id: "e1",
    code: "EG-007",
    category: "education",
    year: 2020,
    title: { tr: "Millî Eğitim Kanunu", en: "National Education Act" },
    summary: {
      tr: "On iki yıllık zorunlu eğitim. Tarih ve harita dersi müfredatın omurgasıdır.",
      en: "Twelve years of compulsory schooling. History and map-reading sit at the core of the curriculum.",
    },
  },
  {
    id: "e2",
    code: "EG-021",
    category: "education",
    year: 2025,
    title: { tr: "Arven Akademisi Statüsü", en: "Arven Academy Statute" },
    summary: {
      tr: "Devlet üniversitesine özerklik ve uzay mühendisliği enstitüsü kurar.",
      en: "Grants the state university autonomy and founds the space-engineering institute.",
    },
  },
  {
    id: "s1",
    code: "GV-002",
    category: "security",
    year: 2019,
    title: { tr: "MSK Kuruluş Kanunu", en: "MSK Establishment Act" },
    summary: {
      tr: "Kara, hava, deniz ve özel kuvvetleri tek çatı altında toplar. Sivil denetim esastır.",
      en: "Unites army, air, navy and special forces. Civilian oversight is the rule.",
    },
  },
  {
    id: "s2",
    code: "GV-018",
    category: "security",
    year: 2023,
    title: { tr: "Siber Savunma Yönetmeliği", en: "Cyber Defence Regulation" },
    summary: {
      tr: "Dijital ülke altyapısının korunması ve zorunlu yedekleme.",
      en: "Protection of digital-state infrastructure and mandatory backups.",
    },
  },
  {
    id: "ec1",
    code: "EK-001",
    category: "economy",
    year: 2020,
    title: { tr: "MTT Para Kanunu", en: "MTT Currency Act" },
    summary: {
      tr: "Tek yasal ödeme aracı MTT’dir. Merkez Bankası emisyon yetkisini elinde tutar.",
      en: "MTT is the sole legal tender. The Central Bank holds the right of issue.",
    },
  },
  {
    id: "ec2",
    code: "EK-016",
    category: "economy",
    year: 2024,
    title: { tr: "Kamu Bütçe Disiplini", en: "Public Budget Discipline" },
    summary: {
      tr: "Açık tavanı ve yatırım öncelikleri. Uzay ve demiryolu ayrı kalemdir.",
      en: "Deficit ceiling and investment priorities. Space and rail are separate lines.",
    },
  },
  {
    id: "t1",
    code: "UL-009",
    category: "transport",
    year: 2021,
    title: { tr: "Ulusal Demiryolu Kanunu", en: "National Railway Act" },
    summary: {
      tr: "Melun–Mehmetkent–Toren omurgası kamu malıdır. Özel işletme ruhsata bağlıdır.",
      en: "The Melun–Mehmetkent–Toren spine is public property. Private operation needs a licence.",
    },
  },
  {
    id: "t2",
    code: "UL-027",
    category: "transport",
    year: 2025,
    title: { tr: "Hilalport Rejimi", en: "Hilalport Regime" },
    summary: {
      tr: "Batı limanının gümrük serbest bölgesi ve kılavuzluk zorunluluğu.",
      en: "Western port free-customs zone and compulsory pilotage.",
    },
  },
  {
    id: "tc1",
    code: "DJ-004",
    category: "technology",
    year: 2022,
    title: { tr: "Açık Veri ve Yazılım Kanunu", en: "Open Data and Software Act" },
    summary: {
      tr: "Devlet yazılımı mümkün olduğunca yerel ve çevrimdışı çalışır. Harita verisi düzenlenebilir tutulur.",
      en: "State software should run locally and offline. Map data is kept editable.",
    },
  },
  {
    id: "tc2",
    code: "DJ-012",
    category: "technology",
    year: 2026,
    title: { tr: "Yapay Zekâ Kullanım İlkeleri", en: "AI Use Principles" },
    summary: {
      tr: "Kamu yapay zekâsı denetlenebilir olmalı; kurgusal dünya verisi uydurulmuş gerçek gibi sunulamaz.",
      en: "Public AI must be auditable; fictional-world data may not be presented as invented fact about Earth.",
    },
  },
  {
    id: "en1",
    code: "CV-006",
    category: "environment",
    year: 2021,
    title: { tr: "Saven Rezervi Kanunu", en: "Saven Reserve Act" },
    summary: {
      tr: "Kıyı bataklıkları ve göçmen kuş koridoru milli parktır.",
      en: "Coastal marshes and the migratory-bird corridor are a national park.",
    },
  },
  {
    id: "en2",
    code: "CV-019",
    category: "environment",
    year: 2025,
    title: { tr: "Temiz Enerji Hedefi", en: "Clean Energy Target" },
    summary: {
      tr: "2032’ye kadar elektrik üretiminin yüzde yetmişi yerli yenilenebilir kaynak.",
      en: "Seventy percent of electricity from domestic renewables by 2032.",
    },
  },
  {
    id: "o1",
    code: "KL-003",
    category: "other",
    year: 2018,
    title: { tr: "Bayrak ve Mühür Kanunu", en: "Flag and Seal Act" },
    summary: {
      tr: "Yeşil-siyah-mavi üç kuşak ve mavi hilal. Mühürde hilal ve ülke adı yer alır.",
      en: "Green-black-blue bands and a blue crescent. The seal bears the crescent and the country’s name.",
    },
  },
  {
    id: "o2",
    code: "UZ-001",
    category: "other",
    year: 2022,
    title: { tr: "Uzay Faaliyetleri Kanunu", en: "Space Activities Act" },
    summary: {
      tr: "MUA tekelinde fırlatma; özel uydu ruhsata bağlı. Yörünge millî varlık sayılır.",
      en: "Launches under the MSA; private satellites licensed. Orbit is treated as a national asset.",
    },
  },
];
