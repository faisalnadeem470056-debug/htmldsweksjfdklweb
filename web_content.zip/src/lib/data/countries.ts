import type { Country } from "../types";

export const countries: Country[] = [
  {
    id: "mehmetistan",
    name: { tr: "Mehmetistan", en: "Mehmetistan" },
    capital: { tr: "Mehmetkent", en: "Mehmetkent" },
    relation: "ally",
    color: "#1e6ad4",
    box: { x: 26, y: 24, w: 32, h: 54 },
    history: {
      tr: "2018’de ilan edilen cumhuriyet. Atlas’ın merkez adası.",
      en: "Republic proclaimed in 2018. Central island of the atlas.",
    },
    description: {
      tr: "Dijital ülke, MTT ve MUA’nın evidir. Bu portal onun resmi yüzüdür.",
      en: "Home of the digital state, MTT and the MSA. This portal is its official face.",
    },
  },
  {
    id: "ortamistan",
    name: { tr: "Ortamistan", en: "Ortamistan" },
    capital: { tr: "Ortamkent", en: "Ortamkent" },
    relation: "ally",
    color: "#4a6d8c",
    box: { x: 14, y: 2, w: 30, h: 20 },
    history: {
      tr: "Kuzey adası. Eski denizcilik cumhuriyeti; 2023 dostluk antlaşması.",
      en: "Northern island. An old maritime republic; 2023 friendship treaty.",
    },
    description: {
      tr: "Soğuk iklim, gözlemevleri ve balık. Mehmetistan’ın en yakın kültürel akrabası.",
      en: "Cold climate, observatories and fish. Mehmetistan’s closest cultural kin.",
    },
  },
  {
    id: "kralistan",
    name: { tr: "Kralistan", en: "Kralistan" },
    capital: { tr: "Kralkent", en: "Kralkent" },
    relation: "enemy",
    color: "#b08a3c",
    box: { x: 47, y: 2, w: 26, h: 20 },
    history: {
      tr: "Kuzeydoğu krallığı. Taç hukukunu cumhuriyetlere üstün sayar; 2021’den beri gergin.",
      en: "Northeastern kingdom. Holds crown law above republics; tense since 2021.",
    },
    description: {
      tr: "Altın tarlaları ve sıkı gümrük. Hilal Doktrini’ne karşı çıkar.",
      en: "Gold fields and tight customs. Opposes the Crescent Doctrine.",
    },
  },
  {
    id: "almiraistan",
    name: { tr: "Almiraistan", en: "Almiraistan" },
    capital: { tr: "Almirakent", en: "Almirakent" },
    relation: "ally",
    color: "#7a4e8c",
    box: { x: 1, y: 22, w: 24, h: 30 },
    history: {
      tr: "Batı adası. Liman birliği; MTT’nin ilk dış muhatabı.",
      en: "Western island. A harbour league; MTT’s first foreign counterpart.",
    },
    description: {
      tr: "Ticaret ve gemi inşa. Hilalport hattının öbür ucu Almirakent’tedir.",
      en: "Trade and shipbuilding. The other end of the Hilalport line sits in Almirakent.",
    },
  },
  {
    id: "maysaistan",
    name: { tr: "Maysaistan", en: "Maysaistan" },
    capital: { tr: "Maysakent", en: "Maysakent" },
    relation: "ally",
    color: "#a45a7a",
    box: { x: 1, y: 51, w: 24, h: 26 },
    history: {
      tr: "Güneybatı tarım cumhuriyeti. 2020 tahıl protokolü hâlâ yürürlükte.",
      en: "Southwestern farm republic. The 2020 grain protocol still stands.",
    },
    description: {
      tr: "Ovalar ve sulama birlikleri. Mehmetistan’ın gıda yedek pazarını tutar.",
      en: "Plains and irrigation unions. Holds Mehmetistan’s backup food market.",
    },
  },
  {
    id: "masalistan",
    name: { tr: "Masalistan", en: "Masalistan" },
    capital: { tr: "Masalkent", en: "Masalkent" },
    relation: "neutral",
    color: "#a3533c",
    box: { x: 14, y: 70, w: 26, h: 26 },
    history: {
      tr: "Güney krallık kalıntısı. Masallar ve maden; siyasette mesafe.",
      en: "Southern remnant of a kingdom. Folklore and mines; political distance.",
    },
    description: {
      tr: "Kırmızı topraklar, dağ geçitleri. Yoren sınırı sakin tutulur.",
      en: "Red earth and mountain passes. The Yoren border is kept quiet.",
    },
  },
  {
    id: "talakistan",
    name: { tr: "Talakistan", en: "Talakistan" },
    capital: { tr: "Talakkent", en: "Talakkent" },
    relation: "ally",
    color: "#6b7d3d",
    box: { x: 56, y: 22, w: 20, h: 20 },
    history: {
      tr: "Doğu-kuzey tarım kuşağı. 2023 gümrük birliği.",
      en: "East-north farm belt. 2023 customs union.",
    },
    description: {
      tr: "Velis kapısından geçen kara ticareti. Demiryolu bağlantısı planlanır.",
      en: "Overland trade through the Velis gate. A rail link is planned.",
    },
  },
  {
    id: "hiyaristan",
    name: { tr: "Hiyaristan", en: "Hiyaristan" },
    capital: { tr: "Hiyarkent", en: "Hiyarkent" },
    relation: "neutral",
    color: "#5a8a4a",
    box: { x: 75, y: 21, w: 23, h: 21 },
    history: {
      tr: "Uzak doğu yeşil adası. Orman hukuku sıkı, diplomasi yavaş.",
      en: "Far-eastern green island. Strict forest law, slow diplomacy.",
    },
    description: {
      tr: "Kereste ve ilaç bitkileri. Mehmetistan gözlemevlerine veri satar.",
      en: "Timber and medicinal plants. Sells data to Mehmetistan observatories.",
    },
  },
  {
    id: "barlasistan",
    name: { tr: "Barlasistan", en: "Barlasistan" },
    capital: { tr: "Barlaskent", en: "Barlaskent" },
    relation: "ally",
    color: "#3d6b4a",
    box: { x: 56, y: 42, w: 20, h: 20 },
    history: {
      tr: "Tarihî akraba halk. 2023 antlaşmasının üçüncü imzacısı.",
      en: "Historic kindred people. Third signatory of the 2023 treaty.",
    },
    description: {
      tr: "Dağ ve maden. MSK ile ortak dağ okulu vardır.",
      en: "Mountains and mines. Shares a mountain school with the MSK.",
    },
  },
  {
    id: "toprakistan",
    name: { tr: "Toprakistan", en: "Toprakistan" },
    capital: { tr: "Toprakkent", en: "Toprakkent" },
    relation: "neutral",
    color: "#8a9a3c",
    box: { x: 75, y: 42, w: 23, h: 20 },
    history: {
      tr: "Doğu tarım devleti. Gübre ve tahıl ihracatçısı; bloklara girmez.",
      en: "Eastern agrarian state. Fertilizer and grain exporter; joins no blocs.",
    },
    description: {
      tr: "Geniş tarlalar. Mehmetistan’ın gübre ithalatının büyük kısmı buradan gelir.",
      en: "Broad fields. Most of Mehmetistan’s fertilizer imports come from here.",
    },
  },
  {
    id: "tarikistan",
    name: { tr: "Tarikistan", en: "Tarikistan" },
    capital: { tr: "Tarikkent", en: "Tarikkent" },
    relation: "ally",
    color: "#2f6e6a",
    box: { x: 54, y: 61, w: 22, h: 25 },
    history: {
      tr: "Güneydoğu deniz cumhuriyeti. 2024 liman protokolü.",
      en: "Southeastern maritime republic. 2024 port protocol.",
    },
    description: {
      tr: "Teal kıyılar, arşivler ve medrese geleneği. Ortak deniz tatbikatı yapılır.",
      en: "Teal coasts, archives and a college tradition. Joint naval drills are held.",
    },
  },
  {
    id: "seyyidistan",
    name: { tr: "Seyyidistan", en: "Seyyidistan" },
    capital: { tr: "Seyyidkent", en: "Seyyidkent" },
    relation: "unknown",
    color: "#6b3d6e",
    box: { x: 74, y: 61, w: 24, h: 27 },
    history: {
      tr: "Uzak güneydoğu. İç işleyişi kapalı; elçilik henüz daimî değil.",
      en: "Far southeast. Inner workings closed; the embassy is not yet permanent.",
    },
    description: {
      tr: "Mor kıyılar. Ticaret var, siyaset yok. İlişki durumu resmen ‘bilinmiyor’.",
      en: "Purple coasts. Trade exists, politics does not. Relation officially ‘unknown’.",
    },
  },
];
