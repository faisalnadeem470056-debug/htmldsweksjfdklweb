import type { Text } from "../types";

export const mttInfo = {
  code: "MTT",
  name: { tr: "Mehmetistan Tokenu", en: "Mehmetistan Token" },
  subunit: { tr: "kırat (100 kırat = 1 MTT)", en: "kirat (100 kirat = 1 MTT)" },
  issuer: { tr: "MTT Merkez Bankası", en: "MTT Central Bank" },
  parity: 1,
  notes: {
    tr: "MTT kurgusal bir devlet para birimidir. Kâğıt seri ve dijital cüzdan birlikte yürür. Dışarıda kotasyon tutulmaz; iç parite 1,00’dir.",
    en: "MTT is a fictional state currency. Paper series and digital wallet run together. No external quote is kept; internal parity is 1.00.",
  },
};

export const indicators: { label: Text; value: string; delta: string; up: boolean }[] = [
  { label: { tr: "GSYİH", en: "GDP" }, value: "142,6 Mr MTT", delta: "+3,4%", up: true },
  { label: { tr: "Enflasyon", en: "Inflation" }, value: "%2,1", delta: "−0,3", up: true },
  { label: { tr: "İşsizlik", en: "Unemployment" }, value: "%5,8", delta: "−0,4", up: true },
  { label: { tr: "Cari denge", en: "Current account" }, value: "+4,1 Mr", delta: "+0,6", up: true },
  { label: { tr: "Rezerv", en: "Reserves" }, value: "31,2 Mr", delta: "+1,1", up: true },
  { label: { tr: "Kamu borcu", en: "Public debt" }, value: "%28 GSYİH", delta: "−1,2", up: true },
];

export const budget = {
  year: 2026,
  total: 38_400_000_000,
  revenue: [
    { label: { tr: "Vergi", en: "Tax" }, pct: 54 },
    { label: { tr: "Gümrük", en: "Customs" }, pct: 14 },
    { label: { tr: "Kamu iktisadi", en: "SOEs" }, pct: 18 },
    { label: { tr: "MTT senyoraj", en: "MTT seigniorage" }, pct: 6 },
    { label: { tr: "Diğer", en: "Other" }, pct: 8 },
  ],
  spend: [
    { label: { tr: "Eğitim", en: "Education" }, pct: 18 },
    { label: { tr: "Sağlık", en: "Health" }, pct: 14 },
    { label: { tr: "MSK", en: "MSK" }, pct: 12 },
    { label: { tr: "Ulaştırma", en: "Transport" }, pct: 16 },
    { label: { tr: "Uzay ve bilim", en: "Space & science" }, pct: 9 },
    { label: { tr: "Sosyal", en: "Social" }, pct: 15 },
    { label: { tr: "Enerji", en: "Energy" }, pct: 8 },
    { label: { tr: "Diğer", en: "Other" }, pct: 8 },
  ],
};

export const tradePartners: { name: string; share: number; kind: "export" | "import" }[] = [
  { name: "Almiraistan", share: 18, kind: "export" },
  { name: "Ortamistan", share: 14, kind: "export" },
  { name: "Barlasistan", share: 12, kind: "export" },
  { name: "Talakistan", share: 11, kind: "export" },
  { name: "Maysaistan", share: 9, kind: "export" },
  { name: "Tarikistan", share: 8, kind: "export" },
  { name: "Toprakistan", share: 16, kind: "import" },
  { name: "Hiyaristan", share: 13, kind: "import" },
  { name: "Kralistan", share: 10, kind: "import" },
  { name: "Seyyidistan", share: 7, kind: "import" },
];

export const sectors: { name: Text; pct: number }[] = [
  { name: { tr: "Sanayi", en: "Industry" }, pct: 31 },
  { name: { tr: "Hizmet", en: "Services" }, pct: 44 },
  { name: { tr: "Tarım", en: "Agriculture" }, pct: 14 },
  { name: { tr: "Enerji", en: "Energy" }, pct: 6 },
  { name: { tr: "Uzay ve yazılım", en: "Space & software" }, pct: 5 },
];

export const developments: { title: Text; body: Text }[] = [
  {
    title: { tr: "Hilalport ikinci iskele", en: "Hilalport second quay" },
    body: {
      tr: "2026 bütçesinde batı limanına ikinci konteyner hattı. Yıllık kapasite hedefi 2,4 milyon TEU.",
      en: "Second container line for the western port in the 2026 budget. Target capacity 2.4 million TEU a year.",
    },
  },
  {
    title: { tr: "MTT dijital cüzdan v3", en: "MTT digital wallet v3" },
    body: {
      tr: "Çevrimdışı karekod ödemesi ve il bazlı vergi iadesi. Merkez Bankası 2026 üçüncü çeyrekte yayına alır.",
      en: "Offline QR payments and provincial tax rebates. The Central Bank ships in 2026 Q3.",
    },
  },
  {
    title: { tr: "Varis uydu parçası kümesi", en: "Varis satellite-parts cluster" },
    body: {
      tr: "MUA tedarikinin yüzde kırkı yerli hale geldi. İhracat kalemi olarak ‘uzay metalı’ açıldı.",
      en: "Forty percent of MSA supply is now domestic. ‘Space metal’ opened as an export line.",
    },
  },
];
