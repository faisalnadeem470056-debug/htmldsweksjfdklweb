import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function fmtNum(n: number, lang: "tr" | "en"): string {
  return n.toLocaleString(lang === "tr" ? "tr-TR" : "en-US");
}

export function fmtCompact(n: number, lang: "tr" | "en"): string {
  return n.toLocaleString(lang === "tr" ? "tr-TR" : "en-US", {
    notation: "compact",
    maximumFractionDigits: 1,
  });
}
