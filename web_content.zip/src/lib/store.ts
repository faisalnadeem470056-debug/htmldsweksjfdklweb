import { create } from "zustand";
import { persist } from "zustand/middleware";
import type { Locale } from "./types";

type Theme = "dark" | "light";

type AppState = {
  theme: Theme;
  lang: Locale;
  animations: boolean;
  notifications: boolean;
  seenSplash: boolean;
  highScore: number;
  citizenName: string;
  setTheme: (theme: Theme) => void;
  toggleTheme: () => void;
  setLang: (lang: Locale) => void;
  setAnimations: (v: boolean) => void;
  setNotifications: (v: boolean) => void;
  setSeenSplash: () => void;
  setHighScore: (n: number) => void;
  setCitizenName: (n: string) => void;
};

export const useApp = create<AppState>()(
  persist(
    (set, get) => ({
      theme: "dark",
      lang: "tr",
      animations: true,
      notifications: true,
      seenSplash: false,
      highScore: 0,
      citizenName: "",
      setTheme: (theme) => set({ theme }),
      toggleTheme: () => set({ theme: get().theme === "dark" ? "light" : "dark" }),
      setLang: (lang) => set({ lang }),
      setAnimations: (animations) => set({ animations }),
      setNotifications: (notifications) => set({ notifications }),
      setSeenSplash: () => set({ seenSplash: true }),
      setHighScore: (highScore) => set({ highScore }),
      setCitizenName: (citizenName) => set({ citizenName }),
    }),
    { name: "mehmetistan-settings" },
  ),
);

export function applyDocumentTheme(theme: Theme, animations: boolean) {
  const root = document.documentElement;
  root.dataset.theme = theme;
  root.dataset.anim = animations ? "on" : "off";
  root.style.colorScheme = theme;
}
