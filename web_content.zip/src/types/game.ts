export type GameState = 'MENU' | 'PLAYING' | 'PAUSED' | 'VICTORY' | 'GAMEOVER' | 'LEVELS' | 'WEAPONS' | 'UPGRADES' | 'SHOP' | 'SETTINGS';

export type WeaponType = 'pistol' | 'shotgun' | 'rifle' | 'sniper' | 'machinegun' | 'special';

export interface Weapon {
  id: WeaponType;
  name: string;
  category: string;
  damage: number;
  fireRate: number; // shots per second
  magSize: number;
  currentAmmo: number;
  reserveAmmo: number;
  reloadTime: number; // in seconds
  range: number;
  bulletSpeed: number;
  spread: number;
  pellets: number; // 1 for rifle/pistol, 6-8 for shotgun
  cost: number;
  unlocked: boolean;
  upgradeLevel: number;
  maxUpgradeLevel: number;
  color: string;
  description: string;
}

export type ZombieType = 'normal' | 'fast' | 'strong' | 'armored' | 'mutant' | 'boss';

export interface MapTheme {
  id: string;
  name: string;
  levels: [number, number]; // [startLevel, endLevel]
  bgColor: string;
  groundColor: string;
  gridColor: string;
  obstacleColor: string;
  accentColor: string;
  description: string;
  bossName: string;
}

export interface PlayerStats {
  hp: number;
  maxHp: number;
  shield: number;
  maxShield: number;
  speed: number;
  coins: number;
  xp: number;
  level: number;
  highestLevelUnlocked: number;
  stars: Record<number, number>; // levelNumber -> stars (1-3)
  perks: {
    maxHealthLevel: number;
    armorLevel: number;
    speedLevel: number;
    coinMagnetLevel: number;
    critChanceLevel: number;
  };
  inventory: WeaponType[];
  equippedWeapon: WeaponType;
}

export interface GameSettings {
  soundEnabled: boolean;
  musicEnabled: boolean;
  soundVolume: number;
  musicVolume: number;
  graphicsQuality: 'high' | 'medium' | 'low';
  sensitivity: number;
  aimAssist: boolean;
  touchControls: boolean;
}

export interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  color: string;
  radius: number;
  alpha: number;
  life: number;
  maxLife: number;
  glow?: boolean;
}

export interface FloatingText {
  id: string;
  x: number;
  y: number;
  text: string;
  color: string;
  size: number;
  alpha: number;
  life: number;
}

export interface Bullet {
  id: string;
  x: number;
  y: number;
  vx: number;
  vy: number;
  damage: number;
  rangeLeft: number;
  color: string;
  isPlayerBullet: boolean;
  piercing: number; // how many zombies it can pass through
  radius: number;
  isExplosive?: boolean;
  trailColor?: string;
}

export interface Zombie {
  id: string;
  type: ZombieType;
  x: number;
  y: number;
  hp: number;
  maxHp: number;
  speed: number;
  damage: number;
  radius: number;
  color: string;
  accentColor: string;
  attackCooldown: number;
  attackRange: number;
  isBoss?: boolean;
  bossTitle?: string;
  specialCooldown?: number;
  stateTimer?: number;
  phase?: number;
  angle: number;
  animFrame: number;
}

export interface ItemPickup {
  id: string;
  type: 'health' | 'ammo' | 'shield' | 'coin' | 'double_damage';
  x: number;
  y: number;
  value: number;
  radius: number;
  life: number;
  icon: string;
  color: string;
}

export interface Obstacle {
  x: number;
  y: number;
  width: number;
  height: number;
  type: 'crate' | 'rock' | 'barrel' | 'barrier' | 'pillar';
  health?: number; // barrels can explode!
  isExplosive?: boolean;
}
