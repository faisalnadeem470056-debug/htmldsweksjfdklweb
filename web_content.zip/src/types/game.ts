export type PlayerColor = 'red' | 'green' | 'yellow' | 'blue';

export type PlayerType = 'human' | 'bot';

export interface Token {
  id: number; // 0..3
  color: PlayerColor;
  // step: -1 means in yard/base
  // 0..50: on main path (0 is player's starting cell)
  // 51..55: on colored home column
  // 56: reached Goal/Home
  step: number;
}

export interface Player {
  color: PlayerColor;
  name: string;
  type: PlayerType;
  tokens: Token[];
  hasWon: boolean;
  rank?: number; // 1st, 2nd, 3rd, 4th
  active: boolean; // whether active in 2-player or 4-player mode
}

export type GameMode = '2-player' | '4-player';

export type GamePhase = 
  | 'start' 
  | 'rolling' 
  | 'awaiting_move' 
  | 'moving' 
  | 'turn_transition' 
  | 'game_over';

export interface GameStats {
  gamesPlayed: number;
  gamesWon: number;
  redWins: number;
  greenWins: number;
  yellowWins: number;
  blueWins: number;
  tokensCaptured: number;
  tokensLost: number;
  tokensHome: number;
  sixesRolled: number;
  highestStreak: number;
}

export interface HistoryItem {
  id: string;
  text: string;
  color: PlayerColor;
  timestamp: number;
  type: 'roll' | 'move' | 'capture' | 'home' | 'win' | 'info';
}
