import React from 'react';
import { Play, RotateCcw, Settings, Home } from 'lucide-react';

interface PauseModalProps {
  onResume: () => void;
  onRestart: () => void;
  onSettings: () => void;
  onQuit: () => void;
}

export const PauseModal: React.FC<PauseModalProps> = ({
  onResume,
  onRestart,
  onSettings,
  onQuit
}) => {
  return (
    <div id="pause-modal" className="absolute inset-0 z-40 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 select-none animate-in fade-in duration-150">
      <div className="w-full max-w-sm rounded-3xl bg-slate-950 border-2 border-slate-700/80 p-6 flex flex-col items-center text-center shadow-2xl">
        <h2 className="font-display font-black text-3xl text-white tracking-wider mb-1">
          GAME PAUSED
        </h2>
        <p className="text-xs text-slate-400 mb-6">Combat action is temporarily suspended</p>

        <div className="w-full flex flex-col gap-3">
          <button
            id="resume-btn"
            onClick={onResume}
            className="w-full py-3.5 px-6 rounded-xl bg-gradient-to-r from-rose-600 to-red-600 hover:from-rose-500 hover:to-red-500 text-white font-display font-black text-base tracking-wider flex items-center justify-center gap-2 shadow-lg shadow-rose-950/40 active:scale-95 transition-all"
          >
            <Play size={18} className="fill-white" />
            <span>RESUME MISSION</span>
          </button>

          <button
            onClick={onRestart}
            className="w-full py-3 px-6 rounded-xl bg-slate-900 border border-slate-700 hover:border-slate-500 text-slate-200 font-display font-bold text-sm flex items-center justify-center gap-2 active:scale-95 transition-all"
          >
            <RotateCcw size={16} />
            <span>RESTART LEVEL</span>
          </button>

          <button
            onClick={onSettings}
            className="w-full py-3 px-6 rounded-xl bg-slate-900 border border-slate-700 hover:border-slate-500 text-slate-200 font-display font-bold text-sm flex items-center justify-center gap-2 active:scale-95 transition-all"
          >
            <Settings size={16} className="text-rose-400" />
            <span>SETTINGS & AUDIO</span>
          </button>

          <button
            onClick={onQuit}
            className="w-full py-3 px-6 rounded-xl bg-slate-900/60 border border-slate-800 hover:border-rose-900 text-rose-400 font-display font-bold text-sm flex items-center justify-center gap-2 active:scale-95 transition-all"
          >
            <Home size={16} />
            <span>QUIT TO MAIN MENU</span>
          </button>
        </div>
      </div>
    </div>
  );
};
