import React from 'react';
import { Star, Award, Coins, ArrowRight, RotateCcw, Crosshair, Home, Skull } from 'lucide-react';

interface VictoryDefeatModalProps {
  status: 'VICTORY' | 'GAMEOVER';
  level: number;
  isBoss: boolean;
  bossName: string | null;
  starsEarned: number;
  coinsEarned: number;
  xpEarned: number;
  score: number;
  zombiesKilled: number;
  onNextLevel: () => void;
  onRetry: () => void;
  onGoToArmory: () => void;
  onGoToMenu: () => void;
}

export const VictoryDefeatModal: React.FC<VictoryDefeatModalProps> = ({
  status,
  level,
  isBoss,
  bossName,
  starsEarned,
  coinsEarned,
  xpEarned,
  score,
  zombiesKilled,
  onNextLevel,
  onRetry,
  onGoToArmory,
  onGoToMenu
}) => {
  const isVictory = status === 'VICTORY';

  return (
    <div id="end-game-modal" className="absolute inset-0 z-40 bg-black/85 backdrop-blur-md flex items-center justify-center p-4 select-none animate-in fade-in duration-200">
      <div 
        className={`w-full max-w-md rounded-3xl border-2 p-6 sm:p-8 flex flex-col items-center text-center shadow-2xl relative overflow-hidden ${
          isVictory 
            ? 'bg-slate-950 border-emerald-500/80 shadow-emerald-950/60' 
            : 'bg-slate-950 border-rose-500/80 shadow-rose-950/60'
        }`}
      >
        {/* Glow Header */}
        <div 
          className="absolute -top-20 w-48 h-48 rounded-full blur-3xl pointer-events-none opacity-40"
          style={{ backgroundColor: isVictory ? '#10b981' : '#f43f5e' }}
        />

        {/* Title & Icon */}
        <div className="relative z-10">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl mb-3 shadow-lg border-2">
            {isVictory ? (
              <Award className="text-yellow-400" size={36} />
            ) : (
              <Skull className="text-rose-500" size={36} />
            )}
          </div>

          <h2 className={`font-display font-black text-3xl sm:text-4xl tracking-wider ${
            isVictory ? 'text-white' : 'text-rose-400'
          }`}>
            {isVictory ? (isBoss ? 'BOSS CRUSHED!' : 'LEVEL COMPLETED!') : 'HUNTER DEFEATED'}
          </h2>

          <p className="text-xs text-slate-400 mt-1 font-semibold">
            {isBoss && isVictory 
              ? `${bossName} has been eradicated!` 
              : `Sector Level ${level} Combat Report`}
          </p>
        </div>

        {/* Stars Banner (for victory) */}
        {isVictory && (
          <div className="flex items-center justify-center gap-2 my-4">
            {[1, 2, 3].map(s => (
              <Star
                key={s}
                size={34}
                className={`transition-all ${
                  s <= starsEarned
                    ? 'text-yellow-400 fill-yellow-400 drop-shadow-[0_0_10px_rgba(250,204,21,0.7)] scale-110'
                    : 'text-slate-800'
                }`}
              />
            ))}
          </div>
        )}

        {/* Rewards & Combat Stats Grid */}
        <div className="w-full bg-slate-900/80 border border-slate-800 rounded-2xl p-4 my-4 grid grid-cols-2 gap-3 text-left">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-amber-500/20 border border-amber-500/40 flex items-center justify-center text-amber-400">
              <Coins size={18} />
            </div>
            <div>
              <div className="text-[10px] text-slate-400 font-bold uppercase">Coins Earned</div>
              <div className="text-sm font-mono font-bold text-amber-300">+{coinsEarned}</div>
            </div>
          </div>

          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-cyan-500/20 border border-cyan-500/40 flex items-center justify-center text-cyan-400">
              <Award size={18} />
            </div>
            <div>
              <div className="text-[10px] text-slate-400 font-bold uppercase">Experience XP</div>
              <div className="text-sm font-mono font-bold text-cyan-300">+{xpEarned}</div>
            </div>
          </div>

          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-rose-500/20 border border-rose-500/40 flex items-center justify-center text-rose-400">
              <Skull size={18} />
            </div>
            <div>
              <div className="text-[10px] text-slate-400 font-bold uppercase">Zombies Down</div>
              <div className="text-sm font-mono font-bold text-slate-200">{zombiesKilled} Kills</div>
            </div>
          </div>

          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-purple-500/20 border border-purple-500/40 flex items-center justify-center text-purple-400">
              <Star size={18} />
            </div>
            <div>
              <div className="text-[10px] text-slate-400 font-bold uppercase">Final Score</div>
              <div className="text-sm font-mono font-bold text-slate-200">{score}</div>
            </div>
          </div>
        </div>

        {/* Tip for defeat */}
        {!isVictory && (
          <p className="text-xs text-amber-300/90 italic mb-4">
            Tip: Keep moving with Dodge (Space) and upgrade your Weapon damage in the Armory!
          </p>
        )}

        {/* Action Buttons */}
        <div className="w-full flex flex-col gap-2.5">
          {isVictory ? (
            <button
              id="next-level-btn"
              onClick={onNextLevel}
              className="w-full py-3.5 px-6 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-500 hover:from-emerald-500 hover:to-teal-400 text-white font-display font-black text-base tracking-wider flex items-center justify-center gap-2 shadow-lg shadow-emerald-950/60 active:scale-95 transition-all"
            >
              <span>CONTINUE TO LEVEL {level + 1}</span>
              <ArrowRight size={18} />
            </button>
          ) : (
            <button
              id="retry-level-btn"
              onClick={onRetry}
              className="w-full py-3.5 px-6 rounded-xl bg-gradient-to-r from-rose-600 to-red-500 hover:from-rose-500 hover:to-red-400 text-white font-display font-black text-base tracking-wider flex items-center justify-center gap-2 shadow-lg shadow-rose-950/60 active:scale-95 transition-all"
            >
              <RotateCcw size={18} />
              <span>RETRY LEVEL {level}</span>
            </button>
          )}

          <div className="w-full grid grid-cols-2 gap-2">
            <button
              onClick={onGoToArmory}
              className="py-2.5 px-4 rounded-xl bg-slate-900 border border-slate-700 hover:border-slate-500 text-slate-200 font-display font-bold text-xs flex items-center justify-center gap-1.5 active:scale-95 transition-all"
            >
              <Crosshair size={14} className="text-amber-400" />
              <span>ARMORY</span>
            </button>

            <button
              onClick={onGoToMenu}
              className="py-2.5 px-4 rounded-xl bg-slate-900 border border-slate-700 hover:border-slate-500 text-slate-200 font-display font-bold text-xs flex items-center justify-center gap-1.5 active:scale-95 transition-all"
            >
              <Home size={14} className="text-cyan-400" />
              <span>MAIN MENU</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
