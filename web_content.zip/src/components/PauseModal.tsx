import React from 'react';
import { Play, RotateCcw, Home, Volume2, VolumeX, HelpCircle } from 'lucide-react';
import { sounds } from '../utils/audio';

interface PauseModalProps {
  isOpen: boolean;
  soundEnabled: boolean;
  onResume: () => void;
  onRestart: () => void;
  onHome: () => void;
  onToggleSound: () => void;
  onOpenHowToPlay: () => void;
}

export const PauseModal: React.FC<PauseModalProps> = ({
  isOpen,
  soundEnabled,
  onResume,
  onRestart,
  onHome,
  onToggleSound,
  onOpenHowToPlay,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-fade-in">
      <div className="relative w-full max-w-sm bg-slate-900 border border-amber-500/40 rounded-3xl p-6 shadow-2xl text-center">
        {/* Glow accent */}
        <div className="absolute top-0 left-1/2 -translate-x-1/2 -translate-y-1/2 w-28 h-28 bg-amber-500/20 rounded-full blur-2xl pointer-events-none" />

        <h3 className="text-2xl font-black font-cinzel text-amber-300 tracking-wide mb-1">
          GAME PAUSED
        </h3>
        <p className="text-xs text-slate-400 mb-6">Take a breather, the board is waiting.</p>

        <div className="space-y-3">
          {/* Resume */}
          <button
            onClick={() => {
              sounds.playClick();
              onResume();
            }}
            className="w-full py-3.5 px-4 rounded-xl font-bold bg-gradient-to-r from-amber-400 to-yellow-500 text-slate-950 hover:brightness-110 shadow-lg shadow-amber-500/20 flex items-center justify-center gap-2 cursor-pointer transition-transform active:scale-95"
          >
            <Play className="w-5 h-5 fill-slate-950" />
            RESUME MATCH
          </button>

          {/* Restart */}
          <button
            onClick={() => {
              sounds.playClick();
              onRestart();
            }}
            className="w-full py-3 px-4 rounded-xl font-semibold bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700/80 flex items-center justify-center gap-2 cursor-pointer transition-colors"
          >
            <RotateCcw className="w-4 h-4 text-amber-400" />
            RESTART MATCH
          </button>

          {/* Sound Toggle */}
          <button
            onClick={onToggleSound}
            className="w-full py-3 px-4 rounded-xl font-semibold bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700/80 flex items-center justify-center gap-2 cursor-pointer transition-colors"
          >
            {soundEnabled ? (
              <>
                <Volume2 className="w-4 h-4 text-emerald-400" />
                SOUND: ON
              </>
            ) : (
              <>
                <VolumeX className="w-4 h-4 text-rose-400" />
                SOUND: MUTED
              </>
            )}
          </button>

          {/* How to Play */}
          <button
            onClick={() => {
              sounds.playClick();
              onOpenHowToPlay();
            }}
            className="w-full py-3 px-4 rounded-xl font-semibold bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700/80 flex items-center justify-center gap-2 cursor-pointer transition-colors"
          >
            <HelpCircle className="w-4 h-4 text-blue-400" />
            HOW TO PLAY
          </button>

          {/* Return Home */}
          <button
            onClick={() => {
              sounds.playClick();
              onHome();
            }}
            className="w-full py-3 px-4 rounded-xl font-semibold text-rose-400 hover:bg-rose-500/10 border border-rose-500/30 flex items-center justify-center gap-2 cursor-pointer transition-colors mt-2"
          >
            <Home className="w-4 h-4" />
            QUIT TO MAIN MENU
          </button>
        </div>
      </div>
    </div>
  );
};
