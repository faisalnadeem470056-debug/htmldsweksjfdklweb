import React from 'react';
import { X, Mic, Globe, Volume2 } from 'lucide-react';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  onOpenLiveChat: () => void;
}

export function SettingsModal({ isOpen, onClose, onOpenLiveChat }: SettingsModalProps) {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm animate-fade-in">
      <div className="w-full max-w-md bg-white dark:bg-slate-900 rounded-2xl shadow-2xl border border-slate-200 dark:border-slate-800 flex flex-col overflow-hidden">
        
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-slate-200 dark:border-slate-800">
          <h2 className="text-lg font-semibold text-slate-900 dark:text-white">Settings</h2>
          <button 
            onClick={onClose}
            className="p-2 text-slate-500 hover:text-slate-700 dark:hover:text-slate-300 rounded-full hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
          >
            <X size={20} />
          </button>
        </div>

        {/* Content */}
        <div className="p-4 space-y-6">
          
          {/* Voice & Audio Section */}
          <div>
            <h3 className="text-sm font-medium text-slate-500 uppercase tracking-wider mb-3 px-1">
              Voice & Audio
            </h3>
            
            <div className="bg-slate-50 dark:bg-slate-800/50 rounded-xl p-4 border border-slate-200 dark:border-slate-800">
              <div className="flex items-start gap-4">
                <div className="p-3 bg-orange-100 text-orange-600 rounded-lg">
                  <Mic size={24} />
                </div>
                <div className="flex-1">
                  <h4 className="font-medium text-slate-900 dark:text-white mb-1">Live Conversation</h4>
                  <p className="text-sm text-slate-500 mb-4">
                    Talk to India GPT in real-time. Supports multiple languages including Hindi, English, Bengali, and more.
                  </p>
                  <button 
                    onClick={() => {
                      onClose();
                      onOpenLiveChat();
                    }}
                    className="w-full py-2 bg-orange-600 hover:bg-orange-700 text-white rounded-lg font-medium transition-colors flex items-center justify-center gap-2"
                  >
                    <Mic size={18} />
                    Start Live Chat
                  </button>
                </div>
              </div>
            </div>
          </div>

          {/* Language Section (Informational) */}
          <div>
            <h3 className="text-sm font-medium text-slate-500 uppercase tracking-wider mb-3 px-1">
              Language
            </h3>
            <div className="bg-slate-50 dark:bg-slate-800/50 rounded-xl p-4 border border-slate-200 dark:border-slate-800 flex items-center gap-3">
              <Globe size={20} className="text-slate-400" />
              <div className="text-sm text-slate-600 dark:text-slate-300">
                India GPT automatically detects and responds in your preferred language. Just start speaking or typing!
              </div>
            </div>
          </div>

        </div>
        
        {/* Footer */}
        <div className="p-4 bg-slate-50 dark:bg-slate-800/30 border-t border-slate-200 dark:border-slate-800 text-center text-xs text-slate-500">
          Version 1.0.0 • Made for India
        </div>

      </div>
    </div>
  );
}
