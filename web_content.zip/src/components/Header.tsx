import React from 'react';
import { UserRole, Teacher } from '../types';
import { getTodayJalali, getCurrentPersianTime, toPersianDigits } from '../utils/jalali';
import { 
  GraduationCap, 
  Smartphone, 
  Monitor, 
  UserCheck, 
  Sparkles, 
  RotateCcw,
  ShieldCheck
} from 'lucide-react';

interface HeaderProps {
  currentRole: UserRole;
  currentUserId: string;
  onRoleChange: (role: UserRole, userId: string) => void;
  isMobileFrame: boolean;
  onToggleFrame: () => void;
  onResetData: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  currentRole,
  currentUserId,
  onRoleChange,
  isMobileFrame,
  onToggleFrame,
  onResetData
}) => {
  const jalali = getTodayJalali();
  const time = getCurrentPersianTime();

  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-slate-200 text-slate-800 shadow-xs">
      {/* Top Banner: Jalali Date & Institute Name */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-3 flex flex-wrap items-center justify-between gap-3">
        
        {/* Branding */}
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-amber-500 to-indigo-600 flex items-center justify-center shadow-md shadow-indigo-500/20 text-white font-black text-xl tracking-tight">
            IM
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-base sm:text-lg font-bold text-slate-900 tracking-tight">
                آکادمی هوشمند تیزهوشان آی‌مکس
              </h1>
              <span className="hidden sm:inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-amber-50 text-amber-800 border border-amber-200">
                <Sparkles className="w-3 h-3 text-amber-600" />
                سمپاد ۱۴۰۵-۱۴۰۴
              </span>
            </div>
            <p className="text-xs text-slate-500">
              سامانه یکپارچه آموزشگاه تیزهوشان • پنل اساتید، اولیا و مدیریت
            </p>
          </div>
        </div>

        {/* Date & Time info */}
        <div className="hidden md:flex items-center gap-3.5 text-xs text-slate-600 bg-slate-100/90 px-3.5 py-1.5 rounded-xl border border-slate-200">
          <div className="flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
            <span>امروز:</span>
            <span className="font-semibold text-emerald-800">{jalali.fullText}</span>
          </div>
          <span className="text-slate-300">|</span>
          <div>
            ساعت: <span className="font-medium text-slate-700">{toPersianDigits(time)}</span>
          </div>
        </div>

        {/* Action Controls */}
        <div className="flex items-center gap-2">
          {/* Mobile Simulator Toggle */}
          <button
            onClick={onToggleFrame}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold transition-all ${
              isMobileFrame
                ? 'bg-indigo-600 text-white shadow-sm shadow-indigo-500/30'
                : 'bg-white hover:bg-slate-100 text-slate-700 border border-slate-200 shadow-xs'
            }`}
            title="تغییر حالت نمایش بین موبایل و دسکتاپ"
          >
            {isMobileFrame ? (
              <>
                <Smartphone className="w-3.5 h-3.5 text-indigo-200" />
                <span>شبیه‌ساز موبایل</span>
              </>
            ) : (
              <>
                <Monitor className="w-3.5 h-3.5 text-slate-500" />
                <span>نمای عریض دسکتاپ</span>
              </>
            )}
          </button>

          {/* Reset Demo Data */}
          <button
            onClick={onResetData}
            className="p-1.5 rounded-xl bg-white hover:bg-slate-100 text-slate-500 hover:text-slate-800 transition-colors border border-slate-200 shadow-xs"
            title="بازنشانی اطلاعات اولیه نمونه"
          >
            <RotateCcw className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Role Switcher Toolbar */}
      <div className="bg-slate-50/90 border-t border-slate-200/80 px-4 py-2">
        <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-1.5 text-xs font-medium text-slate-600">
            <UserCheck className="w-3.5 h-3.5 text-indigo-600" />
            <span>تغییر نقش کاربری:</span>
          </div>

          <div className="flex flex-wrap items-center gap-1.5">
            {/* Admin */}
            <button
              onClick={() => onRoleChange('admin', 'usr-admin-1')}
              className={`px-3 py-1 rounded-full text-xs font-medium transition-all ${
                currentRole === 'admin'
                  ? 'bg-rose-600 text-white shadow-xs ring-2 ring-rose-300'
                  : 'bg-white hover:bg-slate-100 text-slate-700 border border-slate-200 shadow-xs'
              }`}
            >
              مدیر کل (مهندس حسینی)
            </button>

            {/* Teacher Abbasi */}
            <button
              onClick={() => onRoleChange('teacher', 'teacher-abbasi')}
              className={`px-3 py-1 rounded-full text-xs font-medium transition-all ${
                currentRole === 'teacher' && currentUserId === 'teacher-abbasi'
                  ? 'bg-indigo-600 text-white shadow-xs ring-2 ring-indigo-300'
                  : 'bg-white hover:bg-slate-100 text-slate-700 border border-slate-200 shadow-xs'
              }`}
            >
              استاد عباسی (هوش محاسباتی و خلاقیت)
            </button>

            {/* Teacher Marhamati */}
            <button
              onClick={() => onRoleChange('teacher', 'teacher-marhamati')}
              className={`px-3 py-1 rounded-full text-xs font-medium transition-all ${
                currentRole === 'teacher' && currentUserId === 'teacher-marhamati'
                  ? 'bg-teal-600 text-white shadow-xs ring-2 ring-teal-300'
                  : 'bg-white hover:bg-slate-100 text-slate-700 border border-slate-200 shadow-xs'
              }`}
            >
              استاد مرحمتی (هوش کلامی و منطقی)
            </button>

            {/* Parent/Student Ali (Grade 6) */}
            <button
              onClick={() => onRoleChange('parent', 'parent-ali')}
              className={`px-3 py-1 rounded-full text-xs font-medium transition-all ${
                (currentRole === 'parent' || currentRole === 'student') && currentUserId === 'parent-ali'
                  ? 'bg-amber-600 text-white shadow-xs ring-2 ring-amber-300'
                  : 'bg-white hover:bg-slate-100 text-slate-700 border border-slate-200 shadow-xs'
              }`}
            >
              اولیا / دانش‌آموز (علی احمدی - ششم)
            </button>

            {/* Student Artin (Grade 9) */}
            <button
              onClick={() => onRoleChange('student', 'std-artin-9')}
              className={`px-3 py-1 rounded-full text-xs font-medium transition-all ${
                currentRole === 'student' && currentUserId === 'std-artin-9'
                  ? 'bg-purple-600 text-white shadow-xs ring-2 ring-purple-300'
                  : 'bg-white hover:bg-slate-100 text-slate-700 border border-slate-200 shadow-xs'
              }`}
            >
              دانش‌آموز (آرتین صادقی - نهم)
            </button>
          </div>
        </div>
      </div>
    </header>
  );
};
