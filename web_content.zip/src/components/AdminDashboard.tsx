import React, { useState } from 'react';
import { 
  Student, 
  Teacher, 
  ClassItem, 
  SessionItem, 
  PaymentItem, 
  ExamDefinition, 
  ExamResult,
  GradeLevel,
  GRADE_CONFIG
} from '../types';
import { 
  toPersianDigits, 
  formatToman, 
  formatPersianPercentage, 
  getTodayJalali 
} from '../utils/jalali';
import { 
  Users, 
  Layers, 
  CalendarCheck, 
  CreditCard, 
  Database, 
  CheckCircle2, 
  Trophy, 
  Plus, 
  UserPlus,
  PlusCircle,
  Clock,
  ShieldCheck
} from 'lucide-react';
import confetti from 'canvas-confetti';

interface AdminDashboardProps {
  students: Student[];
  teachers: Teacher[];
  classes: ClassItem[];
  sessions: SessionItem[];
  payments: PaymentItem[];
  exams: ExamDefinition[];
  results: ExamResult[];
  onConfirmPayment: (studentId: string, amount: number, confirmedBy: string, PersianDate: string) => void;
  onAddStudent: (student: Omit<Student, 'studentId' | 'activeCycleSessions' | 'currentCycleNumber'>) => void;
  onAddClass?: (newClass: Omit<ClassItem, 'classId'>) => void;
}

export const AdminDashboard: React.FC<AdminDashboardProps> = ({
  students,
  teachers,
  classes,
  sessions,
  payments,
  exams,
  results,
  onConfirmPayment,
  onAddStudent,
  onAddClass
}) => {
  const [activeTab, setActiveTab] = useState<'overview' | 'payments' | 'rankings' | 'students' | 'database'>('overview');
  
  // Modals state
  const [showAddStudentModal, setShowAddStudentModal] = useState(false);
  const [newStudentName, setNewStudentName] = useState('');
  const [newStudentGrade, setNewStudentGrade] = useState<GradeLevel>(6);
  const [newStudentPhone, setNewStudentPhone] = useState('');
  const [newStudentNational, setNewStudentNational] = useState('');
  const [newStudentClass, setNewStudentClass] = useState(classes[0]?.classId || '');

  // Add Class Modal State
  const [showAddClassModal, setShowAddClassModal] = useState(false);
  const [targetTeacherId, setTargetTeacherId] = useState<string>(teachers[0]?.teacherId || 'teacher-abbasi');
  const [newClassName, setNewClassName] = useState('');
  const [newClassGrade, setNewClassGrade] = useState<GradeLevel>(6);
  const [newClassSchedule, setNewClassSchedule] = useState('');
  const [selectedStudentIds, setSelectedStudentIds] = useState<string[]>([]);

  // Helpers
  const formatGradeText = (grade: GradeLevel | number) => {
    switch (grade) {
      case 3: return 'پایه سوم ابتدایی';
      case 4: return 'پایه چهارم ابتدایی';
      case 5: return 'پایه پنجم (آمادگی تیزهوشان)';
      case 6: return 'پایه ششم تیزهوشان';
      case 9: return 'پایه نهم تیزهوشان';
      default: return `پایه ${grade}`;
    }
  };

  const isJointGrade = (grade: GradeLevel | number) => {
    return grade === 5 || grade === 6 || grade === 9;
  };

  // Computed Dashboard Metrics
  const totalStudentsCount = students.length;
  const activeClassesCount = classes.length;
  const sessionsThisMonthCount = sessions.length;
  const pendingPaymentsCount = students.filter(s => s.activeCycleSessions >= 5).length;

  // Separate Rankings for Sixth Grade & Ninth Grade
  const getTopRankings = (grade: 6 | 9) => {
    const gradeStudents = students.filter(s => s.grade === grade);
    const mapped = gradeStudents.map(std => {
      const res = results.find(r => r.studentId === std.studentId);
      return {
        student: std,
        result: res,
        totalPercentage: res?.totalPercentage || 0,
        tScore: res?.tScore || 0,
        rank: res?.rank || 99
      };
    });

    return mapped.sort((a, b) => (a.rank || 99) - (b.rank || 99));
  };

  const topSixth = getTopRankings(6);
  const topNinth = getTopRankings(9);

  // Handle "تایید واریز" (Confirm Deposit)
  const handleConfirmPayment = (studentId: string) => {
    const student = students.find(s => s.studentId === studentId);
    if (!student) return;

    const jalali = getTodayJalali();
    const amount = student.grade === 9 ? 3200000 : 2800000;

    onConfirmPayment(studentId, amount, 'مهندس حسینی (مدیر کل)', jalali.formatted);

    confetti({
      particleCount: 80,
      spread: 80,
      origin: { y: 0.5 }
    });

    alert(`واریز شهریه دوره جدید برای ${student.fullName} تایید شد و شمارنده جلسات به صفر بازنشانی گردید.`);
  };

  // Handle Add Student
  const handleCreateStudent = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newStudentName.trim() || !newStudentPhone.trim()) return;

    onAddStudent({
      fullName: newStudentName.trim(),
      grade: newStudentGrade,
      parentPhone: newStudentPhone.trim(),
      nationalCode: newStudentNational.trim() || '002' + Math.floor(1000000 + Math.random() * 9000000),
      classId: newStudentClass,
      photo: newStudentGrade === 6 
        ? 'https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?w=200&auto=format&fit=crop&q=80'
        : 'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?w=200&auto=format&fit=crop&q=80'
    });

    setNewStudentName('');
    setNewStudentPhone('');
    setNewStudentNational('');
    setShowAddStudentModal(false);
  };

  // Handle Add Class
  const handleCreateClass = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newClassName.trim() || !onAddClass) return;

    const gradeNum = Number(newClassGrade) as GradeLevel;
    const isJoint = isJointGrade(gradeNum);

    onAddClass({
      className: newClassName.trim(),
      grade: gradeNum,
      teacherId: targetTeacherId,
      isJointTeaching: isJoint,
      schedule: newClassSchedule.trim() || 'روزهای زوج ۱۶:۰۰ الی ۱۸:۰۰',
      students: selectedStudentIds
    });

    setNewClassName('');
    setNewClassSchedule('');
    setSelectedStudentIds([]);
    setShowAddClassModal(false);

    confetti({
      particleCount: 70,
      spread: 70,
      origin: { y: 0.5 }
    });
  };

  const openAddClassForTeacher = (teacherId: string) => {
    setTargetTeacherId(teacherId);
    setShowAddClassModal(true);
  };

  return (
    <div className="space-y-6">
      
      {/* Admin Executive Header */}
      <div className="bg-white border border-slate-200 rounded-2xl p-5 sm:p-6 shadow-xs flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-xl font-bold text-slate-900">
              داشبورد جامع مدیریت کل آموزشگاه تیزهوشان آی‌مکس
            </h2>
            <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-rose-50 text-rose-700 border border-rose-200">
              مدیریت ارشد (Super Admin)
            </span>
          </div>
          <p className="text-xs text-slate-600 mt-1">
            نظارت تفکیک‌شده بر اساتید (عباسی و مرحمتی)، دوره‌های مالی، تاییدیه‌های واریز، آزمون‌های سمپاد و رتبه‌بندی کل
          </p>
        </div>

        <div className="flex items-center gap-2 flex-wrap">
          <button
            onClick={() => setShowAddClassModal(true)}
            className="flex items-center gap-1.5 px-3.5 py-2.5 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 border border-indigo-200 rounded-xl text-xs font-bold transition-colors"
          >
            <PlusCircle className="w-4 h-4" />
            <span>افزودن کلاس جدید</span>
          </button>
          <button
            onClick={() => setShowAddStudentModal(true)}
            className="flex items-center gap-1.5 px-4 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold shadow-xs transition-colors"
          >
            <UserPlus className="w-4 h-4" />
            <span>ثبت‌نام دانش‌آموز جدید</span>
          </button>
        </div>
      </div>

      {/* DASHBOARD METRIC CARDS */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
        
        {/* Total Students */}
        <div className="bg-white border border-slate-200 hover:border-indigo-300 p-4 rounded-2xl shadow-xs transition-all space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-xs text-slate-500 font-medium">تعداد کل دانش‌آموزان</span>
            <div className="w-8 h-8 rounded-xl bg-indigo-50 text-indigo-700 flex items-center justify-center border border-indigo-100">
              <Users className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl font-bold text-slate-900 font-mono">
            {toPersianDigits(totalStudentsCount)}
          </div>
          <span className="text-[11px] text-emerald-700 font-medium flex items-center gap-1">
            <span>در پایه‌های پنجم، ششم و نهم</span>
          </span>
        </div>

        {/* Active Classes */}
        <div className="bg-white border border-slate-200 hover:border-indigo-300 p-4 rounded-2xl shadow-xs transition-all space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-xs text-slate-500 font-medium">کلاس‌های فعال</span>
            <div className="w-8 h-8 rounded-xl bg-blue-50 text-blue-700 flex items-center justify-center border border-blue-100">
              <Layers className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl font-bold text-slate-900 font-mono">
            {toPersianDigits(activeClassesCount)}
          </div>
          <span className="text-[11px] text-blue-700 font-medium">
            استاد عباسی و استاد مرحمتی
          </span>
        </div>

        {/* Sessions this month */}
        <div className="bg-white border border-slate-200 hover:border-indigo-300 p-4 rounded-2xl shadow-xs transition-all space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-xs text-slate-500 font-medium">جلسات ثبت شده</span>
            <div className="w-8 h-8 rounded-xl bg-teal-50 text-teal-700 flex items-center justify-center border border-teal-100">
              <CalendarCheck className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl font-bold text-slate-900 font-mono">
            {toPersianDigits(sessionsThisMonthCount)}
          </div>
          <span className="text-[11px] text-teal-700 font-medium">
            گزارش دقیق به اولیا
          </span>
        </div>

        {/* Pending Payments */}
        <div className="bg-white border border-slate-200 hover:border-indigo-300 p-4 rounded-2xl shadow-xs transition-all space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-xs text-slate-500 font-medium">شهریه‌های سررسید</span>
            <div className="w-8 h-8 rounded-xl bg-rose-50 text-rose-700 flex items-center justify-center border border-rose-100">
              <CreditCard className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl font-bold text-rose-700 font-mono">
            {toPersianDigits(pendingPaymentsCount)}
          </div>
          <span className="text-[11px] text-rose-600 font-medium">
            جلسه ۵ به بالا (آماده تایید)
          </span>
        </div>
      </div>

      {/* Tabs Navigation */}
      <div className="flex rounded-xl bg-slate-100 p-1 border border-slate-200 overflow-x-auto gap-1">
        <button
          onClick={() => setActiveTab('overview')}
          className={`flex-1 min-w-[130px] py-2 px-3 rounded-lg text-xs font-bold transition-all ${
            activeTab === 'overview' ? 'bg-white text-indigo-700 shadow-xs' : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          نظارت کلی و اساتید
        </button>

        <button
          onClick={() => setActiveTab('payments')}
          className={`flex-1 min-w-[140px] py-2 px-3 rounded-lg text-xs font-bold transition-all ${
            activeTab === 'payments' ? 'bg-white text-indigo-700 shadow-xs' : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          مدیریت شهریه‌ها و تایید واریز
        </button>

        <button
          onClick={() => setActiveTab('rankings')}
          className={`flex-1 min-w-[150px] py-2 px-3 rounded-lg text-xs font-bold transition-all ${
            activeTab === 'rankings' ? 'bg-white text-indigo-700 shadow-xs' : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          رتبه‌بندی ششم و نهم سمپاد
        </button>

        <button
          onClick={() => setActiveTab('students')}
          className={`flex-1 min-w-[130px] py-2 px-3 rounded-lg text-xs font-bold transition-all ${
            activeTab === 'students' ? 'bg-white text-indigo-700 shadow-xs' : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          فهرست کل دانش‌آموزان
        </button>

        <button
          onClick={() => setActiveTab('database')}
          className={`flex-1 min-w-[140px] py-2 px-3 rounded-lg text-xs font-bold transition-all ${
            activeTab === 'database' ? 'bg-white text-indigo-700 shadow-xs' : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          معماری پایگاه داده و امنیت
        </button>
      </div>

      {/* TAB 1: OVERVIEW & TEACHERS MANAGEMENT */}
      {activeTab === 'overview' && (
        <div className="space-y-6">
          
          {/* Teachers Section */}
          <div className="bg-white border border-slate-200 rounded-2xl p-5 sm:p-6 space-y-4 shadow-xs">
            <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-100 pb-3">
              <div>
                <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
                  <Users className="w-5 h-5 text-indigo-600" />
                  <span>هیات علمی و اساتید آموزشگاه تیزهوشان آی‌مکس</span>
                </h3>
                <p className="text-xs text-slate-500 mt-0.5">
                  تفکیک تخصص و امکان افزودن کلاس مجزا برای هر مدرس
                </p>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {teachers.map((t) => {
                const teacherSessions = sessions.filter(s => s.teacherId === t.teacherId);
                const teacherClasses = classes.filter(c => t.assignedClasses.includes(c.classId) || c.teacherId === t.teacherId);

                return (
                  <div
                    key={t.teacherId}
                    className="bg-slate-50 border border-slate-200 p-5 rounded-2xl space-y-4 hover:border-indigo-300 transition-colors"
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3.5">
                        <img
                          src={t.photo}
                          alt={t.fullName}
                          className="w-14 h-14 rounded-2xl object-cover border border-slate-200 shadow-xs"
                        />
                        <div>
                          <h4 className="font-bold text-slate-900 text-sm sm:text-base">
                            {t.fullName}
                          </h4>
                          <p className="text-xs text-amber-700 font-bold mt-0.5">
                            {t.subject}
                          </p>
                          <p className="text-[11px] text-slate-500 font-mono mt-0.5">
                            تماس: {toPersianDigits(t.phone)}
                          </p>
                        </div>
                      </div>

                      <button
                        onClick={() => openAddClassForTeacher(t.teacherId)}
                        className="flex items-center gap-1 px-3 py-1.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-semibold shadow-xs"
                      >
                        <Plus className="w-3.5 h-3.5" />
                        <span>افزودن کلاس</span>
                      </button>
                    </div>

                    <div className="bg-white p-3 rounded-xl border border-slate-200 text-xs space-y-1.5">
                      <div className="flex justify-between">
                        <span className="text-slate-500">کلاس‌های تحت مدیریت:</span>
                        <span className="font-bold text-slate-800">{toPersianDigits(teacherClasses.length)} کلاس</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-slate-500">جلسات ثبت شده:</span>
                        <span className="font-bold text-emerald-700 font-mono">{toPersianDigits(teacherSessions.length)} جلسه</span>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Classes Overview */}
          <div className="bg-white border border-slate-200 rounded-2xl p-5 sm:p-6 space-y-4 shadow-xs">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
                <Layers className="w-5 h-5 text-indigo-600" />
                <span>کلاس‌های در حال برگزاری موسسه آی‌مکس</span>
              </h3>
              <button
                onClick={() => setShowAddClassModal(true)}
                className="flex items-center gap-1.5 px-3.5 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-semibold shadow-xs"
              >
                <PlusCircle className="w-3.5 h-3.5" />
                <span>افزودن کلاس جدید</span>
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
              {classes.map(c => {
                const assignedTeacher = teachers.find(t => t.teacherId === c.teacherId || t.assignedClasses.includes(c.classId));
                const isJoint = c.isJointTeaching ?? isJointGrade(c.grade);

                return (
                  <div key={c.classId} className="bg-slate-50 border border-slate-200 p-4 rounded-xl space-y-2 hover:border-slate-300 transition-colors">
                    <div className="flex justify-between items-start gap-1">
                      <h5 className="font-bold text-xs text-slate-900 line-clamp-1">{c.className}</h5>
                      <span className="text-[10px] bg-indigo-50 text-indigo-700 border border-indigo-200 px-2 py-0.5 rounded-full font-bold shrink-0">
                        {formatGradeText(c.grade)}
                      </span>
                    </div>

                    <div>
                      {isJoint ? (
                        <span className="inline-flex items-center gap-1 text-[9px] font-bold text-emerald-700 bg-emerald-50 px-1.5 py-0.5 rounded-md border border-emerald-200">
                          <Layers className="w-2.5 h-2.5 text-emerald-600" />
                          تدریس مشترک (عباسی و مرحمتی)
                        </span>
                      ) : (
                        <span className="inline-flex items-center gap-1 text-[9px] font-bold text-amber-700 bg-amber-50 px-1.5 py-0.5 rounded-md border border-amber-200">
                          <ShieldCheck className="w-2.5 h-2.5 text-amber-600" />
                          کلاس مستقل مدرس
                        </span>
                      )}
                    </div>

                    <p className="text-[11px] text-slate-500 flex items-center gap-1">
                      <Clock className="w-3 h-3 text-slate-400" />
                      <span>{c.schedule}</span>
                    </p>
                    <div className="text-[11px] text-slate-600 pt-2 border-t border-slate-200 flex justify-between">
                      <span>مدرس: {assignedTeacher ? assignedTeacher.name : 'اساتید آموزشگاه'}</span>
                      <span className="font-bold font-mono">{toPersianDigits(c.students.length)} نفر</span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

        </div>
      )}

      {/* TAB 2: SMART PAYMENT MANAGEMENT */}
      {activeTab === 'payments' && (
        <div className="space-y-5">
          <div className="bg-white border border-slate-200 rounded-2xl p-5 sm:p-6 space-y-5 shadow-xs">
            
            <div>
              <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
                <CreditCard className="w-5 h-5 text-amber-600" />
                <span>سامانه هوشمند بررسی وضعیت شهریه و دکمه «تایید واریز»</span>
              </h3>
              <p className="text-xs text-slate-500 mt-1">
                قوانین وضعیت: کمتر از ۵ جلسه: نوار زرد (فعال) • جلسه ۵ تا ۷: نوار نارنجی (نزدیک به پرداخت) • جلسه ۸ به بالا: نوار قرمز (مهلت واریز). با کلیک روی «تایید واریز»، شمارنده جلسات صفر شده و دوره جدید آغاز می‌گردد.
              </p>
            </div>

            {/* Students Payment Table */}
            <div className="overflow-x-auto rounded-xl border border-slate-200">
              <table className="w-full text-right text-xs">
                <thead className="bg-slate-50 text-slate-700 font-semibold border-b border-slate-200">
                  <tr>
                    <th className="p-3">دانش‌آموز</th>
                    <th className="p-3 text-center">پایه</th>
                    <th className="p-3 text-center">جلسات طی شده</th>
                    <th className="p-3">وضعیت چرخه</th>
                    <th className="p-3 text-center">دوره فعلی</th>
                    <th className="p-3 text-center">شهریه دوره</th>
                    <th className="p-3 text-center">عملیات مدیریت</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 bg-white text-slate-800">
                  {students.map((std) => {
                    const count = std.activeCycleSessions;
                    const isRed = count >= 8;
                    const isOrange = count >= 5 && count < 8;

                    return (
                      <tr key={std.studentId} className="hover:bg-slate-50/70 transition-colors">
                        <td className="p-3">
                          <div className="flex items-center gap-2.5">
                            <img
                              src={std.photo}
                              alt={std.fullName}
                              className="w-8 h-8 rounded-lg object-cover border border-slate-200"
                            />
                            <div>
                              <div className="font-bold text-slate-900">{std.fullName}</div>
                              <div className="text-[11px] text-slate-500 font-mono">
                                {toPersianDigits(std.parentPhone)}
                              </div>
                            </div>
                          </div>
                        </td>

                        <td className="p-3 text-center font-semibold">
                          {std.grade === 6 ? 'ششم' : std.grade === 9 ? 'نهم' : 'پنجم'}
                        </td>

                        <td className="p-3 text-center font-mono font-bold">
                          <span className={`px-2 py-0.5 rounded text-xs ${
                            isRed ? 'bg-rose-50 text-rose-700 border border-rose-200' :
                            isOrange ? 'bg-orange-50 text-orange-700 border border-orange-200' :
                            'bg-amber-50 text-amber-700 border border-amber-200'
                          }`}>
                            {toPersianDigits(count)} از ۸ جلسه
                          </span>
                        </td>

                        <td className="p-3">
                          <div className="space-y-1 max-w-[200px]">
                            <div className="flex justify-between text-[11px]">
                              <span className={
                                isRed ? 'text-rose-700 font-bold' :
                                isOrange ? 'text-orange-700 font-semibold' :
                                'text-amber-800'
                              }>
                                {isRed ? 'لطفاً شهریه دوره جدید پرداخت شود' :
                                 isOrange ? 'زمان پرداخت دوره جدید نزدیک است' :
                                 'جلسات فعال'}
                              </span>
                            </div>
                            <div className="w-full bg-slate-100 rounded-full h-2 overflow-hidden border border-slate-200">
                              <div
                                className={`h-full rounded-full ${
                                  isRed ? 'bg-rose-500' :
                                  isOrange ? 'bg-orange-500' :
                                  'bg-amber-500'
                                }`}
                                style={{ width: `${Math.min(100, (count / 8) * 100)}%` }}
                              ></div>
                            </div>
                          </div>
                        </td>

                        <td className="p-3 text-center font-mono font-bold text-slate-600">
                          دوره {toPersianDigits(std.currentCycleNumber)}
                        </td>

                        <td className="p-3 text-center font-mono text-emerald-700 font-bold">
                          {formatToman(std.grade === 9 ? 3200000 : 2800000)}
                        </td>

                        {/* Admin Action Button: "تایید واریز" */}
                        <td className="p-3 text-center">
                          <button
                            onClick={() => handleConfirmPayment(std.studentId)}
                            className="px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs shadow-xs flex items-center justify-center gap-1.5 mx-auto transition-all active:scale-95"
                          >
                            <CheckCircle2 className="w-3.5 h-3.5" />
                            <span>تایید واریز</span>
                          </button>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>

            {/* Total Payments History */}
            <div className="space-y-3 pt-2">
              <h4 className="text-xs font-bold text-slate-700">
                تاریخچه آخرین واریزی‌های تایید شده در سیستم:
              </h4>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                {payments.map((p) => (
                  <div
                    key={p.paymentId}
                    className="bg-slate-50 p-3.5 rounded-xl border border-slate-200 text-xs space-y-1.5"
                  >
                    <div className="flex justify-between items-center">
                      <span className="font-bold text-slate-900">{p.studentName}</span>
                      <span className="text-emerald-700 font-mono font-bold">{formatToman(p.amount)}</span>
                    </div>
                    <div className="flex justify-between text-[11px] text-slate-500">
                      <span>دوره {toPersianDigits(p.cycleNumber)}</span>
                      <span className="font-mono">{toPersianDigits(p.PersianDate)}</span>
                    </div>
                    <div className="text-[10px] text-indigo-600">
                      تاییدکننده: {p.confirmedBy || 'مدیریت کل'}
                    </div>
                  </div>
                ))}
              </div>
            </div>

          </div>
        </div>
      )}

      {/* TAB 3: SEPARATE RANKING SYSTEM */}
      {activeTab === 'rankings' && (
        <div className="space-y-5">
          <div className="bg-white border border-slate-200 rounded-2xl p-5 sm:p-6 space-y-5 shadow-xs">
            <div>
              <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
                <Trophy className="w-5 h-5 text-amber-500" />
                <span>رتبه‌بندی رسمی داوطلبان سمپاد به تفکیک پایه ششم و نهم</span>
              </h3>
              <p className="text-xs text-slate-500 mt-1">
                مدیریت کل به رتبه‌بندی کامل تمام دانش‌آموزان دسترسی دارد؛ اولیا فقط رتبه فرزند خود را مشاهده می‌کنند.
              </p>
            </div>

            {/* Two Column Grid for 6th and 9th Grade Rankings */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              
              {/* Sixth Grade Leaderboard */}
              <div className="bg-slate-50 border border-indigo-200 rounded-2xl p-4 space-y-3">
                <div className="flex items-center justify-between border-b border-indigo-100 pb-2.5">
                  <div className="flex items-center gap-2">
                    <Trophy className="w-4 h-4 text-amber-500" />
                    <h4 className="font-bold text-sm text-indigo-900">
                      رتبه‌بندی پایه ششم تیزهوشان
                    </h4>
                  </div>
                  <span className="text-xs text-slate-500">دفترچه ۱ (تحلیلی) و دفترچه ۲</span>
                </div>

                <div className="space-y-2">
                  {topSixth.map((item) => (
                    <div
                      key={item.student.studentId}
                      className={`flex items-center justify-between p-3 rounded-xl border text-xs transition-colors ${
                        item.rank === 1 ? 'bg-amber-50 border-amber-300 text-amber-900' :
                        item.rank === 2 ? 'bg-white border-slate-200 text-slate-800 shadow-2xs' :
                        item.rank === 3 ? 'bg-white border-slate-200 text-slate-800' :
                        'bg-white border-slate-200 text-slate-700'
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        <span className={`w-7 h-7 rounded-lg flex items-center justify-center font-bold font-mono text-xs ${
                          item.rank === 1 ? 'bg-amber-500 text-slate-900 shadow-xs font-black' :
                          item.rank === 2 ? 'bg-slate-200 text-slate-800' :
                          item.rank === 3 ? 'bg-amber-100 text-amber-800' :
                          'bg-slate-100 text-slate-600'
                        }`}>
                          {toPersianDigits(item.rank)}
                        </span>
                        <div className="flex items-center gap-2">
                          <img
                            src={item.student.photo}
                            alt={item.student.fullName}
                            className="w-8 h-8 rounded-lg object-cover border border-slate-200"
                          />
                          <div>
                            <div className="font-bold text-slate-900 text-xs">{item.student.fullName}</div>
                            <div className="text-[11px] text-slate-500">رتبه {toPersianDigits(item.rank)}</div>
                          </div>
                        </div>
                      </div>

                      <div className="text-left font-mono">
                        <div className="font-bold text-indigo-700 text-sm">
                          {formatPersianPercentage(item.totalPercentage)}
                        </div>
                        <div className="text-[10px] text-slate-500">
                          تراز: {toPersianDigits(item.tScore)}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Ninth Grade Leaderboard */}
              <div className="bg-slate-50 border border-purple-200 rounded-2xl p-4 space-y-3">
                <div className="flex items-center justify-between border-b border-purple-100 pb-2.5">
                  <div className="flex items-center gap-2">
                    <Trophy className="w-4 h-4 text-purple-600" />
                    <h4 className="font-bold text-sm text-purple-900">
                      رتبه‌بندی پایه نهم تیزهوشان
                    </h4>
                  </div>
                  <span className="text-xs text-slate-500">تحصیلی و تحلیلی</span>
                </div>

                <div className="space-y-2">
                  {topNinth.map((item) => (
                    <div
                      key={item.student.studentId}
                      className={`flex items-center justify-between p-3 rounded-xl border text-xs transition-colors ${
                        item.rank === 1 ? 'bg-purple-50 border-purple-300 text-purple-900' :
                        'bg-white border-slate-200 text-slate-800'
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        <span className={`w-7 h-7 rounded-lg flex items-center justify-center font-bold font-mono text-xs ${
                          item.rank === 1 ? 'bg-purple-600 text-white font-black' :
                          'bg-slate-100 text-slate-600'
                        }`}>
                          {toPersianDigits(item.rank)}
                        </span>
                        <div className="flex items-center gap-2">
                          <img
                            src={item.student.photo}
                            alt={item.student.fullName}
                            className="w-8 h-8 rounded-lg object-cover border border-slate-200"
                          />
                          <div>
                            <div className="font-bold text-slate-900 text-xs">{item.student.fullName}</div>
                            <div className="text-[11px] text-slate-500">رتبه {toPersianDigits(item.rank)}</div>
                          </div>
                        </div>
                      </div>

                      <div className="text-left font-mono">
                        <div className="font-bold text-purple-700 text-sm">
                          {formatPersianPercentage(item.totalPercentage)}
                        </div>
                        <div className="text-[10px] text-slate-500">
                          تراز: {toPersianDigits(item.tScore)}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

            </div>

          </div>
        </div>
      )}

      {/* TAB 4: STUDENTS LIST */}
      {activeTab === 'students' && (
        <div className="space-y-4">
          <div className="bg-white border border-slate-200 rounded-2xl p-5 sm:p-6 space-y-4 shadow-xs">
            <div className="flex justify-between items-center border-b border-slate-100 pb-3">
              <h3 className="font-bold text-slate-900 text-base">بانک اطلاعات دانش‌آموزان موسسه</h3>
              <button
                onClick={() => setShowAddStudentModal(true)}
                className="px-3.5 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-semibold flex items-center gap-1.5 shadow-xs"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>افزودن دانش‌آموز</span>
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
              {students.map(s => (
                <div key={s.studentId} className="bg-slate-50 border border-slate-200 p-4 rounded-xl flex items-center gap-3 hover:border-indigo-300 transition-colors">
                  <img src={s.photo} alt={s.fullName} className="w-12 h-12 rounded-xl object-cover border border-slate-200" />
                  <div className="space-y-0.5 text-xs">
                    <div className="font-bold text-slate-900">{s.fullName}</div>
                    <div className="text-indigo-600 font-medium">{formatGradeText(s.grade)}</div>
                    <div className="text-slate-500 font-mono">{toPersianDigits(s.parentPhone)}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* TAB 5: FIREBASE ARCHITECTURE & SCHEMA INSPECTOR */}
      {activeTab === 'database' && (
        <div className="bg-white border border-slate-200 rounded-2xl p-5 sm:p-6 space-y-4 text-xs shadow-xs">
          <div>
            <h3 className="font-bold text-slate-900 text-base flex items-center gap-2">
              <Database className="w-5 h-5 text-amber-500" />
              <span>ساختار پایگاه داده و معماری Cloud Firestore موسسه آی‌مکس</span>
            </h3>
            <p className="text-slate-500 mt-1">
              تعریف مجموعه‌ها، فیلدها و قوانین امنیتی نقش‌محور (RBAC) طراحی شده برای مقیاس‌پذیری و تفکیک اساتید
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 space-y-2">
              <span className="font-bold text-indigo-700 block">مجموعه‌های اصلی (Collections):</span>
              <ul className="list-disc list-inside text-slate-700 space-y-1 font-mono">
                <li><span className="text-amber-800 font-bold">teachers</span>: استاد عباسی (محاسباتی) و استاد مرحمتی (کلامی)</li>
                <li><span className="text-amber-800 font-bold">classes</span>: classId, className, grade, teacherId, students</li>
                <li><span className="text-amber-800 font-bold">students</span>: studentId, fullName, photo, grade, parentPhone</li>
                <li><span className="text-amber-800 font-bold">sessions</span>: sessionId, classId, teacherId, PersianDate, time</li>
                <li><span className="text-amber-800 font-bold">payments</span>: studentId, amount, paymentStatus, cycleNumber</li>
                <li><span className="text-amber-800 font-bold">exams & results</span>: scores, rank, percentile, AI analysis</li>
              </ul>
            </div>

            <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 space-y-2">
              <span className="font-bold text-emerald-700 block">سیاست‌های امنیتی Firestore (Security Rules):</span>
              <ul className="list-disc list-inside text-slate-700 space-y-1">
                <li>استاد عباسی صرفاً به کلاس‌ها و جلسات تخصصی خود (هوش محاسباتی و خلاقیت) دسترسی دارد.</li>
                <li>استاد مرحمتی صرفاً به کلاس‌ها و جلسات تخصصی خود (هوش کلامی و منطقی) دسترسی دارد.</li>
                <li>اولیا صرفاً کارنامه، رتبه و حضور فرزند خود را مشاهده می‌نمایند.</li>
                <li>دکمه «تایید واریز» و بازنشانی چرخه مالی صرفاً با دسترسی مدیریت (Admin) قابل اجراست.</li>
              </ul>
            </div>
          </div>
        </div>
      )}

      {/* Add Student Modal */}
      {showAddStudentModal && (
        <div className="fixed inset-0 z-50 bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white border border-slate-200 w-full max-w-md rounded-2xl p-6 space-y-4 shadow-xl text-slate-800">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <h3 className="text-base font-bold text-slate-900">ثبت‌نام داوطلب تیزهوشان جدید</h3>
              <button
                onClick={() => setShowAddStudentModal(false)}
                className="text-slate-400 hover:text-slate-700"
              >
                ✕
              </button>
            </div>
            
            <form onSubmit={handleCreateStudent} className="space-y-3 text-xs">
              <div>
                <label className="text-slate-700 font-semibold block mb-1">نام و نام‌خانوادگی:</label>
                <input
                  type="text"
                  required
                  placeholder="مثال: پارسا کاظمی"
                  value={newStudentName}
                  onChange={(e) => setNewStudentName(e.target.value)}
                  className="w-full bg-white p-2.5 rounded-xl border border-slate-300 text-slate-900 focus:outline-none focus:border-indigo-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="text-slate-700 font-semibold block mb-1">پایه تحصیلی:</label>
                  <select
                    value={newStudentGrade}
                    onChange={(e) => setNewStudentGrade(Number(e.target.value) as GradeLevel)}
                    className="w-full bg-white p-2.5 rounded-xl border border-slate-300 text-slate-900 focus:outline-none focus:border-indigo-500 font-medium"
                  >
                    <option value={3}>پایه سوم ابتدایی</option>
                    <option value={4}>پایه چهارم ابتدایی</option>
                    <option value={5}>پایه پنجم (آمادگی تیزهوشان)</option>
                    <option value={6}>پایه ششم تیزهوشان</option>
                    <option value={9}>پایه نهم تیزهوشان</option>
                  </select>
                </div>

                <div>
                  <label className="text-slate-700 font-semibold block mb-1">شماره تماس اولیا:</label>
                  <input
                    type="tel"
                    required
                    placeholder="09121234567"
                    value={newStudentPhone}
                    onChange={(e) => setNewStudentPhone(e.target.value)}
                    className="w-full bg-white p-2.5 rounded-xl border border-slate-300 text-slate-900 font-mono focus:outline-none focus:border-indigo-500"
                  />
                </div>
              </div>

              <div>
                <label className="text-slate-700 font-semibold block mb-1">کد ملی:</label>
                <input
                  type="text"
                  placeholder="0023456789"
                  value={newStudentNational}
                  onChange={(e) => setNewStudentNational(e.target.value)}
                  className="w-full bg-white p-2.5 rounded-xl border border-slate-300 text-slate-900 font-mono focus:outline-none focus:border-indigo-500"
                />
              </div>

              <div>
                <label className="text-slate-700 font-semibold block mb-1">تخصیص کلاس اولیه:</label>
                <select
                  value={newStudentClass}
                  onChange={(e) => setNewStudentClass(e.target.value)}
                  className="w-full bg-white p-2.5 rounded-xl border border-slate-300 text-slate-900 focus:outline-none focus:border-indigo-500"
                >
                  {classes.map(c => (
                    <option key={c.classId} value={c.classId}>
                      {c.className}
                    </option>
                  ))}
                </select>
              </div>

              <div className="flex gap-2 pt-3">
                <button
                  type="button"
                  onClick={() => setShowAddStudentModal(false)}
                  className="flex-1 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold rounded-xl"
                >
                  انصراف
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white font-bold rounded-xl shadow-xs"
                >
                  ثبت‌نام دانش‌آموز
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ADD CLASS MODAL FOR SPECIFIC TEACHER */}
      {showAddClassModal && (
        <div className="fixed inset-0 z-50 bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white border border-slate-200 w-full max-w-lg rounded-2xl p-6 space-y-4 shadow-xl text-slate-800">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div className="flex items-center gap-2">
                <PlusCircle className="w-5 h-5 text-indigo-600" />
                <h3 className="text-base font-bold text-slate-900">افزودن کلاس جدید به تفکیک مدرس</h3>
              </div>
              <button
                onClick={() => setShowAddClassModal(false)}
                className="text-slate-400 hover:text-slate-700"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleCreateClass} className="space-y-3.5 text-xs">
              <div>
                <label className="text-slate-700 font-semibold block mb-1">انتخاب مدرس کلاس:</label>
                <select
                  value={targetTeacherId}
                  onChange={(e) => setTargetTeacherId(e.target.value)}
                  className="w-full bg-white p-2.5 rounded-xl border border-slate-300 text-slate-900 focus:outline-none focus:border-indigo-500 font-medium"
                >
                  {teachers.map(t => (
                    <option key={t.teacherId} value={t.teacherId}>
                      {t.fullName} ({t.subject})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="text-slate-700 font-semibold block mb-1">نام کلاس:</label>
                <input
                  type="text"
                  required
                  placeholder="مثال: کلاس هوش محاسباتی ششم - کد ۱۰۲"
                  value={newClassName}
                  onChange={(e) => setNewClassName(e.target.value)}
                  className="w-full bg-white p-2.5 rounded-xl border border-slate-300 text-slate-900 focus:outline-none focus:border-indigo-500"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                <div>
                  <label className="text-slate-700 font-semibold block mb-1">پایه تحصیلی:</label>
                  <select
                    value={newClassGrade}
                    onChange={(e) => setNewClassGrade(Number(e.target.value) as GradeLevel)}
                    className="w-full bg-white p-2.5 rounded-xl border border-slate-300 text-slate-900 focus:outline-none focus:border-indigo-500 font-medium"
                  >
                    <option value={3}>پایه سوم ابتدایی (کلاس مستقل)</option>
                    <option value={4}>پایه چهارم ابتدایی (کلاس مستقل)</option>
                    <option value={5}>پایه پنجم (تدریس مشترک عباسی و مرحمتی)</option>
                    <option value={6}>پایه ششم تیزهوشان (تدریس مشترک عباسی و مرحمتی)</option>
                    <option value={9}>پایه نهم تیزهوشان (تدریس مشترک عباسی و مرحمتی)</option>
                  </select>
                </div>

                <div>
                  <label className="text-slate-700 font-semibold block mb-1">برنامه هفتگی:</label>
                  <input
                    type="text"
                    placeholder="مثال: شنبه و چهارشنبه ۱۸:۰۰"
                    value={newClassSchedule}
                    onChange={(e) => setNewClassSchedule(e.target.value)}
                    className="w-full bg-white p-2.5 rounded-xl border border-slate-300 text-slate-900 focus:outline-none focus:border-indigo-500"
                  />
                </div>
              </div>

              {/* Explanatory Teaching Notice */}
              {isJointGrade(newClassGrade) ? (
                <div className="p-3 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-900 text-xs flex items-start gap-2">
                  <Layers className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                  <div>
                    <span className="font-bold">ساختار تدریس مشترک (پایه‌های پنجم، ششم و نهم):</span>
                    <p className="text-[11px] text-emerald-700 mt-0.5 leading-relaxed">
                      فقط در پایه‌های ۵، ۶ و ۹ استاد عباسی و استاد مرحمتی به صورت توأمان و مشترک تدریس می‌کنند.
                    </p>
                  </div>
                </div>
              ) : (
                <div className="p-3 rounded-xl bg-amber-50 border border-amber-200 text-amber-900 text-xs flex items-start gap-2">
                  <ShieldCheck className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
                  <div>
                    <span className="font-bold">کلاس مستقل مدرس (پایه‌های سوم و چهارم):</span>
                    <p className="text-[11px] text-amber-700 mt-0.5 leading-relaxed">
                      هر مدرس برای پایه‌های سوم و چهارم کلاس‌های مستقل خود را برگزار می‌نماید.
                    </p>
                  </div>
                </div>
              )}

              <div>
                <label className="text-slate-700 font-semibold block mb-1">انتخاب دانش‌آموزان ثبت‌نامی:</label>
                <div className="max-h-36 overflow-y-auto border border-slate-200 rounded-xl p-2 space-y-1 bg-slate-50">
                  {students.map((std) => (
                    <label
                      key={std.studentId}
                      className="flex items-center gap-2 p-1.5 rounded-lg hover:bg-white text-xs text-slate-700 cursor-pointer"
                    >
                      <input
                        type="checkbox"
                        checked={selectedStudentIds.includes(std.studentId)}
                        onChange={(e) => {
                          if (e.target.checked) {
                            setSelectedStudentIds([...selectedStudentIds, std.studentId]);
                          } else {
                            setSelectedStudentIds(selectedStudentIds.filter(id => id !== std.studentId));
                          }
                        }}
                        className="rounded text-indigo-600 focus:ring-indigo-500"
                      />
                      <span>{std.fullName} ({formatGradeText(std.grade)})</span>
                    </label>
                  ))}
                </div>
              </div>

              <div className="flex gap-2 pt-3">
                <button
                  type="button"
                  onClick={() => setShowAddClassModal(false)}
                  className="flex-1 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold rounded-xl"
                >
                  انصراف
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white font-bold rounded-xl shadow-xs"
                >
                  ثبت کلاس برای مدرس
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
