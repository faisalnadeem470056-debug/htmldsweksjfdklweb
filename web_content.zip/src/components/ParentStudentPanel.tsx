import React, { useState } from 'react';
import { Student, SessionItem, ExamResult, PaymentItem } from '../types';
import { toPersianDigits, formatToman, formatPersianPercentage } from '../utils/jalali';
import { ReportCardModal } from './ReportCardModal';
import { 
  Calendar, 
  CreditCard, 
  FileText, 
  Trophy, 
  CheckCircle, 
  Clock, 
  Sparkles, 
  TrendingUp, 
  Award,
  AlertTriangle,
  Download,
  Printer
} from 'lucide-react';

interface ParentStudentPanelProps {
  currentStudent: Student;
  sessions: SessionItem[];
  payments: PaymentItem[];
  results: ExamResult[];
  onSelectStudent?: (studentId: string) => void;
  availableStudents: Student[];
}

export const ParentStudentPanel: React.FC<ParentStudentPanelProps> = ({
  currentStudent,
  sessions,
  payments,
  results,
  onSelectStudent,
  availableStudents
}) => {
  const [activeTab, setActiveTab] = useState<'attendance' | 'payment' | 'exams' | 'ranking'>('attendance');
  const [selectedResult, setSelectedResult] = useState<ExamResult | null>(null);

  // Filter student sessions
  const studentSessions = sessions.filter(s => s.classId === currentStudent.classId || s.className.includes(currentStudent.grade === 6 ? 'ششم' : 'نهم'));
  
  // Group by teacher: Abbasi (Computational & Creativity) vs Marhamati (Verbal & Logical)
  const abbasiSessions = studentSessions.filter(s => s.teacherId === 'teacher-abbasi');
  const marhamatiSessions = studentSessions.filter(s => s.teacherId === 'teacher-marhamati');

  // Filter student payments
  const studentPayments = payments.filter(p => p.studentId === currentStudent.studentId);

  // Filter student exam results
  const studentResults = results.filter(r => r.studentId === currentStudent.studentId);
  const latestResult = studentResults[0] || null;

  // Payment status calculation according to exact rules:
  // Less than 5 sessions: yellow progress bar, "جلسات فعال"
  // At session 5 (5-7): orange warning bar, "زمان پرداخت دوره جدید نزدیک است"
  // At session 8+: red warning bar, "لطفاً شهریه دوره جدید پرداخت شود"
  const sessionCount = currentStudent.activeCycleSessions;
  
  let paymentStatusType: 'yellow' | 'orange' | 'red' = 'yellow';
  let paymentStatusText = 'جلسات فعال';
  let barColor = 'bg-amber-500';
  let barTextColor = 'text-amber-800';

  if (sessionCount >= 8) {
    paymentStatusType = 'red';
    paymentStatusText = 'لطفاً شهریه دوره جدید پرداخت شود';
    barColor = 'bg-rose-500';
    barTextColor = 'text-rose-700';
  } else if (sessionCount >= 5) {
    paymentStatusType = 'orange';
    paymentStatusText = 'زمان پرداخت دوره جدید نزدیک است';
    barColor = 'bg-orange-500';
    barTextColor = 'text-orange-700';
  }

  const progressPercent = Math.min(100, (sessionCount / 8) * 100);

  return (
    <div className="space-y-5">
      
      {/* Student Profile Card & Switcher */}
      <div className="bg-white border border-slate-200 rounded-2xl p-4 sm:p-5 shadow-xs">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3.5">
            <img
              src={currentStudent.photo}
              alt={currentStudent.fullName}
              className="w-14 h-14 rounded-2xl object-cover border-2 border-indigo-500 shadow-xs"
            />
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-lg font-bold text-slate-900">
                  {currentStudent.fullName}
                </h2>
                <span className="px-2.5 py-0.5 rounded-full text-xs font-semibold bg-indigo-50 text-indigo-700 border border-indigo-200">
                  {currentStudent.grade === 6 ? 'پایه ششم تیزهوشان' : currentStudent.grade === 9 ? 'پایه نهم تیزهوشان' : currentStudent.grade === 5 ? 'پایه پنجم (آمادگی تیزهوشان)' : currentStudent.grade === 4 ? 'پایه چهارم ابتدایی' : 'پایه سوم ابتدایی'}
                </span>
              </div>
              <p className="text-xs text-slate-500 mt-0.5">
                شماره تماس اولیا: {toPersianDigits(currentStudent.parentPhone)} • کد ملی: {toPersianDigits(currentStudent.nationalCode)}
              </p>
            </div>
          </div>

          {/* Switch active student if parent has multiple */}
          {availableStudents.length > 1 && onSelectStudent && (
            <div className="flex items-center gap-2 self-stretch sm:self-auto bg-slate-50 p-1.5 rounded-xl border border-slate-200">
              <span className="text-xs text-slate-500 pr-1">تغییر فرزند:</span>
              <select
                value={currentStudent.studentId}
                onChange={(e) => onSelectStudent(e.target.value)}
                className="bg-white text-xs text-slate-800 rounded-lg px-2.5 py-1.5 border border-slate-300 focus:outline-none focus:border-indigo-500 font-medium"
              >
                {availableStudents.map(s => (
                  <option key={s.studentId} value={s.studentId}>
                    {s.fullName} ({s.grade === 6 ? 'ششم' : s.grade === 9 ? 'نهم' : s.grade === 5 ? 'پنجم' : s.grade === 4 ? 'چهارم' : 'سوم'})
                  </option>
                ))}
              </select>
            </div>
          )}
        </div>

        {/* Quick KPI Strip */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 mt-4 pt-4 border-t border-slate-100">
          <div className="bg-slate-50 p-3 rounded-xl border border-slate-200 text-center">
            <span className="text-[11px] text-slate-500">جلسات استاد عباسی (محاسباتی)</span>
            <div className="text-base font-bold text-blue-700 mt-0.5">
              {toPersianDigits(abbasiSessions.length)} جلسه
            </div>
          </div>

          <div className="bg-slate-50 p-3 rounded-xl border border-slate-200 text-center">
            <span className="text-[11px] text-slate-500">جلسات استاد مرحمتی (کلامی)</span>
            <div className="text-base font-bold text-teal-700 mt-0.5">
              {toPersianDigits(marhamatiSessions.length)} جلسه
            </div>
          </div>

          <div className="bg-slate-50 p-3 rounded-xl border border-slate-200 text-center">
            <span className="text-[11px] text-slate-500">وضعیت دوره شهریه</span>
            <div className={`text-xs font-bold mt-1 ${barTextColor}`}>
              {toPersianDigits(sessionCount)} از ۸ جلسه
            </div>
          </div>

          <div className="bg-slate-50 p-3 rounded-xl border border-slate-200 text-center">
            <span className="text-[11px] text-slate-500">آخرین رتبه سمپاد</span>
            <div className="text-base font-black text-amber-600 mt-0.5">
              {latestResult ? `رتبه ${toPersianDigits(latestResult.rank)}` : 'در انتظار آزمون'}
            </div>
          </div>
        </div>
      </div>

      {/* Navigation Tabs */}
      <div className="flex rounded-xl bg-slate-100 p-1 border border-slate-200 overflow-x-auto gap-1">
        <button
          onClick={() => setActiveTab('attendance')}
          className={`flex-1 min-w-[110px] flex items-center justify-center gap-1.5 py-2 px-3 rounded-lg text-xs font-bold transition-all ${
            activeTab === 'attendance'
              ? 'bg-white text-indigo-700 shadow-xs'
              : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          <Calendar className="w-3.5 h-3.5" />
          <span>حضور و جلسات</span>
        </button>

        <button
          onClick={() => setActiveTab('payment')}
          className={`flex-1 min-w-[110px] flex items-center justify-center gap-1.5 py-2 px-3 rounded-lg text-xs font-bold transition-all ${
            activeTab === 'payment'
              ? 'bg-white text-indigo-700 shadow-xs'
              : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          <CreditCard className="w-3.5 h-3.5" />
          <span>وضعیت شهریه</span>
          {paymentStatusType === 'red' && (
            <span className="w-2 h-2 rounded-full bg-rose-500 animate-ping"></span>
          )}
        </button>

        <button
          onClick={() => setActiveTab('exams')}
          className={`flex-1 min-w-[110px] flex items-center justify-center gap-1.5 py-2 px-3 rounded-lg text-xs font-bold transition-all ${
            activeTab === 'exams'
              ? 'bg-white text-indigo-700 shadow-xs'
              : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          <FileText className="w-3.5 h-3.5" />
          <span>کارنامه هوشمند</span>
        </button>

        <button
          onClick={() => setActiveTab('ranking')}
          className={`flex-1 min-w-[110px] flex items-center justify-center gap-1.5 py-2 px-3 rounded-lg text-xs font-bold transition-all ${
            activeTab === 'ranking'
              ? 'bg-white text-indigo-700 shadow-xs'
              : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          <Trophy className="w-3.5 h-3.5" />
          <span>رتبه‌بندی سمپاد</span>
        </button>
      </div>

      {/* TAB 1: ATTENDANCE & SESSIONS */}
      {activeTab === 'attendance' && (
        <div className="space-y-4">
          <div className="bg-white border border-slate-200 rounded-2xl p-5 space-y-5 shadow-xs">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div>
                <h3 className="font-bold text-slate-900 text-base">
                  گزارش جلسات تشکیل شده دانش‌آموز {currentStudent.fullName}
                </h3>
                <p className="text-xs text-slate-500 mt-0.5">
                  تفکیک جلسات استاد عباسی (هوش محاسباتی و خلاقیت) و استاد مرحمتی (هوش کلامی و منطقی)
                </p>
              </div>
              <div className="px-3 py-1 bg-slate-100 rounded-lg text-xs font-mono text-slate-700 border border-slate-200">
                مجموع: {toPersianDigits(studentSessions.length)} جلسه
              </div>
            </div>

            {/* Abbasi Sessions Group */}
            <div className="bg-blue-50/40 rounded-xl p-4 border border-blue-200 space-y-3">
              <div className="flex items-center justify-between border-b border-blue-200 pb-2.5">
                <div className="flex items-center gap-2">
                  <div className="w-2.5 h-2.5 rounded-full bg-blue-600"></div>
                  <h4 className="font-bold text-sm text-blue-900">
                    کلاس‌های استاد عباسی (هوش محاسباتی و خلاقیت)
                  </h4>
                </div>
                <span className="text-xs font-bold text-blue-700 bg-blue-100 px-2 py-0.5 rounded border border-blue-200">
                  {toPersianDigits(abbasiSessions.length)} جلسه ثبت شده
                </span>
              </div>

              {abbasiSessions.length === 0 ? (
                <p className="text-xs text-slate-500 py-2">هنوز جلسه‌ای برای این استاد ثبت نشده است.</p>
              ) : (
                <div className="space-y-2">
                  {abbasiSessions.map((ses) => (
                    <div
                      key={ses.sessionId}
                      className="flex items-center justify-between bg-white p-3 rounded-lg border border-slate-200 hover:border-blue-300 transition-colors text-xs"
                    >
                      <div className="flex items-center gap-3">
                        <span className="w-7 h-7 rounded-lg bg-blue-100 text-blue-800 flex items-center justify-center font-bold font-mono">
                          {toPersianDigits(ses.sessionNumber)}
                        </span>
                        <div>
                          <div className="font-semibold text-slate-900">
                            جلسه {toPersianDigits(ses.sessionNumber)}
                          </div>
                          {ses.topic && (
                            <div className="text-[11px] text-slate-500 mt-0.5">{ses.topic}</div>
                          )}
                        </div>
                      </div>

                      <div className="flex items-center gap-3 text-slate-600">
                        <div className="flex items-center gap-1 font-mono text-amber-700">
                          <Calendar className="w-3.5 h-3.5" />
                          <span>{toPersianDigits(ses.PersianDate)}</span>
                        </div>
                        <div className="flex items-center gap-1 font-mono text-slate-500">
                          <Clock className="w-3.5 h-3.5" />
                          <span>{toPersianDigits(ses.time)}</span>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Marhamati Sessions Group */}
            <div className="bg-teal-50/40 rounded-xl p-4 border border-teal-200 space-y-3">
              <div className="flex items-center justify-between border-b border-teal-200 pb-2.5">
                <div className="flex items-center gap-2">
                  <div className="w-2.5 h-2.5 rounded-full bg-teal-600"></div>
                  <h4 className="font-bold text-sm text-teal-900">
                    کلاس‌های استاد مرحمتی (هوش کلامی و منطقی)
                  </h4>
                </div>
                <span className="text-xs font-bold text-teal-700 bg-teal-100 px-2 py-0.5 rounded border border-teal-200">
                  {toPersianDigits(marhamatiSessions.length)} جلسه ثبت شده
                </span>
              </div>

              {marhamatiSessions.length === 0 ? (
                <p className="text-xs text-slate-500 py-2">هنوز جلسه‌ای برای این استاد ثبت نشده است.</p>
              ) : (
                <div className="space-y-2">
                  {marhamatiSessions.map((ses) => (
                    <div
                      key={ses.sessionId}
                      className="flex items-center justify-between bg-white p-3 rounded-lg border border-slate-200 hover:border-teal-300 transition-colors text-xs"
                    >
                      <div className="flex items-center gap-3">
                        <span className="w-7 h-7 rounded-lg bg-teal-100 text-teal-800 flex items-center justify-center font-bold font-mono">
                          {toPersianDigits(ses.sessionNumber)}
                        </span>
                        <div>
                          <div className="font-semibold text-slate-900">
                            جلسه {toPersianDigits(ses.sessionNumber)}
                          </div>
                          {ses.topic && (
                            <div className="text-[11px] text-slate-500 mt-0.5">{ses.topic}</div>
                          )}
                        </div>
                      </div>

                      <div className="flex items-center gap-3 text-slate-600">
                        <div className="flex items-center gap-1 font-mono text-amber-700">
                          <Calendar className="w-3.5 h-3.5" />
                          <span>{toPersianDigits(ses.PersianDate)}</span>
                        </div>
                        <div className="flex items-center gap-1 font-mono text-slate-500">
                          <Clock className="w-3.5 h-3.5" />
                          <span>{toPersianDigits(ses.time)}</span>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: SMART PAYMENT SYSTEM */}
      {activeTab === 'payment' && (
        <div className="space-y-4">
          <div className="bg-white border border-slate-200 rounded-2xl p-5 sm:p-6 space-y-6 shadow-xs">
            
            {/* Header */}
            <div>
              <div className="flex items-center justify-between border-b border-slate-100 pb-3">
                <h3 className="font-bold text-slate-900 text-base flex items-center gap-2">
                  <CreditCard className="w-5 h-5 text-indigo-600" />
                  <span>سامانه مدیریت چرخه شهریه تیزهوشان</span>
                </h3>
                <span className="text-xs font-semibold text-slate-700 bg-slate-100 px-3 py-1 rounded-lg border border-slate-200">
                  دوره شماره {toPersianDigits(currentStudent.currentCycleNumber)}
                </span>
              </div>
              <p className="text-xs text-slate-500 mt-2">
                هر دوره آموزشی شامل ۸ جلسه تدریس تخصصی اساتید می‌باشد.
              </p>
            </div>

            {/* Dynamic Status Progress Bar according to rules */}
            <div className={`p-4 rounded-2xl border ${
              paymentStatusType === 'red' ? 'bg-rose-50 border-rose-200' :
              paymentStatusType === 'orange' ? 'bg-orange-50 border-orange-200' :
              'bg-amber-50 border-amber-200'
            } space-y-3`}>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  {paymentStatusType === 'red' ? (
                    <AlertTriangle className="w-5 h-5 text-rose-600 animate-bounce" />
                  ) : paymentStatusType === 'orange' ? (
                    <Clock className="w-5 h-5 text-orange-600" />
                  ) : (
                    <CheckCircle className="w-5 h-5 text-amber-600" />
                  )}
                  <span className={`font-bold text-sm ${barTextColor}`}>
                    {paymentStatusText}
                  </span>
                </div>
                <div className="text-xs font-mono font-bold text-slate-800">
                  {toPersianDigits(sessionCount)} از ۸ جلسه گذرانده شده
                </div>
              </div>

              {/* Progress Bar Track */}
              <div className="w-full bg-white rounded-full h-3 overflow-hidden p-0.5 border border-slate-200">
                <div
                  className={`h-full rounded-full transition-all duration-500 ${barColor}`}
                  style={{ width: `${progressPercent}%` }}
                ></div>
              </div>

              {/* Status explanation */}
              <div className="text-xs">
                {paymentStatusType === 'red' && (
                  <p className="text-rose-800 leading-relaxed font-semibold">
                    توجه: تعداد ۸ جلسه این دوره تکمیل شده است. لطفاً جهت استمرار حضور در کلاس‌های تیزهوشان، شهریه دوره جدید را واریز و فیش را به آموزشگاه ارسال فرمایید.
                  </p>
                )}
                {paymentStatusType === 'orange' && (
                  <p className="text-orange-800 leading-relaxed font-medium">
                    یادآوری: دانش‌آموز ۵ جلسه از ۸ جلسه دوره جاری را سپری نموده است. مهلت واریز شهریه دوره بعدی به زودی فرا می‌رسد.
                  </p>
                )}
                {paymentStatusType === 'yellow' && (
                  <p className="text-amber-800 leading-relaxed font-medium">
                    جلسات دوره فعال است. نیازی به پرداخت در این مرحله نیست.
                  </p>
                )}
              </div>
            </div>

            {/* Tuition Details & Account Info */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
              <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 space-y-1.5">
                <div className="text-slate-500">مبلغ شهریه دوره ۸ جلسه‌ای:</div>
                <div className="font-bold text-base text-emerald-700 font-mono">
                  {formatToman(2800000)}
                </div>
                <div className="text-[11px] text-slate-500">شامل جلسات استاد عباسی + استاد مرحمتی + آزمون‌های شبیه‌ساز سمپاد</div>
              </div>

              <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 space-y-1.5">
                <div className="text-slate-500">شماره کارت موسسه جهت واریز:</div>
                <div className="font-mono text-sm text-slate-900 font-bold tracking-wider">
                  ۶۰۳۷-۹۹۷۵-۸۸۲۲-۴۴۱۰
                </div>
                <div className="text-[11px] text-slate-500">بانک ملی • به نام آموزشگاه تیزهوشان آی‌مکس</div>
              </div>
            </div>

            {/* Past Payment History */}
            <div className="space-y-2.5 pt-2">
              <h4 className="text-xs font-bold text-slate-800">تاریخچه پرداخت‌های تایید شده این دانش‌آموز:</h4>
              {studentPayments.length === 0 ? (
                <p className="text-xs text-slate-500 bg-slate-50 p-3 rounded-xl border border-slate-200">سابقه‌ای ثبت نشده است.</p>
              ) : (
                <div className="space-y-2">
                  {studentPayments.map((p) => (
                    <div
                      key={p.paymentId}
                      className="flex items-center justify-between bg-slate-50 p-3.5 rounded-xl border border-slate-200 text-xs"
                    >
                      <div className="flex items-center gap-2">
                        <CheckCircle className="w-4 h-4 text-emerald-600" />
                        <div>
                          <div className="font-semibold text-slate-900">
                            تسویه شهریه دوره {toPersianDigits(p.cycleNumber)}
                          </div>
                          <div className="text-[11px] text-slate-500">تایید شده توسط {p.confirmedBy || 'مدیریت'}</div>
                        </div>
                      </div>
                      <div className="text-left">
                        <div className="font-bold text-emerald-700 font-mono">{formatToman(p.amount)}</div>
                        <div className="text-[11px] text-slate-500 font-mono">{toPersianDigits(p.PersianDate)}</div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>

          </div>
        </div>
      )}

      {/* TAB 3: SMART EXAM REPORT CARDS */}
      {activeTab === 'exams' && (
        <div className="space-y-4">
          <div className="bg-white border border-slate-200 rounded-2xl p-5 sm:p-6 space-y-4 shadow-xs">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between border-b border-slate-100 pb-3 gap-2">
              <div>
                <h3 className="font-bold text-slate-900 text-base flex items-center gap-2">
                  <Award className="w-5 h-5 text-amber-500" />
                  <span>کارنامه‌های هوشمند آزمون‌های شبیه‌ساز سمپاد</span>
                </h3>
                <p className="text-xs text-slate-500 mt-1">
                  مشاهده ریز نمرات {currentStudent.grade === 6 ? 'دفترچه ۱ (تحلیلی) و دفترچه ۲' : 'دفترچه تحصیلی و تحلیلی'}، تحلیل هوش مصنوعی و امکان صدور کارنامه رسمی
                </p>
              </div>
              <span className="inline-flex items-center gap-1.5 px-3 py-1 bg-emerald-50 text-emerald-800 border border-emerald-200 rounded-xl text-xs font-bold self-start sm:self-auto">
                <Download className="w-3.5 h-3.5 text-emerald-600" />
                قابلیت دانلود مستقیم PDF رسمی
              </span>
            </div>

            {studentResults.length === 0 ? (
              <div className="text-center py-8 bg-slate-50 rounded-xl border border-dashed border-slate-200 text-slate-500 text-xs">
                هنوز کارنامه‌ای برای این دانش‌آموز ثبت نشده است.
              </div>
            ) : (
              <div className="space-y-3">
                {studentResults.map((res) => (
                  <div
                    key={res.resultId}
                    className="bg-slate-50 border border-slate-200 hover:border-indigo-300 rounded-2xl p-4 sm:p-5 transition-all shadow-xs space-y-4"
                  >
                    {/* Header line */}
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-200 pb-3">
                      <div>
                        <div className="flex items-center gap-2">
                          <h4 className="font-bold text-sm sm:text-base text-slate-900">
                            {res.examTitle}
                          </h4>
                          <span className="text-[11px] bg-amber-100 text-amber-800 border border-amber-200 px-2.5 py-0.5 rounded-full font-bold">
                            رتبه {toPersianDigits(res.rank)} در پایه
                          </span>
                        </div>
                        <p className="text-xs text-slate-500 mt-0.5">
                          تاریخ برگزاری: {toPersianDigits(res.PersianDate)} • تعداد شرکت‌کنندگان: {toPersianDigits(res.totalParticipants)} نفر
                        </p>
                      </div>

                      <div className="flex items-center gap-2 self-start sm:self-auto">
                        <button
                          onClick={() => setSelectedResult(res)}
                          className="flex items-center gap-1.5 px-3.5 py-2 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 text-white rounded-xl text-xs font-bold shadow-xs transition-all cursor-pointer"
                          title="مشاهده کارنامه رسمی و دانلود مستقیم فایل PDF"
                        >
                          <Download className="w-4 h-4" />
                          <span>دریافت PDF رسمی</span>
                        </button>
                        <button
                          onClick={() => setSelectedResult(res)}
                          className="flex items-center gap-1.5 px-3.5 py-2 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 border border-indigo-200 rounded-xl text-xs font-bold transition-all cursor-pointer"
                        >
                          <FileText className="w-4 h-4 text-indigo-600" />
                          <span>مشاهده کارنامه</span>
                        </button>
                      </div>
                    </div>

                    {/* Quick Metrics Grid */}
                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 text-center text-xs">
                      <div className="bg-white p-3 rounded-xl border border-slate-200">
                        <span className="text-slate-500 text-[11px]">درصد کل تراز</span>
                        <div className="font-bold text-base text-indigo-700 font-mono mt-0.5">
                          {formatPersianPercentage(res.totalPercentage)}
                        </div>
                      </div>

                      <div className="bg-white p-3 rounded-xl border border-slate-200">
                        <span className="text-slate-500 text-[11px]">تراز استاندارد سمپاد</span>
                        <div className="font-black text-base text-indigo-900 font-mono mt-0.5">
                          {toPersianDigits(res.tScore)}
                        </div>
                      </div>

                      <div className="bg-white p-3 rounded-xl border border-slate-200">
                        <span className="text-slate-500 text-[11px]">نمره کل خام</span>
                        <div className="font-bold text-base text-slate-800 font-mono mt-0.5">
                          {toPersianDigits(res.totalScore)}
                        </div>
                      </div>

                      <div className="bg-white p-3 rounded-xl border border-slate-200">
                        <span className="text-slate-500 text-[11px]">درصد برتری (چارک)</span>
                        <div className="font-bold text-base text-emerald-700 font-mono mt-0.5">
                          {toPersianDigits(res.percentile)}%
                        </div>
                      </div>
                    </div>

                    {/* AI Preview Snippet */}
                    <div className="bg-white border border-indigo-100 rounded-xl p-3 text-xs space-y-1">
                      <div className="flex items-center gap-1.5 font-bold text-indigo-800">
                        <Sparkles className="w-3.5 h-3.5 text-amber-500" />
                        <span>تحلیل هوش مصنوعی:</span>
                        <span className="text-slate-700 font-normal mr-1">{res.analysis.comparisonToPrevious}</span>
                      </div>
                      <p className="text-slate-600 line-clamp-2 leading-relaxed">
                        {res.analysis.summary}
                      </p>
                    </div>

                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}

      {/* TAB 4: PROGRESS CHARTS & RANKING */}
      {activeTab === 'ranking' && (
        <div className="space-y-4">
          <div className="bg-white border border-slate-200 rounded-2xl p-5 sm:p-6 space-y-6 shadow-xs">
            
            {/* Own Student Rank Banner */}
            <div className="bg-indigo-50/50 border border-indigo-200 rounded-2xl p-5 text-center space-y-2">
              <span className="px-3 py-1 bg-amber-100 text-amber-800 text-xs font-bold rounded-full border border-amber-200 inline-flex items-center gap-1">
                <Trophy className="w-3.5 h-3.5 text-amber-600" />
                جایگاه انحصاری در آزمون اخیر سمپاد
              </span>
              <h3 className="text-xl sm:text-2xl font-black text-slate-900">
                رتبه {toPersianDigits(latestResult?.rank || 2)} در پایه {currentStudent.grade === 6 ? 'ششم' : 'نهم'} تیزهوشان
              </h3>
              <p className="text-xs text-slate-600 max-w-md mx-auto">
                بر اساس استاندارد محرمانگی آموزشگاه تیزهوشان آی‌مکس، اولیا گرامی صرفاً رتبه و کارنامه تحلیلی فرزند خود را مشاهده می‌نمایند.
              </p>
            </div>

            {/* Progress Across Exams */}
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <h4 className="text-sm font-bold text-slate-900 flex items-center gap-2">
                  <TrendingUp className="w-4 h-4 text-emerald-600" />
                  <span>نمودار رشد و مقایسه مراحل آزمون‌ها</span>
                </h4>
                <span className="text-xs text-emerald-700 font-bold bg-emerald-50 border border-emerald-200 px-2 py-0.5 rounded">
                  روند صعودی +۱۵٪
                </span>
              </div>

              {/* Progress Visualization Cards */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                {studentResults.map((r, idx) => (
                  <div
                    key={r.resultId}
                    className="bg-slate-50 p-4 rounded-xl border border-slate-200 hover:border-slate-300 transition-colors space-y-3"
                  >
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-bold text-indigo-700">
                        مرحله {toPersianDigits(studentResults.length - idx)}
                      </span>
                      <span className="text-[11px] font-mono text-slate-500">
                        {toPersianDigits(r.PersianDate)}
                      </span>
                    </div>

                    <div className="space-y-1.5">
                      <div className="flex justify-between text-xs">
                        <span className="text-slate-600">درصد کسب شده:</span>
                        <span className="font-bold text-indigo-700 font-mono">
                          {formatPersianPercentage(r.totalPercentage)}
                        </span>
                      </div>
                      <div className="w-full bg-slate-200 rounded-full h-2 overflow-hidden">
                        <div
                          className="bg-indigo-600 h-full rounded-full"
                          style={{ width: `${r.totalPercentage}%` }}
                        ></div>
                      </div>
                    </div>

                    <div className="flex justify-between text-xs pt-2 border-t border-slate-200">
                      <div>
                        <span className="text-slate-500 text-[11px]">تراز سمپاد:</span>
                        <div className="font-bold text-slate-900 font-mono">{toPersianDigits(r.tScore)}</div>
                      </div>
                      <div className="text-left">
                        <span className="text-slate-500 text-[11px]">رتبه مرحله:</span>
                        <div className="font-bold text-emerald-700 font-mono">رتبه {toPersianDigits(r.rank)}</div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

          </div>
        </div>
      )}

      {/* Detailed Official Report Card Modal */}
      {selectedResult && (
        <ReportCardModal
          result={selectedResult}
          student={currentStudent}
          onClose={() => setSelectedResult(null)}
        />
      )}

    </div>
  );
};
