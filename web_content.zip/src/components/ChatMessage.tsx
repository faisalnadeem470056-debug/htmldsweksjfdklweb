import React from 'react';
import ReactMarkdown from 'react-markdown';
import { Prism as SyntaxHighlighter } from 'react-syntax-highlighter';
import { oneDark } from 'react-syntax-highlighter/dist/esm/styles/prism';
import remarkGfm from 'remark-gfm';
import { cn } from '../utils/cn';
import { Bot, User, Copy, Check, Download, Volume2, Square } from 'lucide-react';

interface ChatMessageProps {
  role: 'user' | 'model';
  content: string;
  images?: string[];
  isThinking?: boolean;
}

export function ChatMessage({ role, content, images, isThinking }: ChatMessageProps) {
  const [copied, setCopied] = React.useState(false);
  const [isPlaying, setIsPlaying] = React.useState(false);

  const handleCopy = () => {
    navigator.clipboard.writeText(content);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleSpeak = () => {
    if (isPlaying) {
      window.speechSynthesis.cancel();
      setIsPlaying(false);
      return;
    }

    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel(); // stop any current speech
      const utterance = new SpeechSynthesisUtterance(content);
      utterance.lang = 'hi-IN'; // Default to Indian accent if available
      utterance.onend = () => setIsPlaying(false);
      utterance.onerror = () => setIsPlaying(false);
      setIsPlaying(true);
      window.speechSynthesis.speak(utterance);
    }
  };

  const handleDownload = (imageUrl: string) => {
    const link = document.createElement('a');
    link.href = imageUrl;
    link.download = `india-ai-generated-${Date.now()}.png`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // cleanup speech on unmount
  React.useEffect(() => {
    return () => {
      if (isPlaying) window.speechSynthesis.cancel();
    };
  }, [isPlaying]);

  return (
    <div className={cn(
      "flex w-full p-4 gap-4 max-w-4xl mx-auto",
      role === 'user' ? "bg-transparent" : "bg-slate-50/50 dark:bg-slate-900/50 rounded-xl"
    )}>
      <div className={cn(
        "flex-shrink-0 w-8 h-8 rounded-full flex items-center justify-center",
        role === 'user' ? "bg-indigo-600 text-white" : "bg-orange-500 text-white" // India GPT uses Orange (Saffron)
      )}>
        {role === 'user' ? <User size={18} /> : <Bot size={18} />}
      </div>
      
      <div className="flex-1 overflow-hidden">
        <div className="flex items-center justify-between mb-1">
          <span className="font-semibold text-sm text-slate-700 dark:text-slate-300">
            {role === 'user' ? 'You' : 'India GPT'}
          </span>
          {role === 'model' && (
            <div className="flex items-center gap-1">
              <button 
                onClick={handleSpeak}
                className={cn(
                  "p-1 rounded transition-colors",
                  isPlaying ? "text-orange-500 bg-orange-100 dark:bg-orange-900/30" : "text-slate-500 hover:bg-slate-200 dark:hover:bg-slate-800"
                )}
                title={isPlaying ? "Stop speaking" : "Read aloud"}
              >
                {isPlaying ? <Square size={14} /> : <Volume2 size={14} />}
              </button>
              <button 
                onClick={handleCopy}
                className="p-1 hover:bg-slate-200 dark:hover:bg-slate-800 rounded text-slate-500 transition-colors"
                title="Copy response"
              >
                {copied ? <Check size={14} /> : <Copy size={14} />}
              </button>
            </div>
          )}
        </div>
        {isThinking ? (
          <div className="flex items-center gap-2 text-slate-500 animate-pulse">
            <div className="w-2 h-2 bg-slate-400 rounded-full animate-bounce" style={{ animationDelay: '0ms' }} />
            <div className="w-2 h-2 bg-slate-400 rounded-full animate-bounce" style={{ animationDelay: '150ms' }} />
            <div className="w-2 h-2 bg-slate-400 rounded-full animate-bounce" style={{ animationDelay: '300ms' }} />
          </div>
        ) : (
          <div className="prose prose-slate dark:prose-invert max-w-none text-sm sm:text-base leading-relaxed">
            {images && images.length > 0 && (
              <div className={cn(
                "mb-4 grid gap-2",
                images.length === 1 ? "grid-cols-1" : "grid-cols-2"
              )}>
                {images.map((img, idx) => (
                  <div key={idx} className="relative group inline-block">
                    <img 
                      src={img} 
                      alt={`Content ${idx}`} 
                      className="rounded-lg shadow-md w-full h-auto border border-slate-200 dark:border-slate-700 cursor-pointer transition-transform hover:scale-[1.01]"
                      onClick={() => handleDownload(img)}
                    />
                    <button
                      onClick={() => handleDownload(img)}
                      className="absolute top-2 right-2 p-2 bg-black/50 hover:bg-black/70 text-white rounded-full opacity-0 group-hover:opacity-100 transition-opacity backdrop-blur-sm"
                      title="Download Image"
                    >
                      <Download size={20} />
                    </button>
                  </div>
                ))}
              </div>
            )}
            <ReactMarkdown
              remarkPlugins={[remarkGfm]}
              components={{
                code({node, inline, className, children, ...props}: any) {
                  const match = /language-(\w+)/.exec(className || '')
                  return !inline && match ? (
                    <SyntaxHighlighter
                      {...props}
                      style={oneDark}
                      language={match[1]}
                      PreTag="div"
                      className="rounded-lg !mt-2 !mb-2 text-sm"
                    >
                      {String(children).replace(/\n$/, '')}
                    </SyntaxHighlighter>
                  ) : (
                    <code {...props} className={cn(className, "bg-slate-100 dark:bg-slate-800 px-1 py-0.5 rounded text-pink-600 dark:text-pink-400 font-mono text-sm")}>
                      {children}
                    </code>
                  )
                }
              }}
            >
              {content}
            </ReactMarkdown>
          </div>
        )}
      </div>
    </div>
  );
}
