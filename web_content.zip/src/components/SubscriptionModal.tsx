import React, { useState, useEffect } from 'react';
import { X, Check, CreditCard, Sparkles, Zap, ShieldCheck, Loader2 } from 'lucide-react';
import { getUserId } from '../utils/auth';

interface SubscriptionModalProps {
  isOpen: boolean;
  onClose: () => void;
}

interface PlanInfo {
  plan: string;
  status: string;
  messageCount: number;
  maxMessages: number;
}

export function SubscriptionModal({ isOpen, onClose }: SubscriptionModalProps) {
  const [loading, setLoading] = useState(false);
  const [currentPlan, setCurrentPlan] = useState<PlanInfo | null>(null);

  useEffect(() => {
    if (isOpen) {
      fetchUserPlan();
    }
  }, [isOpen]);

  const fetchUserPlan = async () => {
    try {
      const res = await fetch('/api/user', {
        headers: {
          'x-user-id': getUserId()
        }
      });
      if (res.ok) {
        const data = await res.json();
        setCurrentPlan(data);
      }
    } catch (e) {
      console.error(e);
    }
  };

  const handleSubscribe = async (planName: string) => {
    try {
      setLoading(true);
      const res = await fetch('/api/create-checkout-session', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-user-id': getUserId()
        },
        body: JSON.stringify({ plan: planName })
      });
      
      const data = await res.json();
      if (data.url) {
        window.location.href = data.url;
      } else {
        alert("Failed to start checkout: " + (data.error || "Unknown error"));
        setLoading(false);
      }
    } catch (error) {
      console.error(error);
      alert("Payment gateway error. Please try again.");
      setLoading(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-[300] flex items-center justify-center bg-slate-950/80 backdrop-blur-md p-4 animate-fade-in overflow-y-auto">
      <div className="w-full max-w-4xl bg-white dark:bg-slate-900 rounded-3xl shadow-2xl overflow-hidden flex flex-col my-8">
        
        <div className="px-6 py-4 border-b border-slate-200 dark:border-slate-800 flex justify-between items-center bg-slate-50 dark:bg-slate-950 sticky top-0 z-10">
          <div>
            <h2 className="text-2xl font-black text-slate-900 dark:text-white flex items-center gap-2">
              <Sparkles className="text-orange-500" />
              Upgrade to Pro
            </h2>
            <p className="text-sm text-slate-500 mt-1">
              Current Plan: <span className="font-bold text-orange-600 uppercase">{currentPlan?.plan || 'FREE'}</span> 
              {' '}({currentPlan?.messageCount || 0}/{currentPlan?.maxMessages || 10} msgs today)
            </p>
          </div>
          <button 
            onClick={onClose}
            className="p-2 hover:bg-slate-200 dark:hover:bg-slate-800 rounded-full transition-colors"
          >
            <X className="text-slate-500" />
          </button>
        </div>

        <div className="p-6 md:p-8 grid grid-cols-1 md:grid-cols-3 gap-6">
          
          {/* FREE PLAN */}
          <div className="border border-slate-200 dark:border-slate-800 rounded-2xl p-6 bg-slate-50 dark:bg-slate-900/50 flex flex-col">
            <h3 className="text-lg font-bold text-slate-900 dark:text-white mb-2">Free Plan</h3>
            <div className="text-3xl font-black text-slate-900 dark:text-white mb-6">₹0 <span className="text-sm font-normal text-slate-500">/month</span></div>
            <ul className="space-y-3 mb-8 flex-1">
              <li className="flex gap-2 text-sm text-slate-600 dark:text-slate-300"><Check size={18} className="text-green-500 flex-shrink-0" /> 10 Messages per day</li>
              <li className="flex gap-2 text-sm text-slate-600 dark:text-slate-300"><Check size={18} className="text-green-500 flex-shrink-0" /> Basic AI Model</li>
              <li className="flex gap-2 text-sm text-slate-600 dark:text-slate-300 opacity-50"><X size={18} className="text-slate-400 flex-shrink-0" /> No Image Analysis</li>
              <li className="flex gap-2 text-sm text-slate-600 dark:text-slate-300 opacity-50"><X size={18} className="text-slate-400 flex-shrink-0" /> No Advanced Reasoning</li>
            </ul>
            <button disabled className="w-full py-3 rounded-xl bg-slate-200 dark:bg-slate-800 text-slate-500 font-bold">
              {currentPlan?.plan === 'FREE' ? 'Current Plan' : 'Free'}
            </button>
          </div>

          {/* PRO PLAN */}
          <div className="border-2 border-orange-500 rounded-2xl p-6 bg-white dark:bg-slate-900 shadow-xl shadow-orange-500/10 flex flex-col relative transform md:-translate-y-4">
            <div className="absolute top-0 left-1/2 transform -translate-x-1/2 -translate-y-1/2 bg-gradient-to-r from-orange-500 to-red-500 text-white text-xs font-bold px-3 py-1 rounded-full uppercase tracking-wider">
              Most Popular
            </div>
            <h3 className="text-lg font-bold text-slate-900 dark:text-white mb-2 flex items-center gap-2">
              <Zap size={18} className="text-orange-500" /> Pro Plan
            </h3>
            <div className="text-3xl font-black text-slate-900 dark:text-white mb-6">₹499 <span className="text-sm font-normal text-slate-500">/month</span></div>
            <ul className="space-y-3 mb-8 flex-1">
              <li className="flex gap-2 text-sm text-slate-600 dark:text-slate-300"><Check size={18} className="text-orange-500 flex-shrink-0" /> 100 Messages per day</li>
              <li className="flex gap-2 text-sm text-slate-600 dark:text-slate-300"><Check size={18} className="text-orange-500 flex-shrink-0" /> Advanced Pro Model</li>
              <li className="flex gap-2 text-sm text-slate-600 dark:text-slate-300"><Check size={18} className="text-orange-500 flex-shrink-0" /> Image Understanding</li>
              <li className="flex gap-2 text-sm text-slate-600 dark:text-slate-300"><Check size={18} className="text-orange-500 flex-shrink-0" /> Priority Processing</li>
            </ul>
            <button 
              onClick={() => handleSubscribe('PRO')}
              disabled={loading || currentPlan?.plan === 'PRO' || currentPlan?.plan === 'PREMIUM'}
              className="w-full py-3 rounded-xl bg-gradient-to-r from-orange-500 to-red-500 text-white font-bold shadow-lg shadow-orange-500/25 hover:shadow-orange-500/40 transition-all disabled:opacity-50 disabled:grayscale"
            >
              {loading ? <Loader2 size={20} className="animate-spin mx-auto" /> : (currentPlan?.plan === 'PRO' ? 'Current Plan' : 'Upgrade to Pro')}
            </button>
          </div>

          {/* PREMIUM PLAN */}
          <div className="border border-slate-200 dark:border-slate-800 rounded-2xl p-6 bg-slate-50 dark:bg-slate-900/50 flex flex-col">
            <h3 className="text-lg font-bold text-slate-900 dark:text-white mb-2 flex items-center gap-2">
              <ShieldCheck size={18} className="text-blue-500" /> Premium
            </h3>
            <div className="text-3xl font-black text-slate-900 dark:text-white mb-6">₹1,999 <span className="text-sm font-normal text-slate-500">/month</span></div>
            <ul className="space-y-3 mb-8 flex-1">
              <li className="flex gap-2 text-sm text-slate-600 dark:text-slate-300"><Check size={18} className="text-blue-500 flex-shrink-0" /> 500 Messages per day</li>
              <li className="flex gap-2 text-sm text-slate-600 dark:text-slate-300"><Check size={18} className="text-blue-500 flex-shrink-0" /> Highest Tier AI Models</li>
              <li className="flex gap-2 text-sm text-slate-600 dark:text-slate-300"><Check size={18} className="text-blue-500 flex-shrink-0" /> Advanced Media Generation</li>
              <li className="flex gap-2 text-sm text-slate-600 dark:text-slate-300"><Check size={18} className="text-blue-500 flex-shrink-0" /> Zero Restrictions</li>
            </ul>
            <button 
              onClick={() => handleSubscribe('PREMIUM')}
              disabled={loading || currentPlan?.plan === 'PREMIUM'}
              className="w-full py-3 rounded-xl bg-slate-900 dark:bg-white text-white dark:text-slate-900 font-bold hover:bg-slate-800 dark:hover:bg-slate-100 transition-all disabled:opacity-50"
            >
              {loading ? <Loader2 size={20} className="animate-spin mx-auto" /> : (currentPlan?.plan === 'PREMIUM' ? 'Current Plan' : 'Get Premium')}
            </button>
          </div>

        </div>
        
        <div className="bg-slate-100 dark:bg-slate-950 px-6 py-4 text-center text-xs text-slate-500 flex justify-center items-center gap-4">
          <span className="flex items-center gap-1"><ShieldCheck size={14} /> Secure Checkout by Stripe</span>
          <span className="flex items-center gap-1"><CreditCard size={14} /> UPI, Cards & NetBanking</span>
        </div>
      </div>
    </div>
  );
}
