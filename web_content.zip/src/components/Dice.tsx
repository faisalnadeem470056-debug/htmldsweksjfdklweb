import React from 'react';
import { PlayerColor } from '../types/game';

interface DiceProps {
  value: number;
  isRolling: boolean;
  canRoll: boolean;
  activeColor: PlayerColor;
  onRoll: () => void;
  disabledReason?: string;
}

// 6 pip configurations
const PIP_CONFIGS: Record<number, { top: string; left: string }[]> = {
  1: [{ top: '50%', left: '50%' }],
  2: [
    { top: '25%', left: '25%' },
    { top: '75%', left: '75%' },
  ],
  3: [
    { top: '25%', left: '25%' },
    { top: '50%', left: '50%' },
    { top: '75%', left: '75%' },
  ],
  4: [
    { top: '25%', left: '25%' },
    { top: '25%', left: '75%' },
    { top: '75%', left: '25%' },
    { top: '75%', left: '75%' },
  ],
  5: [
    { top: '25%', left: '25%' },
    { top: '25%', left: '75%' },
    { top: '50%', left: '50%' },
    { top: '75%', left: '25%' },
    { top: '75%', left: '75%' },
  ],
  6: [
    { top: '22%', left: '25%' },
    { top: '50%', left: '25%' },
    { top: '78%', left: '25%' },
    { top: '22%', left: '75%' },
    { top: '50%', left: '75%' },
    { top: '78%', left: '75%' },
  ],
};

const COLOR_ACCENTS: Record<PlayerColor, { ring: string; glow: string; pip: string }> = {
  red: { ring: 'ring-red-500', glow: 'shadow-red-500/50', pip: 'bg-red-600' },
  green: { ring: 'ring-emerald-500', glow: 'shadow-emerald-500/50', pip: 'bg-emerald-600' },
  yellow: { ring: 'ring-amber-400', glow: 'shadow-amber-400/50', pip: 'bg-amber-600' },
  blue: { ring: 'ring-blue-500', glow: 'shadow-blue-500/50', pip: 'bg-blue-600' },
};

export const Dice: React.FC<DiceProps> = ({
  value,
  isRolling,
  canRoll,
  activeColor,
  onRoll,
  disabledReason,
}) => {
  const pips = PIP_CONFIGS[value] || PIP_CONFIGS[1];
  const accent = COLOR_ACCENTS[activeColor];

  return (
    <div className="flex flex-col items-center justify-center gap-1.5 sm:gap-2">
      <button
        type="button"
        onClick={canRoll ? onRoll : undefined}
        disabled={!canRoll}
        className={`relative group w-16 h-16 sm:w-20 sm:h-20 rounded-2xl bg-gradient-to-br from-white via-slate-100 to-slate-300 border-2 border-slate-300 shadow-xl transition-all duration-200 select-none flex items-center justify-center ${
          canRoll
            ? `cursor-pointer ring-4 ${accent.ring} shadow-2xl ${accent.glow} hover:scale-105 active:scale-95 animate-pulse`
            : 'opacity-90 cursor-default'
        } ${isRolling ? 'animate-dice-roll' : ''}`}
        aria-label={`Dice showing ${value}`}
        title={disabledReason || (canRoll ? 'Click to Roll Dice (or press Space)' : '')}
      >
        {/* Subtle glossy 3D overlay */}
        <div className="absolute inset-1 rounded-xl bg-gradient-to-t from-black/5 to-white/40 pointer-events-none" />

        {/* Dice Pips */}
        {pips.map((pip, idx) => (
          <span
            key={idx}
            className={`absolute w-3 h-3 sm:w-3.5 sm:h-3.5 rounded-full ${accent.pip} shadow-inner -translate-x-1/2 -translate-y-1/2 transition-all duration-150`}
            style={{ top: pip.top, left: pip.left }}
          />
        ))}

        {/* Sparkle on 6 */}
        {value === 6 && !isRolling && (
          <span className="absolute -top-2 -right-2 bg-amber-400 text-slate-950 text-[10px] font-black px-1.5 py-0.5 rounded-full shadow-md animate-bounce">
            +1 ROLL
          </span>
        )}
      </button>

      {/* Button helper text */}
      <div className="text-center min-h-[1.25rem]">
        {canRoll ? (
          <span className="text-xs sm:text-sm font-bold text-amber-300 tracking-wide drop-shadow animate-pulse">
            TAP TO ROLL
          </span>
        ) : isRolling ? (
          <span className="text-xs text-slate-300 font-medium">Rolling...</span>
        ) : (
          <span className="text-xs text-slate-400 font-medium">
            {disabledReason || `Rolled ${value}`}
          </span>
        )}
      </div>
    </div>
  );
};
