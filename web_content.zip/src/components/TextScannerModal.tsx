import React, { useState, useRef } from 'react';
import { Camera, X, Copy, Download, Loader2, ImagePlus } from 'lucide-react';
import { streamChatResponse } from '../services/gemini';

interface TextScannerModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export function TextScannerModal({ isOpen, onClose }: TextScannerModalProps) {
  const [image, setImage] = useState<string | null>(null);
  const [extractedText, setExtractedText] = useState<string>('');
  const [isScanning, setIsScanning] = useState(false);
  const [error, setError] = useState<string | null>(null);
  
  const fileInputRef = useRef<HTMLInputElement>(null);
  const galleryInputRef = useRef<HTMLInputElement>(null);

  if (!isOpen) return null;

  const handleCapture = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      try {
        const { resizeImage } = await import('../utils/image');
        const resizedImage = await resizeImage(file, 800); // Max 800px to bypass WAF
        setImage(resizedImage);
        extractText(resizedImage);
      } catch (err) {
        console.error("Image resize failed", err);
        const reader = new FileReader();
        reader.onloadend = () => {
          const base64Image = reader.result as string;
          setImage(base64Image);
          extractText(base64Image);
        };
        reader.readAsDataURL(file);
      }
    }
  };

  const extractText = async (base64Image: string) => {
    setIsScanning(true);
    setExtractedText('');
    setError(null);
    try {
      const prompt = "Extract all the text from this image perfectly. Provide ONLY the extracted text, no explanations, no markdown blocks, just the raw text exactly as it appears in the image.";
      
      const stream = streamChatResponse([], prompt, [base64Image], 'gemini-3.1-flash-lite', 'Female');
      let fullText = '';
      for await (const chunk of stream) {
        if (chunk.error) {
           throw new Error(chunk.error);
        }
        fullText += chunk.text || '';
        setExtractedText(fullText);
      }
    } catch (err: any) {
      console.error(err);
      if (err.message && err.message.includes('Upgrade to Pro')) {
         setError("Image scanning requires a PRO plan. Please click 'Upgrade to PRO' on the main screen.");
      } else {
         setError(err.message || "Failed to extract text. Please try again.");
      }
    } finally {
      setIsScanning(false);
    }
  };

  const copyToClipboard = () => {
    navigator.clipboard.writeText(extractedText);
    alert("Text copied to clipboard!");
  };

  const downloadText = () => {
    const blob = new Blob([extractedText], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'scanned_text.txt';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="fixed inset-0 z-[200] flex items-center justify-center bg-slate-950/80 backdrop-blur-md p-4 animate-fade-in">
      <div className="w-full max-w-2xl bg-white dark:bg-slate-900 rounded-3xl shadow-2xl p-6 border border-slate-200 dark:border-slate-800 flex flex-col max-h-[90vh]">
        
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-xl font-bold text-slate-900 dark:text-white flex items-center gap-2">
            <Camera className="text-orange-500" />
            Smart Text Scanner
          </h2>
          <button 
            onClick={onClose}
            className="p-2 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-full transition-colors"
          >
            <X className="text-slate-500" />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto space-y-4">
          {!image ? (
            <div className="flex flex-col items-center justify-center py-12 px-4 text-center border-2 border-dashed border-slate-300 dark:border-slate-700 rounded-2xl">
              <Camera size={48} className="text-slate-400 mb-4" />
              <p className="text-slate-600 dark:text-slate-300 mb-6">Take a photo or choose an image from your gallery to scan text.</p>
              
              <input 
                type="file" 
                ref={fileInputRef}
                onChange={handleCapture}
                accept="image/*"
                capture="environment"
                className="hidden"
              />
              <input 
                type="file" 
                ref={galleryInputRef}
                onChange={handleCapture}
                accept="image/*"
                className="hidden"
              />
              <div className="flex flex-col sm:flex-row gap-3">
                <button 
                  onClick={() => fileInputRef.current?.click()}
                  className="px-6 py-3 bg-orange-600 hover:bg-orange-700 text-white font-bold rounded-full shadow-lg transition-transform hover:scale-105 active:scale-95 flex items-center gap-2"
                >
                  <Camera size={20} /> Open Camera
                </button>
                <button 
                  onClick={() => galleryInputRef.current?.click()}
                  className="px-6 py-3 bg-slate-200 hover:bg-slate-300 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-900 dark:text-white font-bold rounded-full shadow-md transition-transform hover:scale-105 active:scale-95 flex items-center gap-2"
                >
                  <ImagePlus size={20} /> Choose from Gallery
                </button>
              </div>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 h-full min-h-[300px]">
              <div className="flex flex-col">
                <p className="text-xs font-bold text-slate-500 mb-2 uppercase">Captured Image</p>
                <div className="relative flex-1 bg-slate-100 dark:bg-slate-800 rounded-xl overflow-hidden min-h-[200px]">
                  <img src={image} alt="Scanned document" className="absolute inset-0 w-full h-full object-contain" />
                </div>
                <button 
                  onClick={() => { setImage(null); setExtractedText(''); }}
                  className="mt-2 py-2 text-sm text-slate-600 dark:text-slate-300 hover:text-orange-500 dark:hover:text-orange-400 font-medium transition-colors"
                >
                  Retake Photo
                </button>
              </div>

              <div className="flex flex-col">
                <p className="text-xs font-bold text-slate-500 mb-2 uppercase flex items-center justify-between">
                  <span>Extracted Text</span>
                  {isScanning && <Loader2 size={14} className="animate-spin text-orange-500" />}
                </p>
                <div className="flex-1 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl p-4 overflow-y-auto whitespace-pre-wrap font-mono text-sm text-slate-800 dark:text-slate-200 min-h-[200px]">
                  {isScanning && !extractedText ? (
                    <div className="flex flex-col items-center justify-center h-full text-slate-500">
                      <Loader2 size={32} className="animate-spin mb-2 text-orange-500" />
                      <p>Analyzing text with AI...</p>
                    </div>
                  ) : error ? (
                    <p className="text-red-500">{error}</p>
                  ) : (
                    extractedText || "No text detected yet."
                  )}
                </div>
                
                {extractedText && !isScanning && (
                  <div className="flex gap-2 mt-2">
                    <button 
                      onClick={copyToClipboard}
                      className="flex-1 flex items-center justify-center gap-2 py-2 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 rounded-lg text-sm font-medium transition-colors"
                    >
                      <Copy size={16} /> Copy
                    </button>
                    <button 
                      onClick={downloadText}
                      className="flex-1 flex items-center justify-center gap-2 py-2 bg-orange-600 hover:bg-orange-700 text-white rounded-lg text-sm font-medium shadow-md transition-colors"
                    >
                      <Download size={16} /> Download
                    </button>
                  </div>
                )}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
