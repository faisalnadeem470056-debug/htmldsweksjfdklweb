import React, { useEffect, useState } from 'react';
import { X, Crown, Activity, Calendar, Zap, AlertCircle } from 'lucide-react';

interface MyPlanModalProps {
  isOpen: boolean;
  onClose: () => void;
  userId: string;
  onUpgrade: () => void;
}

export function MyPlanModal({ isOpen, onClose, userId, onUpgrade }: MyPlanModalProps) {
  const [userData, setUserData] = useState<any>(null);

  useEffect(() => {
    if (isOpen && userId) {
      fetch('/api/user', { headers: { 'x-user-id': userId } })
        .then(res => res.json())
        .then(data => setUserData(data))
        .catch(console.error);
    }
  }, [isOpen, userId]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-[200] flex items-center justify-center bg-slate-950/80 backdrop-blur-sm p-4 animate-fade-in">
      <div className="relative w-full max-w-2xl bg-white dark:bg-slate-900 rounded-3xl shadow-2xl p-6 md:p-8 border border-slate-200 dark:border-slate-800">
        <button 
          onClick={onClose}
          className="absolute top-4 right-4 p-2 bg-slate-100 dark:bg-slate-800 text-slate-500 rounded-full hover:bg-slate-200 dark:hover:bg-slate-700 transition-colors"
        >
          <X size={24} />
        </button>
        
        <h2 className="text-2xl font-bold text-slate-900 dark:text-white mb-6 flex items-center gap-2">
          <Crown className="text-orange-500" />
          My Plan & Usage
        </h2>

        {userData ? (
          <div className="space-y-6">
            <div className="bg-slate-50 dark:bg-slate-950 p-6 rounded-2xl border border-slate-200 dark:border-slate-800 flex justify-between items-center">
              <div>
                <p className="text-sm text-slate-500 dark:text-slate-400 mb-1">Current Plan</p>
                <h3 className={`text-3xl font-black ${userData.plan === 'PRO' ? 'text-orange-500' : userData.plan === 'PREMIUM' ? 'text-purple-500' : 'text-slate-900 dark:text-white'}`}>
                  {userData.plan}
                </h3>
                <span className={`inline-block mt-2 px-2 py-1 text-xs font-bold rounded-lg ${userData.status === 'ACTIVE' ? 'bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400' : 'bg-red-100 text-red-700'}`}>
                  Status: {userData.status}
                </span>
              </div>
              {userData.plan === 'FREE' && (
                <button onClick={() => { onClose(); onUpgrade(); }} className="px-6 py-3 bg-gradient-to-r from-orange-500 to-rose-500 text-white font-bold rounded-xl shadow-lg hover:scale-105 transition-transform">
                  Upgrade
                </button>
              )}
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="bg-slate-50 dark:bg-slate-950 p-4 rounded-xl border border-slate-200 dark:border-slate-800">
                <div className="flex items-center gap-2 text-slate-700 dark:text-slate-300 mb-2 font-semibold">
                  <Activity size={18} className="text-blue-500"/>
                  Usage (Messages)
                </div>
                <div className="text-2xl font-bold text-slate-900 dark:text-white">
                  {userData.messageCount} <span className="text-sm font-normal text-slate-500">/ {userData.maxMessages} limit</span>
                </div>
                <div className="w-full bg-slate-200 dark:bg-slate-800 h-2 rounded-full mt-3 overflow-hidden">
                  <div 
                    className={`h-full rounded-full ${userData.messageCount >= userData.maxMessages ? 'bg-red-500' : 'bg-blue-500'}`}
                    style={{ width: `${Math.min((userData.messageCount / userData.maxMessages) * 100, 100)}%` }}
                  />
                </div>
              </div>

              {userData.currentPeriodEnd && (
                <div className="bg-slate-50 dark:bg-slate-950 p-4 rounded-xl border border-slate-200 dark:border-slate-800">
                  <div className="flex items-center gap-2 text-slate-700 dark:text-slate-300 mb-2 font-semibold">
                    <Calendar size={18} className="text-orange-500"/>
                    Next Billing Date
                  </div>
                  <div className="text-xl font-bold text-slate-900 dark:text-white">
                    {new Date(userData.currentPeriodEnd * 1000).toLocaleDateString()}
                  </div>
                  <p className="text-xs text-slate-500 mt-2">Renews automatically</p>
                </div>
              )}
            </div>

            {userData.plan !== 'FREE' && (
               <div className="pt-4 border-t border-slate-200 dark:border-slate-800 flex justify-end gap-3">
                 <form action="/api/subscription/portal" method="POST">
                    <input type="hidden" name="userId" value={userId} />
                    <button type="submit" className="px-4 py-2 border border-slate-300 dark:border-slate-600 rounded-lg text-slate-700 dark:text-slate-300 font-medium hover:bg-slate-50 dark:hover:bg-slate-800">
                      Manage Subscription & Billing
                    </button>
                 </form>
               </div>
            )}
          </div>
        ) : (
          <div className="text-center py-10">Loading...</div>
        )}
      </div>
    </div>
  );
}
