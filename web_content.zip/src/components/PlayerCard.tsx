import React from 'react';
import { Player, PlayerColor } from '../types/game';
import { Bot, User, Crown } from 'lucide-react';

interface PlayerCardProps {
  player: Player;
  isActive: boolean;
  consecutiveSixes?: number;
}

const COLOR_STYLES: Record<
  PlayerColor,
  {
    bg: string;
    border: string;
    text: string;
    glow: string;
    badge: string;
    accent: string;
  }
> = {
  red: {
    bg: 'from-red-950/70 to-slate-900/90',
    border: 'border-red-500/40',
    text: 'text-red-400',
    glow: 'shadow-red-500/30',
    badge: 'bg-red-500/20 text-red-300 border-red-500/40',
    accent: '#EF4444',
  },
  green: {
    bg: 'from-emerald-950/70 to-slate-900/90',
    border: 'border-emerald-500/40',
    text: 'text-emerald-400',
    glow: 'shadow-emerald-500/30',
    badge: 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40',
    accent: '#10B981',
  },
  yellow: {
    bg: 'from-amber-950/70 to-slate-900/90',
    border: 'border-amber-500/40',
    text: 'text-amber-400',
    glow: 'shadow-amber-500/30',
    badge: 'bg-amber-500/20 text-amber-300 border-amber-500/40',
    accent: '#F59E0B',
  },
  blue: {
    bg: 'from-blue-950/70 to-slate-900/90',
    border: 'border-blue-500/40',
    text: 'text-blue-400',
    glow: 'shadow-blue-500/30',
    badge: 'bg-blue-500/20 text-blue-300 border-blue-500/40',
    accent: '#3B82F6',
  },
};

export const PlayerCard: React.FC<PlayerCardProps> = ({
  player,
  isActive,
  consecutiveSixes = 0,
}) => {
  const styles = COLOR_STYLES[player.color];

  const inYardCount = player.tokens.filter((t) => t.step === -1).length;
  const inHomeCount = player.tokens.filter((t) => t.step === 56).length;
  const onTrackCount = 4 - inYardCount - inHomeCount;

  return (
    <div
      className={`relative rounded-xl p-2 sm:p-2.5 transition-all duration-300 border bg-gradient-to-b ${
        styles.bg
      } ${
        isActive
          ? `ring-2 sm:ring-4 ring-amber-400 border-amber-400 shadow-lg ${styles.glow} scale-[1.02]`
          : `${styles.border} opacity-85 hover:opacity-100`
      }`}
    >
      {/* Active turn badge */}
      {isActive && (
        <span className="absolute -top-2.5 right-2 bg-gradient-to-r from-amber-400 to-yellow-500 text-slate-950 text-[10px] font-black tracking-wider px-2 py-0.5 rounded-full shadow-md animate-pulse">
          TURN
        </span>
      )}

      {/* Header: Avatar, Name, Type */}
      <div className="flex items-center justify-between gap-1.5 mb-1.5">
        <div className="flex items-center gap-1.5 min-w-0">
          <div
            className="w-6 h-6 sm:w-7 sm:h-7 rounded-lg flex items-center justify-center shrink-0 border border-white/20"
            style={{ backgroundColor: styles.accent }}
          >
            {player.type === 'human' ? (
              <User className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-white" />
            ) : (
              <Bot className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-white" />
            )}
          </div>
          <div className="truncate">
            <h4 className="text-xs sm:text-sm font-bold text-slate-100 truncate flex items-center gap-1">
              {player.name}
              {player.hasWon && <Crown className="w-3.5 h-3.5 text-amber-400 inline shrink-0" />}
            </h4>
            <p className="text-[10px] text-slate-400 capitalize flex items-center gap-1">
              <span>{player.color}</span>
              <span>•</span>
              <span>{player.type}</span>
            </p>
          </div>
        </div>

        {/* Consecutive sixes badge */}
        {isActive && consecutiveSixes > 0 && (
          <div className="flex items-center gap-0.5 bg-amber-400/20 border border-amber-400/40 px-1.5 py-0.5 rounded text-[10px] text-amber-300 font-bold shrink-0">
            <span>6s:</span>
            <span>{consecutiveSixes}</span>
          </div>
        )}
      </div>

      {/* Token status breakdown pills */}
      <div className="grid grid-cols-3 gap-1 text-[10px] font-medium text-center">
        <div className="bg-slate-900/60 rounded px-1 py-0.5 border border-white/5" title="Tokens in Yard">
          <span className="text-slate-400 block text-[9px]">Base</span>
          <span className="text-slate-200 font-bold">{inYardCount}</span>
        </div>
        <div className="bg-slate-900/60 rounded px-1 py-0.5 border border-white/5" title="Tokens on Board">
          <span className="text-slate-400 block text-[9px]">Track</span>
          <span className="text-amber-300 font-bold">{onTrackCount}</span>
        </div>
        <div className="bg-slate-900/60 rounded px-1 py-0.5 border border-white/5" title="Tokens in Home Goal">
          <span className="text-slate-400 block text-[9px]">Goal</span>
          <span className="text-emerald-400 font-bold flex items-center justify-center gap-0.5">
            {inHomeCount}
            {inHomeCount === 4 && <Crown className="w-2.5 h-2.5 text-amber-400" />}
          </span>
        </div>
      </div>
    </div>
  );
};
