import React, { useState, useEffect } from 'react';
import { X, ExternalLink, Info } from 'lucide-react';

interface InterstitialAdProps {
  isOpen: boolean;
  onComplete: () => void;
}

export function InterstitialAd({ isOpen, onComplete }: InterstitialAdProps) {
  const [timeLeft, setTimeLeft] = useState(5);
  const [canSkip, setCanSkip] = useState(false);

  useEffect(() => {
    if (isOpen) {
      setTimeLeft(5);
      setCanSkip(false);
      const timer = setInterval(() => {
        setTimeLeft((prev) => {
          if (prev <= 1) {
            clearInterval(timer);
            setCanSkip(true);
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
      return () => clearInterval(timer);
    }
  }, [isOpen]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-[9999] flex flex-col bg-slate-100 dark:bg-slate-900 animate-fade-in">
      {/* Header */}
      <div className="flex justify-between items-center p-4 bg-white dark:bg-slate-950 shadow-sm border-b border-slate-200 dark:border-slate-800">
        <div className="flex items-center gap-2 text-xs text-slate-500 font-medium px-2 py-1 bg-slate-100 dark:bg-slate-800 rounded">
          <Info size={12} />
          Advertisement
        </div>
        {canSkip ? (
          <button 
            onClick={onComplete}
            className="flex items-center gap-1 px-4 py-2 bg-slate-200 dark:bg-slate-800 hover:bg-slate-300 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 rounded-full font-medium transition-colors cursor-pointer"
          >
            Skip Ad <X size={16} />
          </button>
        ) : (
          <div className="px-4 py-2 text-slate-500 text-sm font-medium">
            Skip in {timeLeft}s
          </div>
        )}
      </div>
      
      {/* Ad Content - Google Text Ad Style */}
      <div className="flex-1 flex flex-col items-center justify-center p-6 bg-slate-50 dark:bg-slate-900">
        <div 
          onClick={() => { if (canSkip) onComplete(); }}
          className="w-full max-w-2xl bg-white dark:bg-slate-950 p-8 md:p-12 rounded-3xl shadow-xl border border-slate-200 dark:border-slate-800 cursor-pointer transform transition hover:scale-[1.02]"
        >
          <div className="flex items-center gap-2 mb-4">
            <span className="text-[10px] font-bold text-slate-600 dark:text-slate-300 tracking-wider uppercase border border-slate-300 dark:border-slate-700 px-2 py-0.5 rounded">Sponsored</span>
            <span className="text-sm text-slate-400">· www.cloud-ai-mastery.com</span>
          </div>
          <h2 className="text-2xl md:text-3xl font-medium text-blue-600 dark:text-blue-400 mb-4 hover:underline">
            Master AI Development in 30 Days | Guaranteed Placement
          </h2>
          <p className="text-slate-600 dark:text-slate-400 text-lg mb-8 leading-relaxed">
            Join our exclusive bootcamp. Learn to build full-stack AI applications with React, Node.js, and Gemini. Start your journey today and get 50% off on enrollment. Limited seats available!
          </p>
          <div className="flex items-center text-blue-600 dark:text-blue-400 font-medium text-lg group">
            Visit Site <ExternalLink size={20} className="ml-2 group-hover:translate-x-1 transition-transform" />
          </div>
        </div>
        
        <p className="mt-8 text-xs text-slate-400 dark:text-slate-500 text-center max-w-md">
          This ad helps us keep India GPT free for everyone. Upgrade to PRO to enjoy an ad-free experience.
        </p>
      </div>
    </div>
  );
}
