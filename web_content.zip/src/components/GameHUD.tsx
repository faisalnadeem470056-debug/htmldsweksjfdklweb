import React from 'react';
import { Shield, Heart, Pause, Crosshair, Award, Coins, Skull, Zap } from 'lucide-react';
import { Weapon, Zombie, ItemPickup } from '../types/game';

interface GameHUDProps {
  level: number;
  mapName: string;
  zombiesRemaining: number;
  totalZombies: number;
  bossZombie: Zombie | null;
  hp: number;
  maxHp: number;
  shield: number;
  maxShield: number;
  activeWeapon: Weapon;
  unlockedWeapons: Weapon[];
  onSelectWeapon: (weaponId: Weapon['id']) => void;
  coinsEarned: number;
  score: number;
  comboCount: number;
  isReloading: boolean;
  onPause: () => void;
  playerPos: { x: number; y: number };
  zombies: Zombie[];
  pickups: ItemPickup[];
  worldSize: { width: number; height: number };
  jumpCooldown: number;
  canJump: boolean;
}

export const GameHUD: React.FC<GameHUDProps> = ({
  level,
  mapName,
  zombiesRemaining,
  totalZombies,
  bossZombie,
  hp,
  maxHp,
  shield,
  maxShield,
  activeWeapon,
  unlockedWeapons,
  onSelectWeapon,
  coinsEarned,
  score,
  comboCount,
  isReloading,
  onPause,
  playerPos,
  zombies,
  pickups,
  worldSize,
  jumpCooldown,
  canJump
}) => {
  const hpPercent = Math.max(0, Math.min(100, (hp / maxHp) * 100));
  const shieldPercent = Math.max(0, Math.min(100, (shield / maxShield) * 100));
  const bossHpPercent = bossZombie ? Math.max(0, Math.min(100, (bossZombie.hp / bossZombie.maxHp) * 100)) : 0;

  return (
    <div id="game-hud-root" className="absolute inset-0 pointer-events-none z-20 flex flex-col justify-between p-3 sm:p-4 select-none">
      {/* Top Header Bar */}
      <div className="w-full flex items-start justify-between gap-2">
        {/* Level and Objective */}
        <div className="flex flex-col gap-1 bg-slate-900/85 backdrop-blur border border-slate-700/80 rounded-xl px-3 py-2 shadow-lg max-w-[200px] sm:max-w-xs">
          <div className="flex items-center gap-2">
            <span className="px-2 py-0.5 rounded bg-rose-600 text-white font-display font-bold text-xs">
              LVL {level}
            </span>
            <span className="text-xs font-semibold text-slate-300 truncate">{mapName}</span>
          </div>
          <div className="flex items-center gap-2 text-xs">
            <Skull size={14} className="text-rose-400" />
            <span className="font-bold text-slate-200">
              {bossZombie ? 'BOSS BATTLE' : `Zombies: ${zombiesRemaining}/${totalZombies}`}
            </span>
          </div>
        </div>

        {/* Center: Boss Bar or Combo Banner */}
        <div className="flex-1 max-w-md mx-2 flex flex-col items-center">
          {bossZombie ? (
            <div id="boss-health-bar" className="w-full bg-slate-950/90 border-2 border-rose-500/80 rounded-xl p-2 shadow-2xl animate-pulse">
              <div className="flex justify-between items-center mb-1">
                <span className="text-xs font-display font-black text-rose-400 tracking-wider flex items-center gap-1">
                  <Skull size={14} className="text-red-500 animate-bounce" /> {bossZombie.bossTitle || 'BOSS THREAT'}
                </span>
                <span className="text-[11px] font-mono font-bold text-slate-300">
                  {Math.ceil(bossZombie.hp)} / {bossZombie.maxHp}
                </span>
              </div>
              <div className="w-full h-3 bg-slate-800 rounded-full overflow-hidden border border-rose-900/60 relative">
                <div
                  className="h-full bg-gradient-to-r from-red-600 via-rose-500 to-amber-400 transition-all duration-150 rounded-full shadow-[0_0_12px_rgba(239,68,68,0.8)]"
                  style={{ width: `${bossHpPercent}%` }}
                />
              </div>
            </div>
          ) : comboCount > 1 ? (
            <div className="px-4 py-1.5 rounded-full bg-gradient-to-r from-amber-500/90 to-rose-500/90 border border-white/50 text-white shadow-lg flex items-center gap-1.5 animate-bounce">
              <Award size={16} />
              <span className="font-display font-black text-sm tracking-wide">
                {comboCount}x COMBO!
              </span>
            </div>
          ) : null}
        </div>

        {/* Right Header: Coins, Score, Radar, and Pause Button */}
        <div className="flex items-center gap-2 pointer-events-auto">
          {/* Stats pills */}
          <div className="hidden sm:flex flex-col items-end bg-slate-900/85 backdrop-blur border border-slate-700/80 rounded-xl px-3 py-1.5 text-xs shadow-lg">
            <div className="flex items-center gap-1.5 text-amber-400 font-bold">
              <Coins size={14} />
              <span>+{coinsEarned}</span>
            </div>
            <div className="text-[11px] text-slate-400 font-mono">
              SCORE: <span className="text-white font-bold">{score}</span>
            </div>
          </div>

          {/* Mini Radar (Round Threat Radar) */}
          <div 
            id="mini-radar"
            className="w-16 h-16 sm:w-20 sm:h-20 rounded-full bg-slate-950/90 border border-cyan-500/40 relative overflow-hidden shadow-lg hidden xs:block"
            title="Radar: Green = You, Red = Zombies, Yellow = Items, Purple = Boss"
          >
            {/* Grid crosshair lines */}
            <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
              <div className="w-full h-[1px] bg-cyan-500/20" />
              <div className="h-full w-[1px] bg-cyan-500/20 absolute" />
            </div>
            {/* Radar sweeping scan */}
            <div className="absolute inset-0 rounded-full border border-cyan-400/20" />

            {/* Radar Blips */}
            {/* Center: Player */}
            <div className="absolute w-2 h-2 rounded-full bg-emerald-400 top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 shadow-sm shadow-emerald-400" />
            
            {/* Zombies */}
            {zombies.map(z => {
              const dx = (z.x - playerPos.x) / (worldSize.width / 2);
              const dy = (z.y - playerPos.y) / (worldSize.height / 2);
              const radarX = 50 + dx * 40;
              const radarY = 50 + dy * 40;
              if (radarX < 2 || radarX > 98 || radarY < 2 || radarY > 98) return null;
              return (
                <div
                  key={z.id}
                  className={`absolute rounded-full -translate-x-1/2 -translate-y-1/2 ${
                    z.isBoss 
                      ? 'w-2.5 h-2.5 bg-rose-500 animate-ping' 
                      : 'w-1.5 h-1.5 bg-red-400'
                  }`}
                  style={{ left: `${radarX}%`, top: `${radarY}%` }}
                />
              );
            })}

            {/* Pickups */}
            {pickups.map(p => {
              const dx = (p.x - playerPos.x) / (worldSize.width / 2);
              const dy = (p.y - playerPos.y) / (worldSize.height / 2);
              const radarX = 50 + dx * 40;
              const radarY = 50 + dy * 40;
              if (radarX < 2 || radarX > 98 || radarY < 2 || radarY > 98) return null;
              return (
                <div
                  key={p.id}
                  className="absolute w-1.5 h-1.5 rounded-full bg-amber-300 -translate-x-1/2 -translate-y-1/2"
                  style={{ left: `${radarX}%`, top: `${radarY}%` }}
                />
              );
            })}
          </div>

          {/* Pause Button */}
          <button
            id="pause-game-btn"
            onClick={onPause}
            className="w-10 h-10 rounded-xl bg-slate-900/90 border border-slate-700 hover:border-slate-500 text-slate-200 flex items-center justify-center shadow-lg active:scale-95 transition-all"
            title="Pause (Esc)"
          >
            <Pause size={18} />
          </button>
        </div>
      </div>

      {/* Bottom HUD: Status Bars (Left) and Weapon Bar (Right) */}
      <div className="w-full flex flex-col sm:flex-row items-end justify-between gap-3">
        {/* Player Health and Shield Gauges */}
        <div className="bg-slate-900/90 backdrop-blur border border-slate-700/80 rounded-2xl p-3 shadow-xl flex flex-col gap-2 w-full max-w-[260px]">
          {/* Health */}
          <div>
            <div className="flex justify-between text-xs font-bold mb-1">
              <span className="flex items-center gap-1 text-rose-400">
                <Heart size={14} className={hp < 30 ? 'animate-pulse text-red-500' : ''} /> HP
              </span>
              <span className="text-slate-200 font-mono text-[11px]">{Math.ceil(hp)} / {maxHp}</span>
            </div>
            <div className="w-full h-2.5 bg-slate-800 rounded-full overflow-hidden border border-slate-700">
              <div
                className={`h-full transition-all duration-200 rounded-full ${
                  hp < 30 ? 'bg-red-500 animate-pulse' : 'bg-emerald-500'
                }`}
                style={{ width: `${hpPercent}%` }}
              />
            </div>
          </div>

          {/* Shield */}
          <div>
            <div className="flex justify-between text-xs font-bold mb-1">
              <span className="flex items-center gap-1 text-sky-400">
                <Shield size={14} /> SHIELD
              </span>
              <span className="text-slate-200 font-mono text-[11px]">{Math.ceil(shield)} / {maxShield}</span>
            </div>
            <div className="w-full h-2 bg-slate-800 rounded-full overflow-hidden border border-slate-700">
              <div
                className="h-full bg-cyan-400 transition-all duration-200 rounded-full"
                style={{ width: `${shieldPercent}%` }}
              />
            </div>
          </div>

          {/* Dodge / Dash Status */}
          <div className="flex items-center justify-between text-[11px] font-semibold text-slate-400 pt-1 border-t border-slate-800">
            <span className="flex items-center gap-1">
              <Zap size={12} className={canJump ? 'text-indigo-400' : 'text-slate-600'} />
              Dodge Dash (Space)
            </span>
            <span className={canJump ? 'text-emerald-400 font-bold' : 'text-slate-500'}>
              {canJump ? 'READY' : `${jumpCooldown.toFixed(1)}s`}
            </span>
          </div>
        </div>

        {/* Right: Active Weapon Card & Quick Switcher */}
        <div className="flex flex-col items-end gap-2 pointer-events-auto">
          {/* Quick weapon switch tabs (Keys 1-6 / Click) */}
          <div className="flex items-center gap-1 bg-slate-950/80 p-1 rounded-xl border border-slate-800">
            {unlockedWeapons.map((w, index) => (
              <button
                key={w.id}
                onClick={() => onSelectWeapon(w.id)}
                className={`px-2.5 py-1 rounded-lg text-xs font-bold transition-all flex items-center gap-1 ${
                  activeWeapon.id === w.id
                    ? 'bg-rose-600 text-white shadow-md'
                    : 'bg-slate-900/60 text-slate-400 hover:text-slate-200 border border-slate-800'
                }`}
                title={`Press ${index + 1} to equip`}
              >
                <span className="text-[10px] opacity-70">[{index + 1}]</span>
                <span className="truncate max-w-[60px] sm:max-w-none">{w.name.split(' ')[0]}</span>
              </button>
            ))}
          </div>

          {/* Main Active Weapon Card */}
          <div 
            id="active-weapon-hud-card"
            className="bg-slate-900/90 backdrop-blur border border-slate-700/80 rounded-2xl p-3 shadow-xl flex items-center gap-3 min-w-[220px]"
          >
            <div 
              className="w-12 h-12 rounded-xl flex items-center justify-center border shadow-inner"
              style={{ backgroundColor: `${activeWeapon.color}22`, borderColor: activeWeapon.color }}
            >
              <Crosshair size={24} style={{ color: activeWeapon.color }} />
            </div>

            <div className="flex-1">
              <div className="text-xs font-bold text-slate-300 truncate">{activeWeapon.name}</div>
              <div className="flex items-baseline gap-1 mt-0.5">
                <span className={`font-mono text-xl font-black ${isReloading ? 'text-amber-400 animate-pulse' : 'text-white'}`}>
                  {isReloading ? 'RELOADING' : activeWeapon.currentAmmo}
                </span>
                {!isReloading && (
                  <span className="text-xs text-slate-400 font-mono">
                    / {activeWeapon.reserveAmmo > 900 ? '∞' : activeWeapon.reserveAmmo}
                  </span>
                )}
              </div>
              <div className="text-[10px] text-slate-400">
                [L-Click] Fire &bull; [R] Reload
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
