import React, { useEffect } from 'react';
import confetti from 'canvas-confetti';
import { Trophy, Crown, RotateCcw, Home, Sparkles } from 'lucide-react';
import { Player, PlayerColor } from '../types/game';
import { sounds } from '../utils/audio';

interface WinnerModalProps {
  winner: Player;
  isOpen: boolean;
  onPlayAgain: () => void;
  onHome: () => void;
}

const COLOR_NAMES: Record<PlayerColor, { name: string; text: string; bg: string }> = {
  red: { name: 'Red', text: 'text-red-400', bg: 'bg-red-500' },
  green: { name: 'Green', text: 'text-emerald-400', bg: 'bg-emerald-500' },
  yellow: { name: 'Yellow', text: 'text-amber-400', bg: 'bg-amber-500' },
  blue: { name: 'Blue', text: 'text-blue-400', bg: 'bg-blue-500' },
};

export const WinnerModal: React.FC<WinnerModalProps> = ({
  winner,
  isOpen,
  onPlayAgain,
  onHome,
}) => {
  useEffect(() => {
    if (isOpen) {
      sounds.playWinFanfare();

      // Launch celebratory confetti bursts
      const duration = 3.5 * 1000;
      const animationEnd = Date.now() + duration;
      const defaults = { startVelocity: 30, spread: 360, ticks: 60, zIndex: 9999 };

      const interval: ReturnType<typeof setInterval> = setInterval(() => {
        const timeLeft = animationEnd - Date.now();
        if (timeLeft <= 0) {
          return clearInterval(interval);
        }
        const particleCount = 50 * (timeLeft / duration);
        confetti({
          ...defaults,
          particleCount,
          origin: { x: 0.15 + Math.random() * 0.2, y: Math.random() - 0.2 },
        });
        confetti({
          ...defaults,
          particleCount,
          origin: { x: 0.65 + Math.random() * 0.2, y: Math.random() - 0.2 },
        });
      }, 250);

      return () => clearInterval(interval);
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const colorMeta = COLOR_NAMES[winner.color];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-fade-in">
      <div className="relative w-full max-w-md bg-gradient-to-b from-slate-900 via-slate-900 to-amber-950/30 border-2 border-amber-400/60 rounded-3xl p-6 sm:p-8 shadow-2xl text-center overflow-hidden">
        {/* Glow backdrop */}
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-48 h-48 bg-amber-500/25 rounded-full blur-3xl pointer-events-none" />

        {/* Floating Crown / Trophy */}
        <div className="relative mx-auto w-24 h-24 mb-4 flex items-center justify-center">
          <div className="absolute inset-0 rounded-full bg-amber-500/20 animate-ping opacity-60" />
          <div className="relative w-20 h-20 rounded-full bg-gradient-to-tr from-amber-600 via-yellow-400 to-amber-200 p-1 shadow-xl flex items-center justify-center">
            <div className="w-full h-full rounded-full bg-slate-950 flex items-center justify-center">
              <Trophy className="w-10 h-10 text-amber-400 animate-bounce" />
            </div>
          </div>
          <Crown className="absolute -top-3 right-1 w-8 h-8 text-amber-300 drop-shadow-lg rotate-12" />
        </div>

        {/* Title */}
        <div className="flex items-center justify-center gap-2 mb-1">
          <Sparkles className="w-5 h-5 text-amber-400" />
          <h2 className="text-3xl font-black font-cinzel text-amber-300 tracking-wider">
            CHAMPION!
          </h2>
          <Sparkles className="w-5 h-5 text-amber-400" />
        </div>

        <p className="text-slate-300 text-sm mb-4">
          All 4 tokens safely brought home!
        </p>

        {/* Winner Highlight Card */}
        <div className="bg-slate-800/80 border border-amber-500/30 rounded-2xl p-4 mb-6 shadow-inner flex items-center justify-center gap-3">
          <div
            className={`w-10 h-10 rounded-xl flex items-center justify-center text-white font-bold text-lg shadow-md ${colorMeta.bg}`}
          >
            ★
          </div>
          <div className="text-left">
            <h3 className="text-xl font-black text-white">{winner.name}</h3>
            <p className={`text-xs font-semibold capitalize ${colorMeta.text}`}>
              {colorMeta.name} Player ({winner.type})
            </p>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="space-y-3">
          <button
            onClick={() => {
              sounds.playClick();
              onPlayAgain();
            }}
            className="w-full py-3.5 px-4 rounded-xl font-bold bg-gradient-to-r from-amber-400 to-yellow-500 text-slate-950 hover:brightness-110 shadow-lg shadow-amber-500/20 flex items-center justify-center gap-2 cursor-pointer transition-transform active:scale-95"
          >
            <RotateCcw className="w-5 h-5 text-slate-950" />
            PLAY AGAIN
          </button>

          <button
            onClick={() => {
              sounds.playClick();
              onHome();
            }}
            className="w-full py-3 px-4 rounded-xl font-semibold bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 flex items-center justify-center gap-2 cursor-pointer transition-colors"
          >
            <Home className="w-4 h-4 text-slate-400" />
            MAIN MENU
          </button>
        </div>
      </div>
    </div>
  );
};
