import React, { useState } from 'react';
import { Play, HelpCircle, Volume2, VolumeX, Trophy, Users, Bot, User, Sparkles } from 'lucide-react';
import { GameMode, PlayerColor, PlayerType } from '../types/game';
import { sounds } from '../utils/audio';

interface PlayerSlotConfig {
  color: PlayerColor;
  name: string;
  type: PlayerType;
}

interface StartScreenProps {
  soundEnabled: boolean;
  onToggleSound: () => void;
  onOpenHowToPlay: () => void;
  onOpenStats: () => void;
  onStartGame: (mode: GameMode, playerConfigs: PlayerSlotConfig[]) => void;
}

export const StartScreen: React.FC<StartScreenProps> = ({
  soundEnabled,
  onToggleSound,
  onOpenHowToPlay,
  onOpenStats,
  onStartGame,
}) => {
  const [mode, setMode] = useState<GameMode>('4-player');

  // Player configs
  const [configs, setConfigs] = useState<Record<PlayerColor, { name: string; type: PlayerType }>>({
    red: { name: 'Player 1', type: 'human' },
    green: { name: 'Bot Green', type: 'bot' },
    yellow: { name: 'Player 2', type: 'human' },
    blue: { name: 'Bot Blue', type: 'bot' },
  });

  const togglePlayerType = (color: PlayerColor) => {
    sounds.playClick();
    setConfigs((prev) => ({
      ...prev,
      [color]: {
        ...prev[color],
        type: prev[color].type === 'human' ? 'bot' : 'human',
        name:
          prev[color].type === 'human'
            ? `Bot ${color.charAt(0).toUpperCase() + color.slice(1)}`
            : `Player ${color === 'red' ? '1' : color === 'green' ? '2' : color === 'yellow' ? '3' : '4'}`,
      },
    }));
  };

  const handleStart = () => {
    sounds.playClick();
    const activeColors: PlayerColor[] =
      mode === '2-player' ? ['red', 'yellow'] : ['red', 'green', 'yellow', 'blue'];

    const playerConfigs: PlayerSlotConfig[] = activeColors.map((color) => ({
      color,
      name: configs[color].name,
      type: configs[color].type,
    }));

    onStartGame(mode, playerConfigs);
  };

  return (
    <div className="relative min-h-screen w-full flex flex-col items-center justify-center p-4 bg-gradient-to-b from-slate-950 via-slate-900 to-[#070b14] overflow-hidden">
      {/* Decorative ambient glowing orbs */}
      <div className="absolute top-1/4 -left-20 w-80 h-80 bg-red-600/15 rounded-full blur-[100px] pointer-events-none" />
      <div className="absolute top-1/3 -right-20 w-80 h-80 bg-emerald-600/15 rounded-full blur-[100px] pointer-events-none" />
      <div className="absolute -bottom-20 left-1/3 w-96 h-96 bg-amber-500/15 rounded-full blur-[120px] pointer-events-none" />

      {/* Main Container */}
      <div className="relative z-10 w-full max-w-md mx-auto flex flex-col items-center">
        {/* Crown Badge */}
        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-500/10 border border-amber-500/30 text-amber-300 text-xs font-semibold mb-3 shadow-sm">
          <Sparkles className="w-3.5 h-3.5 text-amber-400" />
          <span>CLASSIC BOARD GAME REIMAGINED</span>
        </div>

        {/* Game Title */}
        <h1 className="text-5xl sm:text-6xl font-black font-cinzel text-center tracking-wider mb-2 text-gold-gradient drop-shadow-lg">
          ARS LUDO
        </h1>
        <p className="text-slate-400 text-xs sm:text-sm text-center mb-6 tracking-wide">
          Roll the dice, capture tokens, and conquer the board!
        </p>

        {/* Card Frame */}
        <div className="w-full bg-slate-900/80 backdrop-blur-xl border border-amber-500/30 rounded-3xl p-5 sm:p-6 shadow-2xl mb-6 space-y-5">
          {/* Mode Selector (2-Player vs 4-Player) */}
          <div>
            <label className="block text-xs font-bold text-slate-300 uppercase tracking-wider mb-2 flex items-center gap-1.5">
              <Users className="w-4 h-4 text-amber-400" /> Select Game Mode
            </label>
            <div className="grid grid-cols-2 gap-2.5">
              <button
                type="button"
                onClick={() => {
                  sounds.playClick();
                  setMode('2-player');
                }}
                className={`py-3 px-4 rounded-xl font-bold text-sm border cursor-pointer transition-all ${
                  mode === '2-player'
                    ? 'bg-gradient-to-r from-amber-400 to-yellow-500 text-slate-950 border-amber-400 shadow-md shadow-amber-500/20 scale-[1.02]'
                    : 'bg-slate-800/80 text-slate-300 border-slate-700 hover:border-slate-600'
                }`}
              >
                2 PLAYERS
                <span className="block text-[10px] font-normal opacity-80 mt-0.5">
                  Red vs Yellow (Head-to-Head)
                </span>
              </button>

              <button
                type="button"
                onClick={() => {
                  sounds.playClick();
                  setMode('4-player');
                }}
                className={`py-3 px-4 rounded-xl font-bold text-sm border cursor-pointer transition-all ${
                  mode === '4-player'
                    ? 'bg-gradient-to-r from-amber-400 to-yellow-500 text-slate-950 border-amber-400 shadow-md shadow-amber-500/20 scale-[1.02]'
                    : 'bg-slate-800/80 text-slate-300 border-slate-700 hover:border-slate-600'
                }`}
              >
                4 PLAYERS
                <span className="block text-[10px] font-normal opacity-80 mt-0.5">
                  Full Board Battle
                </span>
              </button>
            </div>
          </div>

          {/* Seat Configuration (Human vs AI Toggles) */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <label className="text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center gap-1.5">
                <Bot className="w-4 h-4 text-amber-400" /> Configure Players
              </label>
              <span className="text-[11px] text-slate-400">Tap to toggle Bot / Human</span>
            </div>

            <div className="grid grid-cols-2 gap-2">
              {/* Red */}
              <div
                onClick={() => togglePlayerType('red')}
                className="p-2.5 rounded-xl bg-red-950/40 border border-red-500/40 flex items-center justify-between cursor-pointer hover:border-red-400 transition-colors"
              >
                <div className="flex items-center gap-2">
                  <div className="w-7 h-7 rounded-lg bg-red-600 flex items-center justify-center text-white text-xs font-bold shadow">
                    R
                  </div>
                  <div>
                    <span className="text-xs font-bold text-slate-200 block truncate">
                      {configs.red.name}
                    </span>
                    <span className="text-[10px] text-red-300 font-semibold uppercase">
                      {configs.red.type}
                    </span>
                  </div>
                </div>
                {configs.red.type === 'human' ? (
                  <User className="w-4 h-4 text-emerald-400 shrink-0" />
                ) : (
                  <Bot className="w-4 h-4 text-amber-400 shrink-0" />
                )}
              </div>

              {/* Yellow */}
              <div
                onClick={() => togglePlayerType('yellow')}
                className="p-2.5 rounded-xl bg-amber-950/40 border border-amber-500/40 flex items-center justify-between cursor-pointer hover:border-amber-400 transition-colors"
              >
                <div className="flex items-center gap-2">
                  <div className="w-7 h-7 rounded-lg bg-amber-500 flex items-center justify-center text-slate-950 text-xs font-black shadow">
                    Y
                  </div>
                  <div>
                    <span className="text-xs font-bold text-slate-200 block truncate">
                      {configs.yellow.name}
                    </span>
                    <span className="text-[10px] text-amber-300 font-semibold uppercase">
                      {configs.yellow.type}
                    </span>
                  </div>
                </div>
                {configs.yellow.type === 'human' ? (
                  <User className="w-4 h-4 text-emerald-400 shrink-0" />
                ) : (
                  <Bot className="w-4 h-4 text-amber-400 shrink-0" />
                )}
              </div>

              {/* Green (if 4 player) */}
              {mode === '4-player' && (
                <div
                  onClick={() => togglePlayerType('green')}
                  className="p-2.5 rounded-xl bg-emerald-950/40 border border-emerald-500/40 flex items-center justify-between cursor-pointer hover:border-emerald-400 transition-colors"
                >
                  <div className="flex items-center gap-2">
                    <div className="w-7 h-7 rounded-lg bg-emerald-600 flex items-center justify-center text-white text-xs font-bold shadow">
                      G
                    </div>
                    <div>
                      <span className="text-xs font-bold text-slate-200 block truncate">
                        {configs.green.name}
                      </span>
                      <span className="text-[10px] text-emerald-300 font-semibold uppercase">
                        {configs.green.type}
                      </span>
                    </div>
                  </div>
                  {configs.green.type === 'human' ? (
                    <User className="w-4 h-4 text-emerald-400 shrink-0" />
                  ) : (
                    <Bot className="w-4 h-4 text-amber-400 shrink-0" />
                  )}
                </div>
              )}

              {/* Blue (if 4 player) */}
              {mode === '4-player' && (
                <div
                  onClick={() => togglePlayerType('blue')}
                  className="p-2.5 rounded-xl bg-blue-950/40 border border-blue-500/40 flex items-center justify-between cursor-pointer hover:border-blue-400 transition-colors"
                >
                  <div className="flex items-center gap-2">
                    <div className="w-7 h-7 rounded-lg bg-blue-600 flex items-center justify-center text-white text-xs font-bold shadow">
                      B
                    </div>
                    <div>
                      <span className="text-xs font-bold text-slate-200 block truncate">
                        {configs.blue.name}
                      </span>
                      <span className="text-[10px] text-blue-300 font-semibold uppercase">
                        {configs.blue.type}
                      </span>
                    </div>
                  </div>
                  {configs.blue.type === 'human' ? (
                    <User className="w-4 h-4 text-emerald-400 shrink-0" />
                  ) : (
                    <Bot className="w-4 h-4 text-amber-400 shrink-0" />
                  )}
                </div>
              )}
            </div>
          </div>

          {/* PLAY Button */}
          <button
            type="button"
            onClick={handleStart}
            className="w-full py-4 rounded-2xl font-black font-cinzel text-lg tracking-wider bg-gradient-to-r from-amber-400 via-yellow-400 to-amber-500 text-slate-950 hover:brightness-110 shadow-xl shadow-amber-500/25 flex items-center justify-center gap-3 cursor-pointer transition-transform active:scale-95"
          >
            <Play className="w-6 h-6 fill-slate-950" />
            START GAME
          </button>
        </div>

        {/* Secondary Options Bar: HOW TO PLAY, SOUND, STATS */}
        <div className="w-full grid grid-cols-3 gap-2 text-xs">
          <button
            onClick={() => {
              sounds.playClick();
              onOpenHowToPlay();
            }}
            className="py-2.5 px-3 rounded-xl bg-slate-900/80 hover:bg-slate-800 border border-slate-800 hover:border-slate-700 text-slate-300 flex items-center justify-center gap-1.5 cursor-pointer transition-colors"
          >
            <HelpCircle className="w-4 h-4 text-amber-400" />
            <span>HOW TO PLAY</span>
          </button>

          <button
            onClick={() => {
              sounds.playClick();
              onOpenStats();
            }}
            className="py-2.5 px-3 rounded-xl bg-slate-900/80 hover:bg-slate-800 border border-slate-800 hover:border-slate-700 text-slate-300 flex items-center justify-center gap-1.5 cursor-pointer transition-colors"
          >
            <Trophy className="w-4 h-4 text-amber-400" />
            <span>STATS</span>
          </button>

          <button
            onClick={onToggleSound}
            className="py-2.5 px-3 rounded-xl bg-slate-900/80 hover:bg-slate-800 border border-slate-800 hover:border-slate-700 text-slate-300 flex items-center justify-center gap-1.5 cursor-pointer transition-colors"
          >
            {soundEnabled ? (
              <>
                <Volume2 className="w-4 h-4 text-emerald-400" />
                <span>SOUND ON</span>
              </>
            ) : (
              <>
                <VolumeX className="w-4 h-4 text-rose-400" />
                <span>SOUND OFF</span>
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
};
