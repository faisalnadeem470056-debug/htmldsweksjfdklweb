import React from 'react';
import { Pause, RotateCcw, Volume2, VolumeX, HelpCircle, Trophy } from 'lucide-react';
import { Player, PlayerColor } from '../types/game';
import { sounds } from '../utils/audio';

interface ControlsHeaderProps {
  activePlayer: Player;
  turnMessage: string;
  soundEnabled: boolean;
  onToggleSound: () => void;
  onPause: () => void;
  onRestart: () => void;
  onOpenHowToPlay: () => void;
  onOpenStats: () => void;
}

const PLAYER_BADGE: Record<PlayerColor, { bg: string; text: string; border: string }> = {
  red: { bg: 'bg-red-500/20', text: 'text-red-400', border: 'border-red-500/40' },
  green: { bg: 'bg-emerald-500/20', text: 'text-emerald-400', border: 'border-emerald-500/40' },
  yellow: { bg: 'bg-amber-500/20', text: 'text-amber-400', border: 'border-amber-500/40' },
  blue: { bg: 'bg-blue-500/20', text: 'text-blue-400', border: 'border-blue-500/40' },
};

export const ControlsHeader: React.FC<ControlsHeaderProps> = ({
  activePlayer,
  turnMessage,
  soundEnabled,
  onToggleSound,
  onPause,
  onRestart,
  onOpenHowToPlay,
  onOpenStats,
}) => {
  const badgeStyle = PLAYER_BADGE[activePlayer.color];

  return (
    <header className="w-full max-w-4xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-2 px-3 py-2 sm:px-4 bg-slate-900/80 backdrop-blur-md border border-slate-800 rounded-2xl shadow-lg mb-2">
      {/* Left: Logo & Active Player */}
      <div className="flex items-center gap-3 w-full sm:w-auto justify-between sm:justify-start">
        <h1 className="text-xl sm:text-2xl font-black font-cinzel text-gold-gradient tracking-wider">
          ARS LUDO
        </h1>

        {/* Turn indicator pill */}
        <div
          className={`flex items-center gap-1.5 px-2.5 py-1 rounded-full border text-xs font-bold ${badgeStyle.bg} ${badgeStyle.text} ${badgeStyle.border} shadow-sm animate-pulse`}
        >
          <span
            className="w-2.5 h-2.5 rounded-full"
            style={{
              backgroundColor:
                activePlayer.color === 'red'
                  ? '#EF4444'
                  : activePlayer.color === 'green'
                  ? '#10B981'
                  : activePlayer.color === 'yellow'
                  ? '#F59E0B'
                  : '#3B82F6',
            }}
          />
          <span>{activePlayer.name}'s Turn</span>
        </div>
      </div>

      {/* Center: Dynamic Game Status Message */}
      <div className="text-center text-xs sm:text-sm font-semibold text-slate-200 px-2 py-0.5 min-h-[1.5rem] flex items-center justify-center">
        <span className="truncate max-w-xs sm:max-w-md drop-shadow">{turnMessage}</span>
      </div>

      {/* Right: Quick Action Controls */}
      <div className="flex items-center gap-1 sm:gap-1.5">
        <button
          onClick={onToggleSound}
          className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white border border-slate-700/60 transition-colors cursor-pointer"
          title={soundEnabled ? 'Mute Sound' : 'Enable Sound'}
          aria-label="Sound Toggle"
        >
          {soundEnabled ? (
            <Volume2 className="w-4 h-4 text-emerald-400" />
          ) : (
            <VolumeX className="w-4 h-4 text-rose-400" />
          )}
        </button>

        <button
          onClick={() => {
            sounds.playClick();
            onOpenHowToPlay();
          }}
          className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white border border-slate-700/60 transition-colors cursor-pointer"
          title="How to Play"
          aria-label="Rules"
        >
          <HelpCircle className="w-4 h-4 text-amber-400" />
        </button>

        <button
          onClick={() => {
            sounds.playClick();
            onOpenStats();
          }}
          className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white border border-slate-700/60 transition-colors cursor-pointer"
          title="Hall of Fame & Statistics"
          aria-label="Stats"
        >
          <Trophy className="w-4 h-4 text-amber-400" />
        </button>

        <button
          onClick={() => {
            sounds.playClick();
            onRestart();
          }}
          className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white border border-slate-700/60 transition-colors cursor-pointer"
          title="Restart Game"
          aria-label="Restart"
        >
          <RotateCcw className="w-4 h-4 text-slate-300" />
        </button>

        <button
          onClick={() => {
            sounds.playClick();
            onPause();
          }}
          className="p-2 rounded-xl bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border border-amber-500/40 transition-colors cursor-pointer"
          title="Pause Menu"
          aria-label="Pause"
        >
          <Pause className="w-4 h-4" />
        </button>
      </div>
    </header>
  );
};
