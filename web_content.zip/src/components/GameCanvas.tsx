import React, { useRef, useEffect, useState, useCallback } from 'react';
import { 
  Weapon, 
  WeaponType, 
  Zombie, 
  ZombieType, 
  Bullet, 
  Particle, 
  FloatingText, 
  ItemPickup, 
  Obstacle,
  PlayerStats,
  GameSettings
} from '../types/game';
import { getLevelDetails, getMapThemeForLevel } from '../game/constants';
import { sounds } from '../game/sound';
import jubairBgUrl from '../assets/jubair-bg.png';

interface GameCanvasProps {
  level: number;
  playerStats: PlayerStats;
  settings: GameSettings;
  activeWeapon: Weapon;
  unlockedWeapons: Weapon[];
  medkitCount: number;
  onUseMedkit: () => void;
  onSelectWeapon: (id: WeaponType) => void;
  onLevelComplete: (stats: { stars: number; coins: number; xp: number; score: number; kills: number }) => void;
  onGameOver: (stats: { score: number; kills: number }) => void;
  onPause: () => void;
  isPaused: boolean;
  // External touch controls injection
  touchMoveVector: { x: number; y: number };
  touchAimAngle: number | null;
  isTouchShooting: boolean;
  touchReloadTrigger: number;
  touchJumpTrigger: number;
  // State reporting for HUD
  onUpdateHUD: (data: {
    hp: number;
    maxHp: number;
    shield: number;
    maxShield: number;
    zombiesRemaining: number;
    totalZombies: number;
    bossZombie: Zombie | null;
    coinsEarned: number;
    score: number;
    comboCount: number;
    isReloading: boolean;
    playerPos: { x: number; y: number };
    zombies: Zombie[];
    pickups: ItemPickup[];
    worldSize: { width: number; height: number };
    jumpCooldown: number;
    canJump: boolean;
  }) => void;
}

export const GameCanvas: React.FC<GameCanvasProps> = ({
  level,
  playerStats,
  settings,
  activeWeapon,
  unlockedWeapons,
  medkitCount,
  onUseMedkit,
  onSelectWeapon,
  onLevelComplete,
  onGameOver,
  onPause,
  isPaused,
  touchMoveVector,
  touchAimAngle,
  isTouchShooting,
  touchReloadTrigger,
  touchJumpTrigger,
  onUpdateHUD
}) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const backgroundImageRef = useRef<HTMLImageElement | null>(null);

  useEffect(() => {
    const img = new Image();
    img.src = jubairBgUrl;
    img.onload = () => {
      backgroundImageRef.current = img;
    };
  }, []);

  // Level configuration
  const levelDetails = getLevelDetails(level);
  const mapTheme = getMapThemeForLevel(level);

  // World dimensions
  const WORLD_WIDTH = 2200;
  const WORLD_HEIGHT = 1800;

  // Mutable Game State in Ref for 60FPS loop without stale closures
  const stateRef = useRef({
    player: {
      x: WORLD_WIDTH / 2,
      y: WORLD_HEIGHT / 2,
      vx: 0,
      vy: 0,
      angle: 0,
      radius: 20,
      hp: 100 + (playerStats.perks.maxHealthLevel - 1) * 25,
      maxHp: 100 + (playerStats.perks.maxHealthLevel - 1) * 25,
      shield: 50,
      maxShield: 50,
      speed: 240 + (playerStats.perks.speedLevel - 1) * 20,
      isDashing: false,
      dashTimer: 0,
      dashCooldown: 0,
      isInvulnerable: false
    },
    weapon: { ...activeWeapon },
    keys: { w: false, a: false, s: false, d: false, space: false, r: false },
    mouse: { x: 0, y: 0, isDown: false, worldX: 0, worldY: 0 },
    camera: { x: WORLD_WIDTH / 2, y: WORLD_HEIGHT / 2, shake: 0 },
    zombies: [] as Zombie[],
    bullets: [] as Bullet[],
    particles: [] as Particle[],
    floatingTexts: [] as FloatingText[],
    pickups: [] as ItemPickup[],
    obstacles: [] as Obstacle[],
    shockwaves: [] as Array<{ x: number; y: number; radius: number; maxRadius: number; color: string; alpha: number; damage: number }>,
    // Match progress
    zombiesSpawned: 0,
    totalToSpawn: levelDetails.totalZombies,
    zombiesRemaining: levelDetails.totalZombies,
    coinsEarned: 0,
    xpEarned: 0,
    score: 0,
    comboCount: 0,
    comboTimer: 0,
    kills: 0,
    isReloading: false,
    reloadProgress: 0,
    shootCooldown: 0,
    hasEnded: false,
    doubleDamageTimer: 0,
    lastFrameTime: performance.now()
  });

  // Sync active weapon changes into stateRef
  useEffect(() => {
    stateRef.current.weapon = { ...activeWeapon };
    stateRef.current.isReloading = false;
    stateRef.current.reloadProgress = 0;
  }, [activeWeapon]);

  // Handle Touch Reload & Jump Triggers
  useEffect(() => {
    if (touchReloadTrigger > 0) {
      triggerReload();
    }
  }, [touchReloadTrigger]);

  useEffect(() => {
    if (touchJumpTrigger > 0) {
      triggerDodge();
    }
  }, [touchJumpTrigger]);

  const triggerReload = () => {
    const s = stateRef.current;
    if (s.isReloading || s.weapon.currentAmmo >= s.weapon.magSize) return;
    if (s.weapon.reserveAmmo <= 0) return;
    s.isReloading = true;
    s.reloadProgress = 0;
    sounds.playReload();
  };

  const triggerDodge = () => {
    const s = stateRef.current;
    if (s.player.dashCooldown <= 0 && !s.player.isDashing) {
      s.player.isDashing = true;
      s.player.dashTimer = 0.25; // 0.25 seconds invulnerable roll
      s.player.dashCooldown = Math.max(0.8, 1.6 - (playerStats.perks.speedLevel - 1) * 0.15);
      sounds.playJump();

      // Create dodge puff particles
      for (let i = 0; i < 8; i++) {
        s.particles.push({
          x: s.player.x,
          y: s.player.y,
          vx: (Math.random() - 0.5) * 80,
          vy: (Math.random() - 0.5) * 80,
          color: '#38bdf8',
          radius: 3 + Math.random() * 3,
          alpha: 0.8,
          life: 0,
          maxLife: 0.3
        });
      }
    }
  };

  // Build Map Obstacles and Explosive Barrels
  useEffect(() => {
    const s = stateRef.current;
    const obstacles: Obstacle[] = [];

    // Outer boundary walls
    const wallThickness = 60;
    obstacles.push({ x: 0, y: 0, width: WORLD_WIDTH, height: wallThickness, type: 'barrier' });
    obstacles.push({ x: 0, y: WORLD_HEIGHT - wallThickness, width: WORLD_WIDTH, height: wallThickness, type: 'barrier' });
    obstacles.push({ x: 0, y: 0, width: wallThickness, height: WORLD_HEIGHT, type: 'barrier' });
    obstacles.push({ x: WORLD_WIDTH - wallThickness, y: 0, width: wallThickness, height: WORLD_HEIGHT, type: 'barrier' });

    // Scatter themed obstacles and explosive red barrels
    const numObstacles = 18;
    for (let i = 0; i < numObstacles; i++) {
      const ox = 200 + Math.random() * (WORLD_WIDTH - 400);
      const oy = 200 + Math.random() * (WORLD_HEIGHT - 400);
      // Ensure not on top of player spawn
      if (Math.hypot(ox - WORLD_WIDTH / 2, oy - WORLD_HEIGHT / 2) > 220) {
        const isExplosive = i % 3 === 0;
        obstacles.push({
          x: ox,
          y: oy,
          width: isExplosive ? 36 : 48 + Math.random() * 30,
          height: isExplosive ? 36 : 48 + Math.random() * 30,
          type: isExplosive ? 'barrel' : 'crate',
          health: isExplosive ? 40 : 150,
          isExplosive
        });
      }
    }
    s.obstacles = obstacles;

    // Boss spawn if boss level
    if (levelDetails.isBoss) {
      spawnBoss(s);
    }
  }, [level]);

  // Spawn Boss helper
  const spawnBoss = (s: typeof stateRef.current) => {
    const bossType: ZombieType = 'boss';
    const angle = Math.random() * Math.PI * 2;
    const dist = 550;
    const bx = WORLD_WIDTH / 2 + Math.cos(angle) * dist;
    const by = WORLD_HEIGHT / 2 + Math.sin(angle) * dist;
    const baseHp = 1800 + level * 120;

    s.zombies.push({
      id: `boss-${level}`,
      type: bossType,
      x: bx,
      y: by,
      hp: baseHp,
      maxHp: baseHp,
      speed: 130 * levelDetails.speedMultiplier,
      damage: 32 * levelDetails.damageMultiplier,
      radius: 46,
      color: '#f43f5e',
      accentColor: '#fbbf24',
      attackCooldown: 0,
      attackRange: 60,
      isBoss: true,
      bossTitle: levelDetails.bossName || `OMEGA TITAN (LVL ${level})`,
      specialCooldown: 3.5,
      stateTimer: 0,
      phase: 1,
      angle: 0,
      animFrame: 0
    });

    s.totalToSpawn = 1 + levelDetails.totalZombies;
    s.zombiesRemaining = s.totalToSpawn;
    sounds.playBossRoar();
  };

  // Keyboard and Mouse Event Handlers
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (isPaused) {
        if (e.key === 'Escape') onPause();
        return;
      }
      const k = e.key.toLowerCase();
      if (k === 'w' || k === 'arrowup') stateRef.current.keys.w = true;
      if (k === 'a' || k === 'arrowleft') stateRef.current.keys.a = true;
      if (k === 's' || k === 'arrowdown') stateRef.current.keys.s = true;
      if (k === 'd' || k === 'arrowright') stateRef.current.keys.d = true;
      if (k === 'r') triggerReload();
      if (e.code === 'Space') {
        e.preventDefault();
        triggerDodge();
      }
      if (e.key === 'Escape') onPause();

      // Number keys 1-6 for weapon switch
      const num = parseInt(k, 10);
      if (!isNaN(num) && num >= 1 && num <= unlockedWeapons.length) {
        onSelectWeapon(unlockedWeapons[num - 1].id);
      }
    };

    const handleKeyUp = (e: KeyboardEvent) => {
      const k = e.key.toLowerCase();
      if (k === 'w' || k === 'arrowup') stateRef.current.keys.w = false;
      if (k === 'a' || k === 'arrowleft') stateRef.current.keys.a = false;
      if (k === 's' || k === 'arrowdown') stateRef.current.keys.s = false;
      if (k === 'd' || k === 'arrowright') stateRef.current.keys.d = false;
    };

    const handleMouseDown = (e: MouseEvent) => {
      if (e.button === 0) {
        stateRef.current.mouse.isDown = true;
      }
    };

    const handleMouseUp = (e: MouseEvent) => {
      if (e.button === 0) {
        stateRef.current.mouse.isDown = false;
      }
    };

    const handleMouseMove = (e: MouseEvent) => {
      if (!canvasRef.current) return;
      const rect = canvasRef.current.getBoundingClientRect();
      stateRef.current.mouse.x = e.clientX - rect.left;
      stateRef.current.mouse.y = e.clientY - rect.top;
    };

    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);
    window.addEventListener('mousedown', handleMouseDown);
    window.addEventListener('mouseup', handleMouseUp);
    window.addEventListener('mousemove', handleMouseMove);

    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
      window.removeEventListener('mousedown', handleMouseDown);
      window.removeEventListener('mouseup', handleMouseUp);
      window.removeEventListener('mousemove', handleMouseMove);
    };
  }, [isPaused, onPause, onSelectWeapon, unlockedWeapons]);

  // Main 60FPS Game Loop
  useEffect(() => {
    let animationFrameId: number;

    const gameLoop = (currentTime: number) => {
      const s = stateRef.current;
      const dt = Math.min(0.05, (currentTime - s.lastFrameTime) / 1000);
      s.lastFrameTime = currentTime;

      const canvas = canvasRef.current;
      if (canvas && !isPaused && !s.hasEnded) {
        updateGame(dt);
        renderGame(canvas);
      }

      animationFrameId = requestAnimationFrame(gameLoop);
    };

    animationFrameId = requestAnimationFrame(gameLoop);
    return () => cancelAnimationFrame(animationFrameId);
  }, [isPaused, level, settings]);

  // Game Logic Tick
  const updateGame = (dt: number) => {
    const s = stateRef.current;
    const player = s.player;

    // 1. Move Player
    let moveX = 0;
    let moveY = 0;

    if (s.keys.w) moveY -= 1;
    if (s.keys.s) moveY += 1;
    if (s.keys.a) moveX -= 1;
    if (s.keys.d) moveX += 1;

    // Combine with virtual joystick
    if (touchMoveVector.x !== 0 || touchMoveVector.y !== 0) {
      moveX = touchMoveVector.x;
      moveY = touchMoveVector.y;
    }

    const moveLen = Math.hypot(moveX, moveY);
    if (moveLen > 0) {
      moveX /= moveLen;
      moveY /= moveLen;
    }

    const currentSpeed = player.isDashing ? player.speed * 2.2 : player.speed;
    const nextPx = player.x + moveX * currentSpeed * dt;
    const nextPy = player.y + moveY * currentSpeed * dt;

    // Obstacle collision check for player
    let canMoveX = true;
    let canMoveY = true;
    for (const obs of s.obstacles) {
      if (checkCircleRectCollide(nextPx, player.y, player.radius, obs)) canMoveX = false;
      if (checkCircleRectCollide(player.x, nextPy, player.radius, obs)) canMoveY = false;
    }

    if (canMoveX) player.x = Math.max(player.radius + 60, Math.min(WORLD_WIDTH - player.radius - 60, nextPx));
    if (canMoveY) player.y = Math.max(player.radius + 60, Math.min(WORLD_HEIGHT - player.radius - 60, nextPy));

    // Dash / Dodge timers
    if (player.dashCooldown > 0) player.dashCooldown -= dt;
    if (player.isDashing) {
      player.dashTimer -= dt;
      if (player.dashTimer <= 0) player.isDashing = false;
    }

    // 2. Player Aiming Direction
    if (canvasRef.current) {
      const screenW = canvasRef.current.width;
      const screenH = canvasRef.current.height;
      s.mouse.worldX = s.camera.x + (s.mouse.x - screenW / 2);
      s.mouse.worldY = s.camera.y + (s.mouse.y - screenH / 2);

      let targetAngle = Math.atan2(s.mouse.worldY - player.y, s.mouse.worldX - player.x);

      // Aim assist or touch aim
      if (touchAimAngle !== null) {
        targetAngle = touchAimAngle;
      } else if (settings.aimAssist && s.zombies.length > 0) {
        let closestDist = 450;
        let closestZombie: Zombie | null = null;
        for (const z of s.zombies) {
          const d = Math.hypot(z.x - player.x, z.y - player.y);
          if (d < closestDist) {
            closestDist = d;
            closestZombie = z;
          }
        }
        if (closestZombie) {
          const assistAngle = Math.atan2(closestZombie.y - player.y, closestZombie.x - player.x);
          // Soft blend
          targetAngle = assistAngle;
        }
      }

      player.angle = targetAngle;
    }

    // 3. Shooting Logic
    if (s.shootCooldown > 0) s.shootCooldown -= dt;

    if (s.isReloading) {
      s.reloadProgress += dt / s.weapon.reloadTime;
      if (s.reloadProgress >= 1) {
        s.isReloading = false;
        s.reloadProgress = 0;
        const needed = s.weapon.magSize - s.weapon.currentAmmo;
        const toLoad = Math.min(needed, s.weapon.reserveAmmo);
        s.weapon.currentAmmo += toLoad;
        if (s.weapon.reserveAmmo < 900) s.weapon.reserveAmmo -= toLoad;
      }
    }

    const wantsToShoot = (s.mouse.isDown || isTouchShooting) && !player.isDashing;
    if (wantsToShoot && s.shootCooldown <= 0) {
      if (s.weapon.currentAmmo > 0 && !s.isReloading) {
        fireWeapon(s);
      } else if (!s.isReloading) {
        triggerReload();
      }
    }

    // 4. Update Bullets
    for (let i = s.bullets.length - 1; i >= 0; i--) {
      const b = s.bullets[i];
      b.x += b.vx * dt;
      b.y += b.vy * dt;
      b.rangeLeft -= Math.hypot(b.vx, b.vy) * dt;

      // Bullet spark trail
      if (settings.graphicsQuality !== 'low' && Math.random() < 0.4) {
        s.particles.push({
          x: b.x,
          y: b.y,
          vx: (Math.random() - 0.5) * 20,
          vy: (Math.random() - 0.5) * 20,
          color: b.color,
          radius: 1.5,
          alpha: 0.6,
          life: 0,
          maxLife: 0.15
        });
      }

      // Check bullet hit obstacles or explosive barrels
      let bulletAbsorbed = false;
      for (const obs of s.obstacles) {
        if (checkPointInRect(b.x, b.y, obs)) {
          bulletAbsorbed = true;
          if (obs.isExplosive && obs.health) {
            obs.health -= b.damage;
            if (obs.health <= 0) {
              detonateExplosiveBarrel(obs, s);
            }
          }
          break;
        }
      }

      if (bulletAbsorbed || b.rangeLeft <= 0) {
        s.bullets.splice(i, 1);
        continue;
      }

      // Bullet hit zombies
      for (let j = s.zombies.length - 1; j >= 0; j--) {
        const z = s.zombies[j];
        const dist = Math.hypot(b.x - z.x, b.y - z.y);
        if (dist <= z.radius + b.radius) {
          // Hit zombie!
          damageZombie(z, b.damage, s, b.x, b.y);
          b.piercing -= 1;

          if (b.isExplosive) {
            createExplosion(b.x, b.y, 110, b.damage * 1.5, s);
          }

          if (b.piercing <= 0) {
            s.bullets.splice(i, 1);
            break;
          }
        }
      }
    }

    // 5. Spawn Zombie Waves
    if (s.zombiesSpawned < s.totalToSpawn && s.zombies.length < 22) {
      if (Math.random() < 0.04) {
        spawnZombie(s);
      }
    }

    // 6. Update Zombies
    for (let i = s.zombies.length - 1; i >= 0; i--) {
      const z = s.zombies[i];
      z.animFrame += dt * 6;

      // Distance and angle to player
      const dx = player.x - z.x;
      const dy = player.y - z.y;
      const dist = Math.hypot(dx, dy);
      z.angle = Math.atan2(dy, dx);

      // Boss Special Abilities
      if (z.isBoss && z.specialCooldown !== undefined) {
        z.specialCooldown -= dt;
        if (z.specialCooldown <= 0) {
          z.specialCooldown = 4.0;
          executeBossSpecial(z, s);
        }
      }

      // Zombie movement toward player (simple pathfinding / obstacle push)
      if (dist > z.attackRange * 0.7) {
        const vx = Math.cos(z.angle) * z.speed;
        const vy = Math.sin(z.angle) * z.speed;
        z.x += vx * dt;
        z.y += vy * dt;
      }

      // Zombie attack cooldown
      if (z.attackCooldown > 0) z.attackCooldown -= dt;
      if (dist <= z.attackRange && z.attackCooldown <= 0) {
        z.attackCooldown = 0.9;
        if (!player.isDashing) {
          // Damage player with armor reduction
          const armorMult = Math.max(0.4, 1 - (playerStats.perks.armorLevel - 1) * 0.08);
          const finalDamage = z.damage * armorMult;

          if (player.shield > 0) {
            player.shield -= finalDamage;
            if (player.shield < 0) {
              player.hp += player.shield; // Overflow to HP
              player.shield = 0;
            }
          } else {
            player.hp -= finalDamage;
          }

          sounds.playPlayerHurt();
          s.camera.shake = 12;

          // Check Player Death
          if (player.hp <= 0 && !s.hasEnded) {
            s.hasEnded = true;
            onGameOver({ score: s.score, kills: s.kills });
            return;
          }
        }
      }

      // Check Zombie Death
      if (z.hp <= 0) {
        handleZombieDeath(z, i, s);
      }
    }

    // 7. Update Pickups & Magnet
    const magnetRange = 70 + (playerStats.perks.coinMagnetLevel - 1) * 35;
    for (let i = s.pickups.length - 1; i >= 0; i--) {
      const p = s.pickups[i];
      p.life -= dt;
      const pdx = player.x - p.x;
      const pdy = player.y - p.y;
      const pdist = Math.hypot(pdx, pdy);

      // Magnet pull
      if (pdist < magnetRange) {
        p.x += (pdx / pdist) * 320 * dt;
        p.y += (pdy / pdist) * 320 * dt;
      }

      if (pdist < player.radius + p.radius) {
        // Collect pickup
        if (p.type === 'coin') {
          const coinBoost = 1 + (playerStats.perks.coinMagnetLevel - 1) * 0.25;
          const gained = Math.round(p.value * coinBoost);
          s.coinsEarned += gained;
          sounds.playCoin();
          s.floatingTexts.push({
            id: `ft-${Date.now()}-${Math.random()}`,
            x: player.x,
            y: player.y - 20,
            text: `+${gained} COINS`,
            color: '#fbbf24',
            size: 14,
            alpha: 1,
            life: 0.8
          });
        } else if (p.type === 'health') {
          player.hp = Math.min(player.maxHp, player.hp + p.value);
          sounds.playPowerup();
          s.floatingTexts.push({
            id: `ft-${Date.now()}-${Math.random()}`,
            x: player.x,
            y: player.y - 20,
            text: `+${p.value} HP`,
            color: '#10b981',
            size: 14,
            alpha: 1,
            life: 0.8
          });
        } else if (p.type === 'shield') {
          player.shield = Math.min(player.maxShield, player.shield + p.value);
          sounds.playPowerup();
        } else if (p.type === 'ammo') {
          s.weapon.reserveAmmo += p.value;
          sounds.playPowerup();
        }

        s.pickups.splice(i, 1);
        continue;
      }

      if (p.life <= 0) {
        s.pickups.splice(i, 1);
      }
    }

    // 8. Update Shockwaves
    for (let i = s.shockwaves.length - 1; i >= 0; i--) {
      const sw = s.shockwaves[i];
      sw.radius += 400 * dt;
      sw.alpha -= dt * 1.6;
      if (sw.radius >= sw.maxRadius || sw.alpha <= 0) {
        s.shockwaves.splice(i, 1);
      }
    }

    // 9. Update Floating Texts & Particles
    for (let i = s.floatingTexts.length - 1; i >= 0; i--) {
      const ft = s.floatingTexts[i];
      ft.y -= 35 * dt;
      ft.life -= dt;
      ft.alpha = Math.max(0, ft.life);
      if (ft.life <= 0) s.floatingTexts.splice(i, 1);
    }

    for (let i = s.particles.length - 1; i >= 0; i--) {
      const pt = s.particles[i];
      pt.x += pt.vx * dt;
      pt.y += pt.vy * dt;
      pt.life += dt;
      pt.alpha = 1 - (pt.life / pt.maxLife);
      if (pt.life >= pt.maxLife) s.particles.splice(i, 1);
    }

    // 10. Combo decay
    if (s.comboCount > 0) {
      s.comboTimer -= dt;
      if (s.comboTimer <= 0) {
        s.comboCount = 0;
      }
    }

    // 11. Camera Smooth Lerp & Screen Shake
    if (s.camera.shake > 0) s.camera.shake = Math.max(0, s.camera.shake - dt * 25);
    const shakeX = (Math.random() - 0.5) * s.camera.shake;
    const shakeY = (Math.random() - 0.5) * s.camera.shake;

    s.camera.x += (player.x - s.camera.x) * 0.1 + shakeX;
    s.camera.y += (player.y - s.camera.y) * 0.1 + shakeY;

    // Check Victory
    if (s.zombiesSpawned >= s.totalToSpawn && s.zombies.length === 0 && !s.hasEnded) {
      s.hasEnded = true;
      const hpRatio = player.hp / player.maxHp;
      const stars = hpRatio > 0.75 ? 3 : hpRatio > 0.35 ? 2 : 1;
      const finalCoins = s.coinsEarned + levelDetails.rewardCoins;
      const finalXp = s.xpEarned + levelDetails.rewardXp;
      sounds.playVictory();
      onLevelComplete({
        stars,
        coins: finalCoins,
        xp: finalXp,
        score: s.score + 500 * stars,
        kills: s.kills
      });
    }

    // Report state to HUD
    const boss = s.zombies.find(z => z.isBoss) || null;
    onUpdateHUD({
      hp: player.hp,
      maxHp: player.maxHp,
      shield: player.shield,
      maxShield: player.maxShield,
      zombiesRemaining: s.zombiesRemaining,
      totalZombies: s.totalToSpawn,
      bossZombie: boss,
      coinsEarned: s.coinsEarned,
      score: s.score,
      comboCount: s.comboCount,
      isReloading: s.isReloading,
      playerPos: { x: player.x, y: player.y },
      zombies: s.zombies,
      pickups: s.pickups,
      worldSize: { width: WORLD_WIDTH, height: WORLD_HEIGHT },
      jumpCooldown: player.dashCooldown,
      canJump: player.dashCooldown <= 0 && !player.isDashing
    });
  };

  // Fire Active Weapon
  const fireWeapon = (s: typeof stateRef.current) => {
    const player = s.player;
    const w = s.weapon;
    w.currentAmmo -= 1;
    s.shootCooldown = 1 / w.fireRate;
    sounds.playShoot(w.id);

    // Muzzle flash recoil & particles
    s.camera.shake = Math.min(8, w.damage * 0.12);
    for (let p = 0; p < w.pellets; p++) {
      const spreadAngle = (Math.random() - 0.5) * w.spread;
      const finalAngle = player.angle + spreadAngle;
      const vx = Math.cos(finalAngle) * w.bulletSpeed;
      const vy = Math.sin(finalAngle) * w.bulletSpeed;

      // Barrel tip position
      const barrelDist = player.radius + 14;
      const bx = player.x + Math.cos(player.angle) * barrelDist;
      const by = player.y + Math.sin(player.angle) * barrelDist;

      // Check critical hit
      const critChance = (playerStats.perks.critChanceLevel - 1) * 0.1;
      const isCrit = Math.random() < critChance;
      const finalDamage = isCrit ? w.damage * 2.5 : w.damage;

      s.bullets.push({
        id: `b-${Date.now()}-${p}-${Math.random()}`,
        x: bx,
        y: by,
        vx,
        vy,
        damage: finalDamage,
        rangeLeft: w.range,
        color: isCrit ? '#facc15' : w.color,
        isPlayerBullet: true,
        piercing: w.id === 'sniper' ? 3 : 1,
        radius: w.id === 'special' ? 10 : 3.5,
        isExplosive: w.id === 'special'
      });
    }

    // Eject shell casing particle
    s.particles.push({
      x: player.x,
      y: player.y,
      vx: Math.cos(player.angle - Math.PI / 2) * 90 + (Math.random() - 0.5) * 20,
      vy: Math.sin(player.angle - Math.PI / 2) * 90 + (Math.random() - 0.5) * 20,
      color: '#fbbf24',
      radius: 2,
      alpha: 1,
      life: 0,
      maxLife: 0.4
    });
  };

  // Spawn Regular Zombies
  const spawnZombie = (s: typeof stateRef.current) => {
    s.zombiesSpawned++;
    const types: ZombieType[] = ['normal', 'fast', 'strong', 'armored', 'mutant'];
    // Weighted selection by level
    let chosenType: ZombieType = 'normal';
    const roll = Math.random();
    if (level > 20 && roll > 0.75) chosenType = 'mutant';
    else if (level > 15 && roll > 0.55) chosenType = 'armored';
    else if (level > 8 && roll > 0.35) chosenType = 'strong';
    else if (roll > 0.2) chosenType = 'fast';

    // Spawn along perimeter
    const angle = Math.random() * Math.PI * 2;
    const spawnDist = 650 + Math.random() * 200;
    const zx = Math.max(80, Math.min(WORLD_WIDTH - 80, s.player.x + Math.cos(angle) * spawnDist));
    const zy = Math.max(80, Math.min(WORLD_HEIGHT - 80, s.player.y + Math.sin(angle) * spawnDist));

    const hpBase = (chosenType === 'strong' ? 160 : chosenType === 'armored' ? 220 : chosenType === 'fast' ? 45 : 80) * levelDetails.hpMultiplier;
    const speedBase = (chosenType === 'fast' ? 210 : chosenType === 'strong' ? 95 : 130) * levelDetails.speedMultiplier;
    const damageBase = (chosenType === 'strong' ? 24 : 12) * levelDetails.damageMultiplier;

    s.zombies.push({
      id: `z-${Date.now()}-${Math.random()}`,
      type: chosenType,
      x: zx,
      y: zy,
      hp: hpBase,
      maxHp: hpBase,
      speed: speedBase,
      damage: damageBase,
      radius: chosenType === 'strong' ? 26 : chosenType === 'armored' ? 24 : 19,
      color: chosenType === 'fast' ? '#ef4444' : chosenType === 'strong' ? '#8b5cf6' : chosenType === 'armored' ? '#3b82f6' : chosenType === 'mutant' ? '#84cc16' : '#10b981',
      accentColor: '#fbbf24',
      attackCooldown: 0,
      attackRange: chosenType === 'strong' ? 38 : 30,
      angle: 0,
      animFrame: Math.random() * 10
    });
  };

  // Damage Zombie
  const damageZombie = (z: Zombie, amount: number, s: typeof stateRef.current, hitX: number, hitY: number) => {
    let finalDmg = amount;
    if (z.type === 'armored') {
      finalDmg *= 0.65; // Armor absorption
    }
    z.hp -= finalDmg;
    sounds.playZombieHit();

    // Floating damage numbers
    s.floatingTexts.push({
      id: `dmg-${Date.now()}-${Math.random()}`,
      x: hitX + (Math.random() - 0.5) * 16,
      y: hitY - 10,
      text: `${Math.round(finalDmg)}`,
      color: finalDmg > 60 ? '#f59e0b' : '#ffffff',
      size: finalDmg > 60 ? 15 : 12,
      alpha: 1,
      life: 0.55
    });

    // Bloodless action spark particles
    for (let p = 0; p < 4; p++) {
      s.particles.push({
        x: hitX,
        y: hitY,
        vx: (Math.random() - 0.5) * 120,
        vy: (Math.random() - 0.5) * 120,
        color: z.color,
        radius: 2.5,
        alpha: 0.9,
        life: 0,
        maxLife: 0.25
      });
    }
  };

  // Handle Zombie Defeat
  const handleZombieDeath = (z: Zombie, index: number, s: typeof stateRef.current) => {
    s.zombies.splice(index, 1);
    s.zombiesRemaining--;
    s.kills++;
    s.score += z.isBoss ? 2500 : 100;
    s.comboCount++;
    s.comboTimer = 2.4;
    sounds.playZombieDefeat();

    // Spawn Coin Drop
    const coinVal = z.isBoss ? 300 : 15 + Math.floor(Math.random() * 20);
    s.pickups.push({
      id: `coin-${Date.now()}-${Math.random()}`,
      type: 'coin',
      x: z.x,
      y: z.y,
      value: coinVal,
      radius: 10,
      life: 25,
      icon: 'coin',
      color: '#fbbf24'
    });

    // Chance for Health or Ammo pack
    if (Math.random() < 0.25 || z.isBoss) {
      s.pickups.push({
        id: `med-${Date.now()}-${Math.random()}`,
        type: Math.random() < 0.5 ? 'health' : 'ammo',
        x: z.x + (Math.random() - 0.5) * 30,
        y: z.y + (Math.random() - 0.5) * 30,
        value: 35,
        radius: 12,
        life: 25,
        icon: 'item',
        color: '#10b981'
      });
    }

    // Defeat burst explosion particles
    for (let p = 0; p < 12; p++) {
      s.particles.push({
        x: z.x,
        y: z.y,
        vx: (Math.random() - 0.5) * 180,
        vy: (Math.random() - 0.5) * 180,
        color: z.color,
        radius: 3 + Math.random() * 3,
        alpha: 1,
        life: 0,
        maxLife: 0.4
      });
    }
  };

  // Boss Special Move Execution
  const executeBossSpecial = (boss: Zombie, s: typeof stateRef.current) => {
    sounds.playBossRoar();
    s.camera.shake = 18;

    // Ground Stomp Shockwave
    s.shockwaves.push({
      x: boss.x,
      y: boss.y,
      radius: 30,
      maxRadius: 280,
      color: '#f43f5e',
      alpha: 1.0,
      damage: 25
    });

    // Check shockwave hit player
    const dist = Math.hypot(s.player.x - boss.x, s.player.y - boss.y);
    if (dist < 280 && !s.player.isDashing) {
      s.player.hp -= 18;
      sounds.playPlayerHurt();
    }
  };

  // Detonate Red Explosive Barrel
  const detonateExplosiveBarrel = (obs: Obstacle, s: typeof stateRef.current) => {
    obs.health = 0;
    const bx = obs.x + obs.width / 2;
    const by = obs.y + obs.height / 2;
    createExplosion(bx, by, 220, 140, s);
    // Remove barrel
    const idx = s.obstacles.indexOf(obs);
    if (idx !== -1) s.obstacles.splice(idx, 1);
  };

  // Create AOE Explosion
  const createExplosion = (x: number, y: number, radius: number, damage: number, s: typeof stateRef.current) => {
    sounds.playExplosion();
    s.camera.shake = 22;

    s.shockwaves.push({
      x,
      y,
      radius: 20,
      maxRadius: radius,
      color: '#f97316',
      alpha: 1,
      damage
    });

    // Damage all zombies in blast radius
    for (const z of s.zombies) {
      const d = Math.hypot(z.x - x, z.y - y);
      if (d <= radius) {
        damageZombie(z, damage, s, z.x, z.y);
      }
    }

    // Damage player if close and not dodging
    const pd = Math.hypot(s.player.x - x, s.player.y - y);
    if (pd <= radius && !s.player.isDashing) {
      s.player.hp -= damage * 0.4;
      sounds.playPlayerHurt();
    }

    // Explosion fireball particles
    for (let i = 0; i < 20; i++) {
      s.particles.push({
        x,
        y,
        vx: (Math.random() - 0.5) * 260,
        vy: (Math.random() - 0.5) * 260,
        color: i % 2 === 0 ? '#ea580c' : '#facc15',
        radius: 4 + Math.random() * 5,
        alpha: 1,
        life: 0,
        maxLife: 0.5
      });
    }
  };

  // 2D Canvas Renderer
  const renderGame = (canvas: HTMLCanvasElement) => {
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    const s = stateRef.current;
    const player = s.player;

    const w = canvas.width;
    const h = canvas.height;

    ctx.save();
    ctx.clearRect(0, 0, w, h);

    // Apply Camera Translation
    ctx.translate(w / 2 - s.camera.x, h / 2 - s.camera.y);

    // 1. Draw Jubair's Photo as the game background
    const bg = backgroundImageRef.current;
    if (bg) {
      const scale = Math.max(WORLD_WIDTH / bg.width, WORLD_HEIGHT / bg.height);
      const drawW = bg.width * scale;
      const drawH = bg.height * scale;
      const drawX = (WORLD_WIDTH - drawW) / 2;
      const drawY = (WORLD_HEIGHT - drawH) / 2;
      ctx.save();
      ctx.globalAlpha = 0.55;
      ctx.drawImage(bg, drawX, drawY, drawW, drawH);
      ctx.restore();
    }

    // Dark map tint keeps zombies, player and HUD effects readable over the photo
    ctx.save();
    ctx.fillStyle = mapTheme.groundColor;
    ctx.globalAlpha = 0.58;
    ctx.fillRect(0, 0, WORLD_WIDTH, WORLD_HEIGHT);
    ctx.restore();

    // Subtle grid pattern
    ctx.strokeStyle = mapTheme.gridColor;
    ctx.lineWidth = 1;
    const gridSize = 100;
    for (let gx = 0; gx < WORLD_WIDTH; gx += gridSize) {
      ctx.beginPath();
      ctx.moveTo(gx, 0);
      ctx.lineTo(gx, WORLD_HEIGHT);
      ctx.stroke();
    }
    for (let gy = 0; gy < WORLD_HEIGHT; gy += gridSize) {
      ctx.beginPath();
      ctx.moveTo(0, gy);
      ctx.lineTo(WORLD_WIDTH, gy);
      ctx.stroke();
    }

    // 2. Draw Obstacles & Barrels
    for (const obs of s.obstacles) {
      if (obs.type === 'barrel') {
        // Red Explosive Barrel
        ctx.fillStyle = '#dc2626';
        ctx.strokeStyle = '#fca5a5';
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.roundRect(obs.x, obs.y, obs.width, obs.height, 8);
        ctx.fill();
        ctx.stroke();

        // Barrel warning decal
        ctx.fillStyle = '#fef08a';
        ctx.font = 'bold 10px sans-serif';
        ctx.textAlign = 'center';
        ctx.fillText('TNT', obs.x + obs.width / 2, obs.y + obs.height / 2 + 3);
      } else {
        // Crate / Barrier
        ctx.fillStyle = mapTheme.obstacleColor;
        ctx.strokeStyle = '#1e293b';
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.roundRect(obs.x, obs.y, obs.width, obs.height, 6);
        ctx.fill();
        ctx.stroke();
      }
    }

    // 3. Draw Shockwaves
    for (const sw of s.shockwaves) {
      ctx.save();
      ctx.strokeStyle = sw.color;
      ctx.lineWidth = 4;
      ctx.globalAlpha = sw.alpha;
      ctx.beginPath();
      ctx.arc(sw.x, sw.y, sw.radius, 0, Math.PI * 2);
      ctx.stroke();
      ctx.restore();
    }

    // 4. Draw Item Pickups
    for (const p of s.pickups) {
      ctx.save();
      ctx.fillStyle = p.color;
      ctx.shadowColor = p.color;
      ctx.shadowBlur = 8;
      ctx.beginPath();
      ctx.arc(p.x, p.y, p.radius, 0, Math.PI * 2);
      ctx.fill();

      // Icon label inside pickup
      ctx.fillStyle = '#ffffff';
      ctx.font = 'bold 9px sans-serif';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText(p.type === 'coin' ? '★' : p.type === 'health' ? '+' : '♦', p.x, p.y);
      ctx.restore();
    }

    // 5. Draw Zombies
    for (const z of s.zombies) {
      ctx.save();
      ctx.translate(z.x, z.y);
      ctx.rotate(z.angle);

      // Zombie Body Shadow
      ctx.fillStyle = 'rgba(0,0,0,0.25)';
      ctx.beginPath();
      ctx.ellipse(0, 4, z.radius, z.radius * 0.7, 0, 0, Math.PI * 2);
      ctx.fill();

      // Main Torso
      ctx.fillStyle = z.color;
      ctx.strokeStyle = '#0f172a';
      ctx.lineWidth = z.isBoss ? 3 : 2;
      ctx.beginPath();
      ctx.arc(0, 0, z.radius, 0, Math.PI * 2);
      ctx.fill();
      ctx.stroke();

      // Zombie Hands / Claws (animated walk cycle)
      const handOffset = Math.sin(z.animFrame) * 4;
      ctx.fillStyle = z.color;
      // Left hand
      ctx.beginPath();
      ctx.arc(z.radius * 0.8, -z.radius * 0.5 + handOffset, 5, 0, Math.PI * 2);
      ctx.fill();
      ctx.stroke();
      // Right hand
      ctx.beginPath();
      ctx.arc(z.radius * 0.8, z.radius * 0.5 - handOffset, 5, 0, Math.PI * 2);
      ctx.fill();
      ctx.stroke();

      // Glowing stylized eyes (No horror, sharp comic gaze)
      ctx.fillStyle = '#fef08a';
      ctx.beginPath();
      ctx.arc(z.radius * 0.4, -z.radius * 0.3, 3, 0, Math.PI * 2);
      ctx.arc(z.radius * 0.4, z.radius * 0.3, 3, 0, Math.PI * 2);
      ctx.fill();

      ctx.restore();

      // Zombie Overhead Health Bar
      const barW = z.radius * 2;
      const barH = 4;
      const hpPct = Math.max(0, z.hp / z.maxHp);
      ctx.fillStyle = 'rgba(15, 23, 42, 0.75)';
      ctx.fillRect(z.x - barW / 2, z.y - z.radius - 12, barW, barH);
      ctx.fillStyle = z.isBoss ? '#f43f5e' : '#10b981';
      ctx.fillRect(z.x - barW / 2, z.y - z.radius - 12, barW * hpPct, barH);
    }

    // 6. Draw Player Hunter "Jubair"
    ctx.save();
    ctx.translate(player.x, player.y);
    ctx.rotate(player.angle);

    // Aim Laser Sight
    ctx.strokeStyle = 'rgba(239, 68, 68, 0.45)';
    ctx.lineWidth = 1.5;
    ctx.setLineDash([4, 4]);
    ctx.beginPath();
    ctx.moveTo(player.radius + 10, 0);
    ctx.lineTo(player.radius + 350, 0);
    ctx.stroke();
    ctx.setLineDash([]);

    // Player Shadow
    ctx.fillStyle = 'rgba(0,0,0,0.3)';
    ctx.beginPath();
    ctx.ellipse(0, 3, player.radius, player.radius * 0.7, 0, 0, Math.PI * 2);
    ctx.fill();

    // Hunter Tactical Vest & Body
    ctx.fillStyle = player.isDashing ? '#38bdf8' : '#0284c7';
    ctx.strokeStyle = '#ffffff';
    ctx.lineWidth = 2.5;
    ctx.beginPath();
    ctx.arc(0, 0, player.radius, 0, Math.PI * 2);
    ctx.fill();
    ctx.stroke();

    // Combat Helmet / Visor
    ctx.fillStyle = '#0f172a';
    ctx.beginPath();
    ctx.arc(0, 0, player.radius * 0.7, 0, Math.PI * 2);
    ctx.fill();

    // Glowing Neon Visor
    ctx.fillStyle = '#38bdf8';
    ctx.beginPath();
    ctx.ellipse(player.radius * 0.35, 0, 4, 8, 0, 0, Math.PI * 2);
    ctx.fill();

    // Equipped Weapon Barrel
    ctx.fillStyle = s.weapon.color;
    ctx.strokeStyle = '#0f172a';
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.roundRect(player.radius * 0.5, -4, 18, 8, 2);
    ctx.fill();
    ctx.stroke();

    ctx.restore();

    // 7. Draw Bullets
    for (const b of s.bullets) {
      ctx.save();
      ctx.fillStyle = b.color;
      ctx.shadowColor = b.color;
      ctx.shadowBlur = 6;
      ctx.beginPath();
      ctx.arc(b.x, b.y, b.radius, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();
    }

    // 8. Draw Particles
    for (const pt of s.particles) {
      ctx.save();
      ctx.fillStyle = pt.color;
      ctx.globalAlpha = Math.max(0, pt.alpha);
      ctx.beginPath();
      ctx.arc(pt.x, pt.y, pt.radius, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();
    }

    // 9. Draw Floating Combat Text
    for (const ft of s.floatingTexts) {
      ctx.save();
      ctx.font = `bold ${ft.size}px 'Teko', sans-serif`;
      ctx.fillStyle = ft.color;
      ctx.globalAlpha = ft.alpha;
      ctx.textAlign = 'center';
      ctx.shadowColor = '#000';
      ctx.shadowBlur = 4;
      ctx.fillText(ft.text, ft.x, ft.y);
      ctx.restore();
    }

    ctx.restore();
  };

  // Helper: circle & rect collision
  const checkCircleRectCollide = (cx: number, cy: number, r: number, rect: Obstacle) => {
    const closestX = Math.max(rect.x, Math.min(cx, rect.x + rect.width));
    const closestY = Math.max(rect.y, Math.min(cy, rect.y + rect.height));
    const distanceX = cx - closestX;
    const distanceY = cy - closestY;
    return (distanceX * distanceX + distanceY * distanceY) < (r * r);
  };

  const checkPointInRect = (px: number, py: number, rect: Obstacle) => {
    return px >= rect.x && px <= rect.x + rect.width && py >= rect.y && py <= rect.y + rect.height;
  };

  // ResizeObserver on canvas container
  useEffect(() => {
    if (!containerRef.current || !canvasRef.current) return;
    const observer = new ResizeObserver(entries => {
      for (const entry of entries) {
        if (canvasRef.current) {
          canvasRef.current.width = entry.contentRect.width;
          canvasRef.current.height = entry.contentRect.height;
        }
      }
    });
    observer.observe(containerRef.current);
    return () => observer.disconnect();
  }, []);

  return (
    <div ref={containerRef} className="relative w-full h-full min-h-screen overflow-hidden bg-black select-none">
      <canvas ref={canvasRef} className="w-full h-full block cursor-crosshair" />
    </div>
  );
};
