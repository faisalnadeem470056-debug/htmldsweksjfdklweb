import React, { useState, useRef, useEffect } from 'react';
import { Send, Mic, MicOff, Plus, AudioLines, X, Camera, ScanText, Monitor } from 'lucide-react';
import { cn } from '../utils/cn';

interface ChatInputProps {
  onSend: (message: string, images?: string[]) => void;
  onLiveChat: () => void;
  onLiveCamera?: () => void;
  onLiveScreenShare?: () => void;
  onScanText?: () => void;
  disabled?: boolean;
}

export function ChatInput({ onSend, onLiveChat, onLiveCamera, onLiveScreenShare, onScanText, disabled }: ChatInputProps) {
  const [input, setInput] = useState('');
  const [images, setImages] = useState<string[]>([]);
  const [isListening, setIsListening] = useState(false);
  const [permissionDenied, setPermissionDenied] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const recognitionRef = useRef<any>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const cameraInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (errorMessage) {
      const timer = setTimeout(() => setErrorMessage(null), 5000);
      return () => clearTimeout(timer);
    }
  }, [errorMessage]);

  useEffect(() => {
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
      textareaRef.current.style.height = `${Math.min(textareaRef.current.scrollHeight, 200)}px`;
    }
  }, [input]);

  const handleSend = () => {
    if ((!input.trim() && images.length === 0) || disabled) return;
    onSend(input, images.length > 0 ? images : undefined);
    setInput('');
    setImages([]);
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  const handleFileSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []);
    if (files.length > 0) {
      const newImages: string[] = [];
      for (const file of files) {
        try {
          const { resizeImage } = await import('../utils/image');
          const resized = await resizeImage(file, 1024);
          newImages.push(resized);
        } catch (err) {
          console.error("Image resize failed", err);
          // fallback to standard read
          const reader = new FileReader();
          await new Promise<void>((resolve) => {
            reader.onloadend = () => {
              newImages.push(reader.result as string);
              resolve();
            };
            reader.readAsDataURL(file);
          });
        }
      }
      setImages(prev => [...prev, ...newImages].slice(0, 20)); // Limit to 20 images
    }
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
    if (cameraInputRef.current) {
      cameraInputRef.current.value = '';
    }
  };

  const removeImage = (index: number) => {
    setImages(prev => prev.filter((_, i) => i !== index));
  };

  const toggleListening = () => {
    if (isListening) {
      recognitionRef.current?.stop();
      setIsListening(false);
      return;
    }

    // Reset states to allow retry
    setPermissionDenied(false);
    setErrorMessage(null);

    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SpeechRecognition) {
      setErrorMessage("Speech recognition is not supported in this browser.");
      return;
    }

    try {
      const recognition = new SpeechRecognition();
      recognition.lang = 'hi-IN'; // Hindi & Indian English / Hinglish
      recognition.interimResults = true;
      recognition.continuous = true;

      recognition.onresult = (event: any) => {
        let finalTranscript = '';
        for (let i = event.resultIndex; i < event.results.length; ++i) {
          if (event.results[i].isFinal) {
            finalTranscript += event.results[i][0].transcript;
          } else {
             // Optional: Handle interim results if needed
          }
        }
        
        // Append only final results to avoid duplication/flicker
        if (finalTranscript) {
          setInput(prev => {
             const newText = prev ? `${prev} ${finalTranscript}` : finalTranscript;
             return newText;
          });
        }
      };

      recognition.onerror = (event: any) => {
        if (event.error === 'not-allowed') {
          console.warn("Speech recognition permission denied.");
          setPermissionDenied(true);
          setErrorMessage("Microphone blocked. Click the 'Lock' icon in your browser address bar to 'Allow' the microphone, then try again.");
          setIsListening(false);
        } else if (event.error === 'no-speech') {
          console.warn("Speech recognition: no speech detected.");
          // Don't stop listening on no-speech, just warn
          return; 
        } else {
          console.error("Speech recognition error", event.error);
          setErrorMessage(`Voice input error: ${event.error}`);
          setIsListening(false);
        }
      };

      recognition.onend = () => {
        setIsListening(false);
      };

      recognitionRef.current = recognition;
      recognition.start();
      setIsListening(true);
    } catch (error) {
      console.error("Failed to start recognition:", error);
      setErrorMessage("Failed to start voice input.");
      setIsListening(false);
    }
  };

  return (
    <div className="w-full max-w-4xl mx-auto p-2 md:p-4">
      {errorMessage && (
        <div className="mb-2 p-2 bg-red-100 dark:bg-red-900/30 text-red-600 dark:text-red-400 text-xs rounded-lg text-center animate-fade-in">
          {errorMessage}
        </div>
      )}
      
      {images.length > 0 && (
        <div className="mb-4 flex flex-wrap gap-3">
          {images.map((img, idx) => (
            <div key={idx} className="relative group">
              <img src={img} alt={`Preview ${idx}`} className="h-20 w-20 object-cover rounded-xl border border-slate-200 dark:border-slate-700 shadow-sm" />
              <button 
                onClick={() => removeImage(idx)}
                className="absolute -top-2 -right-2 p-1 bg-slate-900 text-white rounded-full hover:bg-slate-700 transition-colors shadow-md"
              >
                <X size={12} />
              </button>
            </div>
          ))}
        </div>
      )}

      <div className="flex items-end gap-2 md:gap-3">
        {/* Plus Button */}
        <input 
          type="file" 
          ref={fileInputRef}
          onChange={handleFileSelect}
          accept="image/*"
          multiple
          className="hidden"
        />
        <input 
          type="file" 
          ref={cameraInputRef}
          onChange={handleFileSelect}
          accept="image/*"
          capture="environment"
          className="hidden"
        />
        <div className="flex bg-slate-100 dark:bg-slate-800 rounded-full p-1 shadow-sm flex-shrink-0">
          <button
            onClick={() => fileInputRef.current?.click()}
            className="p-2.5 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 transition-colors rounded-full hover:bg-slate-200 dark:hover:bg-slate-700"
            title="Upload images"
          >
            <Plus size={22} />
          </button>
          <button
            onClick={() => {
              if (onLiveCamera) {
                onLiveCamera();
              } else {
                cameraInputRef.current?.click();
              }
            }}
            className="p-2.5 text-orange-600 dark:text-orange-400 hover:text-orange-700 dark:hover:text-orange-300 transition-colors rounded-full hover:bg-orange-50 dark:hover:bg-orange-950/40 relative"
            title="Live Camera Vision (Gemini Live)"
          >
            <Camera size={22} />
            <span className="absolute top-1 right-1 w-2 h-2 rounded-full bg-green-500 ring-2 ring-white dark:ring-slate-800 animate-pulse" />
          </button>
          {onLiveScreenShare && (
            <button
              onClick={onLiveScreenShare}
              className="p-2.5 text-cyan-600 dark:text-cyan-400 hover:text-cyan-700 dark:hover:text-cyan-300 transition-colors rounded-full hover:bg-cyan-50 dark:hover:bg-cyan-950/40 relative"
              title="Live Screen Share (Dekho aur Poochein)"
            >
              <Monitor size={22} />
              <span className="absolute top-1 right-1 w-2 h-2 rounded-full bg-cyan-500 ring-2 ring-white dark:ring-slate-800 animate-pulse" />
            </button>
          )}
          <button
            onClick={() => {
              if (onScanText) onScanText();
            }}
            className="p-2.5 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 transition-colors rounded-full hover:bg-slate-200 dark:hover:bg-slate-700"
            title="Text Scanner (OCR)"
          >
            <ScanText size={22} />
          </button>
        </div>

        {/* Input Pill */}
        <div className="flex-1 relative flex items-end bg-slate-100 dark:bg-slate-800 rounded-[26px] px-4 py-2 transition-all focus-within:ring-2 focus-within:ring-slate-500/20">
          <textarea
            ref={textareaRef}
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder={images.length > 0 ? "Ask about these images..." : "Ask India GPT"}
            className="flex-1 bg-transparent border-none focus:ring-0 resize-none max-h-[200px] py-3 text-slate-800 dark:text-slate-100 placeholder:text-slate-500 text-lg leading-relaxed"
            rows={1}
            disabled={disabled}
          />
          
          <div className="flex items-center gap-2 pb-2 pl-2 flex-shrink-0">
             {input.trim() || images.length > 0 ? (
                <button
                  onClick={handleSend}
                  disabled={disabled}
                  className="p-2 bg-orange-600 text-white rounded-full hover:bg-orange-700 transition-all shadow-sm"
                >
                  <Send size={20} />
                </button>
             ) : (
                <button
                  onClick={toggleListening}
                  className={cn(
                    "p-2 rounded-full transition-all",
                    isListening 
                      ? "bg-red-100 text-red-600 animate-pulse" 
                      : "text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
                  )}
                  title="Voice Input"
                >
                  {isListening ? <MicOff size={24} /> : <Mic size={24} />}
                </button>
             )}
          </div>
        </div>

        {/* Live Chat Button */}
        <button
          onClick={onLiveChat}
          className="p-3 text-slate-800 dark:text-white hover:bg-slate-200 dark:hover:bg-slate-700 transition-colors rounded-full bg-slate-100 dark:bg-slate-800 flex-shrink-0"
          title="Start Live Chat"
        >
          <AudioLines size={24} />
        </button>
      </div>
      
      <div className="text-center mt-3 text-[10px] text-slate-400 uppercase tracking-widest opacity-50">
        Powered by Advanced Intelligence
      </div>
    </div>
  );
}
