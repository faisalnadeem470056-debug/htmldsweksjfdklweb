import React, { useState } from 'react';
import { X, Check, CreditCard, QrCode, Zap, Crown } from 'lucide-react';

interface PricingModalProps {
  isOpen: boolean;
  onClose: () => void;
  userId: string;
  onSuccess?: () => void;
}

export function PricingModal({ isOpen, onClose, userId, onSuccess }: PricingModalProps) {
  const [loadingPlan, setLoadingPlan] = useState<string | null>(null);
  const [checkoutError, setCheckoutError] = useState<string | null>(null);

  if (!isOpen) return null;

  const loadRazorpay = () => {
    return new Promise((resolve) => {
      const script = document.createElement('script');
      script.src = 'https://checkout.razorpay.com/v1/checkout.js';
      script.onload = () => resolve(true);
      script.onerror = () => resolve(false);
      document.body.appendChild(script);
    });
  };

  const handleSubscribe = async (plan: string) => {
    setLoadingPlan(plan);
    setCheckoutError(null);

    try {
      const res = await loadRazorpay();
      if (!res) {
        setCheckoutError("Razorpay SDK failed to load. Are you online?");
        setLoadingPlan(null);
        return;
      }

      // Step 1: Create Order in Backend
      const orderRes = await fetch('/api/razorpay/create_order', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-user-id': userId
        },
        body: JSON.stringify({ plan })
      });
      
      const orderData = await orderRes.json();
      
      if (!orderRes.ok) {
        setCheckoutError(orderData.error || "Failed to create order");
        setLoadingPlan(null);
        return;
      }

      // Step 2: Open Razorpay Popup
      const options = {
        key: "rzp_test_dummy_key", // Will work in test mode
        amount: orderData.amount,
        currency: orderData.currency || "INR",
        name: "India GPT",
        description: `${plan} Plan Upgrade`,
        order_id: orderData.id,
        handler: async function (response: any) {
           try {
             // Step 3: Verify Payment in Backend
             const verifyRes = await fetch('/api/razorpay/verify', {
                method: 'POST',
                headers: {
                  'Content-Type': 'application/json',
                  'x-user-id': userId
                },
                body: JSON.stringify({
                   razorpay_payment_id: response.razorpay_payment_id,
                   razorpay_order_id: response.razorpay_order_id,
                   razorpay_signature: response.razorpay_signature,
                   plan
                })
             });
             
             if (verifyRes.ok) {
                if (onSuccess) onSuccess();
                onClose();
             } else {
                const errData = await verifyRes.json();
                setCheckoutError(errData.error || "Payment verification failed");
             }
           } catch (err) {
             setCheckoutError("Error verifying payment");
           }
        },
        prefill: {
          name: "",
          email: "",
          contact: ""
        },
        theme: {
          color: "#f97316"
        }
      };

      const paymentObject = new (window as any).Razorpay(options);
      paymentObject.on('payment.failed', function (response: any) {
         setCheckoutError(response.error.description || "Payment failed");
      });
      paymentObject.open();

    } catch (err) {
      setCheckoutError("Network error occurred during checkout.");
    } finally {
      setLoadingPlan(null);
    }
  };

  return (
    <div className="fixed inset-0 z-[200] flex items-center justify-center bg-slate-950/80 backdrop-blur-sm p-4 animate-fade-in overflow-y-auto">
      <div className="relative w-full max-w-5xl bg-white dark:bg-slate-900 rounded-3xl shadow-2xl p-6 md:p-10 border border-slate-200 dark:border-slate-800 my-auto">
        <button 
          onClick={onClose}
          className="absolute top-4 right-4 p-2 bg-slate-100 dark:bg-slate-800 text-slate-500 rounded-full hover:bg-slate-200 dark:hover:bg-slate-700 transition-colors"
        >
          <X size={24} />
        </button>

        <div className="text-center mb-10">
          <h2 className="text-3xl md:text-5xl font-black text-slate-900 dark:text-white mb-4">
            Upgrade to <span className="text-transparent bg-clip-text bg-gradient-to-r from-orange-500 to-rose-500">PRO</span>
          </h2>
          <p className="text-slate-600 dark:text-slate-400 text-lg">Unlock the full power of India GPT</p>
        </div>

        {checkoutError && (
          <div className="mb-8 p-6 bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-2xl text-red-600 dark:text-red-400 text-sm animate-fade-in text-center max-w-2xl mx-auto">
            <p className="font-bold mb-2 text-base">Configuration Required</p>
            <p className="mb-3">{checkoutError}</p>
            <p className="text-xs opacity-80 leading-relaxed bg-red-100 dark:bg-red-900/40 p-3 rounded-xl inline-block text-left">
              <strong>Note on Security:</strong> For your security, real bank selection (HDFC, Bank of Baroda, SBI, etc.) and UPI PIN entry happens securely on the payment gateway's encrypted page, never directly inside this app. To see this flow, you must add a live Payment Gateway key in AI Studio Secrets.
            </p>
          </div>
        )}

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {/* Free Plan */}
          <div className="p-6 rounded-3xl border-2 border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950/50 flex flex-col">
            <h3 className="text-xl font-bold text-slate-900 dark:text-white mb-2">Free</h3>
            <p className="text-3xl font-black text-slate-900 dark:text-white mb-6">₹0<span className="text-sm font-normal text-slate-500">/mo</span></p>
            <ul className="space-y-4 mb-8 flex-1">
              <li className="flex items-center gap-2 text-slate-600 dark:text-slate-300"><Check size={16} className="text-green-500"/> 10 AI Messages / Day</li>
              <li className="flex items-center gap-2 text-slate-600 dark:text-slate-300"><Check size={16} className="text-green-500"/> Basic AI Model</li>
              <li className="flex items-center gap-2 text-slate-600 dark:text-slate-300"><Check size={16} className="text-green-500"/> Standard Speed</li>
            </ul>
            <button disabled className="w-full py-3 rounded-xl bg-slate-200 dark:bg-slate-800 text-slate-500 font-bold">
              Current Plan
            </button>
          </div>

          {/* Pro Plan */}
          <div className="p-6 rounded-3xl border-2 border-orange-500 bg-orange-50 dark:bg-orange-950/20 relative shadow-2xl flex flex-col transform md:-translate-y-4">
            <div className="absolute top-0 left-1/2 -translate-x-1/2 -translate-y-1/2 bg-gradient-to-r from-orange-500 to-rose-500 text-white px-4 py-1 rounded-full text-sm font-bold flex items-center gap-1 shadow-lg">
              <Zap size={14} /> MOST POPULAR
            </div>
            <h3 className="text-xl font-bold text-orange-600 dark:text-orange-400 mb-2">Pro</h3>
            <p className="text-3xl font-black text-slate-900 dark:text-white mb-6">₹499<span className="text-sm font-normal text-slate-500">/mo</span></p>
            <ul className="space-y-4 mb-8 flex-1">
              <li className="flex items-center gap-2 text-slate-900 dark:text-slate-100 font-medium"><Check size={16} className="text-orange-500"/> 100 AI Messages / Day</li>
              <li className="flex items-center gap-2 text-slate-900 dark:text-slate-100 font-medium"><Check size={16} className="text-orange-500"/> Advanced Flash Model</li>
              <li className="flex items-center gap-2 text-slate-900 dark:text-slate-100 font-medium"><Check size={16} className="text-orange-500"/> Full Image & PDF Analysis</li>
              <li className="flex items-center gap-2 text-slate-900 dark:text-slate-100 font-medium"><Check size={16} className="text-orange-500"/> High Speed Priority</li>
            </ul>
            <button 
              onClick={() => handleSubscribe('PRO')}
              disabled={loadingPlan === 'PRO'}
              className="w-full py-3 rounded-xl bg-gradient-to-r from-orange-500 to-rose-500 hover:from-orange-600 hover:to-rose-600 text-white font-bold shadow-lg shadow-orange-500/25 transition-transform hover:scale-105 active:scale-95 flex items-center justify-center gap-2"
            >
              {loadingPlan === 'PRO' ? "Processing..." : "Upgrade to Pro"}
            </button>
            <div className="flex items-center justify-center gap-2 mt-4 text-xs text-slate-500 dark:text-slate-400">
              <CreditCard size={14} /> Credit Card, UPI <QrCode size={14} /> accepted
            </div>
          </div>

          {/* Premium Plan */}
          <div className="p-6 rounded-3xl border-2 border-purple-200 dark:border-purple-900 bg-purple-50 dark:bg-purple-900/10 flex flex-col">
            <h3 className="text-xl font-bold text-purple-600 dark:text-purple-400 mb-2 flex items-center gap-2"><Crown size={20}/> Premium</h3>
            <p className="text-3xl font-black text-slate-900 dark:text-white mb-6">₹999<span className="text-sm font-normal text-slate-500">/mo</span></p>
            <ul className="space-y-4 mb-8 flex-1">
              <li className="flex items-center gap-2 text-slate-900 dark:text-slate-100 font-medium"><Check size={16} className="text-purple-500"/> 1000 AI Messages / Day</li>
              <li className="flex items-center gap-2 text-slate-900 dark:text-slate-100 font-medium"><Check size={16} className="text-purple-500"/> Gemini Pro / Advanced Models</li>
              <li className="flex items-center gap-2 text-slate-900 dark:text-slate-100 font-medium"><Check size={16} className="text-purple-500"/> Complex Reasoning & Coding</li>
              <li className="flex items-center gap-2 text-slate-900 dark:text-slate-100 font-medium"><Check size={16} className="text-purple-500"/> Priority API Access</li>
            </ul>
            <button 
              onClick={() => handleSubscribe('PREMIUM')}
              disabled={loadingPlan === 'PREMIUM'}
              className="w-full py-3 rounded-xl bg-purple-600 hover:bg-purple-700 text-white font-bold shadow-lg shadow-purple-500/25 transition-transform hover:scale-105 active:scale-95"
            >
              {loadingPlan === 'PREMIUM' ? "Processing..." : "Go Premium"}
            </button>
          </div>
        </div>
        
        {/* UPI Instruction Area (Optional for India Context) */}
        <div className="mt-8 pt-8 border-t border-slate-200 dark:border-slate-800 text-center">
          <p className="text-sm text-slate-500 dark:text-slate-400 flex items-center justify-center gap-2">
            Secure checkout powered by industry standard payment gateways. <br/>
            All UPI apps (GPay, PhonePe, Paytm), Cards, and Net Banking supported.
          </p>
        </div>
      </div>
    </div>
  );
}
