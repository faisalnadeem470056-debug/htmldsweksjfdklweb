import React, { useRef, useState } from 'react';
import { ExamResult, Student } from '../types';
import { toPersianDigits, formatPersianPercentage } from '../utils/jalali';
import { exportReportCardToPdf } from '../utils/pdfExport';
import { 
  X, 
  Printer, 
  Award, 
  Sparkles, 
  CheckCircle2, 
  AlertCircle, 
  BookOpen, 
  TrendingUp,
  Download,
  Loader2,
  FileCheck,
  ShieldCheck
} from 'lucide-react';

interface ReportCardModalProps {
  result: ExamResult;
  student: Student;
  onClose: () => void;
}

export const ReportCardModal: React.FC<ReportCardModalProps> = ({
  result,
  student,
  onClose
}) => {
  const reportCardRef = useRef<HTMLDivElement>(null);
  const [isGeneratingPdf, setIsGeneratingPdf] = useState(false);
  const [pdfStatus, setPdfStatus] = useState<string>('');

  const handlePrint = () => {
    window.print();
  };

  const handleDownloadPdf = async () => {
    if (!reportCardRef.current || isGeneratingPdf) return;
    setIsGeneratingPdf(true);
    setPdfStatus('آماده‌سازی کارنامه...');

    try {
      const cleanStudentName = student.fullName.replace(/\s+/g, '_');
      const cleanExamTitle = (result.examTitle || 'Exam').replace(/\s+/g, '_');
      const fileName = `Karname_IMAX_${cleanStudentName}_${cleanExamTitle}.pdf`;

      await exportReportCardToPdf(reportCardRef.current, {
        fileName,
        onProgress: (step) => setPdfStatus(step)
      });
    } catch (error) {
      console.error('Failed to generate PDF:', error);
      alert('متاسفانه در تولید فایل PDF خطایی رخ داد. می‌توانید از دکمه چاپ مستقیم استفاده کنید.');
    } finally {
      setIsGeneratingPdf(false);
      setPdfStatus('');
    }
  };

  const formatGradeName = (grade: number) => {
    switch (grade) {
      case 3: return 'پایه سوم ابتدایی';
      case 4: return 'پایه چهارم ابتدایی';
      case 5: return 'پایه پنجم (آمادگی تیزهوشان)';
      case 6: return 'پایه ششم تیزهوشان (ابتدایی)';
      case 9: return 'پایه نهم تیزهوشان (متوسطه اول)';
      default: return `پایه ${grade}`;
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-6 print:p-0 print:bg-white print:static">
      
      {/* Container */}
      <div className="bg-white border border-slate-200 text-slate-900 w-full max-w-4xl rounded-2xl shadow-2xl overflow-hidden print:border-none print:shadow-none print:bg-white print:text-black print:rounded-none">
        
        {/* Action Header - Hidden during print */}
        <div className="flex flex-wrap items-center justify-between px-5 sm:px-6 py-4 border-b border-slate-200 bg-slate-50/90 print:hidden gap-3">
          <div className="flex items-center gap-2">
            <Award className="w-5 h-5 text-amber-500 shrink-0" />
            <div>
              <span className="font-bold text-sm sm:text-base text-slate-900 block leading-tight">
                کارنامه رسمی و تحلیلی تیزهوشان آی‌مکس (IMAX)
              </span>
              <span className="text-[11px] text-slate-500 hidden sm:block">
                خروجی معتبر برای والدین و داوطلب با قابلیت ذخیره PDF کلاینت‌محور
              </span>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {/* Download PDF button using client-side library */}
            <button
              id="download-pdf-button"
              onClick={handleDownloadPdf}
              disabled={isGeneratingPdf}
              className="flex items-center gap-1.5 px-4 py-2 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 text-white rounded-xl text-xs font-bold shadow-xs transition-all disabled:opacity-50 cursor-pointer active:scale-95"
              title="تولید و دانلود مستقیم فایل PDF در مرورگر بدون نیاز به سرور"
            >
              {isGeneratingPdf ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin text-white" />
                  <span>{pdfStatus || 'در حال ساخت PDF...'}</span>
                </>
              ) : (
                <>
                  <Download className="w-4 h-4 text-white" />
                  <span>دانلود فایل PDF کارنامه</span>
                </>
              )}
            </button>

            {/* Print button */}
            <button
              id="print-button"
              onClick={handlePrint}
              disabled={isGeneratingPdf}
              className="flex items-center gap-1.5 px-3.5 py-2 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 border border-indigo-200 rounded-xl text-xs font-bold transition-colors cursor-pointer"
            >
              <Printer className="w-4 h-4 text-indigo-600" />
              <span className="hidden sm:inline">چاپ کاغذی (Print)</span>
            </button>

            {/* Close button */}
            <button
              onClick={onClose}
              disabled={isGeneratingPdf}
              className="p-2 rounded-xl bg-slate-200/80 hover:bg-slate-300 text-slate-600 hover:text-slate-900 transition-colors cursor-pointer"
              title="بستن پنجره"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Printable & Exportable Report Content */}
        <div ref={reportCardRef} className="p-6 sm:p-8 space-y-6 print:p-4 print:text-black bg-white">
          
          {/* Institute Header Banner */}
          <div className="flex flex-col sm:flex-row items-center justify-between border-b-2 border-indigo-600/30 pb-4 gap-4 print:border-indigo-600">
            <div className="flex items-center gap-3 text-right">
              <div className="w-14 h-14 rounded-2xl bg-gradient-to-tr from-amber-500 to-indigo-600 flex items-center justify-center text-white font-black text-2xl shadow-md print:border print:border-black shrink-0">
                IM
              </div>
              <div>
                <h2 className="text-xl font-black text-slate-900 print:text-black">
                  موسسه تیزهوشان آی‌مکس (IMAX Smart Academy)
                </h2>
                <p className="text-xs text-indigo-700 print:text-slate-700 font-bold">
                  مرکز تخصصی سنجش، آموزش و هدایت داوطلبان آزمون‌های ورودی سمپاد
                </p>
                <p className="text-[11px] text-slate-500 print:text-slate-600 mt-0.5">
                  هوش محاسباتی و خلاقیت (استاد عباسی) • هوش کلامی و منطقی (استاد مرحمتی)
                </p>
              </div>
            </div>

            <div className="text-left sm:text-right bg-slate-50 print:bg-slate-100 p-3 rounded-xl border border-slate-200 print:border-slate-300 text-xs space-y-1 min-w-[200px]">
              <div>عنوان آزمون: <span className="font-bold text-slate-900 print:text-black">{result.examTitle}</span></div>
              <div>تاریخ برگزاری: <span className="font-semibold text-amber-700 print:text-indigo-800">{toPersianDigits(result.PersianDate)}</span></div>
              <div>شناسه یکتای کارنامه: <span className="font-mono text-slate-700 print:text-slate-800 font-bold">{result.resultId}</span></div>
            </div>
          </div>

          {/* Student Profile Ribbon */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4 bg-slate-50 print:bg-slate-50 p-4 rounded-xl border border-slate-200 print:border-slate-300 items-center">
            <div className="flex items-center gap-3">
              <img
                src={student.photo}
                alt={student.fullName}
                crossOrigin="anonymous"
                className="w-14 h-14 rounded-xl object-cover border-2 border-indigo-500 shadow-xs print:border-black"
              />
              <div>
                <div className="text-xs text-slate-500 print:text-slate-500">نام و نام‌خانوادگی:</div>
                <div className="font-bold text-base text-slate-900 print:text-black">{student.fullName}</div>
              </div>
            </div>

            <div>
              <div className="text-xs text-slate-500 print:text-slate-500">پایه تحصیلی:</div>
              <div className="font-semibold text-slate-800 print:text-black">
                {formatGradeName(student.grade)}
              </div>
            </div>

            <div>
              <div className="text-xs text-slate-500 print:text-slate-500">کد ملی / شناسه:</div>
              <div className="font-mono text-slate-700 print:text-black">
                {toPersianDigits(student.nationalCode)}
              </div>
            </div>

            {/* Rank & T-Score Highlight Box */}
            <div className="bg-gradient-to-r from-amber-50 to-indigo-50 print:bg-amber-50 p-3 rounded-xl border border-amber-200 print:border-amber-300 text-center shadow-xs">
              <div className="text-xs text-amber-800 print:text-amber-800 font-semibold">
                رتبه در پایه ({toPersianDigits(result.totalParticipants)} نفر)
              </div>
              <div className="text-2xl font-black text-amber-600 print:text-amber-900 mt-0.5 font-mono">
                رتبه {toPersianDigits(result.rank)}
              </div>
              <div className="text-[11px] text-slate-600 print:text-slate-600">
                تراز کل سمپاد: <span className="font-bold text-indigo-900 print:text-black font-mono">{toPersianDigits(result.tScore)}</span>
              </div>
            </div>
          </div>

          {/* Results Details Table */}
          <div>
            <h3 className="text-sm font-bold text-slate-800 print:text-black mb-2.5 flex items-center gap-2">
              <BookOpen className="w-4 h-4 text-indigo-600" />
              <span>ریز نمرات و درصد پاسخگویی به تفکیک دفترچه‌ها</span>
            </h3>

            {/* 6th Grade Table */}
            {result.grade === 6 && result.sixthGrade && (
              <div className="overflow-x-auto rounded-xl border border-slate-200 print:border-slate-300">
                <table className="w-full text-right text-xs">
                  <thead className="bg-slate-100 print:bg-slate-200 text-slate-800 print:text-black font-semibold">
                    <tr>
                      <th className="p-3">عنوان دفترچه</th>
                      <th className="p-3 text-center">تعداد سوال</th>
                      <th className="p-3 text-center">ضریب</th>
                      <th className="p-3 text-center">درست</th>
                      <th className="p-3 text-center">نادرست</th>
                      <th className="p-3 text-center">سفید</th>
                      <th className="p-3 text-center">نمره خام</th>
                      <th className="p-3 text-center">درصد</th>
                      <th className="p-3 text-center">تراز استاندارد (T)</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-200 print:divide-slate-300 bg-white print:bg-white text-slate-800 print:text-black">
                    <tr>
                      <td className="p-3 font-bold text-indigo-700 print:text-indigo-900">
                        تحلیلی
                      </td>
                      <td className="p-3 text-center font-mono">۶۰</td>
                      <td className="p-3 text-center font-mono font-bold text-amber-700 print:text-black">۳</td>
                      <td className="p-3 text-center font-mono text-emerald-600 print:text-emerald-700 font-bold">
                        {toPersianDigits(result.sixthGrade.booklet1.correct)}
                      </td>
                      <td className="p-3 text-center font-mono text-rose-600 print:text-rose-700">
                        {toPersianDigits(result.sixthGrade.booklet1.wrong)}
                      </td>
                      <td className="p-3 text-center font-mono text-slate-500 print:text-slate-600">
                        {toPersianDigits(result.sixthGrade.booklet1.blank)}
                      </td>
                      <td className="p-3 text-center font-mono font-semibold">
                        {toPersianDigits(result.sixthGrade.booklet1.rawScore)}
                      </td>
                      <td className="p-3 text-center font-bold font-mono text-indigo-700 print:text-indigo-900">
                        {formatPersianPercentage(result.sixthGrade.booklet1.percentage)}
                      </td>
                      <td className="p-3 text-center font-black font-mono text-slate-900 print:text-black">
                        {toPersianDigits(result.sixthGrade.booklet1.tScore)}
                      </td>
                    </tr>
                    <tr>
                      <td className="p-3 font-semibold text-teal-700 print:text-teal-900">
                        دفترچه ۲: سرعت و دقت
                      </td>
                      <td className="p-3 text-center font-mono">۶۰</td>
                      <td className="p-3 text-center font-mono font-bold text-amber-700 print:text-black">۱</td>
                      <td className="p-3 text-center font-mono text-emerald-600 print:text-emerald-700 font-bold">
                        {toPersianDigits(result.sixthGrade.booklet2.correct)}
                      </td>
                      <td className="p-3 text-center font-mono text-rose-600 print:text-rose-700">
                        {toPersianDigits(result.sixthGrade.booklet2.wrong)}
                      </td>
                      <td className="p-3 text-center font-mono text-slate-500 print:text-slate-600">
                        {toPersianDigits(result.sixthGrade.booklet2.blank)}
                      </td>
                      <td className="p-3 text-center font-mono font-semibold">
                        {toPersianDigits(result.sixthGrade.booklet2.rawScore)}
                      </td>
                      <td className="p-3 text-center font-bold font-mono text-indigo-700 print:text-indigo-900">
                        {formatPersianPercentage(result.sixthGrade.booklet2.percentage)}
                      </td>
                      <td className="p-3 text-center font-black font-mono text-slate-900 print:text-black">
                        {toPersianDigits(result.sixthGrade.booklet2.tScore)}
                      </td>
                    </tr>
                  </tbody>
                  <tfoot className="bg-slate-100 print:bg-slate-100 font-bold border-t border-slate-200">
                    <tr>
                      <td className="p-3 text-slate-900 print:text-black">جمع کل آزمون شبیه‌ساز سمپاد</td>
                      <td className="p-3 text-center font-mono">۱۲۰</td>
                      <td className="p-3 text-center">-</td>
                      <td className="p-3 text-center font-mono text-emerald-700 print:text-emerald-800">
                        {toPersianDigits(result.sixthGrade.booklet1.correct + result.sixthGrade.booklet2.correct)}
                      </td>
                      <td className="p-3 text-center font-mono text-rose-700 print:text-rose-800">
                        {toPersianDigits(result.sixthGrade.booklet1.wrong + result.sixthGrade.booklet2.wrong)}
                      </td>
                      <td className="p-3 text-center font-mono">
                        {toPersianDigits(result.sixthGrade.booklet1.blank + result.sixthGrade.booklet2.blank)}
                      </td>
                      <td className="p-3 text-center font-mono">{toPersianDigits(result.totalScore)}</td>
                      <td className="p-3 text-center font-mono text-indigo-800 print:text-indigo-900 text-sm">
                        {formatPersianPercentage(result.totalPercentage)}
                      </td>
                      <td className="p-3 text-center font-mono text-base text-indigo-950 print:text-indigo-950 font-black">
                        {toPersianDigits(result.tScore)}
                      </td>
                    </tr>
                  </tfoot>
                </table>
              </div>
            )}

            {/* 9th Grade Table */}
            {result.grade === 9 && result.ninthGrade && (
              <div className="space-y-4">
                <div className="overflow-x-auto rounded-xl border border-slate-200 print:border-slate-300">
                  <table className="w-full text-right text-xs">
                    <thead className="bg-slate-100 print:bg-slate-200 text-slate-800 print:text-black font-semibold">
                      <tr>
                        <th className="p-2.5">عنوان درس (دفترچه اول استعداد تحصیلی)</th>
                        <th className="p-2.5 text-center">تعداد سوال</th>
                        <th className="p-2.5 text-center">درست</th>
                        <th className="p-2.5 text-center">نادرست</th>
                        <th className="p-2.5 text-center">سفید</th>
                        <th className="p-2.5 text-center">درصد</th>
                        <th className="p-2.5 text-center">سطح عملکرد</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-200 print:divide-slate-300 bg-white print:bg-white text-slate-800 print:text-black">
                      {Object.values(result.ninthGrade.booklet1.subjects).map((sub: any) => (
                        <tr key={sub.key}>
                          <td className="p-2.5 font-medium">{sub.titleFa}</td>
                          <td className="p-2.5 text-center font-mono">{toPersianDigits(sub.questionsCount)}</td>
                          <td className="p-2.5 text-center font-mono text-emerald-600 print:text-emerald-700">{toPersianDigits(sub.correct)}</td>
                          <td className="p-2.5 text-center font-mono text-rose-600 print:text-rose-700">{toPersianDigits(sub.wrong)}</td>
                          <td className="p-2.5 text-center font-mono text-slate-500">{toPersianDigits(sub.blank)}</td>
                          <td className="p-2.5 text-center font-mono font-bold text-indigo-700 print:text-indigo-900">
                            {formatPersianPercentage(sub.percentage)}
                          </td>
                          <td className="p-2.5 text-center">
                            <span className={`px-2 py-0.5 rounded text-[11px] font-semibold ${
                              sub.level === 'عالی' ? 'bg-emerald-50 text-emerald-800 border border-emerald-200' :
                              sub.level === 'خوب' ? 'bg-blue-50 text-blue-800 border border-blue-200' :
                              sub.level === 'قابل قبول' ? 'bg-amber-50 text-amber-800 border border-amber-200' :
                              'bg-rose-50 text-rose-800 border border-rose-200'
                            }`}>
                              {sub.level}
                            </span>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>

                <div className="bg-slate-50 print:bg-slate-100 p-3 rounded-xl border border-slate-200 print:border-slate-300 flex justify-between items-center text-xs">
                  <div>
                    <span className="font-semibold text-indigo-900 print:text-indigo-900">دفترچه دوم: استعداد تحلیلی (۵۰ سوال):</span>
                    <span className="mr-2 text-slate-600 print:text-slate-700">
                      درست: {toPersianDigits(result.ninthGrade.booklet2.correct)} • نادرست: {toPersianDigits(result.ninthGrade.booklet2.wrong)} • سفید: {toPersianDigits(result.ninthGrade.booklet2.blank)}
                    </span>
                  </div>
                  <div className="font-mono font-bold text-sm text-indigo-700 print:text-black">
                    درصد دفترچه دوم: {formatPersianPercentage(result.ninthGrade.booklet2.percentage)}
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* AI Educational Analysis & Suggestions Box */}
          <div className="bg-gradient-to-br from-indigo-50/70 to-purple-50/50 print:bg-slate-100 p-5 rounded-2xl border border-indigo-100 print:border-indigo-300 space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2 text-indigo-900 print:text-amber-800 font-bold text-sm">
                <Sparkles className="w-5 h-5 text-amber-500 animate-pulse" />
                <span>تحلیل هوشمند و راهکارهای ارتقای تراز تیزهوشان (AI Analytics)</span>
              </div>
              <span className="text-[11px] px-2.5 py-0.5 rounded-full bg-indigo-100 text-indigo-800 border border-indigo-200">
                هوش مصنوعی آی‌مکس
              </span>
            </div>

            {/* Summary & Comparison */}
            <div className="space-y-1.5 text-xs sm:text-sm text-slate-800 print:text-slate-800 leading-relaxed">
              <p className="font-semibold text-indigo-950">
                {result.analysis.comparisonToPrevious}
              </p>
              <p className="text-slate-700">
                {result.analysis.summary}
              </p>
            </div>

            {/* Strengths & Weaknesses Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3 pt-2">
              <div className="bg-white print:bg-emerald-50 border border-emerald-200 rounded-xl p-3 text-xs space-y-1.5 shadow-xs">
                <div className="font-bold text-emerald-800 flex items-center gap-1.5">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                  <span>نقاط قوت و مباحث تثبیت‌شده:</span>
                </div>
                <ul className="list-disc list-inside text-slate-700 space-y-1 pr-1">
                  {result.analysis.strengths.map((s, idx) => (
                    <li key={idx}>{s}</li>
                  ))}
                </ul>
              </div>

              <div className="bg-white print:bg-rose-50 border border-rose-200 rounded-xl p-3 text-xs space-y-1.5 shadow-xs">
                <div className="font-bold text-rose-800 flex items-center gap-1.5">
                  <AlertCircle className="w-4 h-4 text-rose-600" />
                  <span>نقاط نیازمند توجه و اصلاح تکنیکی:</span>
                </div>
                <ul className="list-disc list-inside text-slate-700 space-y-1 pr-1">
                  {result.analysis.weaknesses.map((w, idx) => (
                    <li key={idx}>{w}</li>
                  ))}
                </ul>
              </div>
            </div>

            {/* Study Suggestions */}
            <div className="bg-white print:bg-indigo-50 border border-indigo-200 rounded-xl p-3 text-xs space-y-1.5 shadow-xs">
              <div className="font-bold text-indigo-900 flex items-center gap-1.5">
                <TrendingUp className="w-4 h-4 text-indigo-600" />
                <span>برنامه راهبردی و پیشنهادات مطالعاتی اساتید:</span>
              </div>
              <ul className="list-decimal list-inside text-slate-700 space-y-1 pr-1">
                {result.analysis.studySuggestions.map((sug, idx) => (
                  <li key={idx}>{sug}</li>
                ))}
              </ul>
            </div>
          </div>

          {/* Official Signatures & Stamp */}
          <div className="pt-4 border-t border-slate-200 print:border-slate-300 flex justify-between items-center text-xs text-slate-600 print:text-slate-600">
            <div className="text-center">
              <div className="font-medium">مهر رسمی آموزشگاه تیزهوشان آی‌مکس</div>
              <div className="mt-2 w-24 h-12 border-2 border-dashed border-indigo-400 bg-indigo-50/50 print:bg-transparent rounded-lg flex flex-col items-center justify-center font-serif text-[9px] text-indigo-900 font-bold">
                <span>آموزشگاه آی‌مکس</span>
                <span className="text-[8px] text-slate-500 font-mono">تایید شد ✓</span>
              </div>
            </div>

            {student.grade === 3 || student.grade === 4 ? (
              <div className="text-center">
                <div className="font-medium text-slate-800">امضای مدرس دوره اختصاصی</div>
                <div className="text-[11px] text-slate-500">پایه {student.grade === 3 ? 'سوم' : 'چهارم'} ابتدایی</div>
                <div className="mt-1 font-serif text-slate-600 italic">Official Instructor</div>
              </div>
            ) : (
              <>
                <div className="text-center">
                  <div className="font-medium text-slate-800">امضای استاد عباسی</div>
                  <div className="text-[11px] text-slate-500">هوش محاسباتی و خلاقیت</div>
                  <div className="mt-1 font-serif text-indigo-700 italic font-bold">Y. Abbasi</div>
                </div>

                <div className="text-center">
                  <div className="font-medium text-slate-800">امضای استاد مرحمتی</div>
                  <div className="text-[11px] text-slate-500">هوش کلامی و منطقی</div>
                  <div className="mt-1 font-serif text-teal-700 italic font-bold">A. Marhamati</div>
                </div>
              </>
            )}

            <div className="text-center">
              <div className="font-medium text-slate-800">مدیر مسئول آموزشگاه</div>
              <div className="text-[11px] text-slate-500">واحد سنجش و آزمون</div>
              <div className="mt-1 font-semibold text-slate-900 print:text-black">مهندس حسینی</div>
            </div>
          </div>

          {/* Security Watermark & Verification Footer */}
          <div className="pt-3 border-t border-slate-100 print:border-slate-200 flex flex-col sm:flex-row items-center justify-between text-[10px] text-slate-500 print:text-slate-600 gap-1.5">
            <div className="flex items-center gap-1.5">
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
              <span>کارنامه تحلیلی الکترونیکی دارای شناسه اعتبارسنجی معتبر سمپاد موسسه آی‌مکس</span>
            </div>
            <div className="font-mono">
              کد پیگیری: {result.resultId} • تاریخ صدور: {toPersianDigits(result.PersianDate)}
            </div>
          </div>

        </div>

      </div>
    </div>
  );
};
