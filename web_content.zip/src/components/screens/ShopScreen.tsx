import React, { useState } from 'react';
import { ArrowLeft, Coins, ShoppingBag, ShieldAlert, Zap, Gift, Check, Sparkles } from 'lucide-react';
import { PlayerStats } from '../../types/game';

interface ShopScreenProps {
  playerStats: PlayerStats;
  medkitCount: number;
  onAddMedkits: (amount: number, cost: number) => void;
  onAddCoins: (amount: number) => void;
  onBack: () => void;
}

export const ShopScreen: React.FC<ShopScreenProps> = ({
  playerStats,
  medkitCount,
  onAddMedkits,
  onAddCoins,
  onBack
}) => {
  const [dailyClaimed, setDailyClaimed] = useState(false);

  const handleClaimDaily = () => {
    if (dailyClaimed) return;
    onAddCoins(500);
    onAddMedkits(3, 0);
    setDailyClaimed(true);
  };

  return (
    <div id="shop-screen" className="w-full h-full min-h-screen bg-slate-950 flex flex-col p-4 sm:p-6 select-none overflow-y-auto">
      {/* Top Header */}
      <div className="w-full max-w-5xl mx-auto flex items-center justify-between pb-4 border-b border-slate-800">
        <button
          id="shop-back-btn"
          onClick={onBack}
          className="flex items-center gap-2 px-4 py-2 rounded-xl bg-slate-900 border border-slate-700 hover:border-slate-500 text-slate-200 font-bold text-sm transition-all active:scale-95"
        >
          <ArrowLeft size={18} /> BACK
        </button>

        <div className="text-center">
          <h1 className="font-display font-black text-2xl sm:text-3xl text-white tracking-wider">
            BLACK MARKET & SUPPLIES
          </h1>
          <p className="text-xs text-slate-400">Equip medical kits and claim hunter supply drops</p>
        </div>

        <div className="flex items-center gap-2 bg-slate-900 px-3.5 py-1.5 rounded-xl border border-amber-500/30 text-amber-400 font-mono font-bold text-base">
          <Coins size={18} />
          <span>{playerStats.coins.toLocaleString()}</span>
        </div>
      </div>

      {/* Main Grid */}
      <div className="w-full max-w-5xl mx-auto flex-1 flex flex-col gap-6 py-6">
        {/* Daily Hunter Supply Air Drop */}
        <div className="relative overflow-hidden bg-gradient-to-r from-purple-950/80 via-slate-900 to-indigo-950/80 border border-purple-500/50 rounded-3xl p-6 shadow-2xl flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className="w-16 h-16 rounded-2xl bg-purple-600/30 border-2 border-purple-400 flex items-center justify-center text-purple-300 shadow-lg shrink-0">
              <Gift size={36} className="animate-bounce" />
            </div>
            <div>
              <div className="inline-flex items-center gap-1 text-[11px] font-bold text-purple-400 uppercase tracking-widest bg-purple-950/60 px-2.5 py-0.5 rounded-full border border-purple-800 mb-1">
                <Sparkles size={12} /> Daily Resupply Air Drop
              </div>
              <h2 className="font-display font-black text-2xl text-white">HUNTER AID CRATE</h2>
              <p className="text-xs text-slate-300 mt-0.5">
                Contains +500 Gold Coins and 3 Emergency Combat Medkits for your run!
              </p>
            </div>
          </div>

          <button
            id="claim-daily-btn"
            onClick={handleClaimDaily}
            disabled={dailyClaimed}
            className={`py-3.5 px-6 rounded-2xl font-display font-black text-sm tracking-wider flex items-center gap-2 transition-all active:scale-95 shrink-0 ${
              dailyClaimed
                ? 'bg-slate-800 border border-slate-700 text-slate-500 cursor-default'
                : 'bg-purple-600 hover:bg-purple-500 text-white shadow-xl shadow-purple-950/50 border border-purple-300'
            }`}
          >
            {dailyClaimed ? (
              <>
                <Check size={18} /> CRATE CLAIMED
              </>
            ) : (
              <>
                <Gift size={18} /> CLAIM FREE CRATE
              </>
            )}
          </button>
        </div>

        {/* Combat Supplies Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {/* Item 1: 3x Medkit Bundle */}
          <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-5 flex items-center justify-between gap-4 shadow-xl">
            <div className="flex items-center gap-4">
              <div className="w-14 h-14 rounded-2xl bg-emerald-500/20 border border-emerald-500/50 flex items-center justify-center text-emerald-400 shrink-0">
                <ShieldAlert size={28} />
              </div>
              <div>
                <h3 className="font-display font-black text-lg text-white">3x Emergency Medkits</h3>
                <p className="text-xs text-slate-400">Instantly restores 50% HP during intense firefights.</p>
                <span className="text-[11px] font-bold text-emerald-400 mt-1 block">
                  You Own: {medkitCount} in stock
                </span>
              </div>
            </div>

            <button
              onClick={() => onAddMedkits(3, 150)}
              disabled={playerStats.coins < 150}
              className={`px-4 py-2.5 rounded-xl font-display font-black text-xs tracking-wider flex items-center gap-1.5 border transition-all active:scale-95 shrink-0 ${
                playerStats.coins >= 150
                  ? 'bg-emerald-600 hover:bg-emerald-500 text-white border-emerald-400 shadow-md'
                  : 'bg-slate-800 text-slate-600 border-slate-700 cursor-not-allowed'
              }`}
            >
              <span>BUY 150</span>
              <Coins size={14} className="text-amber-300" />
            </button>
          </div>

          {/* Item 2: 10x Heavy Combat Medical Bag */}
          <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-5 flex items-center justify-between gap-4 shadow-xl">
            <div className="flex items-center gap-4">
              <div className="w-14 h-14 rounded-2xl bg-rose-500/20 border border-rose-500/50 flex items-center justify-center text-rose-400 shrink-0">
                <ShoppingBag size={28} />
              </div>
              <div>
                <h3 className="font-display font-black text-lg text-white">10x Trauma Surgical Pack</h3>
                <p className="text-xs text-slate-400">Bulk combat supply with a 25% discount!</p>
                <span className="text-[11px] font-bold text-amber-400 mt-1 block">
                  Best Value for Boss Fights
                </span>
              </div>
            </div>

            <button
              onClick={() => onAddMedkits(10, 400)}
              disabled={playerStats.coins < 400}
              className={`px-4 py-2.5 rounded-xl font-display font-black text-xs tracking-wider flex items-center gap-1.5 border transition-all active:scale-95 shrink-0 ${
                playerStats.coins >= 400
                  ? 'bg-rose-600 hover:bg-rose-500 text-white border-rose-400 shadow-md'
                  : 'bg-slate-800 text-slate-600 border-slate-700 cursor-not-allowed'
              }`}
            >
              <span>BUY 400</span>
              <Coins size={14} className="text-amber-300" />
            </button>
          </div>

          {/* Item 3: Tactical Bounty Hunter Cache (Coins boost) */}
          <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-5 flex items-center justify-between gap-4 shadow-xl">
            <div className="flex items-center gap-4">
              <div className="w-14 h-14 rounded-2xl bg-amber-500/20 border border-amber-500/50 flex items-center justify-center text-amber-400 shrink-0">
                <Coins size={28} />
              </div>
              <div>
                <h3 className="font-display font-black text-lg text-white">Bounty Hunter Grant</h3>
                <p className="text-xs text-slate-400">Sponsored combat grant from Hunter HQ (+1,000 Coins).</p>
                <span className="text-[11px] font-bold text-cyan-400 mt-1 block">
                  Free Combat Sponsorship
                </span>
              </div>
            </div>

            <button
              onClick={() => onAddCoins(1000)}
              className="px-4 py-2.5 rounded-xl bg-amber-600 hover:bg-amber-500 text-white border border-amber-400 font-display font-black text-xs tracking-wider flex items-center gap-1.5 shadow-md active:scale-95 shrink-0"
            >
              <Zap size={14} /> CLAIM +1,000
            </button>
          </div>

          {/* Item 4: War-Chest Gold Influx */}
          <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-5 flex items-center justify-between gap-4 shadow-xl">
            <div className="flex items-center gap-4">
              <div className="w-14 h-14 rounded-2xl bg-sky-500/20 border border-sky-500/50 flex items-center justify-center text-sky-400 shrink-0">
                <Sparkles size={28} />
              </div>
              <div>
                <h3 className="font-display font-black text-lg text-white">War-Chest Reserve</h3>
                <p className="text-xs text-slate-400">Fast-track your weapon upgrades (+3,000 Coins).</p>
                <span className="text-[11px] font-bold text-emerald-400 mt-1 block">
                  Upgrade Accelerator
                </span>
              </div>
            </div>

            <button
              onClick={() => onAddCoins(3000)}
              className="px-4 py-2.5 rounded-xl bg-sky-600 hover:bg-sky-500 text-white border border-sky-400 font-display font-black text-xs tracking-wider flex items-center gap-1.5 shadow-md active:scale-95 shrink-0"
            >
              <Zap size={14} /> CLAIM +3,000
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
