import React from 'react';
import { ArrowLeft, Volume2, VolumeX, Music, Monitor, Sliders, Smartphone, Gamepad2, RotateCcw } from 'lucide-react';
import { GameSettings } from '../../types/game';

interface SettingsScreenProps {
  settings: GameSettings;
  onUpdateSettings: (newSettings: Partial<GameSettings>) => void;
  onResetProgress: () => void;
  onBack: () => void;
}

export const SettingsScreen: React.FC<SettingsScreenProps> = ({
  settings,
  onUpdateSettings,
  onResetProgress,
  onBack
}) => {
  return (
    <div id="settings-screen" className="w-full h-full min-h-screen bg-slate-950 flex flex-col p-4 sm:p-6 select-none overflow-y-auto">
      {/* Top Header */}
      <div className="w-full max-w-4xl mx-auto flex items-center justify-between pb-4 border-b border-slate-800">
        <button
          id="settings-back-btn"
          onClick={onBack}
          className="flex items-center gap-2 px-4 py-2 rounded-xl bg-slate-900 border border-slate-700 hover:border-slate-500 text-slate-200 font-bold text-sm transition-all active:scale-95"
        >
          <ArrowLeft size={18} /> BACK
        </button>

        <div className="text-center">
          <h1 className="font-display font-black text-2xl sm:text-3xl text-white tracking-wider">
            GAME SETTINGS
          </h1>
          <p className="text-xs text-slate-400">Audio, graphics quality, and controller sensitivity</p>
        </div>

        <div className="w-20" />
      </div>

      {/* Settings Options */}
      <div className="w-full max-w-4xl mx-auto flex-1 flex flex-col gap-6 py-6">
        {/* Audio Panel */}
        <div className="bg-slate-900/80 border border-slate-800 rounded-3xl p-6 shadow-xl flex flex-col gap-4">
          <h2 className="font-display font-bold text-lg text-white flex items-center gap-2 border-b border-slate-800 pb-3">
            <Volume2 className="text-cyan-400" size={20} /> AUDIO & MUSIC CONFIGURATION
          </h2>

          {/* Sound FX */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <div className="text-sm font-bold text-slate-200">Sound Effects (SFX)</div>
              <div className="text-xs text-slate-400">Weapon gunshots, zombie impacts, reloads, and explosions</div>
            </div>
            <div className="flex items-center gap-3">
              <input
                type="range"
                min="0"
                max="1"
                step="0.05"
                value={settings.soundVolume}
                onChange={(e) => onUpdateSettings({ soundVolume: parseFloat(e.target.value) })}
                className="w-28 accent-cyan-400"
              />
              <button
                onClick={() => onUpdateSettings({ soundEnabled: !settings.soundEnabled })}
                className={`px-4 py-2 rounded-xl text-xs font-bold border transition-all flex items-center gap-1.5 ${
                  settings.soundEnabled
                    ? 'bg-cyan-600 text-white border-cyan-400'
                    : 'bg-slate-800 text-slate-500 border-slate-700'
                }`}
              >
                {settings.soundEnabled ? <Volume2 size={16} /> : <VolumeX size={16} />}
                <span>{settings.soundEnabled ? 'ON' : 'OFF'}</span>
              </button>
            </div>
          </div>

          {/* Music */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pt-3 border-t border-slate-800/60">
            <div>
              <div className="text-sm font-bold text-slate-200">Action Music Soundtrack</div>
              <div className="text-xs text-slate-400">High-energy arcade combat electronic beat synthesizer</div>
            </div>
            <div className="flex items-center gap-3">
              <input
                type="range"
                min="0"
                max="1"
                step="0.05"
                value={settings.musicVolume}
                onChange={(e) => onUpdateSettings({ musicVolume: parseFloat(e.target.value) })}
                className="w-28 accent-rose-400"
              />
              <button
                onClick={() => onUpdateSettings({ musicEnabled: !settings.musicEnabled })}
                className={`px-4 py-2 rounded-xl text-xs font-bold border transition-all flex items-center gap-1.5 ${
                  settings.musicEnabled
                    ? 'bg-rose-600 text-white border-rose-400'
                    : 'bg-slate-800 text-slate-500 border-slate-700'
                }`}
              >
                <Music size={16} />
                <span>{settings.musicEnabled ? 'ON' : 'OFF'}</span>
              </button>
            </div>
          </div>
        </div>

        {/* Gameplay & Controls Panel */}
        <div className="bg-slate-900/80 border border-slate-800 rounded-3xl p-6 shadow-xl flex flex-col gap-4">
          <h2 className="font-display font-bold text-lg text-white flex items-center gap-2 border-b border-slate-800 pb-3">
            <Sliders className="text-amber-400" size={20} /> GAMEPLAY & CONTROLLER CALIBRATION
          </h2>

          {/* Graphics Quality */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <div className="text-sm font-bold text-slate-200">Graphics Quality</div>
              <div className="text-xs text-slate-400">Particle effects, bloodless sparks, dynamic shadows, and high FPS</div>
            </div>
            <div className="flex items-center gap-1.5">
              {(['high', 'medium', 'low'] as const).map(quality => (
                <button
                  key={quality}
                  onClick={() => onUpdateSettings({ graphicsQuality: quality })}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold uppercase transition-all ${
                    settings.graphicsQuality === quality
                      ? 'bg-amber-600 text-white shadow-md'
                      : 'bg-slate-800 text-slate-400 border border-slate-700'
                  }`}
                >
                  {quality}
                </button>
              ))}
            </div>
          </div>

          {/* Aim Assist */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pt-3 border-t border-slate-800/60">
            <div>
              <div className="text-sm font-bold text-slate-200">Aim Assist (Mobile / Casual)</div>
              <div className="text-xs text-slate-400">Automatically biases shots toward the nearest target zombie</div>
            </div>
            <button
              onClick={() => onUpdateSettings({ aimAssist: !settings.aimAssist })}
              className={`px-4 py-2 rounded-xl text-xs font-bold border transition-all ${
                settings.aimAssist
                  ? 'bg-emerald-600 text-white border-emerald-400'
                  : 'bg-slate-800 text-slate-500 border-slate-700'
              }`}
            >
              {settings.aimAssist ? 'ENABLED' : 'DISABLED'}
            </button>
          </div>

          {/* Touch Controls Overlay Force */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pt-3 border-t border-slate-800/60">
            <div>
              <div className="text-sm font-bold text-slate-200">Virtual Touchpad Overlay</div>
              <div className="text-xs text-slate-400">Display on-screen joystick and action buttons</div>
            </div>
            <button
              onClick={() => onUpdateSettings({ touchControls: !settings.touchControls })}
              className={`px-4 py-2 rounded-xl text-xs font-bold border transition-all ${
                settings.touchControls
                  ? 'bg-sky-600 text-white border-sky-400'
                  : 'bg-slate-800 text-slate-500 border-slate-700'
              }`}
            >
              {settings.touchControls ? 'ALWAYS ON' : 'AUTO DETECT'}
            </button>
          </div>
        </div>

        {/* Controls Reference Diagram (PC vs Mobile) */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {/* PC Layout Card */}
          <div className="bg-slate-900/60 border border-slate-800 rounded-2xl p-4">
            <h3 className="font-display font-bold text-sm text-cyan-400 flex items-center gap-2 mb-2">
              <Gamepad2 size={16} /> PC / KEYBOARD & MOUSE
            </h3>
            <ul className="text-xs text-slate-300 space-y-1.5">
              <li><strong className="text-white font-mono bg-slate-800 px-1.5 py-0.5 rounded">W A S D</strong> - Move Jubair</li>
              <li><strong className="text-white font-mono bg-slate-800 px-1.5 py-0.5 rounded">Mouse</strong> - Aim Crosshair</li>
              <li><strong className="text-white font-mono bg-slate-800 px-1.5 py-0.5 rounded">Left Click</strong> - Shoot / Fire</li>
              <li><strong className="text-white font-mono bg-slate-800 px-1.5 py-0.5 rounded">R</strong> - Reload Weapon</li>
              <li><strong className="text-white font-mono bg-slate-800 px-1.5 py-0.5 rounded">Space</strong> - Dodge / Jump</li>
              <li><strong className="text-white font-mono bg-slate-800 px-1.5 py-0.5 rounded">1, 2, 3, 4</strong> - Weapon Switch</li>
              <li><strong className="text-white font-mono bg-slate-800 px-1.5 py-0.5 rounded">Esc</strong> - Pause Menu</li>
            </ul>
          </div>

          {/* Mobile Layout Card */}
          <div className="bg-slate-900/60 border border-slate-800 rounded-2xl p-4">
            <h3 className="font-display font-bold text-sm text-rose-400 flex items-center gap-2 mb-2">
              <Smartphone size={16} /> MOBILE / TOUCH CONTROLS
            </h3>
            <ul className="text-xs text-slate-300 space-y-1.5">
              <li><strong className="text-white">Left Screen:</strong> Virtual Analog Joystick for 360&deg; movement</li>
              <li><strong className="text-white">Right Screen:</strong> Tap/Hold FIRE button to shoot</li>
              <li><strong className="text-white">DODGE:</strong> Tap Jump/Dodge button to roll out of danger</li>
              <li><strong className="text-white">RELOAD:</strong> Tap R button to refill clip</li>
              <li><strong className="text-white">SWAP:</strong> Tap SWAP button to cycle weapons</li>
              <li><strong className="text-white">HEAL:</strong> Tap Shield/Medkit button for emergency recovery</li>
            </ul>
          </div>
        </div>

        {/* Reset Progress Section */}
        <div className="bg-rose-950/20 border border-rose-900/50 rounded-2xl p-4 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div>
            <div className="text-sm font-bold text-rose-300">Reset Game Progress</div>
            <div className="text-xs text-rose-400/80">Re-locks levels and resets weapon upgrades to Level 1.</div>
          </div>
          <button
            onClick={() => {
              if (window.confirm('Are you sure you want to reset all progress to Level 1?')) {
                onResetProgress();
              }
            }}
            className="px-4 py-2 rounded-xl bg-rose-900/80 hover:bg-rose-800 text-rose-200 border border-rose-700 text-xs font-bold flex items-center gap-2 active:scale-95 transition-all"
          >
            <RotateCcw size={14} /> RESET SAVE DATA
          </button>
        </div>
      </div>
    </div>
  );
};
