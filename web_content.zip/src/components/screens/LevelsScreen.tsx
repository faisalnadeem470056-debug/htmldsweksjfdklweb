import React, { useState } from 'react';
import { ArrowLeft, Lock, Star, Skull, Award, Play } from 'lucide-react';
import { PlayerStats } from '../../types/game';
import { MAP_THEMES, isBossLevel, getLevelDetails } from '../../game/constants';

interface LevelsScreenProps {
  playerStats: PlayerStats;
  onSelectLevel: (level: number) => void;
  onBack: () => void;
}

export const LevelsScreen: React.FC<LevelsScreenProps> = ({
  playerStats,
  onSelectLevel,
  onBack
}) => {
  const [selectedThemeId, setSelectedThemeId] = useState<string>('all');

  const currentTheme = MAP_THEMES.find(t => t.id === selectedThemeId);

  // Generate array from 1 to 100
  const allLevels = Array.from({ length: 100 }, (_, i) => i + 1);

  const displayedLevels = selectedThemeId === 'all'
    ? allLevels
    : allLevels.filter(lvl => {
        if (!currentTheme) return true;
        return lvl >= currentTheme.levels[0] && lvl <= currentTheme.levels[1];
      });

  const totalStars = (Object.values(playerStats.stars) as number[]).reduce((a, b) => a + b, 0);

  return (
    <div id="levels-screen" className="w-full h-full min-h-screen bg-slate-950 flex flex-col p-4 sm:p-6 select-none overflow-y-auto">
      {/* Top Header */}
      <div className="w-full max-w-6xl mx-auto flex items-center justify-between pb-4 border-b border-slate-800">
        <button
          id="levels-back-btn"
          onClick={onBack}
          className="flex items-center gap-2 px-4 py-2 rounded-xl bg-slate-900 border border-slate-700 hover:border-slate-500 text-slate-200 font-bold text-sm transition-all active:scale-95"
        >
          <ArrowLeft size={18} /> BACK
        </button>

        <div className="text-center">
          <h1 className="font-display font-black text-2xl sm:text-3xl text-white tracking-wider">
            MISSION SELECT <span className="text-rose-500">(1 - 100)</span>
          </h1>
          <p className="text-xs text-slate-400">Clear levels to unlock new maps & epic boss battles</p>
        </div>

        <div className="flex items-center gap-1.5 bg-slate-900 px-3 py-1.5 rounded-xl border border-yellow-500/30 text-yellow-400 font-bold text-sm">
          <Award size={16} />
          <span>{totalStars} / 300 ★</span>
        </div>
      </div>

      {/* Map Chapter Filter Tabs */}
      <div className="w-full max-w-6xl mx-auto py-4 overflow-x-auto no-scrollbar flex items-center gap-2">
        <button
          onClick={() => setSelectedThemeId('all')}
          className={`px-3 py-1.5 rounded-xl text-xs font-bold whitespace-nowrap transition-all ${
            selectedThemeId === 'all'
              ? 'bg-rose-600 text-white shadow-lg'
              : 'bg-slate-900 text-slate-400 border border-slate-800 hover:text-slate-200'
          }`}
        >
          All Maps (1-100)
        </button>

        {MAP_THEMES.map(theme => (
          <button
            key={theme.id}
            onClick={() => setSelectedThemeId(theme.id)}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold whitespace-nowrap transition-all flex items-center gap-1.5 ${
              selectedThemeId === theme.id
                ? 'bg-cyan-600 text-white shadow-lg'
                : 'bg-slate-900 text-slate-400 border border-slate-800 hover:text-slate-200'
            }`}
          >
            <span 
              className="w-2 h-2 rounded-full" 
              style={{ backgroundColor: theme.accentColor }} 
            />
            <span>{theme.name}</span>
            <span className="text-[10px] opacity-70">({theme.levels[0]}-{theme.levels[1]})</span>
          </button>
        ))}
      </div>

      {/* Levels Grid */}
      <div className="w-full max-w-6xl mx-auto flex-1 grid grid-cols-3 sm:grid-cols-5 md:grid-cols-8 lg:grid-cols-10 gap-3 pb-8">
        {displayedLevels.map(lvl => {
          const isUnlocked = lvl <= playerStats.highestLevelUnlocked;
          const isBoss = isBossLevel(lvl);
          const stars = playerStats.stars[lvl] || 0;
          const details = getLevelDetails(lvl);

          return (
            <button
              key={lvl}
              disabled={!isUnlocked}
              onClick={() => onSelectLevel(lvl)}
              className={`relative aspect-square rounded-2xl p-2 flex flex-col items-center justify-between transition-all border shadow-md active:scale-95 ${
                !isUnlocked
                  ? 'bg-slate-900/40 border-slate-800/80 text-slate-600 cursor-not-allowed opacity-60'
                  : isBoss
                  ? 'bg-gradient-to-b from-slate-900 to-rose-950/80 border-rose-500/80 text-rose-300 hover:border-rose-400 shadow-rose-950/40 hover:scale-105'
                  : 'bg-slate-900/90 border-slate-700/80 text-slate-200 hover:border-cyan-500 hover:scale-105'
              }`}
            >
              {/* Top Tag: Boss or Star count */}
              <div className="w-full flex justify-between items-center text-[10px]">
                {isBoss ? (
                  <span className="flex items-center gap-0.5 text-rose-400 font-extrabold px-1 rounded bg-rose-950 border border-rose-800">
                    <Skull size={11} /> BOSS
                  </span>
                ) : (
                  <span className="text-slate-500 font-mono">#{lvl}</span>
                )}

                {isUnlocked && (
                  <div className="flex items-center text-yellow-400">
                    <Star size={10} className={stars >= 1 ? 'fill-yellow-400' : 'text-slate-700'} />
                    <Star size={10} className={stars >= 2 ? 'fill-yellow-400' : 'text-slate-700'} />
                    <Star size={10} className={stars >= 3 ? 'fill-yellow-400' : 'text-slate-700'} />
                  </div>
                )}
              </div>

              {/* Center: Level Number or Lock Icon */}
              <div className="my-auto flex flex-col items-center justify-center">
                {isUnlocked ? (
                  <span className={`font-display font-black text-xl sm:text-2xl ${isBoss ? 'text-rose-400' : 'text-white'}`}>
                    {lvl}
                  </span>
                ) : (
                  <Lock size={20} className="text-slate-600" />
                )}
              </div>

              {/* Bottom info */}
              <div className="w-full text-center">
                {isUnlocked ? (
                  <span className="text-[9px] font-bold text-slate-400 truncate block">
                    {details.totalZombies} Zomb
                  </span>
                ) : (
                  <span className="text-[9px] text-slate-600">Locked</span>
                )}
              </div>
            </button>
          );
        })}
      </div>
    </div>
  );
};
