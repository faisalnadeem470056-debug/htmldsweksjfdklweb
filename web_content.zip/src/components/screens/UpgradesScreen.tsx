import React from 'react';
import { ArrowLeft, Coins, Heart, Shield, Zap, Magnet, Target, ArrowUpCircle } from 'lucide-react';
import { PlayerStats } from '../../types/game';

interface UpgradesScreenProps {
  playerStats: PlayerStats;
  onUpgradePerk: (perkKey: keyof PlayerStats['perks']) => void;
  onBack: () => void;
}

export const UpgradesScreen: React.FC<UpgradesScreenProps> = ({
  playerStats,
  onUpgradePerk,
  onBack
}) => {
  const perksList: Array<{
    key: keyof PlayerStats['perks'];
    name: string;
    description: string;
    icon: React.ElementType;
    color: string;
    currentValue: string;
    nextValue: string;
  }> = [
    {
      key: 'maxHealthLevel',
      name: 'Titan Vitality',
      description: 'Increases Jubair maximum health pool for prolonged horde combat.',
      icon: Heart,
      color: '#f43f5e',
      currentValue: `${100 + (playerStats.perks.maxHealthLevel - 1) * 25} HP`,
      nextValue: `+25 HP`
    },
    {
      key: 'armorLevel',
      name: 'Nano-Kevlar Plating',
      description: 'Reinforced ballistic fibers reduce all incoming zombie damage.',
      icon: Shield,
      color: '#38bdf8',
      currentValue: `${(playerStats.perks.armorLevel - 1) * 8}% Reduction`,
      nextValue: `+8% Armor`
    },
    {
      key: 'speedLevel',
      name: 'Combat Agility',
      description: 'Boosts movement sprint velocity and shortens dodge roll cooldown.',
      icon: Zap,
      color: '#fbbf24',
      currentValue: `${240 + (playerStats.perks.speedLevel - 1) * 20} Speed`,
      nextValue: `+20 Speed`
    },
    {
      key: 'coinMagnetLevel',
      name: 'Scavenger Magnet',
      description: 'Pulls dropped coins and supplies from greater distances.',
      icon: Magnet,
      color: '#a855f7',
      currentValue: `Tier ${playerStats.perks.coinMagnetLevel}`,
      nextValue: `+35% Range`
    },
    {
      key: 'critChanceLevel',
      name: 'Lethal Precision',
      description: 'Grants chance to inflict 250% critical damage on bullet hits.',
      icon: Target,
      color: '#10b981',
      currentValue: `${(playerStats.perks.critChanceLevel - 1) * 10}% Crit`,
      nextValue: `+10% Crit`
    }
  ];

  return (
    <div id="upgrades-screen" className="w-full h-full min-h-screen bg-slate-950 flex flex-col p-4 sm:p-6 select-none overflow-y-auto">
      {/* Top Header */}
      <div className="w-full max-w-5xl mx-auto flex items-center justify-between pb-4 border-b border-slate-800">
        <button
          id="upgrades-back-btn"
          onClick={onBack}
          className="flex items-center gap-2 px-4 py-2 rounded-xl bg-slate-900 border border-slate-700 hover:border-slate-500 text-slate-200 font-bold text-sm transition-all active:scale-95"
        >
          <ArrowLeft size={18} /> BACK
        </button>

        <div className="text-center">
          <h1 className="font-display font-black text-2xl sm:text-3xl text-white tracking-wider">
            HUNTER PERKS & UPGRADES
          </h1>
          <p className="text-xs text-slate-400">Permanently bolster combat attributes and survival stats</p>
        </div>

        <div className="flex items-center gap-2 bg-slate-900 px-3.5 py-1.5 rounded-xl border border-amber-500/30 text-amber-400 font-mono font-bold text-base">
          <Coins size={18} />
          <span>{playerStats.coins.toLocaleString()}</span>
        </div>
      </div>

      {/* Perks List */}
      <div className="w-full max-w-5xl mx-auto flex-1 flex flex-col gap-4 py-6">
        {perksList.map(perk => {
          const level = playerStats.perks[perk.key];
          const maxLevel = 5;
          const isMax = level >= maxLevel;
          const cost = 200 + level * 250;
          const canAfford = playerStats.coins >= cost && !isMax;
          const Icon = perk.icon;

          return (
            <div
              key={perk.key}
              className="bg-slate-900/80 border border-slate-800 hover:border-slate-700 rounded-2xl p-4 sm:p-5 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 shadow-xl transition-all"
            >
              <div className="flex items-center gap-4">
                <div
                  className="w-14 h-14 rounded-2xl flex items-center justify-center border-2 shadow-lg shrink-0"
                  style={{ backgroundColor: `${perk.color}20`, borderColor: perk.color }}
                >
                  <Icon size={28} style={{ color: perk.color }} />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <h3 className="font-display font-black text-lg sm:text-xl text-white">
                      {perk.name}
                    </h3>
                    <span className="px-2 py-0.5 rounded bg-slate-800 text-cyan-400 border border-slate-700 text-xs font-mono font-bold">
                      LVL {level}/{maxLevel}
                    </span>
                  </div>
                  <p className="text-xs text-slate-400 max-w-lg mt-0.5">{perk.description}</p>
                  
                  {/* Progress bars */}
                  <div className="flex items-center gap-1.5 mt-2">
                    {Array.from({ length: maxLevel }).map((_, i) => (
                      <div
                        key={i}
                        className={`w-6 h-2 rounded-full ${
                          i < level ? 'bg-cyan-400 shadow-sm shadow-cyan-400' : 'bg-slate-800'
                        }`}
                      />
                    ))}
                    <span className="text-xs font-mono text-slate-300 ml-2">
                      Current: <strong>{perk.currentValue}</strong>
                    </span>
                  </div>
                </div>
              </div>

              {/* Upgrade Action */}
              <div className="w-full sm:w-auto flex sm:flex-col items-center sm:items-end justify-between gap-2 shrink-0">
                {isMax ? (
                  <span className="px-4 py-2 rounded-xl bg-emerald-950/80 border border-emerald-500/40 text-emerald-400 font-display font-black text-xs">
                    MAX LEVEL
                  </span>
                ) : (
                  <button
                    id={`upgrade-${perk.key}-btn`}
                    onClick={() => onUpgradePerk(perk.key)}
                    disabled={!canAfford}
                    className={`w-full sm:w-auto px-5 py-3 rounded-xl font-display font-black text-sm tracking-wider flex items-center justify-center gap-2 border transition-all active:scale-95 ${
                      canAfford
                        ? 'bg-amber-600 hover:bg-amber-500 text-white border-amber-400 shadow-lg shadow-amber-950/40'
                        : 'bg-slate-900 text-slate-500 border-slate-800 cursor-not-allowed'
                    }`}
                  >
                    <ArrowUpCircle size={18} />
                    <span>UPGRADE ({cost}</span>
                    <Coins size={15} className="text-amber-300" />
                    <span>)</span>
                  </button>
                )}
                {!isMax && (
                  <span className="text-[11px] font-semibold text-emerald-400">
                    Next: {perk.nextValue}
                  </span>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
