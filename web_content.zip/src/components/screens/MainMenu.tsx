import React from 'react';
import { 
  Play, 
  Map, 
  Crosshair, 
  ShieldCheck, 
  ShoppingBag, 
  Settings, 
  Coins, 
  Award, 
  Zap, 
  Skull,
  Gamepad2,
  Smartphone
} from 'lucide-react';
import { PlayerStats } from '../../types/game';

interface MainMenuProps {
  playerStats: PlayerStats;
  onNavigate: (screen: 'PLAY' | 'LEVELS' | 'WEAPONS' | 'UPGRADES' | 'SHOP' | 'SETTINGS') => void;
}

export const MainMenu: React.FC<MainMenuProps> = ({ playerStats, onNavigate }) => {
  const totalStars = (Object.values(playerStats.stars) as number[]).reduce((a, b) => a + b, 0);

  return (
    <div 
      id="main-menu" 
      className="relative w-full h-full min-h-screen bg-slate-950 flex flex-col justify-between p-4 sm:p-8 overflow-y-auto overflow-x-hidden select-none"
    >
      {/* Dynamic Background Pattern */}
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-slate-900 via-slate-950 to-black pointer-events-none opacity-90" />
      <div 
        className="absolute inset-0 opacity-10 pointer-events-none" 
        style={{
          backgroundImage: `linear-gradient(#38bdf8 1px, transparent 1px), linear-gradient(90deg, #38bdf8 1px, transparent 1px)`,
          backgroundSize: '40px 40px'
        }} 
      />

      {/* Top Bar: Player Stats & Currencies */}
      <div className="relative z-10 w-full max-w-5xl mx-auto flex flex-wrap items-center justify-between gap-4 bg-slate-900/80 backdrop-blur border border-slate-800 rounded-2xl p-3 sm:p-4 shadow-xl">
        {/* Hunter Badge */}
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-xl bg-gradient-to-tr from-rose-600 to-amber-500 p-0.5 shadow-lg shadow-rose-900/40">
            <div className="w-full h-full bg-slate-950 rounded-[10px] flex items-center justify-center">
              <Skull className="text-rose-500" size={24} />
            </div>
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-white font-display font-extrabold text-base sm:text-lg">JUBAIR</span>
              <span className="px-2 py-0.5 rounded bg-rose-500/20 text-rose-400 font-bold text-xs border border-rose-500/30">
                HUNTER LVL {playerStats.level}
              </span>
            </div>
            <div className="text-xs text-slate-400">
              Level {playerStats.highestLevelUnlocked} / 100 Cleared
            </div>
          </div>
        </div>

        {/* Currency & Stars */}
        <div className="flex items-center gap-3 sm:gap-6">
          <div className="flex items-center gap-2 bg-slate-950/80 px-3 py-1.5 rounded-xl border border-amber-500/30 shadow-inner">
            <Coins size={18} className="text-amber-400 animate-pulse" />
            <span className="font-mono font-bold text-amber-300 text-sm sm:text-base">
              {playerStats.coins.toLocaleString()}
            </span>
          </div>

          <div className="flex items-center gap-2 bg-slate-950/80 px-3 py-1.5 rounded-xl border border-yellow-500/30">
            <Award size={18} className="text-yellow-400" />
            <span className="font-mono font-bold text-yellow-300 text-sm sm:text-base">
              {totalStars} ★
            </span>
          </div>
        </div>
      </div>

      {/* Center: Game Title & Tagline */}
      <div className="relative z-10 w-full max-w-3xl mx-auto my-auto text-center py-6 sm:py-10 flex flex-col items-center">
        {/* Decorative Badge */}
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-rose-950/80 border border-rose-500/40 text-rose-300 text-xs font-bold tracking-widest uppercase mb-3 animate-pulse">
          <Zap size={14} className="text-rose-400" /> 100 Levels &bull; 10 Boss Fights &bull; No Horror
        </div>

        {/* Game Main Title */}
        <h1 className="font-display font-black text-4xl sm:text-6xl md:text-7xl tracking-wider text-transparent bg-clip-text bg-gradient-to-b from-white via-slate-100 to-slate-400 drop-shadow-[0_10px_20px_rgba(0,0,0,0.8)]">
          JUBAIR <span className="text-transparent bg-clip-text bg-gradient-to-r from-rose-500 via-red-500 to-amber-500">ZOMBIE</span> HUNTER
        </h1>

        {/* Tagline */}
        <div className="mt-2 text-sm sm:text-xl font-action font-semibold tracking-[0.25em] text-cyan-400 uppercase drop-shadow-md">
          “HUNT. SHOOT. SURVIVE.”
        </div>

        {/* Big PLAY Button */}
        <div className="mt-8 w-full max-w-xs">
          <button
            id="main-play-btn"
            onClick={() => onNavigate('PLAY')}
            className="w-full group relative py-4 px-8 rounded-2xl bg-gradient-to-r from-rose-600 via-red-600 to-amber-600 text-white font-display font-black text-xl tracking-wider shadow-[0_0_30px_rgba(225,29,72,0.4)] hover:shadow-[0_0_40px_rgba(225,29,72,0.7)] active:scale-95 transition-all flex items-center justify-center gap-3 border border-white/20"
          >
            <Play size={26} className="fill-white group-hover:scale-110 transition-transform" />
            <span>PLAY LEVEL {playerStats.highestLevelUnlocked}</span>
          </button>
        </div>

        {/* Primary Navigation Grid */}
        <div className="mt-6 w-full max-w-xl grid grid-cols-2 sm:grid-cols-5 gap-2.5">
          <button
            id="nav-levels-btn"
            onClick={() => onNavigate('LEVELS')}
            className="flex flex-col items-center justify-center p-3 rounded-xl bg-slate-900/90 hover:bg-slate-800 border border-slate-700/80 hover:border-cyan-500/50 text-slate-200 transition-all shadow-md active:scale-95"
          >
            <Map size={22} className="text-cyan-400 mb-1" />
            <span className="text-xs font-bold font-display">LEVELS</span>
            <span className="text-[10px] text-slate-400">1 - 100</span>
          </button>

          <button
            id="nav-weapons-btn"
            onClick={() => onNavigate('WEAPONS')}
            className="flex flex-col items-center justify-center p-3 rounded-xl bg-slate-900/90 hover:bg-slate-800 border border-slate-700/80 hover:border-amber-500/50 text-slate-200 transition-all shadow-md active:scale-95"
          >
            <Crosshair size={22} className="text-amber-400 mb-1" />
            <span className="text-xs font-bold font-display">WEAPONS</span>
            <span className="text-[10px] text-slate-400">Armory</span>
          </button>

          <button
            id="nav-upgrades-btn"
            onClick={() => onNavigate('UPGRADES')}
            className="flex flex-col items-center justify-center p-3 rounded-xl bg-slate-900/90 hover:bg-slate-800 border border-slate-700/80 hover:border-emerald-500/50 text-slate-200 transition-all shadow-md active:scale-95"
          >
            <ShieldCheck size={22} className="text-emerald-400 mb-1" />
            <span className="text-xs font-bold font-display">UPGRADES</span>
            <span className="text-[10px] text-slate-400">Hunter Perks</span>
          </button>

          <button
            id="nav-shop-btn"
            onClick={() => onNavigate('SHOP')}
            className="flex flex-col items-center justify-center p-3 rounded-xl bg-slate-900/90 hover:bg-slate-800 border border-slate-700/80 hover:border-purple-500/50 text-slate-200 transition-all shadow-md active:scale-95"
          >
            <ShoppingBag size={22} className="text-purple-400 mb-1" />
            <span className="text-xs font-bold font-display">SHOP</span>
            <span className="text-[10px] text-slate-400">Supplies</span>
          </button>

          <button
            id="nav-settings-btn"
            onClick={() => onNavigate('SETTINGS')}
            className="col-span-2 sm:col-span-1 flex flex-col items-center justify-center p-3 rounded-xl bg-slate-900/90 hover:bg-slate-800 border border-slate-700/80 hover:border-rose-500/50 text-slate-200 transition-all shadow-md active:scale-95"
          >
            <Settings size={22} className="text-rose-400 mb-1" />
            <span className="text-xs font-bold font-display">SETTINGS</span>
            <span className="text-[10px] text-slate-400">Audio / Input</span>
          </button>
        </div>
      </div>

      {/* Bottom Information Footer: PC & Mobile Controls Summary */}
      <div className="relative z-10 w-full max-w-4xl mx-auto flex flex-wrap items-center justify-center sm:justify-between text-xs text-slate-400 gap-4 pt-4 border-t border-slate-800/80">
        <div className="flex items-center gap-2">
          <Gamepad2 size={16} className="text-cyan-400" />
          <span><strong>PC:</strong> WASD (Move) &bull; Mouse (Aim & Shoot) &bull; R (Reload) &bull; Space (Dodge) &bull; 1-6 (Swap)</span>
        </div>
        <div className="flex items-center gap-2">
          <Smartphone size={16} className="text-rose-400" />
          <span><strong>Mobile:</strong> Virtual Joystick &bull; Aim/Shoot Buttons &bull; Full Touch Support</span>
        </div>
      </div>
    </div>
  );
};
