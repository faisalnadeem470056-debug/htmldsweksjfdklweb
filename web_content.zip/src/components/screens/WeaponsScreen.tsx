import React, { useState } from 'react';
import { ArrowLeft, Coins, Check, Zap, Crosshair, ArrowUpCircle, Lock } from 'lucide-react';
import { Weapon, WeaponType, PlayerStats } from '../../types/game';

interface WeaponsScreenProps {
  weapons: Record<WeaponType, Weapon>;
  playerStats: PlayerStats;
  onUpgradeWeapon: (weaponId: WeaponType) => void;
  onUnlockWeapon: (weaponId: WeaponType) => void;
  onEquipWeapon: (weaponId: WeaponType) => void;
  onBack: () => void;
}

export const WeaponsScreen: React.FC<WeaponsScreenProps> = ({
  weapons,
  playerStats,
  onUpgradeWeapon,
  onUnlockWeapon,
  onEquipWeapon,
  onBack
}) => {
  const [selectedWeaponId, setSelectedWeaponId] = useState<WeaponType>(playerStats.equippedWeapon);
  const selectedWeapon = weapons[selectedWeaponId];

  const upgradeCost = Math.floor(selectedWeapon.cost * 0.45 + (selectedWeapon.upgradeLevel * 250));
  const canAffordUpgrade = playerStats.coins >= upgradeCost && selectedWeapon.upgradeLevel < selectedWeapon.maxUpgradeLevel;
  const canAffordUnlock = playerStats.coins >= selectedWeapon.cost;
  const isEquipped = playerStats.equippedWeapon === selectedWeapon.id;

  return (
    <div id="weapons-screen" className="w-full h-full min-h-screen bg-slate-950 flex flex-col p-4 sm:p-6 select-none overflow-y-auto">
      {/* Top Header */}
      <div className="w-full max-w-6xl mx-auto flex items-center justify-between pb-4 border-b border-slate-800">
        <button
          id="weapons-back-btn"
          onClick={onBack}
          className="flex items-center gap-2 px-4 py-2 rounded-xl bg-slate-900 border border-slate-700 hover:border-slate-500 text-slate-200 font-bold text-sm transition-all active:scale-95"
        >
          <ArrowLeft size={18} /> BACK
        </button>

        <div className="text-center">
          <h1 className="font-display font-black text-2xl sm:text-3xl text-white tracking-wider">
            ARMORY & WEAPON LAB
          </h1>
          <p className="text-xs text-slate-400">Unlock arsenal and boost firepower with coins</p>
        </div>

        <div className="flex items-center gap-2 bg-slate-900 px-3.5 py-1.5 rounded-xl border border-amber-500/30 text-amber-400 font-mono font-bold text-base">
          <Coins size={18} />
          <span>{playerStats.coins.toLocaleString()}</span>
        </div>
      </div>

      {/* Main Content Layout */}
      <div className="w-full max-w-6xl mx-auto flex-1 grid grid-cols-1 lg:grid-cols-12 gap-6 py-6">
        {/* Left Column: Weapon Selection List (5 cols) */}
        <div className="lg:col-span-5 flex flex-col gap-3">
          {(Object.keys(weapons) as WeaponType[]).map(key => {
            const w = weapons[key];
            const isSel = selectedWeaponId === key;
            const isEq = playerStats.equippedWeapon === key;

            return (
              <button
                key={key}
                onClick={() => setSelectedWeaponId(key)}
                className={`p-3.5 rounded-2xl flex items-center justify-between border transition-all text-left active:scale-[0.98] ${
                  isSel
                    ? 'bg-slate-800 border-cyan-400 shadow-lg shadow-cyan-950/40 scale-[1.01]'
                    : 'bg-slate-900/80 border-slate-800 hover:border-slate-700'
                }`}
              >
                <div className="flex items-center gap-3">
                  <div 
                    className="w-12 h-12 rounded-xl flex items-center justify-center border"
                    style={{ backgroundColor: `${w.color}20`, borderColor: w.color }}
                  >
                    <Crosshair size={24} style={{ color: w.color }} />
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-display font-bold text-white text-base">{w.name}</span>
                      {isEq && (
                        <span className="px-1.5 py-0.5 rounded bg-emerald-500/20 border border-emerald-500/40 text-emerald-400 text-[10px] font-black">
                          EQUIPPED
                        </span>
                      )}
                    </div>
                    <div className="text-xs text-slate-400 font-medium">
                      {w.category} &bull; Tier {w.upgradeLevel}/{w.maxUpgradeLevel}
                    </div>
                  </div>
                </div>

                <div>
                  {w.unlocked ? (
                    <span className="text-xs font-mono text-cyan-400 font-bold">DMG {w.damage}</span>
                  ) : (
                    <div className="flex items-center gap-1 text-amber-400 text-xs font-bold bg-amber-950/40 px-2 py-1 rounded-lg border border-amber-900">
                      <Lock size={12} />
                      <span>{w.cost}</span>
                    </div>
                  )}
                </div>
              </button>
            );
          })}
        </div>

        {/* Right Column: Weapon Detail & Upgrade Studio (7 cols) */}
        <div className="lg:col-span-7 bg-slate-900/90 border border-slate-800 rounded-3xl p-6 flex flex-col justify-between shadow-2xl">
          <div>
            {/* Header info */}
            <div className="flex items-start justify-between">
              <div>
                <span className="text-xs font-bold text-rose-400 tracking-wider uppercase">
                  {selectedWeapon.category}
                </span>
                <h2 className="font-display font-black text-2xl sm:text-3xl text-white mt-0.5">
                  {selectedWeapon.name}
                </h2>
                <p className="text-xs text-slate-400 mt-1 max-w-md">
                  {selectedWeapon.description}
                </p>
              </div>

              <div 
                className="w-16 h-16 rounded-2xl flex items-center justify-center border-2 shadow-xl"
                style={{ backgroundColor: `${selectedWeapon.color}25`, borderColor: selectedWeapon.color }}
              >
                <Crosshair size={32} style={{ color: selectedWeapon.color }} />
              </div>
            </div>

            {/* Performance Stats Bars */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mt-6">
              {/* Damage */}
              <div className="bg-slate-950/70 p-3 rounded-2xl border border-slate-800/80">
                <div className="flex justify-between text-xs font-bold mb-1.5">
                  <span className="text-slate-400">DAMAGE POWER</span>
                  <span className="text-rose-400 font-mono">{selectedWeapon.damage} {selectedWeapon.pellets > 1 ? `x${selectedWeapon.pellets}` : ''}</span>
                </div>
                <div className="w-full h-2 bg-slate-800 rounded-full overflow-hidden">
                  <div 
                    className="h-full bg-rose-500 rounded-full transition-all"
                    style={{ width: `${Math.min(100, (selectedWeapon.damage / 240) * 100)}%` }}
                  />
                </div>
              </div>

              {/* Fire Rate */}
              <div className="bg-slate-950/70 p-3 rounded-2xl border border-slate-800/80">
                <div className="flex justify-between text-xs font-bold mb-1.5">
                  <span className="text-slate-400">FIRE RATE</span>
                  <span className="text-amber-400 font-mono">{selectedWeapon.fireRate} rps</span>
                </div>
                <div className="w-full h-2 bg-slate-800 rounded-full overflow-hidden">
                  <div 
                    className="h-full bg-amber-400 rounded-full transition-all"
                    style={{ width: `${Math.min(100, (selectedWeapon.fireRate / 15) * 100)}%` }}
                  />
                </div>
              </div>

              {/* Magazine Size */}
              <div className="bg-slate-950/70 p-3 rounded-2xl border border-slate-800/80">
                <div className="flex justify-between text-xs font-bold mb-1.5">
                  <span className="text-slate-400">MAGAZINE CAPACITY</span>
                  <span className="text-cyan-400 font-mono">{selectedWeapon.magSize} rds</span>
                </div>
                <div className="w-full h-2 bg-slate-800 rounded-full overflow-hidden">
                  <div 
                    className="h-full bg-cyan-400 rounded-full transition-all"
                    style={{ width: `${Math.min(100, (selectedWeapon.magSize / 100) * 100)}%` }}
                  />
                </div>
              </div>

              {/* Reload Time */}
              <div className="bg-slate-950/70 p-3 rounded-2xl border border-slate-800/80">
                <div className="flex justify-between text-xs font-bold mb-1.5">
                  <span className="text-slate-400">RELOAD SPEED</span>
                  <span className="text-emerald-400 font-mono">{selectedWeapon.reloadTime}s</span>
                </div>
                <div className="w-full h-2 bg-slate-800 rounded-full overflow-hidden">
                  <div 
                    className="h-full bg-emerald-400 rounded-full transition-all"
                    style={{ width: `${Math.max(20, 100 - (selectedWeapon.reloadTime / 3.5) * 100)}%` }}
                  />
                </div>
              </div>
            </div>

            {/* Upgrade Progress Tiers */}
            <div className="mt-6 bg-slate-950/50 p-4 rounded-2xl border border-slate-800">
              <div className="flex justify-between items-center text-xs font-bold text-slate-300 mb-2">
                <span>WEAPON ENHANCEMENT LEVEL</span>
                <span className="text-cyan-400 font-mono">Tier {selectedWeapon.upgradeLevel} of {selectedWeapon.maxUpgradeLevel}</span>
              </div>
              <div className="flex items-center gap-2">
                {Array.from({ length: selectedWeapon.maxUpgradeLevel }).map((_, i) => (
                  <div
                    key={i}
                    className={`flex-1 h-3 rounded-md transition-all ${
                      i < selectedWeapon.upgradeLevel
                        ? 'bg-gradient-to-r from-cyan-500 to-sky-400 shadow-sm shadow-cyan-500/50'
                        : 'bg-slate-800 border border-slate-700'
                    }`}
                  />
                ))}
              </div>
            </div>
          </div>

          {/* Action Buttons: Unlock, Upgrade, Equip */}
          <div className="flex flex-wrap items-center gap-3 pt-6 border-t border-slate-800">
            {selectedWeapon.unlocked ? (
              <>
                <button
                  id="equip-weapon-btn"
                  onClick={() => onEquipWeapon(selectedWeapon.id)}
                  disabled={isEquipped}
                  className={`flex-1 py-3.5 px-6 rounded-xl font-display font-black text-sm tracking-wider flex items-center justify-center gap-2 transition-all active:scale-95 ${
                    isEquipped
                      ? 'bg-emerald-950 border border-emerald-500/40 text-emerald-400 cursor-default'
                      : 'bg-rose-600 hover:bg-rose-500 text-white shadow-lg shadow-rose-900/40'
                  }`}
                >
                  {isEquipped ? (
                    <>
                      <Check size={18} /> ACTIVE IN LOADOUT
                    </>
                  ) : (
                    <>
                      <Zap size={18} /> EQUIP FOR COMBAT
                    </>
                  )}
                </button>

                {selectedWeapon.upgradeLevel < selectedWeapon.maxUpgradeLevel && (
                  <button
                    id="upgrade-weapon-btn"
                    onClick={() => onUpgradeWeapon(selectedWeapon.id)}
                    disabled={!canAffordUpgrade}
                    className={`py-3.5 px-6 rounded-xl font-display font-black text-sm tracking-wider flex items-center justify-center gap-2 transition-all active:scale-95 border ${
                      canAffordUpgrade
                        ? 'bg-amber-600 hover:bg-amber-500 text-white border-amber-400/50 shadow-lg shadow-amber-950/40'
                        : 'bg-slate-900 text-slate-500 border-slate-800 cursor-not-allowed'
                    }`}
                  >
                    <ArrowUpCircle size={18} />
                    <span>UPGRADE ({upgradeCost}</span>
                    <Coins size={14} className="text-amber-300" />
                    <span>)</span>
                  </button>
                )}
              </>
            ) : (
              <button
                id="unlock-weapon-btn"
                onClick={() => onUnlockWeapon(selectedWeapon.id)}
                disabled={!canAffordUnlock}
                className={`w-full py-4 px-6 rounded-xl font-display font-black text-base tracking-wider flex items-center justify-center gap-3 transition-all active:scale-95 border ${
                  canAffordUnlock
                    ? 'bg-gradient-to-r from-amber-600 to-yellow-500 text-white border-yellow-300 shadow-xl shadow-amber-900/40'
                    : 'bg-slate-900 text-slate-500 border-slate-800 cursor-not-allowed'
                }`}
              >
                <Lock size={20} />
                <span>PURCHASE ARSENAL UNLOCK ({selectedWeapon.cost}</span>
                <Coins size={18} className="text-amber-300" />
                <span>)</span>
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
