import React from 'react';
import { Player, PlayerColor, Token } from '../types/game';
import {
  MAIN_PATH,
  SAFE_TRACK_INDICES,
  HOME_PATHS,
  getTokenCoordinate,
  GridCoord,
  getLocationKey,
} from '../utils/boardCoordinates';

interface BoardProps {
  players: Player[];
  activeColor: PlayerColor;
  legalTokenIds: number[];
  isHumanTurn: boolean;
  onTokenClick: (tokenId: number) => void;
  animatingToken?: { color: PlayerColor; tokenId: number } | null;
}

const CELL_SIZE = 40;
const BOARD_SIZE = 600;

export const Board: React.FC<BoardProps> = ({
  players,
  activeColor,
  legalTokenIds,
  isHumanTurn,
  onTokenClick,
  animatingToken,
}) => {
  // Helper to convert grid coord (row, col) to SVG pixel center
  const getCellPixelCenter = (coord: GridCoord) => {
    return {
      x: coord.col * CELL_SIZE + CELL_SIZE / 2,
      y: coord.row * CELL_SIZE + CELL_SIZE / 2,
    };
  };

  // Group tokens by location key to calculate stacking offsets
  const locationGroups: Record<string, { color: PlayerColor; token: Token }[]> = {};

  players.forEach((player) => {
    if (!player.active) return;
    player.tokens.forEach((token) => {
      const key = getLocationKey(player.color, token.id, token.step);
      if (!locationGroups[key]) {
        locationGroups[key] = [];
      }
      locationGroups[key].push({ color: player.color, token });
    });
  });

  return (
    <div className="relative w-full max-w-[560px] aspect-square mx-auto select-none p-1 sm:p-2 bg-gradient-to-b from-amber-500/20 via-slate-900 to-amber-500/10 rounded-2xl sm:rounded-3xl shadow-2xl border border-amber-500/30 backdrop-blur-md">
      <svg
        viewBox={`0 0 ${BOARD_SIZE} ${BOARD_SIZE}`}
        className="w-full h-full rounded-xl sm:rounded-2xl shadow-inner bg-slate-950 overflow-hidden"
        style={{ shapeRendering: 'geometricPrecision' }}
      >
        <defs>
          {/* Gradients */}
          <linearGradient id="redGrad" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0%" stopColor="#EF4444" />
            <stop offset="100%" stopColor="#991B1B" />
          </linearGradient>
          <linearGradient id="greenGrad" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0%" stopColor="#10B981" />
            <stop offset="100%" stopColor="#065F46" />
          </linearGradient>
          <linearGradient id="yellowGrad" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0%" stopColor="#F59E0B" />
            <stop offset="100%" stopColor="#92400E" />
          </linearGradient>
          <linearGradient id="blueGrad" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0%" stopColor="#3B82F6" />
            <stop offset="100%" stopColor="#1E40AF" />
          </linearGradient>
          <linearGradient id="goldGrad" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0%" stopColor="#FDE68A" />
            <stop offset="50%" stopColor="#F59E0B" />
            <stop offset="100%" stopColor="#B45309" />
          </linearGradient>
          <linearGradient id="innerYard" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="#1E293B" />
            <stop offset="100%" stopColor="#0F172A" />
          </linearGradient>

          {/* Token Gradients & Dropshadows */}
          <filter id="tokenShadow" x="-20%" y="-20%" width="140%" height="140%">
            <feDropShadow dx="0" dy="3" stdDeviation="3" floodOpacity="0.6" />
          </filter>
          <filter id="glowGlow" x="-30%" y="-30%" width="160%" height="160%">
            <feGaussianBlur stdDeviation="4" result="blur" />
            <feComposite in="SourceGraphic" in2="blur" operator="over" />
          </filter>

          <radialGradient id="tokenRed" cx="35%" cy="35%" r="65%">
            <stop offset="0%" stopColor="#FCA5A5" />
            <stop offset="40%" stopColor="#EF4444" />
            <stop offset="100%" stopColor="#7F1D1D" />
          </radialGradient>
          <radialGradient id="tokenGreen" cx="35%" cy="35%" r="65%">
            <stop offset="0%" stopColor="#6EE7B7" />
            <stop offset="40%" stopColor="#10B981" />
            <stop offset="100%" stopColor="#064E3B" />
          </radialGradient>
          <radialGradient id="tokenYellow" cx="35%" cy="35%" r="65%">
            <stop offset="0%" stopColor="#FDE68A" />
            <stop offset="40%" stopColor="#F59E0B" />
            <stop offset="100%" stopColor="#78350F" />
          </radialGradient>
          <radialGradient id="tokenBlue" cx="35%" cy="35%" r="65%">
            <stop offset="0%" stopColor="#93C5FD" />
            <stop offset="40%" stopColor="#3B82F6" />
            <stop offset="100%" stopColor="#1E3A8A" />
          </radialGradient>
        </defs>

        {/* Board Background */}
        <rect x="0" y="0" width={BOARD_SIZE} height={BOARD_SIZE} fill="#0d1424" />

        {/* ==================== 4 YARDS (BASES) ==================== */}
        {/* Red Yard (Top Left: 0..240, 0..240) */}
        <rect x="0" y="0" width="240" height="240" fill="url(#redGrad)" />
        <rect x="28" y="28" width="184" height="184" rx="24" fill="url(#innerYard)" stroke="#EF4444" strokeWidth="2.5" />
        {/* 4 Pedestals for Red Tokens */}
        {[
          { cx: 68, cy: 68 },
          { cx: 172, cy: 68 },
          { cx: 68, cy: 172 },
          { cx: 172, cy: 172 },
        ].map((pos, i) => (
          <g key={`red-ped-${i}`}>
            <circle cx={pos.cx} cy={pos.cy} r="26" fill="#1e1e2e" stroke="#EF4444" strokeWidth="2.5" />
            <circle cx={pos.cx} cy={pos.cy} r="18" fill="#EF4444" fillOpacity="0.25" />
          </g>
        ))}

        {/* Green Yard (Top Right: 360..600, 0..240) */}
        <rect x="360" y="0" width="240" height="240" fill="url(#greenGrad)" />
        <rect x="388" y="28" width="184" height="184" rx="24" fill="url(#innerYard)" stroke="#10B981" strokeWidth="2.5" />
        {[
          { cx: 428, cy: 68 },
          { cx: 532, cy: 68 },
          { cx: 428, cy: 172 },
          { cx: 532, cy: 172 },
        ].map((pos, i) => (
          <g key={`green-ped-${i}`}>
            <circle cx={pos.cx} cy={pos.cy} r="26" fill="#1e1e2e" stroke="#10B981" strokeWidth="2.5" />
            <circle cx={pos.cx} cy={pos.cy} r="18" fill="#10B981" fillOpacity="0.25" />
          </g>
        ))}

        {/* Yellow Yard (Bottom Right: 360..600, 360..600) */}
        <rect x="360" y="360" width="240" height="240" fill="url(#yellowGrad)" />
        <rect x="388" y="388" width="184" height="184" rx="24" fill="url(#innerYard)" stroke="#F59E0B" strokeWidth="2.5" />
        {[
          { cx: 428, cy: 428 },
          { cx: 532, cy: 428 },
          { cx: 428, cy: 532 },
          { cx: 532, cy: 532 },
        ].map((pos, i) => (
          <g key={`yellow-ped-${i}`}>
            <circle cx={pos.cx} cy={pos.cy} r="26" fill="#1e1e2e" stroke="#F59E0B" strokeWidth="2.5" />
            <circle cx={pos.cx} cy={pos.cy} r="18" fill="#F59E0B" fillOpacity="0.25" />
          </g>
        ))}

        {/* Blue Yard (Bottom Left: 0..240, 360..600) */}
        <rect x="0" y="360" width="240" height="240" fill="url(#blueGrad)" />
        <rect x="28" y="388" width="184" height="184" rx="24" fill="url(#innerYard)" stroke="#3B82F6" strokeWidth="2.5" />
        {[
          { cx: 68, cy: 428 },
          { cx: 172, cy: 428 },
          { cx: 68, cy: 532 },
          { cx: 172, cy: 532 },
        ].map((pos, i) => (
          <g key={`blue-ped-${i}`}>
            <circle cx={pos.cx} cy={pos.cy} r="26" fill="#1e1e2e" stroke="#3B82F6" strokeWidth="2.5" />
            <circle cx={pos.cx} cy={pos.cy} r="18" fill="#3B82F6" fillOpacity="0.25" />
          </g>
        ))}

        {/* ==================== 52 TRACK CELLS ==================== */}
        {MAIN_PATH.map((cell, idx) => {
          const x = cell.col * CELL_SIZE;
          const y = cell.row * CELL_SIZE;
          const isSafe = SAFE_TRACK_INDICES.has(idx);

          // Color specific start cells
          let fill = '#1e293b';
          let stroke = '#334155';

          if (idx === 0) {
            fill = '#EF4444';
            stroke = '#DC2626';
          } else if (idx === 13) {
            fill = '#10B981';
            stroke = '#059669';
          } else if (idx === 26) {
            fill = '#F59E0B';
            stroke = '#D97706';
          } else if (idx === 39) {
            fill = '#3B82F6';
            stroke = '#2563EB';
          } else if (isSafe) {
            fill = '#262f45';
          }

          return (
            <g key={`track-cell-${idx}`}>
              <rect
                x={x}
                y={y}
                width={CELL_SIZE}
                height={CELL_SIZE}
                fill={fill}
                stroke={stroke}
                strokeWidth="1.2"
              />

              {/* Start square arrow icons */}
              {idx === 0 && (
                <path d={`M ${x + 12} ${y + 20} L ${x + 28} ${y + 20} M ${x + 22} ${y + 14} L ${x + 28} ${y + 20} L ${x + 22} ${y + 26}`} stroke="#FFF" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round" fill="none" />
              )}
              {idx === 13 && (
                <path d={`M ${x + 20} ${y + 12} L ${x + 20} ${y + 28} M ${x + 14} ${y + 22} L ${x + 20} ${y + 28} L ${x + 26} ${y + 22}`} stroke="#FFF" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round" fill="none" />
              )}
              {idx === 26 && (
                <path d={`M ${x + 28} ${y + 20} L ${x + 12} ${y + 20} M ${x + 18} ${y + 14} L ${x + 12} ${y + 20} L ${x + 18} ${y + 26}`} stroke="#FFF" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round" fill="none" />
              )}
              {idx === 39 && (
                <path d={`M ${x + 20} ${y + 28} L ${x + 20} ${y + 12} M ${x + 14} ${y + 18} L ${x + 20} ${y + 12} L ${x + 26} ${y + 18}`} stroke="#FFF" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round" fill="none" />
              )}

              {/* Star emblem on Safe Squares (8, 21, 34, 47) */}
              {[8, 21, 34, 47].includes(idx) && (
                <g transform={`translate(${x + 20}, ${y + 20}) scale(0.95)`}>
                  <polygon
                    points="0,-12 3.5,-4 12,-3.5 5.5,3 7.5,12 0,7 -7.5,12 -5.5,3 -12,-3.5 -3.5,-4"
                    fill="url(#goldGrad)"
                    stroke="#D97706"
                    strokeWidth="1.2"
                  />
                  <circle cx="0" cy="0" r="2.5" fill="#FFF" />
                </g>
              )}
            </g>
          );
        })}

        {/* ==================== 4 COLORED HOME PATHS ==================== */}
        {/* Red Home Path (row 7, cols 1..5) */}
        {HOME_PATHS.red.map((cell, idx) => (
          <rect
            key={`red-home-${idx}`}
            x={cell.col * CELL_SIZE}
            y={cell.row * CELL_SIZE}
            width={CELL_SIZE}
            height={CELL_SIZE}
            fill="#EF4444"
            stroke="#DC2626"
            strokeWidth="1.2"
          />
        ))}

        {/* Green Home Path (col 7, rows 1..5) */}
        {HOME_PATHS.green.map((cell, idx) => (
          <rect
            key={`green-home-${idx}`}
            x={cell.col * CELL_SIZE}
            y={cell.row * CELL_SIZE}
            width={CELL_SIZE}
            height={CELL_SIZE}
            fill="#10B981"
            stroke="#059669"
            strokeWidth="1.2"
          />
        ))}

        {/* Yellow Home Path (row 7, cols 9..13) */}
        {HOME_PATHS.yellow.map((cell, idx) => (
          <rect
            key={`yellow-home-${idx}`}
            x={cell.col * CELL_SIZE}
            y={cell.row * CELL_SIZE}
            width={CELL_SIZE}
            height={CELL_SIZE}
            fill="#F59E0B"
            stroke="#D97706"
            strokeWidth="1.2"
          />
        ))}

        {/* Blue Home Path (col 7, rows 9..13) */}
        {HOME_PATHS.blue.map((cell, idx) => (
          <rect
            key={`blue-home-${idx}`}
            x={cell.col * CELL_SIZE}
            y={cell.row * CELL_SIZE}
            width={CELL_SIZE}
            height={CELL_SIZE}
            fill="#3B82F6"
            stroke="#2563EB"
            strokeWidth="1.2"
          />
        ))}

        {/* ==================== CENTER GOAL AREA (3x3: 240..360) ==================== */}
        {/* Red Triangle */}
        <polygon points="240,240 300,300 240,360" fill="url(#redGrad)" stroke="#B91C1C" strokeWidth="2" />
        {/* Green Triangle */}
        <polygon points="240,240 360,240 300,300" fill="url(#greenGrad)" stroke="#047857" strokeWidth="2" />
        {/* Yellow Triangle */}
        <polygon points="360,240 360,360 300,300" fill="url(#yellowGrad)" stroke="#B45309" strokeWidth="2" />
        {/* Blue Triangle */}
        <polygon points="240,360 360,360 300,300" fill="url(#blueGrad)" stroke="#1D4ED8" strokeWidth="2" />

        {/* Center Golden Compass Medallion */}
        <circle cx="300" cy="300" r="22" fill="#0F172A" stroke="url(#goldGrad)" strokeWidth="3" />
        <circle cx="300" cy="300" r="14" fill="url(#goldGrad)" />
        <polygon points="300,288 304,297 312,300 304,303 300,312 296,303 288,300 296,297" fill="#FFF" />

        {/* ==================== TOKENS LAYER ==================== */}
        {players.map((player) => {
          if (!player.active) return null;

          return player.tokens.map((token) => {
            const isTurnPlayer = player.color === activeColor;
            const isMovable = isTurnPlayer && isHumanTurn && legalTokenIds.includes(token.id);
            const isAnimating =
              animatingToken?.color === player.color && animatingToken?.tokenId === token.id;

            // Get base coordinates
            const baseCoord = getTokenCoordinate(player.color, token.id, token.step);
            const center = getCellPixelCenter(baseCoord);

            // Compute stacking offset if multiple tokens are on this square
            const locKey = getLocationKey(player.color, token.id, token.step);
            const tokensOnSquare = locationGroups[locKey] || [];
            let offsetX = 0;
            let offsetY = 0;
            let tokenRadius = 17;

            if (tokensOnSquare.length > 1 && token.step !== -1) {
              const myIdx = tokensOnSquare.findIndex(
                (item) => item.color === player.color && item.token.id === token.id
              );
              tokenRadius = 13;
              if (tokensOnSquare.length === 2) {
                const shift = 8;
                offsetX = myIdx === 0 ? -shift : shift;
                offsetY = myIdx === 0 ? -shift : shift;
              } else if (tokensOnSquare.length === 3) {
                const shift = 9;
                if (myIdx === 0) {
                  offsetX = -shift;
                  offsetY = -shift;
                } else if (myIdx === 1) {
                  offsetX = shift;
                  offsetY = -shift;
                } else {
                  offsetX = 0;
                  offsetY = shift;
                }
              } else {
                const shift = 9;
                offsetX = (myIdx % 2 === 0 ? -shift : shift);
                offsetY = (myIdx < 2 ? -shift : shift);
              }
            }

            const posX = center.x + offsetX;
            const posY = center.y + offsetY;

            const radialId =
              player.color === 'red'
                ? 'url(#tokenRed)'
                : player.color === 'green'
                ? 'url(#tokenGreen)'
                : player.color === 'yellow'
                ? 'url(#tokenYellow)'
                : 'url(#tokenBlue)';

            return (
              <g
                key={`token-${player.color}-${token.id}`}
                transform={`translate(${posX}, ${posY})`}
                className={`transition-transform duration-200 ${
                  isMovable ? 'cursor-pointer' : ''
                }`}
                onClick={() => {
                  if (isMovable) {
                    onTokenClick(token.id);
                  }
                }}
              >
                {/* Glow & Pulse Ring for Movable Tokens */}
                {isMovable && (
                  <>
                    <circle
                      cx="0"
                      cy="0"
                      r={tokenRadius + 8}
                      fill="none"
                      stroke="#FACC15"
                      strokeWidth="3.5"
                      strokeDasharray="4 2"
                      className="animate-pulse-ring"
                    />
                    <circle
                      cx="0"
                      cy="0"
                      r={tokenRadius + 4}
                      fill="#FEF08A"
                      fillOpacity="0.3"
                      className="animate-ping"
                    />
                  </>
                )}

                {/* Animated token bounce */}
                <g className={isMovable ? 'animate-token-bounce' : isAnimating ? 'animate-token-land' : ''}>
                  {/* Token Body (3D Sphere with Shadow) */}
                  <circle
                    cx="0"
                    cy="0"
                    r={tokenRadius}
                    fill={radialId}
                    stroke="#FFFFFF"
                    strokeWidth={isMovable ? '2.5' : '1.8'}
                    filter="url(#tokenShadow)"
                  />

                  {/* Inner ring */}
                  <circle
                    cx="0"
                    cy="0"
                    r={tokenRadius * 0.58}
                    fill="none"
                    stroke="rgba(255, 255, 255, 0.45)"
                    strokeWidth="1.2"
                  />

                  {/* Center Emblem / Crown / Number */}
                  {token.step === 56 ? (
                    <text
                      x="0"
                      y="4"
                      textAnchor="middle"
                      fontSize={tokenRadius * 0.9}
                      fill="#FFF"
                      fontWeight="bold"
                    >
                      ★
                    </text>
                  ) : (
                    <circle cx="0" cy="0" r={tokenRadius * 0.28} fill="#FFF" fillOpacity="0.8" />
                  )}

                  {/* 3D Gloss Highlight */}
                  <ellipse
                    cx={-tokenRadius * 0.3}
                    cy={-tokenRadius * 0.35}
                    rx={tokenRadius * 0.35}
                    ry={tokenRadius * 0.22}
                    fill="#FFFFFF"
                    fillOpacity="0.75"
                    transform={`rotate(-25, ${-tokenRadius * 0.3}, ${-tokenRadius * 0.35})`}
                  />
                </g>
              </g>
            );
          });
        })}
      </svg>
    </div>
  );
};
