import React from 'react';
import { X, Play, Shield, Sparkles, RefreshCw, Trophy, Target } from 'lucide-react';
import { sounds } from '../utils/audio';

interface HowToPlayModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const HowToPlayModal: React.FC<HowToPlayModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/80 backdrop-blur-sm animate-fade-in">
      <div className="relative w-full max-w-lg bg-slate-900 border border-amber-500/40 rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="flex items-center justify-between p-4 sm:p-5 border-b border-slate-800 bg-gradient-to-r from-amber-500/10 via-slate-800 to-amber-500/10">
          <div className="flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-amber-400" />
            <h3 className="text-lg sm:text-xl font-bold font-cinzel text-amber-300">
              HOW TO PLAY ARS LUDO
            </h3>
          </div>
          <button
            onClick={() => {
              sounds.playClick();
              onClose();
            }}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
            aria-label="Close"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-4 sm:p-5 overflow-y-auto space-y-4 text-sm text-slate-300">
          {/* Rule 1: Leaving Yard */}
          <div className="flex items-start gap-3 bg-slate-800/60 p-3 rounded-xl border border-slate-700/50">
            <div className="w-8 h-8 rounded-lg bg-amber-500/20 text-amber-400 flex items-center justify-center shrink-0 font-bold border border-amber-500/40">
              6
            </div>
            <div>
              <h4 className="font-bold text-slate-100 flex items-center gap-1.5">
                Rolling a 6 to Enter
              </h4>
              <p className="text-xs text-slate-400 mt-0.5 leading-relaxed">
                Tokens start in their colored yard (Base). Rolling a <strong>6</strong> allows you to
                bring a token out onto your colored starting square, plus grants an <strong>extra roll</strong>!
              </p>
            </div>
          </div>

          {/* Rule 2: Movement */}
          <div className="flex items-start gap-3 bg-slate-800/60 p-3 rounded-xl border border-slate-700/50">
            <div className="w-8 h-8 rounded-lg bg-blue-500/20 text-blue-400 flex items-center justify-center shrink-0 border border-blue-500/40">
              <Play className="w-4 h-4" />
            </div>
            <div>
              <h4 className="font-bold text-slate-100 flex items-center gap-1.5">
                Clockwise Path
              </h4>
              <p className="text-xs text-slate-400 mt-0.5 leading-relaxed">
                Tokens advance clockwise around the 52-cell outer track according to the dice roll.
                Movable tokens pulse with a bright golden ring — just tap them to move!
              </p>
            </div>
          </div>

          {/* Rule 3: Safe Squares */}
          <div className="flex items-start gap-3 bg-slate-800/60 p-3 rounded-xl border border-slate-700/50">
            <div className="w-8 h-8 rounded-lg bg-yellow-500/20 text-yellow-400 flex items-center justify-center shrink-0 border border-yellow-500/40">
              <Shield className="w-4 h-4" />
            </div>
            <div>
              <h4 className="font-bold text-slate-100 flex items-center gap-1.5">
                Safe Star Squares
              </h4>
              <p className="text-xs text-slate-400 mt-0.5 leading-relaxed">
                Squares marked with a <strong>Golden Star</strong> and the 4 colored starting squares
                are <strong>Safe Zones</strong>. Tokens cannot be captured while resting on safe squares!
              </p>
            </div>
          </div>

          {/* Rule 4: Captures */}
          <div className="flex items-start gap-3 bg-slate-800/60 p-3 rounded-xl border border-slate-700/50">
            <div className="w-8 h-8 rounded-lg bg-red-500/20 text-red-400 flex items-center justify-center shrink-0 border border-red-500/40">
              <Target className="w-4 h-4" />
            </div>
            <div>
              <h4 className="font-bold text-slate-100 flex items-center gap-1.5">
                Capturing Opponents
              </h4>
              <p className="text-xs text-slate-400 mt-0.5 leading-relaxed">
                Landing on an opponent token on an unsafe square captures it and sends it straight back to its yard! Capturing an opponent also awards you a <strong>Bonus Turn</strong>!
              </p>
            </div>
          </div>

          {/* Rule 5: Bonus Turns */}
          <div className="flex items-start gap-3 bg-slate-800/60 p-3 rounded-xl border border-slate-700/50">
            <div className="w-8 h-8 rounded-lg bg-emerald-500/20 text-emerald-400 flex items-center justify-center shrink-0 border border-emerald-500/40">
              <RefreshCw className="w-4 h-4" />
            </div>
            <div>
              <h4 className="font-bold text-slate-100 flex items-center gap-1.5">
                Bonus Turns
              </h4>
              <p className="text-xs text-slate-400 mt-0.5 leading-relaxed">
                You get an extra dice roll whenever: you roll a <strong>6</strong>, you <strong>capture</strong> an opponent, or one of your tokens enters the <strong>Home Goal</strong>.
              </p>
            </div>
          </div>

          {/* Rule 6: Winning */}
          <div className="flex items-start gap-3 bg-slate-800/60 p-3 rounded-xl border border-slate-700/50">
            <div className="w-8 h-8 rounded-lg bg-amber-500/20 text-amber-300 flex items-center justify-center shrink-0 border border-amber-500/40">
              <Trophy className="w-4 h-4" />
            </div>
            <div>
              <h4 className="font-bold text-slate-100 flex items-center gap-1.5">
                Winning the Game
              </h4>
              <p className="text-xs text-slate-400 mt-0.5 leading-relaxed">
                Enter your colored Home column and reach the center triangle. An <strong>exact roll</strong> is required to step into the final Home Goal. The first player to bring all 4 tokens Home is crowned the Champion!
              </p>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-slate-800 bg-slate-950 flex justify-end">
          <button
            onClick={() => {
              sounds.playClick();
              onClose();
            }}
            className="w-full sm:w-auto px-6 py-2.5 rounded-xl font-bold bg-gradient-to-r from-amber-400 to-yellow-500 text-slate-950 hover:brightness-110 shadow-lg cursor-pointer transition-transform active:scale-95"
          >
            GOT IT, LET'S PLAY!
          </button>
        </div>
      </div>
    </div>
  );
};
