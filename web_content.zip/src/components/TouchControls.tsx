import React, { useRef, useState, useEffect, useCallback } from 'react';
import { Target, RefreshCw, Zap, ShieldAlert, ChevronRight, Crosshair } from 'lucide-react';
import { Weapon } from '../types/game';

interface TouchControlsProps {
  onMove: (dx: number, dy: number) => void;
  onAim: (angle: number) => void;
  onShootStart: () => void;
  onShootEnd: () => void;
  onReload: () => void;
  onJump: () => void;
  onSwitchWeapon: () => void;
  onUseItem: () => void;
  activeWeapon: Weapon;
  medkitCount: number;
  isReloading: boolean;
  canJump: boolean;
  jumpCooldown: number;
}

export const TouchControls: React.FC<TouchControlsProps> = ({
  onMove,
  onShootStart,
  onShootEnd,
  onReload,
  onJump,
  onSwitchWeapon,
  onUseItem,
  activeWeapon,
  medkitCount,
  isReloading,
  canJump,
  jumpCooldown
}) => {
  const joystickBaseRef = useRef<HTMLDivElement>(null);
  const [joystickActive, setJoystickActive] = useState(false);
  const [joystickPos, setJoystickPos] = useState({ x: 0, y: 0 });
  const [touchId, setTouchId] = useState<number | null>(null);

  const handleTouchStart = (e: React.TouchEvent) => {
    e.preventDefault();
    if (touchId !== null) return;
    const touch = e.changedTouches[0];
    setTouchId(touch.identifier);
    setJoystickActive(true);
    updateJoystick(touch.clientX, touch.clientY);
  };

  const updateJoystick = useCallback((clientX: number, clientY: number) => {
    if (!joystickBaseRef.current) return;
    const rect = joystickBaseRef.current.getBoundingClientRect();
    const centerX = rect.left + rect.width / 2;
    const centerY = rect.top + rect.height / 2;

    const dx = clientX - centerX;
    const dy = clientY - centerY;
    const dist = Math.sqrt(dx * dx + dy * dy);
    const maxDist = 44;

    if (dist <= maxDist) {
      setJoystickPos({ x: dx, y: dy });
      onMove(dx / maxDist, dy / maxDist);
    } else {
      const angle = Math.atan2(dy, dx);
      const nx = Math.cos(angle) * maxDist;
      const ny = Math.sin(angle) * maxDist;
      setJoystickPos({ x: nx, y: ny });
      onMove(nx / maxDist, ny / maxDist);
    }
  }, [onMove]);

  useEffect(() => {
    const handleTouchMoveWindow = (e: TouchEvent) => {
      if (touchId === null) return;
      for (let i = 0; i < e.changedTouches.length; i++) {
        if (e.changedTouches[i].identifier === touchId) {
          updateJoystick(e.changedTouches[i].clientX, e.changedTouches[i].clientY);
          break;
        }
      }
    };

    const handleTouchEndWindow = (e: TouchEvent) => {
      if (touchId === null) return;
      for (let i = 0; i < e.changedTouches.length; i++) {
        if (e.changedTouches[i].identifier === touchId) {
          setTouchId(null);
          setJoystickActive(false);
          setJoystickPos({ x: 0, y: 0 });
          onMove(0, 0);
          break;
        }
      }
    };

    window.addEventListener('touchmove', handleTouchMoveWindow, { passive: false });
    window.addEventListener('touchend', handleTouchEndWindow);
    window.addEventListener('touchcancel', handleTouchEndWindow);

    return () => {
      window.removeEventListener('touchmove', handleTouchMoveWindow);
      window.removeEventListener('touchend', handleTouchEndWindow);
      window.removeEventListener('touchcancel', handleTouchEndWindow);
    };
  }, [touchId, onMove, updateJoystick]);

  return (
    <div id="touch-controls-container" className="absolute inset-0 pointer-events-none z-30 select-none overflow-hidden">
      {/* Left Area: Virtual Joystick */}
      <div 
        className="absolute bottom-6 left-6 pointer-events-auto flex flex-col items-center"
      >
        <div
          ref={joystickBaseRef}
          id="virtual-joystick"
          onTouchStart={handleTouchStart}
          className={`w-28 h-28 rounded-full border-2 transition-colors flex items-center justify-center relative shadow-lg ${
            joystickActive 
              ? 'bg-slate-900/60 border-cyan-400 shadow-cyan-500/20' 
              : 'bg-slate-900/40 border-slate-700/60'
          }`}
        >
          {/* Inner stick */}
          <div
            className="w-12 h-12 rounded-full bg-gradient-to-tr from-cyan-600 to-sky-400 border border-white/60 shadow-md flex items-center justify-center transform"
            style={{
              transform: `translate(${joystickPos.x}px, ${joystickPos.y}px)`,
              transition: joystickActive ? 'none' : 'transform 0.15s ease-out'
            }}
          >
            <div className="w-4 h-4 rounded-full bg-white/40" />
          </div>

          {/* Directional marks */}
          <div className="absolute top-1 text-[10px] font-bold text-slate-500">W</div>
          <div className="absolute bottom-1 text-[10px] font-bold text-slate-500">S</div>
          <div className="absolute left-1.5 text-[10px] font-bold text-slate-500">A</div>
          <div className="absolute right-1.5 text-[10px] font-bold text-slate-500">D</div>
        </div>
        <span className="text-[11px] font-semibold text-slate-400 tracking-wider mt-1 uppercase">Move</span>
      </div>

      {/* Right Area: Action Buttons */}
      <div className="absolute bottom-6 right-6 pointer-events-auto flex flex-col items-end gap-3">
        {/* Top utility row: Weapon Switch, Medkit, Reload */}
        <div className="flex items-center gap-2">
          {/* Use Medkit / Item button */}
          <button
            id="mobile-heal-btn"
            onTouchStart={(e) => { e.preventDefault(); onUseItem(); }}
            className={`w-12 h-12 rounded-full border flex flex-col items-center justify-center shadow-lg active:scale-95 transition-transform ${
              medkitCount > 0 
                ? 'bg-emerald-950/80 border-emerald-500 text-emerald-300' 
                : 'bg-slate-900/60 border-slate-700 text-slate-500 opacity-60'
            }`}
          >
            <ShieldAlert size={18} />
            <span className="text-[9px] font-bold mt-0.5">{medkitCount}</span>
          </button>

          {/* Weapon Switch Button */}
          <button
            id="mobile-weapon-switch-btn"
            onTouchStart={(e) => { e.preventDefault(); onSwitchWeapon(); }}
            className="w-12 h-12 rounded-full bg-slate-900/80 border border-amber-500 text-amber-400 flex flex-col items-center justify-center shadow-lg active:scale-95 transition-transform"
          >
            <ChevronRight size={18} />
            <span className="text-[9px] font-bold truncate max-w-[40px]">SWAP</span>
          </button>

          {/* Reload Button */}
          <button
            id="mobile-reload-btn"
            onTouchStart={(e) => { e.preventDefault(); onReload(); }}
            disabled={isReloading}
            className={`w-12 h-12 rounded-full border flex flex-col items-center justify-center shadow-lg active:scale-95 transition-transform ${
              isReloading 
                ? 'bg-amber-950/80 border-amber-500 text-amber-300 animate-spin' 
                : 'bg-slate-900/80 border-sky-500 text-sky-400'
            }`}
          >
            <RefreshCw size={18} />
            <span className="text-[9px] font-bold mt-0.5">R</span>
          </button>
        </div>

        {/* Main Action Row: Jump / Dodge and Giant Shoot button */}
        <div className="flex items-center gap-3">
          {/* Jump / Dodge roll button */}
          <button
            id="mobile-jump-btn"
            onTouchStart={(e) => { e.preventDefault(); onJump(); }}
            disabled={!canJump}
            className={`w-14 h-14 rounded-full border flex flex-col items-center justify-center shadow-lg active:scale-95 transition-all ${
              canJump 
                ? 'bg-indigo-950/80 border-indigo-400 text-indigo-300 hover:bg-indigo-900' 
                : 'bg-slate-900/60 border-slate-800 text-slate-600'
            }`}
          >
            <Zap size={22} />
            <span className="text-[9px] font-bold mt-0.5">DODGE</span>
            {jumpCooldown > 0 && (
              <div 
                className="absolute inset-0 rounded-full border-2 border-indigo-500 opacity-40 animate-ping"
              />
            )}
          </button>

          {/* Shoot Button */}
          <button
            id="mobile-shoot-btn"
            onTouchStart={(e) => { e.preventDefault(); onShootStart(); }}
            onTouchEnd={(e) => { e.preventDefault(); onShootEnd(); }}
            className="w-20 h-20 rounded-full bg-gradient-to-tr from-rose-600 to-amber-500 border-2 border-white/80 text-white flex flex-col items-center justify-center shadow-xl shadow-rose-900/50 active:scale-95 transition-transform"
          >
            <Crosshair size={28} className="animate-pulse" />
            <span className="text-[11px] font-extrabold tracking-wider font-action mt-0.5">FIRE</span>
          </button>
        </div>
      </div>
    </div>
  );
};
