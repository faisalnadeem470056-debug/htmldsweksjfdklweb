import React, { useState, useEffect } from 'react';
import { X, Trophy, BarChart3, RotateCcw, Swords, ShieldCheck, Flame } from 'lucide-react';
import { GameStats } from '../types/game';
import { getStats, getMatchHistory, MatchRecord, resetAllStats } from '../utils/storage';
import { sounds } from '../utils/audio';

interface StatsModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const StatsModal: React.FC<StatsModalProps> = ({ isOpen, onClose }) => {
  const [stats, setStats] = useState<GameStats>(getStats());
  const [history, setHistory] = useState<MatchRecord[]>(getMatchHistory());
  const [confirmReset, setConfirmReset] = useState(false);

  useEffect(() => {
    if (isOpen) {
      setStats(getStats());
      setHistory(getMatchHistory());
      setConfirmReset(false);
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const winRate =
    stats.gamesPlayed > 0 ? Math.round((stats.gamesWon / stats.gamesPlayed) * 100) : 0;

  const handleReset = () => {
    sounds.playClick();
    resetAllStats();
    setStats(getStats());
    setHistory([]);
    setConfirmReset(false);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/80 backdrop-blur-sm animate-fade-in">
      <div className="relative w-full max-w-lg bg-slate-900 border border-amber-500/40 rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="flex items-center justify-between p-4 sm:p-5 border-b border-slate-800 bg-gradient-to-r from-amber-500/10 via-slate-800 to-amber-500/10">
          <div className="flex items-center gap-2">
            <Trophy className="w-5 h-5 text-amber-400" />
            <h3 className="text-lg sm:text-xl font-bold font-cinzel text-amber-300">
              ARS LUDO HALL OF FAME
            </h3>
          </div>
          <button
            onClick={() => {
              sounds.playClick();
              onClose();
            }}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
            aria-label="Close"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-4 sm:p-5 overflow-y-auto space-y-5">
          {/* Top Quick Metrics */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
            <div className="bg-slate-800/80 p-3 rounded-xl border border-slate-700/60 text-center">
              <span className="text-[11px] text-slate-400 font-medium block">Matches</span>
              <span className="text-xl font-black text-white">{stats.gamesPlayed}</span>
            </div>
            <div className="bg-slate-800/80 p-3 rounded-xl border border-amber-500/30 text-center">
              <span className="text-[11px] text-amber-400 font-medium block">Victories</span>
              <span className="text-xl font-black text-amber-400">{stats.gamesWon}</span>
            </div>
            <div className="bg-slate-800/80 p-3 rounded-xl border border-slate-700/60 text-center">
              <span className="text-[11px] text-slate-400 font-medium block">Win Rate</span>
              <span className="text-xl font-black text-emerald-400">{winRate}%</span>
            </div>
            <div className="bg-slate-800/80 p-3 rounded-xl border border-slate-700/60 text-center">
              <span className="text-[11px] text-slate-400 font-medium block flex items-center justify-center gap-1">
                <Flame className="w-3 h-3 text-orange-400" /> Streak
              </span>
              <span className="text-xl font-black text-orange-400">{stats.highestStreak}</span>
            </div>
          </div>

          {/* Color Victories Breakdown */}
          <div className="bg-slate-800/60 p-3.5 rounded-xl border border-slate-700/50">
            <h4 className="text-xs font-bold text-slate-300 uppercase tracking-wider mb-2.5 flex items-center gap-1.5">
              <BarChart3 className="w-4 h-4 text-amber-400" /> Victories By Color
            </h4>
            <div className="grid grid-cols-4 gap-2 text-center text-xs">
              <div className="bg-red-950/40 border border-red-500/40 p-2 rounded-lg">
                <span className="text-red-400 font-bold block">Red</span>
                <span className="text-lg font-black text-white">{stats.redWins}</span>
              </div>
              <div className="bg-emerald-950/40 border border-emerald-500/40 p-2 rounded-lg">
                <span className="text-emerald-400 font-bold block">Green</span>
                <span className="text-lg font-black text-white">{stats.greenWins}</span>
              </div>
              <div className="bg-amber-950/40 border border-amber-500/40 p-2 rounded-lg">
                <span className="text-amber-400 font-bold block">Yellow</span>
                <span className="text-lg font-black text-white">{stats.yellowWins}</span>
              </div>
              <div className="bg-blue-950/40 border border-blue-500/40 p-2 rounded-lg">
                <span className="text-blue-400 font-bold block">Blue</span>
                <span className="text-lg font-black text-white">{stats.blueWins}</span>
              </div>
            </div>
          </div>

          {/* In-Game Action Stats */}
          <div className="grid grid-cols-2 gap-2.5 text-xs">
            <div className="bg-slate-800/50 p-3 rounded-xl border border-slate-700/50 flex items-center gap-3">
              <div className="p-2 bg-red-500/20 text-red-400 rounded-lg">
                <Swords className="w-4 h-4" />
              </div>
              <div>
                <span className="text-slate-400 block text-[11px]">Captures Made</span>
                <span className="text-base font-bold text-white">{stats.tokensCaptured}</span>
              </div>
            </div>

            <div className="bg-slate-800/50 p-3 rounded-xl border border-slate-700/50 flex items-center gap-3">
              <div className="p-2 bg-emerald-500/20 text-emerald-400 rounded-lg">
                <ShieldCheck className="w-4 h-4" />
              </div>
              <div>
                <span className="text-slate-400 block text-[11px]">Tokens Reached Goal</span>
                <span className="text-base font-bold text-white">{stats.tokensHome}</span>
              </div>
            </div>
          </div>

          {/* Recent Match History */}
          <div>
            <h4 className="text-xs font-bold text-slate-300 uppercase tracking-wider mb-2 flex items-center gap-1.5">
              Recent Matches
            </h4>
            {history.length === 0 ? (
              <p className="text-xs text-slate-500 italic text-center py-4 bg-slate-800/30 rounded-xl">
                No matches recorded yet. Play your first match!
              </p>
            ) : (
              <div className="space-y-1.5 max-h-40 overflow-y-auto pr-1">
                {history.map((m) => (
                  <div
                    key={m.id}
                    className="flex items-center justify-between p-2 rounded-lg bg-slate-800/40 border border-slate-700/40 text-xs"
                  >
                    <div className="flex items-center gap-2">
                      <span
                        className="w-2.5 h-2.5 rounded-full"
                        style={{
                          backgroundColor:
                            m.winnerColor === 'red'
                              ? '#EF4444'
                              : m.winnerColor === 'green'
                              ? '#10B981'
                              : m.winnerColor === 'yellow'
                              ? '#F59E0B'
                              : '#3B82F6',
                        }}
                      />
                      <span className="font-semibold text-white">{m.winnerName} won</span>
                      <span className="text-[10px] text-slate-400">({m.mode})</span>
                    </div>
                    <div className="text-right text-[10px] text-slate-400">
                      <span>{m.turns} turns</span>
                      <span className="mx-1">•</span>
                      <span>{m.date}</span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-slate-800 bg-slate-950 flex items-center justify-between">
          {confirmReset ? (
            <div className="flex items-center gap-2">
              <span className="text-xs text-red-400">Confirm reset?</span>
              <button
                onClick={handleReset}
                className="px-3 py-1.5 bg-red-600 hover:bg-red-500 text-white text-xs font-bold rounded-lg cursor-pointer transition-colors"
              >
                Yes, Reset
              </button>
              <button
                onClick={() => setConfirmReset(false)}
                className="px-3 py-1.5 bg-slate-700 hover:bg-slate-600 text-slate-200 text-xs rounded-lg cursor-pointer"
              >
                Cancel
              </button>
            </div>
          ) : (
            <button
              onClick={() => setConfirmReset(true)}
              className="flex items-center gap-1.5 text-xs text-slate-400 hover:text-red-400 transition-colors cursor-pointer"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              Reset Stats
            </button>
          )}

          <button
            onClick={() => {
              sounds.playClick();
              onClose();
            }}
            className="px-5 py-2 rounded-xl font-bold bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs cursor-pointer transition-colors"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
