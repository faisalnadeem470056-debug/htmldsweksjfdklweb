import { MapTheme, Weapon, WeaponType, GameSettings, PlayerStats } from '../types/game';

export const MAP_THEMES: MapTheme[] = [
  {
    id: 'city',
    name: 'Neo City Outskirts',
    levels: [1, 10],
    bgColor: '#1e293b',
    groundColor: '#334155',
    gridColor: '#475569',
    obstacleColor: '#64748b',
    accentColor: '#38bdf8',
    description: 'Urban combat zones filled with barricades and asphalt streetways.',
    bossName: 'Goliath Brute (Lv 10)'
  },
  {
    id: 'village',
    name: 'Abandoned Village',
    levels: [11, 20],
    bgColor: '#292524',
    groundColor: '#44403c',
    gridColor: '#57534e',
    obstacleColor: '#78716c',
    accentColor: '#f59e0b',
    description: 'Old wooden cottages, fences, and rural zombie horde ambushes.',
    bossName: 'Venom Stalker (Lv 20)'
  },
  {
    id: 'desert',
    name: 'Scorched Desert',
    levels: [21, 30],
    bgColor: '#451a03',
    groundColor: '#78350f',
    gridColor: '#92400e',
    obstacleColor: '#b45309',
    accentColor: '#fbbf24',
    description: 'Golden dunes and jagged sandstone canyons under scorching heat.',
    bossName: 'Dune Ravager (Lv 30)'
  },
  {
    id: 'forest',
    name: 'Emerald Forest',
    levels: [31, 40],
    bgColor: '#064e3b',
    groundColor: '#065f46',
    gridColor: '#047857',
    obstacleColor: '#059669',
    accentColor: '#10b981',
    description: 'Dense woodland trails, mossy boulders, and fast ambushing mutants.',
    bossName: 'Primal Behemoth (Lv 40)'
  },
  {
    id: 'factory',
    name: 'Cyber Factory',
    levels: [41, 50],
    bgColor: '#1c1917',
    groundColor: '#292524',
    gridColor: '#44403c',
    obstacleColor: '#ea580c',
    accentColor: '#f97316',
    description: 'Hazardous industrial complex with steam pipes and fuel reserves.',
    bossName: 'Cyber-Mech Zombie (Lv 50)'
  },
  {
    id: 'military',
    name: 'Fortress Military Base',
    levels: [51, 60],
    bgColor: '#14532d',
    groundColor: '#166534',
    gridColor: '#15803d',
    obstacleColor: '#22c55e',
    accentColor: '#84cc16',
    description: 'Reinforced bunker perimeter, armored supply crates, and heavy resistance.',
    bossName: 'Titan Commando (Lv 60)'
  },
  {
    id: 'snow',
    name: 'Frozen Tundra',
    levels: [61, 70],
    bgColor: '#0f172a',
    groundColor: '#1e3a8a',
    gridColor: '#2563eb',
    obstacleColor: '#60a5fa',
    accentColor: '#38bdf8',
    description: 'Blizzard-swept mountain plains with ice stalagmites and freezing winds.',
    bossName: 'Frost Colossus (Lv 70)'
  },
  {
    id: 'lab',
    name: 'Bio-Hazard Lab',
    levels: [71, 80],
    bgColor: '#3b0764',
    groundColor: '#581c87',
    gridColor: '#6b21a8',
    obstacleColor: '#a855f7',
    accentColor: '#c084fc',
    description: 'Subterranean mutant research facility filled with toxic bio-containment cells.',
    bossName: 'Bio-Abomination (Lv 80)'
  },
  {
    id: 'arena',
    name: 'Doomsday Arena',
    levels: [81, 100],
    bgColor: '#450a0a',
    groundColor: '#7f1d1d',
    gridColor: '#991b1b',
    obstacleColor: '#ef4444',
    accentColor: '#f43f5e',
    description: 'The final battleground where the zombie contagion source awaits execution.',
    bossName: 'THE APEX DOOMSDAY TITAN (Lv 100)'
  }
];

export const INITIAL_WEAPONS: Record<WeaponType, Weapon> = {
  pistol: {
    id: 'pistol',
    name: 'P-99 Combat Eagle',
    category: 'Handgun',
    damage: 28,
    fireRate: 4,
    magSize: 12,
    currentAmmo: 12,
    reserveAmmo: 999, // Infinite backup
    reloadTime: 1.2,
    range: 650,
    bulletSpeed: 950,
    spread: 0.04,
    pellets: 1,
    cost: 0,
    unlocked: true,
    upgradeLevel: 1,
    maxUpgradeLevel: 5,
    color: '#e2e8f0',
    description: 'Reliable sidearm with pinpoint precision and unlimited reserve ammunition.'
  },
  shotgun: {
    id: 'shotgun',
    name: 'Striker-12 Shotgun',
    category: 'Shotgun',
    damage: 22, // per pellet (x6 = 132 close range)
    fireRate: 1.4,
    magSize: 8,
    currentAmmo: 8,
    reserveAmmo: 64,
    reloadTime: 2.0,
    range: 480,
    bulletSpeed: 780,
    spread: 0.22,
    pellets: 6,
    cost: 450,
    unlocked: false,
    upgradeLevel: 1,
    maxUpgradeLevel: 5,
    color: '#fb923c',
    description: 'Devastating close-range crowd clearing with heavy kinetic knockback.'
  },
  rifle: {
    id: 'rifle',
    name: 'AK-Titan Tactical',
    category: 'Assault Rifle',
    damage: 42,
    fireRate: 8.5,
    magSize: 30,
    currentAmmo: 30,
    reserveAmmo: 180,
    reloadTime: 1.8,
    range: 750,
    bulletSpeed: 1050,
    spread: 0.06,
    pellets: 1,
    cost: 1200,
    unlocked: false,
    upgradeLevel: 1,
    maxUpgradeLevel: 5,
    color: '#38bdf8',
    description: 'Rapid-firing automatic rifle with unmatched mid-range suppression.'
  },
  sniper: {
    id: 'sniper',
    name: 'Ghost Rail Sniper',
    category: 'Sniper Rifle',
    damage: 240,
    fireRate: 1.1,
    magSize: 5,
    currentAmmo: 5,
    reserveAmmo: 30,
    reloadTime: 2.4,
    range: 1200,
    bulletSpeed: 1600,
    spread: 0.01,
    pellets: 1,
    cost: 2500,
    unlocked: false,
    upgradeLevel: 1,
    maxUpgradeLevel: 5,
    color: '#a855f7',
    description: 'High-caliber anti-material rounds that slice clean through multiple targets.'
  },
  machinegun: {
    id: 'machinegun',
    name: 'Vulcan Minigun',
    category: 'Heavy Machine Gun',
    damage: 36,
    fireRate: 14,
    magSize: 100,
    currentAmmo: 100,
    reserveAmmo: 400,
    reloadTime: 3.2,
    range: 700,
    bulletSpeed: 980,
    spread: 0.12,
    pellets: 1,
    cost: 5000,
    unlocked: false,
    upgradeLevel: 1,
    maxUpgradeLevel: 5,
    color: '#f43f5e',
    description: 'Unleashes a relentless storm of lead. Ideal for decimating massive hordes.'
  },
  special: {
    id: 'special',
    name: 'Plasma Blaster FX-10',
    category: 'Special Prototype',
    damage: 180,
    fireRate: 2.2,
    magSize: 15,
    currentAmmo: 15,
    reserveAmmo: 60,
    reloadTime: 2.2,
    range: 850,
    bulletSpeed: 820,
    spread: 0.03,
    pellets: 1,
    cost: 10000,
    unlocked: false,
    upgradeLevel: 1,
    maxUpgradeLevel: 5,
    color: '#10b981',
    description: 'Experimental plasma accelerator firing exploding bio-energy spheres.'
  }
};

export const DEFAULT_PLAYER_STATS: PlayerStats = {
  hp: 100,
  maxHp: 100,
  shield: 50,
  maxShield: 50,
  speed: 240,
  coins: 100,
  xp: 0,
  level: 1,
  highestLevelUnlocked: 1,
  stars: {},
  perks: {
    maxHealthLevel: 1,
    armorLevel: 1,
    speedLevel: 1,
    coinMagnetLevel: 1,
    critChanceLevel: 1
  },
  inventory: ['pistol'],
  equippedWeapon: 'pistol'
};

export const DEFAULT_SETTINGS: GameSettings = {
  soundEnabled: true,
  musicEnabled: true,
  soundVolume: 0.8,
  musicVolume: 0.6,
  graphicsQuality: 'high',
  sensitivity: 1.0,
  aimAssist: true,
  touchControls: true
};

export const BOSS_LEVELS = [10, 20, 30, 40, 50, 60, 70, 80, 90, 100];

export function getMapThemeForLevel(level: number): MapTheme {
  const theme = MAP_THEMES.find(t => level >= t.levels[0] && level <= t.levels[1]);
  return theme || MAP_THEMES[MAP_THEMES.length - 1];
}

export function isBossLevel(level: number): boolean {
  return BOSS_LEVELS.includes(level);
}

export function getLevelDetails(level: number) {
  const isBoss = isBossLevel(level);
  const theme = getMapThemeForLevel(level);
  
  // Progression formulas:
  // Zombie count scales progressively from ~14 to ~85 (plus boss)
  const baseCount = Math.floor(12 + (level * 0.75));
  const totalZombies = isBoss ? Math.max(10, Math.floor(baseCount * 0.6)) : baseCount;
  
  // HP scaling:
  const hpMultiplier = 1 + (level - 1) * 0.055;
  // Speed scaling:
  const speedMultiplier = Math.min(1.65, 1 + (level - 1) * 0.007);
  // Damage scaling:
  const damageMultiplier = 1 + (level - 1) * 0.045;
  
  // Coin and XP rewards
  const rewardCoins = Math.floor(150 + level * 28 + (isBoss ? 400 : 0));
  const rewardXp = Math.floor(80 + level * 20 + (isBoss ? 250 : 0));

  return {
    level,
    isBoss,
    theme,
    totalZombies,
    hpMultiplier,
    speedMultiplier,
    damageMultiplier,
    rewardCoins,
    rewardXp,
    bossName: isBoss ? theme.bossName : null
  };
}
