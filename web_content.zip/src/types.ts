/**
 * IMAX Smart Academy - Core Types and Models
 * تیزهوشان آی‌مکس
 */

export type UserRole = 'student' | 'parent' | 'teacher' | 'admin';

export interface User {
  id: string;
  name: string;
  fullName?: string;
  phone: string;
  role: UserRole;
  avatar?: string;
  createdAt?: string;
}

export interface Teacher {
  teacherId: string;
  name: string; // e.g. "عباسی" or "مرحمتی"
  fullName: string; // e.g. "استاد یامین عباسی" or "استاد علیرضا مرحمتی"
  assignedClasses: string[]; // classId[]
  phone: string;
  subject: string; // e.g. "هوش تحلیلی و ریاضیات" or "علوم تجربی، سرعت و دقت"
  photo: string;
}

export type GradeLevel = 3 | 4 | 5 | 6 | 9;

export const GRADE_CONFIG: Record<GradeLevel, { title: string; isJointTeaching: boolean; description: string }> = {
  3: {
    title: 'پایه سوم ابتدایی',
    isJointTeaching: false,
    description: 'کلاس‌های مستقل هر مدرس (تقویت پایه، ریاضیات و درک مطلب)'
  },
  4: {
    title: 'پایه چهارم ابتدایی',
    isJointTeaching: false,
    description: 'کلاس‌های مستقل هر مدرس (مقدمات هوش و تفکر حل مسئله)'
  },
  5: {
    title: 'پایه پنجم (آمادگی تیزهوشان)',
    isJointTeaching: true,
    description: 'تدریس مشترک عباسی (محاسباتی) و مرحمتی (کلامی)'
  },
  6: {
    title: 'پایه ششم تیزهوشان',
    isJointTeaching: true,
    description: 'تدریس مشترک عباسی (محاسباتی و خلاقیت) و مرحمتی (کلامی و منطقی)'
  },
  9: {
    title: 'پایه نهم تیزهوشان',
    isJointTeaching: true,
    description: 'تدریس مشترک عباسی (ریاضی و تحلیلی) و مرحمتی (کلامی و منطقی)'
  }
};

export interface ClassItem {
  classId: string;
  className: string;
  grade: GradeLevel;
  teacherId: string; // Abbasi or Marhamati
  isJointTeaching?: boolean; // true for grades 5, 6, 9 where Abbasi & Marhamati teach together
  schedule: string;
  students: string[]; // studentId[]
}

export interface Student {
  studentId: string;
  fullName: string;
  photo: string;
  grade: GradeLevel;
  parentPhone: string;
  classId: string;
  nationalCode: string;
  activeCycleSessions: number; // Count of sessions in current cycle (0..8+)
  currentCycleNumber: number; // Cycle count (1, 2, 3...)
}

export interface SessionItem {
  sessionId: string;
  classId: string;
  className: string;
  teacherId: string;
  teacherName: string;
  PersianDate: string; // e.g. "1405/07/10"
  time: string; // e.g. "16:30"
  sessionNumber: number;
  topic?: string;
}

export interface PaymentItem {
  paymentId: string;
  studentId: string;
  studentName: string;
  amount: number; // in Tomans
  paymentStatus: 'confirmed' | 'pending' | 'overdue';
  cycleNumber: number;
  paymentDate: string; // ISO
  PersianDate: string;
  confirmedBy?: string;
}

// Exam System Types
export type PerformanceLevel = 'عالی' | 'خوب' | 'قابل قبول' | 'نیازمند تلاش';

export interface SixthGradeBooklet1Score {
  totalQuestions: 60;
  coefficient: 3;
  correct: number;
  wrong: number;
  blank: number;
  percentage: number;
  rawScore: number;
  tScore: number;
}

export interface SixthGradeBooklet2Score {
  totalQuestions: 60;
  coefficient: 1;
  correct: number;
  wrong: number;
  blank: number;
  percentage: number;
  rawScore: number;
  tScore: number;
}

export interface NinthGradeSubjectScore {
  key: string;
  titleFa: string;
  questionsCount: number;
  correct: number;
  wrong: number;
  blank: number;
  percentage: number;
  level: PerformanceLevel;
}

export interface AIAnalysis {
  summary: string;
  comparisonToPrevious: string; // e.g. "رشد ۱۵٪ نسبت به آزمون مرحله ۲"
  strengths: string[];
  weaknesses: string[];
  studySuggestions: string[];
}

export interface ExamResult {
  resultId: string;
  studentId: string;
  examId: string;
  grade: 6 | 9;
  examTitle: string;
  examDate: string;
  PersianDate: string;
  
  // Grade 6 details (if grade 6)
  sixthGrade?: {
    booklet1: SixthGradeBooklet1Score; // Analytical Intelligence
    booklet2: SixthGradeBooklet2Score; // Speed & Accuracy
  };

  // Grade 9 details (if grade 9)
  ninthGrade?: {
    booklet1: {
      totalQuestions: 75;
      subjects: Record<string, NinthGradeSubjectScore>;
      totalPercentage: number;
      score: number;
    };
    booklet2: {
      totalQuestions: 50; // Analytical Intelligence
      correct: number;
      wrong: number;
      blank: number;
      percentage: number;
      score: number;
    };
  };

  // Overall metrics
  totalPercentage: number;
  totalScore: number;
  tScore: number;
  rank: number; // Rank in grade
  totalParticipants: number;
  percentile: number;
  analysis: AIAnalysis;
}

export interface ExamDefinition {
  examId: string;
  title: string;
  grade: 6 | 9;
  examDate: string;
  PersianDate: string;
  totalQuestions: number;
}

// Payment warning status rule
export type PaymentCycleStatus = 'active' | 'approaching' | 'due';
