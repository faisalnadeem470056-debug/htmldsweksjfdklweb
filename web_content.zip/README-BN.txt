Digonto Mozumdar — Offline App Project

এই অ্যাপের ওয়েবসাইটের HTML/CSS/JavaScript ও embedded images APK-এর assets-এর মধ্যে আছে।
অ্যাপটি file:///android_asset/index.html খুলে, তাই ওয়েবসাইটের জন্য ইন্টারনেট দরকার নেই।

AndroidIDE-তে root folder Open Project করে Build APK করুন।
