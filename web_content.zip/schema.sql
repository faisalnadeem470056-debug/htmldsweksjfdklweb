CREATE EXTENSION IF NOT EXISTS pgcrypto;

CREATE TABLE IF NOT EXISTS company_settings (
  id text PRIMARY KEY,
  data jsonb NOT NULL,
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS users (
  id text PRIMARY KEY,
  name text NOT NULL,
  role text NOT NULL,
  active boolean NOT NULL DEFAULT true,
  pin_hash text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS sessions (
  id text PRIMARY KEY,
  user_id text NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  token_hash text NOT NULL UNIQUE,
  expires_at timestamptz NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_sessions_token ON sessions(token_hash);

CREATE TABLE IF NOT EXISTS governorates (
  code text PRIMARY KEY,
  name_en text NOT NULL,
  name_ar text NOT NULL,
  name_fr text NOT NULL,
  name_it text NOT NULL
);

CREATE TABLE IF NOT EXISTS records (
  id text PRIMARY KEY,
  resource text NOT NULL,
  data jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_by text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_records_resource ON records(resource);
CREATE INDEX IF NOT EXISTS idx_records_data_gin ON records USING gin(data);

CREATE TABLE IF NOT EXISTS audit_logs (
  id text PRIMARY KEY,
  user_id text,
  user_name text,
  action text NOT NULL,
  entity text NOT NULL,
  entity_id text,
  meta jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_audit_created ON audit_logs(created_at DESC);

CREATE TABLE IF NOT EXISTS knowledge_documents (
  id text PRIMARY KEY,
  title text NOT NULL,
  content text NOT NULL,
  language text NOT NULL DEFAULT 'ar',
  source text,
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_knowledge_fts ON knowledge_documents USING gin(to_tsvector('simple', content));

INSERT INTO company_settings(id,data) VALUES ('company', '{"name":"B-Touristic","brand":"B-Touristic / BTouristic","owner":"الأستاذ محمد موسي","email":"mohamed.moussa@btouristic.com","phones":["01148535084","01099091108","01010223978"],"website":"btouristic.com","address":"مصر - الجيزة"}'::jsonb)
ON CONFLICT (id) DO UPDATE SET data=EXCLUDED.data, updated_at=now();

INSERT INTO governorates(code,name_en,name_ar,name_fr,name_it) VALUES
('CAI','Cairo','القاهرة','Le Caire','Il Cairo'),('GIZ','Giza','الجيزة','Gizeh','Giza'),('ALX','Alexandria','الإسكندرية','Alexandrie','Alessandria'),('QLY','Qalyubia','القليوبية','Qalyubia','Qalyubia'),('PSD','Port Said','بورسعيد','Port-Saïd','Porto Said'),('SUE','Suez','السويس','Suez','Suez'),('DMT','Damietta','دمياط','Damiette','Damietta'),('DKH','Dakahlia','الدقهلية','Dakahlia','Dakahlia'),('SHR','Sharqia','الشرقية','Sharqia','Sharqia'),('KFS','Kafr El Sheikh','كفر الشيخ','Kafr el-Cheikh','Kafr El Sheikh'),('GHB','Gharbia','الغربية','Gharbia','Gharbia'),('MNF','Monufia','المنوفية','Monufia','Monufia'),('BHR','Beheira','البحيرة','Beheira','Beheira'),('ISM','Ismailia','الإسماعيلية','Ismaïlia','Ismailia'),('NSN','North Sinai','شمال سيناء','Sinaï du Nord','Sinai Settentrionale'),('SSN','South Sinai','جنوب سيناء','Sinaï du Sud','Sinai Meridionale'),('RED','Red Sea','البحر الأحمر','Mer Rouge','Mar Rosso'),('FYM','Fayoum','الفيوم','Fayoum','Fayyum'),('BNS','Beni Suef','بني سويف','Beni Souef','Beni Suef'),('MNJ','Minya','المنيا','Minya','Minya'),('AST','Asyut','أسيوط','Assiout','Asyut'),('SHG','Sohag','سوهاج','Sohag','Sohag'),('QNA','Qena','قنا','Qena','Qena'),('LXR','Luxor','الأقصر','Louxor','Luxor'),('ASN','Aswan','أسوان','Assouan','Aswan'),('WAD','New Valley','الوادي الجديد','Nouvelle-Vallée','Nuova Valle'),('MTR','Matrouh','مطروح','Matrouh','Matruh')
ON CONFLICT (code) DO NOTHING;

INSERT INTO knowledge_documents(id,title,content,language,source) VALUES
('KB-COMPANY','B-Touristic Company Profile','B-Touristic / BTouristic is a full-service Egyptian tourism agency. Owner and founder: الأستاذ محمد موسي. Address: Egypt - Giza. Email: mohamed.moussa@btouristic.com. Phones: 01148535084, 01099091108, 01010223978. Website: btouristic.com. Services include customized travel programs, group and individual packages, hotel bookings, transportation, guided tours, cultural experiences, corporate travel and events.','en','company-master-data'),
('KB-COMPANY-AR','بيانات شركة B-Touristic','شركة B-Touristic / BTouristic وكالة سفر متكاملة الخدمات في مصر. المالك والمؤسس: الأستاذ محمد موسي. المقر: مصر - الجيزة. البريد: mohamed.moussa@btouristic.com. الهواتف: 01148535084 و01099091108 و01010223978. الموقع: btouristic.com. الخدمات تشمل برامج سفر مخصصة، باقات جماعية وفردية، حجوزات الفنادق والنقل، الجولات والرحلات الثقافية، وسفر الشركات والفعاليات.','ar','company-master-data')
ON CONFLICT (id) DO UPDATE SET content=EXCLUDED.content, updated_at=now();
