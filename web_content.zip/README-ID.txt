KALKULATOR PRODUKSI ROTI - PROJECT ANDROID OFFLINE

Cara membuat APK:
1. Install Android Studio.
2. Buka folder KalkulatorProduksiRotiAndroid ini sebagai project.
3. Tunggu Gradle selesai sync.
4. Pilih Build > Build APK(s).
5. APK debug biasanya berada di app/build/outputs/apk/debug/app-debug.apk

Aplikasi menggunakan index.html V9 yang sudah tertanam di assets.
Aplikasi tidak membutuhkan internet untuk menjalankan kalkulator.
