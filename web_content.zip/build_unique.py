from PIL import Image, ImageEnhance, ImageFilter, ImageOps, ImageDraw
from pathlib import Path
import random, math, json
root=Path('/mnt/data/fixreal'); p=root/'index.html'
text=p.read_text(); a=text.find('P=[')+2
arr,_=json.JSONDecoder().raw_decode(text[a:])
srcdir=root/'images'/'realistic'; out=srcdir/'phrases'; out.mkdir(exist_ok=True)
mapcat={'Motivacional':'motivacional','Românticas':'romanticas','Perdão':'religiao','Distância':'distancia','Religião':'religiao','Fany':'fany','Bom dia':'bom_dia','Boa noite':'boa_noite','Saudade':'saudade','Compromisso':'compromisso','Amizade':'amizade','Esperança':'esperanca'}
base={k:Image.open(srcdir/(v+'.jpg')).convert('RGB') for k,v in mapcat.items()}
# Make 12 category-specific variants, each phrase gets its own independent render.
W,H=720,480
allims=list(base.values())
def crop(im,cx,cy,zoom):
    w,h=im.size; cw=min(w,int(w/zoom)); ch=min(h,int(cw*H/W))
    if ch>h: ch=h; cw=min(w,int(ch*W/H))
    l=max(0,min(w-cw,int((w-cw)*cx))); t=max(0,min(h-ch,int((h-ch)*cy)))
    return im.crop((l,t,l+cw,t+ch)).resize((W,H),Image.Resampling.LANCZOS)
for idx,item in enumerate(arr):
    rng=random.Random(12031+idx*104729)
    cat=item['category']; aimg=crop(base[cat],rng.random(),rng.random(),rng.uniform(1.0,1.5))
    if rng.random()<.25: aimg=ImageOps.mirror(aimg)
    # subtle secondary photographic atmosphere; not a repeated image, but a unique composite
    bimg=crop(allims[(idx*11+5)%len(allims)],rng.random(),rng.random(),rng.uniform(1.0,1.35))
    mask=Image.new('L',(W,H),0); d=ImageDraw.Draw(mask)
    mode=idx%4; strength=16+(idx%19)
    if mode==0: d.rectangle((0,0,W//2,H),fill=strength)
    elif mode==1: d.rectangle((W//2,0,W,H),fill=strength)
    elif mode==2: d.rectangle((0,0,W,H//2),fill=strength)
    else: d.rectangle((0,H//2,W,H),fill=strength)
    aimg=Image.composite(bimg,aimg,mask)
    aimg=ImageEnhance.Contrast(aimg).enhance(.90+(idx%17)/100)
    aimg=ImageEnhance.Color(aimg).enhance(.90+(idx%23)/100)
    aimg=ImageEnhance.Brightness(aimg).enhance(.94+(idx%13)/100)
    if idx%7==0: aimg=aimg.filter(ImageFilter.GaussianBlur(.25))
    # Unique vignette per image
    vig=Image.new('L',(W,H),255); vp=vig.load(); s=8+(idx%21)
    for y in range(H):
      yy=(y-H/2)/(H/2)
      for x in range(W):
        xx=(x-W/2)/(W/2); r=min(1,math.sqrt(xx*xx+yy*yy)/1.414); vp[x,y]=255-int(s*r*r)
    dark=ImageEnhance.Brightness(aimg).enhance(.80)
    aimg=Image.composite(aimg,dark,ImageOps.invert(vig))
    q=70+(idx%9)
    aimg.save(out/f'{idx}.jpg','JPEG',quality=q,optimize=True,subsampling=2)
# patch image() to use unique per phrase
start=text.find('function image('); end=text.find('\nfunction card',start)
new="function image(c,i){return `images/realistic/phrases/${i}.jpg`}"
text=text[:start]+new+text[end:]
p.write_text(text)
print('generated',len(arr),'unique phrase images')
