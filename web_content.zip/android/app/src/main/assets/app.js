const $=id=>document.getElementById(id);
let db=JSON.parse(localStorage.studyPlanner||'{"tasks":[],"goals":[],"books":[],"logs":[],"current":0}');
let state={book:null,page:1,pdf:null,running:false,start:0,elapsed:0,interval:null,pageTimer:null};
const fa=n=>String(n).replace(/\d/g,d=>'۰۱۲۳۴۵۶۷۸۹'[d]);
function save(){localStorage.studyPlanner=JSON.stringify(db);render();}
function now(){return new Date().toISOString().slice(0,10)}
function render(){
 $('today').textContent='امروز: '+fa(now());
 $('tasks').innerHTML=db.tasks.map((t,i)=>`<div class="item ${t.done?'done':''}"><input type="checkbox" ${t.done?'checked':''} onchange="toggleTask(${i})"><span>${t.text} <span class="small">${t.min||0} دقیقه</span></span><button onclick="delTask(${i})">حذف</button></div>`).join('');
 $('homeTasks').innerHTML=db.tasks.map((t,i)=>`<div class="item ${t.done?'done':''}"><input type="checkbox" ${t.done?'checked':''} onchange="toggleTask(${i})">${t.text}</div>`).join('')||'فعالیتی ثبت نشده.';
 $('goals').innerHTML=db.goals.map((g,i)=>{let p=Math.min(100,Math.round((g.done/g.target)*100)||0);return `<div class="item"><b>${g.text}</b><span>${fa(g.done)}/${fa(g.target)} — ${fa(p)}٪</span><button onclick="goalDone(${i})">+۱</button></div>`}).join('');
 $('books').innerHTML=db.books.map((b,i)=>`<div class="item"><span>📖 ${b.name}<br><span class="small">${fa(b.pages||'?')} صفحه | صفحه آخر: ${fa(b.lastPage||1)}</span></span><button onclick="selectBook(${i})">مطالعه</button></div>`).join('')||'هنوز کتابی اضافه نشده.';
 let logs=db.logs; $('dTime').textContent=fa(Math.round(logs.reduce((a,x)=>a+x.min,0)))+' دقیقه';
 $('dPages').textContent=fa(logs.reduce((a,x)=>a+x.pages,0)); $('dBooks').textContent=fa(db.books.filter(x=>x.finished).length);
 let goal=db.goals[0]; $('dGoal').textContent=goal?fa(Math.min(100,Math.round(goal.done/goal.target*100)))+'٪':'۰٪';
 $('sToday').textContent=fa(sumLogs(0)); $('sWeek').textContent=fa(sumLogs(7)); $('sMonth').textContent=fa(sumLogs(30)); $('sYear').textContent=fa(sumLogs(365));
 calendar();
}
function sumLogs(days){let cut=new Date(Date.now()-days*864e5);return Math.round(db.logs.filter(x=>new Date(x.date)>=cut).reduce((a,x)=>a+x.min,0))}
function addTask(){let t=$('taskText').value.trim();if(!t)return;db.tasks.push({text:t,min:+$('taskMin').value||0,done:false});$('taskText').value='';save()}
function toggleTask(i){db.tasks[i].done=!db.tasks[i].done;save()}
function delTask(i){db.tasks.splice(i,1);save()}
function addGoal(){let t=$('goalText').value.trim(),n=+$('goalTarget').value||1;if(!t)return;db.goals.push({text:t,target:n,done:0});save()}
function goalDone(i){db.goals[i].done++;save()}
function calendar(){let d=new Date(), days=['شنبه','یکشنبه','دوشنبه','سه‌شنبه','چهارشنبه','پنجشنبه','جمعه'];$('calendarBox').innerHTML='<b>'+d.toLocaleDateString('fa-IR',{year:'numeric',month:'long'})+'</b><br>'+days.map(x=>`<span class="day">${x.slice(0,3)}</span>`).join('')}
document.querySelectorAll('nav button').forEach(b=>b.onclick=()=>{document.querySelectorAll('.tab').forEach(x=>x.classList.remove('active'));$(b.dataset.tab).classList.add('active')});
$('files').onchange=e=>[...e.target.files].forEach(file=>{let url=URL.createObjectURL(file);db.books.push({name:file.name,url,type:file.type,lastPage:1,pages:0,finished:false});});save();
async function selectBook(i){state.book=i;let b=db.books[i];state.page=b.lastPage||1;document.querySelector('[data-tab="study"]').click();$('studyInfo').textContent='در حال مطالعه: '+b.name;
if(b.type==='application/pdf'){ $('photo').style.display='none';$('pdfCanvas').style.display='block';pdfjsLib.getDocument(b.url).promise.then(p=>{state.pdf=p;b.pages=p.numPages;save();showPage()})}
else{$('pdfCanvas').style.display='none';$('photo').style.display='block';$('photo').src=b.url;b.pages=1;save()}
}
async function showPage(){if(!state.pdf)return;let pg=await state.pdf.getPage(state.page),v=pg.getViewport({scale:1.3}),c=$('pdfCanvas');c.width=v.width;c.height=v.height;await pg.render({canvasContext:c.getContext('2d'),viewport:v}).promise;db.books[state.book].lastPage=state.page;save()}
function nextPage(){if(!state.book)return;let b=db.books[state.book];if(state.page<(b.pages||9999)){state.page++;b.lastPage=state.page;showPage()}else{b.finished=true; if(state.book+1<db.books.length)selectBook(state.book+1);save()}}
function prevPage(){if(state.page>1){state.page--;showPage()}}
function startStudy(){if(state.running||!state.book)return;state.running=true;state.start=Date.now();state.interval=setInterval(()=>{$('timer').textContent=format(Date.now()-state.start+state.elapsed)},1000);let sec=+$('pageSeconds').value||60;state.pageTimer=setInterval(nextPage,sec*1000)}
function pauseStudy(){if(!state.running)return;state.running=false;clearInterval(state.interval);clearInterval(state.pageTimer);state.elapsed+=Date.now()-state.start;db.logs.push({date:now(),min:Math.round(state.elapsed/60000),pages:Math.max(0,state.page-(db.books[state.book]?.lastPage||1))});state.elapsed=0;save()}
function format(ms){let s=Math.floor(ms/1000),h=Math.floor(s/3600),m=Math.floor(s%3600/60),x=s%60;return [h,m,x].map(fa).join(':')}
render();