/* MIDOK : les accès restent en mémoire jusqu'à l'export privé demandé par l'administrateur. */
const MidokProvision = (() => {
  let members = [], selected = new Set(), batch = null, running = false, stop = false, backupOffered = false;
  const endpoint = '/functions/v1/midok-provision';
  const uuidRE = /^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
  const stateText = { pending: 'En attente', created: 'Créé / confirmé', existing: 'Existant conservé', error: 'À reprendre' };
  function password() {
    const alphabet = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789-_!@#$%*';
    // Rejet des octets hors d'un multiple de la longueur : aucune réduction biaisée.
    let value = 'Mi9!';
    while (value.length < 24) {
      for (const b of crypto.getRandomValues(new Uint8Array(32))) {
        if (b < Math.floor(256 / alphabet.length) * alphabet.length) value += alphabet[b % alphabet.length];
        if (value.length === 24) break;
      }
    }
    return value;
  }
  function status(text) { const el = document.getElementById('provision-status'); if (el) el.textContent = text; }
  function csvCell(value) {
    let s = String(value ?? '');
    if (/^[\s]*[=+@-]|^[\t\r\n]/.test(s)) s = "'" + s;
    return '"' + s.replace(/"/g, '""') + '"';
  }
  function csvText(items) {
    return '\uFEFF' + [['Identifiant', 'Nom', 'Mot de passe temporaire', 'État'],
      ...items.filter(i => i.status === 'created').map(i => [i.code, i.name, i.password, 'Créé — changement obligatoire à la première connexion'])]
      .map(row => row.map(csvCell).join(';')).join('\r\n');
  }
  function parseBatch(text) {
    const value = JSON.parse(text);
    if (value.type !== 'midok-private-access-batch-v1' || value.project !== Cloud.config().url || !uuidRE.test(value.id) ||
        !Array.isArray(value.items) || !value.items.length || value.items.length > 1000) throw Error('Ce fichier n’est pas un lot privé MIDOK de ce projet.');
    const codes = new Set();
    const items = value.items.map(i => {
      if (typeof i.code !== 'string' || !/^[A-Z0-9_-]{1,30}$/.test(i.code) || codes.has(i.code) ||
          typeof i.name !== 'string' || !i.name || i.name.length > 500 || typeof i.password !== 'string' ||
          i.password.length < 16 || i.password.length > 128 || !uuidRE.test(i.operation)) throw Error('Lot incomplet ou codes en doublon.');
      codes.add(i.code);
      return { code: i.code, name: i.name, password: i.password, operation: i.operation, status: 'pending', message: '' };
    });
    return { type: value.type, project: value.project, id: value.id, items };
  }
  function render() {
    const view = document.getElementById('view');
    if (!view) return;
    if (batch) {
      view.innerHTML = '<h2>Création des accès membres</h2><p>Lot de ' + batch.items.length + ' fiche(s). Les comptes déjà présents sont conservés.</p>' +
        '<div class="card"><p><b>Avant de démarrer :</b> enregistrez le fichier privé du lot. Il contient les mots de passe et permet de reprendre une opération interrompue.</p>' +
        '<button onclick="MidokProvision.exportBackup()">1. Enregistrer le lot privé</button>' +
        '<label><input id="provision-backup-confirmed" type="checkbox" style="width:auto" ' + (running ? 'disabled checked' : '') + '> J’ai enregistré le fichier privé sur mon appareil.</label>' +
        '<button id="provision-start" class="primary" onclick="MidokProvision.run()" ' + (running ? 'disabled' : '') + '>2. Créer / reprendre les accès</button> ' +
        '<button onclick="MidokProvision.pause()" ' + (!running ? 'disabled' : '') + '>Pause après ce compte</button></div>' +
        '<p id="provision-status" role="status" aria-live="polite">' + (running ? 'Création en cours… Gardez cette page ouverte.' : 'Prêt. Aucun mot de passe existant ne sera changé.') + '</p>' +
        '<div class="card"><button onclick="MidokProvision.exportCSV()">Exporter les accès créés (CSV)</button> ' +
        '<button onclick="MidokProvision.showCards()">Afficher les fiches d’accès privées</button> ' +
        '<button onclick="MidokProvision.closeBatch()" ' + (running ? 'disabled' : '') + '>Fermer le lot</button><p>Remettez à chacun uniquement sa propre fiche. Le fichier du lot et le CSV complet restent réservés au bureau.</p></div>' +
        '<div id="provision-results"></div><div id="provision-cards"></div>';
      updateResults();
      return;
    }
    view.innerHTML = '<h2>Accès des membres</h2><p>Vérifiez les noms et les écoles avant de sélectionner les fiches. Les dates manquantes restent signalées, sans empêcher la création d’un accès.</p>' +
      '<div class="toolbar"><button onclick="MidokProvision.load()">Actualiser les comptes</button><button onclick="MidokProvision.selectClearNames()">Sélectionner les fiches sans alerte d’identité</button><button onclick="MidokProvision.clearSelection()">Tout décocher</button></div>' +
      '<p id="provision-status" role="status">Chargez la liste pour voir les comptes existants.</p>' +
      '<div id="provision-members"></div><div class="card"><label><input id="provision-identity" type="checkbox" style="width:auto"> J’ai vérifié l’identité des adhérents sélectionnés.</label>' +
      '<button class="primary" onclick="MidokProvision.prepare()">Préparer les mots de passe temporaires</button></div>' +
      '<div class="card"><h3>Reprendre un lot enregistré</h3><label>Fichier privé du lot (.json)<input type="file" accept=".json,application/json" onchange="MidokProvision.importBackup(this.files[0]);this.value=\'\'"></label></div>';
    drawMembers();
  }
  function drawMembers() {
    const box = document.getElementById('provision-members');
    if (!box) return;
    box.innerHTML = members.map((m, i) => '<label class="card" style="display:block;margin:10px 0"><input style="width:auto" type="checkbox" data-provision-code="' + esc(m.code) + '" ' +
      (selected.has(m.code) ? 'checked ' : '') + (m.status !== 'missing' ? 'disabled ' : '') + 'onchange="MidokProvision.toggle(' + i + ',this.checked)"> ' +
      '<b>' + esc(m.code) + ' · ' + esc(m.name) + '</b><br><small>' + esc(m.school || 'École non renseignée') + '</small><br>' +
      esc(m.status === 'existing' ? 'Compte déjà créé' : m.status === 'disabled' ? 'Compte désactivé, conservé' : 'Accès à créer') +
      (m.warnings.length ? '<p class="notice">' + esc(m.warnings.join(' · ')) + '</p>' : '') + '</label>').join('');
    if (members.length) status(members.length + ' fiches · ' + members.filter(m => m.status !== 'missing').length + ' comptes existants · ' + selected.size + ' sélectionnée(s).');
  }
  async function load() {
    if (batch || running) return;
    status('Vérification des comptes…');
    try {
      const result = await Cloud.call(endpoint, 'POST', { action: 'list' });
      if (!Array.isArray(result.members)) throw Error('Réponse du service illisible.');
      members = result.members; selected.clear(); drawMembers();
    } catch (e) {
      status('Service de création indisponible : ' + e.message + ' Vérifiez que la fonction midok-provision est déployée dans Supabase.');
    }
  }
  function prepare() {
    if (!document.getElementById('provision-identity')?.checked) return alert('Vérifiez les identités, puis cochez la confirmation.');
    const chosen = members.filter(m => selected.has(m.code) && m.status === 'missing');
    if (!chosen.length) return alert('Sélectionnez au moins une fiche sans compte.');
    if (!crypto?.getRandomValues || !crypto?.randomUUID) return alert('Ce navigateur ne permet pas de générer des accès sécurisés.');
    batch = { type: 'midok-private-access-batch-v1', project: Cloud.config().url, id: crypto.randomUUID(),
      items: chosen.map(m => ({ code: m.code, name: m.name, password: password(), operation: crypto.randomUUID(), status: 'pending', message: '' })) };
    backupOffered = false; render();
  }
  function exportBackup() {
    if (!batch) return;
    download('MIDOK_LOT_PRIVE_' + batch.id + '.json', JSON.stringify(batch, null, 2), 'application/json');
    backupOffered = true;
    status('Vérifiez que le fichier privé est enregistré dans Téléchargements, puis cochez la confirmation.');
  }
  async function importBackup(file) {
    if (!file || running) return;
    try {
      if (file.size > 2000000) throw Error('Fichier trop volumineux.');
      const imported = parseBatch(await file.text());
      batch = imported; backupOffered = true; render();
      status('Lot chargé. Chaque compte sera revérifié ; aucun mot de passe existant ne sera remplacé.');
    } catch (e) { alert('Import impossible : ' + e.message); }
  }
  function updateResults() {
    const box = document.getElementById('provision-results');
    if (!box || !batch) return;
    box.innerHTML = table(['Code', 'Nom', 'Résultat'], batch.items.map(i => '<tr><td>' + esc(i.code) + '</td><td>' + esc(i.name) + '</td><td>' +
      esc(stateText[i.status]) + (i.message ? '<br>' + esc(i.message) : '') + '</td></tr>'));
  }
  async function run() {
    if (running || !batch) return;
    if (!backupOffered || !document.getElementById('provision-backup-confirmed')?.checked) return alert('Enregistrez d’abord le lot privé et confirmez sa sauvegarde.');
    running = true; stop = false; render();
    try {
      for (const item of batch.items) {
        if (stop) break;
        if (['created', 'existing'].includes(item.status)) continue;
        status('Création de ' + item.code + '…');
        try {
          const result = await Cloud.call(endpoint, 'POST', { action: 'create', code: item.code, name: item.name,
            password: item.password, operation: item.operation, identityConfirmed: true });
          if (result.code !== item.code || !['created', 'existing'].includes(result.status)) throw Error('Réponse inattendue. Reprenez le même lot.');
          item.status = result.status; item.message = result.status === 'existing' ? 'Mot de passe existant conservé ; aucun nouvel accès à distribuer.' : '';
        } catch (e) { item.status = 'error'; item.message = e.message; stop = true; }
        updateResults();
      }
    } finally {
      running = false; render();
      status(batch.items.filter(i => i.status === 'created').length + ' accès créé(s) ou confirmé(s). ' +
        (stop ? 'Lot interrompu : conservez le même fichier pour reprendre.' : 'Traitement terminé. Exportez les accès créés.'));
    }
  }
  function exportCSV() {
    if (!batch?.items.some(i => i.status === 'created')) return alert('Aucun nouvel accès confirmé à exporter.');
    download('MIDOK_ACCES_CREES_CONFIDENTIEL.csv', csvText(batch.items), 'text/csv;charset=utf-8');
  }
  function showCards() {
    const box = document.getElementById('provision-cards');
    if (!box || !batch) return;
    box.innerHTML = '<p><button onclick="document.getElementById(\'provision-cards\').textContent=\'\'">Masquer les accès</button></p>' +
      batch.items.filter(i => i.status === 'created').map(i => '<article class="card"><h3>MIDOK · Accès personnel</h3><p>' + esc(i.name) + '</p><p>Identifiant : <b>' + esc(i.code) +
        '</b></p><p>Mot de passe temporaire : <code style="overflow-wrap:anywhere;user-select:all">' + esc(i.password) + '</code></p><p>Ouvrez MIDOK Membre. Définissez votre propre mot de passe à la première connexion.</p></article>').join('');
  }
  function closeBatch() {
    if (running || !confirm('Avez-vous conservé le lot privé et exporté les accès créés ? Fermer efface les mots de passe de cette session.')) return;
    batch = null; backupOffered = false; members = []; selected.clear(); render(); load();
  }
  window.addEventListener('beforeunload', e => { if (batch || running) { e.preventDefault(); e.returnValue = ''; } });
  window.addEventListener('pagehide', () => { batch = null; members = []; selected.clear(); });
  return { render, load, prepare, exportBackup, importBackup, run, exportCSV, showCards, closeBatch,
    pause() { stop = true; },
    toggle(i, checked) { const m = members[i]; if (m?.status === 'missing') { if (checked) selected.add(m.code); else selected.delete(m.code); } status(selected.size + ' fiche(s) sélectionnée(s).'); },
    selectClearNames() { for (const m of members) if (m.status === 'missing' && !m.identityWarning) selected.add(m.code); drawMembers(); },
    clearSelection() { selected.clear(); drawMembers(); },
    // Fonctions pures exposées pour les vérifications locales, sans état privé.
    password, csvText, parseBatch,
  };
})();
