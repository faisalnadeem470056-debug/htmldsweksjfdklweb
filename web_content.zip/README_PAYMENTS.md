# Indian GPT Payments Architecture

This app uses a full backend architecture with SQLite + Stripe for real payment processing and robust limits.

### Configuration
Update the `.env` file with actual keys:
```
STRIPE_SECRET_KEY=sk_test_...
STRIPE_WEBHOOK_SECRET=whsec_...
STRIPE_PRICE_PRO_MONTHLY=price_...
STRIPE_PRICE_PREMIUM_MONTHLY=price_...
```

### Models by Plan
- **Free**: Gemini 3.1 Flash Lite
- **Pro**: Gemini 3.1 Flash (Plus Image/Vision features enabled)
- **Premium**: Gemini 3.1 Pro Preview

### Security Rules
- Client is not trusted. Modifying localStorage plan values will not give access.
- Subscriptions are validated completely securely via Stripe webhooks.
- Only the Webhook can activate a paid account, protecting against manipulated API calls.
