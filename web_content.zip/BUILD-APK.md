# Surger: the missing step

The earlier `surger-android-fixed.zip` was **not** an Android installer. It was only the Android Studio source project. Android Downloads will not install a `.zip`, `.md`, or `.html` file as an app.

The file you ultimately need is:

`app-debug.apk`

Once `app-debug.apk` is on your Android phone, opening it from Downloads launches Android's normal installer. After installation, Surger appears in the Android app launcher and loads its HTML from inside the APK.

## Build it in Android Studio

Open the `surger-android` folder. Let Android Studio install the required SDK/Gradle components if prompted. Use the `app` module and the `debug` build variant, then use **Build > Build APK(s)**.

The APK will be under:

`app/build/outputs/apk/debug/app-debug.apk`

## Build it with GitHub Actions

This folder includes `.github/workflows/build-apk.yml`. Put the project in a GitHub repository, open **Actions**, run **Build Surger APK**, and download the `Surger-debug-apk` artifact from the completed run.

The workflow uses Java 17 and Gradle 8.9. Android's current compatibility table lists Gradle 8.9 for Android Gradle Plugin 8.7. citeturn730365search0turn730365search6

## What is fixed in this project

The Surger HTML is bundled into the APK, so the app no longer depends on a separate `surger.html` sitting in Downloads. Native Android speech recognition and text-to-speech are wired through the WebView bridge, and WebView storage is enabled for Surger Memory.

The source's existing security boundaries remain: the app does not silently install itself, bypass Android's installer, unlock the phone, or replace the Android operating system.
