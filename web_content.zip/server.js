require("dotenv").config();

const express = require("express");
const path = require("path");

const app = express();
const PORT = Number(process.env.PORT || 3000);
const API_KEY = process.env.FOOTBALL_API_KEY;
const API_BASE_URL = "https://v3.football.api-sports.io";
const TIMEZONE = "Asia/Baghdad";

// Free plans have a small daily quota. Keep the normal refresh conservative.
// On a paid plan, you can reduce LIVE_REFRESH_MS for faster live scores.
const DAY_CACHE_MS = Number(process.env.DAY_CACHE_MS || 900000);       // 15 min
const LIVE_REFRESH_MS = Number(process.env.LIVE_REFRESH_MS || 120000); // 2 min
const REQUEST_TIMEOUT_MS = Number(process.env.REQUEST_TIMEOUT_MS || 12000);

app.use(express.static(path.join(__dirname)));

const cache = new Map();

function validISODate(value) {
  return /^\d{4}-\d{2}-\d{2}$/.test(value || "");
}

function todayInIraq() {
  return new Intl.DateTimeFormat("en-CA", {
    timeZone: TIMEZONE, year: "numeric", month: "2-digit", day: "2-digit"
  }).format(new Date());
}

function normalizeStatus(short, long) {
  const s = String(short || "").toUpperCase();
  if (["1H","2H","ET","P","LIVE"].includes(s)) return { group: "live", label: s === "HT" ? "الاستراحة" : "مباشرة" };
  if (s === "HT") return { group: "live", label: "الاستراحة" };
  if (["FT","AET","PEN"].includes(s)) return { group: "finished", label: "انتهت" };
  if (["PST"].includes(s)) return { group: "finished", label: "مؤجلة" };
  if (["CANC","ABD"].includes(s)) return { group: "finished", label: "أُلغيت" };
  if (["SUSP"].includes(s)) return { group: "live", label: "معلقة" };
  if (["NS","TBD"].includes(s)) return { group: "upcoming", label: "لم تبدأ" };
  return { group: "upcoming", label: long || "لم تبدأ" };
}

function normalizeFixture(item) {
  const f = item?.fixture;
  const home = item?.teams?.home;
  const away = item?.teams?.away;
  const league = item?.league;
  const status = normalizeStatus(f?.status?.short, f?.status?.long);

  if (!f?.id || !f?.date || !home?.name || !away?.name) return null;

  return {
    fixtureId: String(f.id),
    startTime: f.date,
    homeName: String(home.name),
    awayName: String(away.name),
    homeLogo: typeof home.logo === "string" ? home.logo : "",
    awayLogo: typeof away.logo === "string" ? away.logo : "",
    homeGoals: Number.isInteger(item?.goals?.home) ? item.goals.home : null,
    awayGoals: Number.isInteger(item?.goals?.away) ? item.goals.away : null,
    leagueName: String(league?.name || "بطولة غير محددة"),
    leagueKey: league?.id ? String(league.id) : String(league?.name || ""),
    country: String(league?.country || league?.name || ""),
    round: league?.round ? String(league.round) : "",
    venue: f?.venue?.name ? String(f.venue.name) : "",
    statusGroup: status.group,
    statusLabel: status.label,
    statusCode: String(f?.status?.short || ""),
    elapsed: Number.isInteger(f?.status?.elapsed) ? f.status.elapsed : null
  };
}

async function apiGet(endpoint, params) {
  if (!API_KEY) {
    const error = new Error("FOOTBALL_API_KEY غير موجود في ملف البيئة.");
    error.code = "CONFIG";
    throw error;
  }

  const url = new URL(API_BASE_URL + endpoint);
  Object.entries(params).forEach(([key, value]) => url.searchParams.set(key, value));

  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), REQUEST_TIMEOUT_MS);

  try {
    const response = await fetch(url, {
      signal: controller.signal,
      headers: {
        "x-apisports-key": API_KEY,
        "Accept": "application/json"
      }
    });

    let body = null;
    try { body = await response.json(); } catch {
      const error = new Error("استجابة JSON غير صالحة من مزود البيانات.");
      error.httpStatus = response.status;
      throw error;
    }

    if (!response.ok) {
      const apiError = body?.errors ? JSON.stringify(body.errors) : "";
      const error = new Error(apiError || `API HTTP ${response.status}`);
      error.httpStatus = response.status;
      throw error;
    }

    if (body?.errors && Object.keys(body.errors).length) {
      const error = new Error(JSON.stringify(body.errors));
      error.httpStatus = 400;
      throw error;
    }

    if (!Array.isArray(body?.response)) {
      throw new Error("بنية استجابة API غير متوقعة.");
    }

    return body.response;
  } finally {
    clearTimeout(timer);
  }
}

async function getMatches(date) {
  const existing = cache.get(date);
  const now = Date.now();

  if (existing && now - existing.updatedAt < existing.ttl) {
    return existing;
  }

  // One precise date request is enough for the daily list. The API accepts
  // timezone=Asia/Baghdad, so the returned kickoff timestamps are localized.
  const response = await apiGet("/fixtures", {
    date,
    timezone: TIMEZONE
  });

  const matches = response.map(normalizeFixture).filter(Boolean);

  // Do not expose fabricated data. Empty response stays empty.
  const hasLive = matches.some(m => m.statusGroup === "live");
  const ttl = hasLive ? LIVE_REFRESH_MS : DAY_CACHE_MS;

  const entry = { updatedAt: now, ttl, matches };
  cache.set(date, entry);
  return entry;
}

app.get("/api/matches", async (req, res) => {
  const date = validISODate(req.query.date) ? req.query.date : todayInIraq();

  // Never allow arbitrary historical/future input to alter the page's timezone.
  try {
    const result = await getMatches(date);
    res.set("Cache-Control", "no-store");
    res.json({
      timezone: TIMEZONE,
      date,
      matches: result.matches,
      updatedAt: new Date(result.updatedAt).toISOString(),
      refreshAfterMs: result.ttl
    });
  } catch (error) {
    const status = error.httpStatus === 401 || error.httpStatus === 403 ? 401
      : error.httpStatus === 429 ? 429
      : error.code === "CONFIG" ? 500
      : 502;

    const message = status === 401
      ? "مفتاح API غير صحيح أو غير مصرح به."
      : status === 429
      ? "تم تجاوز حد طلبات API. سيُعاد المحاولة لاحقًا."
      : error.name === "AbortError"
      ? "انتهت مهلة الاتصال بمزود البيانات."
      : error.code === "CONFIG"
      ? "لم يتم إعداد FOOTBALL_API_KEY على الخادم."
      : "تعذر تحميل المباريات حاليًا، حاول مرة أخرى.";

    res.status(status).json({ message });
  }
});

app.get("/api/health", (_req, res) => {
  res.json({ ok: Boolean(API_KEY), timezone: TIMEZONE });
});

app.listen(PORT, () => {
  console.log(`Football Iraq app: http://localhost:${PORT}`);
});
