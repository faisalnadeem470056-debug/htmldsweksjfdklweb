const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { URL } = require('url');
let Pool = null;

const ROOT = __dirname;
const PUBLIC = path.join(ROOT, 'public');
const PORT = Number(process.env.PORT || 8787);
const DATABASE_URL = process.env.DATABASE_URL;
const SESSION_HOURS = Number(process.env.SESSION_HOURS || 8);
const INITIAL_PIN = String(process.env.OWNER_INITIAL_PIN || '012012');
const SESSION_SECRET = process.env.SESSION_SECRET || 'CHANGE_ME_IN_PRODUCTION';
const OPENAI_BASE_URL = (process.env.AI_BASE_URL || 'https://api.openai.com/v1').replace(/\/$/, '');
const AI_MODEL = process.env.AI_MODEL || 'gpt-5.4-mini';

const RESOURCE_TABLES = new Set([
  'clients','bookings','packages','leads','communications','complaints','quotes','tasks',
  'procurement','hotels','suppliers','employees','transactions','campaigns'
]);
const PERMISSIONS = {
  OWNER: ['*'], ADMIN: ['*'], FINANCE: ['transactions','quotes','procurement','clients','bookings'],
  RESERVATIONS: ['clients','bookings','packages','hotels','suppliers','quotes','communications','tasks'],
  MARKETING: ['clients','leads','communications','campaigns','packages'],
  HR: ['employees','tasks'], OPERATIONS: ['bookings','packages','hotels','suppliers','procurement','tasks'],
  AGENT: ['clients','leads','communications','bookings','packages','hotels','quotes'], READONLY: ['clients','bookings','packages','hotels','suppliers']
};

const govs = [
['CAI','Cairo','القاهرة','Le Caire','Il Cairo'],['GIZ','Giza','الجيزة','Gizeh','Giza'],['ALX','Alexandria','الإسكندرية','Alexandrie','Alessandria'],['QLY','Qalyubia','القليوبية','Qalyubia','Qalyubia'],['PSD','Port Said','بورسعيد','Port-Saïd','Porto Said'],['SUE','Suez','السويس','Suez','Suez'],['DMT','Damietta','دمياط','Damiette','Damietta'],['DKH','Dakahlia','الدقهلية','Dakahlia','Dakahlia'],['SHR','Sharqia','الشرقية','Sharqia','Sharqia'],['KFS','Kafr El Sheikh','كفر الشيخ','Kafr el-Cheikh','Kafr El Sheikh'],['GHB','Gharbia','الغربية','Gharbia','Gharbia'],['MNF','Monufia','المنوفية','Monufia','Monufia'],['BHR','Beheira','البحيرة','Beheira','Beheira'],['ISM','Ismailia','الإسماعيلية','Ismaïlia','Ismailia'],['NSN','North Sinai','شمال سيناء','Sinaï du Nord','Sinai Settentrionale'],['SSN','South Sinai','جنوب سيناء','Sinaï du Sud','Sinai Meridionale'],['RED','Red Sea','البحر الأحمر','Mer Rouge','Mar Rosso'],['FYM','Fayoum','الفيوم','Fayoum','Fayyum'],['BNS','Beni Suef','بني سويف','Beni Souef','Beni Suef'],['MNJ','Minya','المنيا','Minya','Minya'],['AST','Asyut','أسيوط','Assiout','Asyut'],['SHG','Sohag','سوهاج','Sohag','Sohag'],['QNA','Qena','قنا','Qena','Qena'],['LXR','Luxor','الأقصر','Louxor','Luxor'],['ASN','Aswan','أسوان','Assouan','Aswan'],['WAD','New Valley','الوادي الجديد','Nouvelle-Vallée','Nuova Valle'],['MTR','Matrouh','مطروح','Matrouh','Matruh']
].map(([code,name_en,name_ar,name_fr,name_it])=>({code,name_en,name_ar,name_fr,name_it}));

let pool = null;
let jsonDb = null;
const rate = new Map();

function id(prefix='ID'){ return `${prefix}-${crypto.randomBytes(7).toString('hex').toUpperCase()}`; }
function hash(value){ return crypto.createHash('sha256').update(String(value)).digest('hex'); }
function timingSafe(a,b){ const x=Buffer.from(String(a)); const y=Buffer.from(String(b)); return x.length===y.length && crypto.timingSafeEqual(x,y); }
function scrypt(value,salt=crypto.randomBytes(16).toString('hex')){ return new Promise((resolve,reject)=>crypto.scrypt(String(value),salt,64,(e,d)=>e?reject(e):resolve(`${salt}:${d.toString('hex')}`))); }
function verifyScrypt(value,stored){ try { const [salt,hex]=String(stored).split(':'); if(!salt||!hex)return false; const derived=crypto.scryptSync(String(value),salt,64); return timingSafe(derived.toString('hex'),hex); } catch { return false; } }
function json(res,status,obj,extra={}){ res.writeHead(status,{ 'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store','Access-Control-Allow-Origin':'*','Access-Control-Allow-Headers':'Content-Type, Authorization','Access-Control-Allow-Methods':'GET,POST,PUT,DELETE,OPTIONS',...extra}); res.end(JSON.stringify(obj)); }
function readBody(req){ return new Promise((resolve,reject)=>{ let s=''; req.on('data',c=>{s+=c;if(s.length>3e6)req.destroy()}); req.on('end',()=>{try{resolve(s?JSON.parse(s):{})}catch(e){reject(e)}});req.on('error',reject); }); }
function clientIp(req){ return (req.headers['x-forwarded-for']||req.socket.remoteAddress||'unknown').split(',')[0].trim(); }
function rateLimit(req){ const now=Date.now(), key=clientIp(req), x=rate.get(key)||{n:0,t:now}; if(now-x.t>60000){x.n=0;x.t=now} x.n++; rate.set(key,x); return x.n<=30; }

async function initJson(){
  const file=path.join(ROOT,'data','db.json');
  jsonDb=JSON.parse(fs.readFileSync(file,'utf8'));
  if(!jsonDb.users?.[0]?.pinHash) jsonDb.users[0].pinHash=await scrypt(INITIAL_PIN);
}
async function init(){
  if(!DATABASE_URL){ await initJson(); console.warn('WARNING: DATABASE_URL is not set; JSON development mode is active.'); return; }
  if (!Pool) { try { Pool = require('pg').Pool; } catch (e) { throw new Error('PostgreSQL mode requires `npm install` so the pg package is installed.'); } }
  pool=new Pool({connectionString:DATABASE_URL,ssl:process.env.PGSSL==='true'?{rejectUnauthorized:false}:undefined,max:Number(process.env.PGPOOL_MAX||10)});
  await pool.query(fs.readFileSync(path.join(ROOT,'schema.sql'),'utf8'));
  const u=await pool.query('SELECT id FROM users LIMIT 1');
  if(!u.rowCount){ const pinHash=await scrypt(INITIAL_PIN); await pool.query('INSERT INTO users(id,name,role,pin_hash) VALUES($1,$2,$3,$4)', ['U-001','الأستاذ محمد موسي','OWNER',pinHash]); }
}

async function dbQuery(text,params=[]){ if(pool)return (await pool.query(text,params)).rows; throw new Error('PostgreSQL is not configured'); }
async function company(){ if(pool){const r=await dbQuery('SELECT data FROM company_settings WHERE id=$1',['company']);return r[0]?.data||{}} return jsonDb.company; }
async function currentUser(req){
  const h=req.headers.authorization||''; if(!h.startsWith('Bearer '))return null; const raw=h.slice(7); const th=hash(raw);
  if(pool){const r=await dbQuery('SELECT u.id,u.name,u.role,u.active,s.expires_at FROM sessions s JOIN users u ON u.id=s.user_id WHERE s.token_hash=$1 AND s.expires_at>now()',[th]); return r[0]||null;}
  return jsonDb.sessions?.[th]||null;
}
async function audit(user,action,entity,entityId,meta={}){
  if(pool) await dbQuery('INSERT INTO audit_logs(id,user_id,user_name,action,entity,entity_id,meta) VALUES($1,$2,$3,$4,$5,$6,$7)',[id('AUD'),user?.id||null,user?.name||'system',action,entity,entityId,meta]);
  else {jsonDb.audit=jsonDb.audit||[];jsonDb.audit.unshift({id:id('AUD'),at:new Date().toISOString(),user:user?.name||'system',action,entity,entityId,meta});jsonDb.audit=jsonDb.audit.slice(0,500);fs.writeFileSync(path.join(ROOT,'data','db.json'),JSON.stringify(jsonDb,null,2));}
}
function can(user,resource,method){ if(!user?.active)return false; const p=PERMISSIONS[user.role]||[]; if(p.includes('*'))return true; if(method==='GET')return p.includes(resource); return p.includes(resource) && ['OWNER','ADMIN','FINANCE','RESERVATIONS','MARKETING','HR','OPERATIONS'].includes(user.role); }

async function listRecords(resource,q=''){
  if(pool){
    const params=[resource]; let sql='SELECT id,data,created_at,updated_at FROM records WHERE resource=$1';
    if(q){params.push(`%${q.toLowerCase()}%`);sql+=' AND lower(data::text) LIKE $2';} sql+=' ORDER BY created_at DESC LIMIT 1000';
    return (await pool.query(sql,params)).rows.map(r=>({id:r.id,...r.data,createdAt:r.created_at,updatedAt:r.updated_at}));
  }
  return (jsonDb[resource]||[]).filter(x=>!q||JSON.stringify(x).toLowerCase().includes(q.toLowerCase()));
}
async function getRecord(resource,rid){
  if(pool){const r=await dbQuery('SELECT id,data,created_at,updated_at FROM records WHERE resource=$1 AND id=$2',[resource,rid]);if(!r[0])return null;return {id:r[0].id,...r[0].data,createdAt:r[0].created_at,updatedAt:r[0].updated_at};}
  return (jsonDb[resource]||[]).find(x=>x.id===rid)||null;
}
async function createRecord(resource,b,user){
  const rid=b.id||id(resource.slice(0,3).toUpperCase()); const item={...b,id:rid,createdAt:new Date().toISOString(),createdBy:user.id}; delete item._id;
  if(pool) await dbQuery('INSERT INTO records(id,resource,data,created_by) VALUES($1,$2,$3,$4)',[rid,resource,item,user.id]);
  else {jsonDb[resource]=jsonDb[resource]||[];jsonDb[resource].unshift(item);fs.writeFileSync(path.join(ROOT,'data','db.json'),JSON.stringify(jsonDb,null,2));}
  await audit(user,'CREATE',resource,rid); return item;
}
async function updateRecord(resource,rid,b,user){
  const old=await getRecord(resource,rid);if(!old)return null;const item={...old,...b,id:rid,updatedAt:new Date().toISOString()};
  if(pool) await dbQuery('UPDATE records SET data=$1,updated_at=now() WHERE resource=$2 AND id=$3',[item,resource,rid]);
  else {const a=jsonDb[resource]||[],i=a.findIndex(x=>x.id===rid);a[i]=item;fs.writeFileSync(path.join(ROOT,'data','db.json'),JSON.stringify(jsonDb,null,2));}
  await audit(user,'UPDATE',resource,rid);return item;
}
async function deleteRecord(resource,rid,user){
  const old=await getRecord(resource,rid);if(!old)return false;
  if(pool) await dbQuery('DELETE FROM records WHERE resource=$1 AND id=$2',[resource,rid]); else {jsonDb[resource]=(jsonDb[resource]||[]).filter(x=>x.id!==rid);fs.writeFileSync(path.join(ROOT,'data','db.json'),JSON.stringify(jsonDb,null,2));}
  await audit(user,'DELETE',resource,rid);return true;
}
async function reports(){
  if(pool){
    const r=await dbQuery(`SELECT
      count(*) FILTER (WHERE resource='bookings') bookings,
      count(*) FILTER (WHERE resource='clients') clients,
      count(*) FILTER (WHERE resource='leads') leads,
      count(*) FILTER (WHERE resource='quotes') quotes,
      count(*) FILTER (WHERE resource='complaints' AND COALESCE(data->>'status','') NOT IN ('مغلقة','closed','resolved')) open_complaints,
      COALESCE(sum(CASE WHEN resource='bookings' THEN COALESCE((data->>'total')::numeric,0) ELSE 0 END),0) revenue,
      COALESCE(sum(CASE WHEN resource='quotes' THEN COALESCE((data->>'sell')::numeric,0)-COALESCE((data->>'cost')::numeric,0) ELSE 0 END),0) margin
      FROM records`); return r[0];
  }
  const b=jsonDb.bookings||[],q=jsonDb.quotes||[];return {bookings:b.length,clients:(jsonDb.clients||[]).length,leads:(jsonDb.leads||[]).length,quotes:q.length,open_complaints:(jsonDb.complaints||[]).filter(x=>x.status!=='مغلقة').length,revenue:b.reduce((a,x)=>a+Number(x.total||0),0),margin:q.reduce((a,x)=>a+Number(x.sell||0)-Number(x.cost||0),0)};
}
async function aiAnswer(question,user){
  const q=String(question||'').trim(); if(!q)throw new Error('السؤال مطلوب');
  const comp=await company(), rep=await reports();
  let docs=[];
  if(pool){ const r=await dbQuery("SELECT title,content,language,source FROM knowledge_documents WHERE to_tsvector('simple',content) @@ plainto_tsquery('simple',$1) ORDER BY updated_at DESC LIMIT 8",[q]); docs=r; }
  const dataContext={company:comp,reports:rep,knowledge:docs};
  if(!process.env.AI_API_KEY){
    return {mode:'local',answer:`وكيل B-Tourisek المحلي متاح بدون مفتاح AI.\n\nسؤالك: ${q}\n\nبيانات الشركة: ${comp.name||'B-Touristic'} — المالك ${comp.owner||'الأستاذ محمد موسي'} — الجيزة.\nالهاتف: ${(comp.phones||[]).join(' / ')}\nالبريد: ${comp.email||''}\n\nمؤشرات النظام الحالية: ${JSON.stringify(rep)}\n\nلإجابة معرفية كاملة وربط الاستدلال بقاعدة المعرفة والحجوزات، أضف AI_API_KEY وAI_MODEL في ملف البيئة.`,context:dataContext};
  }
  const system=`You are B-Tourisek's internal AI assistant. Answer in the user's language. Use only supplied company/system context for company facts. Never invent live hotel rates or availability. Clearly mark missing data. Owner: ${comp.owner}. Company: ${comp.name}.`;
  const resp=await fetch(`${OPENAI_BASE_URL}/chat/completions`,{method:'POST',headers:{'Content-Type':'application/json','Authorization':`Bearer ${process.env.AI_API_KEY}`},body:JSON.stringify({model:AI_MODEL,temperature:0.2,messages:[{role:'system',content:system},{role:'user',content:`Context:\n${JSON.stringify(dataContext)}\n\nQuestion:\n${q}`} ]})});
  const text=await resp.text();if(!resp.ok)throw new Error(`AI provider error ${resp.status}: ${text.slice(0,300)}`);const d=JSON.parse(text);return {mode:'llm',answer:d.choices?.[0]?.message?.content||'لم تصل إجابة من مزود الذكاء الاصطناعي.',context:dataContext};
}
function serveFile(req,res){let p=new URL(req.url,'http://localhost').pathname;if(p==='/')p='/index.html';if(p.includes('..'))return json(res,400,{error:'bad path'});const f=path.join(PUBLIC,p);if(!fs.existsSync(f)||!fs.statSync(f).isFile())return json(res,404,{error:'not found'});const ct={'.html':'text/html; charset=utf-8','.jpg':'image/jpeg','.png':'image/png','.css':'text/css','.js':'application/javascript'}[path.extname(f)]||'application/octet-stream';res.writeHead(200,{'Content-Type':ct});fs.createReadStream(f).pipe(res);}

async function handler(req,res){
  const u=new URL(req.url,'http://localhost');
  if(req.method==='OPTIONS')return json(res,204,{});
  if(!rateLimit(req))return json(res,429,{error:'Too many requests'});
  if(!u.pathname.startsWith('/api/'))return serveFile(req,res);
  try{
    if(req.method==='GET'&&u.pathname==='/api/health')return json(res,200,{ok:true,service:'B-Tourisek API',database:pool?'postgresql':'json-dev',time:new Date().toISOString(),version:'2.0.0'});
    if(req.method==='POST'&&u.pathname==='/api/login'){
      const b=await readBody(req),pin=String(b.pin||'');let user;
      if(pool){const r=await dbQuery('SELECT id,name,role,active,pin_hash FROM users WHERE id=$1',['U-001']);user=r[0];if(!user||!user.active||!verifyScrypt(pin,user.pin_hash))return json(res,401,{ok:false,error:'رمز الدخول غير صحيح'});
        const token=crypto.randomBytes(32).toString('hex');await dbQuery('INSERT INTO sessions(id,user_id,token_hash,expires_at) VALUES($1,$2,$3,now()+($4 * interval \'1 hour\'))',[id('SES'),user.id,hash(token),SESSION_HOURS]);await audit(user,'LOGIN','auth',user.id);delete user.pin_hash;return json(res,200,{ok:true,token,user,company:await company()});
      }
      user=jsonDb.users[0];if(!verifyScrypt(pin,user.pinHash||''))return json(res,401,{ok:false,error:'رمز الدخول غير صحيح'});const token=crypto.randomBytes(32).toString('hex');jsonDb.sessions=jsonDb.sessions||{};jsonDb.sessions[hash(token)]={id:user.id,name:user.name,role:user.role,active:true};fs.writeFileSync(path.join(ROOT,'data','db.json'),JSON.stringify(jsonDb,null,2));await audit(user,'LOGIN','auth',user.id);return json(res,200,{ok:true,token,user:{id:user.id,name:user.name,role:user.role},company:await company()});
    }
    const user=await currentUser(req);if(!user)return json(res,401,{error:'Unauthorized'});
    if(req.method==='POST'&&u.pathname==='/api/logout'){if(pool)await dbQuery('DELETE FROM sessions WHERE token_hash=$1',[hash((req.headers.authorization||'').slice(7))]);return json(res,200,{ok:true});}
    if(req.method==='POST'&&u.pathname==='/api/ai/ask'){if(!['OWNER','ADMIN','RESERVATIONS','MARKETING','OPERATIONS','AGENT','FINANCE'].includes(user.role))return json(res,403,{error:'Forbidden'});const b=await readBody(req);return json(res,200,await aiAnswer(b.question,user));}
    if(req.method==='POST'&&u.pathname==='/api/owner/change-pin'){
      if(user.role!=='OWNER')return json(res,403,{error:'Owner only'});const b=await readBody(req),oldPin=String(b.currentPin||''),newPin=String(b.newPin||'');if(!/^\d{6,12}$/.test(newPin))return json(res,400,{error:'PIN must be 6-12 digits'});
      if(pool){const r=await dbQuery('SELECT pin_hash FROM users WHERE id=$1',['U-001']);if(!verifyScrypt(oldPin,r[0]?.pin_hash))return json(res,401,{error:'Current PIN is incorrect'});const nh=await scrypt(newPin);await dbQuery('UPDATE users SET pin_hash=$1,updated_at=now() WHERE id=$2',[nh,'U-001']);await audit(user,'CHANGE_PIN','auth','U-001');return json(res,200,{ok:true});}
      if(!verifyScrypt(oldPin,jsonDb.users[0].pinHash))return json(res,401,{error:'Current PIN is incorrect'});jsonDb.users[0].pinHash=await scrypt(newPin);fs.writeFileSync(path.join(ROOT,'data','db.json'),JSON.stringify(jsonDb,null,2));return json(res,200,{ok:true});
    }
    if(req.method==='GET'&&u.pathname==='/api/state')return json(res,200,{company:await company(),govs:pool?await dbQuery('SELECT code,name_en,name_ar,name_fr,name_it FROM governorates ORDER BY name_en'):govs,data:Object.fromEntries(await Promise.all([...RESOURCE_TABLES].map(async r=>[r,await listRecords(r)]))),reports:await reports()});
    if(req.method==='GET'&&u.pathname==='/api/reports')return json(res,200,await reports());
    if(req.method==='GET'&&u.pathname==='/api/governorates')return json(res,200,pool?await dbQuery('SELECT code,name_en,name_ar,name_fr,name_it FROM governorates ORDER BY name_en'):govs);
    const m=u.pathname.match(/^\/api\/([a-z]+)(?:\/([^/]+))?$/);if(!m)return json(res,404,{error:'API route not found'});const resource=m[1];if(!RESOURCE_TABLES.has(resource))return json(res,404,{error:'Unknown resource'});
    if(!can(user,resource,req.method))return json(res,403,{error:'Forbidden'});
    if(req.method==='GET'){const q=u.searchParams.get('q')||'';if(m[2]){const x=await getRecord(resource,m[2]);return x?json(res,200,x):json(res,404,{error:'Not found'});}return json(res,200,await listRecords(resource,q));}
    if(req.method==='POST'){const b=await readBody(req);return json(res,201,await createRecord(resource,b,user));}
    if(req.method==='PUT'){if(!m[2])return json(res,400,{error:'ID required'});const b=await readBody(req),x=await updateRecord(resource,m[2],b,user);return x?json(res,200,x):json(res,404,{error:'Not found'});}
    if(req.method==='DELETE'){if(!m[2])return json(res,400,{error:'ID required'});const ok=await deleteRecord(resource,m[2],user);return ok?json(res,200,{ok:true}):json(res,404,{error:'Not found'});}
    return json(res,405,{error:'Method not allowed'});
  }catch(e){console.error(e);return json(res,500,{error:'Server error',detail:process.env.NODE_ENV==='production'?'Internal error':e.message});}
}

init().then(()=>http.createServer(handler).listen(PORT,()=>console.log(`B-Tourisek v2 running on http://localhost:${PORT}`))).catch(e=>{console.error('Startup failed',e);process.exit(1)});
