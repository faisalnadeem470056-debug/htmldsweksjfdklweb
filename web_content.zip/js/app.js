/**
 * پنل استاتیک مدیریت ربات روبیکا
 * مناسب برای تبدیل به APK
 */

(function () {
    'use strict';

    // ========== Storage ==========
    const STORAGE_KEY = 'rubika_panel_data';

    function loadData() {
        try {
            return JSON.parse(localStorage.getItem(STORAGE_KEY)) || {
                token: null,
                botName: 'ربات من',
                botId: '—',
                startText: 'سلام 👋\nبه ربات ما خوش آمدید!',
                startEnabled: true,
                keyboards: [],
                quickReplies: []
            };
        } catch {
            return { token: null, botName: 'ربات من', botId: '—', startText: '', startEnabled: true, keyboards: [], quickReplies: [] };
        }
    }

    function saveData(data) {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
    }

    let data = loadData();

    // ========== Elements ==========
    const loginPage = document.getElementById('loginPage');
    const dashboardPage = document.getElementById('dashboardPage');
    const loginForm = document.getElementById('loginForm');
    const tokenInput = document.getElementById('token');
    const loginError = document.getElementById('loginError');
    const loginBtn = document.getElementById('loginBtn');
    const sidebar = document.getElementById('sidebar');
    const sidebarOverlay = document.getElementById('sidebarOverlay');

    // ========== Login ==========
    if (data.token) {
        showDashboard();
    }

    loginForm.addEventListener('submit', function (e) {
        e.preventDefault();
        const token = tokenInput.value.trim();

        if (!token || token.length < 20) {
            showLoginError('❌ توکن واردشده معتبر نیست.');
            return;
        }

        loginBtn.disabled = true;
        loginBtn.querySelector('.btn-text').style.display = 'none';
        loginBtn.querySelector('.btn-loader').style.display = 'inline';

        // شبیه‌سازی بررسی توکن (در نسخه استاتیک)
        setTimeout(() => {
            data.token = token;
            data.botName = 'ربات روبیکا';
            data.botId = 'b0' + Math.random().toString(36).substr(2, 16);
            saveData(data);
            showDashboard();
            loginBtn.disabled = false;
            loginBtn.querySelector('.btn-text').style.display = 'inline';
            loginBtn.querySelector('.btn-loader').style.display = 'none';
        }, 800);
    });

    document.getElementById('toggleToken').addEventListener('click', function () {
        tokenInput.type = tokenInput.type === 'password' ? 'text' : 'password';
    });

    function showLoginError(msg) {
        loginError.textContent = msg;
        loginError.style.display = 'block';
    }

    function showDashboard() {
        loginPage.classList.remove('active');
        dashboardPage.classList.add('active');
        updateUI();
    }

    // ========== Logout ==========
    document.getElementById('logoutBtn').addEventListener('click', function (e) {
        e.preventDefault();
        if (confirm('آیا می‌خواهید خارج شوید؟')) {
            data.token = null;
            saveData(data);
            loginPage.classList.add('active');
            dashboardPage.classList.remove('active');
            tokenInput.value = '';
        }
    });

    // ========== Navigation ==========
    function switchSection(sectionId) {
        document.querySelectorAll('.section').forEach(s => s.classList.remove('active'));
        document.querySelectorAll('.nav-item[data-section]').forEach(n => n.classList.remove('active'));
        document.querySelectorAll('.bottom-nav-item').forEach(n => n.classList.remove('active'));
        document.querySelectorAll('.quick-action').forEach(n => n.classList.remove('active'));

        const section = document.getElementById('section-' + sectionId);
        if (section) section.classList.add('active');

        document.querySelectorAll(`[data-section="${sectionId}"]`).forEach(el => {
            if (el.classList.contains('nav-item') || el.classList.contains('bottom-nav-item')) {
                el.classList.add('active');
            }
        });

        const titles = {
            home: 'داشبورد',
            start: 'تنظیم Start',
            keyboards: 'مدیریت کیبورد',
            quick: 'پاسخ سریع',
            settings: 'تنظیمات',
            stats: 'آمار'
        };
        document.getElementById('pageTitle').textContent = titles[sectionId] || 'داشبورد';

        // بستن سایدبار موبایل
        sidebar.classList.remove('open');
        sidebarOverlay.classList.remove('show');
    }

    document.querySelectorAll('[data-section]').forEach(el => {
        el.addEventListener('click', function (e) {
            e.preventDefault();
            const section = this.getAttribute('data-section');
            if (section) switchSection(section);
        });
    });

    // Menu toggle
    document.getElementById('menuToggle').addEventListener('click', function () {
        sidebar.classList.toggle('open');
        sidebarOverlay.classList.toggle('show');
    });
    sidebarOverlay.addEventListener('click', function () {
        sidebar.classList.remove('open');
        sidebarOverlay.classList.remove('show');
    });

    // ========== Update UI ==========
    function updateUI() {
        document.getElementById('botName').textContent = data.botName;
        document.getElementById('botNameSidebar').textContent = data.botName;
        document.getElementById('botId').textContent = data.botId;
        document.getElementById('qrCount').textContent = data.quickReplies.length;
        document.getElementById('kbCount').textContent = data.keyboards.length;
        document.getElementById('startText').value = data.startText || '';
        document.getElementById('startEnabled').checked = data.startEnabled !== false;
        renderKeyboards();
        renderQuickReplies();
    }

    // ========== Start ==========
    document.getElementById('saveStart').addEventListener('click', function () {
        data.startText = document.getElementById('startText').value;
        data.startEnabled = document.getElementById('startEnabled').checked;
        saveData(data);
        alert('✅ تنظیمات Start ذخیره شد');
    });

    // ========== Keyboards ==========
    function renderKeyboards() {
        const container = document.getElementById('keyboardsList');
        if (!data.keyboards.length) {
            container.innerHTML = `
                <div class="empty-state glass">
                    <div class="empty-icon">⌨️</div>
                    <h3>هنوز کیبوردی نساخته‌اید</h3>
                    <p>اولین کیبورد خود را بسازید</p>
                </div>`;
            return;
        }
        container.innerHTML = data.keyboards.map((kb, i) => `
            <div class="card glass kb-card">
                <h4>${escapeHtml(kb.name)}</h4>
                <div class="meta">${kb.buttons.length} دکمه</div>
                <div class="actions">
                    <button class="btn btn-sm btn-danger" onclick="deleteKeyboard(${i})">حذف</button>
                </div>
            </div>
        `).join('');
    }

    document.getElementById('addKeyboardBtn').addEventListener('click', function () {
        document.getElementById('kbName').value = '';
        document.getElementById('kbButtons').value = '';
        openModal('keyboardModal');
    });

    document.getElementById('saveKeyboard').addEventListener('click', function () {
        const name = document.getElementById('kbName').value.trim();
        const buttonsRaw = document.getElementById('kbButtons').value.trim();
        if (!name) { alert('نام کیبورد را وارد کنید'); return; }

        const buttons = [];
        buttonsRaw.split('\n').forEach(line => {
            line.split('|').forEach(b => {
                const t = b.trim();
                if (t) buttons.push(t);
            });
        });

        data.keyboards.push({ name, buttons });
        saveData(data);
        renderKeyboards();
        updateUI();
        closeModal('keyboardModal');
    });

    window.deleteKeyboard = function (index) {
        if (confirm('حذف شود؟')) {
            data.keyboards.splice(index, 1);
            saveData(data);
            renderKeyboards();
            updateUI();
        }
    };

    // ========== Quick Replies ==========
    function renderQuickReplies() {
        const container = document.getElementById('quickList');
        if (!data.quickReplies.length) {
            container.innerHTML = `
                <div class="empty-state glass">
                    <div class="empty-icon">⚡</div>
                    <h3>پاسخ سریعی تعریف نشده</h3>
                    <p>پاسخ‌های خودکار ربات را اینجا تعریف کنید</p>
                </div>`;
            return;
        }

        const scopeLabel = { both: '🌐 هر دو', pv: '📩 PV', group: '👥 گروه' };
        container.innerHTML = '<div class="cards-grid">' + data.quickReplies.map((qr, i) => `
            <div class="card glass qr-card">
                <h4>${escapeHtml(qr.name)}</h4>
                <div class="meta">
                    Trigger: <code>${escapeHtml(qr.trigger)}</code> | ${scopeLabel[qr.scope] || qr.scope}
                </div>
                <div class="actions">
                    <button class="btn btn-sm btn-danger" onclick="deleteQuick(${i})">حذف</button>
                </div>
            </div>
        `).join('') + '</div>';
    }

    document.getElementById('addQuickBtn').addEventListener('click', function () {
        document.getElementById('qrName').value = '';
        document.getElementById('qrTrigger').value = '';
        document.getElementById('qrResponse').value = '';
        document.getElementById('qrScope').value = 'both';
        openModal('quickModal');
    });

    document.getElementById('saveQuick').addEventListener('click', function () {
        const name = document.getElementById('qrName').value.trim();
        const trigger = document.getElementById('qrTrigger').value.trim();
        const response = document.getElementById('qrResponse').value.trim();
        const scope = document.getElementById('qrScope').value;

        if (!name || !trigger || !response) {
            alert('همه فیلدها الزامی هستند');
            return;
        }

        data.quickReplies.push({ name, trigger, response, scope });
        saveData(data);
        renderQuickReplies();
        updateUI();
        closeModal('quickModal');
    });

    window.deleteQuick = function (index) {
        if (confirm('حذف شود؟')) {
            data.quickReplies.splice(index, 1);
            saveData(data);
            renderQuickReplies();
            updateUI();
        }
    };

    // ========== Modal ==========
    function openModal(id) {
        document.getElementById(id).classList.add('active');
    }
    function closeModal(id) {
        document.getElementById(id).classList.remove('active');
    }
    document.querySelectorAll('[data-close]').forEach(btn => {
        btn.addEventListener('click', function () {
            closeModal(this.getAttribute('data-close'));
        });
    });

    // ========== Copy Webhook ==========
    document.getElementById('copyWebhook').addEventListener('click', function () {
        const input = document.getElementById('webhookUrl');
        input.select();
        navigator.clipboard.writeText(input.value).then(() => {
            alert('کپی شد!');
        }).catch(() => {
            document.execCommand('copy');
            alert('کپی شد!');
        });
    });

    // ========== Helpers ==========
    function escapeHtml(str) {
        if (!str) return '';
        return String(str)
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;');
    }
})();
