# ECO RADAR 3.1 — Proyecto Android listo para convertir a APK

## Mejoras incluidas
- Interfaz renovada tipo centro de prevención.
- Pronóstico y probabilidad de lluvia.
- Índice ECO RADAR y detección de empeoramiento basada en variables meteorológicas.
- GPS y mapa.
- Alertas locales Android + alertas por voz.
- Monitoreo periódico en segundo plano.
- Acceso directo a avisos oficiales de SENAMHI.
- Acceso directo a reportes sísmicos oficiales IGP/CENSIS.
- Widget Android y reinicio automático del monitor tras reiniciar el teléfono.
- Se eliminó la dependencia del workflow de GitHub.

## Importante
ECO RADAR no predice terremotos. Los eventos sísmicos se deben verificar con IGP/CENSIS.
Los avisos de SENAMHI se consideran fuente oficial; la app puede notificar que debe revisarse un aviso, pero no debe presentar una estimación propia como si fuera un aviso de SENAMHI.

## Conversión a APK sin GitHub
Abre este proyecto en Android Studio o en un compilador Android compatible, ejecuta:
`./gradlew assembleDebug`
El APK se genera en:
`app/build/outputs/apk/debug/app-debug.apk`

También puedes importar la carpeta completa en una plataforma de compilación Android que acepte proyectos Gradle/Android. No se necesita GitHub.
