export default async function handler(req,res){
  if(req.method!=='POST') return res.status(405).json({error:'Método não permitido'});
  const key=process.env.GROQ_API_KEY;
  if(!key) return res.status(500).json({error:'GROQ_API_KEY não configurada'});
  try{
    const {topic='esportes'}=req.body||{};
    const prompt=`Você é o analista do SportsHub. Faça uma análise curta, clara e útil sobre ${topic}. Explique momento, pontos fortes, o que observar e contexto competitivo. Não invente resultados recentes que não foram fornecidos. Responda em português do Brasil.`;
    const r=await fetch('https://api.groq.com/openai/v1/chat/completions',{method:'POST',headers:{'Authorization':`Bearer ${key}`,'Content-Type':'application/json'},body:JSON.stringify({model:'openai/gpt-oss-120b',messages:[{role:'system',content:'Você é um analista esportivo objetivo.'},{role:'user',content:prompt}],temperature:0.5,max_tokens:500})});
    const data=await r.json(); if(!r.ok) return res.status(r.status).json({error:data?.error?.message||'Erro na Groq'});
    return res.status(200).json({text:data.choices?.[0]?.message?.content||'Sem resposta'});
  }catch(e){return res.status(500).json({error:e.message||'Erro interno'})}
}
