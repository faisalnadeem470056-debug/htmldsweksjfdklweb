from PIL import Image, ImageEnhance, ImageFilter, ImageOps, ImageDraw
from pathlib import Path
import random, math, io

root=Path('/mnt/data/fixreal')
srcdir=root/'images'/'realistic'
out=srcdir/'phrases'
out.mkdir(exist_ok=True)

cats=['Motivacional','Românticas','Perdão','Distância','Religião','Fany','Bom dia','Boa noite','Saudade','Compromisso','Amizade','Esperança']
mapcat={'Motivacional':'motivacional','Românticas':'romanticas','Perdão':'religiao','Distância':'distancia','Religião':'religiao','Fany':'fany','Bom dia':'bom_dia','Boa noite':'boa_noite','Saudade':'saudade','Compromisso':'compromisso','Amizade':'amizade','Esperança':'esperanca'}
base={k:Image.open(srcdir/(v+'.jpg')).convert('RGB') for k,v in mapcat.items()}
# Add a soft vector dove source for forgiveness if desired, but use religion photo as realistic base.
W,H=720,480

# Build a varied pool from all available photos for subtle secondary overlays.
allims=list({id(im):im for im in base.values()}.values())

def fit_crop(im, cx, cy, zoom):
    # crop a 16:10 window with controlled zoom/offset, then resize
    w,h=im.size
    cw=min(w, int(w/zoom)); ch=min(h, int(cw*H/W))
    if ch>h: ch=h; cw=min(w,int(ch*W/H))
    left=max(0,min(w-cw,int((w-cw)*cx)))
    top=max(0,min(h-ch,int((h-ch)*cy)))
    return im.crop((left,top,left+cw,top+ch)).resize((W,H),Image.Resampling.LANCZOS)

def make(idx, cat):
    rng=random.Random(99173+idx*7919)
    im=base[cat]
    # unique crop/zoom per index
    cx=rng.uniform(.05,.95); cy=rng.uniform(.05,.95)
    zoom=rng.uniform(1.0,1.38)
    a=fit_crop(im,cx,cy,zoom)
    # Occasionally flip, but deterministically.
    if rng.random()<.22: a=ImageOps.mirror(a)
    # Blend a second photo softly to create a distinct, natural atmospheric variation.
    other=allims[(idx*7+3)%len(allims)]
    b=fit_crop(other,rng.random(),rng.random(),rng.uniform(1.0,1.25))
    b=ImageEnhance.Brightness(b).enhance(rng.uniform(.75,1.05))
    mask=Image.new('L',(W,H),0)
    d=ImageDraw.Draw(mask)
    # broad edge/diagonal overlay, low opacity
    side=rng.choice([0,1,2,3])
    if side==0: d.rectangle((0,0,W//2,H),fill=rng.randint(18,38))
    elif side==1: d.rectangle((W//2,0,W,H),fill=rng.randint(18,38))
    elif side==2: d.rectangle((0,0,W,H//2),fill=rng.randint(18,38))
    else: d.rectangle((0,H//2,W,H),fill=rng.randint(18,38))
    a=Image.composite(b,a,mask)
    # unique photo-like grading
    a=ImageEnhance.Contrast(a).enhance(rng.uniform(.90,1.15))
    a=ImageEnhance.Color(a).enhance(rng.uniform(.88,1.16))
    a=ImageEnhance.Brightness(a).enhance(rng.uniform(.92,1.08))
    if rng.random()<.35:
        a=a.filter(ImageFilter.GaussianBlur(rng.uniform(.15,.55)))
    # subtle vignette, unique strength
    vig=Image.new('L',(W,H),255)
    px=vig.load(); strength=rng.randint(8,28)
    for y in range(H):
        yy=(y-H/2)/(H/2)
        for x in range(W):
            xx=(x-W/2)/(W/2)
            r=min(1, math.sqrt(xx*xx+yy*yy)/1.414)
            px[x,y]=255-int(strength*r*r)
    a=Image.composite(a, ImageEnhance.Brightness(a).enhance(.78), ImageOps.invert(vig))
    # Tiny unique exposure grain to ensure byte-level uniqueness without visible artifacts.
    buf=io.BytesIO(); a.save(buf,'JPEG',quality=76,optimize=True,subsampling=2)
    data=bytearray(buf.getvalue())
    # JPEG comment marker would be more intrusive; append harmless trailing bytes is tolerated but avoid.
    # Instead vary quality already.
    (out/f'{idx}.jpg').write_bytes(data)

for i in range(600):
    # Read categories from index.js P array by parsing JSON-ish strings is overkill; map in same order as category blocks.
    # Extract actual category from index.html's P JSON below.
    pass
