KORYOB APK PROJECT — ҚАДАМҲО

1) Ин ZIP-ро дар Android Studio ё AndroidIDE кушо.
2) Sync/Build-ро иҷро кун.
3) Build > Build APK(s)-ро интихоб кун.
4) APK-и debug дар:
   app/build/outputs/apk/debug/app-debug.apk

Муҳим:
- Firebase Web config дар script.js ҷойгир аст.
- Интернет барои Firebase лозим аст.
- Firestore Rules бояд барои корбарони иҷозатдодашуда дуруст танзим шуда бошад.
- Ин версия WebView аст.
