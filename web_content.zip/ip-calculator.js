function calculateIP() {
    const ip = document.getElementById("ip").value.trim();
    let subnet = document.getElementById("subnet").value.trim();
    const result = document.getElementById("result");

    if (!isValidIP(ip)) {
        result.innerHTML = "<p>IP Address tidak valid.</p>";
        return;
    }

    // Kalau input berupa CIDR, contoh /24
    if (subnet.startsWith("/")) {
        const cidr = Number(subnet.substring(1));

        if (cidr < 0 || cidr > 32 || !Number.isInteger(cidr)) {
            result.innerHTML = "<p>CIDR harus antara /0 sampai /32.</p>";
            return;
        }

        subnet = cidrToMask(cidr);
    }

    if (!isValidIP(subnet)) {
        result.innerHTML = "<p>Subnet Mask tidak valid.</p>";
        return;
    }

    const ipParts = ip.split(".").map(Number);
    const subnetParts = subnet.split(".").map(Number);

    const network = ipParts.map((value, i) => {
        return value & subnetParts[i];
    });

    const broadcast = ipParts.map((value, i) => {
        return network[i] | (255 - subnetParts[i]);
    });

    const cidr = maskToCIDR(subnetParts);
    const hostBits = 32 - cidr;

    const totalHosts = Math.pow(2, hostBits);
    const usableHosts = hostBits >= 2 ? totalHosts - 2 : 0;

    result.innerHTML = `
        <div class="result-box">
            <h2>Hasil</h2>

            <p><b>IP Address:</b> ${ip}</p>
            <p><b>Subnet Mask:</b> ${subnet}</p>
            <p><b>CIDR:</b> /${cidr}</p>
            <p><b>Network:</b> ${network.join(".")}</p>
            <p><b>Broadcast:</b> ${broadcast.join(".")}</p>
            <p><b>Total Address:</b> ${totalHosts}</p>
            <p><b>Host yang dapat digunakan:</b> ${usableHosts}</p>
        </div>
    `;
}

function cidrToMask(cidr) {
    const parts = [];

    for (let i = 0; i < 4; i++) {
        const bits = Math.min(8, Math.max(0, cidr - i * 8));

        if (bits === 0) {
            parts.push(0);
        } else {
            parts.push(256 - Math.pow(2, 8 - bits));
        }
    }

    return parts.join(".");
}

function maskToCIDR(mask) {
    return mask
        .map(number => number.toString(2).padStart(8, "0"))
        .join("")
        .split("")
        .filter(bit => bit === "1")
        .length;
}

function isValidIP(ip) {
    const parts = ip.split(".");

    if (parts.length !== 4) {
        return false;
    }

    return parts.every(part => {
        const number = Number(part);

        return (
            part !== "" &&
            Number.isInteger(number) &&
            number >= 0 &&
            number <= 255
        );
    });
}