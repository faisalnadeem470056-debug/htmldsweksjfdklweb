let catatan = JSON.parse(
    localStorage.getItem("catatanTKJ")
) || [];

let catatanTerbuka = null;


function simpanCatatan() {

    const judul =
        document.getElementById("judul").value.trim();

    const kategori =
        document.getElementById("kategori").value.trim();

    const isi =
        document.getElementById("isi").value.trim();


    if (judul === "" || isi === "") {

        alert("Nama materi dan isi harus diisi.");

        return;
    }


    const data = {

        id: Date.now(),

        judul: judul,

        kategori: kategori || "Umum",

        isi: isi

    };


    catatan.push(data);

    localStorage.setItem(
        "catatanTKJ",
        JSON.stringify(catatan)
    );


    document.getElementById("judul").value = "";
    document.getElementById("kategori").value = "";
    document.getElementById("isi").value = "";


    tampilkanCatatan();
}


function tampilkanCatatan(data = catatan) {

    const daftar =
        document.getElementById("daftarCatatan");


    if (data.length === 0) {

        daftar.innerHTML = `
            <p style="color:#9da3ae;">
                Materi tidak ditemukan.
            </p>
        `;

        return;
    }


    let output = "";


    data.forEach(function(item) {

        const terbuka =
            catatanTerbuka === item.id;


        output += `

            <div
                class="result-box"
                style="cursor:pointer;"
                onclick="bukaCatatan(${item.id})"
            >

                <div style="
                    display:flex;
                    justify-content:space-between;
                    align-items:center;
                    gap:10px;
                ">

                    <div>

                        <h2 style="margin-bottom:5px;">
                            ${item.judul}
                        </h2>

                        <p style="
                            color:#9da3ae;
                            font-size:13px;
                        ">
                            ${item.kategori}
                        </p>

                    </div>

                    <b>
                        ${terbuka ? "▲" : "▼"}
                    </b>

                </div>


                ${
                    terbuka
                    ?
                    `
                        <div style="
                            margin-top:15px;
                            padding-top:15px;
                            border-top:1px solid #292d36;
                        ">

                            <p style="
                                white-space:pre-wrap;
                                line-height:1.6;
                            ">
                                ${item.isi}
                            </p>

                            <button
                                onclick="event.stopPropagation(); hapusCatatan(${item.id})"
                            >
                                HAPUS
                            </button>

                        </div>
                    `
                    :
                    ""
                }

            </div>

        `;

    });


    daftar.innerHTML = output;
}


function bukaCatatan(id) {

    if (catatanTerbuka === id) {

        catatanTerbuka = null;

    } else {

        catatanTerbuka = id;

    }

    cariCatatan();
}


function cariCatatan() {

    const keyword =
        document.getElementById("search").value
        .toLowerCase()
        .trim();


    const hasil = catatan.filter(function(item) {

        return (
            item.judul.toLowerCase().includes(keyword) ||
            item.kategori.toLowerCase().includes(keyword) ||
            item.isi.toLowerCase().includes(keyword)
        );

    });


    tampilkanCatatan(hasil);
}


function hapusCatatan(id) {

    catatan = catatan.filter(function(item) {

        return item.id !== id;

    });


    if (catatanTerbuka === id) {

        catatanTerbuka = null;

    }


    localStorage.setItem(
        "catatanTKJ",
        JSON.stringify(catatan)
    );


    cariCatatan();
}


tampilkanCatatan();