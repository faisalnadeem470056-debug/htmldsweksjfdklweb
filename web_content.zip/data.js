/* NPL DATA — keep official/verified information here. */
window.NPL_DATA = {
  league: {
    shortName: "NPL",
    fullName: "Noapur Premier League",
    location: "Noapur",
    startingText: "Starting 2017",
    currentSeasonId: "s30",
    whatsapp: "8801615012884",
    facebook: "https://www.facebook.com/share/1T1SGGJKeL/?mibextid=wwXIfr",
    achievementPost: "https://www.facebook.com/share/p/1DTRPvT6vs/?mibextid=wwXIfr",
    description: "আমাদের প্রাণের নোয়াপুর গ্রাম, আমাদের আবেগ ও ঐক্যের প্রতীক Noapur Premier League (NPL)। খেলাধুলার মাধ্যমে ভ্রাতৃত্ব, বন্ধুত্ব, সহযোগিতা ও আনন্দকে একসাথে ধরে রাখাই আমাদের পথচলা।"
  },
  seasons: [
    { id:"s30", number:30, year:null, name:"NPL Season 30", status:"Upcoming Soon", description:"Season 30 is the upcoming chapter of Noapur Premier League. Official teams, fixtures and statistics will be added as they are confirmed.", teams:[], players:[], matches:[], standings:[], awards:[], gallery:[], videos:[], news:[] },
    ...Array.from({length:10},(_,i)=>{const n=29-i;return {id:`s${n}`,number:n,year:null,name:`NPL Season ${n}`,status:"Memories Updating Soon",description:`Season ${n} archive is being prepared. Memories, champions and verified information will be updated soon.`,teams:[],players:[],matches:[],standings:[],awards:[],gallery:[],videos:[],news:[]};})
  ],
  juniorNPL: {
    name:"Junior NPL", number:8, status:"Season 8",
    description:"বড় ভাইদের NPL দেখে অনুপ্রাণিত হয়েই আমাদের JR.NPL-এর পথচলা শুরু হয় ২০২৩ সালে। ছোটদের জন্য একটি সুন্দর ক্রিকেট প্ল্যাটফর্ম তৈরি করা, প্রতিভাবান খেলোয়াড়দের খুঁজে বের করা এবং খেলাধুলার মাধ্যমে ভ্রাতৃত্ব ও সৌহার্দ্য তৈরি করাই আমাদের মূল লক্ষ্য।",
    teams:[], players:[
      {id:"jr-irfan",name:"Irfan",jersey:"77"},
      {id:"jr-rifat",name:"Rifat",jersey:"45"},
      {id:"jr-rezaul",name:"Rezaul",jersey:"15"},
      {id:"jr-sagor",name:"Sagor",jersey:"20"},
      {id:"jr-shabab",name:"Shabab",jersey:"22"},
      {id:"jr-mezbah",name:"Mezbah",jersey:"75"},
      {id:"jr-sifat-1",name:"Sifat 1",jersey:"30"},
      {id:"jr-siam-1",name:"Siam (1)",jersey:"50"},
      {id:"jr-siam-2",name:"Siam (2)",jersey:"17"},
      {id:"jr-sifat-2",name:"Sifat (2)",jersey:"09"},
      {id:"jr-rahim",name:"Rahim",jersey:"10"},
      {id:"jr-abab",name:"Abab",jersey:"47"},
      {id:"jr-saikat",name:"Saikat",jersey:"100"},
      {id:"jr-arafat",name:"Arafat",jersey:"29"},
      {id:"jr-sunny",name:"Sunny",jersey:"80"},
      {id:"jr-tamin",name:"Tamin",jersey:"200"}
    ], matches:[], standings:[], awards:[], gallery:[], videos:[], news:[]
  },
  players: [
    { id:"sami", name:"Sami", jersey:"Not Fixed", rating:6, photo:"assets/players/sami.jpeg", role:"Player", bio:"Player profile information will be added soon.", restrictions:"No restrictions added yet." },
    { id:"rahad", name:"Rahad", jersey:"21", rating:8, photo:"assets/players/rahad.jpeg", role:"Player", bio:"Player profile information will be added soon.", restrictions:"No restrictions added yet." },
    { id:"murad", name:"Murad", jersey:"Not Fixed", rating:4, photo:"assets/players/murad.jpeg", role:"Player", bio:"Player profile information will be added soon.", restrictions:"No restrictions added yet." }
  ],
  memories: [
    {
      id:"memory-17-may-2025",
      image:"assets/npl-memory-17-may-2025.jpeg",
      date:"17 May 2025",
      season:"NPL Season 28",
      title:"একসাথে এগিয়ে চলার এক সুন্দর স্মৃতি",
      caption:"১৭ মে ২০২৫ — NPL Season 28-এর একটি স্মরণীয় মুহূর্ত। আপনারা দেখতে পাচ্ছেন, আমাদের NPL-এ গ্রামের বন্ধু, বড় ভাই, ছোট ভাই ও গ্রামবাসীরা একসাথে ঐক্যবদ্ধ হয়ে NPL-কে এগিয়ে নিয়ে যাচ্ছেন। ক্রিকেটের মাঠের এই বন্ধনই আমাদের NPL-এর সবচেয়ে সুন্দর পরিচয়।"
    }
  ],
  announcements: [
    {date:"NPL • 2026", title:"NPL Season 30 — Coming Soon", text:"নোয়াপুর প্রিমিয়ার লিগের নতুন অধ্যায় Season 30 খুব শিগগিরই শুরু হবে। অফিসিয়াল সময়সূচি ও অন্যান্য তথ্য নিশ্চিত হলে এখানে প্রকাশ করা হবে।"}
  ],
  news: [],
  history: [],
  achievements: [
    {
      id:"achievement-drone-gift",
      date:"19 April",
      title:"NPL-এর জন্য একটি ড্রোন উপহার",
      image:"assets/npl-drone-gift.jpeg",
      text:"আলহামদুলিল্লাহ! ❤️\n\nমাহমুদুল হাসান ভাইয়ের সহযোগিতা এবং Shazzadul Islam ভাইয়ের চেষ্টায় চায়না থেকে আজ আমরা আমাদের গ্রাম ও NPL-এর জন্য একটি ড্রোন হাতে পেয়েছি 🚁✨\n\nএটা আমাদের জন্য অনেক খুশির একটি বিষয়। এখন আমরা আমাদের গ্রামের সুন্দর মুহূর্তগুলো, খেলাধুলা আর বিশেষ ঘটনাগুলো আরও ভালোভাবে সবার সাথে শেয়ার করতে পারবো, ইনশাআল্লাহ 🎥🌿\n\nআপনাদের এই সাপোর্ট আমাদের সামনে এগিয়ে যেতে অনেক সাহায্য করবে! আবারও আন্তরিক ধন্যবাদ জানাই সিজান ভাইকে, আর বিশেষভাবে ধন্যবাদ মাহমুদুল হাসান ভাইকে ❤️ — Feeling lovely."
    }
  ]
};
