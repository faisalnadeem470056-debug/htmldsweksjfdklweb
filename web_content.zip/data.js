export const SYLLABUS = {
  Physics: [
    ['p1','Electricity: Magnetic and Heating Effects (8th)'],
    ['p2','Pressure, Winds, Storms, and Cyclones (8th)'],
    ['p3','Light: Mirrors and Lenses (8th)'],
    ['p4','Describing Motion Around Us (9th)'],
    ['p5','How Forces Affect Motion (9th)'],
    ['p6','Work and Energy (9th)']
  ],
  Chemistry: [
    ['c1','Particulate Nature of Matter (8th)'],
    ['c2','Nature of Matter: Elements, Compounds, and Mixtures (8th)'],
    ['c3','The Amazing World of Solutes, Solvents, and Solutions (8th)'],
    ['c4','Exploring Mixtures and Their Separation (9th)'],
    ['c5','Journey Inside the Atom (9th)']
  ],
  Biology: [
    ['b1','Health: The Ultimate Treasure'],
    ['b2','How Nature Works in Harmony'],
    ['b3','Our Home: Earth, a Unique Life Sustaining Planet'],
    ['b4','Cell'],
    ['b5','Tissues in Action']
  ],
  Maths: [
    ['m1','Orienting Yourself: The Use of Coordinates (9th)'],
    ['m2','Introduction to Linear Polynomials (9th)'],
    ['m3','The World of Numbers (9th)'],
    ['m4','Exploring Algebraic Identities (9th)'],
    ['m5',"I'm Up and Down, and Round and Round (9th)"],
    ['m6','Measuring Space: Perimeter and Area (9th)'],
    ['m7','The Mathematics of Maybe: Introduction to Probability (9th)'],
    ['m8','Area (8th)'],
    ['m9','Algebra Basics (8th)'],
    ['m10','Fractions in Disguise (8th)'],
    ['m11','Proportional Reasoning (8th)'],
    ['m12','Power Plays (8th)'],
    ['m13','Quadrilaterals (8th)']
  ],
  IQ: [
    ['i1','Alphabet Test'],['i2','Blood Relation'],['i3','Coding-Decoding'],['i4','Counting of Figures'],['i5','Dice'],['i6','Cube'],['i7','Direction Sense'],['i8','Embedded Figure'],['i9','Puzzle Test'],['i10','Sitting Arrangement'],['i11','Inserting the Missing Character'],['i12','Series (Verbal & Non-Verbal)'],['i13','Mathematical Operations'],['i14','Mirror Image'],['i15','Number, Ranking and Time Sequence Test'],['i16','Venn Diagram'],['i17','Water Image']
  ]
};

const q = (id,subject,topic,difficulty,question,options,correctAnswer,explanation) => ({id,subject,topic,difficulty,question,options,correctAnswer,explanation});
export const QUESTIONS = [
q('p-q1','Physics','Describing Motion Around Us (9th)','Easy','A car travels 120 m in 10 s. What is its average speed?',['10 m/s','12 m/s','1200 m/s','0.083 m/s'],1,'Average speed = distance ÷ time = 120 ÷ 10 = 12 m/s.'),
q('p-q2','Physics','How Forces Affect Motion (9th)','Medium','Which quantity measures the change in velocity per unit time?',['Speed','Acceleration','Distance','Momentum'],1,'Acceleration is the rate of change of velocity.'),
q('p-q3','Physics','Work and Energy (9th)','Medium','A force of 10 N moves an object 5 m in the direction of the force. Work done is:',['2 J','15 J','50 J','100 J'],2,'Work = force × displacement = 10 × 5 = 50 J.'),
q('p-q4','Physics','Light: Mirrors and Lenses (8th)','Easy','A plane mirror forms an image that is:',['Real and inverted','Virtual and erect','Real and enlarged','Virtual and inverted'],1,'A plane mirror produces a virtual, erect image of equal size.'),
q('p-q5','Physics','Pressure, Winds, Storms, and Cyclones (8th)','Easy','Wind generally moves from a region of:',['Low pressure to high pressure','High pressure to low pressure','High temperature to low temperature only','No pressure to high pressure'],1,'Air moves from higher pressure toward lower pressure.'),
q('c-q1','Chemistry','Particulate Nature of Matter (8th)','Easy','Matter is made up of:',['Only cells','Tiny particles','Only liquids','Energy alone'],1,'Matter is composed of very small particles.'),
q('c-q2','Chemistry','Nature of Matter: Elements, Compounds, and Mixtures (8th)','Medium','Which is a compound?',['Air','Brass','Water','Soil'],2,'Water is a compound with hydrogen and oxygen chemically combined.'),
q('c-q3','Chemistry','The Amazing World of Solutes, Solvents, and Solutions (8th)','Easy','In salt water, salt is the:',['Solvent','Solute','Residue','Indicator'],1,'Salt dissolves in water, so salt is the solute.'),
q('c-q4','Chemistry','Exploring Mixtures and Their Separation (9th)','Medium','Which method separates an insoluble solid from a liquid?',['Filtration','Distillation','Sublimation','Chromatography'],0,'Filtration retains the insoluble solid while liquid passes through.'),
q('c-q5','Chemistry','Journey Inside the Atom (9th)','Medium','The negatively charged particle in an atom is the:',['Proton','Neutron','Electron','Nucleus'],2,'Electrons carry negative charge.'),
q('b-q1','Biology','Cell','Easy','The basic structural and functional unit of life is the:',['Tissue','Cell','Organ','Organ system'],1,'The cell is the basic unit of life.'),
q('b-q2','Biology','Tissues in Action','Easy','A group of similar cells performing a common function is called a:',['Tissue','System','Species','Molecule'],0,'A tissue is a group of similar cells with a common function.'),
q('b-q3','Biology','Health: The Ultimate Treasure','Medium','Which habit best supports good health?',['Regular exercise and balanced diet','Skipping sleep','Avoiding water','Only studying'],0,'Balanced nutrition, activity and adequate rest support health.'),
q('b-q4','Biology','How Nature Works in Harmony','Medium','Organisms in an ecosystem are connected mainly through:',['Food chains and interactions','Only rocks','Only weather','No relationships'],0,'Energy and matter move through interconnected organisms and their environment.'),
q('b-q5','Biology','Our Home: Earth, a Unique Life Sustaining Planet','Easy','Which gas is essential for aerobic respiration?',['Nitrogen','Oxygen','Helium','Neon'],1,'Oxygen is required for aerobic respiration.'),
q('m-q1','Maths','The World of Numbers (9th)','Easy','Which number is irrational?',['1/2','0.25','√2','4'],2,'√2 cannot be expressed as a ratio of two integers.'),
q('m-q2','Maths','Exploring Algebraic Identities (9th)','Medium','(a+b)² equals:',['a²+b²','a²+2ab+b²','a²-2ab+b²','2a+2b'],1,'The square identity is a² + 2ab + b².'),
q('m-q3','Maths','Orienting Yourself: The Use of Coordinates (9th)','Easy','The point (0, 5) lies on the:',['x-axis','y-axis','origin only','quadrant IV'],1,'A point with x-coordinate 0 lies on the y-axis.'),
q('m-q4','Maths','The Mathematics of Maybe: Introduction to Probability (9th)','Easy','The probability of a certain event is:',['0','1/2','1','2'],2,'A certain event has probability 1.'),
q('m-q5','Maths','Measuring Space: Perimeter and Area (9th)','Medium','The area of a rectangle 8 cm long and 3 cm wide is:',['11 cm²','24 cm²','22 cm','48 cm²'],1,'Area = length × width = 8 × 3 = 24 cm².'),
q('m-q6','Maths','Fractions in Disguise (8th)','Medium','Which is equivalent to 3/4?',['6/8','4/3','9/16','12/20'],0,'Multiplying numerator and denominator by 2 gives 6/8.'),
q('m-q7','Maths','Quadrilaterals (8th)','Easy','The sum of the interior angles of a quadrilateral is:',['180°','270°','360°','540°'],2,'A quadrilateral can be divided into two triangles, giving 360°.'),
q('i-q1','IQ','Alphabet Test','Easy','Which letter comes next: A, C, E, G, ?',['H','I','J','K'],1,'The sequence advances by two letters each time.'),
q('i-q2','IQ','Coding-Decoding','Medium','If CAT is coded as DBU, how is DOG coded using the same rule?',['EPH','EOG','DPH','FPI'],0,'Each letter is shifted one position forward: D→E, O→P, G→H.'),
q('i-q3','IQ','Direction Sense','Easy','A person walks north, then turns right. Which direction are they facing?',['West','East','South','North'],1,'A right turn from north points east.'),
q('i-q4','IQ','Series (Verbal & Non-Verbal)','Medium','Find the next number: 2, 5, 8, 11, ?',['12','13','14','15'],2,'Each term increases by 3.'),
q('i-q5','IQ','Blood Relation','Medium','Riya says, “He is the son of my mother’s only daughter.” The boy is Riya’s:',['Brother','Son','Father','Uncle'],1,'Riya’s mother’s only daughter is Riya, so the boy is her son.'),
q('i-q6','IQ','Venn Diagram','Easy','Which shape best represents students who play cricket and football?',['Two overlapping circles','Two separate circles','A triangle only','A single point'],0,'The overlap represents students belonging to both groups.'),
q('i-q7','IQ','Mirror Image','Easy','A mirror image reverses an object mainly along its:',['Vertical axis','Horizontal axis','Diagonal only','Depth only'],0,'A standard mirror reverses left and right across a vertical plane.'),
q('i-q8','IQ','Mathematical Operations','Easy','If + means × and × means +, then 3 + 4 × 2 equals:',['14','20','10','24'],0,'Replace symbols: 3×4 + 2 = 14.'),
];

export const EXAM_PATTERNS = {
  offline: {label:'Offline Mock', questions:80, duration:120, counts:{Physics:15,Chemistry:15,Biology:15,Maths:15,IQ:20}},
  online: {label:'Online Mock', questions:100, duration:120, counts:{Physics:19,Chemistry:18,Biology:19,Maths:19,IQ:25}}
};
