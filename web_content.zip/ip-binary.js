function ipToBinary() {

    const ip = document.getElementById("ipInput").value.trim();
    const result = document.getElementById("binaryResult");

    const parts = ip.split(".");

    if (parts.length !== 4) {
        result.innerHTML = "<p>IP Address tidak valid.</p>";
        return;
    }

    const valid = parts.every(part => {
        const number = Number(part);

        return (
            part !== "" &&
            Number.isInteger(number) &&
            number >= 0 &&
            number <= 255
        );
    });

    if (!valid) {
        result.innerHTML = "<p>IP Address tidak valid.</p>";
        return;
    }

    const binary = parts.map(part => {
        return Number(part)
            .toString(2)
            .padStart(8, "0");
    });

    result.innerHTML = `
        <div class="result-box">
            <h2>Hasil</h2>
            <p><b>IP:</b> ${ip}</p>
            <p><b>Binary:</b> ${binary.join(".")}</p>
        </div>
    `;
}


function binaryToIP() {

    const binary = document
        .getElementById("binaryInput")
        .value
        .trim();

    const result = document.getElementById("ipResult");

    const parts = binary.split(".");

    if (parts.length !== 4) {
        result.innerHTML = "<p>Binary tidak valid.</p>";
        return;
    }

    const valid = parts.every(part => {
        return /^[01]{8}$/.test(part);
    });

    if (!valid) {
        result.innerHTML = "<p>Setiap bagian harus 8 bit.</p>";
        return;
    }

    const ip = parts.map(part => {
        return parseInt(part, 2);
    });

    result.innerHTML = `
        <div class="result-box">
            <h2>Hasil</h2>
            <p><b>Binary:</b> ${binary}</p>
            <p><b>IP Address:</b> ${ip.join(".")}</p>
        </div>
    `;
}