huh? HTML app
================
Upload this ZIP to an HTML-to-APK builder.
Entry file: index.html
The app contains the included image panel, search, and Android share-sheet support.
