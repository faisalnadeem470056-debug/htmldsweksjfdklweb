Fany — Francisca Eduardo App v2 (corrigido)

Alterações:
- Removida a expressão "Respire, confie e continue." de todas as frases.
- Eliminadas as repetições: agora existem 600 textos diferentes.
- Cada frase possui a sua própria imagem local em images/0.svg até images/599.svg.
- As imagens das frases abrem sem internet.
- A imagem da secção Fany também é local (images/fany.svg).
- Removidas as imagens externas do Unsplash.
- Favoritos continuam guardados no armazenamento local do navegador.

Para usar: abra index.html. Não é necessário servidor nem internet para as imagens.
