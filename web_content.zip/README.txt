HFS App — Haji Furniture Showroom
=================================

This is a responsive mobile-friendly web app/prototype for HFS.

Included:
- HFS branding
- Home/hero section
- Furniture collection using the uploaded photos
- 10% follower offer
- Call and WhatsApp buttons
- Showroom location button
- Mobile-friendly design

How to use:
1. Extract HFS_App.zip.
2. Open index.html in a browser.
3. For a phone home-screen experience, open it in Chrome and use "Add to Home screen".
