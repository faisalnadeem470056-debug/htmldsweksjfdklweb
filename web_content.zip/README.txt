TURBO RACER X — MOBILE APP

This is an installable Progressive Web App (PWA).

PHONE INSTALL:
1. Put this folder on a web server (or use a simple local web server).
2. Open index.html through the server in Chrome.
3. Tap Chrome menu (⋮) → Add to Home screen / Install app.
4. Launch "Turbo Racer X" from your home screen. It opens like an app.

The game works with touch/drag, left/right buttons and Nitro.
