NOVA - application HTML
Fichiers : index.html, style.css, app.js
Pour créer un APK : compresser ces 3 fichiers dans un ZIP, puis envoyer le ZIP dans AndroidBuild.
