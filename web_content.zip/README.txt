KAS ACCOUNTING 2026 - PWA V3
==============================
Cara pakai tanpa Android Studio:
1. Upload folder ini ke hosting yang mendukung HTTPS (misalnya GitHub Pages, Netlify, Vercel, atau hosting sendiri).
2. Buka alamatnya dari Chrome Android.
3. Pilih menu Chrome > "Tambahkan ke layar utama" / "Install app".
4. Aplikasi dapat dipakai seperti aplikasi Android dan data transaksi tersimpan di perangkat.
PIN awal: 1234

Catatan: Untuk install PWA, hosting perlu HTTPS (kecuali localhost).
Backup tersedia di menu Laporan -> Backup JSON.
