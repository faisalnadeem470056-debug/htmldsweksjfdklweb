FN Academy V1 — Android + iPhone/iPad

Este pacote usa a mesma FN Academy para as duas plataformas.

ANDROID / GOOGLE PLAY
1. Instalar Node.js e Android Studio.
2. Na pasta do projeto:
   npm install
   npx cap add android
   npx cap sync android
   npx cap open android
3. No Android Studio, gerar o AAB assinado para a Google Play.

IPHONE / IPAD / APP STORE
1. É necessário um Mac com Xcode.
2. Na pasta do projeto:
   npm install
   npx cap add ios
   npx cap sync ios
   npx cap open ios
3. No Xcode, configurar a conta Apple Developer e gerar o Archive para App Store Connect.

IMPORTANTE
- O curso HTML é o mesmo nas duas versões.
- Antes de publicar, ainda convém preparar ícone, splash screen, política de privacidade e dados das lojas.
