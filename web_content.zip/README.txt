Открой эту папку в AndroidIDE. Затем Build > Assemble Debug.
