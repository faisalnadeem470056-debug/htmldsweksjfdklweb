Employee Card Designer - MOHAMED BADRAWY

This is a self-contained HTML/CSS/JavaScript app designed to be converted to APK.
index.html must remain at the ZIP root. The fixed card template is in img/card_template.png.

Main features:
- Arabic/English UI
- Name, job, workplace, phone, residence, code
- Fixed automatic photo placement
- Photo filters and optional overlay text
- Per-field color and font
- Optional QR preview and phone pill
- New Person reset
- Save final card as PNG
