PUZZLE QUEST v0.3
Prototype mobile avec menu, carte et 12 niveaux/énigmes.
Ouvrir index.html avec Chrome.
La prochaine étape peut être l'emballage Android et l'ajout des vrais graphismes/sons.
