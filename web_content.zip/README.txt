MAURIFLIX — version WebToApp
Cette version est prête à être importée comme projet HTML dans WebToApp.
Fonctions : ajout de vidéos, bibliothèque locale, recherche, tri, lecture et suppression.
