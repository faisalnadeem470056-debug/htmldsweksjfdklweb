NOVA-K AGENCY — APP v6

Versión V5 + rediseño visual premium:
- Estética oscura/cósmica NOVA-K.
- Gradientes morado/azul, tarjetas premium y efectos de profundidad.
- Mejor jerarquía visual y legibilidad.
- Botones, estados y KPIs más claros.
- Animaciones suaves.
- Mantiene todas las funciones, datos e historial de la V5.
