TESTE HTML → APK

Projeto mínimo com apenas index.html.

Envie o arquivo ZIP para um conversor HTML → APK.
O aplicativo deve abrir mostrando "TESTE HTML APK OK".
