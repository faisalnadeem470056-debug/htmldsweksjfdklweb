WANN SHATSHET - HTML project
Upload the ZIP containing index.html and assets/ to an HTML-to-APK builder.
