StudyMaster V8

Open index.html in a modern browser. No internet is required.

V7 additions:
- 8 subjects: Physics, Chemistry, Mathematics, English, General Knowledge, Urdu, Sindhi, Islamiat.
- Level 1–10 in every chapter.
- Exactly 10 MCQs per level.
- English / Urdu / Sindhi language selector before a quiz.
- Language can be changed while the same quiz is running.
- Urdu and Sindhi display in their native script.
- Level result: 6–10 = Completed, 0–4 = Failed, 5 = Not Passed.
- Completion status is saved locally.
- 10-minute quiz timer, random questions, review answers and local history.
- Dark mode.

Note: The new Urdu, Sindhi, Islamiat and General Knowledge banks include multilingual question content. The existing Physics, Chemistry, Mathematics and English banks remain available from V6/V5 and their existing question text is English; the language control is ready for multilingual expansion of those banks.


V8 EXPANSION
- 15 chapters per subject (8 subjects).
- Level 1-10 in every chapter.
- Exactly 10 MCQ slots per level.
- Existing offline multilingual quiz system retained.


V9 update: Added a styled top-center creator credit: “Created by Farhan Ali Bhutto”.
