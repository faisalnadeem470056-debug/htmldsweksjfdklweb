PROJECT SHADOW: NEON RAID
Original clean rebuild. No external game assets, music, characters, names, or logos are included.
Target: Android, compatible with armeabi-v7a when built with an Android SDK/NDK configuration that includes it.
