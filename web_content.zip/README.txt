TOY FACTORY: AFTER HOURS
Mobil tarayıcı için tek dosyalık korku oyunu prototipi.

Oynama:
1. index.html dosyasını Chrome ile aç.
2. BAŞLA'ya bas.
3. Sol joystick: hareket.
4. Sağ tarafı sürükle: kamerayı çevir.
5. ETKİLEŞ: jeneratörü çalıştır ve sonra çıkış kapısına git.

Not: Bu, Poppy Playtime'dan bağımsız özgün bir prototiptir.
