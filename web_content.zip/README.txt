MY AI — VINH AN (PWA)

Mở PWA qua HTTPS hoặc localhost (không mở trực tiếp bằng file://).
Sau đó chọn Cài đặt ứng dụng / Add to Home Screen.

API key trong HTML vẫn là khóa phía client; không nên dùng file này công khai với khóa thật.
