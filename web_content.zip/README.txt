BOLA FLAP — ANIMAÇÕES + MODELOS DE BOLA

- Toques geram partículas e pequenos efeitos visuais.
- Botões têm animação de pressionamento.
- Cada skin agora tem um modelo visual diferente:
  Couro, Futebol, Tênis, Prata, Ouro, Esmeralda e Diamante.
- A evolução visual vai da bola simples à bola mais sofisticada.
- O restante do jogo foi mantido.
