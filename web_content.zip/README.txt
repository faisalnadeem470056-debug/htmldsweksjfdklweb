BudgetPro — package HTML local pour conversion en APK
index.html contient l application autonome.
Utilise un convertisseur qui EMBARQUE le HTML dans une WebView; aucune URL HTTPS ni content:// nest nécessaire.
