AGUA POLAR H₂O — versión instalable en celular

Esta carpeta contiene la versión PWA del aplicativo:
- index.html: aplicativo
- manifest.webmanifest: nombre/ícono/presentación de app
- service-worker.js: soporte de funcionamiento offline y caché

IMPORTANTE:
Para que Android permita instalarla como aplicación, los archivos deben publicarse en un sitio HTTPS (por ejemplo, un hosting). Abrir el HTML como archivo local no activa todas las funciones de instalación PWA.

Cuando esté publicada, en Chrome Android se podrá usar "Instalar aplicación" o "Agregar a pantalla de inicio".
