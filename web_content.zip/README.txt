NOVA-K AGENCY - Control de Reclutamiento
Versión 1 (PWA/web app)
Funciones: reclutadores, contadores automáticos, reclutados, ID, nombre, aprobado/rechazado, editar y guardado local.
Para convertirla a APK: este proyecto puede envolverse con Capacitor/Android Studio en un entorno de compilación Android.
