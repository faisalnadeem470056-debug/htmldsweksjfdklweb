TradeLab 3-Sheet Final

1st tab: All Year — yearly P&L statement only, based on Trading Journal All Year.
2nd tab: 2025-26 — yearly/monthly dashboard only; no trade input.
3rd tab: 2026-27 — dashboard + current-year trade input.
New trade input is restricted to 2026-27 and its calculated net P&L flows into daily and monthly/current-year live totals.
Original workbook values are kept as the base dashboard values.
