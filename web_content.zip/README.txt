FX + Crypto Easy APK Project
==============================

This is a simple HTML/CSS/JavaScript paper-trading demo designed to be easy to package as an Android APK from a phone.

The app contains:
- Forex and crypto demo markets
- Virtual $10,000 balance
- BUY/SELL paper-order buttons
- Forex/Crypto filters
- Mobile-friendly dark UI

It does NOT connect to real money, a broker, or an exchange.

To convert it:
1. Keep index.html at the root of this ZIP.
2. Use an HTML-to-APK builder that accepts ZIP projects.
3. Set app name: FX Crypto Demo
4. Build APK and install it on Android.

For any future real-money version, use appropriate licensed providers and legal/compliance review.
