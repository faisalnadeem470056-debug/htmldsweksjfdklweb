ABOUD PES Android project
- اسم التطبيق: عبود بيس | ABOUD PES
- نسخة WebView من الواجهة التجريبية السابقة.
- لبناء APK: افتح المشروع في Android Studio ثم Build > Build APK(s).
- البيانات الرياضية داخل الواجهة تجريبية وليست نتائج حية.