CHLAZENI TOPENI FRYC – instalacni demo

Toto je hotova offline webova aplikace (PWA) v barvach a s logem z dodane vizitky.

PRO INSTALACI DO ANDROIDU:
1. Nahraj slozku na web/hosting s HTTPS.
2. Otevri index.html v Chrome.
3. V menu Chrome zvol „Pridat na plochu“ / „Instalovat aplikaci“.

Přímé APK zde nyní nevytvářím, protože v tomto pracovním prostředí není Android SDK/build toolchain. Zdroj je ale připravený jako instalovatelná PWA.
