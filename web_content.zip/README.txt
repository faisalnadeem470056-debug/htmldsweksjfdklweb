APP CODING - CLEAN COURSE LOGO VERSION

1. Extract the ZIP file.
2. Open the app_coding folder.
3. Open index.html in Chrome.

Includes:
- App Coding logo and banner
- Compact header and non-cropped banner
- Home, Courses and Profile pages
- Official-style HTML5, CSS3, JavaScript, Python, Android, Flutter, Firebase and Figma SVG logos
