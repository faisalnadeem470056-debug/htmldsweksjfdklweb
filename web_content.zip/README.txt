ALUCARD app project. No npm packages required. Put your API key in .env, then run: node server.js
