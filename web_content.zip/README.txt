BEERALEY PRO – MODERN WEB APP
================================
Noocan waxaa loo sameeyay in si fudud loogu rogo APK.

Waxyaabaha ku jira:
- UI casri ah oo mobile-first ah
- Geed/dalag kasta marka la taabto: faahfaahin
- 3 marxaladood: geed yar → koritaan → qaangaar/miro
- Waraab, bacrimin, cayayaan iyo talooyin daryeel
- Raadinta geedaha
- Bacriminta: NPK, Urea, DAP, Compost, digada, Potassium
- Jadwalka daryeelka
- WhatsApp: 0684411459 (link-ga app-ka wuxuu isticmaalaa +252)
- Diyaar u ah in HTML-to-APK builder lagu geliyo

Fiiro:
- Xogta aasaasiga ah app-ka waxay ku jirtaa gudaha faylasha.
- Cimilo/suuq qiime toos ah waxay u baahan yihiin API/online backend marka la hirgelinayo.
- Qiyaasta bacriminta ama pesticide-ka waa in lagu saleeyaa ciidda, dalagga, calaamadda alaabta iyo talada khabiirka deegaanka.


NOOCAAN LA CASRIYEY:
- Bogga geed kasta wuxuu leeyahay visual card, quick-care badges iyo 3 marxaladood oo faahfaahsan.
- WhatsApp contact 0684411459 ayaa ku jira Home, Settings iyo bog kasta oo geed ah.
- App-ka wuxuu ku shaqayn karaa gudaha APK iyadoo xogta aasaasiga ah la bundled-gareeyay.
