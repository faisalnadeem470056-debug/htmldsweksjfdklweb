-- دا فایل یو ځل په Supabase SQL Editor کې اجرا کړئ.
-- لومړی اصلي اډمین یوازې د 775216 کوډ په وسیله جوړېږي، او یوازې یو ځل.
drop function if exists public.claim_first_owner();
create or replace function public.claim_first_owner(p_code text)
returns json language plpgsql security definer set search_path=public as $$
begin
  if auth.uid() is null then return json_build_object('success',false,'message','حساب پیدا نه شو.'); end if;
  if p_code <> '775216' then return json_build_object('success',false,'message','د لومړي اډمین کوډ ناسم دی.'); end if;
  if exists(select 1 from public.admins where role='owner' and enabled=true) or exists(select 1 from public.admins) then
    return json_build_object('success',false,'message','لومړی اډمین لا مخکې جوړ شوی دی.');
  end if;
  insert into public.admins(id,role,enabled) values(auth.uid(),'owner',true);
  return json_build_object('success',true,'role','owner');
end; $$;
revoke execute on function public.claim_first_owner(text) from public;
grant execute on function public.claim_first_owner(text) to authenticated;

-- د مجازي/دوهم اډمین ثابت پاسورډ. مجازي اډمین یوازې پوسټونه جوړولی شي.
drop function if exists public.login_virtual_admin(text);
create or replace function public.login_virtual_admin(p_password text)
returns json language plpgsql security definer set search_path=public as $$
begin
  if auth.uid() is null then return json_build_object('success',false,'message','حساب پیدا نه شو.'); end if;
  if p_password <> 'Rokhan@12345' then return json_build_object('success',false,'message','د مجازي اډمین پاسورډ ناسم دی.'); end if;
  if not exists(select 1 from public.admins where role='owner' and enabled=true) then
    return json_build_object('success',false,'message','لومړی اصلي اډمین باید مخکې جوړ شي.');
  end if;
  insert into public.admins(id,role,enabled) values(auth.uid(),'editor',true)
    on conflict(id) do update set role='editor',enabled=true;
  return json_build_object('success',true,'role','editor');
end; $$;
revoke execute on function public.login_virtual_admin(text) from public;
grant execute on function public.login_virtual_admin(text) to authenticated;

create or replace function public.redeem_admin_code(p_code text)
returns json language plpgsql security definer set search_path=public as $$
declare v_code public.admin_codes%rowtype;
begin
  if auth.uid() is null then return json_build_object('success',false,'message','حساب پیدا نه شو.'); end if;
  select * into v_code from public.admin_codes where code=p_code and enabled=true for update;
  if not found then return json_build_object('success',false,'message','دا کوډ ناسم یا غیر فعال دی.'); end if;
  insert into public.admins(id,role,enabled) values(auth.uid(),'editor',true)
    on conflict(id) do update set enabled=true;
  update public.admin_codes set enabled=false,used_by=auth.uid() where code=p_code;
  return json_build_object('success',true);
end; $$;
grant execute on function public.redeem_admin_code(text) to authenticated;

create or replace function public.increment_post_view(p_post_id bigint)
returns void language sql security definer set search_path=public as $$
  update public.posts set views=views+1,updated_at=now() where id=p_post_id;
$$;
grant execute on function public.increment_post_view(bigint) to authenticated;

create or replace function public.toggle_post_like(p_post_id bigint)
returns json language plpgsql security definer set search_path=public as $$
declare v_liked boolean;
begin
  if auth.uid() is null then return json_build_object('liked',false); end if;
  if exists(select 1 from public.post_likes where post_id=p_post_id and user_id=auth.uid()) then
    delete from public.post_likes where post_id=p_post_id and user_id=auth.uid();
    update public.posts set likes=greatest(0,likes-1) where id=p_post_id;
    v_liked:=false;
  else
    insert into public.post_likes(post_id,user_id) values(p_post_id,auth.uid()) on conflict do nothing;
    update public.posts set likes=likes+1 where id=p_post_id;
    v_liked:=true;
  end if;
  return json_build_object('liked',v_liked);
end; $$;
grant execute on function public.toggle_post_like(bigint) to authenticated;

-- د اډمین پوسټونه تل له ۰ لیدنو/لایکونو شروع کېږي؛ مالک وروسته شمېرې بدلولی شي.
drop policy if exists "posts_insert" on public.posts;
create policy "posts_insert" on public.posts for insert to authenticated
with check (public.is_admin() and created_by=auth.uid() and (public.is_owner() or (views=0 and likes=0)));
