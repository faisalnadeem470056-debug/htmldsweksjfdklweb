window.MIDOK_CONFIG = {
  "url": "https://yiozxgmolugolfiocrwx.supabase.co",
  "publicKey": "sb_publishable_5jKQuq7QFyvkY_h54hp6LA_MfSsvW-N"
};
