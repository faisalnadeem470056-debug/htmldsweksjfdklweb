function calculateSubnet() {

    const network = document.getElementById("network").value.trim();
    const subnetCount = Number(
        document.getElementById("subnets").value
    );

    const result = document.getElementById("subnetResult");

    if (!isValidIP(network)) {
        result.innerHTML = "<p>Network Address tidak valid.</p>";
        return;
    }

    if (
        !Number.isInteger(subnetCount) ||
        subnetCount < 1
    ) {
        result.innerHTML = "<p>Jumlah subnet tidak valid.</p>";
        return;
    }

    const requiredBits = Math.ceil(
        Math.log2(subnetCount)
    );

    const newCIDR = 24 + requiredBits;

    if (newCIDR > 32) {
        result.innerHTML =
            "<p>Jumlah subnet terlalu banyak.</p>";
        return;
    }

    const blockSize =
        Math.pow(2, 32 - newCIDR);

    const ipParts = network.split(".").map(Number);

    let output = `
        <div class="result-box">
            <h2>Hasil Subnet</h2>
            <p><b>CIDR baru:</b> /${newCIDR}</p>
            <p><b>Ukuran blok:</b> ${blockSize}</p>
            <hr>
    `;

    for (let i = 0; i < subnetCount; i++) {

        const start =
            ipToNumber(ipParts) + (i * blockSize);

        const end =
            start + blockSize - 1;

        output += `
            <p>
                <b>Subnet ${i + 1}</b><br>
                Network: ${numberToIP(start)}<br>
                Broadcast: ${numberToIP(end)}
            </p>
            <hr>
        `;
    }

    output += `</div>`;

    result.innerHTML = output;
}


function isValidIP(ip) {

    const parts = ip.split(".");

    if (parts.length !== 4) {
        return false;
    }

    return parts.every(part => {

        const number = Number(part);

        return (
            part !== "" &&
            Number.isInteger(number) &&
            number >= 0 &&
            number <= 255
        );
    });
}


function ipToNumber(parts) {

    return (
        parts[0] * 256 ** 3 +
        parts[1] * 256 ** 2 +
        parts[2] * 256 +
        parts[3]
    );
}


function numberToIP(number) {

    return [
        Math.floor(number / 256 ** 3) % 256,
        Math.floor(number / 256 ** 2) % 256,
        Math.floor(number / 256) % 256,
        number % 256
    ].join(".");
}